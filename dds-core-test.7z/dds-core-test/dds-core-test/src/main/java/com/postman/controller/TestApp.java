package com.postman.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class TestApp {

	public static void main(String[] args) {

	

		 
	/*	 try {
			 
			 String filePath = "D:\\dds-core-test.xml";
			 File inputFile = new File(filePath);
			 
			 String xmlFile = inputFile.getAbsolutePath();
			 
			 Paths.get(xmlFile);
			 System.out.println(Files.lines(Paths.get(xmlFile)).collect(Collectors.joining("/n/t")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		try {
			String xmlFilePath = "D:\\dds-core-test.xml";
			
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			
            Document document = documentBuilder.parse(xmlFilePath);
            
            Node company = document.getFirstChild();

            Node staff = document.getElementsByTagName("request").item(0);
            
            NodeList list = staff.getChildNodes();
            
            for (int i = 0; i < list.getLength(); i++) {
            	Node node = list.item(i);

     		   // get the salary element, and update the value
     		   if ("CallerId".equals(node.getNodeName())) {
     			   node.setTextContent("20000");
     		   }
            }
            /*NamedNodeMap attr = staff.getAttributes();
    		Node nodeAttr = attr.getNamedItem("id");
    		nodeAttr.setTextContent("2");
    		
    		System.out.println(staff);*/
    		
    		
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

}
