package com.postman.Entity;

public class ParcelCodingInfo {

}
