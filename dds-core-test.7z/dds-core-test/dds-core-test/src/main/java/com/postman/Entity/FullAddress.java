package com.postman.Entity;

public class FullAddress {

}
