package com.postman.Entity;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(propOrder = { "Barcodes", "DestinationStation", "FullAddress",
		"Identcode", "Image", "ParPicId", "ParcelAddress", "ParcelCodingInfo",
		"ProduktZusatzleistungen", "SourceStation", "Timestamp", "VcsCase" })
@XmlRootElement(name = "ParcelInfo")
public class ParcelInfo {

	private Barcodes Barcodes;
	private String DestinationStation;
	private FullAddress FullAddress;
	private String Identcode;
	private String Image;
	private String ParPicId;
	private ParcelAddress ParcelAddress;
	private ParcelCodingInfo ParcelCodingInfo;
	private Boolean ProduktZusatzleistungen;
	private String SourceStation;
	private String Timestamp;
	private String VcsCase;

	public Barcodes getBarcodes() {
		return Barcodes;
	}
	
    @XmlElement( name = "Barcodes" )
	public void setBarcodes(Barcodes barcodes) {
		Barcodes = barcodes;
	}

	public String getDestinationStation() {
		return DestinationStation;
	}
	
    @XmlElement( name = "DestinationStation" )
	public void setDestinationStation(String destinationStation) {
		DestinationStation = destinationStation;
	}

	public FullAddress getFullAddress() {
		return FullAddress;
	}
	
    @XmlElement( name = "FullAddress" )
	public void setFullAddress(FullAddress fullAddress) {
		FullAddress = fullAddress;
	}

	public String getIdentcode() {
		return Identcode;
	}
	
    @XmlElement( name = "Identcode" )
	public void setIdentcode(String identcode) {
		Identcode = identcode;
	}

	public String getImage() {
		return Image;
	}
	
    @XmlElement( name = "Image" )
	public void setImage(String image) {
		Image = image;
	}
    
	public String getParPicId() {
		return ParPicId;
	}
	
    @XmlElement( name = "ParPicId" )
	public void setParPicId(String parPicId) {
		ParPicId = parPicId;
	}

	public ParcelAddress getParcelAddress() {
		return ParcelAddress;
	}
	
    @XmlElement( name = "ParcelAddress" )
	public void setParcelAddress(ParcelAddress parcelAddress) {
		ParcelAddress = parcelAddress;
	}

	public ParcelCodingInfo getParcelCodingInfo() {
		return ParcelCodingInfo;
	}
	
    @XmlElement( name = "ParcelCodingInfo" )
	public void setParcelCodingInfo(ParcelCodingInfo parcelCodingInfo) {
		ParcelCodingInfo = parcelCodingInfo;
	}

	public Boolean getProduktZusatzleistungen() {
		return ProduktZusatzleistungen;
	}
	
    @XmlElement( name = "ProduktZusatzleistungen" )
	public void setProduktZusatzleistungen(Boolean produktZusatzleistungen) {
		ProduktZusatzleistungen = produktZusatzleistungen;
	}

	public String getSourceStation() {
		return SourceStation;
	}
	
    @XmlElement( name = "SourceStation" )
	public void setSourceStation(String sourceStation) {
		SourceStation = sourceStation;
	}

	public String getTimestamp() {
		return Timestamp;
	}
	
    @XmlElement( name = "Timestamp" )
	public void setTimestamp(String timestamp) {
		Timestamp = timestamp;
	}

	public String getVcsCase() {
		return VcsCase;
	}
	
    @XmlElement( name = "VcsCase" )
	public void setVcsCase(String vcsCase) {
		VcsCase = vcsCase;
	}

}
