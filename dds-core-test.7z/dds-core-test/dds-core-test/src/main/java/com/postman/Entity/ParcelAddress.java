package com.postman.Entity;

public class ParcelAddress {

}
