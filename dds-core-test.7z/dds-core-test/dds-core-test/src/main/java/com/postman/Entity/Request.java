package com.postman.Entity;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType( propOrder = { "CallerId", "ParcelInfo", "ParcelInfoSentTimestamp", "Version" } )
@XmlRootElement( name = "Request" )
public class Request {
	private String CallerId;
	private ParcelInfo ParcelInfo;
	private String ParcelInfoSentTimestamp;
	private String Version;
	
	public String getCallerId() {
		return CallerId;
	}
	
    @XmlElement( name = "CallerId" )
	public void setCallerId(String callerId) {
		CallerId = callerId;
	}
	public ParcelInfo getParcelInfo() {
		return ParcelInfo;
	}
	
    @XmlElement( name = "ParcelInfo" )
	public void setParcelInfo(ParcelInfo parcelInfo) {
		ParcelInfo = parcelInfo;
	}
	public String getParcelInfoSentTimestamp() {
		return ParcelInfoSentTimestamp;
	}
	
    @XmlElement( name = "ParcelInfoSentTimestamp" )
	public void setParcelInfoSentTimestamp(String parcelInfoSentTimestamp) {
		ParcelInfoSentTimestamp = parcelInfoSentTimestamp;
	}
	public String getVersion() {
		return Version;
	}
	
    @XmlElement( name = "Version" )
	public void setVersion(String version) {
		Version = version;
	}
	
}
