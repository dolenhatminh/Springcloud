package com.postman.Entity;

public class Barcodes {

}
