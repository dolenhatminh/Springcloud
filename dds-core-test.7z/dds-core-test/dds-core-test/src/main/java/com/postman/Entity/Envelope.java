package com.postman.Entity;

public class Envelope {
	private String CallerId;
	
}
