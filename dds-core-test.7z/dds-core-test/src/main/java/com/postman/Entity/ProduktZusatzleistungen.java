package com.postman.Entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ProduktZusatzleistungen")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProduktZusatzleistungen {
	
	
	@XmlAttribute(name = "i:nil")
	private boolean nil;

	public boolean isNil() {
		return nil;
	}

	public void setNil(boolean nil) {
		this.nil = nil;
	}
	
}
