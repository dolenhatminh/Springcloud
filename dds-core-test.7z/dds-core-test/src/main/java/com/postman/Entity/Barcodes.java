package com.postman.Entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement( name = "Barcodes" )
@XmlAccessorType(XmlAccessType.FIELD)
public class Barcodes {
	
    @XmlElement( name = "Barcode" )
	private Barcode Barcode;

	public Barcode getBarcode() {
		return Barcode;
	}
	
	public void setBarcode(Barcode barcode) {
		Barcode = barcode;
	}
	
	
	
}
