package com.postman.Entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlType( propOrder = { "CallerId", "ParcelInfo", "ParcelInfoSentTimestamp", "Version" } )
@XmlRootElement( name = "Request" )
@XmlAccessorType(XmlAccessType.FIELD)
public class Request {
	
	@XmlAttribute(name = "xmlns:i")
	private String xmlns;
    @XmlElement( name = "CallerId" )
	private String CallerId;
    @XmlElement( name = "ParcelInfo" )
	private ParcelInfo ParcelInfo;
    @XmlElement( name = "ParcelInfoSentTimestamp" )
	private String ParcelInfoSentTimestamp;
    @XmlElement( name = "Version" )
	private String Version;
	
	public String getCallerId() {
		return CallerId;
	}
	
	public void setCallerId(String callerId) {
		CallerId = callerId;
	}
	public ParcelInfo getParcelInfo() {
		return ParcelInfo;
	}
	
	public void setParcelInfo(ParcelInfo parcelInfo) {
		ParcelInfo = parcelInfo;
	}
	public String getParcelInfoSentTimestamp() {
		return ParcelInfoSentTimestamp;
	}
	
	public void setParcelInfoSentTimestamp(String parcelInfoSentTimestamp) {
		ParcelInfoSentTimestamp = parcelInfoSentTimestamp;
	}
	public String getVersion() {
		return Version;
	}
	
	public void setVersion(String version) {
		Version = version;
	}

	public String getXmlns() {
		return xmlns;
	}

	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}
	
	
}
