package com.postman.Entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "Barcodes", "DestinationStation", "FullAddress",
		"Identcode", "Image", "ParPicId", "ParcelAddress", "ParcelCodingInfo",
		"ProduktZusatzleistungen", "SourceStation", "Timestamp", "VcsCase" })
@XmlRootElement(name = "ParcelInfo")
@XmlAccessorType(XmlAccessType.FIELD)
public class ParcelInfo {
	
    @XmlElement( name = "Barcodes" )
	private Barcodes Barcodes;
    @XmlElement( name = "DestinationStation" )
	private String DestinationStation;
    @XmlElement( name = "FullAddress" )
	private FullAddress FullAddress;
    @XmlElement( name = "Identcode" )
	private String Identcode;
    @XmlElement( name = "Image" )
	private String Image;
    @XmlElement( name = "ParPicId" )
	private String ParPicId;
    @XmlElement( name = "ParcelAddress" )
	private ParcelAddress ParcelAddress;
    @XmlElement( name = "ParcelCodingInfo" )
	private ParcelCodingInfo ParcelCodingInfo;
    @XmlElement(name = "ProduktZusatzleistungen")
	private ProduktZusatzleistungen ProduktZusatzleistungen;
    @XmlElement( name = "SourceStation" )
	private String SourceStation;
    @XmlElement( name = "Timestamp" )
	private String Timestamp;
    @XmlElement( name = "VcsCase" )
	private String VcsCase;

	public Barcodes getBarcodes() {
		return Barcodes;
	}
	
	public void setBarcodes(Barcodes barcodes) {
		Barcodes = barcodes;
	}

	public String getDestinationStation() {
		return DestinationStation;
	}
	
	public void setDestinationStation(String destinationStation) {
		DestinationStation = destinationStation;
	}

	public FullAddress getFullAddress() {
		return FullAddress;
	}
	
	public void setFullAddress(FullAddress fullAddress) {
		FullAddress = fullAddress;
	}

	public String getIdentcode() {
		return Identcode;
	}
	
	public void setIdentcode(String identcode) {
		Identcode = identcode;
	}

	public String getImage() {
		return Image;
	}
	
	public void setImage(String image) {
		Image = image;
	}
    
	public String getParPicId() {
		return ParPicId;
	}
	
	public void setParPicId(String parPicId) {
		ParPicId = parPicId;
	}

	public ParcelAddress getParcelAddress() {
		return ParcelAddress;
	}
	
	public void setParcelAddress(ParcelAddress parcelAddress) {
		ParcelAddress = parcelAddress;
	}

	public ParcelCodingInfo getParcelCodingInfo() {
		return ParcelCodingInfo;
	}
	
	public void setParcelCodingInfo(ParcelCodingInfo parcelCodingInfo) {
		ParcelCodingInfo = parcelCodingInfo;
	}

	public ProduktZusatzleistungen getProduktZusatzleistungen() {
		return ProduktZusatzleistungen;
	}
	
	public void setProduktZusatzleistungen(ProduktZusatzleistungen produktZusatzleistungen) {
		ProduktZusatzleistungen = produktZusatzleistungen;
	}

	public String getSourceStation() {
		return SourceStation;
	}
	
	public void setSourceStation(String sourceStation) {
		SourceStation = sourceStation;
	}

	public String getTimestamp() {
		return Timestamp;
	}
	
	public void setTimestamp(String timestamp) {
		Timestamp = timestamp;
	}

	public String getVcsCase() {
		return VcsCase;
	}
	
	public void setVcsCase(String vcsCase) {
		VcsCase = vcsCase;
	}

}
