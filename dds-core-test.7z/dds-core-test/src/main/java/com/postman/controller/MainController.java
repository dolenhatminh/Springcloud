package com.postman.controller;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

public class MainController {

	private static String username = "pnmai";
	private static String password = "abc123";

	public static void main(String[] args) {
		try {
			String filePath = "dds-core-test.xml";
	        File xmlFile = new File(filePath);
	        
	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder;
	        
	        dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();
			
			
			HttpResponse<JsonNode> response = Unirest.get("http://10.10.15.196:9200/dds-core-test_2018.04.24/_search")
					.basicAuth(username, password).header("Authorization", "Basic cG5tYWk6YWJjMTIz")
					.header("Cache-Control", "no-cache").header("Postman-Token", "336f076d-1083-474a-8759-f09ab2eb8fd5")
					.asJson();

			JSONArray listJsArray = response.getBody().getArray();

			for (Object objectJS : listJsArray) {
				JSONObject jsonObject = (JSONObject) objectJS;

				JSONArray JsArray = jsonObject.getJSONObject("hits").getJSONArray("hits");

				for (Object object : JsArray) {
					JSONObject jsonOb = (JSONObject) object;
					if ((jsonOb.getJSONObject("_source").get("message").toString()).equals("Detail of the parcel. The image byte array was removed")) {
							
					}
				}

			}

		} catch (UnirestException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@SuppressWarnings("unused")
	private static void updateElementValue(Document doc) {
		 NodeList employees = doc.getElementsByTagName("s:Envelope");
	        Element emp = null;
	        //loop for each employee
	        for(int i=0; i<employees.getLength();i++){
	            emp = (Element) employees.item(i);
	            Node name = emp.getElementsByTagName("name").item(0).getFirstChild();
	            name.setNodeValue(name.getNodeValue().toUpperCase());
	        }
		
	}

}
