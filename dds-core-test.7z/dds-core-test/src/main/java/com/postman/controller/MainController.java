package com.postman.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.postman.Entity.Barcode;
import com.postman.Entity.Barcodes;
import com.postman.Entity.Body;
import com.postman.Entity.Envelope;
import com.postman.Entity.FullAddress;
import com.postman.Entity.ParcelAddress;
import com.postman.Entity.ParcelCodingInfo;
import com.postman.Entity.ParcelInfo;
import com.postman.Entity.ProduktZusatzleistungen;
import com.postman.Entity.Request;
import com.postman.Entity.TransferParcelInfo;

public class MainController {

	private final static String username = "pnmai";
	private final static String password = "abc123";
	private final static String url = "http://10.10.15.196:9200/dds-core-test_2018.04.24/_search";
	private final static String fileIma = "C:\\Users\\dlnminh\\Documents\\Downloads\\42202582-8684-4c63-96be-71a436d4e464.tif";
	private final static String filexml = "C:\\Users\\dlnminh\\Desktop\\dds-core-test.xml";	
	
	public static void main(String[] args) {
		try {
			
			// converting image byte array into Base64 
			File file = new File(fileIma);
			
			byte image [] = readImage(file);
			String imageDt = "";
			
			if (image.length > 0) {
				 imageDt = encodeImage(image);
			}
			
			// Access PostMan and convert data xml to json
			HttpResponse<JsonNode> response = Unirest.get(url)
					.basicAuth(username, password).header("Authorization", "Basic cG5tYWk6YWJjMTIz")
					.header("Cache-Control", "no-cache").header("Postman-Token", "336f076d-1083-474a-8759-f09ab2eb8fd5")
					.asJson();

			
			JSONArray listJsArray = response.getBody().getArray();
			
			Request request = new Request();
			Body body = new Body();
			Envelope envelope = new Envelope();
			TransferParcelInfo transferParcelInfo = new TransferParcelInfo();
			envelope.setXmlns("http://schemas.xmlsoap.org/soap/envelope/");
			transferParcelInfo.setXmlns("Ch.Post.PL.Vae.VG.ParcelInfoService");
			request.setXmlns("http://www.w3.org/2001/XMLSchema-instance");
			Barcodes barcodes = new Barcodes();
			Barcode barcode = new Barcode(); 
			ParcelInfo parcelInfo = new ParcelInfo();
			FullAddress fullAddress = new FullAddress();
			ParcelAddress parcelAddress = new ParcelAddress();
			ParcelCodingInfo parcelCodingInfo = new ParcelCodingInfo();
			ProduktZusatzleistungen prZusatzleistungen = new ProduktZusatzleistungen();
			
			
			for (Object objectJS : listJsArray) {
				JSONObject jsonObject = (JSONObject) objectJS;

				JSONArray JsArray = jsonObject.getJSONObject("hits").getJSONArray("hits");

				for (Object object : JsArray) {
					JSONObject jsonOb = (JSONObject) object;
					
					if ((jsonOb.getJSONObject("_source").get("message").toString()).equals("Detail of the parcel. The image byte array was removed")) {
						
						JSONObject jsonParcelInfo = jsonOb.getJSONObject("_source").getJSONObject("parcelContent").getJSONObject("parcelInfo");
						
						request.setCallerId(jsonOb.getJSONObject("_source").getJSONObject("parcelContent").get("callerId").toString());	
						JSONArray jsobject = jsonParcelInfo.getJSONArray("barcodes");
							for(Object json : jsobject) {
								JSONObject jsonCode = (JSONObject) json;
								barcode.setCode(jsonCode.get("code").toString());
								barcode.setEdges(jsonCode.get("edges").toString());
								barcode.setType(jsonCode.get("type").toString());
								barcode.setY1(jsonCode.getJSONObject("boundary").get("y1").toString());
								barcode.setX1(jsonCode.getJSONObject("boundary").get("x1").toString());
								barcode.setY2(jsonCode.getJSONObject("boundary").get("y2").toString());
								barcode.setX2(jsonCode.getJSONObject("boundary").get("x2").toString());
								barcode.setY3(jsonCode.getJSONObject("boundary").get("y3").toString());
								barcode.setX3(jsonCode.getJSONObject("boundary").get("x3").toString());
								barcode.setY4(jsonCode.getJSONObject("boundary").get("y4").toString());
								barcode.setX4(jsonCode.getJSONObject("boundary").get("x4").toString());
							}
							
							parcelInfo.setDestinationStation(jsonParcelInfo.get("destinationStation").toString());
							fullAddress.setAddressType(jsonParcelInfo.getJSONObject("fullAddress").get("addressType").toString());
							fullAddress.setAngle(jsonParcelInfo.getJSONObject("fullAddress").get("angle").toString());
							fullAddress.setOrt(jsonParcelInfo.getJSONObject("fullAddress").get("ort").toString());
							fullAddress.setPostleitzahl(jsonParcelInfo.getJSONObject("fullAddress").get("postleitzahl").toString());
							fullAddress.setStrasse(jsonParcelInfo.getJSONObject("fullAddress").get("strasse").toString());
							fullAddress.setStrassennummer(jsonParcelInfo.getJSONObject("fullAddress").get("strassenNummer").toString());
							fullAddress.setVertices(jsonParcelInfo.getJSONObject("fullAddress").get("vertices").toString());
							
							JSONObject jsonBoundary = jsonParcelInfo.getJSONObject("fullAddress").getJSONObject("boundary");
							
							
							fullAddress.setY1(jsonBoundary.get("y1").toString());
							fullAddress.setX1(jsonBoundary.get("x1").toString());
							fullAddress.setY2(jsonBoundary.get("y2").toString());
							fullAddress.setX2(jsonBoundary.get("x2").toString());
							fullAddress.setY3(jsonBoundary.get("y3").toString());
							fullAddress.setX3(jsonBoundary.get("x3").toString());
							fullAddress.setY4(jsonBoundary.get("y4").toString());
							fullAddress.setX4(jsonBoundary.get("x4").toString());
							fullAddress.setZipBase(jsonParcelInfo.getJSONObject("fullAddress").get("zipBase").toString());
							
							
							parcelInfo.setIdentcode(jsonParcelInfo.get("identCode").toString());
							parcelInfo.setImage(imageDt);
							parcelInfo.setParPicId(jsonParcelInfo.get("parPicId").toString());
							parcelInfo.setTimestamp(jsonOb.getJSONObject("_source").get("@timestamp").toString());
							parcelInfo.setVcsCase(jsonParcelInfo.get("vcsCase").toString());
							
							parcelAddress.setAddressType(jsonParcelInfo.getJSONObject("parcelAddress").get("addressType").toString());
							parcelAddress.setHousenumber(jsonParcelInfo.getJSONObject("parcelAddress").get("houseNumber").toString());
							parcelAddress.setStreetnumber(jsonParcelInfo.getJSONObject("parcelAddress").get("streetNumber").toString());
							parcelAddress.setZip(jsonParcelInfo.getJSONObject("parcelAddress").get("zip").toString());
							
							parcelCodingInfo.setCodingQuality(jsonParcelInfo.getJSONObject("parcelCodingInfo").get("codingQuality").toString());
							parcelCodingInfo.setCodingArt(jsonParcelInfo.getJSONObject("parcelCodingInfo").get("codingArt").toString());
							prZusatzleistungen.setNil(true);
							parcelInfo.setProduktZusatzleistungen(prZusatzleistungen);
							parcelInfo.setSourceStation(jsonParcelInfo.get("sourceStation").toString());
							
							
							request.setParcelInfoSentTimestamp(jsonOb.getJSONObject("_source").getJSONObject("parcelContent").get("parcelInfoSentTimestamp").toString());
							request.setVersion(jsonOb.getJSONObject("_source").getJSONObject("parcelContent").get("version").toString());
						
					}
					
				}
				
			}
			
			
			barcodes.setBarcode(barcode);
			parcelInfo.setBarcodes(barcodes);
			parcelInfo.setFullAddress(fullAddress);
			parcelInfo.setParcelAddress(parcelAddress);
			parcelInfo.setParcelCodingInfo(parcelCodingInfo);
			request.setParcelInfo(parcelInfo);
			transferParcelInfo.setRequest(request);
			body.setTransferParcelInfo(transferParcelInfo);
			
			envelope.setBody(body);
			
			
			JAXBContext jaxbContext = JAXBContext.newInstance( Envelope.class );
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            
            jaxbMarshaller.setProperty( Marshaller.JAXB_FORMATTED_OUTPUT, true );

            // marshaling of java objects in xml (output to file and standard output) 
            jaxbMarshaller.marshal( envelope, new File(filexml) );
            jaxbMarshaller.marshal( envelope, System.out );

		} catch (UnirestException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static String encodeImage(byte[]  imageArray ) {
		return Base64.encodeBase64String(imageArray);
	}
	
	public static byte[] readImage(File file) {
		
		FileInputStream fileInputStream;
		byte imageData[] = null ;
		try {
			fileInputStream = new FileInputStream(file);
			imageData = new byte[(int) file.length()];
			if (file != null) {
				fileInputStream.read(imageData);
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return imageData;
	}
}
