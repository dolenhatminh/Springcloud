/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package UI.UserControl.Table;

import java.util.EventListener;

/**
 *
 * @author vtlong
 */
public interface TableButtonListener extends EventListener {
  public void tableButtonClicked( int row, int col );
}
