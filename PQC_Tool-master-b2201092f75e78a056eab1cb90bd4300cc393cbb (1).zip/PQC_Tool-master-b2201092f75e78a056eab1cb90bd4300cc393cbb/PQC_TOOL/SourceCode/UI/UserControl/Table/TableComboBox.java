/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UI.UserControl.Table;

import java.awt.Component;
import java.util.EventObject;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.event.CellEditorListener;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

/**
 *
 * @author Administrator
 */
public class TableComboBox extends JComboBox implements TableCellRenderer {

    String[] source;
    
    public TableComboBox(String[] text) {
        super(text);
        source = text;
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        if(value!=null) {
            setSelectedItem(value);
        } else {
            setSelectedIndex(0);
        }
        return this;
    }    
}
