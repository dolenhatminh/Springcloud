/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UI.UserControl.Table;

import java.awt.Component;
import java.util.EventObject;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.event.CellEditorListener;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

/**
 *
 * @author Administrator
 */
public class TableCheckBox extends JCheckBox implements TableCellRenderer, TableCellEditor {

    public TableCheckBox() {
        super();
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        if(value!=null) {
            setSelected(Boolean.valueOf(value.toString()));
        } else {
            setSelected(false);
        }
        return this;
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        JCheckBox chk = new JCheckBox();
        if(value!=null) {
            chk.setSelected(Boolean.valueOf(value.toString()));
        }
        return chk;
    }

    @Override
    public Object getCellEditorValue() {
        return this.isSelected();
    }

    @Override
    public boolean isCellEditable(EventObject anEvent) {
        return true;
    }

    @Override
    public boolean shouldSelectCell(EventObject anEvent) {
        return true;
    }

    @Override
    public boolean stopCellEditing() {
        return true;
    }

    @Override
    public void cancelCellEditing() {
        
    }

    @Override
    public void addCellEditorListener(CellEditorListener l) {
        
    }

    @Override
    public void removeCellEditorListener(CellEditorListener l) {
        
    }
    
}
