/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UI.UserControl.Table;

/**
 *
 * @author vtlong
 */
public class CellRenderData implements Comparable<CellRenderData> {
    String data = "";
    boolean selected = false;
    private boolean sortInt = false;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    @Override
    public String toString() {
        return data;
    }

    public CellRenderData(String data) {
        this.data = data;
    }
    
    public CellRenderData(String data, boolean sortInt) {
        this.data = data;
        this.sortInt = sortInt;
    }

    /**
     * @return the sortInt
     */
    public boolean isSortInt() {
        return sortInt;
    }

    /**
     * @param sortInt the sortInt to set
     */
    public void setSortInt(boolean sortInt) {
        this.sortInt = sortInt;
    }

    @Override
    public int compareTo(CellRenderData o) {
        if(this.sortInt) {
            if(Integer.valueOf(this.data) == Integer.valueOf(o.data)) {
                return 0;
            } else if(Integer.valueOf(this.data) > Integer.valueOf(o.data)){
                return 1;
            } else {
                return -1;
            }                
        } else {
            return this.data.compareTo(o.data);            
        }
    }
    
}
