/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package UI.UserControl.Tree;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JComponent;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

/**
 *
 * @author vtlong
 */
public class HighlightTreeCellRenderer extends DefaultTreeCellRenderer {
    private static final Color ROLLOVER_ROW_COLOR = new Color(220, 240, 255);
    public String q;
    private boolean rollOver;

    @Override public void updateUI() {
        setTextSelectionColor(null);
        setTextNonSelectionColor(null);
        setBackgroundSelectionColor(null);
        setBackgroundNonSelectionColor(null);
        super.updateUI();
    }
    @Override public Color getBackgroundNonSelectionColor() {
        return rollOver ? ROLLOVER_ROW_COLOR : super.getBackgroundNonSelectionColor();
    }
    @Override public Component getTreeCellRendererComponent(JTree tree, Object value, boolean isSelected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        JComponent c = (JComponent) super.getTreeCellRendererComponent(tree, value, isSelected, expanded, leaf, row, hasFocus);
        if (isSelected) {
            c.setForeground(getTextSelectionColor());
        } else {
            rollOver = q != null && !q.isEmpty() && String.valueOf(value).toLowerCase().contains(q.toLowerCase());
            c.setForeground(getTextNonSelectionColor());
            c.setBackground(getBackgroundNonSelectionColor());
        }
        return c;
    }
}
