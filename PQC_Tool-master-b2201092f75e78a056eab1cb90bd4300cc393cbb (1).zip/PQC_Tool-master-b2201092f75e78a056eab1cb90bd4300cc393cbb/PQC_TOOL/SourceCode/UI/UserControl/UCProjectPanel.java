/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UI.UserControl;

import business.DataManagement;
import business.ObserverManager;
import business.ProjectInfo;
import business.ProjectManagement;
import business.ProjectSelectFileCache;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Observer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;


public class UCProjectPanel extends javax.swing.JPanel {

    private ObserverManager obServerManager;
    private JFileChooser mFc;
    private JTextField txtFilter;
    private JPanel pnlFilter;
    private List<File> mSelectedFile;
    private String directoryPath;
    private javax.swing.filechooser.FileFilter filterText, filterXML;
    private ProjectManagement projectManagement;
    private DataManagement dataManagement;
    private ProjectInfo currentProject;
    private String txtFile = "";

    public UCProjectPanel() {
        initComponents();
        try {
            txtFilter = new JTextField();
            txtFilter.setPreferredSize(new Dimension(200, 20));
            // Listen for changes in the text
            txtFilter.getDocument().addDocumentListener(new DocumentListener() {
              @Override
              public void changedUpdate(DocumentEvent e) {
                rescanDirectory();
              }
              @Override
              public void removeUpdate(DocumentEvent e) {
                rescanDirectory();
              }
              @Override
              public void insertUpdate(DocumentEvent e) {
                rescanDirectory();
              }

              public void rescanDirectory() {
                 mFc.rescanCurrentDirectory();
              }
            });
            pnlFilter = new JPanel(new BorderLayout());
            JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
            panel1.add(new JLabel("Filter text:"));
            JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
            panel2.add(txtFilter);
            pnlFilter.add(panel1, BorderLayout.NORTH);
            pnlFilter.add(panel2, BorderLayout.CENTER);
            
            
            projectManagement = new ProjectManagement();
            obServerManager = new ObserverManager();
            mFc = new JFileChooser();
            mFc.setAcceptAllFileFilterUsed(false);
            filterText = new javax.swing.filechooser.FileFilter() {
                @Override
                public boolean accept(File f) {
                    String s = f.getName();
                    if (f.isDirectory() && s.toLowerCase().contains(txtFilter.getText().toLowerCase())) {
                        return true;
                    }
                    return s.toLowerCase().contains(txtFilter.getText().toLowerCase()) && (s.toLowerCase().endsWith(".txt") || s.toLowerCase().endsWith(".dat") || s.toLowerCase().endsWith(".csv") || s.toLowerCase().endsWith(".xls"));
                }

                @Override
                public String getDescription() {
                    return "*.txt,*.dat,*.csv,*.xls";
                }
            };
            filterXML = new javax.swing.filechooser.FileFilter() {
                @Override
                public boolean accept(File f) {
                    String s = f.getName();
                    if (f.isDirectory() && s.toLowerCase().contains(txtFilter.getText().toLowerCase())) {
                        return true;
                    }
                    return s.toLowerCase().contains(txtFilter.getText().toLowerCase()) && s.toLowerCase().endsWith(".xml");
                }

                @Override
                public String getDescription() {
                    return "*.xml";
                }
            };
            dataManagement = new DataManagement();
            loadAllProject();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public void addObserver(Observer o) {
        obServerManager.addObserver(o);
    }

    public void deleteObserver(Observer o) {
        obServerManager.deleteObserver(o);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cboProject = new javax.swing.JComboBox();
        txtBrowser = new javax.swing.JTextField();
        btnBrowser = new javax.swing.JButton();
        btnShowData = new javax.swing.JButton();
        btnExport = new javax.swing.JButton();
        txtExportKey = new javax.swing.JTextField();
        btnExportBrower = new javax.swing.JButton();

        cboProject.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "------Choose project" }));
        cboProject.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboProjectItemStateChanged(evt);
            }
        });

        txtBrowser.setEditable(false);

        btnBrowser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/16x16/directory_16x16.png"))); // NOI18N
        btnBrowser.setMnemonic('b');
        btnBrowser.setText("Browser");
        btnBrowser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBrowserActionPerformed(evt);
            }
        });

        btnShowData.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/16x16/view.png"))); // NOI18N
        btnShowData.setMnemonic('s');
        btnShowData.setText("Show Data");
        btnShowData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowDataActionPerformed(evt);
            }
        });

        btnExport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/16x16/run.png"))); // NOI18N
        btnExport.setText("Export Key");
        btnExport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportActionPerformed(evt);
            }
        });

        txtExportKey.setEditable(false);

        btnExportBrower.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/16x16/directory_16x16.png"))); // NOI18N
        btnExportBrower.setText("Export Browser");
        btnExportBrower.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportBrowerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cboProject, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtBrowser, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBrowser, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtExportKey, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnExportBrower)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
                .addComponent(btnExport)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnShowData, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboProject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnShowData)
                    .addComponent(txtBrowser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBrowser)
                    .addComponent(btnExport)
                    .addComponent(txtExportKey, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExportBrower))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnBrowserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBrowserActionPerformed
        if (cboProject.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Please choose project!");
            return;
        }
        currentProject = (ProjectInfo) cboProject.getSelectedItem();
        ProjectInfo project = (ProjectInfo) cboProject.getSelectedItem();          
        //<---Cache Directory of selected file 
        ProjectSelectFileCache projCache = new ProjectSelectFileCache();
        mFc.setCurrentDirectory(new File(projCache.getCache(btnBrowser.getText(),project.getProjectName())));
        //--->              
        if (project.getDataType() == ProjectInfo.DataType.TEXT) {
            mFc.setFileSelectionMode(JFileChooser.FILES_ONLY);
            mFc.removeChoosableFileFilter(filterXML);
            mFc.addChoosableFileFilter(filterText);
            mFc.setMultiSelectionEnabled(true);
        } else {
            mFc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
            mFc.removeChoosableFileFilter(filterText);
            mFc.addChoosableFileFilter(filterXML);
            mFc.setMultiSelectionEnabled(true);
        }
        try {
            if (mFc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                for (File file : mFc.getSelectedFiles()) {
                    if (!file.exists()) {
                        return;
                    }
                }
                mSelectedFile = Arrays.asList(mFc.getSelectedFiles());
                String text = "";
                String fileDir = "";    //<--cache-->
                for (File file : mSelectedFile) {
                    text += file.getName() + ";";
                    fileDir = file.getParentFile().getCanonicalPath(); //<--cache-->
                }
                txtBrowser.setText(text.substring(0, text.length() - 1));
                //<---Cache Directory of selected file
                projCache.addCache(btnBrowser.getText(),project.getProjectName(), fileDir); 
                //--->
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "File's not compatible!");
            ex.printStackTrace();
        }
    }//GEN-LAST:event_btnBrowserActionPerformed

    private void loadAllProject() throws Exception {
        List<ProjectInfo> projects = projectManagement.getAllProjects();
        for (ProjectInfo project : projects) {
            cboProject.addItem(project);
        }
    }

    private void btnShowDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowDataActionPerformed
        if (mSelectedFile == null) {
            JOptionPane.showMessageDialog(this, "Please choose files to view!");
            return;
        }
        List<Object> projectAndFiles = new ArrayList<Object>();
        projectAndFiles.add(cboProject.getSelectedItem());
        projectAndFiles.add(mSelectedFile);
        obServerManager.notifyObserver(projectAndFiles);
    }//GEN-LAST:event_btnShowDataActionPerformed

    private void cboProjectItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboProjectItemStateChanged
        txtBrowser.setText("");
        mFc = new JFileChooser(mFc.getCurrentDirectory());
        mFc.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
              if (JFileChooser.DIRECTORY_CHANGED_PROPERTY.equals(evt.getPropertyName())) {
                txtFilter.setText("");
              }
            }
        });
        mFc.setAccessory(pnlFilter);
        mFc.setAcceptAllFileFilterUsed(false);
        mSelectedFile = null;
            
    }//GEN-LAST:event_cboProjectItemStateChanged

   
    private void btnExportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportActionPerformed
        // TODO add your handling code here:
         if (cboProject.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Please choose project!");
            return;
        } 
         else if (mSelectedFile == null) {
            JOptionPane.showMessageDialog(this, "Please choose files to view!");
            return;
        } else if (directoryPath == null){
             JOptionPane.showMessageDialog(this, "Please choose directoryPath for exportkey!");
            return;
        }
        
       ProjectInfo project = (ProjectInfo) cboProject.getSelectedItem();      
       if (project.getDataType() == ProjectInfo.DataType.XML) {
           try{
               exportkey();
               JOptionPane.showMessageDialog(this, "ExportKey is Sucessfully!"); 
           }catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "ExportKey is Error " + ex.getMessage());
                return;
           }
           
       }
        if (project.getDataType() != ProjectInfo.DataType.XML) {
            JOptionPane.showMessageDialog(this, "Support with xml file!");
        }
       
        
       
    }//GEN-LAST:event_btnExportActionPerformed

    private void btnExportBrowerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportBrowerActionPerformed
        // TODO add your handling code here:
        if (cboProject.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Please choose project!");
            return;
        } 
        ProjectInfo project = (ProjectInfo) cboProject.getSelectedItem();
        //<---Lock directory of file select on Desktop--->
        mFc.setSelectedFile(new File(System.getProperty("user.home")+"//Desktop//."));
        try {
            if (mFc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                File file = mFc.getSelectedFile();
                txtExportKey.setText(file.getAbsolutePath());
                directoryPath = file.getAbsolutePath();
            }
        }  catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "File's not compatible!");
            ex.printStackTrace();
        }
        
    }//GEN-LAST:event_btnExportBrowerActionPerformed

    private void exportkey() throws Exception{
        List<List<String>> listExportKey = null;        
        txtFile = directoryPath + ".txt";
        if (mSelectedFile.size() == 1 && mSelectedFile.get(0).isFile()) {
                listExportKey =  dataManagement.readXMLFileForExportKey(currentProject,mSelectedFile.get(0));
                if (listExportKey.isEmpty() || listExportKey.isEmpty()) {
                    throw new Exception("Can't found data QC on selected files!");
                }
                File file = new File(txtFile);
                if (!file.exists()) {
                    file.createNewFile();
                }
                FileWriter fw = new FileWriter(file);
                BufferedWriter bw = new BufferedWriter(fw);
                for (int i = 0; i < listExportKey.size(); i++) {
                    bw.write(listExportKey.get(i).get(0));
                    bw.newLine();
                }
                bw.flush();
                bw.close();
         } else {List<File> listFile = new ArrayList<File>();
                for (File file : mSelectedFile) {
                    getAllFileXMLInFolderAndSubFolder(listFile, file);
                }

                Collections.sort(listFile, new Comparator<File>() {
                    @Override
                    public int compare(File f1, File f2) {
                        return f1.getName().compareTo(f2.getName());
                    }
                });
                List<List<String>> listFileData = (List<List<String>>) dataManagement.getListFileXMLOnTable(currentProject, listFile);
                if (listFile.isEmpty() || listFileData.isEmpty()) {
                    throw new Exception("Can't found data QC on selected files!");
                }
               listExportKey = new ArrayList<List<String>>();
                for (int i = 0; i < listFileData.size(); i++) {                    
                    listExportKey.addAll(dataManagement.readXMLFileForExportKey(currentProject,new File(listFileData.get(i).get(2))));
                }
                
                File file = new File(txtFile);
                if (!file.exists()) {
                    file.createNewFile();
                }
                FileWriter fw = new FileWriter(file);
                BufferedWriter bw = new BufferedWriter(fw);
                for (int i = 0; i < listExportKey.size(); i++) {
                    bw.write(listExportKey.get(i).get(0));
                    bw.newLine();
                }
                bw.flush();
                bw.close();
                
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBrowser;
    private javax.swing.JButton btnExport;
    private javax.swing.JButton btnExportBrower;
    private javax.swing.JButton btnShowData;
    private javax.swing.JComboBox cboProject;
    private javax.swing.JTextField txtBrowser;
    private javax.swing.JTextField txtExportKey;
    // End of variables declaration//GEN-END:variables
    
     private void getAllFileXMLInFolderAndSubFolder(List<File> listFile, File file) {
        if (file.isFile() && file.getPath().toLowerCase().endsWith(".xml")) {
            listFile.add(file);
        } else if (file.isDirectory()) {
            for (File fileChild : file.listFiles()) {
                getAllFileXMLInFolderAndSubFolder(listFile, fileChild);
            }
        }

    }




}
