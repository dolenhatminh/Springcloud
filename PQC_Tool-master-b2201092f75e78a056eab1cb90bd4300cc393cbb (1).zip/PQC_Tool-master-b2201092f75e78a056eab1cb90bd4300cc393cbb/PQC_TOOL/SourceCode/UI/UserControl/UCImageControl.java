/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UI.UserControl;

import com.sun.media.jai.codec.FileSeekableStream;
import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageDecoder;
import com.sun.media.jai.codec.SeekableStream;
import com.sun.media.jai.codec.TIFFDecodeParam;
import com.sun.media.jai.widget.DisplayJAI;
import java.awt.Cursor;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.awt.image.renderable.ParameterBlock;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.RandomAccessFile;
import javax.media.jai.Interpolation;
import javax.media.jai.JAI;
import javax.media.jai.PlanarImage;
import javax.swing.JScrollPane;
import utilities.ImageUtils;
import utilities.TIFConvert;
import utilities.TIFConvertPDF;

/**
 *
 * @author vtlong
 */
public class UCImageControl extends DisplayJAI implements MouseListener, MouseMotionListener {

    private String imagePath = "";
    private Point begin, end;
    private int zoom = 100;
    private int page = 0;
    private final int ZOOM_DEFAULT = 100;

    public UCImageControl() {
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    public void setImage(String fileName) throws Exception {
        try {
            File file = new File(fileName);
            if (!fileName.equals("") && file.exists()) {
                this.setImagePath(fileName);
                this.page = 0;
                setImage();
            } else {
                this.setImagePath("");
                this.set(new PlanarImage() {
                    @Override
                    public Raster getTile(int i, int i1) {
                        throw new UnsupportedOperationException("Not supported yet.");
                    }
                });
            }
        } catch (Exception ex) {
            throw ex;
        }
    }

    public void setPage(int page) throws Exception {
        this.page = page;
        setImage();
    }

    public void setImage() throws Exception {
        try {
            File file = new File(getImagePath());
            if (file.exists()) {
                PlanarImage image = readImage(this.page, zoom);
                this.set(image);
            } else {
                this.set(new PlanarImage() {
                    @Override
                    public Raster getTile(int i, int i1) {
                        throw new UnsupportedOperationException("Not supported yet.");
                    }
                });
            }
        } catch (Exception ex) {
            throw ex;
        }
    }

    public void zoomIn() throws Exception {
        if (zoom >= 30) {
            zoom = zoom - 10;
        }
        setImage();
    }

    public void zoomOut() throws Exception {
        if (zoom <= 300) {
            zoom = zoom + 10;
        }
        setImage();
    }
    private BufferedImage[] bufPDF;

    private PlanarImage readImage(int page, int zoom) throws Exception {
        PlanarImage planarImg = null;
        ParameterBlock pb = null;
        SeekableStream s = null;
        bufPDF = null;
        try {
            String ext = getImagePath().substring(getImagePath().lastIndexOf(".") + 1).toLowerCase();
            if (ext.equals("tif") || ext.equals("tiff")) {
                RandomAccessFile f = new RandomAccessFile(getImagePath(), "r");
                byte[] b = new byte[(int) f.length()];
                f.read(b);
                f.close();
                if (s != null) {
                    s.close();
                    s = null;
                }
                InputStream in = new ByteArrayInputStream(b);
                s = SeekableStream.wrapInputStream(in, true);
                in.close();
                pb = new ParameterBlock();
                pb.add(s);
                pb.add(new TIFFDecodeParam());
                pb.add(page);
                planarImg = JAI.create("TIFF", pb);
            } else {
                if (ext.equals("jpg") || ext.equals("jpeg")) {
                    planarImg = ImageUtils.load(new File(getImagePath()));
                } else if (ext.equals("pdf")) {
                    if (bufPDF == null) {
                        bufPDF = TIFConvertPDF.getImageFromPDF(getImagePath(), 200, TIFConvert.CLR_RGB, TIFConvert.COMPRESSION_LZW);
                    }
                    planarImg = PlanarImage.wrapRenderedImage(bufPDF[page]);
                }
            }

            if (zoom != ZOOM_DEFAULT) {
                pb = new ParameterBlock();
                pb.addSource(planarImg);
                pb.add((float) zoom / ZOOM_DEFAULT);
                pb.add((float) zoom / ZOOM_DEFAULT);
                pb.add(0.0F);
                pb.add(0.0F);
                pb.add(Interpolation.getInstance(Interpolation.INTERP_BICUBIC_2));
                planarImg = JAI.create("scale", pb, null);
            }

            //return planarImg;
        } catch (Exception ex) {
            //JOptionPane.showMessageDialog(null, "Cannot read image: " + ex.getMessage());
            throw ex;
            //return null;
        } finally {
            pb = null;
        }
        return planarImg;
    }

    public int getTotalPage() {
        int retVal = 0;
        if (getImagePath().equals("")) {
            return retVal;
        }

        String ext = getImagePath().substring(getImagePath().lastIndexOf(".") + 1).toLowerCase();
        if (ext.equals("pdf")) {
            return bufPDF.length;
        } else if (ext.equals("tif") || ext.equals("tiff")) {
            SeekableStream s = null;
            ImageDecoder dec = null;
            try {
                File file = new File(getImagePath());
                s = new FileSeekableStream(file);
                TIFFDecodeParam param = null;
                dec = ImageCodec.createImageDecoder("tiff", s, param);
                retVal = dec.getNumPages();
            } catch (Exception ex) {
                return 1;
            }
        } else {
            return 1;

        }
        return retVal;
    }

    @Override
    public void mousePressed(MouseEvent me) {
        begin = me.getPoint();
        end = me.getPoint();
        setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
    }

    @Override
    public void mouseDragged(MouseEvent me) {
        end = me.getPoint();
        int x = end.x - begin.x;
        int y = end.y - begin.y;
        //begin = end;
        JScrollPane scroll = (JScrollPane) getParent().getParent();
        scroll.getVerticalScrollBar().setValue(scroll.getVerticalScrollBar().getValue() - y);
        scroll.getHorizontalScrollBar().setValue(scroll.getHorizontalScrollBar().getValue() - x);
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    }

    /**
     * @return the imagePath
     */
    public String getImagePath() {
        return imagePath;
    }

    /**
     * @param imagePath the imagePath to set
     */
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}
