/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UI.UserControl;

import UI.UserControl.Table.CellRenderData;
import UI.UserControl.Table.TableColumnAdjuster;
import UI.UserControl.Tree.HighlightTreeCellRenderer;
import business.DataManagement;
import business.FieldInfo;
import business.Node;
import business.ObserverManager;
import business.ProjectInfo;
import dbaccess.Configuration;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.SortOrder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import utilities.CommonUtilities;

/**
 *
 * @author Administrator
 */
public class UCListDataPanel extends javax.swing.JPanel implements Observer {

    /**
     * Creates new form UCListDataPanel
     */
    private ObserverManager obServerManager;
    private ProjectInfo currentProject;
    private List<File> mSelectedFile;
    private DefaultTableModel tableData, tableXMLFile;
    TableColumnAdjuster tblDataAdjust, tblFileAdjust, tblDataDetailAdjust;
    private DataManagement dataManagement;
    public final static String[] tableXMLFileColumnNames = {"INDEX", "FILE NAME", "FILE PATH"};
    private HighlightTreeCellRenderer renderer;
    private int rowIndexCurrent = -1;

    public void addObserver(Observer o) {
        obServerManager.addObserver(o);
    }

    public void deleteObserver(Observer o) {
        obServerManager.deleteObserver(o);
    }

    public UCListDataPanel() {
        initComponents();
        obServerManager = new ObserverManager();
        initListDataControl();
        dataManagement = new DataManagement();
    }

    private void initListDataControl() {
        tblData.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblData.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        tblData.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                final Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (value instanceof CellRenderData) {
                    CellRenderData data = (CellRenderData) value;
                    if (data.isSelected()) {
                        c.setBackground(Color.YELLOW.brighter().brighter());
                    } else {
                        c.setBackground(row % 2 == 0 ? table.getSelectionBackground() : Color.WHITE);
                    }
                    if (isSelected) {
                        c.setBackground(table.getSelectionBackground().darker());
                        data.setSelected(true);
                    }
                } else {                    
                }
                return c;
            }
        });

        tblDataDetail.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblDataDetail.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        tblDataDetail.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                final Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (value instanceof CellRenderData) {
                    CellRenderData data = (CellRenderData) value;
                    if (data.isSelected()) {
                        c.setBackground(Color.YELLOW.brighter().brighter());
                    } else {
                        c.setBackground(row % 2 == 0 ? table.getSelectionBackground() : Color.WHITE);
                    }
                    if (isSelected) {
                        c.setBackground(table.getSelectionBackground().darker());
                        data.setSelected(true);
                    }
                }
                return c;
            }
        });

        tblData.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                try {
                    if (e.getValueIsAdjusting()) {
                        loadDataDetailTable(tblData.getSelectedRow(), currentProject);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error load detail: " + ex.getMessage());
                }
            }
        });
        /**/

        tblData.setModel(new DefaultTableModel());
        tblDataAdjust = new TableColumnAdjuster(tblData);
        tblDataAdjust.setColumnHeaderIncluded(true);

        tblDataDetailAdjust = new TableColumnAdjuster(tblDataDetail);
        tblDataDetailAdjust.setColumnHeaderIncluded(true);

        tblFile.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblFile.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        tblFile.setModel(new DefaultTableModel());
        tblFile.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent event) {
                if (!event.getValueIsAdjusting()) {
                    try {
                        showDataXMLOfFile();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        tblFileAdjust = new TableColumnAdjuster(tblFile);
        tblFileAdjust.setColumnHeaderIncluded(true);

        treeData.setEditable(true);
        treeData.setModel(new DefaultTreeModel(null));
        treeData.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        obServerManager.notifyObserver("");
        txtCurrentImagePath.setText("");
        pnlDataDetail.setBorder(javax.swing.BorderFactory.createTitledBorder("Detail Data"));
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnExpand = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel7 = new javax.swing.JPanel();
        jSplitPane2 = new javax.swing.JSplitPane();
        jPanel2 = new javax.swing.JPanel();
        chkShowImagePathColumn = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblData = new javax.swing.JTable();
        lblTotalRow = new javax.swing.JLabel();
        pnlDataDetail = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblDataDetail = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        jSplitPane1 = new javax.swing.JSplitPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblFile = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        treeData = new javax.swing.JTree();
        txtCurrentImagePath = new javax.swing.JTextField();
        btnCopy = new javax.swing.JButton();
        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();

        btnExpand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/16x16/arrow_right_green.png"))); // NOI18N
        btnExpand.setMnemonic('e');
        btnExpand.setText("Expand");
        btnExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExpandActionPerformed(evt);
            }
        });

        jSplitPane2.setDividerLocation(400);
        jSplitPane2.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Data"));

        chkShowImagePathColumn.setMnemonic('a');
        chkShowImagePathColumn.setText("Show image path column");
        chkShowImagePathColumn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkShowImagePathColumnActionPerformed(evt);
            }
        });

        jScrollPane1.setAutoscrolls(true);

        tblData.setAutoCreateRowSorter(true);
        tblData.setFont(new java.awt.Font("Dialog", 0, 14));
        tblData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tblData.setCellSelectionEnabled(true);
        tblData.setDragEnabled(true);
        tblData.setRowHeight(20);
        tblData.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDataMouseClicked(evt);
            }
        });
        tblData.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tblDataKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tblData);

        lblTotalRow.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblTotalRow.setForeground(new java.awt.Color(0, 102, 255));
        lblTotalRow.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblTotalRow.setText("0 row(s)");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 522, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(chkShowImagePathColumn, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblTotalRow, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 498, Short.MAX_VALUE))
                    .addContainerGap()))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 377, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(chkShowImagePathColumn)
                        .addComponent(lblTotalRow))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        jSplitPane2.setLeftComponent(jPanel2);

        pnlDataDetail.setBorder(javax.swing.BorderFactory.createTitledBorder("Detail Data"));

        jScrollPane4.setAutoscrolls(true);

        tblDataDetail.setAutoCreateRowSorter(true);
        tblDataDetail.setFont(new java.awt.Font("Dialog", 0, 14));
        tblDataDetail.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tblDataDetail.setCellSelectionEnabled(true);
        tblDataDetail.setRowHeight(20);
        tblDataDetail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDataDetailMouseClicked(evt);
            }
        });
        tblDataDetail.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tblDataDetailKeyReleased(evt);
            }
        });
        jScrollPane4.setViewportView(tblDataDetail);

        javax.swing.GroupLayout pnlDataDetailLayout = new javax.swing.GroupLayout(pnlDataDetail);
        pnlDataDetail.setLayout(pnlDataDetailLayout);
        pnlDataDetailLayout.setHorizontalGroup(
            pnlDataDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDataDetailLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 498, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlDataDetailLayout.setVerticalGroup(
            pnlDataDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDataDetailLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)
                .addContainerGap())
        );

        jSplitPane2.setRightComponent(pnlDataDetail);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jSplitPane2)
                .addGap(5, 5, 5))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jSplitPane2)
                .addGap(6, 6, 6))
        );

        jTabbedPane1.addTab("Text data", jPanel7);

        jSplitPane1.setDividerLocation(0);
        jSplitPane1.setDividerSize(5);
        jSplitPane1.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);

        tblFile.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(tblFile);

        jSplitPane1.setTopComponent(jScrollPane3);

        treeData.setFont(new java.awt.Font("Dialog", 0, 14));
        treeData.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
            public void valueChanged(javax.swing.event.TreeSelectionEvent evt) {
                treeDataValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(treeData);

        jSplitPane1.setBottomComponent(jScrollPane2);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSplitPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 520, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jSplitPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 563, Short.MAX_VALUE)
                .addGap(4, 4, 4))
        );

        jTabbedPane1.addTab("XML data", jPanel8);

        txtCurrentImagePath.setEditable(false);
        txtCurrentImagePath.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N

        btnCopy.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/16x16/copy.gif"))); // NOI18N
        btnCopy.setMnemonic('c');
        btnCopy.setText("Copy");
        btnCopy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCopyActionPerformed(evt);
            }
        });

        txtSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchKeyReleased(evt);
            }
        });

        btnSearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/16x16/search.png"))); // NOI18N
        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(txtCurrentImagePath)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCopy))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1)
                .addGap(8, 8, 8))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtSearch)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnExpand, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnSearch)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnExpand)
                        .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCopy)
                    .addComponent(txtCurrentImagePath, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void chkShowImagePathColumnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkShowImagePathColumnActionPerformed
        try {
            showHideImagePathColumn();
        } catch (Exception ex) {
        }
    }//GEN-LAST:event_chkShowImagePathColumnActionPerformed

    private void showHideImagePathColumn() throws Exception {
        if (!chkShowImagePathColumn.isSelected()) {
            tblData.getColumn("FULL_FILE_NAME").setMinWidth(0);
            tblData.getColumn("FULL_FILE_NAME").setMaxWidth(0);
        } else {
            tblData.getColumn("FULL_FILE_NAME").setMaxWidth(5000);
            tblDataAdjust.adjustColumn(tblData.getColumn("FULL_FILE_NAME").getModelIndex());
        }
    }

    private void treeDataValueChanged(javax.swing.event.TreeSelectionEvent evt) {//GEN-FIRST:event_treeDataValueChanged
        try {
            DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) treeData.getLastSelectedPathComponent();
            if (selectedNode != null) {
                //enable set button
                Node node = (Node) selectedNode.getUserObject();
                if (node.getChild().isEmpty()) {
                    StringSelection selection = new StringSelection(node.getValue());
                    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                    clipboard.setContents(selection, selection);
                }
                if (!node.getImagePath().isEmpty()) {
                    obServerManager.notifyObserver(node.getImagePath());
                    txtCurrentImagePath.setText(node.getImagePath());
                } else if (node.getRecordNode() != null) {
                    obServerManager.notifyObserver(node.getRecordNode().getImagePath());
                    txtCurrentImagePath.setText(node.getRecordNode().getImagePath());
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error " + ex.getMessage());
        }
    }//GEN-LAST:event_treeDataValueChanged

    private void btnExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExpandActionPerformed
        if (btnExpand.getText().equals("Expand")) {
            btnExpand.setText("Collapse");
            btnExpand.setIcon(new ImageIcon(System.getProperty("user.dir") + "/icons/16x16/arrow_left_green.png"));
        } else {
            btnExpand.setText("Expand");
            btnExpand.setIcon(new ImageIcon(System.getProperty("user.dir") + "/icons/16x16/arrow_right_green.png"));
        }
        obServerManager.notifyObserver(btnExpand.getText().equals("Expand"));
    }//GEN-LAST:event_btnExpandActionPerformed

    private void btnCopyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCopyActionPerformed
        try {            
            StringSelection selection = new StringSelection(txtCurrentImagePath.getText());
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(selection, selection);           
            if (System.getProperty("os.name").toLowerCase().startsWith("linux")) {
                // Build a list of browsers to try, in this order.
                String[] programs = Configuration.getProperties("appImg").split(",");
                if (txtCurrentImagePath.getText().toLowerCase().endsWith(".pdf")) {
                    programs = Configuration.getProperties("appPdf").split(",");
                }
                if (txtCurrentImagePath.getText().toLowerCase().endsWith(".tif") || txtCurrentImagePath.getText().toLowerCase().endsWith(".tiff")) {
                    programs = Configuration.getProperties("appTif").split(",");
                }
                // Build a command string which looks like "browser1 "url" || browser2 "url" ||..."
                StringBuilder cmd = new StringBuilder();
                for (int i = 0; i < programs.length; i++) {
                    cmd.append(i == 0 ? "" : " || ").append(programs[i]).append(" \"").append(txtCurrentImagePath.getText()).append("\" ");
                }
                Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd.toString()});
            } else {               
                Desktop.getDesktop().open(new File(txtCurrentImagePath.getText()));
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } 
    }//GEN-LAST:event_btnCopyActionPerformed

    private void tblDataKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tblDataKeyReleased
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            showImageSelected();
            loadDataDetailTable(tblData.getSelectedRow(), currentProject);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_tblDataKeyReleased

    private void tblDataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDataMouseClicked
        try {
            // TODO add your handling code here:
            showImageSelected();
            loadDataDetailTable(tblData.getSelectedRow(), currentProject);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_tblDataMouseClicked

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        // TODO add your handling code here:
        try {
            hightlightTree();
        } catch (Exception ex) {
            ex.printStackTrace();
        };
        //tree.repaint();
    }//GEN-LAST:event_btnSearchActionPerformed

    private void txtSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            try {
                hightlightTree();
            } catch (Exception ex) {
                ex.printStackTrace();
            };
        }
    }//GEN-LAST:event_txtSearchKeyReleased

    private void tblDataDetailMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDataDetailMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tblDataDetailMouseClicked

    private void tblDataDetailKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tblDataDetailKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tblDataDetailKeyReleased

    private void hightlightTree() throws Exception {
        try {
            if (treeData.getModel().getRoot() == null) {
                return;
            }
            jTabbedPane1.setSelectedIndex(1);
            String q = txtSearch.getText();
            renderer.q = q;
            TreePath root = treeData.getPathForRow(0);
            //collapseAll(treeData, root);
            if (!q.isEmpty()) {
                searchTree(treeData, root, q);
            }
            treeData.repaint();
        } catch (Exception ex) {
            throw ex;
        }
    }

    private static void searchTree(JTree tree, TreePath path, String q) throws Exception {
        try {
            TreeNode node = (TreeNode) path.getLastPathComponent();
            if (node == null) {
                return;
            }
            if (node.toString().toLowerCase().contains(q.toLowerCase())) {
                tree.expandPath(path.getParentPath());
                tree.scrollPathToVisible(path);
            }
            if (!node.isLeaf() && node.getChildCount() >= 0) {
                Enumeration e = node.children();
                while (e.hasMoreElements()) {
                    searchTree(tree, path.pathByAddingChild(e.nextElement()), q);
                }
            }
        } catch (Exception ex) {
            throw ex;
        }
    }

    /*
     private static void collapseAll(JTree tree, TreePath parent) throws Exception {
     try {
     TreeNode node = (TreeNode) parent.getLastPathComponent();
     if (!node.isLeaf() && node.getChildCount() >= 0) {
     Enumeration e = node.children();
     while (e.hasMoreElements()) {
     TreeNode n = (TreeNode) e.nextElement();
     TreePath path = parent.pathByAddingChild(n);
     collapseAll(tree, path);
     }
     }
     tree.collapsePath(parent);
     } catch (Exception ex) {
     throw ex;
     }
     }*/

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCopy;
    private javax.swing.JButton btnExpand;
    private javax.swing.JButton btnSearch;
    private javax.swing.JCheckBox chkShowImagePathColumn;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JSplitPane jSplitPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblTotalRow;
    private javax.swing.JPanel pnlDataDetail;
    private javax.swing.JTable tblData;
    private javax.swing.JTable tblDataDetail;
    private javax.swing.JTable tblFile;
    private javax.swing.JTree treeData;
    private javax.swing.JTextField txtCurrentImagePath;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables

    @Override
    public void update(Observable o, Object arg) {
        try {
            if (arg != null) {
                List<Object> projectAndFiles = (ArrayList<Object>) arg;
                currentProject = (ProjectInfo) projectAndFiles.get(0);
                mSelectedFile = (List<File>) projectAndFiles.get(1);
                showData();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error " + ex.getMessage());
        }
    }
    
    private void showImageSelected() throws Exception {
        String full_file_name = String.valueOf(tblData.getValueAt(tblData.getSelectedRow(), tblData.getColumn("FULL_FILE_NAME").getModelIndex()));
        txtCurrentImagePath.setText(full_file_name);
        obServerManager.notifyObserver(full_file_name);
    }

    private void showDataXMLOfFile() throws Exception {
        try {
            String fileXML = String.valueOf(tblFile.getValueAt(tblFile.getSelectedRow(), tblFile.getColumn("FILE PATH").getModelIndex()));
            List<File> files = new ArrayList<File>();
            files.add(new File(fileXML));
            Node rootNode = (Node) dataManagement.readDataFromFiles(currentProject, files);
            loadDataXMLOnTree(rootNode);
        } catch (Exception ex) {
            throw ex;
        }
    }

    private void showData() throws Exception {
        //long start = Calendar.getInstance().getTimeInMillis();        
        initListDataControl();
        jSplitPane1.setDividerLocation(0);
        if (currentProject.getDataType() == ProjectInfo.DataType.TEXT) {
            List<List<String>> listData = (List<List<String>>) dataManagement.readDataFromFiles(currentProject, mSelectedFile);
            loadDataOnTable(listData);
            jTabbedPane1.setSelectedIndex(0);
        } else {
            if (mSelectedFile.size() == 1 && mSelectedFile.get(0).isFile()) {
                Node rootNode = (Node) dataManagement.readDataFromFiles(currentProject, mSelectedFile);
                loadDataXMLOnTree(rootNode);
            } else {
                List<File> listFile = new ArrayList<File>();
                for (File file : mSelectedFile) {
                    getAllFileXMLInFolderAndSubFolder(listFile, file);
                }

                Collections.sort(listFile, new Comparator<File>() {
                    @Override
                    public int compare(File f1, File f2) {
                        return f1.getName().compareTo(f2.getName());
                    }
                });

                List<List<String>> listFileData = (List<List<String>>) dataManagement.getListFileXMLOnTable(currentProject, listFile);
                if (listFile.isEmpty() || listFileData.isEmpty()) {
                    throw new Exception("Can't found data QC on selected files!");
                }
                loadListFileXMLOnTable(listFileData);
                jSplitPane1.setDividerLocation(100);
            }
            jTabbedPane1.setSelectedIndex(1);
        }
        //System.out.println((Calendar.getInstance().getTimeInMillis() - start));
    }

    private void getAllFileXMLInFolderAndSubFolder(List<File> listFile, File file) {
        if (file.isFile() && file.getPath().toLowerCase().endsWith(".xml")) {
            listFile.add(file);
        } else if (file.isDirectory()) {
            for (File fileChild : file.listFiles()) {
                getAllFileXMLInFolderAndSubFolder(listFile, fileChild);
            }
        }

    }

    private void loadListFileXMLOnTable(List<List<String>> listData) throws Exception {
        tableXMLFile = new DefaultTableModel(tableXMLFileColumnNames, listData.size());
        for (int i = 0; i < tableXMLFile.getRowCount(); i++) {
            for (int j = 0; j < tableXMLFile.getColumnCount(); j++) {
                tableXMLFile.setValueAt(new CellRenderData(listData.get(i).get(j)), i, j);
            }
        }
        tblFile.setModel(tableXMLFile);
        tblFileAdjust.adjustColumns();
        tblFile.setRowSelectionInterval(0, 0);
    }

    private void loadDataOnTable(List<List<String>> listData) throws Exception {
        tableData = new DefaultTableModel(listData.get(0).toArray(), listData.size() - 1){
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return CellRenderData.class;
            }
        };

        for (int i = 0; i < tableData.getRowCount(); i++) {
            for (int j = 0; j < tableData.getColumnCount(); j++) {
                 if(j==0) {
                    tableData.setValueAt(new CellRenderData(listData.get(i + 1).get(j), true), i, j);
                } else {
                    tableData.setValueAt(new CellRenderData(listData.get(i + 1).get(j)), i, j);
                }
            }
        }
        tblData.setModel(tableData);

        //sort table data
        List<FieldInfo> listFieldSort = currentProject.getListFieldSort();
        for (int i = 0; i < listFieldSort.size(); i++) {
            FieldInfo field = listFieldSort.get(i);
            //int columnMove = tableData.findColumn(field.getFieldName().toUpperCase());
            for (int j = 0; j < tblData.getColumnCount(); j++) {
                if (tblData.getColumnName(j).equals(field.getFieldName().toUpperCase())) {
                    tblData.moveColumn(j, i + 1);
                    break;
                }
            }
        }
        //end sort table data

        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(tableData) {
            @Override
            public void toggleSortOrder(int column) {
                if (column >= 0 && column < getModelWrapper().getColumnCount() && isSortable(column)) {
                    List<SortKey> keys = new ArrayList<SortKey>(getSortKeys());
                    if (!keys.isEmpty()) {
                        SortKey sortKey = keys.get(0);
                        if (sortKey.getColumn() == column && sortKey.getSortOrder() == SortOrder.DESCENDING) {
                            setSortKeys(null);
                            return;
                        }
                    }
                }
                super.toggleSortOrder(column);
            }
        };
        tblData.setRowSorter(sorter);

        tblDataAdjust.adjustColumns();
        lblTotalRow.setText(String.valueOf(tblData.getRowCount()) + " row(s)");
        showHideImagePathColumn();
    }

    private void loadDataDetailTable(int rowIndex, ProjectInfo project) throws Exception {
        if (rowIndex < 0) {
            tblDataDetail.setModel(new DefaultTableModel());
            return;
        }
        if(rowIndex == rowIndexCurrent) {
            return;
        }
        tblDataDetail.getTableHeader().setReorderingAllowed(false);
        rowIndexCurrent = rowIndex;
        List<List<String>> dataDetail = new ArrayList<List<String>>();
        int max_column = 0;
        for (int i = 0; i < project.getListFieldSort().size(); i++) {
            FieldInfo field = project.getListFieldSort().get(i);
            if (!field.getSeparator().isEmpty()) {
                List<String> rowData = new ArrayList();
                rowData.add(field.getFieldName());
                int columnIndex = 0;
                for (int j = 0; j < tblData.getColumnCount(); j++) {
                    if (tblData.getColumnName(j).equals(field.getFieldName().toUpperCase())) {
                        columnIndex = tblData.getColumnModel().getColumn(j).getModelIndex();
                        break;
                    }
                }
                String data = tblData.getModel().getValueAt(tblData.convertRowIndexToModel(rowIndex), columnIndex).toString();
                if (!data.isEmpty()) {
                    rowData.addAll(Arrays.asList(data.split(CommonUtilities.getSeparatorWithSpecialCharacter(field.getSeparator()), -1)));
                }
                dataDetail.add(rowData);
                if (rowData.size() > max_column) {
                    max_column = rowData.size();
                }
            }
        }

        if (max_column == 0) {
            return;
        }

        List<List<String>> dataDetailRotate = new ArrayList<List<String>>();
        for (int i = 0; i < max_column; i++) {
            List<String> rowDataRotate = new ArrayList();
            if (i == 0) {
                rowDataRotate.add("ID");
            } else {
                rowDataRotate.add(String.valueOf(i));
            }
            for (List<String> rowData : dataDetail) {
                if (rowData.size() > i) {
                    rowDataRotate.add(rowData.get(i));
                } else {
                    rowDataRotate.add("");
                }
            }
            dataDetailRotate.add(rowDataRotate);
        }

        TableModel tableDataDetail = new DefaultTableModel(dataDetailRotate.get(0).toArray(), dataDetailRotate.size() - 1) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                    return CellRenderData.class;
            }
        };

        for (int i = 0; i < tableDataDetail.getRowCount(); i++) {
            for (int j = 0; j < tableDataDetail.getColumnCount(); j++) {
                if(j==0) {
                    tableDataDetail.setValueAt(new CellRenderData(dataDetailRotate.get(i + 1).get(j), true), i, j);
                } else {
                    tableDataDetail.setValueAt(new CellRenderData(dataDetailRotate.get(i + 1).get(j)), i, j);
                }                
            }
        }
        tblDataDetail.setModel(tableDataDetail);
        pnlDataDetail.setBorder(javax.swing.BorderFactory.createTitledBorder("Detail Data ( " + tblDataDetail.getRowCount() + " rows)"));
        tblDataDetailAdjust.adjustColumns();

    }

    private void loadDataXMLOnTree(Node rootNode) throws Exception {
        TreeModel model = new DefaultTreeModel(buildTree(rootNode));
        renderer = new HighlightTreeCellRenderer();
        txtSearch.setText("");
        treeData.setCellRenderer(renderer);
        treeData.setModel(model);
        /**/
        for (int i = 0; i < treeData.getRowCount(); i++) {
            treeData.expandRow(i);
        }
        /**/
    }

    public DefaultMutableTreeNode buildTree(Node node) throws Exception {
        DefaultMutableTreeNode result;
        result = new DefaultMutableTreeNode(node);
        for (Node child : node.getChild()) {
            if (child.isVisible()) {
                result.add(buildTree(child));
            }
        }
        return result;
    }      
}
