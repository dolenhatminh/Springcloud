/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utilities;

//import Implementation.Sourcecode.application.MainFunctions;
import dbaccess.Configuration;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.swing.table.TableColumn;

//import Implementation.Sourcecode.application.UINavigator;
/**
 *
 * @author nvhviet
 */
public class CommonUtilities {
    
    public static final String LIST_SPECIAL_CHARACTER = "!@#$%^&*()|";

    public static Date convertStringToDate(String pDate) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date temp = new Date();
        try {
            temp = df.parse(pDate);
        } catch (Exception e) {
        }
        return temp;
    }
    
    public static String getSeparatorWithSpecialCharacter(String separator) {
        for (char c : LIST_SPECIAL_CHARACTER.toCharArray()) {
            separator = separator.replace(String.valueOf(c), "\\" + String.valueOf(c));
        }
        return separator;
    }
    
    

    public static Object executejsFunction(String functionName, String script, String[] paramNames, Vector<Object> paramValues) throws ScriptException, NoSuchMethodException {
        ScriptEngineManager _mgr = new ScriptEngineManager();
        ScriptEngine engine = _mgr.getEngineByName("JavaScript");
        engine.eval(script);
        Object result = "";
        for (int i = 0; i < paramNames.length; ++i) {
            engine.put(paramNames[i], paramValues.elementAt(i));
        }
        Invocable invocableEngine = (Invocable) engine;
        result = invocableEngine.invokeFunction(functionName, paramValues.toArray());
        return result;
    }

    public static String getDateFormat(Date date, String format) throws Exception {
        try {
            if (date == null) {
                return "";
            }
            return new SimpleDateFormat(format).format(date);
        } catch (Exception e) {
            throw e;
        }
    }

    public static boolean isNumber(String str) {
        if (str.equals("")) {
            return false;
        }
        char[] chars = str.toCharArray();
        int sz = chars.length;
        boolean hasExp = false;
        boolean hasDecPoint = false;
        boolean allowSigns = false;
        boolean foundDigit = false;
        // deal with any possible sign up front
        int start = (chars[0] == '-') ? 1 : 0;
        if (sz > start + 1) {
            if (chars[start] == '0' && chars[start + 1] == 'x') {
                int i = start + 2;
                if (i == sz) {
                    return false; // str == "0x"
                }
                // checking hex (it can't be anything else)
                for (; i < chars.length; i++) {
                    if ((chars[i] < '0' || chars[i] > '9')
                            && (chars[i] < 'a' || chars[i] > 'f')
                            && (chars[i] < 'A' || chars[i] > 'F')) {
                        return false;
                    }
                }
                return true;
            }
        }
        sz--; // don't want to loop to the last char, check it afterwords
        // for type qualifiers
        int i = start;
        // loop to the next to last char or to the last char if we need another digit to
        // make a valid number (e.g. chars[0..5] = "1234E")
        while (i < sz || (i < sz + 1 && allowSigns && !foundDigit)) {
            if (chars[i] >= '0' && chars[i] <= '9') {
                foundDigit = true;
                allowSigns = false;

            } else if (chars[i] == '.') {
                if (hasDecPoint || hasExp) {
                    // two decimal points or dec in exponent
                    return false;
                }
                hasDecPoint = true;
            } else if (chars[i] == 'e' || chars[i] == 'E') {
                // we've already taken care of hex.
                if (hasExp) {
                    // two E's
                    return false;
                }
                if (!foundDigit) {
                    return false;
                }
                hasExp = true;
                allowSigns = true;
            } else if (chars[i] == '+' || chars[i] == '-') {
                if (!allowSigns) {
                    return false;
                }
                allowSigns = false;
                foundDigit = false; // we need a digit after the E
            } else {
                return false;
            }
            i++;
        }
        if (i < chars.length) {
            if (chars[i] >= '0' && chars[i] <= '9') {
                // no type qualifier, OK
                return true;
            }
            if (chars[i] == 'e' || chars[i] == 'E') {
                // can't have an E at the last byte
                return false;
            }
            if (!allowSigns
                    && (chars[i] == 'd'
                    || chars[i] == 'D'
                    || chars[i] == 'f'
                    || chars[i] == 'F')) {
                return foundDigit;
            }
            if (chars[i] == 'l'
                    || chars[i] == 'L') {
                // not allowing L with an exponent
                return foundDigit && !hasExp;
            }
            // last character is illegal
            return false;
        }
        // allowSigns is true iff the val ends in 'E'
        // found digit it to make sure weird stuff like '.' and '1E-' doesn't pass
        return !allowSigns && foundDigit;
    }

    public static void setColumnWith(TableColumn col, int with) {
        col.setMinWidth(with);
        col.setMaxWidth(with);
    }
    
    public static String addPrefix(String str) throws Exception {
        String tmp = str;
        try {
            String prefixWindows = Configuration.getProperties("prefixWindows");
            String prefixLinux = Configuration.getProperties("prefixLinux");
            if (System.getProperty("os.name").toLowerCase().startsWith("linux")){
                if(!tmp.startsWith(prefixLinux)) {
                    tmp = prefixLinux + tmp;
                }
            }
            else if (System.getProperty("os.name").toLowerCase().startsWith("windows")){
                if(!tmp.startsWith(prefixWindows) && tmp.indexOf(":")!=1) {
                    tmp = prefixWindows + tmp;
                }
            }
        } catch (Exception ex) {
            throw new Exception("Add prefix error: " + ex.getMessage());
        }
        return tmp;
    }
    
    public static String removePrefix(String str) {
        String tmp = str;
        try {
            if (str == null || str.length() <= 0) {
                return str;
            }
            tmp = str.replace("\\", "/");
            tmp = tmp.replace("//", "\\\\");
            String prefixWindows = Configuration.getProperties("prefixWindows");
            String prefixLinux = Configuration.getProperties("prefixLinux");
            prefixWindows = prefixWindows.replace("//", "\\\\");
            if (str.startsWith(prefixWindows)) {
                tmp = str.substring(prefixWindows.length());
            } else if (str.startsWith(prefixLinux)) {
                tmp = str.substring(prefixLinux.length());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return tmp;
    }
    

    public static void runExternalEXE(String filePath, String[] args) {
        try {
            String path = "";
            String os = System.getProperty("os.name");

            if (os.toLowerCase().startsWith("windows")) {
                path = path + "\"" + filePath + "\" ";
            }
            for (int i = 0; i < args.length - 1; i++) {
                if (args[i].startsWith(":")) {
                    args[i] = args[i].substring(1);
                    path += args[i].replace("\"", "\\\"") + " ";
                } else {
                    path += "\"" + args[i].replace("\"", "\\\"") + "\"" + " ";
                }
            }
            path += "\"" + args[args.length - 1].replace("\"", "\\\"") + "\"";
            try {
                Runtime rt = Runtime.getRuntime();
                Process p = null;
                try {
                    p = rt.exec(path);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                if (p != null) {
                    // any error message?
                    StreamGobblerError sE = new StreamGobblerError(p.getErrorStream());
                    sE.start();
                    // any output?
                    StreamGobblerOutput sI = new StreamGobblerOutput(p.getInputStream());
                    sI.start();
                    boolean isRunning = true;
                    while (isRunning) {
                        if (!sE.isAlive() || !sI.isAlive()) {
                            isRunning = false;
                        }
                        Thread.sleep(100);
                    }
                }
                if (p != null) {
                    p.destroy();
                }
                p = null;
                System.gc();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static class StreamGobblerOutput extends Thread {

        InputStream is;

        StreamGobblerOutput(InputStream is) {
            this.is = is;
        }

        public void run() {
            try {
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                String line = null;
                while ((line = br.readLine()) != null) {
                    if (line.equals("IDEAS Change config")) {
                    }
                    System.out.println("OUPUT>" + line);
                }
            } catch (Exception ioe) {
                ioe.printStackTrace();
            }
        }
    }

    private static class StreamGobblerError extends Thread {

        InputStream is;

        StreamGobblerError(InputStream is) {
            this.is = is;
        }

        public void run() {
            try {
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                String line = null;
                while ((line = br.readLine()) != null) {
                    System.out.println("ERROR >" + line);
                }
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }
    }
    
    public static String parseTempParameterString(String input){
        String retVal = input;
        retVal=retVal.replace("IDEASNULL", "");
        retVal=retVal.replace("IDEASBLANK", " ");
        retVal=retVal.replace("IDEASCOMMA", ";");
        retVal=retVal.replace("IDEASNEXTLINE", "\n");
        retVal=retVal.replace("IDEASTAB", "\t");
        return retVal;
    }
    
    public static String getPrefixPath(String path) {
        if (!System.getProperty("os.name").startsWith("Windows")) {
             path = path.replace("P:", "/Public");
             System.out.println(path);
        } else {
            path = path.replace("/Public", "P:");
            path = path.replace("/", "\\");
        }
        return path;
    }
}
