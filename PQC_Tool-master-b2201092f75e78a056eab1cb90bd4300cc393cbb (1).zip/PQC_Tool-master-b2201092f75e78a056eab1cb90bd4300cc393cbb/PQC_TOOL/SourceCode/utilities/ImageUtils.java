package utilities;

import com.sun.media.jai.codec.FileSeekableStream;
import com.sun.media.jai.codec.SeekableStream;
import com.sun.media.jai.codec.TIFFDecodeParam;
import com.sun.media.jai.codec.TIFFEncodeParam;
import com.sun.media.jai.codecimpl.TIFFCodec;
import com.sun.media.jai.codecimpl.TIFFImageEncoder;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.DataBuffer;
import java.awt.image.renderable.ParameterBlock;
import java.awt.image.renderable.RenderedImageFactory;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.FileImageInputStream;
import javax.imageio.stream.ImageInputStream;
import javax.media.jai.BorderExtender;
import javax.media.jai.Histogram;
import javax.media.jai.ImageLayout;
import javax.media.jai.Interpolation;
import javax.media.jai.InterpolationBicubic;
import javax.media.jai.JAI;
import javax.media.jai.KernelJAI;
import javax.media.jai.LookupTableJAI;
import javax.media.jai.OperationRegistry;
import javax.media.jai.ParameterBlockJAI;
import javax.media.jai.PlanarImage;
import javax.media.jai.RegistryElementDescriptor;
import javax.media.jai.RenderedOp;
import javax.media.jai.registry.RIFRegistry;

public abstract class ImageUtils {

    public static float translateMinX = 0f;
    public static float translateMinY = 0f;
    
    public static PlanarImage load(String path) throws MalformedURLException {
        return load(new File(path));
    }

    public static PlanarImage load(File file) {
        return JAI.create("fileload", file.getAbsolutePath());
    }

    public static PlanarImage load(URL url) {
        return JAI.create("url", url);
    }

    public static void save(PlanarImage image, File outputFile, String format) {
        JAI.create("filestore", image, outputFile.getAbsolutePath(), format);
    }

    public static ParameterBlock getParameterBlockForImage(PlanarImage image) {
        ParameterBlock pb = new ParameterBlock();
        pb.addSource(image);
        return pb;
    }

    public static ParameterBlockJAI getParameterBlockJAIForImage(PlanarImage image, String op) {
        ParameterBlockJAI pb = new ParameterBlockJAI(op);
        pb.addSource(image);
        return pb;
    }

    /**
     * Register JAI operators
     */
    public static void registerOp(String productName, String operationName, RegistryElementDescriptor descriptor,
            RenderedImageFactory rif) {
        try {
            OperationRegistry or = JAI.getDefaultInstance().getOperationRegistry();
            or.registerDescriptor(descriptor);
            RIFRegistry.register(or, operationName, productName, rif);
        } catch (IllegalArgumentException e) {
// do nothing: operator already registered
        }
    }

    public static PlanarImage scale(PlanarImage image, float scale) {
        return scale(image, scale, InterpolationBicubic.INTERP_BICUBIC);
    }

    public static PlanarImage scale(PlanarImage image, float scale, int interpolation) {
        ParameterBlock pb = getParameterBlockForImage(image);
        pb.add(scale);
        pb.add(scale);
        pb.add(0.0F);
        pb.add(0.0F);
        pb.add(InterpolationBicubic.getInstance(interpolation));
        return JAI.create("scale", pb);
    }

    public static PlanarImage grayscale(PlanarImage image) {
        if (image.getNumBands() == 1) {
            return image;
        }
        final double[][] matrix1 = {{1. / 3, 1. / 3, 1. / 3, 0}};
        ParameterBlock pb1 = getParameterBlockForImage(image);
        pb1.add(matrix1);
        return JAI.create("bandcombine", pb1, null);
    }

    public static PlanarImage invert(PlanarImage image) {
        return JAI.create("invert", getParameterBlockForImage(image), null);
    }

    public static PlanarImage binarize(PlanarImage image) {
        if (image.getNumBands() > 1) {
            image = grayscale(image);
        }
        return binarize(image, getBinarizationThreshold(image));
    }

    public static PlanarImage binarize(PlanarImage image, double threshold) {
        if (image.getNumBands() > 1) {
            image = grayscale(image);
        }
        ParameterBlock pb = getParameterBlockForImage(image);
        pb.add(threshold);
        return JAI.create("binarize", pb);
    }

    public static double getBinarizationThreshold(PlanarImage image) {
        Histogram histogram = (Histogram) JAI.create("histogram", image).getProperty("histogram");
        return histogram.getIterativeThreshold()[0];
    }

    public static PlanarImage crop(PlanarImage image, Rectangle2D rectangle) {
        return crop(image, (float) rectangle.getX(), (float) rectangle.getY(), (float) rectangle.getWidth(),
                (float) rectangle.getHeight());
    }

    public static PlanarImage crop(PlanarImage image, float x, float y, float width, float height) {
        ParameterBlock pb = getParameterBlockForImage(image);
        pb.add(x);
        pb.add(y);
        pb.add(width);
        pb.add(height);
        return JAI.create("crop", pb);
    }

    public static PlanarImage blur(PlanarImage image, int radius) {
        int klen = Math.max(radius, 2);
        int ksize = klen * klen;
        float f = 1f / ksize;
        float[] kern = new float[ksize];
        for (int i = 0; i < ksize; i++) {
            kern[i] = f;
        }
        KernelJAI blur = new KernelJAI(klen, klen, kern);
        ParameterBlockJAI param = new ParameterBlockJAI("Convolve");
        param.addSource(image);
        param.setParameter("kernel", blur);
// hint with border extender
        RenderingHints hint = new RenderingHints(JAI.KEY_BORDER_EXTENDER, BorderExtender.createInstance(BorderExtender.BORDER_COPY));
        return JAI.create("Convolve", param, hint);
    }

    public static PlanarImage adjustLight(PlanarImage image, int ipParam) { // ipParam = 18
        ParameterBlock pb = new ParameterBlock();
        pb.addSource(image);
        byte lookUpTableData[];
        lookUpTableData = new byte[256];
        for (int j = 0; j < 256; j++) {
            lookUpTableData[j] = clampByte(j + ipParam);
        }

        LookupTableJAI lookUp = new LookupTableJAI(lookUpTableData);
        pb.add(lookUp);

        image = JAI.create("lookup", pb, null);
        return image;
        //tellObservers();
    }
    
    public static RenderedOp createGraphics(PlanarImage image) {
        if(image.getColorModel().getPixelSize()>8){
            BufferedImage buff = image.getAsBufferedImage();
            BufferedImage outputImage=new BufferedImage(buff.getWidth(null), buff.getHeight(null), BufferedImage.TYPE_BYTE_INDEXED);
            outputImage.createGraphics().drawImage(buff, 0 , 0, null);
            
            ParameterBlock param = new ParameterBlock();
            param.addSource(outputImage);
            param.add(DataBuffer.TYPE_BYTE);
            RenderedOp finalImage = JAI.create("Format", param);
            return finalImage;
        }else{        
            ImageLayout tileLayout = new ImageLayout(image);
            tileLayout.setTileWidth(256);
            tileLayout.setTileHeight(256);
            HashMap map = new HashMap();
            map.put(JAI.KEY_IMAGE_LAYOUT, tileLayout);
            map.put(JAI.KEY_INTERPOLATION,
            Interpolation.getInstance(Interpolation.INTERP_BICUBIC));
            RenderingHints tileHints = new RenderingHints(map);
            ParameterBlock pb = new ParameterBlock();
            pb.addSource(image);
            return JAI.create("format", pb, tileHints);
        }
    }

    public static boolean isBlackWhile(File file) {
        boolean bw = true;
        try {
            Iterator readers = ImageIO.getImageReadersByFormatName("tiff");
            ImageReader reader = (ImageReader) readers.next();
            ImageInputStream iis = new FileImageInputStream(file);
            reader.setInput(iis, true, true);
            ImageReadParam param = reader.getDefaultReadParam();
            BufferedImage buff = reader.read(0, param);            
            bw = (buff.getRGB(0, 0) == -1);
            readers = null;
            iis.close();
            iis = null;
            reader.dispose();
            reader = null;
            param = null;
            buff = null;
            System.gc();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bw;
    }
    
    public static boolean isJPEG_in_TIFF(File file) throws IOException {
        boolean jpg_in_tiff = true;
        PlanarImage planarImg = null;
        ParameterBlock pb = null;
        SeekableStream s = null;
        try {            
            s = new FileSeekableStream(file);
            pb = new ParameterBlock();
            pb.add(s);
            pb.add(new TIFFDecodeParam());
            pb.add(0);                    
            planarImg = JAI.create("TIFF", pb);
            planarImg.getAsBufferedImage(new Rectangle(0,0,1,1), planarImg.getColorModel());//Get Buffer fail => JPEG in TIFF            
            jpg_in_tiff = false;
        } catch (Exception e) {
            
        } finally {
            if(planarImg!=null){
                planarImg.dispose();
                planarImg = null;
            }
            if(pb!=null){
                pb.removeSources();
                pb = null;   
            }
            if(s!=null){
                s.close();
                s = null;
            }
        }
        return jpg_in_tiff;
    }
    
    public static byte[] getByteFromBufferedImage(BufferedImage img, String extention) throws Exception{        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write( img, extention, baos );
        baos.flush();
        byte[] imageInByte = baos.toByteArray();
        baos.close();
        return imageInByte;
    }

    private final static byte clampByte(int i) {
        if (i > 255) {
            return -1;
        }
        if (i < 0) {
            return 0;
        } else {
            return (byte) i;
        }
    }
    private static Hashtable<String, String> listOfFile = new Hashtable<String, String>();

    public static String convertNoneTiff2Tiff(String fileName) {
        if (listOfFile.containsKey(fileName)) {
            return listOfFile.get(fileName);
        } else {
            String ext = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
            if (ext.equals("tiff") || ext.equals("tif") || ext.equals("jpg") || ext.equals("jpeg")) {
                return fileName;
            } else if (ext.equals("pdf")) {
                return fileName;
                /*try {
                    int dpi = 200;
                    //int color = TIFConvert.CLR_BLACK_WHITE;
                    //int compression = TIFConvert.COMPRESSION_CCITT_T_6;
                    int color = TIFConvert.CLR_GRAY_SCALE;
                    int compression = TIFConvert.COMPRESSION_LZW;
                    float quality = 1f;

                    File dir = new File(System.getProperty("java.io.tmpdir") + "/IDEAS");
                    if (dir.exists()) {
                        String[] filesList = dir.list();
                        for (String s : filesList) {
                            new java.io.File(dir, s).delete();
                        }
                    }
                    if (!dir.exists()) {
                        dir.mkdir();
                    }
                    File temp = File.createTempFile("Image_", ".tif", dir);
                    // Delete temp file when program exits.
                    temp.deleteOnExit();
                    String tif = temp.getPath();
                    TIFConvertPDF.convert(fileName, tif, dpi, color, compression, quality);
                    listOfFile.clear();
                    listOfFile.put(fileName, tif);
                    return tif;
                } catch (Exception ex) {
                    ex.printStackTrace();
                    return fileName;
                }*/
            } else {
                OutputStream stream = null;
                try {
                    ParameterBlockJAI loadPB = new ParameterBlockJAI("fileload");
                    loadPB.setParameter("filename", fileName);
                    PlanarImage sImg = JAI.create("fileload", loadPB);
                    Image img = sImg.getAsBufferedImage();
                    RenderedOp source = JAI.create("AWTImage", img);
                    //source = JAI.create("Invert", source, null);
                    BufferedImage image = source.getAsBufferedImage();
                    BufferedImage outputImage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_RGB);
                    outputImage.createGraphics().drawImage(image, 0, 0, null);
                    TIFFEncodeParam param = new TIFFEncodeParam();
                    //param.setCompression(TIFFEncodeParam.COMPRESSION_GROUP3_2D);                                                          
                    param.setCompression(TIFFEncodeParam.COMPRESSION_JPEG_TTN2);

                    File dir = new File(System.getProperty("java.io.tmpdir") + "/IDEAS");
                    if (dir.exists()) {
                        String[] filesList = dir.list();
                        for (String s : filesList) {
                            new java.io.File(dir, s).delete();
                        }
                    }
                    if (!dir.exists()) {
                        dir.mkdir();
                    }
                    File tiff = File.createTempFile("Image_", ".tif", dir);
                    stream = new FileOutputStream(tiff);
                    TIFFImageEncoder encoder = (TIFFImageEncoder) TIFFCodec.createImageEncoder("tiff", stream, param);
                    encoder.encode(outputImage);
                    listOfFile.clear();
                    listOfFile.put(fileName, tiff.getPath());
                    return tiff.getPath();
                } catch (Exception ex) {
                    return fileName;
                } finally {
                    try {
                        stream.close();
                    } catch (Exception ex) {
                    }
                }
            }
        }
    }
}
