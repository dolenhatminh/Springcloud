/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import dbaccess.Configuration;
import dbaccess.DBase;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import utilities.CommonUtilities;

public class DataManagement extends DBase {

    public DataManagement() {
        try {
            setDefaultUsernamePassword();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public Object readDataFromFiles(ProjectInfo project, List<File> listFile) throws Exception {
        try {
            if (listFile.isEmpty()) {
                return null;
            }
            if (project.getDataType() == ProjectInfo.DataType.TEXT) {
                return readTextFiles(project, listFile);
            } else {
                return readXMLFile(project, listFile.get(0));
            }
        } catch (Exception ex) {
            throw ex;
        }
    }

    public List<List<String>> getListFileXMLOnTable(ProjectInfo project, List<File> listFile) throws Exception {

        List<List<String>> listData = new ArrayList<List<String>>();
        try {
            if (Configuration.getProperties("projectNotIDEAS").toLowerCase().contains("," + project.getProjectName().toLowerCase() + ",")) {
                for (int i = 0; i < listFile.size(); i++) {
                    List<String> row = new ArrayList<String>();
                    row.add(String.valueOf(i));
                    row.add(String.valueOf(listFile.get(i).getName()));
                    row.add(String.valueOf(listFile.get(i).getPath()));
                    listData.add(row);
                }
                return listData;
            }

            String keyDB = getKeyColumnOnlyDatabase(project.getKeyColumn());

            StringBuilder sqlSelect = new StringBuilder();
            sqlSelect.append("SELECT DISTINCT export_file_name, export_folder FROM ");
            sqlSelect.append(project.getSchemaName()).append(".management JOIN ").append(project.getSchemaName());
            sqlSelect.append(".export_type_info ON management.id = export_type_info.management_id JOIN ").append(project.getSchemaName());
            sqlSelect.append(".export_info ON export_type_info.export_info_id = export_info.id WHERE export_folder || '/' || export_file_name IN (");
            for (File file : listFile) {
                sqlSelect.append("'").append(CommonUtilities.removePrefix(file.getPath().replace("\\", "/"))).append("',");
            }
            sqlSelect.deleteCharAt(sqlSelect.length() - 1);
            sqlSelect.append(") AND ").append(keyDB).append(" ORDER BY export_file_name");

            //Check database connection        
            Connection con;
            try {
                con = openConnection(project.getIpHost(), project.getDatabaseName(), project.getUserName(), project.getPassword());
            } catch (Exception ex) {
                throw ex;
            }
            //System.out.println(sqlSelect.toString());
            ResultSet rs = con.createStatement().executeQuery(sqlSelect.toString());
            while (rs.next()) {
                List<String> row = new ArrayList<String>();
                row.add(String.valueOf(rs.getRow()));
                row.add(String.valueOf(rs.getString(1)));
                row.add(CommonUtilities.addPrefix(String.valueOf(rs.getString(2)) + "/" + String.valueOf(rs.getString(1))));
                listData.add(row);
            }

            return listData;

        } catch (Exception ex) {
            throw ex;
        }
    }

    public List<List<String>> readTextFiles(ProjectInfo project, List<File> listFile) throws Exception {
        try {
            List<List<String>> listData = new ArrayList<List<String>>();
            
            //listData.add(new ArrayList<String>(Arrays.asList(project.getListFieldString().toUpperCase().split(";"))));
            listData.add(new ArrayList());
            listData.get(0).add("ID");
            for (FieldInfo field : project.getListField()) {
                listData.get(0).add(field.getFieldName().toUpperCase());
            }
            listData.get(0).add("FULL_FILE_NAME");
            String separator = CommonUtilities.getSeparatorWithSpecialCharacter(project.getSeparator());

            int totalRecord = 0;
            List<Range> rangeList = null;

            if (project.getQcPercent() < 100 || !project.getAQLList().equals("")) {
                for (File file : listFile) {
                    totalRecord += countLineTextFile(file.getPath());
                    if (project.isHeader()) {
                        totalRecord--;
                    }
                }
                if (project.getQcPercent() < 100) {
                    rangeList = getRangeFromPercent(totalRecord, project.getQcPercent(), Integer.valueOf(Configuration.getProperties("cropCount")));

                } else if (!project.getAQLList().equals("")) {
                    rangeList = getRangeFromAQL(totalRecord, project.getAQLList(), Integer.valueOf(Configuration.getProperties("cropCount")));
                }
                //for (Range range : rangeList) {
                //    System.out.println(range.from + " - " + range.to);
                //}
            }

            int lineIndex = -1;

            for (File file : listFile) {
                // Read xls file
                if(file.getAbsolutePath().endsWith(".xls")) {
                    FileInputStream fileInputStream = new FileInputStream(file);
                    Workbook workBook = new HSSFWorkbook(fileInputStream);
                    Sheet workSheet = workBook.getSheetAt(0);
                    Iterator<Row> rows = workSheet.iterator();
                    boolean skipHeader = false;
                    
                    while(rows.hasNext()) {
                        Row row = rows.next();
                        
                        if (project.isHeader() && !skipHeader) {
                            skipHeader = true;
                            continue;
                        }
                        lineIndex++;
                        if (project.getQcPercent() < 100 || !project.getAQLList().equals("")) {
                            if (!findRange(lineIndex, rangeList)) {
                                continue;
                            }
                        }
                        
                        List<String> data = new ArrayList<String>();
                        Iterator<Cell> cells = row.iterator();

                        while(cells.hasNext()) {
                            Cell cell = cells.next();
                            
                            switch(cell.getCellType()) {
                                case Cell.CELL_TYPE_STRING:
                                    data.add(cell.getStringCellValue());
                                    break;
                                case Cell.CELL_TYPE_NUMERIC:
                                    cell.setCellType(Cell.CELL_TYPE_STRING);
                                    data.add(cell.getStringCellValue());
                                    break;
                            }
                        }
                        
                        data.add(0, String.valueOf(listData.size()));
                        for (int i = data.size(); i < listData.get(0).size(); i++) {
                            data.add("");
                        }
                        listData.add(data);
                    }
                    
                    fileInputStream.close();
                } else {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "windows-1252"));;
                    String line = null;
                    boolean skipHeader = false;

                    while ((line = reader.readLine()) != null) {
                        if (project.isHeader() && !skipHeader) {
                            skipHeader = true;
                            continue;
                        }
                        lineIndex++;
                        if (line.trim().isEmpty()) {
                            continue;
                        }

                        if (project.getQcPercent() < 100 || !project.getAQLList().equals("")) {
                            if (!findRange(lineIndex, rangeList)) {
                                continue;
                            }
                        }

                        if (project.getSeparator().equalsIgnoreCase("[tab]")) {
                            List<String> data = new ArrayList<String>(Arrays.asList(line.split("\t", -2)));
                            data.add(0, String.valueOf(listData.size()));
                            for (int i = data.size(); i < listData.get(0).size(); i++) {
                                data.add("");
                            }
                            listData.add(data);
                        } else if (project.getSeparator().equalsIgnoreCase("[fix]")) {
                            List<String> data = new ArrayList<String>();
                            data.add(0, String.valueOf(listData.size()));
                            for (String header : listData.get(0)) {
                                if (header.equalsIgnoreCase("ID") || header.equalsIgnoreCase("FULL_FILE_NAME")) {
                                    continue;
                                }
                                int begin = Integer.valueOf(header.split(",")[2]) - 1;
                                int end = begin + Integer.valueOf(header.split(",")[1]);
                                if (begin >= line.length()) {
                                    data.add("");
                                    continue;
                                } else if (end >= line.length()) {
                                    end = line.length() - 1;
                                }
                                data.add(line.substring(begin, end).trim());
                            }
                            for (int i = data.size(); i < listData.get(0).size(); i++) {
                                data.add("");
                            }
                            listData.add(data);
                        } else {
                            List<String> data = new ArrayList<String>(Arrays.asList(line.split(separator, -2)));
                            data.add(0, String.valueOf(listData.size()));
                            for (int i = data.size(); i < listData.get(0).size(); i++) {
                                data.add("");
                            }
                            listData.add(data);
                        }
                    }
                    reader.close();
                }
            }

            //type [fix] with: col1,0,5;col2,5,10;... -> only get column name and replace
            if (project.getSeparator().equalsIgnoreCase("[fix]")) {
                for (int i = 1; i < listData.get(0).size() - 1; i++) {
                    listData.get(0).set(i, listData.get(0).get(i).split(",")[0]);
                }
            }
            getFullFileNameFromDataBaseByInsertTableTemp(listData, project);

            int posFullFileNameColumn = listData.get(0).indexOf("FULL_FILE_NAME");
            //remove records have no full_file_name
            for (int i = listData.size() - 1; i > 0; i--) {
                List<String> datas = listData.get(i);
                if (datas.get(posFullFileNameColumn).isEmpty()) {
                    listData.remove(i);
                }
            }

            return listData;
        } catch (Exception ex) {
            throw ex;
        }
    }

    public String getFullFileNameForRecord(List<String> listValue, ProjectInfo project) throws Exception {
        String imagePath = "";
        //Check key column
        List<String> keyColumnList = getKeyColumnListOnFile(project.getKeyColumn());
        if (keyColumnList.isEmpty()) {
            throw new Exception("Can't found key column to connect database!");
        }
        //Check database connection        
        Connection con;
        try {
            con = openConnection(project.getIpHost(), project.getDatabaseName(), project.getUserName(), project.getPassword());
        } catch (Exception ex) {
            throw ex;
        }

        try {
            String fullFileName = "", managementID = "";
            try {
                fullFileName = getColumnNameExactly(project.getSchemaName(), "management", new String[]{"full_file_name", "fullfilename1"}, con);
                managementID = getColumnNameExactly(project.getSchemaName(), "data", new String[]{"managementid", "management_id"}, con);
            } catch (Exception ex) {
                throw ex;
            }

            StringBuilder sqlSelect = new StringBuilder();
            sqlSelect.append("SELECT management.").append(fullFileName).append(" AS full_file_name FROM ");
            sqlSelect.append(project.getSchemaName()).append(".management , ").append(project.getSchemaName()).append(".data WHERE management.id = data.");
            sqlSelect.append(managementID).append(" and ( ");

            String keyColumnQuery = project.getKeyColumn().toLowerCase();

            for (int i = 0; i < keyColumnList.size(); i++) {
                keyColumnQuery = keyColumnQuery.replace("file.\"" + keyColumnList.get(i) + "\"", "'" + listValue.get(i) + "'");
            }

            sqlSelect.append(keyColumnQuery);
            sqlSelect.append(" ) LIMIT 1");
            //System.out.println(sqlSelect.toString());
            ResultSet rs = con.createStatement().executeQuery(sqlSelect.toString());
            while (rs.next()) {
                imagePath = CommonUtilities.addPrefix(rs.getString("full_file_name"));
            }
            rs.close();

        } catch (Exception ex) {
            throw ex;
        } finally {
            con.close();
            return imagePath;
        }
    }

    private void getFullFileNameFromDataBaseByInsertTableTemp(List<List<String>> listData, ProjectInfo project) throws Exception {
        //SimpleDateFormat df = new SimpleDateFormat("ddMMyyyy_hhmmss");
        String tableName = "tmp";//"TMP_" + df.format(Calendar.getInstance().getTime());
        //Check key column
        List<String> keyColumnList = getKeyColumnListOnFile(project.getKeyColumn());
        if (keyColumnList.isEmpty()) {
            throw new Exception("Can't found key column to connect database!");
        }
        //Check database connection        
        Connection con;
        try {
            con = openConnection(project.getIpHost(), project.getDatabaseName(), project.getUserName(), project.getPassword());
        } catch (Exception ex) {
            throw ex;
        }
        try {
            //Create table 
            StringBuilder sqlCreateTable = new StringBuilder("CREATE TEMPORARY TABLE ").append(tableName).append("( id serial NOT NULL, ");
            for (String keyColumn : keyColumnList) {
                sqlCreateTable.append("\"").append(keyColumn.toLowerCase()).append("\"").append(" character varying, ");
            }
            sqlCreateTable.append(" CONSTRAINT pk_").append(tableName).append(" PRIMARY KEY (id) ) with ( oids=false) ON COMMIT DROP; ");
            //Insert value to table
            StringBuilder sqlInsert = new StringBuilder().append("INSERT INTO ").append(tableName).append(" VALUES ");
            for (int i = 1; i < listData.size(); i++) {
                List<String> datas = listData.get(i);
                sqlInsert.append("(").append(i).append(",");
                for (String keyColumn : keyColumnList) {
                    try {
                        String data = datas.get(listData.get(0).indexOf(keyColumn.toUpperCase())).replace("'", "''").replace("\\", "\\\\");
                        sqlInsert.append("'").append(data).append("',");
                    } catch (Exception ex) {
                        freeConnection(Configuration.projectName);
                        throw new Exception("Can't found column \"" + keyColumn + "\"");
                    }
                }
                sqlInsert.deleteCharAt(sqlInsert.length() - 1);
                sqlInsert.append("),");
            }
            sqlInsert.deleteCharAt(sqlInsert.length() - 1).append(";");
            String fullFileName = "", managementID = "";
            try {
                fullFileName = getColumnNameExactly(project.getSchemaName(), "management", new String[]{"full_file_name", "fullfilename1"}, con);
                managementID = getColumnNameExactly(project.getSchemaName(), "data", new String[]{"managementid", "management_id"}, con);
            } catch (Exception ex) {
                throw ex;
            }
            StringBuilder sqlSelect = new StringBuilder();
            sqlSelect.append("SELECT management.").append(fullFileName).append(" AS full_file_name, file.id FROM ").append(tableName).append(" AS file, ");
            sqlSelect.append(project.getSchemaName()).append(".management , ").append(project.getSchemaName()).append(".data WHERE management.id = data.");
            sqlSelect.append(managementID).append(" and (").append(project.getKeyColumn().toLowerCase()).append(") ORDER BY file.id;");

            con.setAutoCommit(false);
            CallableStatement proc = con.prepareCall("{ ? = call " + Configuration.projectName + ".get_full_file_name_from_insert_key_data(?,?,?) }");
            proc.registerOutParameter(1, Types.OTHER);
            proc.setString(2, sqlCreateTable.toString());
            proc.setString(3, sqlInsert.toString());
            proc.setString(4, sqlSelect.toString());
            //System.out.println(sqlCreateTable.toString());
            //System.out.println(sqlInsert.toString().replace("'", "''"));
            //System.out.println(sqlSelect.toString());
            //long start = Calendar.getInstance().getTimeInMillis();
            proc.execute();
            //System.out.println((Calendar.getInstance().getTimeInMillis() - start));
            ResultSet rs = (ResultSet) proc.getObject(1);
            int posFullFileNameColumn = listData.get(0).indexOf("FULL_FILE_NAME");
            while (rs.next()) {
                listData.get(rs.getInt("id")).set(posFullFileNameColumn, CommonUtilities.addPrefix(rs.getString("full_file_name")));
            }
            con.commit();
            rs.close();
            proc.close();

        } catch (Exception ex) {
            throw ex;
        } finally {
            con.commit();
            con.close();
        }
    }

    private String getColumnNameExactly(String schemaName, String tableName, String[] columnNames, Connection con) throws Exception {
        StringBuilder sqlSelect = new StringBuilder();
        sqlSelect.append("SELECT column_name FROM information_schema.columns WHERE table_schema = '").append(schemaName.toLowerCase());
        sqlSelect.append("' and table_name= '").append(tableName).append("' and (");
        for (String columnName : columnNames) {
            sqlSelect.append("column_name ='").append(columnName.toLowerCase()).append("' or ");
        }
        sqlSelect.delete(sqlSelect.length() - 3, sqlSelect.length() - 1).append(") ");
        String columnName = "";
        try {
            ResultSet rs = con.createStatement().executeQuery(sqlSelect.toString());
            while (rs.next()) {
                columnName = rs.getString("column_name").toLowerCase();
            }
            rs.close();
            if (columnName.isEmpty()) {
                throw new Exception("Not found " + columnNames[0] + " column!");
            }
        } catch (Exception ex) {
            throw ex;
        }
        return columnName;
    }
    public List<List<String>> readXMLFileForExportKey(ProjectInfo project, File xmlFile) throws Exception {
        try {
            List<String> keyColumnList = getKeyColumnListOnFile(project.getKeyColumn());
            if (keyColumnList.isEmpty()) {
                throw new Exception("Can't found key column to connect database!");
            }
            SAXReader reader = new SAXReader();
            Document doc = reader.read(xmlFile);
            //Node root = build(doc.getRootElement(), keyColumnList);
            Element root = doc.getRootElement();
            Node rootNode = buildNode(root, null, keyColumnList);
            List<List<String>> listData = new ArrayList<List<String>>();
            List<String> header = new ArrayList<String>();            
            for (String key : keyColumnList) {
                header.add(key.toUpperCase());
            }            
            listData.add(header);
            Node recordParent = searchRecordParentNode(rootNode);

            List<Range> rangeList = null;
            if (project.getQcPercent() < 100 || !project.getAQLList().equals("")) {
                int recordCount = 0;
                for (Node recordNode : recordParent.getChild()) {
                    if (recordNode.getName().equalsIgnoreCase("Record")) {
                        recordCount++;
                    }
                }
                if (project.getQcPercent() < 100) {
                    rangeList = getRangeFromPercent(recordCount, project.getQcPercent(), Integer.valueOf(Configuration.getProperties("cropCount")));
                } else {
                    rangeList = getRangeFromAQL(recordCount, project.getAQLList(), Integer.valueOf(Configuration.getProperties("cropCount")));
                }                
            }
            int lineIndex = -1;

            if (recordParent != null) {
                for (Node recordNode : recordParent.getChild()) {
                    if (!recordNode.getName().equalsIgnoreCase("Record")) {
                        continue;
                    }
                    lineIndex++;

                    if (project.getQcPercent() < 100 || !project.getAQLList().equals("")) {
                        if (!findRange(lineIndex, rangeList)) {
                            recordNode.setVisible(false);
                            continue;
                        }
                    }

                    recordNode.setId(listData.size());
                    List<String> data = new ArrayList<String>();
                    for (int i = data.size(); i < header.size(); i++) {
                        data.add("");
                    }
                    data.set(0, String.valueOf(listData.size()));
                    for (Node keyNode : recordNode.getKeyNode()) {
                        data.set(header.indexOf(keyNode.getName().toUpperCase()), keyNode.getValue());
                    }
                    listData.add(data);

                }
            }
           return  listData;
        }catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        }
     
    }
    public Node readXMLFile(ProjectInfo project, File xmlFile) throws Exception {
        try {
            List<String> keyColumnList = getKeyColumnListOnFile(project.getKeyColumn());
            if (keyColumnList.isEmpty()) {
                throw new Exception("Can't found key column to connect database!");
            }
            SAXReader reader = new SAXReader();
            Document doc = reader.read(xmlFile);
            //Node root = build(doc.getRootElement(), keyColumnList);
            Element root = doc.getRootElement();
            Node rootNode = buildNode(root, null, keyColumnList);
            List<List<String>> listData = new ArrayList<List<String>>();
            List<String> header = new ArrayList<String>();
            header.add(0, "ID");
            for (String key : keyColumnList) {
                header.add(key.toUpperCase());
            }
            header.add("FULL_FILE_NAME");
            listData.add(header);

            Node recordParent = searchRecordParentNode(rootNode);

            List<Range> rangeList = null;
            if (project.getQcPercent() < 100 || !project.getAQLList().equals("")) {
                int recordCount = 0;
                for (Node recordNode : recordParent.getChild()) {
                    if (recordNode.getName().equalsIgnoreCase("Record")) {
                        recordCount++;
                    }
                }
                if (project.getQcPercent() < 100) {
                    rangeList = getRangeFromPercent(recordCount, project.getQcPercent(), Integer.valueOf(Configuration.getProperties("cropCount")));
                } else {
                    rangeList = getRangeFromAQL(recordCount, project.getAQLList(), Integer.valueOf(Configuration.getProperties("cropCount")));
                }

                //for (Range range : rangeList) {
                //    System.out.println(range.from + " - " + range.to);
                //}
            }
            int lineIndex = -1;

            if (recordParent != null) {
                for (Node recordNode : recordParent.getChild()) {
                    if (!recordNode.getName().equalsIgnoreCase("Record")) {
                        continue;
                    }
                    lineIndex++;

                    if (project.getQcPercent() < 100 || !project.getAQLList().equals("")) {
                        if (!findRange(lineIndex, rangeList)) {
                            recordNode.setVisible(false);
                            continue;
                        }
                    }

                    recordNode.setId(listData.size());
                    List<String> data = new ArrayList<String>();
                    for (int i = data.size(); i < header.size(); i++) {
                        data.add("");
                    }
                    data.set(0, String.valueOf(listData.size()));
                    for (Node keyNode : recordNode.getKeyNode()) {
                        data.set(header.indexOf(keyNode.getName().toUpperCase()), keyNode.getValue());
                    }
                    listData.add(data);

                }
                getFullFileNameFromDataBaseByInsertTableTemp(listData, project);

                for (Node recordNode : recordParent.getChild()) {                    
                    if (recordNode.getId() != 0) {
                        if (listData.get(recordNode.getId()).get(header.indexOf("FULL_FILE_NAME")).isEmpty()) {
                            recordNode.setVisible(false);
                        } else {
                            recordNode.setImagePath(listData.get(recordNode.getId()).get(header.indexOf("FULL_FILE_NAME")));
                        }
                    }
                }
            }
            return rootNode;
        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        }
    }

    public Node buildNode(Element e, Node parentNode, List<String> keyColumnList) throws Exception {
        Node result = new Node(e.getName(), e.getText());
        if (parentNode != null) {
            result.setParent(parentNode);
            result.setNodePath(parentNode.getNodePath() + "/" + result.getName());
            if (parentNode.getName().equalsIgnoreCase("Record")) {
                result.setRecordNode(parentNode);
                setKeyNode(result, keyColumnList);
            } else if (parentNode.getRecordNode() != null) {
                result.setRecordNode(parentNode.getRecordNode());
                setKeyNode(result, keyColumnList);
            }
            parentNode.getChild().add(result);
        }
        for (Object o : e.elements()) {
            buildNode((Element) o, result, keyColumnList);
        }
        return result;
    }

    public Node searchRecordParentNode(Node root) throws Exception {
        if (root.getName().equals("Record")) {
            return root.getParent();
        }
        for (Node child : root.getChild()) {
            Node search = searchRecordParentNode(child);
            if (search != null) {
                return search;
            }
        }
        return null;
    }

    public void setKeyNode(Node node, List<String> keyColumnList) throws Exception {
        for (String key : keyColumnList) {
            if (key.equalsIgnoreCase(node.getName())) {
                node.getRecordNode().getKeyNode().add(node);
                return;
            }
        }
    }

    public List<String> getKeyColumnListOnFile(String keyColumn) throws Exception {
        try {
            List<String> columnList = new ArrayList<String>();
            keyColumn = keyColumn.toLowerCase();
            while (keyColumn.contains("file.")) {
                keyColumn = keyColumn.substring(keyColumn.indexOf("file.") + 5);
                int start = keyColumn.indexOf("\"");
                int end = keyColumn.indexOf("\"", start + 1);
                if (start != -1 && end != -1) {
                    columnList.add(keyColumn.substring(start + 1, end));
                }
            }
            return columnList;
        } catch (Exception ex) {
            throw ex;
        }
    }

    public String getKeyColumnOnlyDatabase(String keyColumn) throws Exception {
        try {
            String keyDB = " 1 = 1 ";
            keyColumn = keyColumn.toLowerCase();
            for (String key : keyColumn.split("and")) {
                if (!key.trim().isEmpty()) {
                    if (!key.contains("file.")) {
                        keyDB += " and " + key;
                    }
                }
            }
            return keyDB;
        } catch (Exception ex) {
            throw ex;
        }
    }

    public List<String> getKeyColumnListOnDatabase(String keyColumn) throws Exception {
        try {
            List<String> columnList = new ArrayList<String>();
            List<String> columnListOnFile = getKeyColumnListOnFile(keyColumn);
            keyColumn = keyColumn.toLowerCase();
            for (String column : columnListOnFile) {
                keyColumn = keyColumn.substring(keyColumn.indexOf(column.toLowerCase()));
                int start = keyColumn.indexOf("=") + 1;
                int end = keyColumn.indexOf("and", start + 1);
                if (start != -1) {
                    if (end != -1) {
                        columnList.add(keyColumn.substring(start + 1, end));
                    } else {
                        columnList.add(keyColumn.substring(start + 1));
                    }
                }
            }

            return columnList;
        } catch (Exception ex) {
            throw ex;
        }
    }

    private int countLineTextFile(String textFile) throws Exception {
        int count = 0;
        try {
            LineNumberReader lnr = new LineNumberReader(new FileReader(new File(textFile)));
            lnr.skip(Long.MAX_VALUE);
            count = lnr.getLineNumber();
            lnr.close();
            return count;
        } catch (Exception ex) {
            throw ex;
        }
    }

    private List<Range> getRangeFromPercent(int total, int percentQC, int cropCount) throws Exception {
        float percent = (float) percentQC / 100;
        int recordCount = Math.round(total / cropCount * percent);
        //sample total = 900, percent 30%, cropcount 3 -> percentCrop = 30/3 = 10%
        List<Range> rangeList = new ArrayList<Range>();
        try {
            if (total <= cropCount) {
                Range range = new Range();
                range.from = 0;
                range.to = Math.round(total * percent) - 1;
                rangeList.add(range);
                return rangeList;
            }
            for (int i = 0; i < cropCount; i++) {
                Range range = new Range();
                range.from = Math.round((float) total / cropCount) * i;
                range.to = range.from + recordCount - 1;
                if (i == cropCount - 1) {
                    range.to = range.to + Math.round((total * percent)) - recordCount * cropCount;
                }
                rangeList.add(range);
            }
            return rangeList;
        } catch (Exception ex) {
            throw ex;
        }
    }

    private List<AQLRange> getAQLRange(String AQLList) throws Exception {
        try {
            List<AQLRange> rangeList = new ArrayList<AQLRange>();
            for (String item : AQLList.split(";")) {
                if (item.equals("")) {
                    continue;
                }
                AQLRange AQLItem = new AQLRange();
                String[] AQLSize = item.split(",");
                AQLItem.from = Integer.valueOf(AQLSize[0]);
                AQLItem.to = Integer.valueOf(AQLSize[1]);
                AQLItem.sampleSize = Integer.valueOf(AQLSize[2]);
                rangeList.add(AQLItem);
            }
            return rangeList;
        } catch (Exception ex) {
            throw ex;
        }
    }

    private int findSampleSize(List<AQLRange> AQLList, int total) throws Exception {
        try {
            int sampleSize = 0;
            for (AQLRange item : AQLList) {
                if (total >= item.from && total <= item.to) {
                    sampleSize = item.sampleSize;
                    break;
                }
            }
            return sampleSize;
        } catch (Exception ex) {
            throw ex;
        }
    }

    private List<Range> getRangeFromAQL(int total, String AQLList, int cropCount) throws Exception {
        try {
            int sampleSize = findSampleSize(getAQLRange(AQLList), total);
            float percent = (float) sampleSize / total;
            int recordCount = Math.round(total / cropCount * percent);
            //sample total = 900, percent 30%, cropcount 3 -> percentCrop = 30/3 = 10%
            List<Range> rangeList = new ArrayList<Range>();
            if (total <= cropCount) {
                Range range = new Range();
                range.from = 0;
                range.to = sampleSize - 1;
                rangeList.add(range);
                return rangeList;
            }
            for (int i = 0; i < cropCount; i++) {
                Range range = new Range();
                range.from = Math.round((float) total / cropCount) * i;
                range.to = range.from + recordCount - 1;
                if (i == cropCount - 1) {
                    range.to = range.to + sampleSize - recordCount * cropCount;
                }
                rangeList.add(range);
            }
            return rangeList;
        } catch (Exception ex) {
            throw ex;
        }
    }

    private boolean findRange(int number, List<Range> rangeList) throws Exception {
        for (Range range : rangeList) {
            if (number >= range.from && number <= range.to) {
                return true;
            }
        }
        return false;
    }

    public class Range {
        public int from = 0;
        public int to = 0;
    }

    public class AQLRange extends Range {

        public int sampleSize = 0;
    }
}
