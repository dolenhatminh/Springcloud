/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import utilities.CommonUtilities;

/**
 *
 * @author vtlong
 */
public class ProjectInfo {

    public enum DataType { TEXT, XML }

    private int id = 0;
    private String projectName = "";
    private DataType dataType = DataType.TEXT;
    private String ipHost = "";
    private String databaseName = "";
    private String schemaName = "";
    private String userName = "";
    private String password = "";
    private boolean header = false;
    private String separator = "";
    private String templatePath = "";
    private String listFieldString = "";
    private List<FieldInfo> listField;
    private String keyColumn = "";
    private int qcPercent = 0;
    private String AQLTemplate = "";
    private String AQLList = "";
    public final String SEPARATOR_FIELD_LEVEL1 = "#", SEPARATOR_FIELD_LEVEL2 = "|";
    public final int MAX_ORDER = 1000000;

    public ProjectInfo() {
        listField = new ArrayList();
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @return the dataType
     */
    public DataType getDataType() {
        return dataType;
    }

    /**
     * @param dataType the dataType to set
     */
    public void setDataType(DataType dataType) {
        this.dataType = dataType;
    }

    public void setDataType(int dataType) {
        if (dataType == 0) {
            this.dataType = DataType.TEXT;
        } else {
            this.dataType = DataType.XML;
        }
    }

    /**
     * @return the ipHost
     */
    public String getIpHost() {
        return ipHost;
    }

    /**
     * @param ipHost the ipHost to set
     */
    public void setIpHost(String ipHost) {
        this.ipHost = ipHost;
    }

    /**
     * @return the database
     */
    public String getDatabaseName() {
        return databaseName;
    }

    /**
     * @param databaseName
     */
    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    /**
     * @return the schema
     */
    public String getSchemaName() {
        return schemaName;
    }

    /**
     * @param schemaName
     */
    public void setSchemaName(String schemaName) {
        this.schemaName = schemaName;
    }

    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the header
     */
    public boolean isHeader() {
        return header;
    }

    /**
     * @param header the header to set
     */
    public void setHeader(boolean header) {
        this.header = header;
    }

    /**
     * @return the separator
     */
    public String getSeparator() {
        return separator;
    }

    /**
     * @param separator the separator to set
     */
    public void setSeparator(String separator) {
        this.separator = separator;
    }

    /**
     * @return the templatePath
     */
    public String getTemplatePath() {
        return templatePath;
    }

    /**
     * @param templatePath the templatePath to set
     */
    public void setTemplatePath(String templatePath) {
        this.templatePath = templatePath;
    }

    /**
     * @return the fieldList
     */
    public String getListFieldString() {
        return listFieldString;
    }

    public void setListFieldString(String listFieldStr) throws Exception {
        this.listFieldString = listFieldStr;
        if(listFieldStr.isEmpty()) {
            return;
        }
        if(!listFieldStr.contains(SEPARATOR_FIELD_LEVEL1)) {
            for (String fieldName : listFieldStr.split(";")) {
                listField.add(new FieldInfo(fieldName, "", MAX_ORDER));
            }
            return;
        }
        
        for (String fieldProperties : listFieldStr.split(CommonUtilities.getSeparatorWithSpecialCharacter(SEPARATOR_FIELD_LEVEL1))) {
            String[] fieldPropertiesArray = fieldProperties.split(CommonUtilities.getSeparatorWithSpecialCharacter(SEPARATOR_FIELD_LEVEL2), 3);
            String fieldName = fieldPropertiesArray[0];
            String separatorMulti = fieldPropertiesArray[1];
            String index = fieldPropertiesArray[2];            
            listField.add(new FieldInfo(fieldName, separatorMulti, index.isEmpty() ? MAX_ORDER : Double.valueOf(index).intValue()));
        }
    }

    /**
     * @return the keyColumn
     */
    public String getKeyColumn() {
        return keyColumn;
    }

    /**
     * @param keyColumn the keyColumn to set
     */
    public void setKeyColumn(String keyColumn) {
        this.keyColumn = keyColumn;
    }

    /**
     * @return the qcPercent
     */
    public int getQcPercent() {
        return qcPercent;
    }

    /**
     * @param qcPercent the qcPercent to set
     */
    public void setQcPercent(int qcPercent) {
        this.qcPercent = qcPercent;
    }

    /**
     * @return the AQLTemplate
     */
    public String getAQLTemplate() {
        return AQLTemplate;
    }

    /**
     * @param AQLTemplate the AQLTemplate to set
     */
    public void setAQLTemplate(String AQLTemplate) {
        this.AQLTemplate = AQLTemplate;
    }

    /**
     * @return the AQLList
     */
    public String getAQLList() {
        return AQLList;
    }

    /**
     * @param AQLList the AQLList to set
     */
    public void setAQLList(String AQLList) {
        this.AQLList = AQLList;
    }

    @Override
    public String toString() {
        return projectName;
    }
    
    /**
     * @return the listField
     */
    public List<FieldInfo> getListField() {
        return listField;
    }
    
    /**
     * @return the listField
     */
    public List<FieldInfo> getListFieldSort() {
        List<FieldInfo> listFieldSoft = new ArrayList<FieldInfo>(listField);
        Collections.sort(listFieldSoft, new Comparator<FieldInfo>() {
            @Override
            public int compare(FieldInfo o1, FieldInfo o2) {
                return o1.getIndex() == o2.getIndex() ? 0 : o1.getIndex() > o2.getIndex() ? 1 : -1;
            }
        });
        return listFieldSoft;
    }

    /**
     * @param listField the listField to set
     */
    public void setListField(List<FieldInfo> listField) {
        this.listField = listField;
    }

}
