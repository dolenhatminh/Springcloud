/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author vtlong
 */
public class ObserverManager extends Observable{
    
    public void notifyObserver() {
        setChanged();
        notifyObservers();
    }
    
    public void notifyObserver(Object obs) {
        setChanged();
        notifyObservers(obs);
    }
    
}
