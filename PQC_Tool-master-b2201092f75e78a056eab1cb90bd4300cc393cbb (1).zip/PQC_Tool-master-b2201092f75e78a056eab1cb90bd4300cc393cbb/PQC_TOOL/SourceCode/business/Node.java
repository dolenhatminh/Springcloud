/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Administrator
 */
public class Node {
    private int id = 0;
    private String name = "";
    private String value = "";
    private String imagePath = "";
    private String nodePath = "";
    private Node parent;
    private Node recordNode;
    private List<Node> child;
    private List<Node> keyNode;
    private boolean visible = true;
    
    Node() {
        child = new ArrayList<Node>();
        keyNode = new ArrayList<Node>();
    }
    
    Node(String name, String value) {
        this.name = name;
        this.value = value;
        this.nodePath = name;
        child = new ArrayList<Node>();
        keyNode = new ArrayList<Node>();
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * @return the imagePath
     */
    public String getImagePath() {
        return imagePath;
    }

    /**
     * @param imagePath the imagePath to set
     */
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    /**
     * @return the child
     */
    public List<Node> getChild() {
        return child;
    }

    /**
     * @param child the child to set
     */
    public void setChild(List<Node> child) {
        this.setChild(child);
    }

    /**
     * @return the nodePath
     */
    public String getNodePath() {
        return nodePath;
    }

    /**
     * @param nodePath the nodePath to set
     */
    public void setNodePath(String nodePath) {
        this.nodePath = nodePath;
    }

    /**
     * @return the parent
     */
    public Node getParent() {
        return parent;
    }

    /**
     * @param parent the parent to set
     */
    public void setParent(Node parent) {
        this.parent = parent;
    }

    /**
     * @return the recordNode
     */
    public Node getRecordNode() {
        return recordNode;
    }

    /**
     * @param recordNode the recordNode to set
     */
    public void setRecordNode(Node recordNode) {
        this.recordNode = recordNode;
    }

    /**
     * @return the keyNode
     */
    public List<Node> getKeyNode() {
        return keyNode;
    }

    /**
     * @param keyNode the keyNode to set
     */
    public void setKeyNode(List<Node> keyNode) {
        this.keyNode = keyNode;
    }
    
    @Override
    public String toString() {
        String str = name;
        if(!value.trim().isEmpty()) {
            str += "  { " + value.trim() + " }";
        }
        if(id!= 0) {
            str += " (" + id + ")";
        }
        if(getChild().size() > 0) {
            str += " [" + getChild().size() + "]";
        }
        return str;
    }

    /**
     * @return the visible
     */
    public boolean isVisible() {
        return visible;
    }

    /**
     * @param visible the visible to set
     */
    public void setVisible(boolean visible) {
        this.visible = visible;
    }
    
}
