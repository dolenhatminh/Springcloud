/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lkduy
 */
public class ProjectSelectFileCache {
    File fileCache = null;
    
    
    public ProjectSelectFileCache(){
        fileCache = new File("SourceCode\\caches\\DirectoryCache.txt");  
        if(!fileCache.exists()){
            fileCache.getParentFile().mkdir();
            try {               
                fileCache.createNewFile();
            } catch (IOException ex) {
                Logger.getLogger(ProjectSelectFileCache.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public String getCache(String buttonName, String projectName){      
        String retVal="";
        String line="";
        String pattern = "("+buttonName+"\\|x\\|"+projectName+"\\|x\\|)(.+)";
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileCache));
            while ((line = br.readLine()) != null){
                if(line.matches(pattern)){
                    retVal = line.replaceAll(pattern, "$2");
                    break;
                }
            }
            br.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ProjectSelectFileCache.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ProjectSelectFileCache.class.getName()).log(Level.SEVERE, null, ex);
        }       
        return retVal;
    }
    
    public void addCache(String buttonName, String projectName, String dir){     
        String line="";
        String pattern = "("+buttonName+"\\|x\\|"+projectName+"\\|x\\|)(.+)";
        String fileContent="";
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileCache));
           
            while ((line = br.readLine()) != null){            
                if(line.matches(pattern)){
                    line = "";
                }
                else
                    fileContent += line+"\r\n";
            }
            fileContent += buttonName+"|x|"+projectName+"|x|"+dir+"\r\n";
            br.close();
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileCache));
            bw.write(fileContent);
            bw.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ProjectSelectFileCache.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ProjectSelectFileCache.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }
}
