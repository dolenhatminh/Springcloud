/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import dbaccess.Configuration;
import dbaccess.DBase;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import utilities.EncryptDecryptUtils;

/**
 *
 * @author vtlong
 */
public class ProjectManagement extends DBase {
    
    public ProjectManagement() {
        try {
            setDefaultUsernamePassword();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public List<ProjectInfo> getAllProjects() throws Exception {
        try {
            List<ProjectInfo> projects = new ArrayList<ProjectInfo>();
            openConnection(Configuration.projectName, false);
            Object[] params = new Object[0];
            ResultSet result = (ResultSet) processStore(Configuration.projectName, "get_all_projects", params, Types.OTHER);
            commit(Configuration.projectName);
            while (result.next()) {
                ProjectInfo project = new ProjectInfo();
                project.setId(result.getInt("id"));
                project.setProjectName(result.getString("project_name"));
                project.setDataType(result.getInt("data_type"));
                project.setIpHost(result.getString("ip_host"));
                project.setDatabaseName(result.getString("database_name"));
                project.setSchemaName(result.getString("schema_name"));
                project.setUserName(result.getString("user_name"));
                project.setPassword(EncryptDecryptUtils.decrypt(result.getString("password")));
                project.setHeader(result.getBoolean("is_header"));
                project.setSeparator(result.getString("separator"));
                project.setTemplatePath(result.getString("template_path"));
                project.setListFieldString(result.getString("field_list"));
                project.setKeyColumn(result.getString("key_column"));
                project.setQcPercent(result.getInt("qc_percent"));
                project.setAQLTemplate(result.getString("aql_template"));
                project.setAQLList(result.getString("aql_list"));
                projects.add(project);
            }
            return projects;
        } catch (Exception ex) {
            rollback(Configuration.projectName);
            throw ex;
        } finally {
            freeConnection(Configuration.projectName);
        }
    }

    public boolean saveAllProjects(List<ProjectInfo> updateProjects, List<ProjectInfo> deleteProjects) throws Exception {
        try {
            for(ProjectInfo project : updateProjects) {
                if(project.getId() == 0) {
                    addProjectInfo(project);
                } else {
                    updateProjectInfo(project);
                }
            }
            deleteProjectInfo(deleteProjects);
            return true;
        } catch (Exception ex) {
            throw ex;
        }
    }

    public boolean addProjectInfo(ProjectInfo project) throws Exception {
        try {
            openConnection(Configuration.projectName, false);
            Object[] params = new Object[15];
            params[0] = project.getProjectName();
            params[1] = (project.getDataType() == ProjectInfo.DataType.TEXT) ? 0: 1;
            params[2] = project.getIpHost();
            params[3] = project.getDatabaseName();
            params[4] = project.getSchemaName();
            params[5] = project.getUserName();
            params[6] = EncryptDecryptUtils.encrypt(project.getPassword());
            params[7] = project.isHeader();
            params[8] = project.getSeparator();
            params[9] = project.getTemplatePath();
            params[10] = project.getListFieldString();
            params[11] = project.getKeyColumn();
            params[12] = project.getQcPercent();
            params[13] = project.getAQLTemplate();
            params[14] = project.getAQLList();
            int retVal = (Integer) processStore(Configuration.projectName, "add_project", params, Types.INTEGER);
            commit(Configuration.projectName);
            return retVal > 0;
        } catch (Exception ex) {
            rollback(Configuration.projectName);
            throw ex;
        } finally {
            freeConnection(Configuration.projectName);
        }
    }

    public boolean updateProjectInfo(ProjectInfo project) throws Exception {
        try {
            openConnection(Configuration.projectName, false);
            Object[] params = new Object[16];
            params[0] = project.getProjectName();
            params[1] = (project.getDataType() == ProjectInfo.DataType.TEXT) ? 0: 1;
            params[2] = project.getIpHost();
            params[3] = project.getDatabaseName();
            params[4] = project.getSchemaName();
            params[5] = project.getUserName();
            params[6] = EncryptDecryptUtils.encrypt(project.getPassword());
            params[7] = project.isHeader();
            params[8] = project.getSeparator();
            params[9] = project.getTemplatePath();
            params[10] = project.getListFieldString();
            params[11] = project.getKeyColumn();
            params[12] = project.getQcPercent();
            params[13] = project.getAQLTemplate();
            params[14] = project.getAQLList();
            params[15] = project.getId();
            int retVal = (Integer) processStore(Configuration.projectName, "update_project", params, Types.INTEGER);
            commit(Configuration.projectName);
            return retVal > 0;
        } catch (Exception ex) {
            rollback(Configuration.projectName);
            throw ex;
        } finally {
            freeConnection(Configuration.projectName);
        }
    }

    public boolean deleteProjectInfo(List<ProjectInfo> projects) throws Exception {
        try {
            if(projects.isEmpty()) {
                return false;
            }
            openConnection(Configuration.projectName, false);
            String listID = "";
            for(ProjectInfo project : projects) {
                listID += project.getId() + ",";
            }
            listID = listID.substring(0, listID.length() - 1);
            Object[] params = new Object[1];
            params[0] = listID;
            int retVal = (Integer) processStore(Configuration.projectName, "delete_projects", params, Types.INTEGER);
            commit(Configuration.projectName);
            return retVal > 0;
        } catch (Exception ex) {
            rollback(Configuration.projectName);
            throw ex;
        } finally {
            freeConnection(Configuration.projectName);
        }
    }
}
