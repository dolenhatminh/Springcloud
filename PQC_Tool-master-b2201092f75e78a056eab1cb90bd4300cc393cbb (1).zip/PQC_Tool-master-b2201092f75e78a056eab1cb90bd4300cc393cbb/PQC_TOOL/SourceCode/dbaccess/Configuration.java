/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dbaccess;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

/**
 *
 * @author vtlong
 */
public class Configuration {

    private static Properties prop = null;
    public static final String projectName = "pqc_tool";
    
    static {
        try {
            prop = new Properties();
            InputStream is = new FileInputStream(System.getProperty("user.dir") + "/properties/config.properties");
            prop.load(is);
            is.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getProperties(String key) {
        return prop.getProperty(key);
    }
}
