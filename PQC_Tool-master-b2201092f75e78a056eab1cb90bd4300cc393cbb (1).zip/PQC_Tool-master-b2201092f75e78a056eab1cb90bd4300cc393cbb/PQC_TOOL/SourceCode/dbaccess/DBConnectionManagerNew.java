package dbaccess;


import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.util.Hashtable;


public class DBConnectionManagerNew {
    static private DBConnectionManagerNew m_inst;
    private Driver driver;
    private DBConnectionPool connPool;
    @SuppressWarnings("unchecked")
	private Hashtable Hash_DBCode_Pool = new Hashtable();

    static synchronized public DBConnectionManagerNew instance(String strDBName,
    		String strUsername, String strPassword, String ipAddress) throws Exception{
        try{
            if (m_inst == null) { // a bit careful here
                synchronized (DBConnectionManagerNew.class) {
                    if (m_inst == null) {
                        m_inst = new DBConnectionManagerNew(strDBName, strUsername, strPassword, ipAddress);
                    }
                }
            }
        }
        catch(Exception ex){
            throw ex;
        }
        return m_inst;
    }

//    public static boolean testConnection(String strIpAddress, String dbName,
//    		String strUsername, String strPassword) throws Exception{
//        boolean retVal = false;
//        try{
//            String sdriver = "org.postgresql.Driver";
//            String url = "jdbc:postgresql://" + strIpAddress + "/" + dbName; //;+ Configuration.getInstance().getDBName();
//            String username = strUsername;
//            String password = strPassword;
//            int iMax = 10;
//            DBConnectionPool dbPool = new DBConnectionPool(sdriver, url, username, password, iMax);
//            Connection conn = dbPool.getConn();
//            if(conn != null) retVal = true;
//        }
//        catch(Exception ex){
//            throw ex;
//        }
//        return retVal;
//    }

    public static Connection getConnection(String strIpAddress, String dbName,
    		String strUsername, String strPassword) throws Exception{
        Connection retVal = null;
        try{
            String sdriver = "";
            String url = "";
            
            sdriver = "org.postgresql.Driver";
            url = "jdbc:postgresql://" + strIpAddress + "/" + dbName;                    
                    
            String username = strUsername;
            String password = strPassword;
            int iMax = 10;
            DBConnectionPool dbPool = new DBConnectionPool(sdriver, url, username, password, iMax);
            retVal = dbPool.getConn();
        }
        catch(Exception ex){
            throw ex;
        }
        return retVal;
    }

    private DBConnectionManagerNew(String strDBName, String strUsername, 
    		String strPassword, String ipAddress) throws Exception{
        try{
            initEx(strDBName, strUsername, strPassword, ipAddress);
        }
        catch(Exception iex){
            throw iex;
        }
    }

    private void initEx(String strDBName, String strUsername, 
    		String strPassword, String ipAddress) throws Exception{
        try{
            createPoolsEx(strDBName, strUsername, strPassword, ipAddress);
        }
        catch(Exception iex){
            throw iex;
        }
    }

    /**
     * <summary> * Returns an open connection. If no one is available, and the
     * max number of connections has not been reached, a new connection will be
     * created. </summary> <returns>Connection</returns>
     */
    public Connection getConn() throws Exception {
        try {
            return connPool.getConn();
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * <summary> Returns an open connection. If no one is available, and the max
     * number of connections has not been reached, a new connection will be
     * created. If the max number has been reached, waits until one is available
     * or the specified time has elapsed </summary> <param name="ltime">long:
     * number of milliseconds to wait </param> <returns>Connection</returns>
     */
    public Connection getConn(long ltime) throws Exception {
        try {
            return connPool.getConn(ltime);
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * <summary> Return a connection to the pool </summary> <param
     * name="conn">Connection: Connection that will be returned to the pool</param>
     * <returns>void</returns>
     */
    public void freeConn(Connection conn) throws Exception {
        connPool.freeConn(conn);
    }

    /**
     * <summary> Close all open connections and de-registers all drivers
     * </summary> <returns>void</returns>
     */
    public synchronized void release() throws Exception {
        // pool
        try {
            connPool.release();
        } catch (Exception e) {
            throw e;
        }

        // driver
        try {
            DriverManager.deregisterDriver(driver);
        } catch (Exception e) {
            throw e;
        }
    }

    // Additional Pool Here
    @SuppressWarnings("unchecked")
    private int createPoolsEx(String strDBName, String strUsername, 
    		String strPassword, String ipAddress) throws Exception{
        try{
            String sdriver = "";
            String url = "";
            sdriver = "org.postgresql.Driver";                    
            url = "jdbc:postgresql://" + ipAddress + "/" + strDBName;
            String username = strUsername;
            String password = strPassword;
            int iMax = 10;            
            Hash_DBCode_Pool.put(ipAddress+strDBName, new DBConnectionPool(sdriver, url,
                            username, password, iMax));
        }
        catch(Exception ex){
           throw ex;
        }
        return 0;
    }

    private DBConnectionPool getPool(String strDBName, String strUsername, 
    		String strPassword, String ipAddress) throws Exception{
        try{
            DBConnectionPool pool = (DBConnectionPool) Hash_DBCode_Pool.get(ipAddress+strDBName);
            if (pool == null) {
                createPoolsEx(strDBName, strUsername, strPassword, ipAddress);
                return getPool(strDBName, strUsername, strPassword, ipAddress);
            } else {
                return pool;
            }
        }
        catch(Exception ex){
            throw ex;
        }
    }

    /**
     * <summary> * Returns an open connection from the pool of the associated
     * database. If no one is available, and the max number of connections has
     * not been reached, a new connection will be created. </summary>
     * <returns>Connection</returns>
     */
    public Connection getConn(String strDBName, String strUsername, String strPassword, String ipAddress) throws Exception {
        try {
            DBConnectionPool pool = getPool(strDBName, strUsername, strPassword, ipAddress);
            if (pool != null) {
                    return pool.getConn();
            }
        } catch (Exception e) {
            throw e;
        }
        return null;
    }

    /**
     * <summary> Return a connection to the pool associated with the dbcode
     * </summary> <param name="dbcpde">Database code: The code prepresent for
     * the database</param> <param name="conn">Connection: Connection that will
     * be returned to the pool</param> <returns>void</returns>
     */
    public void freeConn(String strDBName, String strUsername,
    		String strPassword, Connection conn, String ipAddress) throws Exception {
        try{
            DBConnectionPool pool = getPool(strDBName, strUsername, strPassword, ipAddress);
            if (pool != null) {
                pool.freeConn(conn);
            }
        }
        catch(Exception e){
            throw e;
        }
    }

    /**
     * <summary> Close all open connections and de-registers all drivers
     * associated with the database mentioned through the dbcode </summary>
     * <returns>void</returns>
     */
    public synchronized void release(String strDBName, String strUsername,
    		String strPassword, Connection conn, String ipAddress) throws Exception {
        // pool
        try {
            DBConnectionPool pool = getPool(strDBName, strUsername, strPassword, ipAddress);
            if (pool != null) {
                pool.release();
            }
        } catch (Exception e) {
            throw e;
        }
    }
}
