package dbaccess;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;
import java.util.logging.Logger;

public class DBConnectionPool {

    private String m_sdriver;
    private String m_sURL;
    private String m_suser;
    private String m_spassword;
    private int m_imaxConn;

    private int m_icheckedOut = 0;
    @SuppressWarnings("unchecked")
	private Vector m_vtfreeConnections = new Vector();

    /**
     *
     */

    public DBConnectionPool(String sdriver, String sURL, String suser,
                    String spassword, int imaxConn) {
        this.m_sdriver = sdriver;
        this.m_sURL = sURL;
        this.m_suser = suser;
        this.m_spassword = spassword;
        this.m_imaxConn = imaxConn;
        loadDriver();
    }

    /**
     * <summary> Check out a connection from the pool. -If there is no available
     * connection, a new connection will be created if number of connections
     * hasn't been reached max connections allowed </summary>
     * <returns>Connection</returns>
     *
     * @throws Exception
     */
    public synchronized Connection getConn() throws Exception {
        Connection conn = null;
            //begin : connection for ideas_main
            try{
                conn = newConn();

            }catch(Exception ex){
                throw ex;
            }
            //end : connection for ideas_main
        

        return conn;
    }

    /**
     * <summary> Check out a connection from the pool. -If there is no available
     * connection, a new connection will be created if number of connections
     * hasn't been reached max connections allowed -If there is no available
     * connection and number of connections has been reached max connections
     * allowed, the method will wait for one to be checked in </summary> <param
     * name="ltimeout">long: The timeout value in milliseconds </param>
     * <returns>Connection</returns>
     */
    public synchronized Connection getConn(long ltimeout) throws Exception {
        try {
            long lstartTime = new Date().getTime();
            Connection conn;
            while ((conn = getConn()) == null) {
                try {
                    wait(ltimeout);
                } catch (InterruptedException e) {
                }
                if ((new Date().getTime() - lstartTime) >= ltimeout) {
                    // Timeout has expired
                    return null;
                }
            }
            return conn;
        } catch (Exception e) {
            throw e;
        }

    }

    @SuppressWarnings("unchecked")
	private boolean loadDriver() {
            try {
                Class cls = Class.forName(m_sdriver);
                Driver driver = (Driver) cls.newInstance();
                DriverManager.registerDriver(driver);
                return true;
            } catch (Exception e) {
                return false;
            }
    }

    private Connection newConn() throws Exception {
            Connection conn = null;
            try {
//                conn = DriverManager.getConnection(m_sURL, m_suser, m_spassword);
                checkTimeout cT = new checkTimeout();
                cT.start();
                while(!cT.isFinished){
                    Thread.sleep(10);
                }
                conn = cT.getConnection();
                cT.interrupt();
                cT.stop();
                cT=null;
                System.gc();
            } catch (Exception e) {
                throw e;
            }
            return conn;
    }

    /**
     * @author ttduy
     */
    class createConnectionWithTimeout extends Thread implements Runnable{
        Connection conn = null;
        public void run(){
            try{
                conn = DriverManager.getConnection(m_sURL, m_suser, m_spassword);
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }
        public Connection getConnection(){
            return conn;
        }
    }

    /**
     * @author ttduy
     */
    class checkTimeout extends Thread implements Runnable{
        long startTime = 0;
        long endTime = 0;
        Connection conn = null;
        boolean isFinished = false;
        public void run(){
            try{
                createConnectionWithTimeout c = new createConnectionWithTimeout();
                c.start();
                startTime = System.currentTimeMillis();
                while((System.currentTimeMillis()-startTime<=10000) && c.conn==null){//10 seconds
                    sleep(10);
                }
                conn = c.getConnection();
                isFinished = true;
                c.interrupt();
                c.stop();
                c=null;
            }
            catch(Exception ex){
                ex.printStackTrace();
            }
        }
        public boolean isFinished(){
            return isFinished;
        }
        public Connection getConnection(){
            return conn;
        }
    }

    /**
     * <summary> Checks in a connection to the pool. Notify other Threads that
     * are waiting for a connection. </summary> <param name="conn">Connection:
     * The connection that will be checked into the pool </param> <returns>void</returns>
     */
    @SuppressWarnings("unchecked")
    public synchronized void freeConn(Connection conn) throws Exception{
        try{
                if(conn!=null){
                    conn.close();
                }
            
        }
        catch(Exception ex){
             throw ex;
        }
    }

    /**
     * <summary> Closes all available connections </summary> <returns>void</returns>
     */
    @SuppressWarnings("unchecked")
	public synchronized void release() throws Exception {
        Enumeration allConns = m_vtfreeConnections.elements();
        while (allConns.hasMoreElements()) {
            Connection conn = (Connection) allConns.nextElement();
            try {
                // Close connection
                conn.close();
            } catch (SQLException e) {
                throw e;
            }
        }
        m_vtfreeConnections.removeAllElements();
    }
}
