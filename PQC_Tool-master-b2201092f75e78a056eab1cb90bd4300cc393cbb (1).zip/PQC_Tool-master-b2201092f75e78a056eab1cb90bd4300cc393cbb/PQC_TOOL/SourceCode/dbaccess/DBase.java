/*
 * Created on November 05, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package dbaccess;

import com.sun.rowset.CachedRowSetImpl;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import javax.swing.Timer;
import utilities.EncryptDecryptUtils;

/**
 * @author ttduy
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
public abstract class DBase {

    private Connection connProduction = null;
    private Connection connSchema = null;
    private String postgresUsername = "";
    private String postgresPassword = "";
    private String schemaUsername = "";
    private String schemaPassword = "";
    private final int FETCH_SIZE=5000;
    boolean isConnected = false;
    long startTime = 0;
    long endTime = 0;
    Timer t = null;

    public String getPostgresUsername() {
        return postgresUsername;
    }

    public void setPostgresUsername(String postgresUsername) {
        this.postgresUsername = postgresUsername;
    }

    public String getPostgresPassword() {
        return postgresPassword;
    }

    public void setPostgresPassword(String postgresPassword) {
        this.postgresPassword = postgresPassword;
    }

    public String getSchemaUsername() {
        return schemaUsername;
    }

    public void setSchemaUsername(String schemaUsername) {
        this.schemaUsername = schemaUsername;
    }

    protected void setDefaultUsernamePassword() throws Exception {
        try {
            String username = Configuration.getProperties("dbUser");
            String password = EncryptDecryptUtils.decrypt(Configuration.getProperties("dbPass"));
            schemaUsername = username;
            schemaPassword = password;
        } catch (Exception ex) {
            throw ex;
        }
    }

    public void setUsernamePasswordPostgres(String userName, String password) {
        postgresUsername = userName;
        postgresPassword = password;
    }

    public void setUsernamePasswordSchema(String userName, String password) {

        schemaUsername = userName;
        try{
            schemaPassword = EncryptDecryptUtils.decrypt(password);
        }catch(Exception ex){
            //ex.printStackTrace();
        }
    }

    public String getSchemaPassword() {
        return schemaPassword;
    }

    public void setSchemaPassword(String schemaPassword) {
        //this.schemaPassword = schemaPassword;
        try{
            this.schemaPassword = EncryptDecryptUtils.decrypt(schemaPassword);
        }catch(Exception ex){
            //ex.printStackTrace();
        }
    }
    private boolean isAutoCommit = false;

    public boolean testConnection(String ipAddress, String dbName, String userName, String passWord, boolean isCheckReachable) throws Exception {
        boolean retVal = false;
        try {
            if(isCheckReachable){
                retVal = isReachable(ipAddress);
            }
            if(retVal){
                Connection conn = DBConnectionManager.getConnection(ipAddress, dbName, userName, passWord);
                if(conn !=null){
                    retVal = true;
                }
                else{
                    retVal = false;
                }
            }
        } catch (Exception iex) {
            throw iex;
        }
        return retVal;
    }

    public boolean isReachable(String ipAddress) throws Exception {
        boolean retVal = false;
        try {
            try {
                int timeOut = 3000; // I recommend 3 seconds at least
                retVal = InetAddress.getByName(ipAddress).isReachable(timeOut);
            } catch (UnknownHostException e) {
                e.printStackTrace();
                retVal = false;
            } catch (IOException e) {
                e.printStackTrace();
                retVal = false;
            }
        } catch (Exception iex) {
            throw iex;
        }
        return retVal;
    }
    /**
     * free connection
     *
     * @throws Exception
     */
    public void freeConnection(String strDBname) throws Exception {
        try {
            if (strDBname.equalsIgnoreCase("production")) {
                DBConnectionManager dbcManager =
                        DBConnectionManager.instance(strDBname, postgresUsername, postgresPassword);
                dbcManager.freeConn(strDBname, postgresUsername, postgresPassword, connProduction);
            } else {
                DBConnectionManager dbcManager =
                        DBConnectionManager.instance(strDBname, schemaUsername, schemaPassword);
                dbcManager.freeConn(strDBname, schemaUsername, schemaPassword, connSchema);
            }
        } catch (Exception iex) {
            throw iex;
        }
    }


    /**
     * free connection
     *
     * @throws Exception
     */
    public void closeConnection(String strDBname) throws Exception {
        try {
            try {
                freeConnection(strDBname);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (strDBname.equalsIgnoreCase("production")) {
                DBConnectionManager dbcManager =
                        DBConnectionManager.instance(strDBname, postgresUsername, postgresPassword);
                dbcManager.release(strDBname, postgresUsername, postgresPassword, connProduction);
            } else {
                DBConnectionManager dbcManager =
                        DBConnectionManager.instance(strDBname, schemaUsername, schemaPassword);
                dbcManager.release(strDBname, schemaUsername, schemaPassword, connSchema);
            }
        } catch (Exception iex) {
            throw iex;
        }
    }

    /**
     * commit transaction
     *
     * @throws SQLException
     */
    public void commit(String strDBname) throws Exception {
        try {
            if (strDBname.equalsIgnoreCase("production")) {
                if(connProduction!=null && !connProduction.isClosed()){
                    connProduction.commit();
                }
            } else {
                if(connSchema!=null && !connSchema.isClosed()){
                    connSchema.commit();
                }
            }
        } catch (SQLException ex) {
           throw ex;
        }
    }

    /**
     * rollback transaction
     *
     * @throws SQLException
     */
    public void rollback(String strDBname) throws Exception {
        try {
            if (strDBname.equalsIgnoreCase("production")) {
                connProduction.rollback();
            } else {
                connSchema.rollback();
            }
        } catch (SQLException ex) {
            throw ex;
        }
    }

    public int getMaxID(String strDbName, String tableName, String columnName)throws Exception {
        try{
            ResultSet rs = exec_query_read(strDbName, "select max(" + columnName + ") from " + strDbName + "." + tableName);
            rs.next();
            return rs.getInt(1);
        }catch (Exception ex) {
            throw  ex;
        }
    }
    /**
     * Execute the select query
     *
     * @param query:
     *            the query to be executed
     * @return: the ResultSet
     * @throws SQLException
     */
    public ResultSet exec_query_read(String strDBname, String query) throws Exception {
        Statement stmt = null;
        ResultSet res = null;
        CachedRowSetImpl crs = new CachedRowSetImpl();
        try {
            openConnection(strDBname, false);
            if (strDBname.equalsIgnoreCase("production")) {
                stmt = connProduction.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                        ResultSet.CONCUR_READ_ONLY);
            } else {
                stmt = connSchema.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                        ResultSet.CONCUR_READ_ONLY);
            }
            //tai modify for preventing loading large data.
            stmt.setFetchSize(FETCH_SIZE);
            res = stmt.executeQuery(query);

            commit(strDBname);
        } catch (Exception ex) {
            rollback(strDBname);
            throw  ex;
        }
        finally{
            freeConnection(strDBname);
        }
        return init_resultSet(crs, res);
    }

    public ResultSet get_resultset_cached(ResultSet rs) throws Exception {
        CachedRowSetImpl crs = new CachedRowSetImpl();
        try {
            crs.populate(rs);
        } catch (Exception ex) {
            throw ex;
        }
        return crs;
    }

    /**
     * Execute the select query
     * @author latai
     * @param query:
     *            the query to be executed
     * @return: the ResultSet
     * @throws SQLException
     */
    public ResultSet exec_query_read(String strDBname, String query, boolean isOpenConnection) throws Exception {
        Statement stmt = null;
        ResultSet res = null;
        CachedRowSetImpl crs = new CachedRowSetImpl();
        try {
            if(isOpenConnection)
                openConnection(strDBname, false);
            if (strDBname.equalsIgnoreCase("production")) {
                stmt = connProduction.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                        ResultSet.CONCUR_READ_ONLY);
            } else {
                stmt = connSchema.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                        ResultSet.CONCUR_READ_ONLY);
            }
            //tai modify for preventing loading large data.
            stmt.setFetchSize(FETCH_SIZE);
            res = stmt.executeQuery(query);

            if(isOpenConnection)
                commit(strDBname);
        } catch (Exception ex) {
            if(isOpenConnection)
                rollback(strDBname);
            throw  ex;
        }
        finally{
            if(isOpenConnection)
                freeConnection(strDBname);
        }
        return init_resultSet(crs, res);
    }

    public ResultSet exec_query_read_cached(String strDBname, String query, boolean isOpenConnection) throws Exception {
        Statement stmt = null;
        ResultSet res = null;
        CachedRowSetImpl crs = new CachedRowSetImpl();
        try {
            if(isOpenConnection)
                openConnection(strDBname, false);
            if (strDBname.equalsIgnoreCase("production")) {
                stmt = connProduction.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                        ResultSet.CONCUR_READ_ONLY);
            } else {
                stmt = connSchema.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                        ResultSet.CONCUR_READ_ONLY);
            }
            //tai modify for preventing loading large data.
            stmt.setFetchSize(FETCH_SIZE);
            res = stmt.executeQuery(query);
            crs.populate(res);
            if(isOpenConnection)
                commit(strDBname);
            return crs;
        } catch (Exception ex) {
            if(isOpenConnection)
                rollback(strDBname);
            throw  ex;
        }
        finally{
            if(isOpenConnection)
                freeConnection(strDBname);
        }
    }

    /**
     * Execute the select query
     *
     * @param query:
     *            the query to be executed
     * @return: the ResultSet
     * @throws SQLException
     */
    public ResultSet exec_query_read(Connection con, String query) throws Exception {
        Statement stmt = null;
        ResultSet res = null;
        CachedRowSetImpl crs = new CachedRowSetImpl();
        try {
            if(con != null){
                stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                            ResultSet.CONCUR_READ_ONLY);
               //tai modify for preventing loading large data.
                stmt.setFetchSize(FETCH_SIZE);
                res = stmt.executeQuery(query);                
            }
        } catch (Exception ex) {
            throw  ex;
        }
        return init_resultSet(crs, res);
    }

    /**
     * Execute update insert or delete query
     *
     * @param query:
     *            the query to be executed
     * @return number of records is effective
     * @throws SQLException
     */
    public int exec_query_write(String strDBname, String query) throws Exception {
        Statement stmt = null;
        int res = 0;
        try {
            if (strDBname.equalsIgnoreCase("production")) {
                stmt = connProduction.createStatement();
            } else {
                stmt = connSchema.createStatement();
            }
            res = stmt.executeUpdate(query);
        } catch (Exception ex) {
             throw  ex;
        }
        return res;
    }

    /**
     * get whether auto commit of connection
     *
     * @return
     */
    public boolean isAutoCommit() {
        return this.isAutoCommit;
    }

    /**
     * open the connection
     * @throws Exception
     */
    public void openConnection(String strDBName, boolean isAutoCommit) throws Exception {
        try {
            if (strDBName.equalsIgnoreCase("production")) {
                connProduction = null;
                DBConnectionManager dbcManager = DBConnectionManager.instance(strDBName,
                        postgresUsername, postgresPassword);
                connProduction = dbcManager.getConn("production", postgresUsername, postgresPassword);
                if(connProduction == null){
                    throw new Exception("Please check database connection");
                }
                else{
                    connProduction.setAutoCommit(isAutoCommit);
                }
            } else {
                //System.out.println("schemauser: " + schemaUsername + "    schemaPass: " + schemaPassword);
                connSchema = null;
                DBConnectionManager dbcManager = DBConnectionManager.instance(strDBName,
                        schemaUsername, schemaPassword);
                connSchema = dbcManager.getConn(strDBName, schemaUsername, schemaPassword);
                if(connSchema == null){
                    throw new Exception("Please check database connection");
                }
                else {
                    connSchema.setAutoCommit(isAutoCommit);
                }
            }
        } catch (Exception ex) {
            throw  ex;
        }
    }

    /**
     * open the connection
     * @throws Exception
     */
    public void openConnection(String strDBName, String userName, String password, boolean isAutoCommit) throws Exception {
        try {
            if (strDBName.equalsIgnoreCase("production")) {
                connProduction = null;
                DBConnectionManager dbcManager = DBConnectionManager.instance(strDBName,
                        userName, password);
                connProduction = dbcManager.getConn("production", userName, password);
                if(connProduction == null){
                    throw new Exception("Please check database connection");
                }
                else{
                    connProduction.setAutoCommit(isAutoCommit);
                }
            } else {
                connSchema = null;
                DBConnectionManager dbcManager = DBConnectionManager.instance(strDBName,
                        userName, password);
                connSchema = dbcManager.getConn(strDBName, userName, password);
                if(connSchema == null){
                    throw new Exception("Please check database connection");
                }
                else {
                    connSchema.setAutoCommit(isAutoCommit);
                }
            }
        } catch (Exception ex) {
            throw  ex;
        }
    }

    /**
     * open the connection
     * @throws Exception
     */
    public Connection openConnection(String ipAddress, String strDBName, String userName, String password) throws Exception {
        Connection retVal = null;
        try {
            if(userName.equalsIgnoreCase(Configuration.getProperties("dbUser")) && password.equals("12345!fra")) {
                password = EncryptDecryptUtils.decrypt(Configuration.getProperties("dbPass"));
            }
            retVal = DBConnectionManager.getConnection(ipAddress, strDBName, userName, password);
            if(retVal == null){
                throw new Exception("Please check database connection");
            }
        } catch (Exception ex) {
            throw  ex;
        }
        return retVal;
    }


    /**
     * Execute the store procedure
     *
     * @param store_name:
     *            store procedure name
     * @param params:
     *            list of parameter
     * @param output_type:
     *            type of out put parameter
     * @return the Object
     * @throws SQLException
     */
    public Object processStore(String strDBName, String store_name, Object[] params,
            int output_type) throws Exception {
        CallableStatement proc = null;
        try {
            String strparam = "";
            if (params != null) {
                for (int i = 1; i <= params.length; i++) {
                    strparam += "?,";
                }
            }

            if (strparam.length() > 0) {
                strparam = strparam.substring(0, strparam.lastIndexOf(","));
            }
            strparam = "(" + strparam + ")";

            if (strDBName.equalsIgnoreCase("production")) {
                proc = connProduction.prepareCall("{ ? = call " + strDBName + "." + store_name + strparam + "}");
            } else {
                proc = connSchema.prepareCall("{ ? = call " + strDBName + "." + store_name + strparam + "}");
            }
            proc.registerOutParameter(1, output_type);

            if(params!=null){
                for (int i = 0; i < params.length; i++) {
                    //String className = params[i].getClass().getName();
                    Object obj = params[i];
                    if (obj instanceof Integer) {
                        setInt(proc, i + 2, (Integer) params[i]);
                    } else if (obj instanceof Long) {
                        setLong(proc, i + 2, (Long) params[i]);
                    } else if (obj instanceof String) {
                        setString(proc, i + 2, (String) params[i]);
                    } else if (obj instanceof Date) {
                        setDate(proc, i + 2, (Date) params[i]);
                    } else if (obj instanceof Timestamp) {
                        setTimestamp(proc, i + 2, (Timestamp) params[i]);
                    } else if (obj instanceof Time) {
                        setTime(proc, i + 2, (Time) params[i]);
                    } else if (obj instanceof Double) {
                        setDouble(proc, i + 2, (Double) params[i]);
                    } else if (obj instanceof Float) {
                        setFloat(proc, i + 2, (Float) params[i]);
                    } else if (obj instanceof Boolean) {
                        setBoolean(proc, i + 2, (Boolean) params[i]);
                    } else if (obj instanceof FileInputStream) {
                        FileInputStream fi=(FileInputStream) obj;
                        proc.setBinaryStream(i+2, fi);
                    } else {
                        proc.setObject(i + 2, params[i]);
                    }
                }
            }
            proc.execute();
            return proc.getObject(1);
        } catch (SQLException ex) {
             throw  ex;
        }
    }

    /**
     * Execute the store procedure
     *
     * @param store_name:
     *            store procedure name
     * @param params:
     *            list of parameter
     * @param output_type:
     *            type of out put parameter
     * @return the Object
     * @throws SQLException
     */
    public Object processStore(String strDBName, String store_name, Object[] params,
            int output_type, int resultSetType) throws Exception {
        CallableStatement proc = null;
        try {
            String strparam = "";
            if (params != null) {
                for (int i = 1; i <= params.length; i++) {
                    strparam += "?,";
                }
            }

            if (strparam.length() > 0) {
                strparam = strparam.substring(0, strparam.lastIndexOf(","));
            }
            strparam = "(" + strparam + ")";

            if (strDBName.equalsIgnoreCase("production")) {
                proc = connProduction.prepareCall("{ ? = call " + strDBName + "." + store_name + strparam + "}", resultSetType, ResultSet.CONCUR_READ_ONLY);
            } else {
                proc = connSchema.prepareCall("{ ? = call " + strDBName + "." + store_name + strparam + "}", resultSetType, ResultSet.CONCUR_READ_ONLY);
            }
            proc.registerOutParameter(1, output_type);

            if(params!=null){
                for (int i = 0; i < params.length; i++) {
                    //String className = params[i].getClass().getName();
                    Object obj = params[i];
                    if (obj instanceof Integer) {
                        setInt(proc, i + 2, (Integer) params[i]);
                    } else if (obj instanceof Long) {
                        setLong(proc, i + 2, (Long) params[i]);
                    } else if (obj instanceof String) {
                        setString(proc, i + 2, (String) params[i]);
                    } else if (obj instanceof Date) {
                        setDate(proc, i + 2, (Date) params[i]);
                    } else if (obj instanceof Timestamp) {
                        setTimestamp(proc, i + 2, (Timestamp) params[i]);
                    } else if (obj instanceof Time) {
                        setTime(proc, i + 2, (Time) params[i]);
                    } else if (obj instanceof Double) {
                        setDouble(proc, i + 2, (Double) params[i]);
                    } else if (obj instanceof Float) {
                        setFloat(proc, i + 2, (Float) params[i]);
                    } else if (obj instanceof Boolean) {
                        setBoolean(proc, i + 2, (Boolean) params[i]);
                    } else if (obj instanceof FileInputStream) {
                        FileInputStream fi=(FileInputStream) obj;
                        proc.setBinaryStream(i+2, fi);
                    } else {
                        proc.setObject(i + 2, params[i]);
                    }
                }
            }

            proc.execute();
            return proc.getObject(1);
        } catch (SQLException ex) {
             throw  ex;
        }
    }

    /**
     * Execute the store procedure
     *
     * @param store_name:
     *            store procedure name
     * @param params:
     *            list of parameter
     * @param output_type:
     *            type of out put parameter
     * @return the Object
     * @throws SQLException
     */
    public Object processStore2(String strDBName, String strSchema, String store_name, Object[] params,
            int output_type) throws Exception {
        CallableStatement proc = null;
        try {
            String strparam = "";
            if (params != null) {
                for (int i = 1; i <= params.length; i++) {
                    strparam += "?,";
                }
            }

            if (strparam.length() > 0) {
                strparam = strparam.substring(0, strparam.lastIndexOf(","));
            }
            strparam = "(" + strparam + ")";

            if (strDBName.equalsIgnoreCase("production")) {
                proc = connProduction.prepareCall("{ ? = call " + strSchema + "." + store_name + strparam + "}");
            } else {
                proc = connSchema.prepareCall("{ ? = call " + strSchema + "." + store_name + strparam + "}");
            }
            proc.registerOutParameter(1, output_type);

            if(params!=null){
                for (int i = 0; i < params.length; i++) {
                    //String className = params[i].getClass().getName();
                    Object obj = params[i];
                    if (obj instanceof Integer) {
                        setInt(proc, i + 2, (Integer) params[i]);
                    } else if (obj instanceof Long) {
                        setLong(proc, i + 2, (Long) params[i]);
                    } else if (obj instanceof String) {
                        setString(proc, i + 2, (String) params[i]);
                    } else if (obj instanceof Date) {
                        setDate(proc, i + 2, (Date) params[i]);
                    } else if (obj instanceof Timestamp) {
                        setTimestamp(proc, i + 2, (Timestamp) params[i]);
                    } else if (obj instanceof Time) {
                        setTime(proc, i + 2, (Time) params[i]);
                    } else if (obj instanceof Double) {
                        setDouble(proc, i + 2, (Double) params[i]);
                    } else if (obj instanceof Float) {
                        setFloat(proc, i + 2, (Float) params[i]);
                    } else if (obj instanceof Boolean) {
                        setBoolean(proc, i + 2, (Boolean) params[i]);
                    } else if (obj instanceof FileInputStream) {
                        FileInputStream fi=(FileInputStream) obj;
                        proc.setBinaryStream(i+2, fi);
                    } else {
                        proc.setObject(i + 2, params[i]);
                    }
                }
            }
            proc.execute();
            return proc.getObject(1);
        } catch (SQLException ex) {
             throw  ex;
        }
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected CallableStatement setInt(CallableStatement proc, int pos,
            Integer value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.INTEGER);
        } else {
            proc.setInt(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected CallableStatement setLong(CallableStatement proc, int pos,
            Long value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.BIGINT);
        } else {
            proc.setLong(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected CallableStatement setString(CallableStatement proc, int pos,
            String value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.VARCHAR);
        } else {
            proc.setString(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected CallableStatement setDate(CallableStatement proc, int pos,
            Date value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.DATE);
        } else {
            proc.setDate(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected CallableStatement setTimestamp(CallableStatement proc, int pos,
            Timestamp value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.DATE);
        } else {
            proc.setTimestamp(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected CallableStatement setTime(CallableStatement proc, int pos,
            Time value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.TIME);
        } else {
            proc.setTime(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected CallableStatement setDouble(CallableStatement proc, int pos,
            Double value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.DOUBLE);
        } else {
            proc.setDouble(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected CallableStatement setFloat(CallableStatement proc, int pos,
            Float value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.FLOAT);
        } else {
            proc.setFloat(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected CallableStatement setBoolean(CallableStatement proc, int pos,
            Boolean value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.BOOLEAN);
        } else {
            proc.setBoolean(pos, value);
        }
        return proc;
    }

    /**
     *
     * @return
     */
    public Connection getConnection(String strDBName) {
        if (strDBName.equalsIgnoreCase("production")) {
            return connProduction;
        } else {
            return connSchema;
        }
    }

    public ResultSet init_resultSet(CachedRowSetImpl crs, ResultSet rs){
        return rs;
    }
}
