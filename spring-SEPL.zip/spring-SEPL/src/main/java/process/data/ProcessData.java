package process.data;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.context.expression.MapAccessor;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.expression.ExpressionException;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class ProcessData {
	
	
	

	
	public ProcessData() {
		super();
		// TODO Auto-generated constructor stub
	}

	private static final  String filePath  = "c:\\Users\\dlnminh\\Desktop\\document.json";
	public static void main(String[] args) {
		
		
		
		ObjectMapper obMapper = new ObjectMapper();
		
		JSONParser jsonParser = new JSONParser();
		
		
		
		try {
			
			Object obj = jsonParser.parse(new FileReader(filePath));
			
			JSONObject jsonObject = (JSONObject) obj;
			
			Map map = obMapper.readValue(jsonObject.toString(), Map.class);
			StandardEvaluationContext context = new StandardEvaluationContext();
			context.addPropertyAccessor(new MapAccessor());
			context.setRootObject(map);
			ExpressionParser parser = new SpelExpressionParser();
			List exp = parser.parseExpression("data").getValue(context, List.class);
			//StandardEvaluationContext contexts = new StandardEvaluationContext();
			
			for(Object data : exp) {
				context.addPropertyAccessor(new MapAccessor());
				context.setRootObject(data);
				String datas = parser.parseExpression("customerData").getValue(context,String.class);
				Map maps = obMapper.readValue(datas.toString(), Map.class);
				context.addPropertyAccessor(new MapAccessor());
				context.setRootObject(maps);
					context.addPropertyAccessor(new MapAccessor());
					context.setRootObject(maps);
					ExpressionParser parserd = new SpelExpressionParser();
					List expk = parser.parseExpression("data.documents").getValue(context, List.class);
					//if(dt.toString().contains("recipient")) {
					System.out.println(expk);
				//'}
				
			}
			


			
			
			
			
			
			System.out.println("TEST ::::::::::::::::");
			
			
} catch (JsonParseException e) {
	// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	} 
	
	
	   private String compilePropertyPath(String... elements) {
			String path = StringUtils.EMPTY;
			if (ArrayUtils.isNotEmpty(elements)) {
				path = String.join(".", elements);
			}
			return path;
		}
	   
	  /* private <T> T getProperty(String expression, Object object, Class<T> tClass) {
			evaluationContext.setRootObject(object);
			T value = null;

			try {
				value = spelExpressionParser.parseExpression(expression).getValue(evaluationContext, tClass);
			} catch (ExpressionException e) {
				logger.error("Property {} cannot be found on object of type {}.", expression, object.getClass().getName(), e);
			}

			return value;
		}*/
	
	
	
		
	
}
