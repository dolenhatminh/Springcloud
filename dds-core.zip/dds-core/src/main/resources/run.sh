#!/bin/sh

HOST_ADDRESS=$1
JAR_FILE=dds-core.jar
CURRENT_DIR=$PWD
if [ $# -eq 0 ]
then
	HOST_ADDRESS=10.10.15.89
	echo 'Default address: ' $HOST_ADDRESS
fi

NODE_NAME=Node_$HOST_ADDRESS

java -Dcom.sun.management.jmxremote \
		-Dcom.sun.management.jmxremote.authenticate=false \
		-Dcom.sun.management.jmxremote.ssl=false \
		-Dcom.sun.management.jmxremote.port=5000 \
		-Dcom.sun.management.jmxremote.local.only=false \
		-Djava.rmi.server.hostname=$HOST_ADDRESS \
		-DclusterName=DDS-SYSTEM \
		-DnodeName=$NODE_NAME \
		-Djgroups.tcp.address=$HOST_ADDRESS \
		-Djgroups.mping.mcast_port=43366 \
		-Djgroups.tcp.port=7800 \
		-Dserver.port=8080 \
		-Dnotification-max-threads=1 \
		-Djgroups.configuration.file=jgroups-tcp.xml \
		-Dcommon.serverHost=http://$HOST_ADDRESS \
		-Ddmc.response.queue=DMCRSP_$HOST_ADDRESS \
		-Djgroups.tcpping.initial_hosts=10.10.15.89[7800],10.10.15.90[7800] \
		-Dlogging.config=$CURRENT_DIR/config/logback.xml \
		-Dspring.cloud.config.enabled=true \
		-Dspring.profiles.active=rule,par,dpms \
		-Dspring.application.name=dds \
		-Dhttp.maxConnections=30 \
		-server \
		-Xms12g \
		-Xmx12g \
		-XX:MaxMetaspaceSize=512m \
		-XX:+UseG1GC \
		-XX:MaxGCPauseMillis=200 \
		-XX:ParallelGCThreads=20 \
		-XX:ConcGCThreads=5 \
		-XX:InitiatingHeapOccupancyPercent=65 \
		-jar $JAR_FILE
