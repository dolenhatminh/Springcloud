
package vn.sps.aba.dds.common.types.ws.dpm.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AdresseErfassungType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdresseErfassungType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="HausKey" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="TypedFields" type="{Ch.Post.PL.DisCo.ReceiverInfoService}AddressFieldsType" minOccurs="0"/>
 *         &lt;element name="VolleAdresse" type="{Ch.Post.PL.DisCo.ReceiverInfoService}VolleAdresseType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdresseErfassungType", propOrder = {
    "hausKey",
    "typedFields",
    "volleAdresse"
})
public class AdresseErfassungType {

    @XmlElementRef(name = "HausKey", namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> hausKey;
    @XmlElementRef(name = "TypedFields", namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<AddressFieldsType> typedFields;
    @XmlElement(name = "VolleAdresse", required = true, nillable = true)
    protected VolleAdresseType volleAdresse;

    /**
     * Gets the value of the hausKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getHausKey() {
        return hausKey;
    }

    /**
     * Sets the value of the hausKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setHausKey(JAXBElement<Integer> value) {
        this.hausKey = value;
    }

    /**
     * Gets the value of the typedFields property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AddressFieldsType }{@code >}
     *     
     */
    public JAXBElement<AddressFieldsType> getTypedFields() {
        return typedFields;
    }

    /**
     * Sets the value of the typedFields property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AddressFieldsType }{@code >}
     *     
     */
    public void setTypedFields(JAXBElement<AddressFieldsType> value) {
        this.typedFields = value;
    }

    /**
     * Gets the value of the volleAdresse property.
     * 
     * @return
     *     possible object is
     *     {@link VolleAdresseType }
     *     
     */
    public VolleAdresseType getVolleAdresse() {
        return volleAdresse;
    }

    /**
     * Sets the value of the volleAdresse property.
     * 
     * @param value
     *     allowed object is
     *     {@link VolleAdresseType }
     *     
     */
    public void setVolleAdresse(VolleAdresseType value) {
        this.volleAdresse = value;
    }

}
