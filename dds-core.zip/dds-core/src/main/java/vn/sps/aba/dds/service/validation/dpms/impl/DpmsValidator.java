/*
 * Class: DpmsValidator
 *
 * Created on Oct 8, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.dpms.impl;

import javax.xml.bind.JAXBElement;
import javax.xml.transform.Result;
import javax.xml.transform.Source;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.xml.transform.StringResult;
import org.springframework.xml.transform.StringSource;
import org.springframework.xml.validation.XmlValidator;
import org.xml.sax.SAXParseException;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.types.ws.dpms.AddressFields;
import vn.sps.aba.dds.common.types.ws.dpms.CaptureResultRecord;
import vn.sps.aba.dds.common.types.ws.dpms.ObjectFactory;
import vn.sps.aba.dds.common.util.JaxbUtil;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.service.DpmsServiceConfiguration;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.receiver.ReceiverProcessingManager;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;
import vn.sps.aba.dds.service.validation.dpms.IReceiverValidator;
import vn.sps.aba.dds.service.validation.dpms.PackageValidatingInfo;
import vn.sps.aba.dds.service.validation.dpms.ReceiverValidatingInfo;

/**
 * The Class DpmsValidator.
 */
public class DpmsValidator implements IReceiverValidator {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DefaultDpmValidator.class);

    /** The process manager. */
    @Autowired
    private ReceiverProcessingManager processManager;

    /** The receiver info DAO. */
    @Autowired
    private IReceiverInfoCacheDao receiverInfoDao;

    /** The service configuration. */
    @Autowired
    private DpmsServiceConfiguration serviceConfiguration;

    /**
     * Apply manged info.
     *
     * @param receiverInfo the receiver info
     */
    @Override
    public void applyMangedInfo(final ReceiverInfo receiverInfo) {

    }

    /**
     * Checks if is valid address.
     *
     * @param key the key
     * @param validatingInfo the validating info
     * @return true, if is valid address
     */
    private boolean isValidAddress(final String key, final ReceiverValidatingInfo validatingInfo) {

        try {
            final CaptureResultRecord receiverInfoRecord = validatingInfo.getReceiverInfo();
            final AddressFields addressFields = receiverInfoRecord.getAdresseErfassung().getValue().getVolleAdresse().getValue().getFields().getValue();

            if (JaxbUtil.nullOrEmpty(addressFields.getName()) && JaxbUtil.nullOrEmpty(addressFields.getFirmenname())) {
                validatingInfo.getErrors().add("The address fields must contains at least Name or Firmenname");
            }
            if (JaxbUtil.nullOrEmpty(addressFields.getStrasse()) && JaxbUtil.nullOrEmpty(addressFields.getPostfach())) {
                validatingInfo.getErrors().add("The address fields must contains at least Strasse or Postfach");
            }
            if (JaxbUtil.nullOrEmpty(addressFields.getPostleitzahl())) {
                validatingInfo.getErrors().add("The address fields must contains Postleitzahl");
            }
            if (JaxbUtil.nullOrEmpty(addressFields.getOrt())) {
                validatingInfo.getErrors().add("The address fields must contains Ort");
            }
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(key), "Error when checking receiver address fields.", e);
        }

        return validatingInfo.isValid();
    }

    /**
     * Process invalid receiver info.
     *
     * @param key the key
     * @param receiverValidatingInfo the receiver validating info
     * @param packageValidatingInfo the package validating info
     */
    private void processInvalidReceiverInfo(
        final String key,
        final ReceiverValidatingInfo receiverValidatingInfo,
        final PackageValidatingInfo packageValidatingInfo) {
        try {
            final CaptureResultRecord receiverInfoRecord = receiverValidatingInfo.getReceiverInfo();
            LOG.error(IndexMaker.indexes(receiverValidatingInfo), "Invalid receiver info");

            if (this.serviceConfiguration.isStoreInvalidReceiverInfo()) {

                String identCode = JaxbUtil.element2String(receiverInfoRecord.getIdentcode());

                if ((identCode == null) || identCode.isEmpty()) {
                    LOG.warn(IndexMaker.index(key, identCode), "Cannot find ident code in this receiver info. Use a generated key instead.");
                    identCode = key;
                }

                if (this.receiverInfoDao.containKey(identCode)) {
                    LOG.warn(IndexMaker.index(key, identCode), "Invalid receiver info has duplicated ident code");
                }
                final ReceiverInfo receiverInfo = new ReceiverInfo(packageValidatingInfo.getCallerId(), packageValidatingInfo.getVersion(), receiverInfoRecord,
                    true);
                {
                    receiverInfo.setReceived(packageValidatingInfo.getReceivedTime());
                    receiverInfo.setKey(key);
                    receiverInfo.setStatusCode(this.serviceConfiguration.invalidCaptureResultRecordsError().getCode());
                }
                receiverInfo.setState(ReceiverState.INVALID);
                this.receiverInfoDao.store(identCode, receiverInfo);
            }
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.index(key), "Error when trying to store invalid receiver info", e);
        }
    }

    /**
     * Process valid receiver info.
     *
     * @param key the key
     * @param receiverValidatingInfo the receiver validating info
     * @param packageValidatingInfo the package validating info
     */
    private void processValidReceiverInfo(
        final String key,
        final ReceiverValidatingInfo receiverValidatingInfo,
        final PackageValidatingInfo packageValidatingInfo) {

        final CaptureResultRecord receiverInfoRecord = receiverValidatingInfo.getReceiverInfo();
        final String identCode = JaxbUtil.element2String(receiverInfoRecord.getIdentcode());

        if (this.receiverInfoDao.containKey(identCode)) {
            this.receiverInfoDao.remove(identCode);
        }
        final ReceiverInfo receiverInfo = new ReceiverInfo(packageValidatingInfo.getCallerId(), packageValidatingInfo.getVersion(), receiverInfoRecord, true);
        {
            receiverInfo.setReceived(packageValidatingInfo.getReceivedTime());
            receiverInfo.setKey(key);
            receiverInfo.setState(ReceiverState.VERIFIED);
            receiverInfo.setStatusCode(this.serviceConfiguration.successful().getCode());
            receiverInfo.setVerifiedByRule(receiverValidatingInfo.getVerifiedRule());
        }
        this.receiverInfoDao.store(identCode, receiverInfo);
        this.processManager.submit(receiverInfo);
    }

    /**
     * Validate.
     *
     * @param receiverValidatingInfo the receiver validating info
     * @param packageValidatingInfo the package validating info
     * @return true, if successful
     */
    @Override
    public boolean validate(final ReceiverValidatingInfo receiverValidatingInfo, final PackageValidatingInfo packageValidatingInfo) {

        final String key = StringUtil.newUuidString();

        try {
            receiverValidatingInfo.setKey(key);
            final CaptureResultRecord receiverInfoRecord = receiverValidatingInfo.getReceiverInfo();

            // Validate the receiver info by XSD schema
            final ObjectFactory objectFactory = this.serviceConfiguration.getObjectFactory();
            final JAXBElement<CaptureResultRecord> element = objectFactory.createCaptureResultRecord(receiverInfoRecord);
            final Result result = new StringResult();
            this.serviceConfiguration.getMarshaller().marshal(element, result);
            final XmlValidator createValidator = this.serviceConfiguration.getXsdValidationSchemas().createValidator();
            final String content = result.toString();
            final Source source = new StringSource(content);
            final SimpleErrorHandler errorHandler = new SimpleErrorHandler();
            createValidator.validate(source, errorHandler);

            for (final SAXParseException error : errorHandler.getErrors()) {
                receiverValidatingInfo.getErrors().add(error.getMessage());
            }

            if (!receiverValidatingInfo.isValid()) {
                this.processInvalidReceiverInfo(key, receiverValidatingInfo, packageValidatingInfo);
            }
            else {
                // Validate the receiver info by the rules
                if (!this.isValidAddress(key, receiverValidatingInfo)) {
                    this.processInvalidReceiverInfo(key, receiverValidatingInfo, packageValidatingInfo);
                }
                else {
                    this.processValidReceiverInfo(key, receiverValidatingInfo, packageValidatingInfo);
                }
            }
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.index(key), "There is error when validating receiver info", e);
        }

        return receiverValidatingInfo.isValid();
    }

}
