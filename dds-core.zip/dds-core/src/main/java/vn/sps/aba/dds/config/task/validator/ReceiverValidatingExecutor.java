/*
 * Class: TaskDpmbReception
 *
 * Created on Aug 5, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.task.validator;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.config.task.TaskConfiguration;

/**
 * The Class TaskDpmbReception.
 */
@Profile(value = { Profiles.RECEIVER, Profiles.DPM, Profiles.DPMB, Profiles.DPMS })
@Configuration("ReceiverValidatingExecutor")
@ConfigurationProperties(prefix = "task.receiver.validation")
public class ReceiverValidatingExecutor extends TaskConfiguration {

}
