/*
 * Class: AutoCaptureServiceConfiguration
 *
 * Created on Jul 22, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.wsdl.wsdl11.SimpleWsdl11Definition;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.DDSConstant.Namespace;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.dpmb.ObjectFactory;
import vn.sps.aba.dds.config.reponsecode.IDpmbResponseCode;

/**
 * The Class DpmServiceConfiguration.
 */
@Profile(Profiles.DPMB)
@Configuration("DpmbServiceConfiguration")
@ConfigurationProperties(prefix = "ws.dpmb")
public class DpmbServiceConfiguration extends AbstractSoapWsConfiguration implements IDpmbResponseCode {

    /**
     * The Enum ResponseCode.
     */
    private enum ResponseCode {

        /** The Failed authorization error. */
        FailedAuthorizationError,
        /** The Invalid argument error. */
        InvalidArgumentError,
        /** The Invalid capture result records error. */
        InvalidCaptureResultRecordsError,
        /** The Successful. */
        Successful,
        /** The Unexpected error. */
        UnexpectedError
    }

    /** The Constant SOUCE. */
    private static final String SOUCE = DDSConstant.Source.E190;

    /** The Constant WSDL_NAME. */
    private static final String WSDL_NAME = "dpmService";

    /** The caller id format. */
    private String callerIdFormat;

    /** The ident code format. */
    private String identCodeFormat;

    /** The received time format. */
    private String receivedTimeFormat;

    /** The receiver info error format. */
    private String receiverInfoErrorFormat;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#addInterceptors(java.util.List)
     */
    @Override
    public void addInterceptors(final List<EndpointInterceptor> interceptors) {
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.IDpmbResponseCode#failedAuthorizationError()
     */
    @Override
    public Response failedAuthorizationError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.FailedAuthorizationError.name());
    }

    /**
     * Gets the caller id format.
     *
     * @return the caller id format
     */
    public String getCallerIdFormat() {
        return this.callerIdFormat;
    }

    /**
     * Gets the ident code format.
     *
     * @return the ident code format
     */
    public String getIdentCodeFormat() {
        return this.identCodeFormat;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getNamespaceURI()
     */
    @Override
    public String getNamespaceURI() {
        return Namespace.E190_NAMESPACE;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getObjectFactory()
     */
    @Override
    public ObjectFactory getObjectFactory() {
        return (ObjectFactory) super.getObjectFactory();
    }

    /**
     * Gets the received time format.
     *
     * @return the received time format
     */
    public String getReceivedTimeFormat() {
        return this.receivedTimeFormat;
    }

    /**
     * Gets the receiver info error format.
     *
     * @return the receiver info error format
     */
    public String getReceiverInfoErrorFormat() {
        return this.receiverInfoErrorFormat;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getServiceName()
     */
    @Override
    public String getServiceName() {
        return "ReceiverInfo";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#initialize()
     */
    @Override
    @PostConstruct
    public void initialize() throws Exception {
        super.initialize();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.IDpmbResponseCode#invalidArgumentError()
     */
    @Override
    public Response invalidArgumentError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.InvalidArgumentError.name());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.IDpmbResponseCode#invalidCaptureResultRecordsError()
     */
    @Override
    public Response invalidCaptureResultRecordsError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.InvalidCaptureResultRecordsError.name());
    }

    /**
     * Sets the caller id format.
     *
     * @param callerIdFormat the new caller id format
     */
    public void setCallerIdFormat(final String callerIdFormat) {
        this.callerIdFormat = callerIdFormat;
    }

    /**
     * Sets the ident code format.
     *
     * @param identCodeFormat the new ident code format
     */
    public void setIdentCodeFormat(final String identCodeFormat) {
        this.identCodeFormat = identCodeFormat;
    }

    /**
     * Sets the received time format.
     *
     * @param receivedTimeFormat the new received time format
     */
    public void setReceivedTimeFormat(final String receivedTimeFormat) {
        this.receivedTimeFormat = receivedTimeFormat;
    }

    /**
     * Sets the receiver info error format.
     *
     * @param receiverInfoErrorFormat the new receiver info error format
     */
    public void setReceiverInfoErrorFormat(final String receiverInfoErrorFormat) {
        this.receiverInfoErrorFormat = receiverInfoErrorFormat;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.IDpmbResponseCode#successful()
     */
    @Override
    public Response successful() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.Successful.name());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.IDpmbResponseCode#unexpectedError()
     */
    @Override
    public Response unexpectedError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.UnexpectedError.name());
    }

    /**
     * Wsdl definition.
     *
     * @return the simple wsdl11 definition
     */
    @Bean(name = WSDL_NAME)
    public SimpleWsdl11Definition wsdlDefinition() {
        return new SimpleWsdl11Definition(this.wsdlResource);
    }

}
