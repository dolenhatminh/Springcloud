/*
 * Class: IndexesFactory
 *
 * Created on Sep 30, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.logging;

import java.util.HashMap;
import java.util.Map;

import net.logstash.logback.marker.LogstashMarker;
import net.logstash.logback.marker.Markers;
import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;

public final class IndexMaker {

    public static class WsResponse {
        private final String identCode;

        private final String key;

        private final Object response;

        private WsResponse(final IdentifiedEntry entry, final Object response) {
            this.key = entry.getKey();
            this.identCode = entry.getIdentCode();
            this.response = response;
        }

        private WsResponse(final String key, final String identCode, final Object response) {
            this.key = key;
            this.identCode = identCode;
            this.response = response;
        }

        public String getIdentCode() {
            return this.identCode;
        }

        public String getKey() {
            return this.key;
        }

        public Object getResponse() {
            return this.response;
        }
    }

    private static final String FIELD_IDENT_CODE = DDSConstant.ParcelFields.FIELD_IDENT_CODE;

    private static final String FIELD_KEY = DDSConstant.ParcelFields.FIELD_KEY;

    private static final String FIELD_OBJECT_NAME = "content";

    private static final String FIELD_STATE = DDSConstant.ParcelFields.FIELD_STATE;

    private static final String FIELD_DMC_STATE = DDSConstant.ParcelFields.FIELD_DMC_STATE;

    private static final String FIELD_PACKAGE_ID = "packageId";
    
    private static final String FIELD_ABA_REPORT = "receiverInfoReport";

    public static LogstashMarker index(final IdentifiedEntry entry) {
        final Map<String, String> indexes = new HashMap<>();
        {
            indexes.put(FIELD_KEY, entry.getKey());
            indexes.put(FIELD_IDENT_CODE, entry.getIdentCode());
            indexes.put(FIELD_STATE, entry.getState());
            indexes.put(FIELD_DMC_STATE, entry.getMinorState());
        }
        return Markers.appendEntries(indexes);
    }

    public static LogstashMarker index(final IdentifiedEntry entry, final Object response) {
        return indexes(new WsResponse(entry, response));
    }

    public static LogstashMarker index(final ReceiverInfo receiverInfo) {
        final Map<String, String> indexes = new HashMap<>();
        {
            indexes.put(FIELD_KEY, receiverInfo.getKey());
            indexes.put(FIELD_IDENT_CODE, receiverInfo.getIdentCode());
            indexes.put(FIELD_STATE, receiverInfo.getState());
            indexes.put(FIELD_PACKAGE_ID, receiverInfo.getPackageId());
        }
        return Markers.appendEntries(indexes);
    }

    public static LogstashMarker index(final String key) {
        return Markers.append(FIELD_KEY, key);
    }

    public static LogstashMarker index(final String key, final String identCode) {
        final Map<String, String> indexes = new HashMap<>();
        indexes.put(FIELD_KEY, key);
        indexes.put(FIELD_IDENT_CODE, identCode);
        return Markers.appendEntries(indexes);
    }

    public static LogstashMarker indexes(final Object object) {
        return Markers.appendFields(object);
    }
    
	/**
	 * Log fieldName - Object 
	 * @param object
	 * @param fieldName
	 * @return
	 */
	public static LogstashMarker indexes(final Object object, final String fieldName) {
		final Map<String, Object> indexes = new HashMap<>();
		indexes.put(fieldName, object);
		return Markers.appendEntries(indexes);
	}

    public static LogstashMarker indexes(final String key, final Object object) {
        return indexes(key, null, object, FIELD_OBJECT_NAME);
    }

    public static LogstashMarker indexes(final String key, final Object object, final String objectFieldName) {
        return indexes(key, null, object, objectFieldName);
    }

    public static LogstashMarker indexes(final String key, final String identCode, final Object object, final String objectFieldName) {
        final Map<String, Object> indexes = new HashMap<>();
        indexes.put(FIELD_KEY, key);
        indexes.put(FIELD_IDENT_CODE, identCode);
        // Don't use this if the indexed field name "objectFieldName" is null or empty.
        indexes.put(objectFieldName, object);
        return Markers.appendEntries(indexes);
    }

    private IndexMaker() {
    }
}
