package vn.sps.aba.dds.config.service;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * The Class AsdpServiceConfiguration.
 */
@Configuration("AsdpServiceConfiguration")
@ConfigurationProperties(prefix = "lookup.asdp")
public class AsdpServiceConfiguration extends AbstractRestWsConfiguration {

    /** The external. */
    private boolean external;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ServiceInfo#getContextPath()
     */
    @Override
    public String getContextPath() {
        return "";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getServiceName()
     */
    @Override
    public String getServiceName() {
        return "Asdp Plz";
    }

    /**
     * Checks if is external.
     *
     * @return true, if is external
     */
    public boolean isExternal() {
        return this.external;
    }

    /**
     * Sets the external.
     *
     * @param external the new external
     */
    public void setExternal(final boolean external) {
        this.external = external;
    }
}
