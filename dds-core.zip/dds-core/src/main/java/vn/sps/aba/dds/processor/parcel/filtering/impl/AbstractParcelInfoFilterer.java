/*
 * Class: AbstractParcelInfoFilterer
 *
 * Created on Jun 21, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.parcel.filtering.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.activation.UnsupportedDataTypeException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.ifa.chain.IStepResult;
import vn.sps.aba.dds.common.ifa.chain.impl.AbstractResponsibilityHandler;
import vn.sps.aba.dds.common.ifa.chain.impl.StepResult;
import vn.sps.aba.dds.common.model.lookup.IAsdpPlz;
import vn.sps.aba.dds.common.model.parcel.ParcelAddress;
import vn.sps.aba.dds.common.model.parcel.ParcelCodingInfo;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.model.parcel.ProduktZusatzleistung;
import vn.sps.aba.dds.common.types.exception.UnsupportedAttributeException;
import vn.sps.aba.dds.common.types.filter.FilterOperator;
import vn.sps.aba.dds.common.types.filterrule.Constraint;
import vn.sps.aba.dds.common.types.filterrule.FilterRule;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.parcel.filtering.IParcelInfoFilterer;
import vn.sps.aba.dds.repository.cache.interfaces.IParcelInfoCacheDao;
import vn.sps.aba.dds.service.lookup.asdp.IAsdpLookupService;

/**
 * The Class AbstractParcelInfoFilterer.
 */
public abstract class AbstractParcelInfoFilterer extends AbstractResponsibilityHandler<ParcelInfo, IStepResult> implements IParcelInfoFilterer {

    /**
     * The LOG.
     */
    private final static Logger LOG = LoggerFactory.getLogger(AbstractParcelInfoFilterer.class);

    /**
     * The asdp lookup service.
     */
    private final IAsdpLookupService asdpLookupService;

    /**
     * The constraints.
     */
    private FilterRule filterRule;

    /**
     * The parcel info data access object.
     */
    private final IParcelInfoCacheDao parcelInfoDao;

    /**
     * Instantiates a new abstract parcel info filterer.
     *
     * @param filterRule
     *            the filter rule
     * @param asdpLookupService
     *            the asdp lookup service
     * @param parcelInfoDao
     *            the parcel info data access object
     */
    public AbstractParcelInfoFilterer(final FilterRule filterRule, final IAsdpLookupService asdpLookupService, final IParcelInfoCacheDao parcelInfoDao) {
        this.asdpLookupService = asdpLookupService;
        this.parcelInfoDao = parcelInfoDao;
        this.setFilterRule(filterRule);
    }

    /**
     * Compare the date value to the <tt>dateString</tt>. <tt>dateString</tt>
     * must follow the <tt>dateFormat.</tt>, which is "yyyy MM dd".
     *
     * @param value
     *            the <tt>Date</tt> need to be compared
     * @param operation
     *            the operation, a value of
     *            {@linkplain vn.sps.aba.dds.common.types.filterrule.ConstraintOperator}
     * @param dateString
     *            the date in String format, the date must follow the format
     *            "yyyy MM dd"
     *
     * @return true, if the comparison is correct, false otherwise
     *
     * @throws ParseException
     *             if the <tt>dateString</tt> does not match the
     *             <tt>dateFormat</tt>
     */
    boolean compareDate(final Date value, final FilterOperator operation, final String dateString) throws ParseException {
        return this.compareDate(value, operation, dateString, Constant.FORMAT_DEFAULT_DATE_FORMAT);
    }

    /**
     * Compare the date value to the <tt>dateString</tt>. <tt>dateString</tt>
     * must follow the <tt>dateFormat.</tt>
     *
     * @param value
     *            the <tt>Date</tt> need to be compared
     * @param operation
     *            the operation, a value of
     *            {@linkplain vn.sps.aba.dds.common.types.filterrule.ConstraintRelation}
     * @param dateString
     *            the date in String format, the date must follow the
     *            <tt>dateFormat</tt>.If using
     *            {@linkplain vn.sps.aba.dds.common.types.filterrule.FilterOperator#BETWEEN},
     *            you need two date, separated by semi-colon (;).
     * @param dateFormat
     *            the format of the <tt>dateString</tt>.
     *
     * @return true, if the comparison is correct, false otherwise
     *
     * @throws ParseException
     *             if the <tt>dateString</tt> does not match the
     *             <tt>dateFormat</tt>
     */
    boolean compareDate(final Date value, final FilterOperator operation, final String dateString, final String dateFormat) throws ParseException {
        boolean ret = false;

        final DateFormat df = new SimpleDateFormat(dateFormat);
        final Date date = df.parse(dateString);

        switch (operation) {
        case IS:
            ret = value.compareTo(date) == 0;
            break;

        case LESS_THAN:
            ret = value.compareTo(date) < 0;
            break;

        default:
            ret = false;
        }

        return ret;
    }

    /**
     * Gets the filter rule.
     *
     * @return Returns the filterRule.
     */
    protected FilterRule getFilterRule() {
        return this.filterRule;
    }

    /**
     * Handle business.
     *
     * @param entry
     *            the entry
     */
    protected void handleBusiness(final ParcelInfo entry) {

    }

    /**
     * Match.
     *
     * @param entry            the entry
     * @param constraints            the constraints
     * @param matchedContraints the matched contraints
     * @return true, if successful
     */
    private boolean match(final ParcelInfo entry, final List<Constraint> constraints, final List<Constraint> matchedContraints) {
        boolean ret = false;

        if ((constraints != null) && (constraints.size() > 0)) {

            final boolean isMatchAny = this.getFilterRule().isMatchAny();
            ret = !isMatchAny;
            int i = 0;

            while ((ret != isMatchAny) && (i < constraints.size())) {

                final Constraint constraint = constraints.get(i);
                
                try {

                    if (constraint.getPattern() != null) {

                        ret = this.matchModel(constraint, entry);
                        if (ret) {
                            matchedContraints.add(constraint);
                            LOG.debug(IndexMaker.index(entry), "Match with constraint: {}", constraint.toString());
                        }
                    }
                    else {
                        LOG.warn("The pattern must not be null");
                    }
                }
                catch (final Exception e) {

                    LOG.warn(
                        IndexMaker.index(entry),
                        String.format(
                            "There is error occur while filtering parcel info with constraint %s. The filtering will keep going to next constraint",
                            constraint.toString()),
                        e);
                }

                i++;
            }
        }

        return ret;
    }

    /**
     * Match boolean.<br>
     * If the pattern is not "true" (ignored case), we assume it is false
     *
     * @param value
     *            the value
     * @param constraint
     *            the constraint
     * @return true, if successful
     */
    private boolean matchBoolean(final boolean value, final Constraint constraint) {
        boolean ret = false;

        final boolean matchValue = Boolean.valueOf(constraint.getPattern());

        switch (constraint.getOperator()) {

        case IS:
            ret = value == matchValue;
            break;

        default:
            throw this.unsupportOperator(constraint);
        }

        return ret;
    }

    /**
     * Match is begin mach string.
     *
     * @param value
     *            the value
     * @param constraint
     *            the constraint
     * @return true, if successful
     */
    private boolean matchIsBeginMachString(final String value, final Constraint constraint) {
        boolean ret = false;

        switch (constraint.getOperator()) {

        case BEGIN_WITH:
            ret = value.startsWith(constraint.getPattern());
            break;
        default:
            ret = this.matchIsMachString(value, constraint);
            break;
        }

        return ret;
    }

    /**
     * Match string.
     *
     * @param value
     *            the value
     * @param constaint
     *            the constaint
     * @return true, if successful
     */
    private boolean matchIsMachString(final String value, final Constraint constaint) {
        boolean ret = false;

        switch (constaint.getOperator()) {

        case IS:
            ret = value.equals(constaint.getPattern());
            break;
        case MATCH:
            ret = value.matches(constaint.getPattern());
            break;
        default:
            throw this.unsupportOperator(constaint);
        }

        return ret;
    }

    /**
     * Match model.
     *
     * @param constraint
     *            the constraint
     * @param entry
     *            the entry
     * @return true, if successful
     * @throws UnsupportedDataTypeException
     *             the unsupported data type exception
     * @throws UnsupportedAttributeException
     *             the unsupported attribute exception
     */
    private boolean matchModel(final Constraint constraint, final ParcelInfo entry) throws UnsupportedDataTypeException, UnsupportedAttributeException {
        boolean ret = false;

        LOG.debug("Contraint's model: " + constraint.getModel().toString());
        switch (constraint.getModel()) {

        case PARCEL_INFO:
            ret = this.matchParcelInfo(constraint, entry);
            break;

        case PARCEL_CODING_INFO:
            ret = this.matchParcelCodingInfo(constraint, entry);
            break;

        case PRODUKT_ZUSATZ_LEISTUNG:
            ret = this.matchProduktZusatzLeistung(constraint, entry);
            break;

        case PARCEL_ADDRESS:
            ret = this.matchParcelAddress(constraint, entry);
            break;

        case OTHERS:
            ret = this.matchOtherModel(constraint, entry);
            break;

        default:
            throw new UnsupportedDataTypeException("Unsupported filter for model:" + constraint.getModel().getName());
        }

        return ret;
    }

    /**
     * Match other model.
     *
     * @param constraint
     *            the constraint
     * @param entry
     *            the entry
     * @return true, if successful
     * @throws UnsupportedAttributeException
     *             the unsupported attribute exception
     */
    private boolean matchOtherModel(final Constraint constraint, final ParcelInfo entry) throws UnsupportedAttributeException {
        boolean ret = false;

        LOG.debug("Contraint's attribute: " + constraint.getAttribute().getName());
        final ParcelAddress parcelAddress = entry.getParcelAddress();

        switch (constraint.getAttribute()) {
        case OTHER_PLZ_TYPE:

            if (parcelAddress != null) {

                Integer plzType = null;
                if (parcelAddress.getPlzType() == null) {

                    final IAsdpPlz asdpPlz = this.asdpLookupService.getAsdpPlz(entry);

                    if (asdpPlz != null) {
                        plzType = asdpPlz.getPlzTyp();
                        parcelAddress.setPlzType(asdpPlz.getPlzTyp());
                        parcelAddress.setLogType(asdpPlz.getLogTyp());
                    }
                }
                else {
                    plzType = parcelAddress.getPlzType();
                }

                if (plzType != null) {
                    ret = this.matchIsMachString(String.valueOf(plzType), constraint);
                }
            }

            break;

        case OTHER_LOGISTIS_TYPE:

            if (parcelAddress != null) {

                Integer logType = null;
                if (parcelAddress.getLogType() == null) {

                    final IAsdpPlz asdpPlz = this.asdpLookupService.getAsdpPlz(entry);

                    if (asdpPlz != null) {
                        logType = asdpPlz.getLogTyp();
                        parcelAddress.setPlzType(asdpPlz.getPlzTyp());
                        parcelAddress.setLogType(asdpPlz.getLogTyp());
                    }
                }
                else {
                    logType = parcelAddress.getLogType();
                }

                if (logType != null) {
                    ret = this.matchIsMachString(String.valueOf(logType), constraint);
                }
            }

            break;

        case OTHER_IDENT_CODE_REPEATED_TIME:

            LOG.info("This case will not care about the operator");

            final int timeRange = Integer.valueOf(constraint.getPattern()).intValue() * 60000;
            final long receivedTime = entry.getReceived();

            final List<ParcelInfo> existedParcelInfos = this.parcelInfoDao.listByIdentCode(entry.getIdentCode());
            if (existedParcelInfos != null) {

                for (final ParcelInfo parcelInfo : existedParcelInfos) {

                    if (!parcelInfo.getKey().equals(entry.getKey()) && ((receivedTime - parcelInfo.getReceived()) <= timeRange)) {
                        ret = true;
                        break;
                    }
                }
            }

            break;

        default:
            throw this.unsupportAttribute(constraint);
        }

        return ret;
    }

    /**
     * Match parcel address.
     *
     * @param constraint
     *            the constraint
     * @param entry
     *            the entry
     * @return true, if successful
     * @throws UnsupportedAttributeException
     *             the unsupported attribute exception
     */
    private boolean matchParcelAddress(final Constraint constraint, final ParcelInfo entry) throws UnsupportedAttributeException {
        boolean ret = false;
        final ParcelAddress parcelAddress = entry.getParcelAddress();

        switch (constraint.getAttribute()) {

        case PARCEL_ADDRESS_ADDRESSS_TYPE:

            if ((parcelAddress != null) && (parcelAddress.getAddressType() != null)) {
                ret = this.matchIsBeginMachString(parcelAddress.getAddressType(), constraint);
            }
            break;

        case PARCEL_ADDRESS_ZIP:

            if ((parcelAddress != null) && (parcelAddress.getZip() != null)) {
                ret = this.matchIsMachString(parcelAddress.getZip(), constraint);
            }
            break;

        default:
            throw this.unsupportAttribute(constraint);
        }

        return ret;
    }

    /**
     * Match parcel coding info.
     *
     * @param constraint
     *            the constraint
     * @param entry
     *            the entry
     * @return true, if successful
     * @throws UnsupportedAttributeException
     *             the unsupported attribute exception
     */
    private boolean matchParcelCodingInfo(final Constraint constraint, final ParcelInfo entry) throws UnsupportedAttributeException {
        boolean ret = false;
        final ParcelCodingInfo codingInfo = entry.getParcelCodingInfo();

        switch (constraint.getAttribute()) {

        case PARCEL_CODING_INFO_CODING_QUALITY:

            if ((codingInfo != null) && (codingInfo.getCodingQuality() != null)) {

                ret = this.matchIsBeginMachString(codingInfo.getCodingQuality(), constraint);
            }
            break;
        default:
            throw this.unsupportAttribute(constraint);
        }

        return ret;
    }

    /**
     * Match parcel info.
     *
     * @param constraint
     *            the constraint
     * @param entry
     *            the entry
     * @return true, if successful
     * @throws UnsupportedAttributeException
     *             the unsupported attribute exception
     */
    private boolean matchParcelInfo(final Constraint constraint, final ParcelInfo entry) throws UnsupportedAttributeException {
        boolean ret = false;

        LOG.debug("Contraint's attribute: " + constraint.getAttribute().getName());

        switch (constraint.getAttribute()) {
        case PARCEL_INFO_IDENT_CODE:

            if (entry.getIdentCode() != null) {

                switch (constraint.getOperator()) {

                case NOT_MATCH:
                    ret = !entry.getIdentCode().matches(constraint.getPattern());
                    break;

                default:
                    ret = this.matchIsBeginMachString(entry.getIdentCode(), constraint);
                }
                break;
            }
        case PARCEL_INFO_IMAGE:
        case PARCEL_INFO_HAS_IMAGE:
            ret = this.matchBoolean(StringUtil.notNullOrEmpty(entry.getFilePath()) && StringUtil.notNullOrEmpty(entry.getFileName()), constraint);
            break;
        default:
            ret = this.matchOtherModel(constraint, entry);
            break;
        }

        return ret;
    }

    /**
     * Match produkt zusatz leistung.
     * <p>
     * If the ex
     * </p>
     *
     * @param constraint
     *            the constraint
     * @param entry
     *            the entry
     * @return true, if successful
     * @throws UnsupportedAttributeException
     *             the unsupported attribute exception
     */
    private boolean matchProduktZusatzLeistung(final Constraint constraint, final ParcelInfo entry) throws UnsupportedAttributeException {
        boolean ret = false;
        // case
        // There are some open points in requirement here
        // + We have maximum 8 extra services for a parcel. What is the rule for
        // matching ?
        // + Do we support customer to choose more than one rule for this fields
        // ?

        switch (constraint.getAttribute()) {
        case PRODUKT_ZUSATZ_LEISTUNG_CODE:

            if (entry.getProduktZusatzleistungens() != null) {

                for (final ProduktZusatzleistung entryProdukt : entry.getProduktZusatzleistungens()) {

                    ret = this.matchIsBeginMachString(entryProdukt.getCode(), constraint);
                    if (ret) {
                        break;
                    }
                }
            }
            break;
        default:
            throw this.unsupportAttribute(constraint);
        }

        return ret;
    }

    /**
     * {@inheritDoc}<br>
     * Must override this to filter parcel data<br>
     * Forward this data to the <code>getParcelStatus()</code> target
     *
     * @see vn.sps.aba.dds.common.ifa.chain.impl.AbstractResponsibilityHandler#process(java.lang.Object)
     */
    @Override
    protected final IStepResult process(final ParcelInfo entry) {

        final StepResult result = new StepResult();

        if (this.getFilterRule() != null) {

            final List<Constraint> matchedContraints = new ArrayList<>();
            if (this.match(entry, this.getFilterRule().getConstraints(), matchedContraints)) {

                result.setHandledInThisStep(true);
                entry.setState(this.getFilterRule().getUpdatedState());
                entry.setFilteredByRule(this.getFilterRule().getName());
                this.handleBusiness(entry);
                LOG.info(IndexMaker.index(entry), "Applied filter rule {}", this.filterRule.getName());
                for (final Constraint constraint : matchedContraints) {
                    LOG.info(IndexMaker.index(entry), "Match constraint {}", constraint.toString());
                }
            }
            else {
                result.setHandledInThisStep(false);
            }
        }

        return result;
    }

    /**
     * Sets the filter rule.
     *
     * @param filterRule
     *            The filterRule to set.
     */
    public void setFilterRule(final FilterRule filterRule) {
        this.filterRule = filterRule;
    }

    /**
     * Unsupport attribute.
     *
     * @param contraint
     *            the contraint
     * @return the unsupported attribute exception
     */
    private UnsupportedAttributeException unsupportAttribute(final Constraint contraint) {
        return new UnsupportedAttributeException(StringUtil.format("Unsupport [%s] for model [%s]", contraint.getAttribute(), contraint.getModel()));
    }

    /**
     * Unsupport operator.
     *
     * @param contraint
     *            the contraint
     * @return the unsupported operation exception
     */
    private UnsupportedOperationException unsupportOperator(final Constraint contraint) {
        return new UnsupportedOperationException(
            StringUtil.format("Unsupport operator [%s] on attribute [%s] model [%s]", contraint.getOperator(), contraint.getAttribute(), contraint.getModel()));
    }

}
