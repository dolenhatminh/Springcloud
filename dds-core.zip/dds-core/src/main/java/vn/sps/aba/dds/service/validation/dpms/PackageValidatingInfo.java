/*
 * Class: ErrorDPMPackageInfo
 *
 * Created on Sep 8, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.dpms;

import java.util.ArrayList;
import java.util.List;

import vn.sps.aba.dds.common.types.message.Response;

/**
 * The Class DpmPackageValidatingInfo.
 */
public class PackageValidatingInfo {

    /** The caller id. */
    protected String callerId;

    /** The error count. */
    private int errorCount;

    /** The errors. */
    private final List<String> errors = new ArrayList<>();

    /** The package id. */
    private String packageId;

    /** The received time. */
    private long receivedTime;

    /** The response. */
    private Response response;

    /** The total count. */
    private int totalCount;

    /** The version. */
    protected String version;

    /**
     * Instantiates a new dpm package validating info.
     */
    public PackageValidatingInfo() {
    }

    /**
     * Instantiates a new dpm package validating info.
     *
     * @param callerId the caller id
     * @param version the version
     * @param response the response
     */
    public PackageValidatingInfo(final String callerId, final String version, final Response response) {
        this.callerId = callerId;
        this.version = version;
        this.response = response;
    }

    /**
     * Adds the error.
     *
     * @param error the error
     */
    public void addError(final String error) {
        this.errors.add(error);
    }

    /**
     * Gets the caller id.
     *
     * @return the caller id
     */
    public String getCallerId() {
        return this.callerId;
    }

    /**
     * Gets the error count.
     *
     * @return the error count
     */
    public int getErrorCount() {
        return this.errorCount;
    }

    /**
     * Gets the errors.
     *
     * @return the errors
     */
    public List<String> getErrors() {
        return this.errors;
    }

    /**
     * Gets the package id.
     *
     * @return the package id
     */
    public String getPackageId() {
        return this.packageId;
    }

    /**
     * Gets the received time.
     *
     * @return the received time
     */
    public long getReceivedTime() {
        return this.receivedTime;
    }

    /**
     * Gets the response.
     *
     * @return the response
     */
    public Response getResponse() {
        return this.response;
    }

    /**
     * Gets the total count.
     *
     * @return the total count
     */
    public int getTotalCount() {
        return this.totalCount;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public String getVersion() {
        return this.version;
    }

    /**
     * Sets the caller id.
     *
     * @param callerId the new caller id
     */
    public void setCallerId(final String callerId) {
        this.callerId = callerId;
    }

    /**
     * Sets the error count.
     *
     * @param errorCount the new error count
     */
    public void setErrorCount(final int errorCount) {
        this.errorCount = errorCount;
    }

    /**
     * Sets the package id.
     *
     * @param packageId the new package id
     */
    public void setPackageId(final String packageId) {
        this.packageId = packageId;
    }

    /**
     * Sets the received time.
     *
     * @param receivedTime the new received time
     */
    public void setReceivedTime(final long receivedTime) {
        this.receivedTime = receivedTime;
    }

    /**
     * Sets the response.
     *
     * @param response the new response
     */
    public void setResponse(final Response response) {
        this.response = response;
    }

    /**
     * Sets the total count.
     *
     * @param totalCount the new total count
     */
    public void setTotalCount(final int totalCount) {
        this.totalCount = totalCount;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(final String version) {
        this.version = version;
    }
}
