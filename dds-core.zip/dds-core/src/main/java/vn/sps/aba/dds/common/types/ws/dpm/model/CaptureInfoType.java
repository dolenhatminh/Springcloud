
package vn.sps.aba.dds.common.types.ws.dpm.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for CaptureInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CaptureInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CaptureResultCode" type="{Ch.Post.PL.DisCo.ReceiverInfoService}CaptureResultCodeType"/>
 *         &lt;element name="CoderId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CodingStation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CodingTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CaptureInfoType", propOrder = {
    "captureResultCode",
    "coderId",
    "codingStation",
    "codingTimestamp"
})
public class CaptureInfoType {

    @XmlElement(name = "CaptureResultCode", required = true)
    @XmlSchemaType(name = "string")
    protected CaptureResultCodeType captureResultCode;
    @XmlElement(name = "CoderId", required = true, nillable = true)
    protected String coderId;
    @XmlElement(name = "CodingStation", required = true, nillable = true)
    protected String codingStation;
    @XmlElement(name = "CodingTimestamp", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar codingTimestamp;

    /**
     * Gets the value of the captureResultCode property.
     * 
     * @return
     *     possible object is
     *     {@link CaptureResultCodeType }
     *     
     */
    public CaptureResultCodeType getCaptureResultCode() {
        return captureResultCode;
    }

    /**
     * Sets the value of the captureResultCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link CaptureResultCodeType }
     *     
     */
    public void setCaptureResultCode(CaptureResultCodeType value) {
        this.captureResultCode = value;
    }

    /**
     * Gets the value of the coderId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoderId() {
        return coderId;
    }

    /**
     * Sets the value of the coderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoderId(String value) {
        this.coderId = value;
    }

    /**
     * Gets the value of the codingStation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodingStation() {
        return codingStation;
    }

    /**
     * Sets the value of the codingStation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodingStation(String value) {
        this.codingStation = value;
    }

    /**
     * Gets the value of the codingTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCodingTimestamp() {
        return codingTimestamp;
    }

    /**
     * Sets the value of the codingTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCodingTimestamp(XMLGregorianCalendar value) {
        this.codingTimestamp = value;
    }

}
