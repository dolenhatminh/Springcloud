/*
 * Class: BarcodeScheduledSender
 *
 * Created on Oct 12, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.sender.receiver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.scheduler.DdsScheduler;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.logging.report.ReceiverInfoReport;
import vn.sps.aba.dds.service.padasa.matchmakerdaten.IMatchMakerDatenService;

/**
 * The Class MatchmakerScheduledSender.
 */
@Component("MatchmakerScheduledSender")
@Configuration
@ConfigurationProperties("schedule.resend.padasa.matchmaker")
public class MatchmakerScheduledSender extends AbstractReceiverInfoSender {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(MatchmakerScheduledSender.class);

    /** The match maker daten service. */
    @Autowired
    private IMatchMakerDatenService matchMakerDatenService;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.AbstractScheduledSender#buildSenderExecutor()
     */
    @Override
    protected void buildSenderExecutor() {
        this.scheduledExecutor = new DdsScheduler() {

            @Override
            public String getName() {
                return "resend-matchmaker-scheduler-";
            }

            @Override
            public ThreadPoolTaskScheduler getScheduler() {
                final ThreadPoolTaskScheduler executor = new ThreadPoolTaskScheduler();
                {
                    final ThreadPoolTaskScheduler scheduler = executor;
                    scheduler.setBeanName(this.getName());
                    scheduler.setThreadNamePrefix(TaskConfiguration.TASK_PREFIX + this.getName());
                    scheduler.setPoolSize(MatchmakerScheduledSender.this.getParallel());
                    scheduler.setRemoveOnCancelPolicy(MatchmakerScheduledSender.this.isRemoveOnCancel());
                    scheduler.initialize();
                    LOG.info(
                        "Create sender thread pool task executor {}. Core pool: {}. Max pool: {}",
                        this.getName(),
                        scheduler.getPoolSize(),
                        scheduler.getScheduledThreadPoolExecutor().getMaximumPoolSize());
                }
                return executor;
            }
        };
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.receiver.AbstractReceiverInfoSender#getDestinationServiceName()
     */
    @Override
    protected String getDestinationServiceName() {
        return "PADASA MatchMaker";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.receiver.AbstractReceiverInfoSender#mergeAndStore(java.lang.String, java.util.Iterator, vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    protected void mergeAndStore(final String key, final ReceiverInfo receiverInfo) {
        try {
            ReceiverInfo ret = this.receiverInfoDao.get(key);
            if (ret != null) {
                ret.setState(receiverInfo.getReceiverState());
                ret.setMatchMakerBegin(receiverInfo.getMatchMakerBegin());
                ret.setMatchMakerEnd(receiverInfo.getMatchMakerEnd());
                ret.setMatchMakerCount(receiverInfo.getMatchMakerCount());
            }
            else {
                ret = receiverInfo;
                LOG.info(IndexMaker.index(key), "Cannot find any receiver match with key");
            }
            this.receiverInfoDao.store(key, ret);
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(receiverInfo), "There is error when merge and store receiver into database.", e);
        }
    }

    /**
     * {@inheritDoc}
     * NOTE: SINCE ABA-89 HAS NOT USED ENUM: ReceiverState.VERIFIED
     * @see vn.sps.aba.dds.scheduled.sender.receiver.AbstractReceiverInfoSender#needToSent(java.lang.String, vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    protected boolean needToSent(final String key, final ReceiverInfo receiverInfo) {
        return (ReceiverState.VAM_PADASA_READY_NOT_MATCHING == receiverInfo.getReceiverState()) || (ReceiverState.VAM_PADASA_READY == receiverInfo.getReceiverState()) ||
        		(ReceiverState.VAM_SENT == receiverInfo.getReceiverState()) || (ReceiverState.VAM_SENT_NOT_MATCHING == receiverInfo.getReceiverState())
        		|| (ReceiverState.VERIFIED == receiverInfo.getReceiverState());
    }

    /**
     * {@inheritDoc}
     * NOTE: reference state of Parcel that define in handleItem(final ReceiverInfo receiverInfo, final boolean isRetry) of Receiver2VamSendingHandler class.
     * @see vn.sps.aba.dds.scheduled.sender.receiver.AbstractReceiverInfoSender#resend(java.lang.String, vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    protected boolean resend(final String key, final ReceiverInfo receiverInfo) {
        try {
            if (MatchmakerScheduledSender.this.matchMakerDatenService.transferToMatchMaker(receiverInfo)) {

                switch (receiverInfo.getReceiverState()) {
                /*Case VAM_PADASA_READY_NOT_MATCHING[EXCEPT_Rule_Ampkey_Name]: using for has NOT sent parcel to both VAM and PADASA successfully*/
				case VAM_PADASA_READY_NOT_MATCHING:
					receiverInfo.setState(ReceiverState.PADASA_SENT_NOT_MATCHING);
					break;
				/*Case VAM_PADASA_READY[Rule_Ampkey_Name]: using for has NOT sent parcel to both VAM and PADASA successfully*/
                case VAM_PADASA_READY:
                    receiverInfo.setState(ReceiverState.PADASA_SENT);
                    break;
                /*Case VAM_SENT_NOT_MATCHING[EXCEPT_Rule_Ampkey_Name]: using for has NOT sent parcel to PADASA successfully*/
                case VAM_SENT_NOT_MATCHING:
                    receiverInfo.setState(ReceiverState.VAM_PADASA_SENT_NOT_MATCHING);
                    LOG.info(IndexMaker.indexes(new ReceiverInfoReport(receiverInfo), "receiverInfoReport"), "Insert logs receiver_info");
                    break;
                 /*Case VAM_SENT[Rule_Ampkey_Name]: using for has NOT sent parcel to PADASA successfully*/
                case VAM_SENT:
                    receiverInfo.setState(ReceiverState.VAM_PADASA_SENT);
                    LOG.info(IndexMaker.indexes(new ReceiverInfoReport(receiverInfo), "receiverInfoReport"), "Insert logs receiver_info");
                    break;
                /* NOT USE */
                case VERIFIED:
                    receiverInfo.setState(ReceiverState.PADASA_SENT);
                    break;
                default:
                    break;
                }
                LOG.info(IndexMaker.index(receiverInfo), "Forwarded receiver info to PADASA MatchMaker service station successfully");
                return true;
            }
            else {
                LOG.info(IndexMaker.index(receiverInfo), "Failed to forward ReceiverInfo to PADASA MatchMaker service !");
            }
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(receiverInfo), "There is error when re-send PADASA MatchMaker.", e);
        }
        return false;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#taskName()
     */
    @Override
    public String taskName() {
        return "padasa-matchmaker-scheduled-sender";
    }

}
