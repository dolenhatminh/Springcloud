/*
 * Class: Barcode
 *
 * Created on May 19, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.parcel;

import java.io.Serializable;

/**
 * The Class Barcode.
 */
public class Barcode implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -6583265540448410906L;

    /** The boundary. */
    private Boundary boundary;

    /** The code. */
    private String code;

    /** The edges. */
    private String edges;

    /** The kind. */
    private int kind;

    /** The type. */
    private String type;

    /**
     * Instantiates a new barcode.
     */
    public Barcode() {
    }

    /**
     * Constructs a new <tt>Barcode</tt>.
     *
     * @param barcode
     *            the <tt>Barcode</tt> object sent/received via SOAP web service
     */
    public Barcode(final vn.sps.aba.dds.common.types.ws.pds.parcel.model.Barcode barcode) {
        this.code = barcode.getCode();
        this.edges = barcode.getEdges();
        this.type = barcode.getType();

        this.boundary = new Boundary(barcode);
    }

    /**
     * Gets the boundary.
     *
     * @return Returns the boundary.
     */
    public Boundary getBoundary() {
        return this.boundary;
    }

    /**
     * Gets the code.
     *
     * @return Returns the code.
     */
    public String getCode() {
        return this.code;
    }

    /**
     * Gets the edges.
     *
     * @return Returns the edges.
     */
    public String getEdges() {
        return this.edges;
    }

    /**
     * Gets the kind.
     *
     * @return the kind
     */
    public int getKind() {
        return this.kind;
    }

    /**
     * Gets the type.
     *
     * @return Returns the type.
     */
    public String getType() {
        return this.type;
    }

    /**
     * Sets the boundary.
     *
     * @param boundary
     *            The boundary to set.
     */
    public void setBoundary(final Boundary boundary) {
        this.boundary = boundary;
    }

    /**
     * Sets the code.
     *
     * @param code
     *            The code to set.
     */
    public void setCode(final String code) {
        this.code = code;
    }

    /**
     * Sets the edges.
     *
     * @param edges
     *            The edges to set.
     */
    public void setEdges(final String edges) {
        this.edges = edges;
    }

    /**
     * Sets the kind.
     *
     * @param kind the new kind
     */
    public void setKind(final int kind) {
        this.kind = kind;
    }

    /**
     * Sets the type.
     *
     * @param type
     *            The type to set.
     */
    public void setType(final String type) {
        this.type = type;
    }
}
