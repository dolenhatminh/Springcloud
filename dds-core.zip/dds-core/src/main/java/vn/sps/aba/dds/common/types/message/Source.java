/*
  * Class: Source
 *
 * Created on Jun 25, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.message;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * The Class Source.
 */
@XStreamAlias("source")
public class Source {

    /** The description. */
    @XStreamAlias("description")
    @XStreamAsAttribute
    private String description;

    /** The id. */
    @XStreamAlias("key")
    @XStreamAsAttribute
    private String key;

    /**
     * Constructs a new <tt>Source</tt>.
     */
    Source() {
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public String getKey() {
        return this.key;
    }

    /**
     * Sets the description.
     *
     * @param description the description to set
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * Sets the id.
     *
     * @param key the id to set
     */
    public void setKey(final String key) {
        this.key = key;
    }

}
