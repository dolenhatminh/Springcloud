/*
 * Class: IExceptionHandler
 *
 * Created on Nov 16, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.listener;

import java.util.List;

/**
 * The Interface IMightBeErrorCollector.
 */
public interface IMightBeErrorCollector {

    /**
     * Checks for key.
     *
     * @param key the key
     * @return true, if successful
     */
    boolean hasKey(String key);

    /**
     * Iterator.
     *
     * @return the iterator
     */
    List<String> listErrorItem();
}
