
package vn.sps.aba.dds.common.types.ws.dpmb;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the vn.sps.aba.dds.service.dpmb package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _EDienstleistung_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "eDienstleistung");
    private final static QName _CaptureInfo_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "CaptureInfo");
    private final static QName _ParcelData_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "ParcelData");
    private final static QName _AdresseErfassung_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "AdresseErfassung");
    private final static QName _ArrayOfProduktZusatzLeistung_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "ArrayOfProduktZusatzLeistung");
    private final static QName _EPersType_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "ePersType");
    private final static QName _ProduktZusatzLeistung_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "ProduktZusatzLeistung");
    private final static QName _EPersStatus_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "ePersStatus");
    private final static QName _AddressFields_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "AddressFields");
    private final static QName _CaptureResultOut_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "CaptureResultOut");
    private final static QName _CaptureResultRecord_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "CaptureResultRecord");
    private final static QName _VolleAdresse_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "VolleAdresse");
    private final static QName _ECaptureResultCode_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "eCaptureResultCode");
    private final static QName _EAmpStatus_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "eAmpStatus");
    private final static QName _ECaptureAddressType_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "eCaptureAddressType");
    private final static QName _CaptureResultIn_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "CaptureResultIn");
    private final static QName _Timestamps_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Timestamps");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: vn.sps.aba.dds.service.dpmb
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CaptureResultIn }
     * 
     */
    public CaptureResultIn createCaptureResultIn() {
        return new CaptureResultIn();
    }

    /**
     * Create an instance of {@link CaptureResultResponse }
     * 
     */
    public CaptureResultResponse createCaptureResultResponse() {
        return new CaptureResultResponse();
    }

    /**
     * Create an instance of {@link CaptureResultOut }
     * 
     */
    public CaptureResultOut createCaptureResultOut() {
        return new CaptureResultOut();
    }

    /**
     * Create an instance of {@link CaptureResult }
     * 
     */
    public CaptureResult createCaptureResult() {
        return new CaptureResult();
    }

    /**
     * Create an instance of {@link ProduktZusatzLeistung }
     * 
     */
    public ProduktZusatzLeistung createProduktZusatzLeistung() {
        return new ProduktZusatzLeistung();
    }

    /**
     * Create an instance of {@link AdresseErfassung }
     * 
     */
    public AdresseErfassung createAdresseErfassung() {
        return new AdresseErfassung();
    }

    /**
     * Create an instance of {@link ArrayOfProduktZusatzLeistung }
     * 
     */
    public ArrayOfProduktZusatzLeistung createArrayOfProduktZusatzLeistung() {
        return new ArrayOfProduktZusatzLeistung();
    }

    /**
     * Create an instance of {@link CaptureInfo }
     * 
     */
    public CaptureInfo createCaptureInfo() {
        return new CaptureInfo();
    }

    /**
     * Create an instance of {@link ParcelData }
     * 
     */
    public ParcelData createParcelData() {
        return new ParcelData();
    }

    /**
     * Create an instance of {@link Timestamps }
     * 
     */
    public Timestamps createTimestamps() {
        return new Timestamps();
    }

    /**
     * Create an instance of {@link VolleAdresse }
     * 
     */
    public VolleAdresse createVolleAdresse() {
        return new VolleAdresse();
    }

    /**
     * Create an instance of {@link AddressFields }
     * 
     */
    public AddressFields createAddressFields() {
        return new AddressFields();
    }

    /**
     * Create an instance of {@link CaptureResultRecord }
     * 
     */
    public CaptureResultRecord createCaptureResultRecord() {
        return new CaptureResultRecord();
    }

    /**
     * Create an instance of {@link CaptureResultIn.CaptureResultRecords }
     * 
     */
    public CaptureResultIn.CaptureResultRecords createCaptureResultInCaptureResultRecords() {
        return new CaptureResultIn.CaptureResultRecords();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EDienstleistung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "eDienstleistung")
    public JAXBElement<EDienstleistung> createEDienstleistung(EDienstleistung value) {
        return new JAXBElement<EDienstleistung>(_EDienstleistung_QNAME, EDienstleistung.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "CaptureInfo")
    public JAXBElement<CaptureInfo> createCaptureInfo(CaptureInfo value) {
        return new JAXBElement<CaptureInfo>(_CaptureInfo_QNAME, CaptureInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParcelData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "ParcelData")
    public JAXBElement<ParcelData> createParcelData(ParcelData value) {
        return new JAXBElement<ParcelData>(_ParcelData_QNAME, ParcelData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdresseErfassung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "AdresseErfassung")
    public JAXBElement<AdresseErfassung> createAdresseErfassung(AdresseErfassung value) {
        return new JAXBElement<AdresseErfassung>(_AdresseErfassung_QNAME, AdresseErfassung.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfProduktZusatzLeistung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "ArrayOfProduktZusatzLeistung")
    public JAXBElement<ArrayOfProduktZusatzLeistung> createArrayOfProduktZusatzLeistung(ArrayOfProduktZusatzLeistung value) {
        return new JAXBElement<ArrayOfProduktZusatzLeistung>(_ArrayOfProduktZusatzLeistung_QNAME, ArrayOfProduktZusatzLeistung.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EPersType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "ePersType")
    public JAXBElement<EPersType> createEPersType(EPersType value) {
        return new JAXBElement<EPersType>(_EPersType_QNAME, EPersType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProduktZusatzLeistung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "ProduktZusatzLeistung")
    public JAXBElement<ProduktZusatzLeistung> createProduktZusatzLeistung(ProduktZusatzLeistung value) {
        return new JAXBElement<ProduktZusatzLeistung>(_ProduktZusatzLeistung_QNAME, ProduktZusatzLeistung.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EPersStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "ePersStatus")
    public JAXBElement<EPersStatus> createEPersStatus(EPersStatus value) {
        return new JAXBElement<EPersStatus>(_EPersStatus_QNAME, EPersStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressFields }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "AddressFields")
    public JAXBElement<AddressFields> createAddressFields(AddressFields value) {
        return new JAXBElement<AddressFields>(_AddressFields_QNAME, AddressFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureResultOut }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "CaptureResultOut")
    public JAXBElement<CaptureResultOut> createCaptureResultOut(CaptureResultOut value) {
        return new JAXBElement<CaptureResultOut>(_CaptureResultOut_QNAME, CaptureResultOut.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureResultRecord }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "CaptureResultRecord")
    public JAXBElement<CaptureResultRecord> createCaptureResultRecord(CaptureResultRecord value) {
        return new JAXBElement<CaptureResultRecord>(_CaptureResultRecord_QNAME, CaptureResultRecord.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VolleAdresse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "VolleAdresse")
    public JAXBElement<VolleAdresse> createVolleAdresse(VolleAdresse value) {
        return new JAXBElement<VolleAdresse>(_VolleAdresse_QNAME, VolleAdresse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ECaptureResultCode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "eCaptureResultCode")
    public JAXBElement<ECaptureResultCode> createECaptureResultCode(ECaptureResultCode value) {
        return new JAXBElement<ECaptureResultCode>(_ECaptureResultCode_QNAME, ECaptureResultCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EAmpStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "eAmpStatus")
    public JAXBElement<EAmpStatus> createEAmpStatus(EAmpStatus value) {
        return new JAXBElement<EAmpStatus>(_EAmpStatus_QNAME, EAmpStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "eCaptureAddressType")
    public JAXBElement<String> createECaptureAddressType(String value) {
        return new JAXBElement<String>(_ECaptureAddressType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureResultIn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "CaptureResultIn")
    public JAXBElement<CaptureResultIn> createCaptureResultIn(CaptureResultIn value) {
        return new JAXBElement<CaptureResultIn>(_CaptureResultIn_QNAME, CaptureResultIn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Timestamps }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Timestamps")
    public JAXBElement<Timestamps> createTimestamps(Timestamps value) {
        return new JAXBElement<Timestamps>(_Timestamps_QNAME, Timestamps.class, null, value);
    }

}
