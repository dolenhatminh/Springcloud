/*
 * Class: Constraint
 *
 * Created on Jun 21, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.filterrule;

import javax.activation.UnsupportedDataTypeException;

import vn.sps.aba.dds.common.types.exception.UnsupportedAttributeException;
import vn.sps.aba.dds.common.types.filter.FilterAttribute;
import vn.sps.aba.dds.common.types.filter.FilterModel;
import vn.sps.aba.dds.common.types.filter.FilterOperator;

/**
 * The Class Constraint.
 */
public class Constraint {

    /** The name. */
    private FilterAttribute attribute;

    /** The model. */
    private FilterModel model;

    /** The operation. */
    private FilterOperator operator;

    /** The pattern. */
    private String pattern;

    /** The title. */
    private String title;

    /**
     * Gets the attribute.
     *
     * @return Returns the attribute.
     */
    public FilterAttribute getAttribute() {
        return this.attribute;
    }

    /**
     * Gets the model.
     *
     * @return Returns the model.
     */
    public FilterModel getModel() {
        return this.model;
    }

    /**
     * Gets the operation.
     *
     * @return Returns the operation.
     */
    public FilterOperator getOperator() {
        return this.operator;
    }

    /**
     * Gets the pattern.
     *
     * @return Returns the pattern.
     */
    public String getPattern() {
        return this.pattern;
    }

    /**
     * Gets the title.
     *
     * @return Returns the title.
     */
    public String getTitle() {
        return this.title;
    }

    /**
     * Sets the attribute.
     *
     * @param attribute
     *            the new attribute
     * @throws UnsupportedAttributeException
     *             the unsupported attribute exception
     */
    public void setAttribute(final String attribute) throws UnsupportedAttributeException {
        this.attribute = FilterAttribute.forName(attribute);
    }

    /**
     * Sets the model.
     *
     * @param model
     *            The model to set.
     * @throws UnsupportedDataTypeException
     *             the unsupported data type exception
     */
    public void setModel(final String model) throws UnsupportedDataTypeException {
        this.model = FilterModel.forName(model);
    }

    /**
     * Sets the operator.
     *
     * @param operator
     *            the new operator
     * @throws UnsupportedAttributeException
     *             the unsupported attribute exception
     */
    public void setOperator(final String operator) throws UnsupportedAttributeException {
        this.operator = FilterOperator.forName(operator);
    }

    /**
     * Sets the pattern.
     *
     * @param pattern
     *            The pattern to set.
     */
    public void setPattern(final String pattern) {
        this.pattern = pattern;
    }

    /**
     * Sets the title.
     *
     * @param title
     *            The title to set.
     */
    public void setTitle(final String title) {
        this.title = title;
    }

    /**
     * {@inheritDoc}
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return String.format(
            "Attribute: %s.%s - Operator: %s - Pattern: %s",
            this.getModel().getName(),
            this.getAttribute().getName(),
            this.getOperator().getName(),
            this.getPattern());
    }

}
