/*
 * Class: WorkspaceController
 *
 * Created on Oct 26, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.jmx;

import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

/**
 * The Interface WorkspaceController.
 */
@ManagedResource
public interface WorkspaceInfo {
    
    /**
     * Clean finished task from watchers.
     *
     * @return the string
     */
    @ManagedOperation
    String cleanFinishedTaskFromWatchers();

    /**
     * Clean up.
     *
     * @return the string
     */
    @ManagedOperation
    String cleanUp();

    /**
     * Scan directory.
     *
     * @param date the date
     * @return the string
     */
    @ManagedOperation
    String scanDirectory(String dateString);
}
