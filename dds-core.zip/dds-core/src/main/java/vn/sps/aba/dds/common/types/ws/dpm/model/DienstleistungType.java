
package vn.sps.aba.dds.common.types.ws.dpm.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DienstleistungType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DienstleistungType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Pickpost"/>
 *     &lt;enumeration value="MyPost24"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DienstleistungType")
@XmlEnum
public enum DienstleistungType {

    @XmlEnumValue("Pickpost")
    PICKPOST("Pickpost"),
    @XmlEnumValue("MyPost24")
    MY_POST_24("MyPost24");
    private final String value;

    DienstleistungType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DienstleistungType fromValue(String v) {
        for (DienstleistungType c: DienstleistungType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
