/*
 * Class: VamConfiguration
 *
 * Created on Jun 6, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.DDSConstant.Namespace;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.ObjectFactory;
import vn.sps.aba.dds.config.reponsecode.ICommonResponseCode;

/**
 * The Class VamConfiguration.
 */
@Configuration("CaptureResultServiceConfiguration")
@ConfigurationProperties(prefix = "ws.vam.captureresult")
@Profile(value = { Profiles.RECEIVER, Profiles.DPM, Profiles.DPMB, Profiles.DPMS })
public class CaptureResultServiceConfiguration extends AbstractSoapWsConfiguration implements ICommonResponseCode {
    /**
     * The Enum ResponseCode.
     */
    private enum ResponseCode {

        /**
         * The Failed to store data.
         */
        FailedToStoreData,
        /**
         * The Invalid data.
         */
        InvalidData,
        /**
         * The Service available.
         */
        ServiceAvailable,
        /**
         * The Successful.
         */
        Successful,
        /**
         * The Unexpected error.
         */
        UnexpectedError
    }

    /**
     * The Constant SOUCE.
     */
    private static final String SOUCE = DDSConstant.Source.E128;

    /** The caller id. */
    private String callerId;

    /**
     * The destinations.
     */
    private Map<String, String> destinationUrls = new HashMap<>();

    /** The dpm station ids. */
    private String[] dpmStationIds;

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#failedToStoreData()
     */
    @Override
    public Response failedToStoreData() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.FailedToStoreData.name());
    }

    /**
     * Gets the caller id.
     *
     * @return the caller id
     */
    public String getCallerId() {
        return this.callerId;
    }

    /**
     * Gets the destination urls.
     *
     * @return the destination urls
     */
    public Map<String, String> getDestinationUrls() {
        return this.destinationUrls;
    }

    /**
     * Gets the dpm station ids.
     *
     * @return the dpm station ids
     */
    public String[] getDpmStationIds() {
        return this.dpmStationIds;
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getNamespaceURI()
     */
    @Override
    public String getNamespaceURI() {
        return Namespace.E128_NAMESPACE;
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getObjectFactory()
     */
    @Override
    public ObjectFactory getObjectFactory() {
        return (ObjectFactory) super.getObjectFactory();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getServiceName()
     */
    @Override
    public String getServiceName() {
        return "CaptureResult";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getServiceUrls()
     */
    @Override
    public String getServiceUrls() {
        final Set<String> urls = new HashSet<>();

        for (final String url : this.destinationUrls.keySet()) {
            urls.add(String.format("%s:%s", url, this.destinationUrls.get(url)));
        }
        return String.join(";", urls);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#initialize()
     */
    @Override
    @PostConstruct
    public void initialize() throws Exception {
        super.initialize();
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#invalidData()
     */
    @Override
    public Response invalidData() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.InvalidData.name());
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#serviceAvailable()
     */
    @Override
    public Response serviceAvailable() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.ServiceAvailable.name());
    }

    /**
     * Sets the caller id.
     *
     * @param callerId the new caller id
     */
    public void setCallerId(final String callerId) {
        this.callerId = callerId;
    }

    /**
     * Sets the destination urls.
     *
     * @param destinationUrls the destination urls
     */
    public void setDestinationUrls(final Map<String, String> destinationUrls) {
        this.destinationUrls = destinationUrls;
    }

    /**
     * Sets the dpm station ids.
     *
     * @param dpmStationIds the new dpm station ids
     */
    public void setDpmStationIds(final String[] dpmStationIds) {
        this.dpmStationIds = dpmStationIds;
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#successful()
     */
    @Override
    public Response successful() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.Successful.name());
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#unexpectedError()
     */
    @Override
    public Response unexpectedError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.UnexpectedError.name());
    }
}
