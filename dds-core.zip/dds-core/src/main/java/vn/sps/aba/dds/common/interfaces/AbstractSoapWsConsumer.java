/*
 * Class: AbstractSoapWsTemplate
 *
 * Created on Jul 1, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.interfaces;

import java.util.Map;

import javax.xml.ws.BindingProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration;
import vn.sps.aba.dds.logging.IndexMaker;

/**
 * The Class AbstractSoapWsTemplate.
 *
 * @param <T>            the generic type
 * @param <S> the generic type
 * @param <R> the generic type
 */
public abstract class AbstractSoapWsConsumer<T, S, R> extends WebServiceGatewaySupport {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(AbstractSoapWsConsumer.class);

    /** The configuration. */
    protected AbstractSoapWsConfiguration configuration;

    /**
     * Check response.
     *
     * @param entry the entry
     * @param ret the ret
     * @return true, if successful
     */
    protected boolean checkResponse(final IdentifiedEntry entry, final R ret) {
        return false;
    }

    /**
     * Check retry time.
     *
     * @param entry the entry
     * @param retryTime the retry time
     * @param maxRetryTimes the max retry times
     * @param retryIntervalTime the retry interval time
     */
    protected void checkRetryTime(final IdentifiedEntry entry, final int retryTime, final int maxRetryTimes, final long retryIntervalTime) {
        try {
            if ((retryIntervalTime > 0) && (maxRetryTimes > retryTime)) {
                LOG.info(IndexMaker.index(entry), "Retry after {} miliseconds", retryIntervalTime);
                Thread.sleep(retryIntervalTime);
            }
        }
        catch (final Exception e) {
            LOG.debug(entry.getKey(), e.getMessage(), e);
        }

    }

    /**
     * Gets the clients.
     *
     * @return the clients
     */
    protected Object[] getClients() {
        return new Object[0];
    }

    /**
     * Gets the configuration.
     *
     * @return Returns the configuration.
     */
    protected AbstractSoapWsConfiguration getConfiguration() {
        return this.configuration;
    }

    /**
     * Gets the configuration.
     *
     * @param <C> the generic type
     * @param clazz the clazz
     * @return the configuration
     */
    @SuppressWarnings("unchecked")
    protected <C> C getConfiguration(final Class<C> clazz) {
        return (C) this.configuration;
    }

    /**
     * Gets the payload name.
     *
     * @return the payload name
     */
    protected String getServiceName() {
        return "payload";
    }

    /**
     * Handle.
     *
     * @param entry the entry
     * @param payload the payload
     * @param client the client
     * @param url the url
     * @return the r
     */
    private R handle(final IdentifiedEntry entry, final S payload, final T client, final String url) {
        try {
            return this.transfer(entry, payload, client);
        }
        catch (final Exception e) {
            // Don't throw any exception out
            LOG.error(IndexMaker.index(entry), String.format("Error while transfering %s to %s", this.getServiceName(), url), e);
        }
        return null;
    }

    /**
     * Initialize gateway.
     *
     * @throws Exception
     *             the exception
     */
    @Override
    public void initGateway() throws Exception {
        final Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath(this.configuration.getContextPath());
        this.setMarshaller(marshaller);
        this.setUnmarshaller(marshaller);

        final Object[] services = this.getClients();
        for (final Object service : services) {
            final BindingProvider bp = (BindingProvider) service;
            final Map<String, Object> requestContext = bp.getRequestContext();
            requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, this.getConfiguration().getServiceUrl());
            requestContext.put(DDSConstant.WsProperties.CONNECT_TIMEOUT, this.getConfiguration().getConnectTimeout());
            requestContext.put(DDSConstant.WsProperties.REQUEST_TIMEOUT, this.getConfiguration().getReadTimeout());

            LOG.info(StringUtil.printWebServiceInfo(configuration));
        }
    }

    /**
     * Sets the configuration.
     *
     * @param configuration the new configuration
     */
    public abstract void setConfiguration(AbstractSoapWsConfiguration configuration);

    /**
     * Transfer.
     *
     * @param entry the entry
     * @param payload the payload
     * @param client the client
     * @return true, if successful
     * @throws Exception the exception
     */
    protected abstract R transfer(final IdentifiedEntry entry, final S payload, T client) throws Exception;

    /**
     * Send canscade.
     *
     * @param entry the entry
     * @param payload            the payload
     * @param client the client
     * @param url the url
     * @return the response object if the transfer is successful or null if failed.
     */
    protected R transferCascade(final IdentifiedEntry entry, final S payload, final T client, final String url) {

        R ret = null;
        final int maxRetryTimes = this.configuration.getRetryTime();
        int i = -1;

        while (i < this.configuration.getRetryTime()) {
            ret = this.handle(entry, payload, client, url);
            if (!this.checkResponse(entry, ret)) {
                i++;
                ret = null;
                this.checkRetryTime(entry, i, maxRetryTimes, this.configuration.getRetryIntervalTime());
            }
            else {
                break;
            }
        }

        return ret;
    }
}
