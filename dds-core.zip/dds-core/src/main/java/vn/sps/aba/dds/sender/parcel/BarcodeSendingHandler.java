/*
 * Class: Parcel2VamSendingHandler
 *
 * Created on Oct 19, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.sender.parcel;

import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.Enumeration.DmcState;
import vn.sps.aba.dds.common.ifa.TaskWatcher;
import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.sender.BarcodeSendingExecutor;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.scheduled.sender.IScheduledSender;
import vn.sps.aba.dds.scheduled.sender.parcel.BarcodeScheduledSender;
import vn.sps.aba.dds.sender.parcel.interfaces.IBarcodeSender;
import vn.sps.aba.dds.service.padasa.vgparcelbcdataresult.IVgParcelBcDataResultService;

/**
 * The Class Parcel2VamSendingHandler.
 */
@Component("BarcodeSendingHandler")
public class BarcodeSendingHandler extends AbstractParcelSender implements IBarcodeSender {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(BarcodeSendingHandler.class);

    /** The dmc receiving taskwatcher. */
    @Autowired
    @Qualifier("DmcReceiver")
    private TaskWatcher dmcReceiverWatcher;

    /** The executor. */
    @Autowired
    private BarcodeSendingExecutor executor;

    /** The schedule sender. */
    @Autowired
    private BarcodeScheduledSender scheduleSender;

    /** The capture result service. */
    @Autowired
    private IVgParcelBcDataResultService service;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected TaskConfiguration getExecutor() {
        return this.executor;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.sender.parcel.AbstractParcelSender#getScheduledSender()
     */
    @Override
    protected IScheduledSender<ParcelInfo> getScheduledSender() {
        return this.scheduleSender;
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.sender.IExternalSender#getSenderName()
     */
    @Override
    public String getSenderName() {
        return "Barcode sender";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.sender.IExternalSender#handleItem(java.lang.Object)
     */
    @Override
    public Runnable handleItem(final ParcelInfo parcelInfo, final boolean isRetry) {
        return this.handleItem(parcelInfo, parcelInfo.getDmcCode(), isRetry);
    }

    /**
     * Handle item.
     *
     * @param parcelInfo the parcel info
     * @param dmcCode the dmc code
     * @param isRetry the is retry
     * @return the runnable
     */
    private Runnable handleItem(final ParcelInfo parcelInfo, final DMCResponse dmcCode, final boolean isRetry) {
        return () -> {
            String key = parcelInfo.getKey();
            try {
                LOG.info(IndexMaker.index(parcelInfo), "Transfer parcel to PADASA BarcodeData service");
                // Note: this avoids the parcel dmcState is changed against from PADASA_BARCODE_SENT --> PADASA_BARCODE_READY
                DmcState dmcState = parcelInfo.getDmcState() != DmcState.PADASA_BARCODE_SENT ? DmcState.PADASA_BARCODE_READY : parcelInfo.getDmcState();
                if (this.service.transferToBarcodeDataService(parcelInfo, dmcCode)) {
                    dmcState = DmcState.PADASA_BARCODE_SENT;
                }
                final Future<?> task = this.dmcReceiverWatcher.unWatch(key);
                if (task != null) {
                    LOG.info(IndexMaker.index(parcelInfo), "Wait for dmc receiver to finish");
                    task.get();
                }
                parcelInfo.setDmcState(dmcState);
                if (DmcState.PADASA_BARCODE_SENT == dmcState) {
                    LOG.info(IndexMaker.index(parcelInfo), "Transfer parcel to PADASA BarcodeData service successfully");
                }
                else {
                    LOG.info(IndexMaker.index(parcelInfo), "Failed to forward parcel info to PADASA BarcodeData service!");
                    this.scheduleSender.queue(parcelInfo);
                    LOG.info(IndexMaker.index(parcelInfo), "Parcel info was queued up to re-send to PADASA BarcodeData service");
                }
                this.mergeAndStore(key, parcelInfo);
            }
            catch (final Exception e) {
                LOG.debug(IndexMaker.index(parcelInfo), "There is error when transfer parcel to PADASA BarcodeData service", e);
            }
            finally {
                BarcodeSendingHandler.this.watcher.unWatch(key);
                LOG.info(IndexMaker.index(parcelInfo), "Transfer parcel to PADASA BarcodeData service done");
            }
        };
    }

    /**
     * Merge and store.
     *
     * @param key the key
     * @param parcelInfo the parcel info
     */
    protected void mergeAndStore(final String key, final ParcelInfo parcelInfo) {
        try {
            ParcelInfo ret = this.parcelInfoDao.get(key);
            if (ret != null) {
                ret.setDmcState(parcelInfo.getDmcState());
                ret.setBarcodeBegin(parcelInfo.getBarcodeBegin());
                ret.setBarcodeEnd(parcelInfo.getBarcodeEnd());
                ret.setBarcodeCount(parcelInfo.getBarcodeCount());
            }
            else {
                LOG.info(IndexMaker.index(key), "Cannot find any parcel match with key");
                ret = parcelInfo;
            }
            this.parcelInfoDao.store(key, ret);
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when merge and store parcel into database.", e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.sender.parcel.interfaces.IBarcodeSender#submitItem(vn.sps.aba.dds.common.model.parcel.ParcelInfo, vn.sps.aba.dds.common.model.dmc.DMCResponse)
     */
    @Override
    public void submitItem(final ParcelInfo parcelInfo, final DMCResponse dmcData) {
        if (this.watcher.isDone(parcelInfo.getKey())) {
            final Runnable r = this.handleItem(parcelInfo, dmcData, false);
            final Future<?> worker = this.executor.getAsyncExecutor().submit(r);
            this.watcher.watch(parcelInfo.getKey(), worker);
        }
    }
}
