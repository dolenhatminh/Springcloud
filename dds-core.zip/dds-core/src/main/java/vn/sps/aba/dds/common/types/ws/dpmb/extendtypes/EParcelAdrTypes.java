/*
 * Class: EParcelAdrTypes
 *
 * Created on Aug 1, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.ws.dpmb.extendtypes;

public enum EParcelAdrTypes {

    /** The Ausland. */
    Ausland, Firmenadresse, Firmenadresse_MyPost24, Firmenadresse_Pickpost, Firmenadresse_Postfach, Firmenadresse_Postlagernd, MyPost24, Pickpost, Postfach, Postlagernd, Privatadresse, Privatadresse_MyPost24, Privatadresse_Pickpost, Privatadresse_Postfach, Privatadresse_Postlagernd, Unbekannt;

}
