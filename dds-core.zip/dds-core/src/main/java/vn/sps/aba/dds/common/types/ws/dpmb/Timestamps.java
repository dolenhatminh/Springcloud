
package vn.sps.aba.dds.common.types.ws.dpmb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Timestamps complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Timestamps">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DisCoTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="PdsTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="VGTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="VnTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Timestamps", propOrder = {
    "disCoTimestamp",
    "pdsTimestamp",
    "vgTimestamp",
    "vnTimestamp"
})
public class Timestamps {

    @XmlElement(name = "DisCoTimestamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar disCoTimestamp;
    @XmlElement(name = "PdsTimestamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar pdsTimestamp;
    @XmlElement(name = "VGTimestamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar vgTimestamp;
    @XmlElement(name = "VnTimestamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar vnTimestamp;

    /**
     * Gets the value of the disCoTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDisCoTimestamp() {
        return disCoTimestamp;
    }

    /**
     * Sets the value of the disCoTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDisCoTimestamp(XMLGregorianCalendar value) {
        this.disCoTimestamp = value;
    }

    /**
     * Gets the value of the pdsTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPdsTimestamp() {
        return pdsTimestamp;
    }

    /**
     * Sets the value of the pdsTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPdsTimestamp(XMLGregorianCalendar value) {
        this.pdsTimestamp = value;
    }

    /**
     * Gets the value of the vgTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getVGTimestamp() {
        return vgTimestamp;
    }

    /**
     * Sets the value of the vgTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setVGTimestamp(XMLGregorianCalendar value) {
        this.vgTimestamp = value;
    }

    /**
     * Gets the value of the vnTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getVnTimestamp() {
        return vnTimestamp;
    }

    /**
     * Sets the value of the vnTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setVnTimestamp(XMLGregorianCalendar value) {
        this.vnTimestamp = value;
    }

}
