/*
 * Class: AsdpImporter
 *
 * Created on Sep 14, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.importing.impl;

import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.asdp.AsdpPlzz;
import vn.sps.aba.dds.common.model.lookup.AsdpPlz;
import vn.sps.aba.dds.config.cache.CacheAsdpPlzConfiguration;
import vn.sps.aba.dds.config.service.AbstractRestWsConfiguration;
import vn.sps.aba.dds.config.service.AsdpServiceConfiguration;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.repository.cache.interfaces.IAsdpPlzCacheDao;
import vn.sps.aba.dds.repository.importing.IAsdpImporter;
import vn.sps.aba.dds.repository.importing.report.IAsdpImportingReport;
import vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate;

/**
 * The Class AsdpImporter.
 */
@Component
@Configuration
@ConfigurationProperties("lookup.asdp.importing")
public class AsdpImporter extends AbstractRestWsTemplate<AsdpPlz[]> implements IAsdpImporter {

    /**
     * The Class AsdpImportingReport.
     */
    private class AsdpImportingReport implements IAsdpImportingReport {

        /** The number of item. */
        private int numberOfItem;

        /**
         * {@inheritDoc}
         *
         * @see
         * vn.sps.aba.dds.repository.importing.report.IAsdpImportingReport#getNumberOfItem()
         */
        @Override
        public int getNumberOfItem() {
            return this.numberOfItem;
        }

        /**
         * Sets the number of item.
         *
         * @param numberOfItem the new number of item
         */
        public void setNumberOfItem(final int numberOfItem) {
            this.numberOfItem = numberOfItem;
        }

    }

    /**
     * The Class AsdpPlzEntry.
     */
    private class AsdpPlzEntry implements IdentifiedEntry {

        /**
         * {@inheritDoc}
         *
         * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getIdentCode()
         */
        @Override
        public String getIdentCode() {
            return null;
        }

        /**
         * {@inheritDoc}
         *
         * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getKey()
         */
        @Override
        public String getKey() {
            return AsdpPlz.class.getSimpleName();
        }

        /**
         * {@inheritDoc}
         *
         * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getMinorState()
         */
        @Override
        public String getMinorState() {
            return null;
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getReceived()
         */
        @Override
        public long getReceived() {
            return 0;
        }

        /**
         * {@inheritDoc}
         *
         * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getState()
         */
        @Override
        public String getState() {
            return null;
        }

    }

    /**
     * The LOG.
     */
    private static final Logger LOG = LoggerFactory.getLogger(AsdpImporter.class);

    /**
     * The asdp plz cache dao.
     */
    @Autowired
    private IAsdpPlzCacheDao asdpPlzCacheDao;

    /** The cache configuration. */
    @Autowired
    private CacheAsdpPlzConfiguration cacheConfiguration;

    /** The service configuration. */
    @Autowired
    private AsdpServiceConfiguration serviceConfiguration;

    /**
     * The service urls.
     */
    private String[] serviceUrls;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate#getConfiguration()
     */
    @Override
    protected AbstractRestWsConfiguration getConfiguration() {
        return this.serviceConfiguration;
    }

    /**
     * Gets the service urls.
     *
     * @return the service urls
     */
    public String[] getServiceUrls() {
        return this.serviceUrls;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.importing.IAsdpImporter#importData()
     */
    @Override
    public IAsdpImportingReport importData() {

        final AsdpImportingReport report = new AsdpImportingReport();
        String requestUrl = null;
        final AsdpPlzEntry parcelInfo = new AsdpPlzEntry();

        try {
            for (final String url : this.serviceUrls) {
                requestUrl = url;
                final AsdpPlz[] asdpData = this.sendCascade(parcelInfo, null, AsdpPlz[].class, requestUrl);
                if ((asdpData != null) && (asdpData.length > 0)) {
                    final List<AsdpPlz> l = Arrays.asList(asdpData);
                    if (!CollectionUtils.isEmpty(l)) {
                        LOG.info("Remove all existing Asdp Plz");
                        this.asdpPlzCacheDao.clear();
                        l.stream().forEach((asdpPlz) -> {
                            final AsdpPlzz plzz = new AsdpPlzz();
                            {
                                plzz.setLogTyp(asdpPlz.getLogTyp());
                                plzz.setPlzTyp(asdpPlz.getPlzTyp());
                                plzz.setPlzTyp(asdpPlz.getPlzTyp());
                                plzz.setPlz(asdpPlz.getPlz());
                            }
                            this.asdpPlzCacheDao.put(plzz.getPlz(), plzz);
                            report.setNumberOfItem(report.getNumberOfItem() + 1);
                        });
                        break;
                    }
                }
                else {
                    LOG.info("There is no ASDP PLZ downloaded");
                }
            }

        }
        catch (final Exception e) {
            LOG.error("There is error while lookup Asdp data " + requestUrl, e);
        }
        LOG.info(IndexMaker.indexes(report), "Importing asdpplz into cache -size:{}", report.getNumberOfItem());
        return report;
    }

    /**
     * Initialize.
     */
    @PostConstruct
    protected void initialize() {
        if (this.cacheConfiguration.isImportWhileBoot()) {
            if (this.asdpPlzCacheDao.count() <= 0) {
                this.importData();
            }
            else {
                LOG.info("Data of Asdp Plz exists. Don't import it again!");
            }
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate#send(java.lang.String,
     * java.lang.String, java.lang.Object, int, java.lang.Class)
     */
    @Override
    protected AsdpPlz[] send(final IdentifiedEntry entry, final String url, final Object message, final int readTimeOut, final Class<AsdpPlz[]> clazz) {
        try {
            return this.restTemplate.getForObject(url, clazz);
        }
        catch (final Exception e) {
            LOG.warn(IndexMaker.indexes(entry), "There is error when look up ASDP.", e);
        }
        return null;
    }

    /**
     * Sets the service urls.
     *
     * @param serviceUrls the new service urls
     */
    public void setServiceUrls(final String[] serviceUrls) {
        this.serviceUrls = serviceUrls;
    }

}
