/*
 * Class: StringUtil
 *
 * Created on Jun 22, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.util;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.config.service.interfaces.IWsConfiguration;

/**
 * The Class StringUtil.
 */
public final class StringUtil {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(StringUtil.class);

    /**
     * Assert enum.
     *
     * @param values the values
     * @param type the type
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static void assertEnum(final Class type, final String... values) {
        for (final String value : values) {
            Enum.valueOf(type, value);
        }
    }

    /**
     * Builds the tif file name.
     *
     * @param fileName
     *            the file name
     * @return the string
     */
    public static String buildTIFFileName(final String fileName) {
        return fileName + Constant.FILE_EXTENSION_TIF;
    }

    /**
     * Format.
     *
     * @param pattern
     *            the pattern
     * @param args
     *            the args
     * @return the string
     */
    public static String format(final String pattern, final Object... args) {
        return String.format(pattern, args);
    }

    /**
     * Integer2 string.
     *
     * @param value the value
     * @return the string
     */
    public static String integer2String(final Integer value) {
        return value == null ? null : String.valueOf(value);
    }

    /**
     * Less than one.
     *
     * @param value the value
     * @return true, if successful
     */
    public static boolean lessThanOne(final String value) {
        boolean ret = false;

        try {
            if (value != null) {
                final Integer number = Integer.valueOf(value);
                ret = number.intValue() < 1;
            }
        }
        catch (final Exception e) {
            LOG.error("Cannot parse value to integer", e);
        }

        return ret;
    }

    /**
     * New uuid string.
     *
     * @return the string
     */
    public static String newUuidString() {
        return UUID.randomUUID().toString();
    }

    /**
     * Not null or empty.
     *
     * @param value
     *            the value
     * @return true, if successful
     */
    public static boolean notNullOrEmpty(final String value) {
        return (value != null) && !value.isEmpty();
    }

    /**
     * Null or empty.
     *
     * @param value the value
     * @return true, if successful
     */
    public static boolean nullOrEmpty(final String value) {
        return (value == null) || value.isEmpty();
    }

    /**
     * Prints the map.
     *
     * @param <K> the key type
     * @param <V> the value type
     * @param mapName the map name
     * @param datas the datas
     * @return the string
     */
    public static <K, V> String printMap(final String mapName, final Map<K, V> datas) {

        String content = "";

        final Set<Entry<K, V>> entrySet = datas.entrySet();
        for (final Entry<K, V> entry : entrySet) {
            content = String.join("", content, String.format("<%s:%s>", entry.getKey(), entry.getValue().toString()));
        }

        return String.format("%30s -- [%s]", mapName, content);
    }

    /**
     * Prints the web service info.
     *
     * @param config the config
     * @return the string
     */
    public static String printWebServiceInfo(final IWsConfiguration config) {
        return printWebServiceInfo(config, null);
    }

    /**
     * Prints the service.
     *
     * @param config the config
     * @param serviceUrl the service url
     * @return the string
     */
    public static String printWebServiceInfo(final IWsConfiguration config, final String serviceUrl) {
        return String.format(
            "Service Name: %-12s - Conect timeout: %-7s - Read timeout: %-7s - Url: %s",
            config.getServiceName(),
            config.getConnectTimeout(),
            config.getReadTimeout(),
            serviceUrl == null ? config.getServiceUrl() : serviceUrl);
    }

    /**
     * To int.
     *
     * @param value the value
     * @return the integer
     */
    public static Integer toInt(final String value) {

        return 0;
    }

    /**
     * To null string.
     *
     * @param value the value
     * @return the string
     */
    public static String toNullString(final String value) {
        return (value == null) || value.equals("null") ? null : value;
    }

    /**
     * Constructs a new <tt>StringUtil</tt>.
     */
    private StringUtil() {
    }

}
