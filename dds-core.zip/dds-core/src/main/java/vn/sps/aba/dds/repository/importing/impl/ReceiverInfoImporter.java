/*
 * Class: ReceiverInfoImporter
 *
 * Created on Sep 14, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.importing.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import net.logstash.logback.marker.Markers;
import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.receiver.AddressFields;
import vn.sps.aba.dds.common.model.receiver.AdressErfassung;
import vn.sps.aba.dds.common.model.receiver.CaptureInfo;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.model.receiver.VolleAdresse;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.config.task.CommonTaskExecutor;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;
import vn.sps.aba.dds.repository.entity.receiver.AddressFieldsEntity;
import vn.sps.aba.dds.repository.entity.receiver.CaptureInfoEntity;
import vn.sps.aba.dds.repository.entity.receiver.ReceiverInfoEntity;
import vn.sps.aba.dds.repository.entity.receiver.VolleAddressEntity;
import vn.sps.aba.dds.repository.importing.ICacheDataImporter;
import vn.sps.aba.dds.repository.jpa.IReceiverInfoRepository;
import vn.sps.aba.dds.service.validation.dpms.IReceiverValidator;

/**
 * The Class ReceiverInfoImporter.
 */
@Component("ReceiverInfoImporter")
@ConfigurationProperties("importing.receiver")
public class ReceiverInfoImporter implements ICacheDataImporter {

    /**
     * The Class ImportingResult.
     */
    @SuppressWarnings("unused")
    private class ImportingResult {

        /** The expired count. */
        protected int expiredCount;

        /** The from time. */
        protected long fromTime;

        /** The import end. */
        protected long importEnd;

        /** The load begin. */
        protected long loadBegin;

        /** The load end. */
        protected long loadEnd;

        /**
         * The success count.
         */
        protected int successCount;

        /**
         * The total count.
         */
        protected int totalCount;

        /**
         * The to time.
         */
        protected long toTime;

        /**
         * Count expired up.
         */
        public synchronized void countExpiredUp() {
            this.expiredCount++;
        }

        /**
         * Count success up.
         */
        protected synchronized void countSuccessUp() {
            this.successCount++;
        }

        /**
         * Gets the from time.
         *
         * @return the from time
         */
        public long getFromTime() {
            return this.fromTime;
        }

        /**
         * Gets the import end.
         *
         * @return the import end
         */
        public long getImportEnd() {
            return this.importEnd;
        }

        /**
         * Gets the load begin.
         *
         * @return the load begin
         */
        public long getLoadBegin() {
            return this.loadBegin;
        }

        /**
         * Gets the load end.
         *
         * @return the load end
         */
        public long getLoadEnd() {
            return this.loadEnd;
        }

        /**
         * Gets the success count.
         *
         * @return the success count
         */
        public int getSuccessCount() {
            return this.successCount;
        }

        /**
         * Gets the total count.
         *
         * @return the total count
         */
        public int getTotalCount() {
            return this.totalCount;
        }

        /**
         * Gets the to time.
         *
         * @return the to time
         */
        public long getToTime() {
            return this.toTime;
        }
    }

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ReceiverInfoImporter.class);

    /** The common task. */
    @Autowired
    private CommonTaskExecutor commonTask;

    /** The fetch size. */
    private int fetchSize = 5000;

    /** The import boot up. */
    private boolean importBootUp = false;

    /** The is running. */
    private boolean isRunning = false;

    /** The load duration. */
    private int loadDuration;

    /** The parallel. */
    private int parallel = 2;

    /** The receiver info dao. */
    @Autowired
    private IReceiverInfoCacheDao receiverInfoDao;

    /** The receiver validator. */
    @Autowired
    private IReceiverValidator receiverValidator;

    /** The repository. */
    @Autowired
    private IReceiverInfoRepository repository;

    /** The runner. */
    private Thread runner = null;

    /** The sync. */
    private boolean sync;

    /**
     * Gets the parallel.
     *
     * @return the parallel
     */
    protected int getParallel() {
        return this.parallel;
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.repository.importing.ICacheDataImporter#importData(java.time.LocalDateTime,
     * java.time.LocalDateTime)
     */
    @Deprecated
    @Override
    public int importData(final long fromTime, final long toTime) {
        LOG.info("Loading data from database...");
        final ImportingResult importingReport = new ImportingResult();
        final long now = DiscoWallClock.milli();
        importingReport.loadBegin = now;
        importingReport.fromTime = fromTime;
        importingReport.toTime = toTime;
        List<ReceiverInfoEntity> receiverInfoEntities = this.repository.listWithReceivedTime(now, fromTime, toTime);
        importingReport.loadEnd = DiscoWallClock.milli();

        if (CollectionUtils.isEmpty(receiverInfoEntities)) {
            LOG.info("Cannot find any receiver info");
            return 0;
        }
        final Stack<ReceiverInfoEntity> receiverInfos = new Stack<>();
        receiverInfos.addAll(receiverInfoEntities);
        receiverInfoEntities = null;
        final int totalCount = receiverInfos.size();
        LOG.info(
            "Loaded {} receiver infos from database (from {} to {})",
            totalCount,
            DateUtil.milli2LocalDateTime(fromTime),
            DateUtil.milli2LocalDateTime(toTime));

        importingReport.totalCount = totalCount;

        // Note: Check whether we need to use multiple threads for importing data
        LOG.info("Start import receiver info...");
        final List<Future<ReceiverInfo>> tasks = new ArrayList<>(receiverInfos.size());
        this.importReceiverInfoList(receiverInfos, tasks, importingReport);
        if (!this.isSync()) {
            tasks.stream().forEach((task) -> {
                try {
                    task.get();
                }
                catch (final InterruptedException | ExecutionException e) {
                    this.throwImportCacheEntry(e);
                }
            });
        }
        importingReport.importEnd = DiscoWallClock.milli();
        LOG.info(
            Markers.appendFields(importingReport),
            "Importing done. It takes {} millis to load data and {} millis to put into cache.",
            importingReport.loadEnd - importingReport.loadBegin,
            importingReport.importEnd - importingReport.loadEnd);

        return totalCount;
    }

    /**
     * Import one receiver info.
     *
     * @param receiverInfoEntity the receiver info entity
     * @param now the now
     * @return the receiver info
     */
    private ReceiverInfo importOneReceiverInfo(final ReceiverInfoEntity receiverInfoEntity, final long now) {
        ReceiverInfo receiverInfo = null;

        try {
            receiverInfo = this.newReceiverInfo(receiverInfoEntity);
            if (receiverInfo != null) {
                // TODO -- receiverInfoEntity.getLifespan() - (now - receiverInfoEntity.getCreated()) < 0
                final long lifespan = receiverInfoEntity.getLifespan() - (now - receiverInfoEntity.getCreated());
                this.receiverInfoDao.put(receiverInfo.getKey(), receiverInfo, lifespan);
            }
        }
        catch (final Exception e) {
            LOG.error(Markers.appendFields(receiverInfoEntity), "Error import receiver info", e);
        }

        return receiverInfo;
    }

    /**
     * Import receiver info list.
     *
     * @param receiverInfos the receiver infos
     * @param tasks the tasks
     * @param importingResult the importing result
     * @return the list
     */
    private void importReceiverInfoList(
        final Stack<ReceiverInfoEntity> receiverInfos,
        final List<Future<ReceiverInfo>> tasks,
        final ImportingResult importingResult) {

        while (!receiverInfos.empty()) {
            final ReceiverInfoEntity receiverInfo = receiverInfos.pop();
            final Callable<ReceiverInfo> c = () -> {
                ReceiverInfo ret = null;

                final long created = receiverInfo.getCreated();
                final long lifespan = receiverInfo.getLifespan();

                if (importingResult.loadBegin < (created + lifespan)) {
                    ret = ReceiverInfoImporter.this.importOneReceiverInfo(receiverInfo, importingResult.loadBegin);
                    if (ret != null) {
                        importingResult.countSuccessUp();
                    }
                }
                else {
                    importingResult.countExpiredUp();
                }

                return ret;
            };
            if (this.isSync()) {
                try {
                    c.call();
                }
                catch (final Exception e) {
                    this.throwImportCacheEntry(e);
                }
            }
            else {
                tasks.add(this.commonTask.getAsyncExecutor().submit(c));
            }

        }
    }

    /**
     * Inititalize.
     */
    @PostConstruct
    protected void inititalize() {
        if (this.receiverInfoDao.count() <= 0) {
            if (this.importBootUp) {
                if (this.runner == null) {
                    this.runner = new Thread(() -> ReceiverInfoImporter.this.loadDataByDefaultValue());
                    this.runner.start();
                }
            }
        }
    }

    /**
     * Checks if is sync.
     *
     * @return true, if is sync
     */
    public boolean isSync() {
        return this.sync;
    }

    /**
     * Load data.
     *
     * @param result the result
     * @see vn.sps.aba.dds.repository.importing.ICacheDataImporter#loadData(vn.sps.aba.dds.common.types.report.ImportingResult)
     */
    @Override
    public void loadData(final vn.sps.aba.dds.common.types.report.ImportingResult result) {
        if (result != null) {
            try {
                // Note: The importing should be the single process. Do not allow parallel processing
                if (!this.isRunning) {
                    this.isRunning = true;
                    LOG.info("Import receiver info has received time from {} to {}", result.getFromTime(), result.getToTime());
                    int i = 0;

                    final long begin = DiscoWallClock.milli();
                    boolean hasNextPage = true;
                    List<ReceiverInfoEntity> entries = null;
                    int successCount = 0;
                    int loadedCount = 0;
                    int duplicatedCount = 0;
                    while (hasNextPage) {
                        final long batchBegin = DiscoWallClock.milli();
                        final Stack<ReceiverInfoEntity> receiverInfoEntities = new Stack<>();
                        Page<ReceiverInfoEntity> pageData = this.repository
                            .list(begin, result.getFromTime(), result.getToTime(), new PageRequest(i, this.fetchSize));
                        final long batchLoadingEnd = DiscoWallClock.milli();
                        hasNextPage = (pageData != null) && ((entries = pageData.getContent()) != null) && !entries.isEmpty();
                        if (hasNextPage) {
                            receiverInfoEntities.addAll(entries);
                            pageData = null;
                            final int size = receiverInfoEntities.size();
                            loadedCount += size;
                            while (!receiverInfoEntities.isEmpty()) {
                                final ReceiverInfoEntity entity = receiverInfoEntities.pop();
                                final String key = entity.getKey();
                                if (!this.receiverInfoDao.containKey(key)) {
                                    successCount += this.importOneReceiverInfo(entity, begin) != null ? 1 : 0;
                                }
                                else {
                                    duplicatedCount++;
                                }
                            }
                            hasNextPage = size >= this.fetchSize;
                            i++;

                            final long batchImportEnd = DiscoWallClock.milli();
                            LOG.info(
                                "Load batch number {} size {}. Loaded in {}, import in {}",
                                i,
                                size,
                                batchLoadingEnd - batchBegin,
                                batchImportEnd - batchLoadingEnd);
                        }
                    }
                    final long end = DiscoWallClock.milli();
                    result.setLoadedCount(loadedCount);
                    result.setDuplicatedCount(0);
                    result.setSuccessCount(successCount);
                    result.setFailedCount(loadedCount - duplicatedCount - successCount);
                    LOG.info(
                        IndexMaker.indexes(result),
                        "Import receiver done. Loaded {}, Successful {}, Failed {}, Duplicated {}. It takes {} millis",
                        loadedCount,
                        successCount,
                        loadedCount - duplicatedCount - successCount,
                        duplicatedCount,
                        end - begin);
                    result.setMessage("Import done");
                }
                else {
                    result.setMessage("The importing is currently running. Try again later");
                }
            }
            finally {
                this.isRunning = false;
            }
        }
    }

    /**
     * Load data by default value.
     *
     * @return the vn.sps.aba.dds.common.types.report. importing result
     * @see vn.sps.aba.dds.repository.importing.ICacheDataImporter#loadDataByDefaultValue()
     */
    @Override
    public vn.sps.aba.dds.common.types.report.ImportingResult loadDataByDefaultValue() {
        final long now = DiscoWallClock.milli();
        final vn.sps.aba.dds.common.types.report.ImportingResult result = new vn.sps.aba.dds.common.types.report.ImportingResult();
        {
            result.setFromTime(now - this.loadDuration);
            result.setToTime(now);
            this.loadData(result);
        }
        return result;
    }

    /**
     * New adress erfassung.
     *
     * @param receiverInfoEntity the receiver info entity
     * @return the adress erfassung
     */
    private AdressErfassung newAdressErfassung(final ReceiverInfoEntity receiverInfoEntity) {
        final AdressErfassung adressErfassung = new AdressErfassung();
        {
            adressErfassung.setAddressFields(this.newAdressFields(receiverInfoEntity.getAddressFields()));
            adressErfassung.setVolleAdresse(this.newVolleAdresse(receiverInfoEntity.getVolleAddress()));
        }
        return adressErfassung;
    }

    /**
     * New adress fields.
     *
     * @param addressFieldEntity the address field entity
     * @return the address fields
     */
    private AddressFields newAdressFields(final AddressFieldsEntity addressFieldEntity) {

        AddressFields addressFields = null;

        if (addressFieldEntity != null) {
            addressFields = new AddressFields();
            {
                addressFields.setAdressZusatz(addressFieldEntity.getAdressZusatz());
                addressFields.setAnrede(addressFieldEntity.getAnrede());
                addressFields.setCoAdress(addressFieldEntity.getCoAdress());
                addressFields.setDienstleistung(addressFieldEntity.getDienstleistung());
                addressFields.setFirmeName(addressFieldEntity.getFirmeName());
                addressFields.setHausNummer(addressFieldEntity.getHausNummer());
                addressFields.setHausNummerZusatz(addressFieldEntity.getHausNummerZusatz());
                addressFields.setKundenNummer(addressFieldEntity.getKundenNummer());
                addressFields.setLaenderCode(addressFieldEntity.getLaenderCode());
                addressFields.setLand(addressFieldEntity.getLand());
                addressFields.setName(addressFieldEntity.getName());
                addressFields.setNameZusatz(addressFieldEntity.getNameZusatz());
                addressFields.setOrt(addressFieldEntity.getOrt());
                addressFields.setPostfach(addressFieldEntity.getPostfach());
                addressFields.setPostleizahl(addressFieldEntity.getPostleizahl());
                addressFields.setStockwerk(addressFieldEntity.getStockwerk());
                addressFields.setStrasse(addressFieldEntity.getStrasse());
                addressFields.setVorname(addressFieldEntity.getVorname());
            }
        }

        return addressFields;
    }

    /**
     * New capture info.
     *
     * @param captureInfoEntity the capture info entity
     * @return the capture info
     */
    private CaptureInfo newCaptureInfo(final CaptureInfoEntity captureInfoEntity) {

        final CaptureInfo captureInfo = new CaptureInfo();
        {
            if (captureInfoEntity != null) {
                captureInfo.setCaptureResultCode(captureInfoEntity.getCaptureResultCode());
                captureInfo.setCoderId(captureInfoEntity.getCoderId());
                captureInfo.setCodingStation(captureInfoEntity.getCodingStation());
                captureInfo.setCodingTimeStamp(captureInfoEntity.getCodingTimestamp());
            }
        }
        return captureInfo;
    }

    /**
     * New receiver info.
     *
     * @param receiverInfoEntity the receiver info entity
     * @return the receiver info
     */
    private ReceiverInfo newReceiverInfo(final ReceiverInfoEntity receiverInfoEntity) {

        final ReceiverInfo receiverInfo = new ReceiverInfo();
        {
            receiverInfo.setCallerId(receiverInfoEntity.getCallerId());
            receiverInfo.setDisCoTimestamp(receiverInfoEntity.getDisCoTimestamp());
            receiverInfo.setDpmTimeStamp(receiverInfoEntity.getDpmTimestamp());
            receiverInfo.setHausKey(receiverInfoEntity.getHausKey());
            receiverInfo.setIdentCode(receiverInfoEntity.getIdentCode());
            receiverInfo.setKdpId(receiverInfoEntity.getKdpId());
            receiverInfo.setKey(receiverInfoEntity.getKey());
            receiverInfo.setPackageId(receiverInfoEntity.getPackageId());
            receiverInfo.setParcelHausKey(receiverInfoEntity.getParcelHausKey());
            receiverInfo.setPdsTimestamp(receiverInfoEntity.getPdsTimestamp());
            receiverInfo.setPersonKey(receiverInfoEntity.getPersonKey());
            receiverInfo.setProcessEnd(DateUtil.timestamp2MilliTime(receiverInfoEntity.getProcessEnd()));
            receiverInfo.setProcessBegin(DateUtil.timestamp2MilliTime(receiverInfoEntity.getProcessStart()));
            receiverInfo.setReceived(DateUtil.timestamp2MilliTime(receiverInfoEntity.getReceivedTime()));

            receiverInfo.setSenderId(receiverInfoEntity.getSenderId());
            receiverInfo.setState(ReceiverState.valueOf(receiverInfoEntity.getState()));
            receiverInfo.setStatusCode(receiverInfoEntity.getStatusCode());
            receiverInfo.setVamStationSent(receiverInfoEntity.getVamStationSent());
            receiverInfo.setVerifiedByRule(receiverInfoEntity.getVerifiedByRule());
            receiverInfo.setVersion(receiverInfoEntity.getVersion());
            receiverInfo.setVgTimestamp(receiverInfoEntity.getVgTimestamp());
            receiverInfo.setVnTimestamp(receiverInfoEntity.getVnTimestamp());
            receiverInfo.setMatchMakerEnd(DateUtil.timestamp2MilliTime(receiverInfoEntity.getMatchMakerEnd()));
            receiverInfo.setMatchMakerBegin(DateUtil.timestamp2MilliTime(receiverInfoEntity.getMatchMakerBegin()));
            receiverInfo.setMatchMakerCount(receiverInfoEntity.getMatchMakerCount() == null ? 0 : receiverInfoEntity.getMatchMakerCount());
            receiverInfo.setCaptureResultEnd(DateUtil.timestamp2MilliTime(receiverInfoEntity.getCaptureResultEnd()));
            receiverInfo.setCaptureResultBegin(DateUtil.timestamp2MilliTime(receiverInfoEntity.getCaptureResultBegin()));
            receiverInfo.setCaptureResultCount(receiverInfoEntity.getCaptureResultCount() == null ? 0 : receiverInfoEntity.getCaptureResultCount());

            // Don't need to load the parcel data up
            // receiverInfo.setParcelData(receiverInfoEntity.getParcelData());
            receiverInfo.setAdressErfassung(this.newAdressErfassung(receiverInfoEntity));
            receiverInfo.setCaptureInfo(this.newCaptureInfo(receiverInfoEntity.getCaptureInfo()));
            this.receiverValidator.applyMangedInfo(receiverInfo);
        }
        return receiverInfo;
    }

    /**
     * New volle adresse.
     *
     * @param volleAddressEntity the volle address entity
     * @return the volle adresse
     */
    private VolleAdresse newVolleAdresse(final VolleAddressEntity volleAddressEntity) {

        VolleAdresse volleAdresse = null;

        if (volleAddressEntity != null) {
            volleAdresse = new VolleAdresse();
            {
                volleAdresse.setAddressFields(this.newAdressFields(volleAddressEntity.getAddressFields()));
                volleAdresse.setAddressSource(volleAddressEntity.getAddressSource());
                volleAdresse.setParcelAdrAmpStatus(volleAddressEntity.getParcelAdrAmpStatus());
                volleAdresse.setParcelAdrType(volleAddressEntity.getParcelAdrTypes());
                volleAdresse.setParcelStreetNumber(volleAddressEntity.getParcelStreetNumber());
                volleAdresse.setPersStatus(volleAddressEntity.getPersStatus());
                volleAdresse.setPersType(volleAddressEntity.getPersType());
            }
        }
        return volleAdresse;
    }

    /**
     * Sets the fetch size.
     *
     * @param fetchSize the new fetch size
     */
    public void setFetchSize(final int fetchSize) {
        this.fetchSize = fetchSize;
    }

    /**
     * Sets the import boot up.
     *
     * @param importBootUp the new import boot up
     */
    public void setImportBootUp(final boolean importBootUp) {
        this.importBootUp = importBootUp;
    }

    /**
     * Sets the load duration.
     *
     * @param loadDuration the new load duration
     */
    public void setLoadDuration(final int loadDuration) {
        this.loadDuration = loadDuration;
    }

    /**
     * Sets the parallel.
     *
     * @param parallel the new parallel
     */
    public void setParallel(final int parallel) {
        this.parallel = parallel;
    }

    /**
     * Sets the sync.
     *
     * @param sync the new sync
     */
    public void setSync(final boolean sync) {
        this.sync = sync;
    }

    /**
     * Throw import cache entry.
     *
     * @param e the e
     */
    private void throwImportCacheEntry(final Exception e) {
        LOG.error("An error occurs while importing ReceiverInfo data from database to cache", e);
    }

}
