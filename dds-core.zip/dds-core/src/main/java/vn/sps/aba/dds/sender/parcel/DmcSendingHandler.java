/*
 * Class: DmcSendingHandler
 *
 * Created on Oct 19, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.sender.parcel;

import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.Enumeration.DmcState;
import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.sender.DmcSendingExecutor;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.scheduled.sender.IScheduledSender;
import vn.sps.aba.dds.sender.parcel.interfaces.IBlackboxSender;
import vn.sps.aba.dds.sender.parcel.interfaces.IDmcSender;
import vn.sps.aba.dds.sender.parcel.interfaces.IParcel2VamSender;
import vn.sps.aba.dds.service.dmc.IDataMatrixCodingService;

/**
 * The Class DmcSendingHandler.
 */
@Component("DmcSendingHandler")
public class DmcSendingHandler extends AbstractParcelSender implements IDmcSender {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DmcSendingHandler.class);

    /** The blackbox sender. */
    @Autowired
    private IBlackboxSender blackboxSender;

    /** The executor. */
    @Autowired
    private DmcSendingExecutor executor;

    /** The dmc scheduled sender. */
    @Autowired
    @Qualifier("DmcScheduledSender")
    private IScheduledSender<ParcelInfo> scheduledSender;

    /** The data matrix coding service. */
    @Autowired
    private IDataMatrixCodingService service;

    /** The vam sender. */
    @Autowired
    private IParcel2VamSender vamSender;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected TaskConfiguration getExecutor() {
        return this.executor;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.sender.parcel.AbstractParcelSender#getScheduledSender()
     */
    @Override
    protected IScheduledSender<ParcelInfo> getScheduledSender() {
        return this.scheduledSender;
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.sender.IExternalSender#getSenderName()
     */
    @Override
    public String getSenderName() {
        return "DMC sender";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.sender.IExternalSender#handleItem(java.lang.Object)
     */
    @Override
    public Runnable handleItem(final ParcelInfo parcelInfo, final boolean isRetry) {
        return () -> {
            final String key = parcelInfo.getKey();
            try {
                LOG.info(IndexMaker.index(parcelInfo), "Request for DMC processing");
                final DMCResponse response = DmcSendingHandler.this.service.forwardToDmc(parcelInfo);
                if (response != null) {
                    parcelInfo.setDmcState(DmcState.DMC_SENT);
                    LOG.info(IndexMaker.index(parcelInfo), "Request for DMC processing successfully.");
                }
                else {
                    LOG.info(IndexMaker.index(parcelInfo), "Failed to request for DMC processing!");
                    DmcSendingHandler.this.scheduledSender.queue(parcelInfo);
                    LOG.info(IndexMaker.index(parcelInfo), "Parcel was queued up to request for DMC processing later");
                }

                @SuppressWarnings("rawtypes")
                Future task = DmcSendingHandler.this.blackboxSender.getTask(key);
                if (task != null) {
                    LOG.info(IndexMaker.index(parcelInfo), "Wait for Blackbox sender finished");
                    task.get();
                }

                task = DmcSendingHandler.this.vamSender.getTask(key);
                if (task != null) {
                    LOG.info(IndexMaker.index(parcelInfo), "Wait for VAM CaptureResult sender finished");
                    task.get();
                }
            }
            catch (final Exception e) {
                LOG.debug(IndexMaker.index(parcelInfo), "There is error when request for DMC processing", e);
            }
            finally {
                DmcSendingHandler.this.parcelInfoDao.store(key, parcelInfo);
                DmcSendingHandler.this.watcher.unWatch(key);
                LOG.info(IndexMaker.index(parcelInfo), "Request for DMC processing done");
            }
        };
    }

    /**
     * Merge and store.
     *
     * @param key the key
     * @param parcelInfo the parcel info
     */
    protected void mergeAndStore(final String key, final ParcelInfo parcelInfo) {
        try {
            ParcelInfo ret = this.parcelInfoDao.get(key);
            if (ret != null) {
                ret.setDmcState(parcelInfo.getDmcState());
                ret.setDmcBegin(parcelInfo.getDmcBegin());
                ret.setDmcSent(parcelInfo.getDmcSent());
                ret.setDmcCount(parcelInfo.getDmcCount());
            }
            else {
                LOG.info(IndexMaker.index(key), "Cannot find any parcel match with key");
                ret = parcelInfo;
            }
            this.parcelInfoDao.store(key, ret);
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when merge and store parcel into database.", e);
        }
    }
}
