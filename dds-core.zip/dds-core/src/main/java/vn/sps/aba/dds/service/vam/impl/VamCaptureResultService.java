/*
 * Class: CaptureResultServiceImpl
 *
 * Created on Jun 6, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.vam.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.xml.ws.BindingProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultIn;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultOut;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultService;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.ICaptureResultService;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration;
import vn.sps.aba.dds.config.service.CaptureResultServiceConfiguration;
import vn.sps.aba.dds.logging.IndexMaker;

/**
 * The Class CaptureResultServiceConsumer.
 */
@Service
public class VamCaptureResultService extends AbstractSoapWsConsumer<ICaptureResultService, CaptureResultIn, CaptureResultOut>
        implements vn.sps.aba.dds.service.vam.ICaptureResultService {

    /**
     * The Class VamSender.
     */
    private class TransferResult {

        /** The is successful. */
        boolean isSuccessful = false;

        /** The station id. */
        final String stationId;

        /** The url. */
        final String url;

        /**
         * Instantiates a new vam sender.
         *
         * @param stationId the station id
         * @param sender the sender
         */
        public TransferResult(final String stationId, final ICaptureResultService sender) {
            this.stationId = stationId;
            this.url = (String) ((BindingProvider) sender).getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        }
    }

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(VamCaptureResultService.class);

    /** The client. */
    private Map<String, ICaptureResultService> clients;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#checkResponse(java.lang.Object)
     */
    @Override
    protected boolean checkResponse(final IdentifiedEntry entry, final CaptureResultOut resultOut) {
        try {
            LOG.info(IndexMaker.index(entry, resultOut), "VAM CaptureResult service response");

            if (resultOut != null) {

                final CaptureResultServiceConfiguration serviceConfiguration = this.getConfiguration(CaptureResultServiceConfiguration.class);
                return resultOut.getStatusCode() == Integer.valueOf(serviceConfiguration.successful().getCode()).intValue();
            }
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.indexes(entry), "Error while checking response from CaptureResultService", e);
        }

        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#getClients()
     */
    @Override
    protected Object[] getClients() {
        return this.clients.values().toArray();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsTemplate#getPayloadName()
     */
    @Override
    protected String getServiceName() {
        return "CaptureResultService";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsTemplate#initGateway()
     */
    @Override
    public void initGateway() throws Exception {
        final CaptureResultServiceConfiguration serviceConfiguration = this.getConfiguration(CaptureResultServiceConfiguration.class);
        final CaptureResultService captureResultService = new CaptureResultService(this.getConfiguration().getWsdlLocation());
        final Map<String, String> destinationUrls = serviceConfiguration.getDestinationUrls();
        this.clients = new HashMap<>();
        for (final String key : destinationUrls.keySet()) {
            final ICaptureResultService client = captureResultService.getPort(ICaptureResultService.class);
            final BindingProvider bp = (BindingProvider) client;
            final String serviceUrl = destinationUrls.get(key);
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, serviceUrl);
            bp.getRequestContext().put(DDSConstant.WsProperties.CONNECT_TIMEOUT, serviceConfiguration.getConnectTimeout());
            bp.getRequestContext().put(DDSConstant.WsProperties.REQUEST_TIMEOUT, serviceConfiguration.getReadTimeout());
            this.clients.put(key, client);

            LOG.info(StringUtil.printWebServiceInfo(configuration, serviceUrl));
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#setConfiguration(vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration)
     */
    @Override
    @Autowired
    public void setConfiguration(@Qualifier("CaptureResultServiceConfiguration") final AbstractSoapWsConfiguration configuration) {
        this.configuration = configuration;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#transfer(java.lang.Object, java.lang.Object)
     */
    @Override
    protected CaptureResultOut transfer(final IdentifiedEntry entry, final CaptureResultIn payload, final ICaptureResultService client) throws Exception {
        return client.captureResult(payload);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.vam.ICaptureResultService#transferToVamStation(vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public boolean transferToVamStation(final ParcelInfo parcelInfo) {
        try {
            final CaptureResultServiceConfiguration serviceConfiguration = this.getConfiguration(CaptureResultServiceConfiguration.class);

            parcelInfo.setCaptureResultBegin(DiscoWallClock.milli());
            final CaptureResultIn message = MessageBuilder.buildCaptureResult(serviceConfiguration, parcelInfo);
            final String destinationStation = parcelInfo.getDestinationId();
            final ICaptureResultService client = this.clients.get(destinationStation);

            if (client != null) {

                final String url = (String) ((BindingProvider) client).getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
                final boolean ret = this.transferCascade(parcelInfo, message, client, url) != null;
                parcelInfo.setCaptureResultEnd(DiscoWallClock.milli());
                parcelInfo.countVamUp();

                if (!ret) {
                    LOG.info(IndexMaker.indexes(parcelInfo), "Failed to transfer ParcelInfo to VAM at url: {}", url);
                }
                return ret;
            }
            else {
                parcelInfo.setCaptureResultEnd(DiscoWallClock.milli());
                LOG.warn(IndexMaker.index(parcelInfo), "Cannot find a consumer for destination for parcel with destination station {}", destinationStation);
            }
        }
        catch (final Exception e) {
            parcelInfo.setCaptureResultEnd(DiscoWallClock.milli());
            LOG.error(IndexMaker.indexes(parcelInfo), "There are error while building the CaptureResult message", e);
        }

        return false;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.vam.ICaptureResultService#transferToVamStation(vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    public boolean transferToVamStation(final ReceiverInfo receiverInfo) {

        try {
            final CaptureResultServiceConfiguration serviceConfiguration = this.getConfiguration(CaptureResultServiceConfiguration.class);

            receiverInfo.setCaptureResultBegin(DiscoWallClock.milli());
            final CaptureResultIn message = MessageBuilder.buildCaptureResult(serviceConfiguration, receiverInfo);

            final List<Future<TransferResult>> senders = new ArrayList<>();

            final List<String> successfulStations = new ArrayList<>();
            parseExistingSuccessStations(successfulStations, receiverInfo);

            String[] dpmStationIds = serviceConfiguration.getDpmStationIds();

            // TODO -- Trying to name the created thread to be easily managed
            //            ThreadPoolTaskExecutor factory = new ThreadPoolTaskExecutor();
            //            factory.setThreadNamePrefix("dds-receiver2vam-sender-");
            //            factory.setCorePoolSize(dpmStationIds.length);
            //            factory.setMaxPoolSize(dpmStationIds.length);

            ExecutorService threadPool = Executors.newFixedThreadPool(dpmStationIds.length);
            for (final String stationId : dpmStationIds) {

                if (!successfulStations.contains(stationId)) {
                    senders.add(threadPool.submit(() -> {

                        TransferResult vamSender = null;

                        try {
                            final ICaptureResultService sender = VamCaptureResultService.this.clients.get(stationId);
                            vamSender = new TransferResult(stationId, sender);
                            vamSender.isSuccessful = VamCaptureResultService.this.transferCascade(receiverInfo, message, sender, vamSender.url) != null;
                        }
                        catch (final Exception e) {
                            vamSender.isSuccessful = false;
                            LOG.error(IndexMaker.indexes(vamSender), "Error when transfer receiver info to VAM", e);
                        }

                        return vamSender;
                    }));
                }
            }
            threadPool.shutdown();

            for (final Future<TransferResult> sender : senders) {
                final TransferResult result = sender.get();
                if (result.isSuccessful) {
                    successfulStations.add(result.stationId);
                }
                else {
                    LOG.error(IndexMaker.indexes(receiverInfo), "Failed to transfer to VAM station at url {}", result.url);
                }
            }
            if (!successfulStations.isEmpty()) {
                receiverInfo.setVamStationSent(String.join(Constant.CHAR_COMMA, successfulStations));
            }
            receiverInfo.setCaptureResultEnd(DiscoWallClock.milli());
            receiverInfo.countVamUp();
            return successfulStations.size() == dpmStationIds.length;
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.indexes(receiverInfo), "There are error while building the CaptureResult message", e);
        }

        return false;
    }
    
    /**
     * Parses the existing success stations.
     *
     * @param successfulStations the successful stations
     * @param receiverInfo the receiver info
     */
    private void parseExistingSuccessStations(final List<String> successfulStations, final ReceiverInfo receiverInfo) {
        String vamStationSent = receiverInfo.getVamStationSent();
        if (StringUtil.notNullOrEmpty(vamStationSent)) {
            String[] strings = vamStationSent.split(Constant.CHAR_COMMA);
            successfulStations.addAll(Arrays.asList(strings));
        }
    }

}
