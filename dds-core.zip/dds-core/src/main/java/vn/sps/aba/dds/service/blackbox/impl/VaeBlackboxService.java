/*
 * Class: VaeBlackboxService
 *
 * Created on Jul 1, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.blackbox.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import net.logstash.logback.marker.Markers;
import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.ws.vae.blackbox.CaptureRequestRecord;
import vn.sps.aba.dds.common.types.ws.vae.blackbox.CaptureRequestResponse;
import vn.sps.aba.dds.common.types.ws.vae.blackbox.DisCoRequest;
import vn.sps.aba.dds.common.types.ws.vae.blackbox.IDisCoService;
import vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration;
import vn.sps.aba.dds.config.service.VaeBlackboxServiceConfiguration;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.logging.report.VaeRecordReport;
import vn.sps.aba.dds.service.blackbox.IVaeBlackboxService;

/**
 * The Class VaeBlackboxService.
 */
@Service
public class VaeBlackboxService extends AbstractSoapWsConsumer<IDisCoService, CaptureRequestRecord, CaptureRequestResponse> implements IVaeBlackboxService {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(VaeBlackboxService.class);

    /** The client. */
    private IDisCoService client;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#checkResponse(java.lang.Object)
     */
    @Override
    protected boolean checkResponse(final IdentifiedEntry entry, final CaptureRequestResponse response) {
        try {
            LOG.info(IndexMaker.index(entry, response), "VAE BlackBox reponse");

            if (response != null) {

                final VaeBlackboxServiceConfiguration serviceConfiguration = this.getConfiguration(VaeBlackboxServiceConfiguration.class);
                return serviceConfiguration.successful().getCode().equalsIgnoreCase(response.getStatusText());
            }
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.indexes(entry), "Error while checking response from CaptureRequestService", e);
        }
        return false;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.blackbox.IVaeBlackboxService#forwardToBlackbox(vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public boolean forwardToBlackbox(final ParcelInfo parcelInfo) {

        try {
            final VaeBlackboxServiceConfiguration serviceConfiguration = this.getConfiguration(VaeBlackboxServiceConfiguration.class);

            parcelInfo.setBlackboxBegin(DiscoWallClock.milli());
            final CaptureRequestRecord captureRequestRecord = MessageBuilder.buildCaptureRequest(parcelInfo, serviceConfiguration);
            final String url = serviceConfiguration.getServiceUrl();
            final boolean ret = this.transferCascade(parcelInfo, captureRequestRecord, this.client, url) != null;
            parcelInfo.setBlackboxEnd(DiscoWallClock.milli());
            parcelInfo.countVaeUp();

            if (!ret) {
                LOG.error(
                    Markers.append(DDSConstant.ParcelFields.FIELD_KEY, parcelInfo.getKey()),
                    "Failed to transfer ParcelInfo to VAE BlackBoxService at url " + url);
            }
            return ret;
        }
        catch (final Exception e) {

            LOG.error(Markers.appendFields(parcelInfo), "There are error while building the {} message.", this.getServiceName(), e);
        }

        return false;
    }
    
    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#getClients()
     */
    @Override
    protected Object[] getClients() {
        return new Object[] { this.client };
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsTemplate#getPayloadName()
     */
    @Override
    protected String getServiceName() {
        return "CaptureRequest";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsTemplate#initGateway()
     */
    @Override
    public void initGateway() throws Exception {
        final VaeBlackboxServiceConfiguration serviceConfiguration = this.getConfiguration(VaeBlackboxServiceConfiguration.class);
        final DisCoRequest disCoRequest = new DisCoRequest(serviceConfiguration.getWsdlLocation());
        this.client = disCoRequest.getPort(IDisCoService.class);
        super.initGateway();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#setConfiguration(vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration)
     */
    @Autowired
    @Override
    public void setConfiguration(@Qualifier("VaeBlackboxServiceConfiguration") final AbstractSoapWsConfiguration configuration) {
        this.configuration = configuration;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#transfer(java.lang.Object, java.lang.Object)
     */
    @Override
    protected CaptureRequestResponse transfer(final IdentifiedEntry entry, final CaptureRequestRecord payload, final IDisCoService client) throws Exception {
        return client.submitCaptureRequest(payload);
    }

}
