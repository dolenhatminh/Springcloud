/*
 * Class: DpmPayloadValidator
 *
 * Created on Jul 23, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.service.interceptor.dpm;

import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.support.MarshallingUtils;
import org.xml.sax.SAXParseException;

import vn.sps.aba.dds.common.types.message.Description;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultResponse;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.ObjectFactory;
import vn.sps.aba.dds.config.service.DpmServiceConfiguration;
import vn.sps.aba.dds.service.interceptor.AbstractPayloadValidator;

/**
 * The Class DpmPayloadValidator.
 */
public class DpmPayloadValidator extends AbstractPayloadValidator {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DpmPayloadValidator.class);

    /**
     * Instantiates a new DPM payload validator.
     *
     * @param configuration the configuration
     */
    public DpmPayloadValidator(final DpmServiceConfiguration configuration) {
        super(configuration);
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.ws.soap.server.endpoint.interceptor.AbstractFaultCreatingValidatingInterceptor#handleRequestValidationErrors(org.springframework.ws.context.MessageContext, org.xml.sax.SAXParseException[])
     */
    @Override
    protected boolean handleRequestValidationErrors(final MessageContext messageContext, final SAXParseException[] errors) throws TransformerException {

        try {
            if (messageContext.getResponse() instanceof SoapMessage) {

                LOG.info("The receiver info is invalid with following message:");
                final Description description = new Description();

                for (final SAXParseException error : errors) {

                    description.addMessage(error.getMessage());
                    LOG.info(error.getMessage());
                }
                if (this.getAddValidationErrorDetail()) {

                    final Response resp = this.getConfiguration(DpmServiceConfiguration.class).invalidData();

                    final SaajSoapMessage response = (SaajSoapMessage) messageContext.getResponse();

                    if (resp != null) {

                        final ObjectFactory objectFactory = this.getConfiguration().getObjectFactory(ObjectFactory.class);

                        final CaptureResultResponse captureResultResponse = MessageBuilder.buildDPMResponse(objectFactory, resp, description);
                        MarshallingUtils.marshal(this.getConfiguration().getMarshaller(), captureResultResponse, response);
                    }
                }
            }
        }
        catch (final Exception e) {

            LOG.error("There is error while handling validating errors of receiver info service ", e);
        }

        return false;
    }
}
