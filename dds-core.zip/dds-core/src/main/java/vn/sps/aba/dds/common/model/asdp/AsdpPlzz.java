/*
 * Class: AsdpPlzz
 *
 * Created on Oct 13, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.asdp;

import java.io.Serializable;
import java.util.Date;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;

import vn.sps.aba.dds.common.model.lookup.IAsdpPlz;

/**
 * The Class AsdpPlzz.
 */
@Indexed
public class AsdpPlzz implements Serializable, IAsdpPlz {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -6704771266732010109L;

    /** The log typ. */
    private Integer logTyp;

    /** The plz. */
    private String plz;

    /** The plz abs. */
    private Date plzAbs;

    /** The plz ibs. */
    private Date plzIbs;

    /** The plz ort. */
    private String plzOrt;

    /** The plz typ. */
    private Integer plzTyp;

    /**
     * Gets the log typ.
     *
     * @return the log typ
     */
    public Integer getLogTyp() {
        return this.logTyp;
    }

    /**
     * Gets the plz.
     *
     * @return the plz
     */
    @Field(store = Store.YES, analyze = Analyze.NO)
    public String getPlz() {
        return this.plz;
    }

    /**
     * Gets the plz abs.
     *
     * @return the plz abs
     */
    public Date getPlzAbs() {
        return this.plzAbs;
    }

    /**
     * Gets the plz ibs.
     *
     * @return the plz ibs
     */
    public Date getPlzIbs() {
        return this.plzIbs;
    }

    /**
     * Gets the plz ort.
     *
     * @return the plz ort
     */
    public String getPlzOrt() {
        return this.plzOrt;
    }

    /**
     * Gets the plz typ.
     *
     * @return the plz typ
     */
    public Integer getPlzTyp() {
        return this.plzTyp;
    }

    /**
     * Sets the log typ.
     *
     * @param logTyp the new log typ
     */
    public void setLogTyp(final Integer logTyp) {
        this.logTyp = logTyp;
    }

    /**
     * Sets the plz.
     *
     * @param plz the new plz
     */
    public void setPlz(final String plz) {
        this.plz = plz;
    }

    /**
     * Sets the plz abs.
     *
     * @param plzAbs the new plz abs
     */
    public void setPlzAbs(final Date plzAbs) {
        this.plzAbs = plzAbs;
    }

    /**
     * Sets the plz ibs.
     *
     * @param plzIbs the new plz ibs
     */
    public void setPlzIbs(final Date plzIbs) {
        this.plzIbs = plzIbs;
    }

    /**
     * Sets the plz ort.
     *
     * @param plzOrt the new plz ort
     */
    public void setPlzOrt(final String plzOrt) {
        this.plzOrt = plzOrt;
    }

    /**
     * Sets the plz typ.
     *
     * @param plzTyp the new plz typ
     */
    public void setPlzTyp(final Integer plzTyp) {
        this.plzTyp = plzTyp;
    }
}
