/*
 * Class: EDAErrorList
 *
 * Created on Apr 22, 2014
 *
 * (c) Copyright Lam Research Corporation, unpublished work, created 2014
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Lam Research Corporation
 * 4000 N. First Street
 * San Jose, CA
 */
package vn.sps.aba.dds.common.types.message;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * The Class EDAErrorList.
 */
@XStreamAlias("dds-responses")
public class DDSResponseList {

    /** The errors. */
    @XStreamAlias("responses")
    private final List<Response> responses = new ArrayList<Response>();

    /** The sources. */
    @XStreamAlias("sources")
    private final List<Source> sources = new ArrayList<Source>();

    /**
     * Builds the map.
     */
    public void buildMap() {

    }

    /**
     * Gets the responses.
     *
     * @return Returns the responses.
     */
    public List<Response> getResponses() {
        return this.responses;
    }

    /**
     * Gets the sources.
     *
     * @return the sources
     */
    public List<Source> getSources() {
        return this.sources;
    }

}
