/*
 * Class: EnumResolver
 *
 * Created on Jul 23, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.ws.vam.capturing;

import java.util.HashMap;
import java.util.Map;

import vn.sps.aba.dds.common.types.ws.vam.capturing.model.EAmpStatus;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.ECaptureResultCode;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.EDienstleistung;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.EPersStatus;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.EPersType;

/**
 * The Class EnumResolver.
 */
public final class EnumResolver {

    /** The amp statuses. */
    private static Map<String, EAmpStatus> ampStatuses = new HashMap<>();

    /** The capture result codes. */
    private static Map<String, ECaptureResultCode> captureResultCodes = new HashMap<>();

    /** The dienstleistungs. */
    private static Map<String, EDienstleistung> dienstleistungs = new HashMap<>();

    /** The pers statuses. */
    private static Map<String, EPersStatus> persStatuses = new HashMap<>();

    /** The pers types. */
    private static Map<String, EPersType> persTypes = new HashMap<>();

    static {

        for (final EAmpStatus ampStatus : EAmpStatus.values()) {

            ampStatuses.put(ampStatus.value(), ampStatus);
        }

        for (final ECaptureResultCode captureResultCode : ECaptureResultCode.values()) {

            captureResultCodes.put(captureResultCode.value(), captureResultCode);
        }

        for (final EDienstleistung dienstleistungType : EDienstleistung.values()) {

            dienstleistungs.put(dienstleistungType.value(), dienstleistungType);
        }

        for (final EPersStatus EPersStatus : EPersStatus.values()) {

            persStatuses.put(EPersStatus.value(), EPersStatus);
        }

        for (final EPersType EPersType : EPersType.values()) {

            persTypes.put(EPersType.value(), EPersType);
        }

    }

    /**
     * Resolve amp status.
     *
     * @param value the value
     * @return the amp status type
     */
    public static EAmpStatus resolveAmpStatus(final String value) {

        return ampStatuses.get(value);
    }

    /**
     * Resolve capture result code.
     *
     * @param value the value
     * @return the capture result code type
     */
    public static ECaptureResultCode resolveCaptureResultCode(final String value) {

        return captureResultCodes.get(value);
    }

    /**
     * Resolve dienstleistung.
     *
     * @param value the value
     * @return the dienstleistung type
     */
    public static EDienstleistung resolveDienstleistung(final String value) {

        return dienstleistungs.get(value);
    }

    /**
     * Resolve pers status.
     *
     * @param value the value
     * @return the pers status type
     */
    public static EPersStatus resolvePersStatus(final String value) {

        return persStatuses.get(value);
    }

    /**
     * Resolve pers type.
     *
     * @param value the value
     * @return the pers type type
     */
    public static EPersType resolvePersType(final String value) {

        return persTypes.get(value);
    }

    /**
     * Instantiates a new enum resolver.
     */
    private EnumResolver() {
    }
}
