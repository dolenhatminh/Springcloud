/*
 * Class: StateDMCProcessingHandler
 *
 * Created on Jul 4, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.parcel.handers.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.parcel.handers.IParcelStepHandler;
import vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext;

/**
 * The Class StateDMCProcessingHandler.
 */
public class DmcSenderHandler extends AbstractParcelStepHandler implements IParcelStepHandler {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DmcSenderHandler.class);

    /**
     * Instantiates a new state dmc processing handler.
     */
    public DmcSenderHandler() {
        super(PARCEL_STATE_DMCING);
    }

    /**
     * Handle.
     *
     * @param context            the context
     * @param parcelInfo            the parcel info
     */
    @Override
    public void handle(final IParcelStateHandlerContext context, final ParcelInfo parcelInfo) {

        LOG.info(IndexMaker.index(parcelInfo), "Submit parcel info to DMC sender.");
        context.submitDmc(parcelInfo);
    }
}
