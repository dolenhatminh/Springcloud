/*
 * Class: ReceiverInfoController
 *
 * Created on Jul 7, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.controller;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Profile;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.cache.IDDSCacheEntry;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.report.ImportingResult;
import vn.sps.aba.dds.common.types.statistic.Status;
import vn.sps.aba.dds.common.util.ControllerUtil;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.controller.interfaces.IEntriesController;
import vn.sps.aba.dds.controller.interfaces.INoVisibleEntries;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;
import vn.sps.aba.dds.repository.importing.ICacheDataImporter;
import vn.sps.aba.dds.repository.listener.IMightBeErrorCollector;
import vn.sps.aba.dds.repository.query.ICCounter;
import vn.sps.aba.dds.sender.IExternalSender;
import vn.sps.aba.dds.sender.receiver.interfaces.IMatchMakerSender;
import vn.sps.aba.dds.sender.receiver.interfaces.IReceiver2VamSender;

/**
 * The Class ReceiverInfoController.
 */
@ConfigurationProperties
@RestController("ReceiverInfoController")
@RequestMapping("/aba/dds/receiver")
@Profile(value = { Profiles.RECEIVER, Profiles.DPM, Profiles.DPMB, Profiles.DPMS })
public class ReceiverInfoController implements IEntriesController, INoVisibleEntries {
    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ReceiverInfoController.class);

    /** The cache importer. */
    @Autowired
    private ICacheDataImporter cacheImporter;

    /** The capture result in progress states. */
    private String[] captureResultInProgressStates;

    /** The error collector. */
    @Autowired
    @Qualifier("ReceiverInfoCacheDao")
    private IMightBeErrorCollector errorCollector;

    /** The match maker in progress states. */
    private String[] matchMakerInProgressStates;

    /** The match maker sender. */
    @Autowired
    private IMatchMakerSender matchMakerSender;

    /** The receiver info dao. */
    @Autowired
    private IReceiverInfoCacheDao receiverInfoDao;

    /** The vam sender. */
    @Autowired
    private IReceiver2VamSender vamSender;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.interfaces.IEntriesController#checkAndPersist(java.lang.String)
     */
    @Override
    public int checkAndPersist(final String key) {
        return this.checkAndPersist(key, true);
    }

    /**
     * Check and persist.
     *
     * @param key the key
     * @param sync the sync
     * @return the int
     */
    private int checkAndPersist(final String key, final boolean sync) {
        int ret = 0;

        if (StringUtil.notNullOrEmpty(key)) {
            final ReceiverInfo receiverInfo = this.receiverInfoDao.get(key);
            try {
                ret = this.receiverInfoDao.persist(key, receiverInfo, sync) ? 1 : -1;
            }
            catch (final Exception e) {
                ret = -1;
                LOG.error("There is error when persist receiver into dabase", e);
            }
        }

        return ret;
    }

    /**
     * Clear cache.
     */
    @Override
    public void clearCache() {
        this.receiverInfoDao.clear();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.interfaces.IEntriesController#count()
     */
    @Override
    public List<Status> count() {
        return this.count(null, null);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.interfaces.IEntriesController#count(java.time.LocalDateTime, java.time.LocalDateTime)
     */
    @Override
    public List<Status> count(final String fromTime, final String toTime) {

        final List<Status> ret = new ArrayList<>();

        final LocalDateTime fromLocalTime = ControllerUtil.string2LocalDateTime(fromTime);
        final LocalDateTime toLocalTime = ControllerUtil.string2LocalDateTime(toTime);

        final long fromInstant = ControllerUtil.localDateTime2Instant(fromLocalTime);
        final long toInstant = ControllerUtil.localDateTime2Instant(toLocalTime);
        this.receiverInfoDao.countState(ret, fromInstant, toInstant);

        return ret;
    }

    /**
     * Find and submit.
     *
     * @param states the states
     * @param sender the sender
     * @param fromTime the from time
     * @param toTime the to time
     * @param maxResult the max result
     * @return the int
     */
    private int findAndSubmit(
        final String[] states,
        final IExternalSender<ReceiverInfo> sender,
        final LocalDateTime fromTime,
        final LocalDateTime toTime,
        final int maxResult) {
        final List<ReceiverInfo> receiverInfos = new ArrayList<>();

        try {
            if ((states != null) && (states.length > 0)) {
                final long fromInstant = ControllerUtil.localDateTime2Instant(fromTime);
                final long toInstant = ControllerUtil.localDateTime2Instant(toTime);
                for (final String state : states) {
                    final List<ReceiverInfo> results = this.receiverInfoDao.list(fromInstant, toInstant, state, null, maxResult);
                    if ((results != null) && !results.isEmpty()) {
                        receiverInfos.addAll(results);
                    }
                }
                if (!receiverInfos.isEmpty()) {
                    receiverInfos.stream().forEach(t -> sender.rubmitItem(t));
                    LOG.info(
                        "Found and submitted {} receiver has received time between {} and {} and state is one of {} to {}",
                        receiverInfos.size(),
                        fromTime,
                        toTime,
                        Arrays.toString(states),
                        sender.getSenderName());
                }
            }
            else {
                LOG.info("No state specified");
            }
        }
        catch (final Exception e) {
            LOG.error("Error while finding and submitting receivers to " + sender.getSenderName(), e);
        }

        return receiverInfos.size();
    }

    /**
     * Find and submit capture result.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @param maxResult the max result
     * @return the int
     */
    @RequestMapping(value = "/find/submit/capture-result", method = RequestMethod.POST)
    public int findAndSubmitCaptureResult(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        @RequestParam(value = "size") final int maxResult) {

        return this.findAndSubmit(this.captureResultInProgressStates, this.vamSender, fromTime, toTime, maxResult);
    }

    /**
     * Find and submit match maker.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @param maxResult the max result
     * @return the int
     */
    @RequestMapping(value = "/find/submit/matchmaker", method = RequestMethod.POST)
    public int findAndSubmitMatchMaker(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        @RequestParam(value = "size") final int maxResult) {

        return this.findAndSubmit(this.matchMakerInProgressStates, this.matchMakerSender, fromTime, toTime, maxResult);
    }

    /**
     * List all no visible enitries.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @param size the size
     * @return the list
     * @see vn.sps.aba.dds.controller.interfaces.INoVisibleEntries#listAllNoVisibleEnitries(java.lang.String, java.lang.String, int)
     */
    @Override
    public List<IDDSCacheEntry> listAllNoVisibleEnitries(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        final int size) {
        final List<IDDSCacheEntry> ret = new ArrayList<>();

        if (size != 0) {
            final long fromInstant = ControllerUtil.localDateTime2Instant(fromTime);
            final long toInstant = ControllerUtil.localDateTime2Instant(toTime);

            this.receiverInfoDao.getManagedInfo(ret, fromInstant, toInstant, size);
            if (!ret.isEmpty()) {
                LOG.info("Found {} receiver has receive time between [{}] and [{}]", ret.size(), fromTime, toTime);
            }
            else {
                LOG.info("Cannot find any receiver has receive time between [{}] and [{}]", fromTime, toTime);
            }
        }

        return ret;
    }

    /**
     * List by ident code no visible enitries.
     *
     * @param identCode the ident code
     * @return the IDDS cache entry
     * @see vn.sps.aba.dds.controller.interfaces.INoVisibleEntries#listByIdentCodeNoVisibleEnitries(java.lang.String)
     */
    @Override
    public List<IDDSCacheEntry> listByIdentCodeNoVisibleEnitries(
        @RequestParam(value = "identCode") final String identCode,
        @RequestParam(value = "size", defaultValue = "-1") final int size) {
        final List<IDDSCacheEntry> ret = new ArrayList<>();

        if ((size != 0) && (identCode != null)) {
            this.receiverInfoDao.getManagedInfo(ret, null, identCode, size);
            ControllerUtil.sortManagedInfo(ret);
            if (ret.isEmpty()) {
                LOG.info("Cannot find any receiver has ident code {}", identCode);
            }
        }

        return ret;
    }

    /**
     * List by key no visible enitries.
     *
     * @param key the key
     * @return the IDDS cache entry
     * @see vn.sps.aba.dds.controller.interfaces.INoVisibleEntries#listByKeyNoVisibleEnitries(java.lang.String)
     */
    @Override
    public IDDSCacheEntry listByKeyNoVisibleEnitries(@RequestParam(value = "key") final String key) {
        IDDSCacheEntry ret = null;

        if (key != null) {
            final List<IDDSCacheEntry> entries = new ArrayList<>();
            this.receiverInfoDao.getManagedInfo(entries, key, null, -1);
            if (entries.isEmpty()) {
                LOG.info("Cannot find any receiver has key {}", key);
            }
            else {
                ret = entries.get(0);
            }
        }

        return ret;
    }

    /**
     * List by state no visible enitries.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @param state the state
     * @param size the size
     * @return the list
     * @see vn.sps.aba.dds.controller.interfaces.INoVisibleEntries#listByStateNoVisibleEnitries(java.lang.String, java.lang.String, java.lang.String, int)
     */
    @Override
    public List<IDDSCacheEntry> listByStateNoVisibleEnitries(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        final String state,
        final int size) {
        final List<IDDSCacheEntry> ret = new ArrayList<>();

        if (size != 0) {
            final long fromInstant = ControllerUtil.localDateTime2Instant(fromTime);
            final long toInstant = ControllerUtil.localDateTime2Instant(toTime);

            this.receiverInfoDao.getManagedInfo(ret, fromInstant, toInstant, StringUtil.toNullString(state), null, size);
            if (!ret.isEmpty()) {
                LOG.info("Found {} receiver has receive time between [{}] and [{}]", ret.size(), fromTime, toTime);
            }
            else {
                LOG.info("Cannot find any receiver has receive time between [{}] and [{}]", fromTime, toTime);
            }
        }

        return ret;
    }

    /**
     * Load data.
     *
     * @return the importing result
     */
    @RequestMapping(value = "/load-default", method = RequestMethod.POST)
    @ResponseBody
    public ImportingResult loadData() {
        return this.cacheImporter.loadDataByDefaultValue();
    }

    // TODO -- Expose REST API to retrieve current state of receiver info importing (because it takes around 30 minutes for 1 million collections)
    /**
     * Load data.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @return the importing result
     */
    @RequestMapping(value = "/load", method = RequestMethod.POST)
    @ResponseBody
    public ImportingResult loadData(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime) {

        final ImportingResult result = new ImportingResult();
        {
            final long fromEpoch = ZonedDateTime.of(fromTime, DiscoWallClock.zone()).toInstant().toEpochMilli();
            final long toEpoch = ZonedDateTime.of(toTime, DiscoWallClock.zone()).toInstant().toEpochMilli();
            result.setFromTime(fromEpoch);
            result.setToTime(toEpoch);
            this.cacheImporter.loadData(result);
        }

        return result;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.interfaces.IEntriesController#overflow(java.lang.String, java.lang.String)
     */
    @Override
    public String[] persist(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        @RequestParam(value = "size") final int size) {
        final List<String> ret = new ArrayList<>();

        if (fromTime.isBefore(toTime) && (size != 0)) {

            final long fromInstant = ControllerUtil.localDateTime2Instant(fromTime);
            final long toInstant = ControllerUtil.localDateTime2Instant(toTime);

            final List<ReceiverInfo> parcelInfos = this.receiverInfoDao.list(fromInstant, toInstant, null, null, size);
            if ((parcelInfos != null) && (parcelInfos.size() > 0)) {

                LOG.info("Found {} receiver info has receivedTime between {} and {}", parcelInfos.size(), fromTime, toTime);
                final String retPattern = "%s:%s";
                for (final ReceiverInfo parcelInfo : parcelInfos) {
                    final String key = parcelInfo.getKey();
                    String result = null;
                    try {
                        if (this.receiverInfoDao.persist(key, parcelInfo, true)) {
                            result = String.format(retPattern, key, "successful");
                        }
                        else {
                            result = String.format(retPattern, key, "failed");
                        }
                    }
                    catch (final Exception e) {
                        result = String.format(retPattern, key, "failed");
                        LOG.error(IndexMaker.index(key), "Failed trying to persist receiver info " + key, e);
                    }
                    ret.add(result);
                }
            }
            else {
                LOG.info("Cannot find any receiver info has receivedTime between {} and {}", fromTime, toTime);
            }
        }

        return ret.toArray(new String[ret.size()]);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.interfaces.IEntriesController#processDBError()
     */
    @Override
    public String processDBError(final boolean wait) {
        final String pattern = "Found %d error items, persist %d successfully";

        final List<String> errorItems = this.errorCollector.listErrorItem();
        int count = 0;

        for (final String key : errorItems) {
            count += this.checkAndPersist(key, wait) == 1 ? 1 : 0;
        }

        return String.format(pattern, errorItems.size(), count);
    }

    /**
     * Process duplicated entries.
     */
    @Override
    public void processDuplicatedEntries() {
        LOG.info("Removing the duplicated receiver info in cache...");
        final List<ICCounter> entries = this.receiverInfoDao.listDuplicatedIdentCode();
        final AtomicInteger counter = new AtomicInteger();
        if ((entries != null) && !entries.isEmpty()) {
            entries.stream().forEach(t -> {
                if (t.getCount() > 1) {
                    final List<ReceiverInfo> receiverInfos = this.receiverInfoDao.listByIdentCode(t.getIdentCode());
                    if ((receiverInfos != null) && (receiverInfos.size() > 1)) {
                        receiverInfos.sort((r1, r2) -> Long.valueOf(r2.getReceived()).compareTo(Long.valueOf(r1.getReceived())));
                        for (int i = 1; i < receiverInfos.size(); i++) {
                            final ReceiverInfo receiverInfo = receiverInfos.get(i);
                            final String state = receiverInfo.getState();
                            if (ReceiverState.INVALID.name().equals(state) || ReceiverState.VAM_PADASA_SENT.name().equals(state) || ReceiverState.VAM_PADASA_SENT_NOT_MATCHING.name().equals(state)) {
                                this.receiverInfoDao.remove(receiverInfo.getKey());
                                counter.incrementAndGet();
                            }
                        }
                    }
                }
            });
        }
        LOG.info("Removed {} dupllicated receiver info from cache.", counter.get());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.interfaces.IEntriesController#processExpiredEntries()
     */
    @Override
    public void processExpiredEntries() {
        LOG.info("Trying to remove expired receiver info");
        this.receiverInfoDao.removeExpiredEntries();
    }

    /**
     * Sets the capture result in progress states.
     *
     * @param captureResultInProgressStates the new capture result in progress states
     */
    @Value("${controller.receiver.capture-result.in-progress-states}")
    public void setCaptureResultInProgressStates(final String[] captureResultInProgressStates) {
        StringUtil.assertEnum(ReceiverState.class, captureResultInProgressStates);
        this.captureResultInProgressStates = captureResultInProgressStates;
    }

    /**
     * Sets the match maker in progress states.
     *
     * @param matchMakerInProgressStates the new match maker in progress states
     */
    @Value("${controller.receiver.matchmaker.in-progress-states}")
    public void setMatchMakerInProgressStates(final String[] matchMakerInProgressStates) {
        StringUtil.assertEnum(ReceiverState.class, matchMakerInProgressStates);
        this.matchMakerInProgressStates = matchMakerInProgressStates;
    }
}
