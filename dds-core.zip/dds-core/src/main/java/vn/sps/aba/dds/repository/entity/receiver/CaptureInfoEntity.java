/*
 * Class: CaptureInfoEntity
 *
 * Created on Jul 13, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.entity.receiver;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import vn.sps.aba.dds.common.constant.TableNames;
import vn.sps.aba.dds.common.model.receiver.CaptureInfo;

/**
 * The Class CaptureInfoEntity.
 */
@Entity
@Table(name = TableNames.REC_CAPTURE_INFO)
@Access(AccessType.PROPERTY)
public class CaptureInfoEntity implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 5937471759642426334L;

    /** The capture result code. */
    private String captureResultCode;

    /** The coder id. */
    private String coderId;

    /** The coding station. */
    private String codingStation;

    /** The coding timestamp. */
    private String codingTimestamp;

    /** The id. */
    private Long id;

    /**
     * Instantiates a new capture info entity.
     */
    public CaptureInfoEntity() {
    }

    /**
     * Instantiates a new capture info entity.
     *
     * @param captureInfo
     *            the capture info
     */
    public CaptureInfoEntity(final CaptureInfo captureInfo) {
        this.setCaptureResultCode(captureInfo.getCaptureResultCode());
        this.setCoderId(captureInfo.getCoderId());
        this.setCodingStation(captureInfo.getCodingStation());
        this.setCodingTimestamp(captureInfo.getCodingTimeStamp());
    }

    /**
     * Gets the capture result code string.
     *
     * @return the capture result code string
     */
    @Column(name = "capture_result_code", length = 150)
    public String getCaptureResultCode() {
        return this.captureResultCode;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.CaptureInfo#getCoderId()
     */

    @Column(name = "coder_id", length = 100)
    public String getCoderId() {
        return this.coderId;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.CaptureInfo#getCodingStation()
     */

    @Column(name = "coding_station", length = 50)
    public String getCodingStation() {
        return this.codingStation;
    }

    /**
     * Gets the coding time string.
     *
     * @return the coding time string
     */
    @Column(name = "coding_timestamp", length = 100)
    public String getCodingTimestamp() {
        return this.codingTimestamp;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    @Id
    @SequenceGenerator(name = "rec_capture_info_generator", sequenceName = "rec_capture_infos_seq", initialValue = 1, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rec_capture_info_generator")
    @JoinColumn(name = "id", columnDefinition = "bigserial")
    public Long getId() {
        return this.id;
    }

    /**
     * Sets the capture result code string.
     *
     * @param captureResultCode
     *            the new capture result code string
     */
    public void setCaptureResultCode(final String captureResultCode) {
        if (captureResultCode != null) {
            this.captureResultCode = captureResultCode;
        }
    }

    /**
     * Sets the coder id.
     *
     * @param coderId
     *            the new coder id
     */
    private void setCoderId(final String coderId) {
        this.coderId = coderId;
    }

    /**
     * Sets the coding station.
     *
     * @param codingStation
     *            the new coding station
     */
    private void setCodingStation(final String codingStation) {
        this.codingStation = codingStation;

    }

    /**
     * Sets the coding time string.
     *
     * @param codingTimestamp
     *            the new coding timestamp
     */
    public void setCodingTimestamp(final String codingTimestamp) {
        this.codingTimestamp = codingTimestamp;
    }

    /**
     * Sets the id.
     *
     * @param id
     *            the new id
     */
    public void setId(final Long id) {
        this.id = id;
    }
}
