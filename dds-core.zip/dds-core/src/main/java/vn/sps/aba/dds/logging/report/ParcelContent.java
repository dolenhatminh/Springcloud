package vn.sps.aba.dds.logging.report;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.types.ws.pds.parcel.model.TransferParcelInfoIn;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.logging.IndexMaker;
/**
 * Received ParcelInfo (PDS)
 * Class ParcelContent
 */
public class ParcelContent implements Serializable{
	
	 /** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5201495385792814416L;

	/** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ParcelContent.class);
	
    /** The callerId. */
	private String callerId;
	
	 /** The parcelInfo. */
	private ParcelInfo parcelInfo;
	
	 /** The parcelInfoSentTimestamp. */
	private String parcelInfoSentTimestamp;
	
	/** The version. */
	private Integer version;

	/**
	 * Received ParcelInfo (PDS)
	 * Parse from TransferParcelInfoIn
	 * @param TransferParcelInfoIn
	 */
	public ParcelContent(TransferParcelInfoIn parcelInfoIn, ParcelInfo parcelInfo) {
		try {
			this.callerId = parcelInfoIn.getCallerId();
			this.parcelInfo = parcelInfo;
			this.parcelInfoSentTimestamp = DateUtil.gregorian2String(parcelInfoIn.getParcelInfoSentTimestamp());
			this.version = parcelInfoIn.getVersion();
		} catch (Exception e) {
			LOG.info(IndexMaker.index(parcelInfo), "Could not parse to ParcelContent", e);
		}
		
	}

	/**
	 * @return the callerId
	 */
	public String getCallerId() {
		return callerId;
	}

	/**
	 * @return the parcelInfo
	 */
	public ParcelInfo getParcelInfo() {
		return parcelInfo;
	}

	/**
	 * @return the parcelInfoSentTimestamp
	 */
	public String getParcelInfoSentTimestamp() {
		return parcelInfoSentTimestamp;
	}

	/**
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}
	
	
	
}
