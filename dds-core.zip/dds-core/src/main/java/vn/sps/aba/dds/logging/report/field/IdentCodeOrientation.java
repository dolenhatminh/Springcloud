package vn.sps.aba.dds.logging.report.field;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.model.parcel.Barcode;
import vn.sps.aba.dds.logging.report.VaeRecordReport;
/**
 * Class IdentCodeOrientation
 * One of VaeRecordReport's Fields 
 */
public class IdentCodeOrientation implements Serializable {

	 /** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6764207967264134892L;
	
	/** The LOG. */
	private static final Logger LOG = LoggerFactory.getLogger(VaeRecordReport.class);
	
	protected double upperLeftX;
	protected double upperLeftY;
	protected double lowerLeftX;
	protected double lowerLeftY;
	protected double lowerRightX;
	protected double lowerRightY;
	protected double upperRightX;
	protected double upperRightY;

	/** The valid code. */
	private static String validCode = "[0-9]{18}";

	/** The valid type. */
	private static String validType = "I";

	/**
	 * One of VaeRecordReport's Fields 
	 * @param Barcode
	 */
	public IdentCodeOrientation(final Barcode barcode) {
		if (checkVaeCondition(barcode)) {
			this.upperLeftX = string2Double(barcode.getBoundary().getX1());
			this.upperLeftY = string2Double(barcode.getBoundary().getY1());
			this.lowerLeftX = string2Double(barcode.getBoundary().getX2());
			this.lowerLeftY = string2Double(barcode.getBoundary().getY2());
			this.lowerRightX = string2Double(barcode.getBoundary().getX3());
			this.lowerRightY = string2Double(barcode.getBoundary().getY3());
			this.upperRightX = string2Double(barcode.getBoundary().getX4());
			this.upperRightY = string2Double(barcode.getBoundary().getY4());
		}
	}

	/**
	 * @param upperLeftX
	 * @param upperLeftY
	 * @param lowerLeftX
	 * @param lowerLeftY
	 * @param lowerRightX
	 * @param lowerRightY
	 * @param upperRightX
	 * @param upperRightY
	 */
	public IdentCodeOrientation() {
		this.upperLeftX = 0.0;
		this.upperLeftY = 0.0;
		this.lowerLeftX = 0.0;
		this.lowerLeftY = 0.0;
		this.lowerRightX = 0.0;
		this.lowerRightY = 0.0;
		this.upperRightX = 0.0;
		this.upperRightY = 0.0;
	}

	/**
	 * Check vae condition.
	 *
	 * @param barcode
	 *            the barcode
	 * @return true, if successful
	 */
	private static boolean checkVaeCondition(final Barcode barcode) {
		boolean ret = false;

		try {
			final String type = barcode.getType();
			final String code = barcode.getCode();
			if ((type == null) || type.isEmpty() || (code == null)) {
				return false;
			}
			ret = validType.equals(type) && code.matches(validCode);
		} catch (final Exception e) {
			LOG.error("ERRORS: Check condition meet errors ", e);
		}

		return ret;
	}

	/**
	 * String2 double.
	 *
	 * @param s
	 *            the s
	 * @return the double
	 */
	private static Double string2Double(final String s) {
		try {
			return s == null ? 0 : Double.parseDouble(s);
		} catch (final NumberFormatException e) {
			return 0.0;
		}
	}

	/**
	 * @return the upperLeftX
	 */
	public double getUpperLeftX() {
		return upperLeftX;
	}

	/**
	 * @return the upperLeftY
	 */
	public double getUpperLeftY() {
		return upperLeftY;
	}

	/**
	 * @return the lowerLeftX
	 */
	public double getLowerLeftX() {
		return lowerLeftX;
	}

	/**
	 * @return the lowerLeftY
	 */
	public double getLowerLeftY() {
		return lowerLeftY;
	}

	/**
	 * @return the lowerRightX
	 */
	public double getLowerRightX() {
		return lowerRightX;
	}

	/**
	 * @return the lowerRightY
	 */
	public double getLowerRightY() {
		return lowerRightY;
	}

	/**
	 * @return the upperRightX
	 */
	public double getUpperRightX() {
		return upperRightX;
	}

	/**
	 * @return the upperRightY
	 */
	public double getUpperRightY() {
		return upperRightY;
	}

	/**
	 * @return the validCode
	 */
	public static String getValidCode() {
		return validCode;
	}

	/**
	 * @return the validType
	 */
	public static String getValidType() {
		return validType;
	}

}
