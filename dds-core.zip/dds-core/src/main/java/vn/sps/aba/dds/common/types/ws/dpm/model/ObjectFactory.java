
package vn.sps.aba.dds.common.types.ws.dpm.model;

import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the vn.sps.aba.dds.service.dpm.model package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ReceiverInfoResponse_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "ReceiverInfoResponse");
    private final static QName _ReceiverInfoRequest_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "ReceiverInfoRequest");
    private final static QName _PersType_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "PersType");
    private final static QName _ProduktZusatzLeistung_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "ProduktZusatzLeistung");
    private final static QName _CaptureInfo_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "CaptureInfo");
    private final static QName _ParcelData_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "ParcelData");
    private final static QName _AdresseErfassung_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "AdresseErfassung");
    private final static QName _ArrayOfProduktZusatzLeistung_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "ArrayOfProduktZusatzLeistung");
    private final static QName _PersStatus_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "PersStatus");
    private final static QName _Timestamps_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Timestamps");
    private final static QName _CaptureResultCode_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "CaptureResultCode");
    private final static QName _CaptureAddress_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "CaptureAddress");
    private final static QName _AmpStatus_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "AmpStatus");
    private final static QName _VolleAdresse_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "VolleAdresse");
    private final static QName _ReceiverInfo_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "ReceiverInfo");
    private final static QName _AddressFields_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "AddressFields");
    private final static QName _AddressFieldsTypeDienstleistung_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Dienstleistung");
    private final static QName _AddressFieldsTypePostfach_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Postfach");
    private final static QName _AddressFieldsTypeHausnummerZusatz_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "HausnummerZusatz");
    private final static QName _AddressFieldsTypeNameZusatz_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "NameZusatz");
    private final static QName _AddressFieldsTypeKundennummer_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Kundennummer");
    private final static QName _AddressFieldsTypePostleitzahl_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Postleitzahl");
    private final static QName _AddressFieldsTypeStockwerk_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Stockwerk");
    private final static QName _AddressFieldsTypeLaenderCode_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "LaenderCode");
    private final static QName _AddressFieldsTypeAnrede_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Anrede");
    private final static QName _AddressFieldsTypeLand_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Land");
    private final static QName _AddressFieldsTypeName_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Name");
    private final static QName _AddressFieldsTypeOrt_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Ort");
    private final static QName _AddressFieldsTypeAdressZusatz_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "AdressZusatz");
    private final static QName _AddressFieldsTypeCoAdresse_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "CoAdresse");
    private final static QName _AddressFieldsTypeStrasse_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Strasse");
    private final static QName _AddressFieldsTypeVorname_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Vorname");
    private final static QName _AddressFieldsTypeFirmenname_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Firmenname");
    private final static QName _VolleAdresseTypeKdpId_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "KdpId");
    private final static QName _VolleAdresseTypeParcelHausKey_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "ParcelHausKey");
    private final static QName _AdresseErfassungTypeTypedFields_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "TypedFields");
    private final static QName _AdresseErfassungTypeHausKey_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "HausKey");
    private final static QName _ReceiverInfoTypeSenderId_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "SenderId");
    private final static QName _ReceiverInfoResponseTypeDescription_QNAME = new QName("Ch.Post.PL.DisCo.ReceiverInfoService", "Description");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: vn.sps.aba.dds.service.dpm.model
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ReceiverInfoResponseType }
     * 
     */
    public ReceiverInfoResponseType createReceiverInfoResponseType() {
        return new ReceiverInfoResponseType();
    }

    /**
     * Create an instance of {@link ProduktZusatzLeistungType }
     * 
     */
    public ProduktZusatzLeistungType createProduktZusatzLeistungType() {
        return new ProduktZusatzLeistungType();
    }

    /**
     * Create an instance of {@link TransferReceiverInfoRequest }
     * 
     */
    public TransferReceiverInfoRequest createTransferReceiverInfoRequest() {
        return new TransferReceiverInfoRequest();
    }

    /**
     * Create an instance of {@link ReceiverInfoRequestType }
     * 
     */
    public ReceiverInfoRequestType createReceiverInfoRequestType() {
        return new ReceiverInfoRequestType();
    }

    /**
     * Create an instance of {@link AdresseErfassungType }
     * 
     */
    public AdresseErfassungType createAdresseErfassungType() {
        return new AdresseErfassungType();
    }

    /**
     * Create an instance of {@link ArrayOfProduktZusatzLeistungType }
     * 
     */
    public ArrayOfProduktZusatzLeistungType createArrayOfProduktZusatzLeistungType() {
        return new ArrayOfProduktZusatzLeistungType();
    }

    /**
     * Create an instance of {@link CaptureInfoType }
     * 
     */
    public CaptureInfoType createCaptureInfoType() {
        return new CaptureInfoType();
    }

    /**
     * Create an instance of {@link ParcelDataType }
     * 
     */
    public ParcelDataType createParcelDataType() {
        return new ParcelDataType();
    }

    /**
     * Create an instance of {@link TimestampType }
     * 
     */
    public TimestampType createTimestampType() {
        return new TimestampType();
    }

    /**
     * Create an instance of {@link TransferReceiverInfoResponse }
     * 
     */
    public TransferReceiverInfoResponse createTransferReceiverInfoResponse() {
        return new TransferReceiverInfoResponse();
    }

    /**
     * Create an instance of {@link ReceiverInfoType }
     * 
     */
    public ReceiverInfoType createReceiverInfoType() {
        return new ReceiverInfoType();
    }

    /**
     * Create an instance of {@link VolleAdresseType }
     * 
     */
    public VolleAdresseType createVolleAdresseType() {
        return new VolleAdresseType();
    }

    /**
     * Create an instance of {@link AddressFieldsType }
     * 
     */
    public AddressFieldsType createAddressFieldsType() {
        return new AddressFieldsType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReceiverInfoResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "ReceiverInfoResponse")
    public JAXBElement<ReceiverInfoResponseType> createReceiverInfoResponse(ReceiverInfoResponseType value) {
        return new JAXBElement<ReceiverInfoResponseType>(_ReceiverInfoResponse_QNAME, ReceiverInfoResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReceiverInfoRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "ReceiverInfoRequest")
    public JAXBElement<ReceiverInfoRequestType> createReceiverInfoRequest(ReceiverInfoRequestType value) {
        return new JAXBElement<ReceiverInfoRequestType>(_ReceiverInfoRequest_QNAME, ReceiverInfoRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PersTypeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "PersType")
    public JAXBElement<PersTypeType> createPersType(PersTypeType value) {
        return new JAXBElement<PersTypeType>(_PersType_QNAME, PersTypeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProduktZusatzLeistungType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "ProduktZusatzLeistung")
    public JAXBElement<ProduktZusatzLeistungType> createProduktZusatzLeistung(ProduktZusatzLeistungType value) {
        return new JAXBElement<ProduktZusatzLeistungType>(_ProduktZusatzLeistung_QNAME, ProduktZusatzLeistungType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "CaptureInfo")
    public JAXBElement<CaptureInfoType> createCaptureInfo(CaptureInfoType value) {
        return new JAXBElement<CaptureInfoType>(_CaptureInfo_QNAME, CaptureInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParcelDataType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "ParcelData")
    public JAXBElement<ParcelDataType> createParcelData(ParcelDataType value) {
        return new JAXBElement<ParcelDataType>(_ParcelData_QNAME, ParcelDataType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdresseErfassungType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "AdresseErfassung")
    public JAXBElement<AdresseErfassungType> createAdresseErfassung(AdresseErfassungType value) {
        return new JAXBElement<AdresseErfassungType>(_AdresseErfassung_QNAME, AdresseErfassungType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfProduktZusatzLeistungType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "ArrayOfProduktZusatzLeistung")
    public JAXBElement<ArrayOfProduktZusatzLeistungType> createArrayOfProduktZusatzLeistung(ArrayOfProduktZusatzLeistungType value) {
        return new JAXBElement<ArrayOfProduktZusatzLeistungType>(_ArrayOfProduktZusatzLeistung_QNAME, ArrayOfProduktZusatzLeistungType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PersStatusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "PersStatus")
    public JAXBElement<PersStatusType> createPersStatus(PersStatusType value) {
        return new JAXBElement<PersStatusType>(_PersStatus_QNAME, PersStatusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TimestampType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Timestamps")
    public JAXBElement<TimestampType> createTimestamps(TimestampType value) {
        return new JAXBElement<TimestampType>(_Timestamps_QNAME, TimestampType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureResultCodeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "CaptureResultCode")
    public JAXBElement<CaptureResultCodeType> createCaptureResultCode(CaptureResultCodeType value) {
        return new JAXBElement<CaptureResultCodeType>(_CaptureResultCode_QNAME, CaptureResultCodeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link List }{@code <}{@link String }{@code >}{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "CaptureAddress")
    public JAXBElement<List<String>> createCaptureAddress(List<String> value) {
        return new JAXBElement<List<String>>(_CaptureAddress_QNAME, ((Class) List.class), null, ((List<String> ) value));
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmpStatusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "AmpStatus")
    public JAXBElement<AmpStatusType> createAmpStatus(AmpStatusType value) {
        return new JAXBElement<AmpStatusType>(_AmpStatus_QNAME, AmpStatusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VolleAdresseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "VolleAdresse")
    public JAXBElement<VolleAdresseType> createVolleAdresse(VolleAdresseType value) {
        return new JAXBElement<VolleAdresseType>(_VolleAdresse_QNAME, VolleAdresseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReceiverInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "ReceiverInfo")
    public JAXBElement<ReceiverInfoType> createReceiverInfo(ReceiverInfoType value) {
        return new JAXBElement<ReceiverInfoType>(_ReceiverInfo_QNAME, ReceiverInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressFieldsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "AddressFields")
    public JAXBElement<AddressFieldsType> createAddressFields(AddressFieldsType value) {
        return new JAXBElement<AddressFieldsType>(_AddressFields_QNAME, AddressFieldsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReceiverInfoRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "ReceiverInfoRequest", scope = TransferReceiverInfoRequest.class)
    public JAXBElement<ReceiverInfoRequestType> createTransferReceiverInfoRequestReceiverInfoRequest(ReceiverInfoRequestType value) {
        return new JAXBElement<ReceiverInfoRequestType>(_ReceiverInfoRequest_QNAME, ReceiverInfoRequestType.class, TransferReceiverInfoRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DienstleistungType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Dienstleistung", scope = AddressFieldsType.class)
    public JAXBElement<DienstleistungType> createAddressFieldsTypeDienstleistung(DienstleistungType value) {
        return new JAXBElement<DienstleistungType>(_AddressFieldsTypeDienstleistung_QNAME, DienstleistungType.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Postfach", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypePostfach(String value) {
        return new JAXBElement<String>(_AddressFieldsTypePostfach_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "HausnummerZusatz", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeHausnummerZusatz(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeHausnummerZusatz_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "NameZusatz", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeNameZusatz(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeNameZusatz_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Kundennummer", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeKundennummer(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeKundennummer_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Postleitzahl", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypePostleitzahl(String value) {
        return new JAXBElement<String>(_AddressFieldsTypePostleitzahl_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Stockwerk", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeStockwerk(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeStockwerk_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "LaenderCode", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeLaenderCode(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeLaenderCode_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Anrede", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeAnrede(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeAnrede_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Land", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeLand(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeLand_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Name", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeName(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeName_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Ort", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeOrt(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeOrt_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "AdressZusatz", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeAdressZusatz(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeAdressZusatz_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "CoAdresse", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeCoAdresse(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeCoAdresse_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Strasse", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeStrasse(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeStrasse_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Vorname", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeVorname(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeVorname_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Firmenname", scope = AddressFieldsType.class)
    public JAXBElement<String> createAddressFieldsTypeFirmenname(String value) {
        return new JAXBElement<String>(_AddressFieldsTypeFirmenname_QNAME, String.class, AddressFieldsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "KdpId", scope = VolleAdresseType.class)
    public JAXBElement<Integer> createVolleAdresseTypeKdpId(Integer value) {
        return new JAXBElement<Integer>(_VolleAdresseTypeKdpId_QNAME, Integer.class, VolleAdresseType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PersStatusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "PersStatus", scope = VolleAdresseType.class)
    public JAXBElement<PersStatusType> createVolleAdresseTypePersStatus(PersStatusType value) {
        return new JAXBElement<PersStatusType>(_PersStatus_QNAME, PersStatusType.class, VolleAdresseType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "ParcelHausKey", scope = VolleAdresseType.class)
    public JAXBElement<Integer> createVolleAdresseTypeParcelHausKey(Integer value) {
        return new JAXBElement<Integer>(_VolleAdresseTypeParcelHausKey_QNAME, Integer.class, VolleAdresseType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PersTypeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "PersType", scope = VolleAdresseType.class)
    public JAXBElement<PersTypeType> createVolleAdresseTypePersType(PersTypeType value) {
        return new JAXBElement<PersTypeType>(_PersType_QNAME, PersTypeType.class, VolleAdresseType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressFieldsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "TypedFields", scope = AdresseErfassungType.class)
    public JAXBElement<AddressFieldsType> createAdresseErfassungTypeTypedFields(AddressFieldsType value) {
        return new JAXBElement<AddressFieldsType>(_AdresseErfassungTypeTypedFields_QNAME, AddressFieldsType.class, AdresseErfassungType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "HausKey", scope = AdresseErfassungType.class)
    public JAXBElement<Integer> createAdresseErfassungTypeHausKey(Integer value) {
        return new JAXBElement<Integer>(_AdresseErfassungTypeHausKey_QNAME, Integer.class, AdresseErfassungType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReceiverInfoResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "ReceiverInfoResponse", scope = TransferReceiverInfoResponse.class)
    public JAXBElement<ReceiverInfoResponseType> createTransferReceiverInfoResponseReceiverInfoResponse(ReceiverInfoResponseType value) {
        return new JAXBElement<ReceiverInfoResponseType>(_ReceiverInfoResponse_QNAME, ReceiverInfoResponseType.class, TransferReceiverInfoResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "SenderId", scope = ReceiverInfoType.class)
    public JAXBElement<Integer> createReceiverInfoTypeSenderId(Integer value) {
        return new JAXBElement<Integer>(_ReceiverInfoTypeSenderId_QNAME, Integer.class, ReceiverInfoType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", name = "Description", scope = ReceiverInfoResponseType.class)
    public JAXBElement<String> createReceiverInfoResponseTypeDescription(String value) {
        return new JAXBElement<String>(_ReceiverInfoResponseTypeDescription_QNAME, String.class, ReceiverInfoResponseType.class, value);
    }

}
