//@javax.xml.bind.annotation.XmlSchema(xmlns = {
//    @javax.xml.bind.annotation.XmlNs(prefix = "dis", namespaceURI = "http://schemas.datacontract.org/2004/07/DisCoService"),
//    @javax.xml.bind.annotation.XmlNs(prefix = "", namespaceURI = "http://tempuri.org/")/*,
//    @javax.xml.bind.annotation.XmlNs(prefix = "tem", namespaceURI = "http://tempuri.org/"),
//    @javax.xml.bind.annotation.XmlNs(prefix = "", namespaceURI = "http://tempuri.org/") */}, namespace = "http://schemas.datacontract.org/2004/07/DisCoService", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package vn.sps.aba.dds.common.types.ws.vae.blackbox;
