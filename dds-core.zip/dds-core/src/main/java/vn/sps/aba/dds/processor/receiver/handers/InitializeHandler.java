/*
 * Class: StepVerifyingHandler
 *
 * Created on Jul 11, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.receiver.handers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext;

/**
 * The Class StepNewHandler.
 */
public class InitializeHandler extends AbstractReceiverStepHandler implements IReceiverStepHandler {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(InitializeHandler.class);

    /**
     * Instantiates a new step new handler.
     */
    public InitializeHandler() {
        super(STEP_NEW_HANDLER);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.receiver.handers.IReceiverStepHandler#handle(vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext, vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    public void handle(final IReceiverProcessingContext context, final ReceiverInfo receiverInfo) {

        LOG.info(IndexMaker.index(receiverInfo), "Start processing receiver info");

        context.transmitStateTo(receiverInfo, ReceiverState.VERIFYING);

        context.handle(STEP_VERIFYING_HANDLER, receiverInfo);
    }
}
