/*
 * Class: IDataMatrixCodingService
 *
 * Created on Jun 23, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.dmc;

import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;

/**
 * The Interface IDataMatrixCodingService.
 */
public interface IDataMatrixCodingService {

    /**
     * Transfer.
     *
     * @param parcel
     *            the parcel
     * @return the dmc processing response
     */
    DMCResponse forwardToDmc(ParcelInfo parcel);
}
