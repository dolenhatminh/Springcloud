/*
 * Class: DdsScheduledTask
 *
 * Created on Oct 7, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled;

/**
 * The Interface DdsScheduledTask.
 */
public interface DdsScheduledTask {
    /**
     * Gets the cron expression.
     *
     * @return the cron expression
     */
    String getCronExpression();

    /**
     * Handle task.
     *
     * @return the runnable
     */
    Runnable handleTask();

    /**
     * Task name.
     *
     * @return the string
     */
    String taskName();
}
