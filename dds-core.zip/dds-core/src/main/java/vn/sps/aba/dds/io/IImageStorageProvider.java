/*
 * Class: IImageStorageProvider
 *
 * Created on Aug 2, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.io;

import java.io.File;
import java.time.LocalDate;

import vn.sps.aba.dds.service.pds.parcel.IImageInfo;

/**
 * The Interface IImageStorageProvider.
 */
public interface IImageStorageProvider {

    /**
     * Adds the folder.
     *
     * @param date the date
     * @param order the order
     */
    void addFolder(LocalDate date, int order);

    /**
     * File count.
     *
     * @param date the date
     * @return the int
     */
    int fileCount(LocalDate date);

    /**
     * Gets the folder.
     *
     * @param date the date
     * @return the folder
     */
    File getFolder(LocalDate date);

    /**
     * Gets the folder.
     *
     * @param date the date
     * @param imageInfo the image info
     * @return the folder
     */
    void getFolder(LocalDate date, IImageInfo imageInfo);

    /**
     * Scan directory.
     *
     * @param date the date
     */
    void scanDirectory(LocalDate date);
}
