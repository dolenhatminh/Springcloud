/*
 * Class: IWsConfiguration
 *
 * Created on Oct 4, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service.interfaces;

/**
 * The Interface IWsConfiguration.
 */
public interface IWsConfiguration {

    /**
     * Gets the connect timeout.
     *
     * @return the connect timeout
     */
    int getConnectTimeout();

    /**
     * Gets the read timeout.
     *
     * @return the read timeout
     */
    int getReadTimeout();

    /**
     * Gets the retry interval time.
     *
     * @return the retry interval time
     */
    long getRetryIntervalTime();

    /**
     * Gets the retry time.
     *
     * @return the retry time
     */
    int getRetryTime();

    /**
     * Gets the service name.
     *
     * @return the service name
     */
    String getServiceName();

    /**
     * Gets the service url.
     *
     * @return Returns the serviceUrl.
     */
    String getServiceUrl();

}