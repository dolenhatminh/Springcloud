package vn.sps.aba.dds.service.dmc;

import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.net.ssl.HostnameVerifier;

import org.apache.http.client.HttpClient;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.DefaultHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.util.PublicSuffixMatcher;
import org.apache.http.conn.util.PublicSuffixMatcherLoader;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.pool.ConnPoolControl;
import org.apache.http.pool.PoolStats;
import org.apache.http.ssl.SSLContexts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.service.AbstractRestWsConfiguration;
import vn.sps.aba.dds.config.service.interfaces.IWsConfiguration;
import vn.sps.aba.dds.jmx.HttpCPInfo;
import vn.sps.aba.dds.logging.IndexMaker;

/**
 * The Class AbstractRestWsTemplate.
 *
 * @param <T> the generic type
 */
public abstract class AbstractRestWsTemplate<T> implements HttpCPInfo {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(AbstractRestWsTemplate.class);

    /** The conn manager. */
    private ConnPoolControl<HttpRoute> cpController = null;

    /**
     * The rest template.
     */
    protected RestTemplate restTemplate;

    /**
     * Builds the connection manager.
     *
     * @param configuration the configuration
     * @return the http client connection manager
     */
    private HttpClientConnectionManager buildConnectionManager(final AbstractRestWsConfiguration configuration) {
        final PublicSuffixMatcher publicSuffixMatcherCopy = PublicSuffixMatcherLoader.getDefault();
        final HostnameVerifier hostnameVerifierCopy = new DefaultHostnameVerifier(publicSuffixMatcherCopy);
        final ConnectionSocketFactory sslSocketFactoryCopy = new SSLConnectionSocketFactory(SSLContexts.createDefault(), hostnameVerifierCopy);

        final PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(RegistryBuilder.<ConnectionSocketFactory> create()
            .register("http", PlainConnectionSocketFactory.getSocketFactory()).register("https", sslSocketFactoryCopy).build(), null, null, null,
            configuration.getConnTimeToLive(), TimeUnit.MILLISECONDS);
        if (configuration.getMaxConnTotal() > 0) {
            connectionManager.setMaxTotal(configuration.getMaxConnTotal());
        }
        if (configuration.getMaxConnPerRoute() > 0) {
            connectionManager.setDefaultMaxPerRoute(configuration.getMaxConnPerRoute());
        }
        this.cpController = connectionManager;

        return connectionManager;
    }

    /**
     * Builds the http client.
     *
     * @param configuration the configuration
     * @return the http client
     */
    private HttpClient buildHttpClient(final AbstractRestWsConfiguration configuration) {
        final HttpClientBuilder builder = HttpClientBuilder.create().setConnectionManager(this.buildConnectionManager(configuration));
        if (configuration.isDisableAutomaticRetries()) {
            builder.disableAutomaticRetries();
        }
        return builder.build();
    }

    /**
     * Check retry time.
     *
     * @param entry the key
     * @param maxRetryTimes the max retry times
     * @param retryTimes the retry times
     * @param retryIntervalTime the retry interval time
     */
    private void checkRetryTime(final IdentifiedEntry entry, final int maxRetryTimes, final int retryTimes, final long retryIntervalTime) {
        try {
            if (maxRetryTimes > retryTimes) {
                LOG.info(IndexMaker.index(entry), "Retry after {} miliseconds", retryIntervalTime);
                Thread.sleep(retryIntervalTime);
            }
        }
        catch (final Exception e2) {
            LOG.debug(null, e2);
        }
    }

    /**
     * Gets the client http request factory.
     *
     * @param configuration the configuration
     * @return the client http request factory
     */
    private ClientHttpRequestFactory getClientHttpRequestFactory(final AbstractRestWsConfiguration configuration) {
        final HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
        {
            clientHttpRequestFactory.setConnectTimeout(configuration.getConnectTimeout());
            clientHttpRequestFactory.setReadTimeout(configuration.getReadTimeout());
            if (configuration.isUseCustomHttpClient()) {
                clientHttpRequestFactory.setHttpClient(this.buildHttpClient(configuration));
            }
        }
        return clientHttpRequestFactory;
    }

    /**
     *  The configuration.
     *
     * @return the configuration
     */
    protected abstract AbstractRestWsConfiguration getConfiguration();

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.HttpCPInfo#getConnectionPoolInfo()
     */
    @Override
    public String getConnectionPoolInfo() {
        final String pattern = "Max = %d ; On Going = %d ; Pending = %d ; Available = %d";
        if (this.cpController != null) {
            final PoolStats poolStats = this.cpController.getTotalStats();
            return String.format(pattern, poolStats.getMax(), poolStats.getLeased(), poolStats.getPending(), poolStats.getAvailable());
        }
        return "The connection pool is not configured";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.HttpCPInfo#getConnTimeToLive()
     */
    @Override
    public long getConnTimeToLive() {
        return this.getConfiguration().getConnTimeToLive();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.HttpCPInfo#getDefaultConnectTimeOut()
     */
    @Override
    public long getDefaultConnectTimeOut() {
        return this.getConfiguration().getConnectTimeout();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.HttpCPInfo#getDefaultReadTimeOut()
     */
    @Override
    public long getDefaultReadTimeOut() {
        return this.getConfiguration().getReadTimeout();
    }

    /**
     * Initialize rest template.
     *
     * @return the rest template
     */
    @PostConstruct
    protected void initRestTemplate() {
        final AbstractRestWsConfiguration configuration = this.getConfiguration();

        this.restTemplate = new RestTemplate(this.getClientHttpRequestFactory(configuration));
        this.restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        this.restTemplate.getMessageConverters().add(new StringHttpMessageConverter());

        this.logServiceConfig(LOG, null, configuration);
    }

    /**
     * Checks if is response ok.
     *
     * @param entry the key
     * @param ret the ret
     * @return true, if is response ok
     */
    protected boolean isResponseOk(final IdentifiedEntry entry, final T ret) {
        return ret != null;
    }

    /**
     * Log service config.
     *
     * @param logger the logger
     * @param url the url
     * @param config the config
     */
    protected void logServiceConfig(final Logger logger, final String url, final IWsConfiguration config) {
        LOG.info(StringUtil.printWebServiceInfo(config));
    }

    /**
     * Send.
     *
     * @param entry the key
     * @param url the url
     * @param message the message
     * @param readTimeOut the read time out
     * @param clazz the clazz
     * @return true, if successful
     */
    protected T send(final IdentifiedEntry entry, final String url, final Object message, final int readTimeOut, final Class<T> clazz) {
        try {
            ((HttpComponentsClientHttpRequestFactory) this.restTemplate.getRequestFactory()).setReadTimeout(readTimeOut);
            return this.restTemplate.postForObject(url, message, clazz);
        }
        catch (final Exception e) {
            LOG.warn(IndexMaker.index(entry), "There is error when transfer [" + this.getConfiguration().getServiceName() + "].", e);
        }
        return null;
    }

    /**
     * Send cascade.
     *
     * @param entry the key
     * @param message the message
     * @param returnClazz the return clazz
     * @return the t
     */
    protected T sendCascade(final IdentifiedEntry entry, final Object message, final Class<T> returnClazz) {
        return this.sendCascade(entry, message, returnClazz, this.getConfiguration().getServiceUrl());
    }

    /**
     * Send cascade.
     *
     * @param entry the entry
     * @param message the message
     * @param returnClazz the return clazz
     * @param serviceUrl the service url
     * @return the t
     */
    protected T sendCascade(final IdentifiedEntry entry, final Object message, final Class<T> returnClazz, final String serviceUrl) {

        T ret = null;
        int readTimeout = this.getConfiguration().getReadTimeout();
        final int maxRetryTimes = this.getConfiguration().getRetryTime();

        try {
            int i = -1;

            LOG.info("Transfer data to {} service at url {}", this.getConfiguration().getServiceName(), serviceUrl);
            while (i < this.getConfiguration().getRetryTime()) {
                // For each repeated transfering, the readtimeout is added to additional amount
                readTimeout += this.getConfiguration().getAdditionalReadTimeout() * (i + 1);
                ret = this.send(entry, serviceUrl, message, readTimeout, returnClazz);
                if (!this.isResponseOk(entry, ret)) {
                    i++;
                    this.checkRetryTime(entry, maxRetryTimes, i, this.getConfiguration().getRetryIntervalTime());
                }
                else {
                    break;
                }
            }
        }
        catch (final Exception e) {
            LOG.error("Error occurs while trying to transfer data", e);
        }

        return ret;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.HttpCPInfo#setMaxPerRoute(int)
     */
    @Override
    public void setMaxPerRoute(final int max) {
        Assert.isTrue(max > 0, "Max connection per route must be greater than 0");
        if (this.cpController != null) {
            this.cpController.setDefaultMaxPerRoute(max);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.HttpCPInfo#setMaxTotal(int)
     */
    @Override
    public void setMaxTotal(final int max) {
        Assert.isTrue(max > 0, "Max connection must be greater than 0");
        if (this.cpController != null) {
            this.cpController.setMaxTotal(max);
        }
    }
}
