/*
 * Class: IParcelStateHandlerContext
 *
 * Created on Jul 4, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.parcel.handers;

import java.util.List;
import java.util.concurrent.ExecutionException;

import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.config.filtering.IMatchingConfig;
import vn.sps.aba.dds.config.service.interfaces.IParcelInfoServiceConfiguration;
import vn.sps.aba.dds.processor.parcel.filtering.IParcelInfoFilterer;

/**
 * The Interface IParcelStateHandlerContext.
 */
public interface IParcelStateHandlerContext extends IMatchingConfig, IParcelInfoServiceConfiguration {

    /**
     * Find one.
     *
     * @param identCode the ident code
     * @return the receiver info
     */
    ReceiverInfo findOne(String identCode);

    /**
     * Find receiver info by ident code.
     *
     * @param identCode the ident code
     * @return the list
     */
    List<ReceiverInfo> findByIdentCode(String identCode);

    /**
     * Gets the parcel info filterer.
     *
     * @return the parcel info filterer
     */
    IParcelInfoFilterer getParcelInfoFilterer();

    /**
     * Handle.
     *
     * @param stateName            the state
     * @param parcelInfo            the parcel info
     * @throws InterruptedException the interrupted exception
     * @throws ExecutionException the execution exception
     */
    void handle(String stateName, ParcelInfo parcelInfo) throws InterruptedException, ExecutionException;

    /**
     * Submit blackbox.
     *
     * @param parcelInfo the parcel info
     */
    void submitBlackbox(ParcelInfo parcelInfo);

    /**
     * Submit capture result.
     *
     * @param parcelInfo the parcel info
     */
    void submitCaptureResult(ParcelInfo parcelInfo);

    /**
     * Submit dmc.
     *
     * @param parcelInfo the parcel info
     */
    void submitDmc(ParcelInfo parcelInfo);

    /**
     * Transmit state.
     *
     * @param parcelInfo the parcel info
     * @param targetState the target state
     */
    void transmitState(final ParcelInfo parcelInfo, final ParcelState targetState);

    /**
     * Update parcel info.
     *
     * @param parcelInfo
     *            the parcel info
     */
    void updateParcelInfo(ParcelInfo parcelInfo);

    /**
     * Update parcel info.
     *
     * @param parcelInfo            the parcel info
     * @param updatedState the updated state
     */
    void updateParcelInfo(final ParcelInfo parcelInfo, final ParcelState updatedState);
}