/*
 * Class: GenericValidator
 *
 * Created on Jun 13, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vn.sps.aba.dds.service.validation.model.IValidationResult;
import vn.sps.aba.dds.service.validation.model.ValidationResult;

/**
 * The Class GenericReceiverInfoValidator.
 *
 * @param <T> the generic type
 * @param <R> the generic type
 */
public abstract class AbstractGenericValidator<T, R extends ValidationResult> implements IGenericValidator<T, R> {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(AbstractGenericValidator.class);

    /** The class. */
    private final Class<?> clazz;

    /** The next validator. */
    protected IGenericValidator<T, R> nextValidator;

    /**
     * Constructs a new <tt>AbstractGenericValidator</tt>.
     *
     * @param clazz the class
     */
    public AbstractGenericValidator(final Class<?> clazz) {
        this.clazz = clazz;
    }

    /**
     * Gets the message.
     *
     * @return the message
     */
    protected abstract String getMessage();

    /**
     * Gets the response code.
     *
     * @return the response code
     */
    protected abstract int getResponseCode();

    /**
     * Checks if is passed.
     *
     * @param entry the entry
     * @return true, if is passed
     */
    protected abstract boolean isPassed(final T entry);

    /**
     * Sets the next validator.
     *
     * @param nextValidator The nextValidator to set.
     */
    @Override
    public void setNextValidator(final IGenericValidator<T, R> nextValidator) {
        this.nextValidator = nextValidator;
    }

    /**
     * Process.
     *
     * @param entry the entry
     * @return the i validation result
     */
    @SuppressWarnings("unchecked")
    @Override
    public IValidationResult validate(final T entry) {
        if (this.isPassed(entry)) {
            if (this.nextValidator != null) {
                return this.nextValidator.validate(entry);
            }
            else {
                return null;
            }
        }
        else {
            R result = null;
            try {
                result = (R) this.clazz.newInstance();
                if (result != null) {
                    result.setResponseCode(this.getResponseCode());
                    result.setMessage(this.getMessage());
                }
            }
            catch (final InstantiationException | IllegalAccessException e) {
                LOG.error(e.getMessage(), e);
            }

            return result;
        }
    }

}
