
package vn.sps.aba.dds.common.types.ws.vae.blackbox;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SubmitCaptureRequestResult" type="{http://schemas.datacontract.org/2004/07/DisCoService}CaptureRequestResponse" minOccurs="0" form="qualified"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "submitCaptureRequestResult"
})
@XmlRootElement(name = "SubmitCaptureRequestResponse", namespace = "http://tempuri.org/")
public class SubmitCaptureRequestResponse {

    @XmlElementRef(name = "SubmitCaptureRequestResult", namespace = "http://tempuri.org/", type = JAXBElement.class, required = false)
    protected JAXBElement<CaptureRequestResponse> submitCaptureRequestResult;

    /**
     * Gets the value of the submitCaptureRequestResult property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CaptureRequestResponse }{@code >}
     *     
     */
    public JAXBElement<CaptureRequestResponse> getSubmitCaptureRequestResult() {
        return submitCaptureRequestResult;
    }

    /**
     * Sets the value of the submitCaptureRequestResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CaptureRequestResponse }{@code >}
     *     
     */
    public void setSubmitCaptureRequestResult(JAXBElement<CaptureRequestResponse> value) {
        this.submitCaptureRequestResult = value;
    }

}
