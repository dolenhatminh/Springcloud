@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/padasadatenresponse", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package vn.sps.aba.dds.common.types.ws.padasa.matchmakerdaten.model;
