
package vn.sps.aba.dds.common.types.ws.pds.parcel.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ParcelCodingInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ParcelCodingInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CodingArt" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CodingQuality" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ParcelCodingInfo", propOrder = {
    "codingArt",
    "codingQuality"
})
public class ParcelCodingInfo {

    @XmlElement(name = "CodingArt", required = true, nillable = true)
    protected String codingArt;
    @XmlElement(name = "CodingQuality", required = true, nillable = true)
    protected String codingQuality;

    /**
     * Gets the value of the codingArt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodingArt() {
        return codingArt;
    }

    /**
     * Sets the value of the codingArt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodingArt(String value) {
        this.codingArt = value;
    }

    /**
     * Gets the value of the codingQuality property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodingQuality() {
        return codingQuality;
    }

    /**
     * Sets the value of the codingQuality property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodingQuality(String value) {
        this.codingQuality = value;
    }

}
