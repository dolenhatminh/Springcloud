/*
 * Class: RuleLoader
 *
 * Created on Jun 21, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.filtering.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.types.exception.UnsupportedAttributeException;
import vn.sps.aba.dds.common.types.filterrule.FilterRule;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.filtering.IMatchingConfig;
import vn.sps.aba.dds.processor.parcel.filtering.IParcelInfoFilterer;
import vn.sps.aba.dds.processor.parcel.filtering.impl.DefaultParcelInfoFilter;
import vn.sps.aba.dds.repository.cache.interfaces.IParcelInfoCacheDao;
import vn.sps.aba.dds.service.lookup.asdp.IAsdpLookupService;

/**
 * The Class FilteringRuleConfiguration.
 */
@Configuration
@ConfigurationProperties(prefix = "rules")
@Profile(Profiles.PARCEL)
public class FilteringRuleConfiguration implements IMatchingConfig {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(FilteringRuleConfiguration.class);

    /** The asdp lookup service. */
    @Autowired
    private IAsdpLookupService asdpLookupService;

    /** The default status after filter. */
    private ParcelState defaultStatusAfterFilter;

    /** The filter rules. */
    private List<FilterRule> filterRules = new ArrayList<>();

    /** The matched states. */
    private List<String> matchedStates = new ArrayList<>();

    /** The parcel info dao. */
    @Autowired
    private IParcelInfoCacheDao parcelInfoDao;

    /** The parcel info filterer. */
    private IParcelInfoFilterer parcelInfoFilterer;

    /**
     * Gets the default status after filter.
     *
     * @return the default status after filter
     */
    @Override
    public ParcelState getDefaultStatusAfterFilter() {
        return this.defaultStatusAfterFilter;
    }

    /**
     * Gets the filter rules.
     *
     * @return Returns the filterRules.
     */
    public List<FilterRule> getFilterRules() {
        return this.filterRules;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.filtering.IMatchingConfig#getMatchedStates()
     */
    @Override
    public List<String> getMatchedStates() {
        return this.matchedStates;
    }

    /**
     * Gets the parcel info filterer.
     *
     * @return the parcel info filterer
     */
    public IParcelInfoFilterer getParcelInfoFilterer() {
        return this.parcelInfoFilterer;
    }

    /**
     * Load config.
     */
    @PostConstruct
    protected void initialize() {
        LOG.info("Receiver matching states: {}", this.matchedStates.toString());

        // Note: Why initialize the process manager here? Why dont we use @PostContruct to initialize the bean?
        //      When the filter rules are changed by web monitor. DDS-Core will call /refresh method to re-initialize the @Configuration beans. And right after that, the @PostContruct of those beans will be executed
        //      So, this will re-initialize the process manager to create the filtering chain

        // Note: The data should be stopped before update the filter rules. Unless the calling to this.parcelInfoFilterer will return incorrect value
        // 
        LOG.info("Initialize the filtering chain");
        this.parcelInfoFilterer = new DefaultParcelInfoFilter();

        if (this.getFilterRules().size() > 0) {

            final List<IParcelInfoFilterer> filters = new ArrayList<>();
            filters.add(this.parcelInfoFilterer);

            for (final FilterRule filterRule : this.getFilterRules()) {

                if (filterRule.isActive()) {

                    final IParcelInfoFilterer nextHandler = new DefaultParcelInfoFilter(filterRule, this.asdpLookupService, this.parcelInfoDao);

                    filters.get(filters.size() - 1).setNextHandler(nextHandler);
                    filters.add(nextHandler);
                    LOG.info("  [Actived] {}", filterRule.toString());
                }
                else {

                    LOG.info("[Inactived] {}", filterRule.toString());
                }
            }
        }
        StringUtil.assertEnum(ReceiverState.class, matchedStates.toArray(new String[matchedStates.size()]));
    }

    /**
     * Sets the default status after filter.
     *
     * @param defaultStatusAfterFilter
     *            the new default status after filter
     */
    public void setDefaultStatusAfterFilter(final ParcelState defaultStatusAfterFilter) {
        this.defaultStatusAfterFilter = defaultStatusAfterFilter;
    }

    /**
     * Sets the default status after filter.
     *
     * @param defaultStatusAfterFilter
     *            the new default status after filter
     * @throws UnsupportedAttributeException
     *             the unsupported attribute exception
     */
    public void setDefaultStatusAfterFilter(final String defaultStatusAfterFilter) throws UnsupportedAttributeException {
        this.defaultStatusAfterFilter = ParcelState.valueOf(defaultStatusAfterFilter);
    }

    /**
     * Sets the filter rules.
     *
     * @param filterRules
     *            The filterRules to set.
     */
    public void setFilterRules(final List<FilterRule> filterRules) {
        this.filterRules = filterRules;
    }

    /**
     * Sets the matched states.
     *
     * @param matchedStates the new matched states
     */
    public void setMatchedStates(final List<String> matchedStates) {
        this.matchedStates = matchedStates;
    }

}
