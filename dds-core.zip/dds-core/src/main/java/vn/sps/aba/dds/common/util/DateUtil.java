/*
 * Class: DateUtil
 *
 * Created on Jun 23, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.util;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import vn.sps.aba.dds.common.time.DiscoWallClock;

/**
 * The Class DateUtil.
 */
public final class DateUtil {

    /**
     * Current date.
     *
     * @param zoneId the zone id
     * @return the local date
     */
    public static LocalDate currentDate(final ZoneId zoneId) {
        return LocalDate.now(zoneId);
    }

    /**
     * Current date as string.
     *
     * @param pattern the pattern
     * @return the string
     */
    public static String currentDateAsString(final String pattern) {
        return LocalDate.now(DiscoWallClock.zone()).format(DateTimeFormatter.ofPattern(pattern));
    }

    /**
     * Current time stamp as string.
     *
     * @param pattern
     *            the pattern
     * @return the string
     */
    public static String currentTimeStampAsString(final String pattern) {
        return DateTimeFormatter.ofPattern(pattern).format(LocalDateTime.now(DiscoWallClock.zone()));
    }

    /**
     * Gregorian2 string.
     *
     * @param gregorianCalendar
     *            the gregorian calendar
     * @return the string
     */
    public static String gregorian2String(final XMLGregorianCalendar gregorianCalendar) {
        return gregorianCalendar == null ? null : gregorianCalendar.toXMLFormat();
    }

    /**
     * Gregorian2 string.
     *
     * @param timeStamp the time stamp
     * @param pattern the pattern
     * @return the string
     */
    public static String gregorian2String(final XMLGregorianCalendar timeStamp, final String pattern) {
        return DateTimeFormatter.ofPattern(pattern).format(timeStamp.toGregorianCalendar().toZonedDateTime());
    }

    /**
     * Gregorian2 timestamp.
     *
     * @param gregorianTimeStamp
     *            the gregorian time stamp
     * @return the timestamp
     */
    public static Timestamp gregorian2Timestamp(final XMLGregorianCalendar gregorianTimeStamp) {
        return gregorianTimeStamp == null ? null : Timestamp.from(gregorianTimeStamp.toGregorianCalendar().toInstant());
    }

    /**
     * Local date time2 epoch millis.
     *
     * @param fromTime the from time
     * @param zoneId the zone id
     * @return the long
     */
    public static long localDateTime2EpochMillis(final LocalDateTime fromTime, final ZoneId zoneId) {
        return fromTime.atZone(zoneId).toInstant().toEpochMilli();
    }

    /**
     * Local date time2 gregorian calendar.
     *
     * @param localDateTime the local date time
     * @return the XML gregorian calendar
     * @throws DatatypeConfigurationException the datatype configuration exception
     */
    private static XMLGregorianCalendar localDateTime2GregorianCalendar(final LocalDateTime localDateTime) throws DatatypeConfigurationException {
        return DatatypeFactory.newInstance().newXMLGregorianCalendar(localDateTime.format(DateTimeFormatter.ISO_DATE_TIME));
    }

    /**
     * Time stamp2 local date time.
     *
     * @param localDateTime
     *            the local date time
     * @return the timestamp
     */
    public static Timestamp localDateTime2Timestamp(final LocalDateTime localDateTime) {
        return localDateTime == null ? null : Timestamp.valueOf(localDateTime);
    }

    /**
     * Local date time from.
     *
     * @param value the value
     * @param pattern the pattern
     * @return the local date time
     */
    public static LocalDateTime localDateTimeFrom(final String value, final String pattern) {
        return value == null || pattern == null ? null : LocalDateTime.parse(value, DateTimeFormatter.ofPattern(pattern));
    }

    /**
     * Milli2 gregorian calendar.
     *
     * @param epochMilli the epoch milli
     * @return the XML gregorian calendar
     * @throws DatatypeConfigurationException the datatype configuration exception
     */
    public static XMLGregorianCalendar milli2GregorianCalendar(final long epochMilli) throws DatatypeConfigurationException {
        final LocalDateTime localDateTime = milli2LocalDateTime(epochMilli);
        return localDateTime == null ? null : localDateTime2GregorianCalendar(localDateTime);
    }

    /**
     * Milli2 local date time.
     *
     * @param epochMilli the epoch milli
     * @return the local date time
     */
    public static LocalDateTime milli2LocalDateTime(final long epochMilli) {
        return epochMilli <= 0 ? null : LocalDateTime.ofInstant(Instant.ofEpochMilli(epochMilli), DiscoWallClock.zone());
    }

    /**
     * Milli time2 timestamp.
     *
     * @param epochMilli the epoch milli
     * @return the timestamp
     */
    public static Timestamp milliTime2Timestamp(final long epochMilli) {
        return epochMilli <= 0 ? null : Timestamp.valueOf(LocalDateTime.ofInstant(Instant.ofEpochMilli(epochMilli), DiscoWallClock.zone()));
    }

    /**
     * String2 gregorian.
     *
     * @param gregorianString the gregorian string
     * @return the XML gregorian calendar
     * @throws DatatypeConfigurationException the datatype configuration exception
     */
    public static XMLGregorianCalendar string2Gregorian(final String gregorianString) throws DatatypeConfigurationException {
        return gregorianString == null ? null : DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianString);
    }

    /**
     * Time stamp2 gregorian date.
     *
     * @param timeStamp
     *            the time stamp
     * @return the XML gregorian calendar
     * @throws DatatypeConfigurationException
     *             the datatype configuration exception
     */
    public static XMLGregorianCalendar timeStamp2GregorianDate(final Timestamp timeStamp) throws DatatypeConfigurationException {
        return timeStamp == null ? null : DateUtil.milli2GregorianCalendar(timeStamp.getTime());
    }

    /**
     * Timestamp2 local date time.
     *
     * @param timestamp
     *            the timestamp
     * @return the local date time
     */
    public static LocalDateTime timestamp2LocalDateTime(final Timestamp timestamp) {
        return timestamp == null ? null : timestamp.toLocalDateTime();
    }

    /**
     * Timestamp2 mili time.
     *
     * @param timestamp the timestamp
     * @return the long
     */
    public static long timestamp2MilliTime(final Timestamp timestamp) {
        return timestamp == null ? 0 : timestamp.toInstant().toEpochMilli();
    }

    /**
     * Constructs a new <tt>DateUtil</tt>.
     */
    private DateUtil() {
    }
}
