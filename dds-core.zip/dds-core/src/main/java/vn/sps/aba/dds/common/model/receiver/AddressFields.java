/*
 * Class: AddressFields
 *
 * Created on Jul 8, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.receiver;

import java.io.Serializable;

import vn.sps.aba.dds.common.types.ws.dpm.model.AddressFieldsType;
import vn.sps.aba.dds.common.util.JaxbUtil;
import vn.sps.aba.dds.common.util.StringUtil;

/**
 * The Class AddressFields.
 */
public class AddressFields implements Serializable {

    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 7621088037967711729L;

    /**
     * The adress zusatz.
     */
    private String adressZusatz;

    /**
     * The anrede.
     */
    private String anrede;

    /**
     * The co adress.
     */
    private String coAdress;

    /**
     * The dienstleistung.
     */
    private String dienstleistung;

    /**
     * The firme name.
     */
    private String firmeName;

    /**
     * The haus nummer.
     */
    private String hausNummer;

    /**
     * The haus nummer zusatz.
     */
    private String hausNummerZusatz;

    /**
     * The kunden nummer.
     */
    private String kundenNummer;

    /**
     * The laender code.
     */
    private String laenderCode;

    /**
     * The land.
     */
    private String land;

    /**
     * The name.
     */
    private String name;

    /**
     * The name zusatz.
     */
    private String nameZusatz;

    /**
     * The ort.
     */
    private String ort;

    /**
     * The postfach.
     */
    private String postfach;

    /**
     * The postleizahl.
     */
    private String postleizahl;

    /**
     * The stockwerk.
     */
    private String stockwerk;

    /**
     * The strasse.
     */
    private String strasse;

    /**
     * The vorname.
     */
    private String vorname;

    /**
     * Instantiates a new address fields.
     */
    public AddressFields() {
    }

    /**
     * Instantiates a new address fields.
     *
     * @param addressFields the address fields
     */
    public AddressFields(final AddressFieldsType addressFields) {
        this.setAdressZusatz(JaxbUtil.element2String(addressFields.getAdressZusatz()));
        this.setAnrede(JaxbUtil.element2String(addressFields.getAnrede()));
        this.setCoAdress(JaxbUtil.element2String(addressFields.getCoAdresse()));
        this.setDienstleistung(addressFields.getDienstleistung() == null ? null : addressFields.getDienstleistung().getValue().value());
        this.setFirmeName(JaxbUtil.element2String(addressFields.getFirmenname()));
        this.setHausNummer(StringUtil.integer2String(addressFields.getHausnummer()));
        this.setHausNummerZusatz(JaxbUtil.element2String(addressFields.getHausnummerZusatz()));
        this.setKundenNummer(JaxbUtil.element2String(addressFields.getKundennummer()));
        this.setLaenderCode(JaxbUtil.element2String(addressFields.getLaenderCode()));
        this.setLand(JaxbUtil.element2String(addressFields.getLand()));
        this.setName(JaxbUtil.element2String(addressFields.getName()));
        this.setNameZusatz(JaxbUtil.element2String(addressFields.getNameZusatz()));
        this.setOrt(JaxbUtil.element2String(addressFields.getOrt()));
        this.setPostfach(JaxbUtil.element2String(addressFields.getPostfach()));
        this.setPostleizahl(JaxbUtil.element2String(addressFields.getPostleitzahl()));
        this.setStockwerk(JaxbUtil.element2String(addressFields.getStockwerk()));
        this.setStrasse(JaxbUtil.element2String(addressFields.getStrasse()));
        this.setVorname(JaxbUtil.element2String(addressFields.getVorname()));
    }

    /**
     * Instantiates a new address fields.
     *
     * @param addressFields the address fields
     */
    public AddressFields(final vn.sps.aba.dds.common.types.ws.dpmb.AddressFields addressFields) {

        this.setAdressZusatz(addressFields.getAdressZusatz());
        this.setAnrede(addressFields.getAnrede());
        this.setCoAdress(addressFields.getCoAdresse());
        this.setDienstleistung(addressFields.getDienstleistung() == null ? null : addressFields.getDienstleistung().value());
        this.setFirmeName(addressFields.getFirmenname());
        this.setHausNummer(StringUtil.integer2String(addressFields.getHausnummer()));
        this.setHausNummerZusatz(addressFields.getHausnummerZusatz());
        this.setKundenNummer(addressFields.getKundennummer());
        this.setLaenderCode(addressFields.getLaenderCode());
        this.setLand(addressFields.getLand());
        this.setName(addressFields.getName());
        this.setNameZusatz(addressFields.getNameZusatz());
        this.setOrt(addressFields.getOrt());
        this.setPostfach(addressFields.getPostfach());
        this.setPostleizahl(addressFields.getPostleitzahl());
        this.setStockwerk(addressFields.getStockwerk());
        this.setStrasse(addressFields.getStrasse());
        this.setVorname(addressFields.getVorname());
    }

    /**
     * Instantiates a new address fields.
     *
     * @param addressFields the address fields
     */
    public AddressFields(final vn.sps.aba.dds.common.types.ws.dpms.AddressFields addressFields) {

        this.setAdressZusatz(JaxbUtil.element2String(addressFields.getAdressZusatz()));
        this.setAnrede(JaxbUtil.element2String(addressFields.getAnrede()));
        this.setCoAdress(JaxbUtil.element2String(addressFields.getCoAdresse()));
        this.setDienstleistung(JaxbUtil.element2String(addressFields.getDienstleistung()));
        this.setFirmeName(JaxbUtil.element2String(addressFields.getFirmenname()));
        this.setHausNummer(JaxbUtil.element2String(addressFields.getHausnummer()));
        this.setHausNummerZusatz(JaxbUtil.element2String(addressFields.getHausnummerZusatz()));
        this.setKundenNummer(JaxbUtil.element2String(addressFields.getKundennummer()));
        this.setLaenderCode(JaxbUtil.element2String(addressFields.getLaenderCode()));
        this.setLand(JaxbUtil.element2String(addressFields.getLand()));
        this.setName(JaxbUtil.element2String(addressFields.getName()));
        this.setNameZusatz(JaxbUtil.element2String(addressFields.getNameZusatz()));
        this.setOrt(JaxbUtil.element2String(addressFields.getOrt()));
        this.setPostfach(JaxbUtil.element2String(addressFields.getPostfach()));
        this.setPostleizahl(JaxbUtil.element2String(addressFields.getPostleitzahl()));
        this.setStockwerk(JaxbUtil.element2String(addressFields.getStockwerk()));
        this.setStrasse(JaxbUtil.element2String(addressFields.getStrasse()));
        this.setVorname(JaxbUtil.element2String(addressFields.getVorname()));
    }

    /**
     * Instantiates a new address fields.
     *
     * @param addressFields the address fields
     */
    public AddressFields(final vn.sps.aba.dds.common.types.ws.vam.capturing.model.AddressFields addressFields) {

        this.setAdressZusatz(JaxbUtil.element2String(addressFields.getAdressZusatz()));
        this.setAnrede(JaxbUtil.element2String(addressFields.getAnrede()));
        this.setCoAdress(JaxbUtil.element2String(addressFields.getCoAdresse()));
        this.setDienstleistung(addressFields.getDienstleistung() == null ? null : addressFields.getDienstleistung().getValue().value());
        this.setFirmeName(JaxbUtil.element2String(addressFields.getFirmenname()));
        this.setHausNummer(StringUtil.integer2String(addressFields.getHausnummer()));
        this.setHausNummerZusatz(JaxbUtil.element2String(addressFields.getHausnummerZusatz()));
        this.setKundenNummer(JaxbUtil.element2String(addressFields.getKundennummer()));
        this.setLaenderCode(JaxbUtil.element2String(addressFields.getLaenderCode()));
        this.setLand(JaxbUtil.element2String(addressFields.getLand()));
        this.setName(JaxbUtil.element2String(addressFields.getName()));
        this.setNameZusatz(JaxbUtil.element2String(addressFields.getNameZusatz()));
        this.setOrt(JaxbUtil.element2String(addressFields.getOrt()));
        this.setPostfach(JaxbUtil.element2String(addressFields.getPostfach()));
        this.setPostleizahl(JaxbUtil.element2String(addressFields.getPostleitzahl()));
        this.setStockwerk(JaxbUtil.element2String(addressFields.getStockwerk()));
        this.setStrasse(JaxbUtil.element2String(addressFields.getStrasse()));
        this.setVorname(JaxbUtil.element2String(addressFields.getVorname()));
    }
    
  /* public AddressFields (final vn.sps.aba.dds.common.types.ws.vae.blackbox.AddressFields addressFields) {
    	 this.setAdressZusatz(JaxbUtil.element2String(addressFields.getAdressZusatz()));
         this.setAnrede(JaxbUtil.element2String(addressFields.getAnrede()));
         this.setCoAdress(JaxbUtil.element2String(addressFields.getCoAdresse()));
         this.setDienstleistung(addressFields.getDienstleistung() == null ? null : addressFields.getDienstleistung().getValue().value());
         this.setFirmeName(JaxbUtil.element2String(addressFields.getFirmenname()));
         this.setHausNummer(StringUtil.integer2String(addressFields.getHausnummer()));
         this.setHausNummerZusatz(JaxbUtil.element2String(addressFields.getHausnummerZusatz()));
         this.setKundenNummer(JaxbUtil.element2String(addressFields.getKundennummer()));
         this.setLaenderCode(JaxbUtil.element2String(addressFields.getLaenderCode()));
         this.setLand(JaxbUtil.element2String(addressFields.getLand()));
         this.setName(JaxbUtil.element2String(addressFields.getName()));
         this.setNameZusatz(JaxbUtil.element2String(addressFields.getNameZusatz()));
         this.setOrt(JaxbUtil.element2String(addressFields.getOrt()));
         this.setPostfach(JaxbUtil.element2String(addressFields.getPostfach()));
         this.setPostleizahl(JaxbUtil.element2String(addressFields.getPostleitzahl()));
         this.setStockwerk(JaxbUtil.element2String(addressFields.getStockwerk()));
         this.setStrasse(JaxbUtil.element2String(addressFields.getStrasse()));
         this.setVorname(JaxbUtil.element2String(addressFields.getVorname()));
	}*/

    /**
     * Gets the adress zusatz.
     *
     * @return the adress zusatz
     */
    public String getAdressZusatz() {
        return this.adressZusatz;
    }

    /**
     * Gets the anrede.
     *
     * @return the anrede
     */
    public String getAnrede() {
        return this.anrede;
    }

    /**
     * Gets the co adress.
     *
     * @return the co adress
     */
    public String getCoAdress() {
        return this.coAdress;
    }

    /**
     * Gets the dienstleistung.
     *
     * @return the dienstleistung
     */
    public String getDienstleistung() {
        return this.dienstleistung;
    }

    /**
     * Gets the firme name.
     *
     * @return the firme name
     */
    public String getFirmeName() {
        return this.firmeName;
    }

    /**
     * Gets the haus nummer.
     *
     * @return the haus nummer
     */
    public String getHausNummer() {
        return this.hausNummer;
    }

    /**
     * Gets the haus nummer zusatz.
     *
     * @return the haus nummer zusatz
     */
    public String getHausNummerZusatz() {
        return this.hausNummerZusatz;
    }

    /**
     * Gets the kunden nummer.
     *
     * @return the kunden nummer
     */
    public String getKundenNummer() {
        return this.kundenNummer;
    }

    /**
     * Gets the laender code.
     *
     * @return the laender code
     */
    public String getLaenderCode() {
        return this.laenderCode;
    }

    /**
     * Gets the land.
     *
     * @return the land
     */
    public String getLand() {
        return this.land;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Gets the name zusatz.
     *
     * @return the name zusatz
     */
    public String getNameZusatz() {
        return this.nameZusatz;
    }

    /**
     * Gets the ort.
     *
     * @return the ort
     */
    public String getOrt() {
        return this.ort;
    }

    /**
     * Gets the postfach.
     *
     * @return the postfach
     */
    public String getPostfach() {
        return this.postfach;
    }

    /**
     * Gets the postleizahl.
     *
     * @return the postleizahl
     */
    public String getPostleizahl() {
        return this.postleizahl;
    }

    /**
     * Gets the stockwerk.
     *
     * @return the stockwerk
     */
    public String getStockwerk() {
        return this.stockwerk;
    }

    /**
     * Gets the strasse.
     *
     * @return the strasse
     */
    public String getStrasse() {
        return this.strasse;
    }

    /**
     * Gets the vorname.
     *
     * @return the vorname
     */
    public String getVorname() {
        return this.vorname;
    }

    /**
     * Sets the adress zusatz.
     *
     * @param adressZusatz the new adress zusatz
     */
    public void setAdressZusatz(final String adressZusatz) {
        this.adressZusatz = adressZusatz;
    }

    /**
     * Sets the anrede.
     *
     * @param anrede the new anrede
     */
    public void setAnrede(final String anrede) {
        this.anrede = anrede;
    }

    /**
     * Sets the co adress.
     *
     * @param coAdress the new co adress
     */
    public void setCoAdress(final String coAdress) {
        this.coAdress = coAdress;
    }

    /**
     * Sets the dienstleistung.
     *
     * @param dienstleistung the new dienstleistung
     */
    public void setDienstleistung(final String dienstleistung) {
        this.dienstleistung = dienstleistung;
    }

    /**
     * Sets the firme name.
     *
     * @param firmeName the new firme name
     */
    public void setFirmeName(final String firmeName) {
        this.firmeName = firmeName;
    }

    /**
     * Sets the haus nummer.
     *
     * @param hausNummer the new haus nummer
     */
    public void setHausNummer(final String hausNummer) {
        this.hausNummer = hausNummer;
    }

    /**
     * Sets the haus nummer zusatz.
     *
     * @param hausNummerZusatz the new haus nummer zusatz
     */
    public void setHausNummerZusatz(final String hausNummerZusatz) {
        this.hausNummerZusatz = hausNummerZusatz;
    }

    /**
     * Sets the kunden nummer.
     *
     * @param kundenNummer the new kunden nummer
     */
    public void setKundenNummer(final String kundenNummer) {
        this.kundenNummer = kundenNummer;
    }

    /**
     * Sets the laender code.
     *
     * @param laenderCode the new laender code
     */
    public void setLaenderCode(final String laenderCode) {
        this.laenderCode = laenderCode;
    }

    /**
     * Sets the land.
     *
     * @param land the new land
     */
    public void setLand(final String land) {
        this.land = land;
    }

    /**
     * Sets the name.
     *
     * @param name the new name
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * Sets the name zusatz.
     *
     * @param nameZusatz the new name zusatz
     */
    public void setNameZusatz(final String nameZusatz) {
        this.nameZusatz = nameZusatz;
    }

    /**
     * Sets the ort.
     *
     * @param ort the new ort
     */
    public void setOrt(final String ort) {
        this.ort = ort;
    }

    /**
     * Sets the postfach.
     *
     * @param postfach the new postfach
     */
    public void setPostfach(final String postfach) {
        this.postfach = postfach;
    }

    /**
     * Sets the postleizahl.
     *
     * @param postleizahl the new postleizahl
     */
    public void setPostleizahl(final String postleizahl) {
        this.postleizahl = postleizahl;
    }

    /**
     * Sets the stockwerk.
     *
     * @param stockwerk the new stockwerk
     */
    public void setStockwerk(final String stockwerk) {
        this.stockwerk = stockwerk;
    }

    /**
     * Sets the strasse.
     *
     * @param strasse the new strasse
     */
    public void setStrasse(final String strasse) {
        this.strasse = strasse;
    }

    /**
     * Sets the vorname.
     *
     * @param vorname the new vorname
     */
    public void setVorname(final String vorname) {
        this.vorname = vorname;
    }

}
