/*
 * Class: AbstractScheduledSender
 *
 * Created on Oct 12, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;

import vn.sps.aba.dds.jmx.ScheduledTaskInfo;

/**
 * The Class AbstractScheduledSender.
 */
public abstract class AbstractCronScheduler implements ScheduledTaskInfo, DisposableBean {

    /** The cron. */
    private String cron;

    /** The enable. */
    private boolean enable = true;

    /** The schedule configurar. */
    @Autowired
    protected DdsScheduleConfigurar scheduleConfigurar;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ScheduledTaskInfo#emptyQueue(java.lang.String)
     */
    @Override
    public int emptyQueue(final String key) {
        return 0;
    }

    /**
     * Gets the cron.
     *
     * @return the cron
     */
    protected String getCron() {
        return this.cron;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ScheduledTaskInfo#getCronExpression()
     */
    @Override
    public String getCronExpression() {
        return this.cron;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ScheduledTaskInfo#getNumberOfRemainItems()
     */
    @Override
    public int getNumberOfRemainItems() {
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ScheduledTaskInfo#getTaskName()
     */
    @Override
    public String getTaskName() {
        return this.taskName();
    }

    /**
     * Checks if is enable.
     *
     * @return true, if is enable
     */
    protected boolean isEnable() {
        return this.enable;
    }

    /**
     * Sets the cron.
     *
     * @param cron the new cron
     */
    public void setCron(final String cron) {
        this.cron = cron;
    }

    /**
     * Sets the enable.
     *
     * @param enable the new enable
     */
    @Override
    public void setEnable(final boolean enable) {
        this.enable = enable;
    }

    /**
     * Task name.
     *
     * @return the string
     */
    protected abstract String taskName();
}
