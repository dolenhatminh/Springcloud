/*
 * Class: IVerifiedRuleConfiguration
 *
 * Created on Jul 24, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.config.filtering;

import java.util.List;

import vn.sps.aba.dds.common.types.verifying.VerifiedRule;

/**
 * The Interface IVerifiedRuleConfiguration.
 */
public interface IVerifiedRuleConfiguration {

    /**
     * Gets the rules.
     *
     * @return the rules
     */
    List<VerifiedRule> getRules();
}