/*
 * Class: CommonController
 *
 * Created on Dec 1, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import vn.sps.aba.dds.Application;
import vn.sps.aba.dds.common.types.report.ApplicationInfo;

/**
 * The Class ManagementController.
 */
@RestController
@RequestMapping("/manage")
public class ManagementController {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ManagementController.class);

    /** The Constant MVN_PROPS. */
    private static final String MVN_PROPS = "/META-INF/maven/vn.sps.aba/dds-core/pom.properties";

    /** The props. */
    private Properties props = null;

    /**
     * Gets the property.
     *
     * @param name the name
     * @return the property
     */
    private String getProperty(final String name) {
        if (this.props == null) {
            this.loadProperties();
        }
        return this.props.getProperty(name);
    }

    /**
     * Info.
     *
     * @return the application info
     */
    @RequestMapping(value = "/info", method = RequestMethod.GET)
    public ApplicationInfo info() {
        final ApplicationInfo ret = new ApplicationInfo();
        {
            ret.setName("DDS-Core");
            ret.setVersion(this.getProperty("version"));
            ret.setGroupId(this.getProperty("groupId"));
            ret.setArtifactId(this.getProperty("artifactId"));
        }
        return ret;
    }

    /**
     * Load properties.
     */
    private void loadProperties() {

        this.props = new Properties();
        try (InputStream is = Application.class.getResourceAsStream(MVN_PROPS)) {
            this.props.load(is);
        }
        catch (final IOException e) {
            LOG.error("Failed to load the properties file", e);
        }
    }
}
