@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.postlogistics.ch/PLDTVG/V10/")
package vn.sps.aba.dds.common.types.ws.dts.model;
