/*
 * Class: ParcelDataProcessor
 *
 * Created on Jun 20, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.parcel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.parcel.filtering.IParcelInfoFilterer;
import vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext;
import vn.sps.aba.dds.processor.parcel.handers.IParcelStepHandler;
import vn.sps.aba.dds.processor.parcel.handers.impl.BlackBoxHandler;
import vn.sps.aba.dds.processor.parcel.handers.impl.DmcSenderHandler;
import vn.sps.aba.dds.processor.parcel.handers.impl.FilteringHandler;
import vn.sps.aba.dds.processor.parcel.handers.impl.InitializingHandler;
import vn.sps.aba.dds.processor.parcel.handers.impl.MatchingHandler;
import vn.sps.aba.dds.processor.parcel.handers.impl.VamCaptureResultHandler;

/**
 * The Class ParcelDataProcessor.
 */
public class ParcelProcessingContext implements IParcelStateHandlerContext {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ParcelProcessingContext.class);

    /** The executor. */
    private final ParcelProcessingManager executor;

    /** The handlers. */
    private final Map<String, IParcelStepHandler> handlers = new HashMap<>();

    /**
     * Instantiates a new parcel info processing handler.
     *
     * @param executor            the executor
     * @param clock the clock
     */
    public ParcelProcessingContext(final ParcelProcessingManager executor) {
        this.executor = executor;
    }

    /**
     * Adds the handler.
     *
     * @param handler
     *            the handler
     */
    public void addHandler(final IParcelStepHandler handler) {
        this.handlers.put(handler.getStateName(), handler);
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext#findByIdentCode(java.lang.String)
     */
    @Override
    public List<ReceiverInfo> findByIdentCode(final String identCode) {
        return this.executor.getReceiverInfoDpmDao().listByIdentCode(identCode);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext#findOne(java.lang.String)
     */
    @Override
    public ReceiverInfo findOne(final String identCode) {
        return this.executor.getReceiverInfoDpmDao().get(identCode);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.filtering.IMatchingConfig#getDefaultStatusAfterFilter()
     */
    @Override
    public ParcelState getDefaultStatusAfterFilter() {
        return this.executor.getRuleLoader().getDefaultStatusAfterFilter();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IParcelInfoServiceConfiguration#getDestinationPattern()
     */
    @Override
    public String getDestinationPattern() {
        return this.executor.getParcelInfoServiceConfiguration().getDestinationPattern();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.filtering.IMatchingConfig#getMatchedStates()
     */
    @Override
    public List<String> getMatchedStates() {
        return this.executor.getRuleLoader().getMatchedStates();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext#getParcelInfoFilterer()
     */
    @Override
    public IParcelInfoFilterer getParcelInfoFilterer() {
        return this.executor.getParcelInfoFilterer();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IParcelInfoServiceConfiguration#getSourcePattern()
     */
    @Override
    public String getSourcePattern() {
        return this.executor.getParcelInfoServiceConfiguration().getSourcePattern();
    }

    /**
     * Handle the core business work flow<br>
     * <p>
     * 1. Filter parcel info according to the predefined rules. Each filterer
     * has specific business handler<br>
     *
     * 2. Post-process parcel data after
     * filtering. This will do the following businesses: + Update the parcel
     * info in to cache + Forward the parcel info to DMC system if necessary
     * </p>
     *
     * @param parcelInfo
     *            the parcel info
     */
    void handle(final ParcelInfo parcelInfo) {

        try {

            parcelInfo.setProcessBegin(DiscoWallClock.milli());

            this.addHandler(new InitializingHandler());
            this.addHandler(new FilteringHandler());
            this.addHandler(new DmcSenderHandler());
            this.addHandler(new MatchingHandler());
            this.addHandler(new VamCaptureResultHandler());
            this.addHandler(new BlackBoxHandler());

            this.handle(IParcelStepHandler.PARCEL_INITIAL_STATE_HANDLER, parcelInfo);
            parcelInfo.setProcessEnd(DiscoWallClock.milli());
            if (ParcelState.NO_FURTHER_PROCESSING == parcelInfo.getParcelState()) {
                this.executor.getParcelInfoDao().store(parcelInfo.getKey(), parcelInfo);
            }
            else {
                this.executor.getParcelInfoDao().put(parcelInfo.getKey(), parcelInfo);
            }
            LOG.info(IndexMaker.index(parcelInfo), "Finished processing parcel");
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.indexes(parcelInfo), "Error occurs while handle the parcel info", e);
        }
    }

    /**
     * {@inheritDoc}
     * @throws ExecutionException
     * @throws InterruptedException
     * @throws Exception
     *
     * @see vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext#handle(java.lang.String,
     *      vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public void handle(final String stateName, final ParcelInfo parcelInfo) throws InterruptedException, ExecutionException {

        final IParcelStepHandler handler = this.handlers.get(stateName);

        if (handler != null) {

            handler.handle(this, parcelInfo);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext#submitBlackbox(vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public void submitBlackbox(final ParcelInfo parcelInfo) {
        this.executor.getBlackBoxSender().submitItem(parcelInfo);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext#submitCaptureResult(vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public void submitCaptureResult(final ParcelInfo parcelInfo) {
        this.executor.getVamSender().submitItem(parcelInfo);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext#submitDmc(vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public void submitDmc(final ParcelInfo parcelInfo) {
        this.executor.getDmcSender().submitItem(parcelInfo);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext#transmitState(vn.sps.aba.dds.common.model.parcel.ParcelInfo, vn.sps.aba.dds.common.constant.Enumeration.ParcelState)
     */
    @Override
    public void transmitState(final ParcelInfo parcelInfo, final ParcelState targetState) {
        this.updateParcelInfo(parcelInfo, targetState);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext#updateParcelInfo(vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public void updateParcelInfo(final ParcelInfo parcelInfo) {
        this.updateParcelInfo(parcelInfo, parcelInfo.getParcelState());
    }

    /**
     * Update parcel info.
     *
     * @param parcelInfo
     *            the parcel info
     * @param updatedStatus
     *            the updated status
     */
    @Override
    public void updateParcelInfo(final ParcelInfo parcelInfo, final ParcelState updatedStatus) {

        parcelInfo.setState(updatedStatus);
        this.executor.getParcelInfoDao().put(parcelInfo.getKey(), parcelInfo);
        LOG.info(IndexMaker.index(parcelInfo), "Parcel info was changed status to {}", parcelInfo.getState());
    }
}
