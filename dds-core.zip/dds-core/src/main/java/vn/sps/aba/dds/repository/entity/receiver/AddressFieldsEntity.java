/*
 * Class: AddressFields
 *
 * Created on Jul 12, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.entity.receiver;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import vn.sps.aba.dds.common.constant.TableNames;
import vn.sps.aba.dds.common.model.receiver.AddressFields;

/**
 * The Class AddressFieldsEntity.
 */
@Entity
@Table(name = TableNames.REC_ADDRESS_FIELDS)
@Access(AccessType.PROPERTY)
public class AddressFieldsEntity implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 4789384072843442503L;

    /** The adress zusatz. */
    private String adressZusatz;

    /** The anrede. */
    private String anrede;

    /** The co adress. */
    private String coAdress;

    /** The dienstleistung. */
    private String dienstleistung;

    /** The firme name. */
    private String firmeName;

    /** The haus nummer. */
    private String hausNummer;

    /** The haus nummer zusatz. */
    private String hausNummerZusatz;

    /** The id. */
    private Long id;

    /** The kunden nummer. */
    private String kundenNummer;

    /** The laender code. */
    private String laenderCode;

    /** The land. */
    private String land;

    /** The name. */
    private String name;

    /** The name zusatz. */
    private String nameZusatz;

    /** The ort. */
    private String ort;

    /** The postfach. */
    private String postfach;

    /** The postleizahl. */
    private String postleizahl;

    /** The stockwerk. */
    private String stockwerk;

    /** The strasse. */
    private String strasse;

    /** The vorname. */
    private String vorname;

    /**
     * Instantiates a new address fields entity.
     */
    public AddressFieldsEntity() {
    }

    /**
     * Instantiates a new address fields entity.
     *
     * @param addressFields
     *            the address fields
     */
    public AddressFieldsEntity(final AddressFields addressFields) {

        this.setAdressZusatz(addressFields.getAdressZusatz());
        this.setAnrede(addressFields.getAnrede());
        this.setCoAdress(addressFields.getCoAdress());
        this.setDienstleistung(addressFields.getDienstleistung());
        this.setFirmeName(addressFields.getFirmeName());
        this.setHausNummer(addressFields.getHausNummer());
        this.setHausNummerZusatz(addressFields.getHausNummerZusatz());
        this.setKundenNummer(addressFields.getKundenNummer());
        this.setLaenderCode(addressFields.getLaenderCode());
        this.setLand(addressFields.getLand());
        this.setName(addressFields.getName());
        this.setNameZusatz(addressFields.getNameZusatz());
        this.setOrt(addressFields.getOrt());
        this.setPostfach(addressFields.getPostfach());
        this.setPostleizahl(addressFields.getPostleizahl());
        this.setStockwerk(addressFields.getStockwerk());
        this.setStrasse(addressFields.getStrasse());
        this.setVorname(addressFields.getVorname());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getAdressZusatz()
     */

    @Column(name = "address_zusatz", length = 255)
    public String getAdressZusatz() {
        return this.adressZusatz;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getAnrede()
     */

    @Column(name = "anrede", length = 100)
    public String getAnrede() {
        return this.anrede;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getCoAdress()
     */

    @Column(name = "co_address", length = 255)
    public String getCoAdress() {
        return this.coAdress;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getDienstleistung()
     */

    @Column(name = "dienstleistung", length = 100)
    public String getDienstleistung() {
        return this.dienstleistung;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getFirmeName()
     */

    @Column(name = "firme_name", length = 255)
    public String getFirmeName() {
        return this.firmeName;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getHausNummer()
     */

    @Column(name = "haus_nummer", length = 100)
    public String getHausNummer() {
        return this.hausNummer;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getHausNummerZusatz()
     */

    @Column(name = "haus_nummber_zusatz", length = 100)
    public String getHausNummerZusatz() {
        return this.hausNummerZusatz;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    @Id
    @SequenceGenerator(name = "rec_address_fields_generator", sequenceName = "rec_address_fields_seq", initialValue = 1, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rec_address_fields_generator")
    @JoinColumn(name = "id", columnDefinition = "bigserial")
    public Long getId() {
        return this.id;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getKundenNummer()
     */

    @Column(name = "kunden_nummer", length = 100)
    public String getKundenNummer() {
        return this.kundenNummer;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getLaenderCode()
     */

    @Column(name = "laender_code", length = 100)
    public String getLaenderCode() {
        return this.laenderCode;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getLand()
     */

    @Column(name = "land", length = 100)
    public String getLand() {
        return this.land;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getName()
     */

    @Column(name = "name", length = 100)
    public String getName() {
        return this.name;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getNameZusatz()
     */

    @Column(name = "name_zusatz", length = 255)
    public String getNameZusatz() {
        return this.nameZusatz;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getOrt()
     */

    @Column(name = "ort", length = 100)
    public String getOrt() {

        return this.ort;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getPostfach()
     */

    @Column(name = "postfach", length = 100)
    public String getPostfach() {

        return this.postfach;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getPostleizahl()
     */

    @Column(name = "postleizahl", length = 100)
    public String getPostleizahl() {

        return this.postleizahl;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getStockwerk()
     */

    @Column(name = "stockwerk", length = 100)
    public String getStockwerk() {

        return this.stockwerk;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getStrasse()
     */

    @Column(name = "strasse", length = 100)
    public String getStrasse() {

        return this.strasse;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.AddressFields#getVorname()
     */

    @Column(name = "vorname", length = 100)
    public String getVorname() {

        return this.vorname;
    }

    /**
     * Sets the adress zusatz.
     *
     * @param adressZusatz
     *            the new adress zusatz
     */
    public void setAdressZusatz(final String adressZusatz) {
        this.adressZusatz = adressZusatz;
    }

    /**
     * Sets the anrede.
     *
     * @param anrede
     *            the new anrede
     */
    public void setAnrede(final String anrede) {
        this.anrede = anrede;
    }

    /**
     * Sets the co adress.
     *
     * @param coAdress
     *            the new co adress
     */
    public void setCoAdress(final String coAdress) {
        this.coAdress = coAdress;
    }

    /**
     * Sets the dienstleistung.
     *
     * @param dienstleistung
     *            the new dienstleistung
     */
    public void setDienstleistung(final String dienstleistung) {
        this.dienstleistung = dienstleistung;
    }

    /**
     * Sets the firme name.
     *
     * @param firmeName
     *            the new firme name
     */
    public void setFirmeName(final String firmeName) {
        this.firmeName = firmeName;
    }

    /**
     * Sets the haus nummer.
     *
     * @param hausNummer
     *            the new haus nummer
     */
    public void setHausNummer(final String hausNummer) {
        this.hausNummer = hausNummer;
    }

    /**
     * Sets the haus nummer zusatz.
     *
     * @param hausNummerZusatz
     *            the new haus nummer zusatz
     */
    public void setHausNummerZusatz(final String hausNummerZusatz) {
        this.hausNummerZusatz = hausNummerZusatz;
    }

    /**
     * Sets the id.
     *
     * @param id
     *            the new id
     */
    public void setId(final Long id) {
        this.id = id;
    }

    /**
     * Sets the kunden nummer.
     *
     * @param kundenNummer
     *            the new kunden nummer
     */
    public void setKundenNummer(final String kundenNummer) {
        this.kundenNummer = kundenNummer;
    }

    /**
     * Sets the laender code.
     *
     * @param laenderCode
     *            the new laender code
     */
    public void setLaenderCode(final String laenderCode) {
        this.laenderCode = laenderCode;
    }

    /**
     * Sets the land.
     *
     * @param land
     *            the new land
     */
    public void setLand(final String land) {
        this.land = land;
    }

    /**
     * Sets the name.
     *
     * @param name
     *            the new name
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * Sets the name zusatz.
     *
     * @param nameZusatz
     *            the new name zusatz
     */
    public void setNameZusatz(final String nameZusatz) {
        this.nameZusatz = nameZusatz;
    }

    /**
     * Sets the ort.
     *
     * @param ort
     *            the new ort
     */
    public void setOrt(final String ort) {
        this.ort = ort;
    }

    /**
     * Sets the postfach.
     *
     * @param postfach
     *            the new postfach
     */
    public void setPostfach(final String postfach) {
        this.postfach = postfach;
    }

    /**
     * Sets the postleizahl.
     *
     * @param postleizahl
     *            the new postleizahl
     */
    public void setPostleizahl(final String postleizahl) {
        this.postleizahl = postleizahl;
    }

    /**
     * Sets the stockwerk.
     *
     * @param stockwerk
     *            the new stockwerk
     */
    public void setStockwerk(final String stockwerk) {
        this.stockwerk = stockwerk;
    }

    /**
     * Sets the strasse.
     *
     * @param strasse
     *            the new strasse
     */
    public void setStrasse(final String strasse) {
        this.strasse = strasse;
    }

    /**
     * Sets the vorname.
     *
     * @param vorname
     *            the new vorname
     */
    public void setVorname(final String vorname) {
        this.vorname = vorname;
    }

}
