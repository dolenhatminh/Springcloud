/*
 * Class: DdsScheduler
 *
 * Created on Nov 2, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.task.scheduler;

import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

/**
 * The Interface DdsScheduler.
 */
public interface DdsScheduler {

    /**
     * Gets the name.
     *
     * @return the name
     */
    String getName();

    /**
     * Gets the scheduler.
     *
     * @return the scheduler
     */
    ThreadPoolTaskScheduler getScheduler();
}