/*
 * Class: VerifiedRuleConfiguration
 *
 * Created on Jul 5, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.filtering.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.constant.Enumeration.VerifiedField;
import vn.sps.aba.dds.common.types.exception.UnsupportedAttributeException;
import vn.sps.aba.dds.common.types.verifying.VerifiedRule;
import vn.sps.aba.dds.config.filtering.IVerifiedRuleConfiguration;

/**
 * The Class VerifiedRuleConfiguration.
 */
@Configuration
@ConfigurationProperties(prefix = "rules.receiverinfo")
@Profile(value = { Profiles.RECEIVER, Profiles.DPM, Profiles.DPMB, Profiles.DPMS })
public class VerifiedRuleConfiguration implements IVerifiedRuleConfiguration {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(VerifiedRuleConfiguration.class);

    /** The rules. */
    private List<VerifiedRule> rules;

    /** The verified rules. */
    private final List<String> verifiedRules = new ArrayList<>();

    /**
     * Gets the rules.
     *
     * @return the rules
     */
    @Override
    public List<VerifiedRule> getRules() {
        return this.rules;
    }

    /**
     * Gets the verified rules.
     *
     * @return the verified rules
     */
    public List<String> getVerifiedRules() {
        return this.verifiedRules;
    }

    /**
     * Initialize.
     *
     * @throws UnsupportedAttributeException
     *             the unsupported attribute exception
     */
    @PostConstruct
    public void initialize() throws UnsupportedAttributeException {

        this.rules = new ArrayList<>();

        for (final String verifiedRule : this.verifiedRules) {

            final VerifiedRule rule = new VerifiedRule(verifiedRule);

            String delimeter = Constant.CHAR_WHITE;
            if (verifiedRule.contains(Constant.CHAR_COMMA)) {

                delimeter = Constant.CHAR_COMMA;
            }

            final String[] parts = verifiedRule.split(delimeter, -2);

            for (String part : parts) {

                part = part.trim();

                if (!part.isEmpty()) {

                    if (!"and".equalsIgnoreCase(part)) {

                        rule.addField(VerifiedField.forName(part));
                    }
                }
            }

            this.rules.add(rule);
        }
        LOG.info("Verified rules: {}", this.verifiedRules);
    }

    /**
     * Prints the verified rule.
     */
    public void printVerifiedRules() {

        LOG.info("---------- Current verified rule ------------");

        for (final VerifiedRule verifiedRule : this.rules) {
            LOG.info(verifiedRule.toString());
        }
    }
}
