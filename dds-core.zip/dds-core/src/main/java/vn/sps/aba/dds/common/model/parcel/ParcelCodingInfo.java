/*
 * Class: ParcelCodingInfo
 *
 * Created on May 19, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.parcel;

import java.io.Serializable;

/**
 * The Class ParcelCodingInfo.
 */
public class ParcelCodingInfo implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 6291341066722797097L;

    /** The coding art. */
    private String codingArt;

    /** The coding quality. */
    private String codingQuality;

    /**
     * Instantiates a new parcel coding info.
     */
    public ParcelCodingInfo() {
    }

    /**
     * Instantiates a new parcel coding info.
     *
     * @param parcelCodingInfo the parcel coding info
     */
    public ParcelCodingInfo(final vn.sps.aba.dds.common.types.ws.pds.parcel.model.ParcelCodingInfo parcelCodingInfo) {
        this.codingArt = parcelCodingInfo.getCodingArt();
        this.codingQuality = parcelCodingInfo.getCodingQuality();
    }

    /**
     * Gets the coding art.
     *
     * @return Returns the codingArt.
     */
    public String getCodingArt() {
        return this.codingArt;
    }

    /**
     * Gets the coding quality.
     *
     * @return Returns the codingQuality.
     */
    public String getCodingQuality() {
        return this.codingQuality;
    }

    /**
     * Sets the coding art.
     *
     * @param codingArt The codingArt to set.
     */
    public void setCodingArt(final String codingArt) {
        this.codingArt = codingArt;
    }

    /**
     * Sets the coding quality.
     *
     * @param codingQuality The codingQuality to set.
     */
    public void setCodingQuality(final String codingQuality) {
        this.codingQuality = codingQuality;
    }

}
