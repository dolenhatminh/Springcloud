/*
 * Class: ParcelCounter
 *
 * Created on Jul 28, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.pds.counter.impl;

import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.service.pds.counter.IParcelCounter;

/**
 * The Class ParcelCounter.
 */
@Component
@Profile(Profiles.PARCEL)
public class ParcelCounter implements IParcelCounter {

    /** The counter. */
    private final AtomicLong counter;

    /** The date. */
    private LocalDate date;

    /**
     * Instantiates a new parcel counter.
     */
    public ParcelCounter() {
        this.counter = new AtomicLong();
        this.date = LocalDate.now();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.pds.counter.IParcelCounter#current()
     */
    @Override
    public long current() {
        return this.counter.get();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.pds.counter.IParcelCounter#next()
     */
    @Override
    public long next() {
        return this.counter.incrementAndGet();
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.service.pds.counter.IParcelCounter#next(java.time.LocalDate)
     */
    @Override
    public long next(final LocalDate date) {
        if (!date.isEqual(this.date)) {
            this.counter.set(0);
            this.date = date;
        }
        return this.next();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.pds.counter.IParcelCounter#reset()
     */
    @Override
    public long reset() {
        return this.counter.getAndSet(0);
    }

}
