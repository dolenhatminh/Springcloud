/*
 * Class: LoggerFactory
 * 
 * Created on Sep 29, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.logging;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;

import net.logstash.logback.marker.LogstashMarker;
import net.logstash.logback.marker.Markers;
import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.model.IdentifiedEntry;

/**
 * A factory for creating Logger objects.
 */
public final class LoggerFactory {
    
    /**
     * Gets the logger.
     *
     * @param clazz the clazz
     * @return the logger
     */
    public static vn.sps.aba.dds.logging.Logger getLogger(Class<?> clazz) {
        return new DiscoLoggerImpl(clazz);
    }
    
    /**
     * New ws response.
     *
     * @param entry the entry
     * @param response the response
     * @return the ws response
     */
    public static WsResponse newWsResponse(IdentifiedEntry entry, Object response){
        return new WsResponse(entry, response);
    }

    /**
     * The Class DiscoLoggerImpl.
     */
    private static class DiscoLoggerImpl implements vn.sps.aba.dds.logging.Logger {

        /** The Constant FIELD_KEY. */
        private static final String FIELD_KEY = DDSConstant.ParcelFields.FIELD_KEY;

        /** The Constant FIELD_IDENT_CODE. */
        private static final String FIELD_IDENT_CODE = DDSConstant.ParcelFields.FIELD_IDENT_CODE;

        /** The logger. */
        private final Logger logger;

        /**
         * Instantiates a new disco logger impl.
         *
         * @param clazz the clazz
         */
        private DiscoLoggerImpl(Class<?> clazz) {
            logger = org.slf4j.LoggerFactory.getLogger(clazz);
        }

        /**
         * Builds the indexes.
         *
         * @param key the key
         * @param identCode the ident code
         * @return the logstash marker
         */
        private LogstashMarker buildIndexes(String key, String identCode) {
            final Map<String, String> indexes = new HashMap<>();
            indexes.put(FIELD_KEY, key);
            indexes.put(FIELD_IDENT_CODE, identCode);
            return Markers.appendEntries(indexes);
        }

        /**
         * Builds the indexes.
         *
         * @param entry the entry
         * @return the logstash marker
         */
        private LogstashMarker buildIndexes(IdentifiedEntry entry) {
            final Map<String, String> indexes = new HashMap<>();
            indexes.put(FIELD_KEY, entry.getKey());
            indexes.put(FIELD_IDENT_CODE, entry.getIdentCode());
            return Markers.appendEntries(indexes);
        }

        /**
         * Builds the indexes.
         *
         * @param key the key
         * @return the logstash marker
         */
        private LogstashMarker buildIndexes(String key) {
            return Markers.append(FIELD_KEY, key);
        }

        /**
         * Builds the indexes.
         *
         * @param object the object
         * @return the logstash marker
         */
        private LogstashMarker buildIndexes(Object object) {
            return Markers.appendFields(object);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#info(java.lang.String)
         */
        @Override
        public void info(String message) {
            logger.info(message);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#info(java.lang.String, java.lang.Object[])
         */
        @Override
        public void info(String message, Object... objects) {
            logger.info(message, objects);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#info(vn.sps.aba.dds.common.model.IdentifiedEntry, java.lang.String, java.lang.Object[])
         */
        @Override
        public void info(IdentifiedEntry entry, String pattern, Object... objects) {
            logger.info(buildIndexes(entry), pattern, objects);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#info(int, java.lang.Object, java.lang.String, java.lang.Object[])
         */
        @Override
        public void info(int p, Object entry, String pattern, Object... objects) {
            logger.info(buildIndexes(entry), pattern, objects);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#info(java.lang.String, java.lang.String, java.lang.Object[])
         */
        @Override
        public void info(String key, String pattern, Object... objects) {
            logger.info(buildIndexes(key), pattern, objects);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#error(java.lang.String)
         */
        @Override
        public void error(String message) {
            logger.error(message);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#error(java.lang.String, java.lang.Throwable)
         */
        @Override
        public void error(String message, Throwable t) {
            logger.error(message, t);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#error(int, vn.sps.aba.dds.common.model.IdentifiedEntry, java.lang.String, java.lang.Throwable)
         */
        @Override
        public void error(int p, IdentifiedEntry entry, String message, Throwable t) {
            logger.error(buildIndexes(entry), message, t);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#error(java.lang.Object, java.lang.String, java.lang.Throwable)
         */
        @Override
        public void error(Object entry, String message, Throwable t) {
            logger.error(buildIndexes(entry), message, t);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#error(java.lang.String, java.lang.String, java.lang.String, java.lang.Throwable)
         */
        @Override
        public void error(String key, String identCode, String message, Throwable t) {
            logger.error(buildIndexes(key, identCode), message, t);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#error(java.lang.String, java.lang.String, java.lang.Throwable)
         */
        @Override
        public void error(String key, String message, Throwable t) {
            logger.error(buildIndexes(key), message, t);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#warn(java.lang.String)
         */
        @Override
        public void warn(String message) {
            logger.warn(message);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#warn(java.lang.String, java.lang.Throwable)
         */
        @Override
        public void warn(String message, Throwable t) {
            logger.warn(message, t);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#warn(int, java.lang.Object, java.lang.String)
         */
        @Override
        public void warn(int p, Object entry, String message) {
            logger.warn(buildIndexes(entry), message);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#warn(vn.sps.aba.dds.common.model.IdentifiedEntry, java.lang.String)
         */
        @Override
        public void warn(IdentifiedEntry entry, String message) {
            logger.warn(buildIndexes(entry), message);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#warn(java.lang.String, java.lang.String, java.lang.String)
         */
        @Override
        public void warn(String key, String identCode, String message) {
            logger.warn(buildIndexes(key, identCode), message);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#debug(java.lang.String)
         */
        @Override
        public void debug(String message) {
            logger.debug(message);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#debug(java.lang.Object, java.lang.String, java.lang.Object[])
         */
        @Override
        public void debug(Object entry, String pattern, Object... objects) {
            logger.debug(buildIndexes(entry), pattern, objects);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#debug(java.lang.String, java.lang.String, java.lang.Object[])
         */
        @Override
        public void debug(String key, String pattern, Object... objects) {
            logger.debug(buildIndexes(key), pattern, objects);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#debug(java.lang.String, java.lang.String, java.lang.Throwable)
         */
        @Override
        public void debug(String key, String pattern, Throwable t) {
            logger.debug(buildIndexes(key), pattern, t);
        }

        /**
         * {@inheritDoc}
         * 
         * @see vn.sps.aba.dds.logging.Logger#warn(vn.sps.aba.dds.common.model.IdentifiedEntry, java.lang.String, java.lang.Throwable)
         */
        @Override
        public void warn(IdentifiedEntry entry, String message, Throwable t) {
            logger.warn(buildIndexes(entry), message, t);
        }

    }

    /**
     * The Class WsResponse.
     */
    private static class WsResponse {
        
        /** The response. */
        private final Object response;

        /** The key. */
        private final String key;

        /** The ident code. */
        private final String identCode;

        /**
         * Instantiates a new ws response.
         *
         * @param key the key
         * @param identCode the ident code
         * @param response the response
         */
        private WsResponse(String key, String identCode, Object response) {
            this.key = key;
            this.identCode = identCode;
            this.response = response;
        }

        /**
         * Instantiates a new ws response.
         *
         * @param entry the entry
         * @param response the response
         */
        private WsResponse(IdentifiedEntry entry, Object response) {
            this.key = entry.getKey();
            identCode = entry.getIdentCode();
            this.response = response;
        }

        /**
         * Gets the response.
         *
         * @return the response
         */
        @SuppressWarnings("unused")
        public Object getResponse() {
            return response;
        }

        /**
         * Gets the key.
         *
         * @return the key
         */
        @SuppressWarnings("unused")
        public String getKey() {
            return key;
        }

        /**
         * Gets the ident code.
         *
         * @return the ident code
         */
        @SuppressWarnings("unused")
        public String getIdentCode() {
            return identCode;
        }
    }

}
