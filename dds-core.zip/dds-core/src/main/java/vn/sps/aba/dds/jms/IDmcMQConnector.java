/*
 * Class: IDmcMQConnector
 *
 * Created on Nov 9, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.jms;

import vn.sps.aba.dds.common.model.dmc.DMCRequest;
import vn.sps.aba.dds.common.model.dmc.DMCResponse;

/**
 * The Interface IDmcMQConnector.
 */
public interface IDmcMQConnector {

    /**
     * Consume.
     *
     * @param response the response
     */
    void consume(DMCResponse response);

    /**
     * Consume.
     *
     * @param dmcMsgQueueName the dmc msg queue name
     * @return the DMC response
     */
    DMCResponse consume(String dmcMsgQueueName);

    /**
     * Send.
     *
     * @param request the request
     */
    void send(DMCRequest request);

    /**
     * Send.
     *
     * @param request the request
     * @param dmcMsgQueueName the dmc msg queue name
     */
    void send(DMCRequest request, String dmcMsgQueueName);
}
