/*
 * Class: BlackboxSendingHanlder
 *
 * Created on Oct 19, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.sender.parcel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.sender.BlackboxSendingExecutor;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.logging.report.VaeRecordReport;
import vn.sps.aba.dds.scheduled.sender.IScheduledSender;
import vn.sps.aba.dds.sender.parcel.interfaces.IBlackboxSender;
import vn.sps.aba.dds.service.blackbox.IVaeBlackboxService;

/**
 * The Class BlackboxSendingHandler.
 */
@Component("BlackboxSendingHandler")
public class BlackboxSendingHandler extends AbstractParcelSender implements IBlackboxSender {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(BlackboxSendingHandler.class);

    /** The executor. */
    @Autowired
    private BlackboxSendingExecutor executor;

    /** The blackbox scheduled sender. */
    @Autowired
    @Qualifier("BlackboxScheduledSender")
    private IScheduledSender<ParcelInfo> scheduledSender;

    /** The black box service. */
    @Autowired
    private IVaeBlackboxService service;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected TaskConfiguration getExecutor() {
        return this.executor;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.sender.parcel.AbstractParcelSender#getScheduledSender()
     */
    @Override
    protected IScheduledSender<ParcelInfo> getScheduledSender() {
        return this.scheduledSender;
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.sender.IExternalSender#getSenderName()
     */
    @Override
    public String getSenderName() {
        return "BlackBox sender";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.sender.IExternalSender#handleItem(java.lang.Object)
     */
    @Override
    public Runnable handleItem(final ParcelInfo parcelInfo, final boolean isRetry) {
        return () -> {

            try {
                LOG.info(IndexMaker.index(parcelInfo), "Transfer parcel to VAE BlackBox service");
                if (BlackboxSendingHandler.this.service.forwardToBlackbox(parcelInfo)) {
                    parcelInfo.setState(ParcelState.BLACKBOX_SENT);
                    LOG.info(IndexMaker.indexes(new VaeRecordReport(parcelInfo), "vaeBlackBoxReport"), "Insert log VAE_BlackBox Report");
                    LOG.info(IndexMaker.index(parcelInfo), "Transfer parcel to VAE BlackBox service successfully");
                }
                else {
                    LOG.info(IndexMaker.index(parcelInfo), "Failed to forward parcel to VAE BlackBox service!");
                    BlackboxSendingHandler.this.scheduledSender.queue(parcelInfo);
                    LOG.info(IndexMaker.index(parcelInfo), "Parcel was queued up to re-send to VAE CaptureRequest service");
                }
                if (!isRetry) {
                    BlackboxSendingHandler.this.parcelInfoDao.put(parcelInfo.getKey(), parcelInfo);
                }
                else {
                    BlackboxSendingHandler.this.parcelInfoDao.store(parcelInfo.getKey(), parcelInfo);
                }
            }
            catch (final Exception e) {
                LOG.debug(IndexMaker.index(parcelInfo), "There is error when transfer parcel to VAE BlackBox service", e);
            }
            finally {
                BlackboxSendingHandler.this.watcher.unWatch(parcelInfo.getKey());
                LOG.info(IndexMaker.index(parcelInfo), "Transfer parcel to VAE Blackbox service done");
            }
        };
    }

    /**
     * Merge and store.
     *
     * @param key the key
     * @param parcelInfo the parcel info
     */
    protected void mergeAndStore(final String key, final ParcelInfo parcelInfo) {
        try {
            ParcelInfo ret = this.parcelInfoDao.get(key);
            LOG.info(IndexMaker.index(ret), "This parcel in cache");

            if (ret != null) {
                LOG.info(IndexMaker.index(ret), "This parcel in cache");
                ret.setState(parcelInfo.getParcelState());
                ret.setBlackboxBegin(parcelInfo.getBlackboxBegin());
                ret.setBlackboxEnd(parcelInfo.getBlackboxEnd());
                ret.setBarcodeCount(parcelInfo.getBlackboxCount());
            }
            else {
                LOG.info(IndexMaker.index(key), "Cannot find any parcel match with key");
                ret = parcelInfo;
            }
            this.parcelInfoDao.store(key, ret);
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when merge and store parcel into database.", e);
        }
    }

}
