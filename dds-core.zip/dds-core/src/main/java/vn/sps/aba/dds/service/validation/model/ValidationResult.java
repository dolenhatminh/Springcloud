/*
 * Class: ValidationResult
 *
 * Created on Jun 14, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.model;

/**
 * The Class ValidationResult.
 */
public class ValidationResult implements IValidationResult {

    /** The Constant DEFAULT_SUCCESS_CODE. */
    protected static final int DEFAULT_SUCCESS_CODE = 0;

    /** The message. */
    private String message;

    /** The response code. */
    private int responseCode;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.validation.model.IValidationResult#getMessage()
     */
    @Override
    public String getMessage() {
        return this.message;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.validation.model.IValidationResult#getResponseCode()
     */
    @Override
    public int getResponseCode() {
        return this.responseCode;
    }

    /**
     * Gets the success code.
     *
     * @return the success code
     */
    protected int getSuccessCode() {
        return DEFAULT_SUCCESS_CODE;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.validation.model.IValidationResult#isValid()
     */
    @Override
    public boolean isValid() {
        return this.getResponseCode() == this.getSuccessCode();
    }

    /**
     * Sets the message.
     *
     * @param message the new message
     */
    public void setMessage(final String message) {
        this.message = message;

    }

    /**
     * Sets the response code.
     *
     * @param responseCode the new response code
     */
    public void setResponseCode(final int responseCode) {
        this.responseCode = responseCode;
    }
}
