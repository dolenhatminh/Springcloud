/*
 * Class: EnumResolver
 *
 * Created on Jul 23, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.ws.response;

import java.util.HashMap;
import java.util.Map;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.types.ws.dpmb.EAmpStatus;
import vn.sps.aba.dds.common.types.ws.dpmb.ECaptureResultCode;
import vn.sps.aba.dds.common.types.ws.dpmb.EDienstleistung;
import vn.sps.aba.dds.common.types.ws.dpmb.EPersStatus;
import vn.sps.aba.dds.common.types.ws.dpmb.EPersType;
import vn.sps.aba.dds.common.types.ws.dpmb.extendtypes.EParcelAdrTypes;

/**
 * The Class EnumResolver.
 */
public final class EnumResolver {

    /** The amp statuses. */
    private static Map<String, EAmpStatus> ampStatuses = new HashMap<>();

    /** The capture result codes. */
    private static Map<String, ECaptureResultCode> captureResultCodes = new HashMap<>();

    /** The capture result codes string. */
    private static String captureResultCodesString;

    /** The dienstleistungs. */
    private static Map<String, EDienstleistung> dienstleistungs = new HashMap<>();

    /** The parcel adr types. */
    private static Map<String, EParcelAdrTypes> parcelAdrTypes = new HashMap<>();

    /** The parcel adr types string. */
    private static String parcelAdrTypesString;

    /** The pers statuses. */
    private static Map<String, EPersStatus> persStatuses = new HashMap<>();

    /** The pers types. */
    private static Map<String, EPersType> persTypes = new HashMap<>();

    static {

        for (final EAmpStatus ampStatus : EAmpStatus.values()) {

            ampStatuses.put(ampStatus.value(), ampStatus);
        }

        for (final ECaptureResultCode captureResultCode : ECaptureResultCode.values()) {

            captureResultCodes.put(captureResultCode.value(), captureResultCode);
            captureResultCodesString = captureResultCodesString == null ? captureResultCode.value()
                    : String.join(Constant.CHAR_COMMA, captureResultCodesString, captureResultCode.value());
        }

        for (final EDienstleistung dienstleistungType : EDienstleistung.values()) {

            dienstleistungs.put(dienstleistungType.value(), dienstleistungType);
        }

        for (final EPersStatus EPersStatus : EPersStatus.values()) {

            persStatuses.put(EPersStatus.value(), EPersStatus);
        }

        for (final EPersType EPersType : EPersType.values()) {

            persTypes.put(EPersType.value(), EPersType);
        }

        for (final EParcelAdrTypes parcelAdrType : EParcelAdrTypes.values()) {

            parcelAdrTypes.put(parcelAdrType.name(), parcelAdrType);
            parcelAdrTypesString = parcelAdrTypesString == null ? parcelAdrType.name()
                    : String.join(Constant.CHAR_COMMA, parcelAdrTypesString, parcelAdrType.name());
        }
    }

    /**
     * Gets the capture result codes string.
     *
     * @return the capture result codes string
     */
    public static String getCaptureResultCodesString() {
        return captureResultCodesString;
    }

    /**
     * Gets the parcel adr types string.
     *
     * @return the parcel adr types string
     */
    public static String getParcelAdrTypesString() {
        return EnumResolver.parcelAdrTypesString;
    }

    /**
     * Resolve amp status.
     *
     * @param value the value
     * @return the amp status type
     */
    public static EAmpStatus resolveAmpStatus(final String value) {

        return ampStatuses.get(value);
    }

    /**
     * Resolve capture result code.
     *
     * @param value the value
     * @return the capture result code type
     */
    public static ECaptureResultCode resolveCaptureResultCode(final String value) {

        return captureResultCodes.get(value);
    }

    /**
     * Resolve dienstleistung.
     *
     * @param value the value
     * @return the dienstleistung type
     */
    public static EDienstleistung resolveDienstleistung(final String value) {

        return dienstleistungs.get(value);
    }

    /**
     * Resolve e parcel adr types.
     *
     * @param value the value
     * @return the e parcel adr types
     */
    public static EParcelAdrTypes resolveParcelAdrTypes(final String value) {

        return parcelAdrTypes.get(value);
    }

    /**
     * Resolve pers status.
     *
     * @param value the value
     * @return the pers status type
     */
    public static EPersStatus resolvePersStatus(final String value) {

        return persStatuses.get(value);
    }

    /**
     * Resolve pers type.
     *
     * @param value the value
     * @return the pers type type
     */
    public static EPersType resolvePersType(final String value) {

        return persTypes.get(value);
    }

    /**
     * Instantiates a new enum resolver.
     */
    private EnumResolver() {
    }
}
