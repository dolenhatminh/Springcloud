package vn.sps.aba.dds.logging.report.field;
import java.io.Serializable;

import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;

/**
 * One of ReceiverInfoReport's Fields.
 * Class Timestamps
 */
public class Timestamps implements Serializable{
	
	 /** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7928041758987118545L;

	/** The dis co timestamp. */
    private String disCoTimestamp;
    
    /** The pds timestamp. */
    private String pdsTimestamp;
    
    /** The vg timestamp. */
    private String vgTimestamp;

    /** The vn timestamp. */
    private String vnTimestamp;
    
	/**
	 * One of ReceiverInfoReport's Fields.
	 * @param ReceiverInfo
	 */
	public Timestamps(ReceiverInfo receiverInfo) {
		this.disCoTimestamp = receiverInfo.getDisCoTimestamp();
		this.pdsTimestamp = receiverInfo.getPdsTimestamp();
		this.vgTimestamp = receiverInfo.getVgTimestamp();
		this.vnTimestamp = receiverInfo.getVnTimestamp();
	}

	/**
	 * @return the disCoTimestamp
	 */
	public String getDisCoTimestamp() {
		return disCoTimestamp;
	}

	/**
	 * @return the pdsTimestamp
	 */
	public String getPdsTimestamp() {
		return pdsTimestamp;
	}

	/**
	 * @return the vgTimestamp
	 */
	public String getVgTimestamp() {
		return vgTimestamp;
	}

	/**
	 * @return the vnTimestamp
	 */
	public String getVnTimestamp() {
		return vnTimestamp;
	}
    
    

}
