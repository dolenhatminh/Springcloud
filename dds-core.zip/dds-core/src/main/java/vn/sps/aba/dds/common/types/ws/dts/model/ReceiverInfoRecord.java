
package vn.sps.aba.dds.common.types.ws.dts.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ReceiverInfoRecord complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReceiverInfoRecord">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="EnvelopeVersion" type="{http://www.postlogistics.ch/PLDTVG/V10/}Max3Text" form="unqualified"/>
 *         &lt;element name="IdentCode" type="{http://www.postlogistics.ch/PLDTVG/V10/}IdentCode" form="unqualified"/>
 *         &lt;element name="REC_Title" type="{http://www.postlogistics.ch/PLDTVG/V10/}Max35Text" minOccurs="0" form="unqualified"/>
 *         &lt;element name="REC_Name1" type="{http://www.postlogistics.ch/PLDTVG/V10/}Max50Text" minOccurs="0" form="unqualified"/>
 *         &lt;element name="REC_Name2" type="{http://www.postlogistics.ch/PLDTVG/V10/}Max50Text" minOccurs="0" form="unqualified"/>
 *         &lt;element name="REC_Name3" type="{http://www.postlogistics.ch/PLDTVG/V10/}Max50Text" minOccurs="0" form="unqualified"/>
 *         &lt;element name="REC_Street" type="{http://www.postlogistics.ch/PLDTVG/V10/}Max50Text" minOccurs="0" form="unqualified"/>
 *         &lt;element name="REC_POBox" type="{http://www.postlogistics.ch/PLDTVG/V10/}Max35Text" minOccurs="0" form="unqualified"/>
 *         &lt;element name="REC_ZIP" type="{http://www.postlogistics.ch/PLDTVG/V10/}Zip" minOccurs="0" form="unqualified"/>
 *         &lt;element name="REC_City" type="{http://www.postlogistics.ch/PLDTVG/V10/}Max35Text" minOccurs="0" form="unqualified"/>
 *         &lt;element name="REC_Country" type="{http://www.postlogistics.ch/PLDTVG/V10/}Country" minOccurs="0" form="unqualified"/>
 *         &lt;element name="REC_FreeText" type="{http://www.postlogistics.ch/PLDTVG/V10/}Max160Text" minOccurs="0" form="unqualified"/>
 *         &lt;element name="REC_SenderId" type="{http://www.postlogistics.ch/PLDTVG/V10/}Max35Text" minOccurs="0" form="unqualified"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReceiverInfoRecord", propOrder = {
    "envelopeVersion",
    "identCode",
    "recTitle",
    "recName1",
    "recName2",
    "recName3",
    "recStreet",
    "recpoBox",
    "reczip",
    "recCity",
    "recCountry",
    "recFreeText",
    "recSenderId"
})
public class ReceiverInfoRecord {

    @XmlElement(name = "EnvelopeVersion", required = true)
    protected String envelopeVersion;
    @XmlElement(name = "IdentCode", required = true)
    protected String identCode;
    @XmlElement(name = "REC_Title")
    protected String recTitle;
    @XmlElement(name = "REC_Name1")
    protected String recName1;
    @XmlElement(name = "REC_Name2")
    protected String recName2;
    @XmlElement(name = "REC_Name3")
    protected String recName3;
    @XmlElement(name = "REC_Street")
    protected String recStreet;
    @XmlElement(name = "REC_POBox")
    protected String recpoBox;
    @XmlElement(name = "REC_ZIP")
    protected String reczip;
    @XmlElement(name = "REC_City")
    protected String recCity;
    @XmlElement(name = "REC_Country")
    protected String recCountry;
    @XmlElement(name = "REC_FreeText")
    protected String recFreeText;
    @XmlElement(name = "REC_SenderId")
    protected String recSenderId;

    /**
     * Gets the value of the envelopeVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnvelopeVersion() {
        return envelopeVersion;
    }

    /**
     * Sets the value of the envelopeVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnvelopeVersion(String value) {
        this.envelopeVersion = value;
    }

    /**
     * Gets the value of the identCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentCode() {
        return identCode;
    }

    /**
     * Sets the value of the identCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentCode(String value) {
        this.identCode = value;
    }

    /**
     * Gets the value of the recTitle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECTitle() {
        return recTitle;
    }

    /**
     * Sets the value of the recTitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECTitle(String value) {
        this.recTitle = value;
    }

    /**
     * Gets the value of the recName1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECName1() {
        return recName1;
    }

    /**
     * Sets the value of the recName1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECName1(String value) {
        this.recName1 = value;
    }

    /**
     * Gets the value of the recName2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECName2() {
        return recName2;
    }

    /**
     * Sets the value of the recName2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECName2(String value) {
        this.recName2 = value;
    }

    /**
     * Gets the value of the recName3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECName3() {
        return recName3;
    }

    /**
     * Sets the value of the recName3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECName3(String value) {
        this.recName3 = value;
    }

    /**
     * Gets the value of the recStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECStreet() {
        return recStreet;
    }

    /**
     * Sets the value of the recStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECStreet(String value) {
        this.recStreet = value;
    }

    /**
     * Gets the value of the recpoBox property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECPOBox() {
        return recpoBox;
    }

    /**
     * Sets the value of the recpoBox property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECPOBox(String value) {
        this.recpoBox = value;
    }

    /**
     * Gets the value of the reczip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECZIP() {
        return reczip;
    }

    /**
     * Sets the value of the reczip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECZIP(String value) {
        this.reczip = value;
    }

    /**
     * Gets the value of the recCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECCity() {
        return recCity;
    }

    /**
     * Sets the value of the recCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECCity(String value) {
        this.recCity = value;
    }

    /**
     * Gets the value of the recCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECCountry() {
        return recCountry;
    }

    /**
     * Sets the value of the recCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECCountry(String value) {
        this.recCountry = value;
    }

    /**
     * Gets the value of the recFreeText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECFreeText() {
        return recFreeText;
    }

    /**
     * Sets the value of the recFreeText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECFreeText(String value) {
        this.recFreeText = value;
    }

    /**
     * Gets the value of the recSenderId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECSenderId() {
        return recSenderId;
    }

    /**
     * Sets the value of the recSenderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECSenderId(String value) {
        this.recSenderId = value;
    }

}
