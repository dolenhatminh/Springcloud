/*
 * Class: IReceiverValidator
 *
 * Created on Oct 7, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.dpms;

import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;

/**
 * The Interface IReceiverValidator.
 */
public interface IReceiverValidator {

    /**
     * Apply manged info.
     *
     * @param receiverInfo the receiver info
     */
    void applyMangedInfo(ReceiverInfo receiverInfo);

    /**
     * Validate.
     *
     * @param receiverValidatingInfo the receiver validating info
     * @param packageValidatingInfo the package validating info
     * @return true, if successful
     */
    boolean validate(final ReceiverValidatingInfo receiverValidatingInfo, final PackageValidatingInfo packageValidatingInfo);
}
