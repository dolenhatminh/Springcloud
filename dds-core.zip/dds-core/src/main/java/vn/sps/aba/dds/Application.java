package vn.sps.aba.dds;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableMBeanExport;

import vn.sps.aba.dds.controller.ManagementController;

/**
 * The Class Application.
 */
@EnableMBeanExport
@SpringBootApplication(scanBasePackages = { "vn.sps.aba.dds" })
public class Application {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(Application.class);

    /**
     * The main method.
     *
     * @param args
     *            the arguments
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public static void main(final String[] args) throws IOException {
        final Application application = SpringApplication.run(Application.class, args).getBean(Application.class);
        application.printApplicationInfo();
    }

    /** The controller. */
    @Autowired
    private ManagementController controller;

    /**
     * Instantiates a new application.
     */
    protected Application() {
        LOG.info("Disco DDS");
    }

    /**
     * Prints the application info.
     */
    private void printApplicationInfo() {
        LOG.info(":: DDS Core ::   ({})", this.controller.info().getVersion());
    }
}
