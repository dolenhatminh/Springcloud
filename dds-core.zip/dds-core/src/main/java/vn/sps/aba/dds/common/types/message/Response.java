/*
 * Class: Response
 *
 * Created on Jun 25, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.message;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * The Class Response.
 */
@XStreamAlias("response")
public class Response {

    /** The code. */
    @XStreamAlias("code")
    @XStreamAsAttribute
    private String code;

    /** The description. */
    @XStreamAlias("description")
    @XStreamAsAttribute
    private String description;

    /** The code. */
    @XStreamAlias("key")
    @XStreamAsAttribute
    private String key;

    /** The source id. */
    @XStreamAlias("source")
    @XStreamAsAttribute
    private String source;

    /**
     * Instantiates a new response.
     */
    Response() {

    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the key.
     *
     * @return Returns the key.
     */
    public String getKey() {
        return this.key;
    }

    /**
     * Gets the source.
     *
     * @return the sourceId
     */
    public String getSource() {
        return this.source;
    }

    /**
     * Sets the code.
     *
     * @param code the code to set
     */
    public void setCode(final String code) {
        this.code = code;
    }

    /**
     * Sets the description.
     *
     * @param description the description to set
     */
    void setDescription(final String description) {
        this.description = description;
    }

    /**
     * Sets the key.
     *
     * @param key The key to set.
     */
    void setKey(final String key) {
        this.key = key;
    }

    /**
     * Sets the source.
     *
     * @param source the new source
     */
    void setSource(final String source) {
        this.source = source;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "[source=" + this.source + ", key=" + this.key + ", code=" + this.code + "]";
    }
}
