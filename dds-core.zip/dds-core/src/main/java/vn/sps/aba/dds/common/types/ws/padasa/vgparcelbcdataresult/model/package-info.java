@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.post.ch/esb/PdsWSTypes")
package vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model;
