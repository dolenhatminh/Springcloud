/*
 * Class: ICaptureResultService
 *
 * Created on Jun 6, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.vam;

import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;

/**
 * The Interface IVamServiceAdapter.
 */
public interface ICaptureResultService {

    /**
     * Transfer to vam station.
     *
     * @param parcelInfo the parcel info
     * @return true, if successful
     */
    boolean transferToVamStation(ParcelInfo parcelInfo);

    /**
     * Transfer to vam station.
     *
     * @param receiverInfo the receiver info
     * @return true, if successful
     */
    boolean transferToVamStation(ReceiverInfo receiverInfo);

}