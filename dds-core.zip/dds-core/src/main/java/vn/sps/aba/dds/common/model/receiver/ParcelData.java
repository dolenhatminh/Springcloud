/*
 * Class: ParcelData
 *
 * Created on Jul 25, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.receiver;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import vn.sps.aba.dds.common.types.ws.dpmb.ArrayOfProduktZusatzLeistung;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.ProduktZusatzLeistung;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.common.util.JaxbUtil;

/**
 * The Class ParcelData.
 */
public class ParcelData implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -5269902979675693467L;

    /** The acs timestamp. */
    private String acsTimestamp;

    /** The destination station. */
    private String destinationStation;

    /** The par pic id. */
    private String parPicId;

    /** The source station. */
    private String sourceStation;

    /** The vcs case. */
    private String vcsCase;

    /** The zusatz leistungen. */
    private List<String> zusatzLeistungen;

    /**
     * Instantiates a new parcel data.
     *
     * @param parcelData the parcel data
     */
    public ParcelData(final vn.sps.aba.dds.common.types.ws.dpmb.ParcelData parcelData) {

        this.acsTimestamp = DateUtil.gregorian2String(parcelData.getAcsTimestamp());
        this.parPicId = parcelData.getParPicId();
        this.sourceStation = parcelData.getSourceStation();
        this.destinationStation = parcelData.getDestinationStation();
        this.vcsCase = String.valueOf(parcelData.getVcsCase());

        final ArrayOfProduktZusatzLeistung zusatzLeistungens = parcelData.getZusatzLeistungen();
        if (zusatzLeistungens != null) {
            for (final vn.sps.aba.dds.common.types.ws.dpmb.ProduktZusatzLeistung produktZusatzLeistung : zusatzLeistungens.getProduktZusatzLeistung()) {
                this.getZusatzLeistungen().add(String.valueOf(produktZusatzLeistung.getCode()));
            }
        }
    }

    /**
     * Instantiates a new parcel data.
     *
     * @param parcelData the parcel data
     */
    public ParcelData(final vn.sps.aba.dds.common.types.ws.dpms.ParcelData parcelData) {
        this.acsTimestamp = JaxbUtil.element2String(parcelData.getAcsTimestamp());
        this.parPicId = JaxbUtil.element2String(parcelData.getParPicId());
        this.sourceStation = JaxbUtil.element2String(parcelData.getSourceStation());
        this.destinationStation = JaxbUtil.element2String(parcelData.getDestinationStation());
        this.vcsCase = JaxbUtil.element2String(parcelData.getVcsCase());

        if (parcelData.getZusatzLeistungen() != null) {
            final vn.sps.aba.dds.common.types.ws.dpms.ArrayOfProduktZusatzLeistung zusatzLeistungens = parcelData.getZusatzLeistungen().getValue();
            if (zusatzLeistungens != null) {
                for (final vn.sps.aba.dds.common.types.ws.dpms.ProduktZusatzLeistung produktZusatzLeistung : zusatzLeistungens.getProduktZusatzLeistung()) {
                    if (produktZusatzLeistung != null) {
                        final String serviceCode = JaxbUtil.element2String(produktZusatzLeistung.getCode());
                        if (serviceCode != null) {
                            this.getZusatzLeistungen().add(serviceCode);
                        }
                    }
                }
            }
        }
    }

    /**
     * Instantiates a new parcel data.
     *
     * @param parcelData the parcel data
     */
    public ParcelData(final vn.sps.aba.dds.common.types.ws.vam.capturing.model.ParcelData parcelData) {

        this.acsTimestamp = DateUtil.gregorian2String(parcelData.getAcsTimestamp());
        this.parPicId = parcelData.getParPicId();
        this.sourceStation = parcelData.getSourceStation();
        this.destinationStation = parcelData.getDestinationStation();
        this.vcsCase = String.valueOf(parcelData.getVcsCase());

        for (final ProduktZusatzLeistung produktZusatzLeistung : parcelData.getZusatzLeistungen().getProduktZusatzLeistung()) {
            this.getZusatzLeistungen().add(String.valueOf(produktZusatzLeistung.getCode()));
        }
    }

    /**
     * Gets the acs timestamp.
     *
     * @return the acs timestamp
     */
    public String getAcsTimestamp() {
        return this.acsTimestamp;
    }

    /**
     * Gets the destination station.
     *
     * @return the destination station
     */
    public String getDestinationStation() {
        return this.destinationStation;
    }

    /**
     * Gets the par pic id.
     *
     * @return the par pic id
     */
    public String getParPicId() {
        return this.parPicId;
    }

    /**
     * Gets the source station.
     *
     * @return the source station
     */
    public String getSourceStation() {
        return this.sourceStation;
    }

    /**
     * Gets the vcs case.
     *
     * @return the vcs case
     */
    public String getVcsCase() {
        return this.vcsCase;
    }

    /**
     * Gets the zusatz leistungen.
     *
     * @return the zusatz leistungen
     */
    public List<String> getZusatzLeistungen() {
        if (this.zusatzLeistungen == null) {
            this.zusatzLeistungen = new ArrayList<>();
        }
        return this.zusatzLeistungen;
    }

    /**
     * Gets the zusatz leistungen as string.
     *
     * @return the zusatz leistungen as string
     */
    public String[] getZusatzLeistungenAsString() {
        final String[] ret = new String[this.getZusatzLeistungen().size()];

        for (int i = 0; i < this.zusatzLeistungen.size(); i++) {
            ret[i] = String.valueOf(this.zusatzLeistungen.get(i));
        }

        return ret;
    }

    /**
     * Sets the acs timestamp.
     *
     * @param acsTimestamp the new acs timestamp
     */
    public void setAcsTimestamp(final String acsTimestamp) {
        this.acsTimestamp = acsTimestamp;
    }

    /**
     * Sets the destination station.
     *
     * @param destinationStation the new destination station
     */
    public void setDestinationStation(final String destinationStation) {
        this.destinationStation = destinationStation;
    }

    /**
     * Sets the par pic id.
     *
     * @param parPicId the new par pic id
     */
    public void setParPicId(final String parPicId) {
        this.parPicId = parPicId;
    }

    /**
     * Sets the source station.
     *
     * @param sourceStation the new source station
     */
    public void setSourceStation(final String sourceStation) {
        this.sourceStation = sourceStation;
    }

    /**
     * Sets the vcs case.
     *
     * @param vcsCase the new vcs case
     */
    public void setVcsCase(final String vcsCase) {
        this.vcsCase = vcsCase;
    }

    /**
     * Sets the zusatz leistungen.
     *
     * @param zusatzLeistungen the new zusatz leistungen
     */
    public void setZusatzLeistungen(final List<String> zusatzLeistungen) {
        this.zusatzLeistungen = zusatzLeistungen;
    }

}
