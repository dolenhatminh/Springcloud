/*
 * Class: CacheParcelScheduledCleaner
 *
 * Created on Oct 17, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.cleaner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.config.task.scheduler.WorkspaceScheduleExecutor;
import vn.sps.aba.dds.controller.interfaces.IEntriesController;
import vn.sps.aba.dds.scheduled.AbstractCronScheduler;
import vn.sps.aba.dds.scheduled.DdsScheduledTask;

/**
 * The Class CacheReceiverCleaner.
 */
@Configuration
@Component("CacheReceiverCleaner")
@ConfigurationProperties("schedule.remove.expired.receiver")
public class CacheReceiverCleaner extends AbstractCronScheduler implements DdsScheduledTask {

    /** The cleaner. */
    @Autowired
    @Qualifier("ReceiverInfoController")
    private IEntriesController cleaner;

    /** The scheduled executor. */
    @Autowired
    private WorkspaceScheduleExecutor scheduledExecutor;

    /**
     * Config.
     */
    @PostConstruct
    protected void config() {
        this.scheduleConfigurar.registerScheduledTask(this, this.scheduledExecutor);
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.beans.factory.DisposableBean#destroy()
     */
    @Override
    public void destroy() throws Exception {
        this.scheduledExecutor.getScheduler().destroy();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#getCronExpression()
     */
    @Override
    public String getCronExpression() {
        return this.getCron();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#handleTask()
     */
    @Override
    public Runnable handleTask() {
        return () -> {
            if (this.isEnable()) {
                this.cleaner.processExpiredEntries();
                this.cleaner.processDuplicatedEntries();
            }
        };
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.AbstractCronScheduler#taskName()
     */
    @Override
    public String taskName() {
        return "remove-expired-receiver-entries";
    }

}
