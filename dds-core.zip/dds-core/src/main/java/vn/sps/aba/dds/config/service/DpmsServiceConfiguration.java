/*
 * Class: DpmsServiceConfiguration
 *
 * Created on Aug 18, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.ws.wsdl.wsdl11.SimpleWsdl11Definition;
import org.springframework.xml.xsd.XsdSchemaCollection;
import org.springframework.xml.xsd.commons.CommonsXsdSchemaCollection;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.DDSConstant.Namespace;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.dpms.ObjectFactory;
import vn.sps.aba.dds.config.reponsecode.IDpmbResponseCode;

/**
 * The Class DpmsServiceConfiguration.
 */
@Profile(Profiles.DPMS)
@Configuration("DpmsServiceConfiguration")
@ConfigurationProperties(prefix = "ws.dpms")
public class DpmsServiceConfiguration extends AbstractSoapWsConfiguration implements IDpmbResponseCode {

    /**
     * The Enum ResponseCode.
     */
    private enum ResponseCode {

        /** The Failed authorization error. */
        FailedAuthorizationError,
        /** The Invalid argument error. */
        InvalidArgumentError,
        /** The Invalid capture result records error. */
        InvalidCaptureResultRecordsError,
        /** The Successful. */
        Successful,
        /** The Unexpected error. */
        UnexpectedError
    }

    /** The Constant ERROR_RECEIVER_INFO_INDEX_NAME. */
    private static final String ERROR_RECEIVER_INVALID_ARGUMENT = "receiverValidatingInfo";

    /** The Constant ERROR_RECEIVER_INVALID_CAPTURE_RECORD. */
    private static final String ERROR_RECEIVER_INVALID_CAPTURE_RECORD = "invalidCaptureRecord";

    /** The Constant SOUCE. */
    private static final String SOUCE = DDSConstant.Source.E190;

    /** The Constant WSDL_NAME. */
    private static final String WSDL_NAME = "dpmService";

    /** The caller id format. */
    private String callerIdFormat;

    /** The ident code format. */
    private String identCodeFormat;

    /** The invalid capture record field name. */
    private String invalidCaptureRecordFieldName = ERROR_RECEIVER_INVALID_CAPTURE_RECORD;

    /** The received time format. */
    private String receivedTimeFormat;

    /** The receiver info error format. */
    private String receiverInfoErrorFormat;

    /** The error receiver info field name. */
    private String receiverValidatingInfo = ERROR_RECEIVER_INVALID_ARGUMENT;

    /** The store invalid receiver info. */
    private boolean storeInvalidReceiverInfo;

    /** The version range. */
    private int[] versionRange;

    /** The version range string. */
    private String versionRangeString;

    /** The xsd validation schemas. */
    private XsdSchemaCollection xsdValidationSchemas;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.IDpmbResponseCode#failedAuthorizationError()
     */
    @Override
    public Response failedAuthorizationError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.FailedAuthorizationError.name());
    }

    /**
     * Gets the caller id format.
     *
     * @return the caller id format
     */
    public String getCallerIdFormat() {
        return this.callerIdFormat;
    }

    /**
     * Gets the error receiver info field name.
     *
     * @return the error receiver info field name
     */
    public String getErrorReceiverInfoFieldName() {
        return this.receiverValidatingInfo;
    }

    /**
     * Gets the ident code format.
     *
     * @return the ident code format
     */
    public String getIdentCodeFormat() {
        return this.identCodeFormat;
    }

    /**
     * Gets the invalid capture record field name.
     *
     * @return the invalid capture record field name
     */
    public String getInvalidCaptureRecordFieldName() {
        return this.invalidCaptureRecordFieldName;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getNamespaceURI()
     */
    @Override
    public String getNamespaceURI() {
        return Namespace.E190_NAMESPACE;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getObjectFactory()
     */
    @Override
    public ObjectFactory getObjectFactory() {
        return (ObjectFactory) super.getObjectFactory();
    }

    /**
     * Gets the received time format.
     *
     * @return the received time format
     */
    public String getReceivedTimeFormat() {
        return this.receivedTimeFormat;
    }

    /**
     * Gets the receiver info error format.
     *
     * @return the receiver info error format
     */
    public String getReceiverInfoErrorFormat() {
        return this.receiverInfoErrorFormat;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getServiceName()
     */
    @Override
    public String getServiceName() {
        return "ReceiverInfo";
    }

    /**
     * Gets the version range.
     *
     * @return the version range
     */
    public int[] getVersionRange() {
        return this.versionRange;
    }

    /**
     * Gets the version range string.
     *
     * @return the version range string
     */
    public String getVersionRangeString() {
        return this.versionRangeString;
    }

    /**
     * Gets the xsd validation schemas.
     *
     * @return the xsd validation schemas
     */
    public XsdSchemaCollection getXsdValidationSchemas() {
        return this.xsdValidationSchemas;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#initialize()
     */
    @Override
    @PostConstruct
    public void initialize() throws Exception {
        super.initialize();
        this.versionRangeString = this.versionRange[0] == this.versionRange[1] ? "equals " + this.versionRange[0]
                : "between [" + this.versionRange[0] + "," + this.versionRange[1] + "]";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.IDpmbResponseCode#invalidArgumentError()
     */
    @Override
    public Response invalidArgumentError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.InvalidArgumentError.name());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.IDpmbResponseCode#invalidCaptureResultRecordsError()
     */
    @Override
    public Response invalidCaptureResultRecordsError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.InvalidCaptureResultRecordsError.name());
    }

    /**
     * Checks if is store invalid receiver info.
     *
     * @return true, if is store invalid receiver info
     */
    public boolean isStoreInvalidReceiverInfo() {
        return this.storeInvalidReceiverInfo;
    }

    /**
     * Sets the caller id format.
     *
     * @param callerIdFormat the new caller id format
     */
    public void setCallerIdFormat(final String callerIdFormat) {
        this.callerIdFormat = callerIdFormat;
    }

    /**
     * Sets the error receiver info field name.
     *
     * @param receiverValidatingInfo the new error receiver info field name
     */
    public void setErrorReceiverInfoFieldName(final String receiverValidatingInfo) {
        this.receiverValidatingInfo = receiverValidatingInfo;
    }

    /**
     * Sets the ident code format.
     *
     * @param identCodeFormat the new ident code format
     */
    public void setIdentCodeFormat(final String identCodeFormat) {
        this.identCodeFormat = identCodeFormat;
    }

    /**
     * Sets the invalid capture record field name.
     *
     * @param invalidCaptureRecordFieldName the new invalid capture record field name
     */
    public void setInvalidCaptureRecordFieldName(final String invalidCaptureRecordFieldName) {
        this.invalidCaptureRecordFieldName = invalidCaptureRecordFieldName;
    }

    /**
     * Sets the received time format.
     *
     * @param receivedTimeFormat the new received time format
     */
    public void setReceivedTimeFormat(final String receivedTimeFormat) {
        this.receivedTimeFormat = receivedTimeFormat;
    }

    /**
     * Sets the receiver info error format.
     *
     * @param receiverInfoErrorFormat the new receiver info error format
     */
    public void setReceiverInfoErrorFormat(final String receiverInfoErrorFormat) {
        this.receiverInfoErrorFormat = receiverInfoErrorFormat;
    }

    /**
     * Sets the store invalid receiver info.
     *
     * @param storeInvalidReceiverInfo the new store invalid receiver info
     */
    public void setStoreInvalidReceiverInfo(final boolean storeInvalidReceiverInfo) {
        this.storeInvalidReceiverInfo = storeInvalidReceiverInfo;
    }

    /**
     * Sets the version range.
     *
     * @param versionRange the new version range
     */
    public void setVersionRange(final int[] versionRange) {
        if (versionRange.length == 0) {
            throw new IllegalArgumentException("Invalid version value");
        }
        if ((versionRange.length == 2) && (versionRange[0] > versionRange[1])) {
            throw new IllegalArgumentException("Invalid version value");
        }
        this.versionRange = new int[2];
        if (versionRange.length < 2) {
            this.versionRange[0] = versionRange[0];
            this.versionRange[1] = versionRange[0];
        }
        else {
            this.versionRange[0] = versionRange[0];
            this.versionRange[1] = versionRange[1];
        }
    }

    /**
     * Sets the xsd validation schemas.
     *
     * @param schemas the new xsd validation schemas
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void setXsdValidationSchemas(final String[] schemas) throws IOException {
        this.xsdValidationSchemas = this.loadSchemas(schemas);
        ((CommonsXsdSchemaCollection) this.xsdValidationSchemas).afterPropertiesSet();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.IDpmbResponseCode#successful()
     */
    @Override
    public Response successful() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.Successful.name());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.IDpmbResponseCode#unexpectedError()
     */
    @Override
    public Response unexpectedError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.UnexpectedError.name());
    }

    /**
     * Wsdl definition.
     *
     * @return the simple wsdl11 definition
     */
    @Bean(name = WSDL_NAME)
    public SimpleWsdl11Definition wsdlDefinition() {
        return new SimpleWsdl11Definition(this.wsdlResource);
    }
}
