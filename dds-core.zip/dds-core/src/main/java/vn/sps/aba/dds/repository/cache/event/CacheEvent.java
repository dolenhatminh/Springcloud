/*
 * Class: DdsCacheEvent
 * 
 * Created on Sep 4, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.cache.event;

import org.infinispan.Cache;
import org.infinispan.cache.impl.CacheImpl;
import org.infinispan.metadata.Metadata;
import org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent;
import org.infinispan.transaction.xa.GlobalTransaction;

/**
 * The Class CacheEvent.
 *
 * @param <K> the key type
 * @param <V> the value type
 */
public class CacheEvent<K, V> implements CacheEntryCreatedEvent<K, V>, CacheEntryModifiedEvent<K, V> {

    /** The key. */
    private K key;

    /** The old value. */
    private V oldValue;

    /** The new value. */
    private V newValue;

    /** The cache. */
    private Cache<K, V> cache;

    /** The created. */
    private long created;

    /** The lifespan. */
    private long lifespan;

    /**
     * Creates the event.
     *
     * @param <K> the key type
     * @param <V> the value type
     * @param cache the cache
     * @param key the key
     * @param oldValue the old value
     * @param newValue the new value
     * @param created the created
     * @param lifespan the lifespan
     * @return the cache event
     */
    public static <K, V> CacheEvent<K, V> createEvent(Cache<K, V> cache, K key, V oldValue, V newValue, long created, long lifespan) {
        CacheEvent<K, V> e = new CacheEvent<K, V>();
        {
            e.cache = cache;
            e.key = key;
            e.oldValue = oldValue;
            e.newValue = newValue;
            e.created = created;
            e.lifespan = lifespan;
        }
        return e;
    }
    
    /**
     * Creates the event.
     *
     * @param <K> the key type
     * @param <V> the value type
     * @param cache the cache
     * @param key the key
     * @param oldValue the old value
     * @param newValue the new value
     * @return the cache event
     */
    public static <K, V> CacheEvent<K, V> createEvent(Cache<K, V> cache, K key, V oldValue, V newValue) {
        CacheEvent<K, V> e = new CacheEvent<K, V>();
        {
            e.cache = cache;
            e.key = key;
            e.oldValue = oldValue;
            e.newValue = newValue;
        }
        return e;
    }
    
    /**
     * Gets the created.
     *
     * @return the created
     */
    public long getCreated() {
        return created;
    }

    /**
     * Gets the lifespan.
     *
     * @return the lifespan
     */
    public long getLifespan() {
        return lifespan;
    }



    /**
     * {@inheritDoc}
     * 
     * @see org.infinispan.notifications.cachelistener.event.CacheEntryEvent#getKey()
     */
    public K getKey() {
        return key;
    }

    /**
     * Gets the old value.
     *
     * @return the old value
     */
    public V getOldValue() {
        return oldValue;
    }

    /**
     * Gets the new value.
     *
     * @return the new value
     */
    public V getNewValue() {
        return newValue;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.infinispan.notifications.cachelistener.event.Event#getCache()
     */
    public Cache<K, V> getCache() {
        return cache;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.infinispan.notifications.cachelistener.event.TransactionalEvent#getGlobalTransaction()
     */
    @Override
    public GlobalTransaction getGlobalTransaction() {
        return null;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.infinispan.notifications.cachelistener.event.TransactionalEvent#isOriginLocal()
     */
    @Override
    public boolean isOriginLocal() {
        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.infinispan.notifications.cachelistener.event.Event#getType()
     */
    @Override
    public org.infinispan.notifications.cachelistener.event.Event.Type getType() {
        return null;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.infinispan.notifications.cachelistener.event.Event#isPre()
     */
    @Override
    public boolean isPre() {
        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent#getValue()
     */
    @Override
    public V getValue() {
        return newValue;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.infinispan.notifications.cachelistener.event.CacheEntryEvent#getMetadata()
     */
    @Override
    public Metadata getMetadata() {
        return ((CacheImpl<K, V>) cache).getDataContainer().get(key).getMetadata();
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent#isCreated()
     */
    @Override
    public boolean isCreated() {
        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent#isCommandRetried()
     */
    @Override
    public boolean isCommandRetried() {
        return false;
    }
}
