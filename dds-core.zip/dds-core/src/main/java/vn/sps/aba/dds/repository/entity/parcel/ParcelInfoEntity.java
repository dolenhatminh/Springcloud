/*
 * Class: ParcelInfoE
 *
 * Created on Jul 15, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.entity.parcel;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.constant.TableNames;
import vn.sps.aba.dds.common.model.parcel.Barcode;
import vn.sps.aba.dds.common.model.parcel.ParcelAddress;
import vn.sps.aba.dds.common.model.parcel.ParcelCodingInfo;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.repository.entity.InternalEntity;

/**
 * The Class ParcelInfoEntity.
 */
@Entity
@Table(name = TableNames.PAR_PARCEL_INFO, indexes = { @Index(name = "parcel_key", columnList = "key"), @Index(name = "parcel_state", columnList = "state"),
    @Index(name = "parcel_dmc_state", columnList = "dmc_state"), @Index(name = "parcel_created_time", columnList = "created"),
    @Index(name = "parcel_ident_code", columnList = "ident_code"), @Index(name = "parcel_received_time", columnList = "received_time"),
    @Index(name = "parcel_lifespan", columnList = "lifespan") })
@Access(AccessType.PROPERTY)
public class ParcelInfoEntity extends InternalEntity implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -4359689581094083957L;

    /** The address type. */
    private String addressType;

    /** The barcode data time. */
    private Timestamp barcodeDataBegin;

    /** The barcode data count. */
    private Integer barcodeDataCount;

    /** The barcode data done time. */
    private Timestamp barcodeDataEnd;

    /** The barcodes. */
    private List<BarcodeEntity> barcodes;

    /** The blackbox time. */
    private Timestamp blackboxBegin;

    /** The blackbox count. */
    private Integer blackboxCount;

    /** The blackbox done time. */
    private Timestamp blackboxEnd;

    /** The caller id. */
    private String callerId;

    /** The capture result time. */
    private Timestamp captureResultBegin;

    /** The capture result count. */
    private Integer captureResultCount;

    /** The capture result done time. */
    private Timestamp captureResultEnd;

    /** The coding art. */
    private String codingArt;

    /** The coding quality. */
    private String codingQuality;

    /** The destination station. */
    private String destinationStation;

    /** The dmc time. */
    private Timestamp dmcBegin;

    /** The dmc count. */
    private Integer dmcCount;

    /** The dmc done time. */
    private Timestamp dmcEnd;

    /** The dmc sent. */
    private Timestamp dmcSent;

    /** The dmc state. */
    private String dmcState;

    /** The file name. */
    private String fileName;

    /** The file path. */
    private String filePath;

    /** The filtered by rule. */
    private String filteredByRule;

    /** The finished processing time. */
    private Timestamp finishedProcessingTime;

    /** The full address. */
    private FullAddressEntity fullAddress;

    /** The has image. */
    private Boolean hasImage;

    /** The house number. */
    private String houseNumber;

    /** The ident code. */
    private String identCode;

    /** The key. */
    private String key;

    /** The look up done time. */
    private Timestamp lookUpDoneTime;

    /** The look up start time. */
    private Timestamp lookUpStartTime;

    /** The parcel info sent time. */
    private Timestamp parcelInfoSentTime;

    /** The par pic id. */
    private String parPicId;

    /** The produkt zusatzleistung. */
    private String produktZusatzleistung;

    /** The received time. */
    private Timestamp receivedTime;

    /** The source station. */
    private String sourceStation;

    /** The start processing time. */
    private Timestamp startProcessingTime;

    /** The state. */
    private String state;

    /** The status code. */
    private String statusCode;

    /** The stored data time. */
    private Timestamp storedDataTime;

    /** The stored image time. */
    private Timestamp storedImageTime;

    /** The street number. */
    private String streetNumber;

    /** The time stamp. */
    private Timestamp timeStamp;

    /** The vcs case. */
    private Integer vcsCase;

    /** The version. */
    private Integer version;

    /** The zip. */
    private String zip;

    /**
     * Instantiates a new parcel info entity.
     */
    public ParcelInfoEntity() {
    }

    /**
     * Instantiates a new parcel info entity.
     *
     * @param parcelInfo
     *            the parcel info
     */
    public ParcelInfoEntity(final ParcelInfo parcelInfo) {

        for (final Barcode barcode : parcelInfo.getBarcodes()) {
            final BarcodeEntity barcodeEntity = new BarcodeEntity(barcode);
            barcodeEntity.setParcelInfo(this);
            this.getBarcodes().add(barcodeEntity);
        }
        final ParcelCodingInfo parcelCodingInfo = parcelInfo.getParcelCodingInfo();
        if (parcelCodingInfo != null) {
            this.setCodingArt(parcelCodingInfo.getCodingArt());
            this.setCodingQuality(parcelCodingInfo.getCodingQuality());
        }
        this.setDestinationStation(parcelInfo.getDestinationStation());
        this.setFileName(parcelInfo.getFileName());
        this.setFilePath(parcelInfo.getFilePath());

        if (parcelInfo.getFullAddress() != null) {
            this.fullAddress = new FullAddressEntity(parcelInfo.getFullAddress());
        }

        final ParcelAddress parcelAddress = parcelInfo.getParcelAddress();
        if (parcelAddress != null) {
            this.setAddressType(parcelAddress.getAddressType());
            this.setHouseNumber(parcelAddress.getHouseNumber());
            this.setStreetNumber(parcelAddress.getStreetNumber());
            this.setZip(parcelAddress.getZip());
        }

        this.setIdentCode(parcelInfo.getIdentCode());
        this.setKey(parcelInfo.getKey());
        this.setParPicId(parcelInfo.getParPicId());

        this.setProduktZusatzleistung(String.join(Constant.CHAR_COMMA, parcelInfo.getProduktZusatzleistungensAsArray()));

        this.setSourceStation(parcelInfo.getSourceStation());

        this.setTimeStamp(DateUtil.gregorian2Timestamp(parcelInfo.getTimeStamp()));
        this.setVcsCase(parcelInfo.getVcsCase());
        this.setParcelInfoSentTime(DateUtil.gregorian2Timestamp(parcelInfo.getParcelInfoSentTimestamp()));
        this.setVersion(parcelInfo.getVersion());
        this.setCallerId(parcelInfo.getCallerId());

        this.updateInfo(parcelInfo);
    }

    /**
     * Gets the address type.
     *
     * @return the address type
     */
    @Column(name = "address_type", length = 100)
    public String getAddressType() {
        return this.addressType;
    }

    /**
     * Gets the barcode data time.
     *
     * @return the barcode data time
     */
    @Column(name = "barcode_data_begin")
    public Timestamp getBarcodeDataBegin() {
        return this.barcodeDataBegin;
    }

    /**
     * Gets the barcode data count.
     *
     * @return the barcode data count
     */
    @Column(name = "barcode_data_count")
    public Integer getBarcodeDataCount() {
        return this.barcodeDataCount;
    }

    /**
     * Gets the barcode data done time.
     *
     * @return the barcode data done time
     */
    @Column(name = "barcode_data_end")
    public Timestamp getBarcodeDataEnd() {
        return this.barcodeDataEnd;
    }

    /**
     * Gets the barcodes.
     *
     * @return the barcodes
     */
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "parcelInfo", fetch = FetchType.LAZY)
    public List<BarcodeEntity> getBarcodes() {
        if (this.barcodes == null) {
            this.barcodes = new ArrayList<>();
        }
        return this.barcodes;
    }

    /**
     * Gets the blackbox time.
     *
     * @return the blackbox time
     */
    @Column(name = "blackbox_begin")
    public Timestamp getBlackboxBegin() {
        return this.blackboxBegin;
    }

    /**
     * Gets the blackbox count.
     *
     * @return the blackbox count
     */
    @Column(name = "blackbox_count")
    public Integer getBlackboxCount() {
        return this.blackboxCount;
    }

    /**
     * Gets the blackbox done time.
     *
     * @return the blackbox done time
     */
    @Column(name = "blackbox_end")
    public Timestamp getBlackboxEnd() {
        return this.blackboxEnd;
    }

    /**
     * Gets the caller id.
     *
     * @return the caller id
     */
    @Column(name = "caller_id", length = 20)
    public String getCallerId() {
        return this.callerId;
    }

    /**
     * Gets the capture result time.
     *
     * @return the capture result time
     */
    @Column(name = "capture_result_begin")
    public Timestamp getCaptureResultBegin() {
        return this.captureResultBegin;
    }

    /**
     * Gets the capture result count.
     *
     * @return the capture result count
     */
    @Column(name = "capture_result_count")
    public Integer getCaptureResultCount() {
        return this.captureResultCount;
    }

    /**
     * Gets the capture result done time.
     *
     * @return the capture result done time
     */
    @Column(name = "capture_result_end")
    public Timestamp getCaptureResultEnd() {
        return this.captureResultEnd;
    }

    /**
     * Gets the coding art.
     *
     * @return the coding art
     */
    @Column(name = "coding_art", length = 100)
    public String getCodingArt() {
        return this.codingArt;
    }

    /**
     * Gets the coding quality.
     *
     * @return the coding quality
     */
    @Column(name = "coding_quality", length = 100)
    public String getCodingQuality() {
        return this.codingQuality;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.entity.InternalEntity#getCreated()
     */
    @Override
    @Column(name = "created")
    public long getCreated() {
        return super.getCreated();
    }

    /**
     * Gets the destination station.
     *
     * @return the destination station
     */
    @Column(name = "destination_station", length = 100)
    public String getDestinationStation() {
        return this.destinationStation;
    }

    /**
     * Gets the dmc time.
     *
     * @return the dmc time
     */
    @Column(name = "dmc_begin")
    public Timestamp getDmcBegin() {
        return this.dmcBegin;
    }

    /**
     * Gets the dmc count.
     *
     * @return the dmc count
     */
    @Column(name = "dmc_count")
    public Integer getDmcCount() {
        return this.dmcCount;
    }

    /**
     * Gets the dmc done time.
     *
     * @return the dmc done time
     */
    @Column(name = "dmc_end")
    public Timestamp getDmcEnd() {
        return this.dmcEnd;
    }

    /**
     * Gets the dmc sent.
     *
     * @return the dmc sent
     */
    @Column(name = "dmc_sent")
    public Timestamp getDmcSent() {
        return this.dmcSent;
    }

    /**
     * Gets the dmc state.
     *
     * @return the dmc state
     */
    @Column(name = "dmc_state", length = 50)
    public String getDmcState() {
        return this.dmcState;
    }

    /**
     * Gets the file name.
     *
     * @return the file name
     */
    @Column(name = "file_name", length = 100)
    public String getFileName() {
        return this.fileName;
    }

    /**
     * Gets the file path.
     *
     * @return the file path
     */
    @Column(name = "file_path", length = 100)
    public String getFilePath() {
        return this.filePath;
    }

    /**
     * Gets the filtered by rule.
     *
     * @return the filtered by rule
     */
    @Column(name = "filtered_by_rule", length = 200)
    public String getFilteredByRule() {
        return this.filteredByRule;
    }

    /**
     * Gets the finished processing time.
     *
     * @return the finished processing time
     */
    @Column(name = "processing_end")
    public Timestamp getFinishedProcessingTime() {
        return this.finishedProcessingTime;
    }

    /**
     * Gets the full address.
     *
     * @return the full address
     */
    @OneToOne(cascade = CascadeType.ALL)
    public FullAddressEntity getFullAddress() {
        return this.fullAddress;
    }

    /**
     * Gets the checks for image.
     *
     * @return the checks for image
     */
    @Column(name = "has_image", length = 100)
    public Boolean getHasImage() {
        return this.hasImage;
    }

    /**
     * Gets the house number.
     *
     * @return the house number
     */
    @Column(name = "house_number", length = 100)
    public String getHouseNumber() {
        return this.houseNumber;
    }

    /**
     * Gets the ident code.
     *
     * @return the ident code
     */
    @Column(name = "ident_code", length = 100)
    public String getIdentCode() {
        return this.identCode;
    }

    /**
     * Gets the key.
     *
     * @return the key
     */
    @Id
    @Column(name = "key", length = 50)
    public String getKey() {
        return this.key;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.entity.InternalEntity#getLifespan()
     */
    @Override
    @Column(name = "lifespan")
    public long getLifespan() {
        return super.getLifespan();
    }

    /**
     * Gets the look up done time.
     *
     * @return the look up done time
     */
    @Column(name = "lookup_end")
    public Timestamp getLookUpDoneTime() {
        return this.lookUpDoneTime;
    }

    /**
     * Gets the look up start time.
     *
     * @return the look up start time
     */
    @Column(name = "lookup_begin")
    public Timestamp getLookUpStartTime() {
        return this.lookUpStartTime;
    }

    /**
     * Gets the parcel info sent time.
     *
     * @return the parcel info sent time
     */
    @Column(name = "parcel_info_sent_time")
    public Timestamp getParcelInfoSentTime() {
        return this.parcelInfoSentTime;
    }

    /**
     * Gets the par pic id.
     *
     * @return the par pic id
     */
    @Column(name = "parpic_id", length = 100)
    public String getParPicId() {
        return this.parPicId;
    }

    /**
     * Gets the produkt zusatzleistung.
     *
     * @return the produkt zusatzleistung
     */
    @Column(name = "produkt_zusatz_leistung", length = 100)
    public String getProduktZusatzleistung() {
        return this.produktZusatzleistung;
    }

    /**
     * Gets the received time.
     *
     * @return the received time
     */
    @Column(name = "received_time")
    public Timestamp getReceivedTime() {
        return this.receivedTime;
    }

    /**
     * Gets the source station.
     *
     * @return the source station
     */
    @Column(name = "source_station", length = 100)
    public String getSourceStation() {
        return this.sourceStation;
    }

    /**
     * Gets the start processing time.
     *
     * @return the start processing time
     */
    @Column(name = "processing_begin")
    public Timestamp getStartProcessingTime() {
        return this.startProcessingTime;
    }

    /**
     * Gets the state.
     *
     * @return the state
     */
    @Column(name = "state", length = 100)
    public String getState() {
        return this.state;
    }

    /**
     * Gets the status code.
     *
     * @return the status code
     */
    @Column(name = "status_code", length = 20)
    public String getStatusCode() {
        return this.statusCode;
    }

    /**
     * Gets the stored data time.
     *
     * @return the stored data time
     */
    @Column(name = "stored_data_time")
    public Timestamp getStoredDataTime() {
        return this.storedDataTime;
    }

    /**
     * Gets the stored image time.
     *
     * @return the stored image time
     */
    @Column(name = "stored_image_time")
    public Timestamp getStoredImageTime() {
        return this.storedImageTime;
    }

    /**
     * Gets the street number.
     *
     * @return the street number
     */
    @Column(name = "street_number", length = 100)
    public String getStreetNumber() {
        return this.streetNumber;
    }

    /**
     * Gets the time stamp.
     *
     * @return the time stamp
     */
    @Column(name = "timestamps")
    public Timestamp getTimeStamp() {
        return this.timeStamp;
    }

    /**
     * Gets the vcs case.
     *
     * @return the vcs case
     */
    @Column(name = "vcscase", length = 100)
    public Integer getVcsCase() {
        return this.vcsCase;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    @Column(name = "version")
    public Integer getVersion() {
        return this.version;
    }

    /**
     * Gets the zip.
     *
     * @return the zip
     */
    @Column(name = "zip", length = 100)
    public String getZip() {
        return this.zip;
    }

    /**
     * Sets the address type.
     *
     * @param addressType
     *            the new address type
     */
    public void setAddressType(final String addressType) {
        this.addressType = addressType;
    }

    /**
     * Sets the barcode data time.
     *
     * @param barcodeDataBegin
     *            the new barcode data time
     */
    public void setBarcodeDataBegin(final Timestamp barcodeDataBegin) {
        this.barcodeDataBegin = barcodeDataBegin;
    }

    /**
     * Sets the barcode data count.
     *
     * @param barcodeDataCount the new barcode data count
     */
    public void setBarcodeDataCount(final Integer barcodeDataCount) {
        this.barcodeDataCount = barcodeDataCount;
    }

    /**
     * Sets the barcode data done time.
     *
     * @param barcodeDataEnd the new barcode data end
     */
    public void setBarcodeDataEnd(final Timestamp barcodeDataEnd) {
        this.barcodeDataEnd = barcodeDataEnd;
    }

    /**
     * Sets the barcodes.
     *
     * @param barcodes
     *            the new barcodes
     */
    public void setBarcodes(final List<BarcodeEntity> barcodes) {
        this.barcodes = barcodes;
    }

    /**
     * Sets the blackbox time.
     *
     * @param blackboxBegin
     *            the new blackbox time
     */
    public void setBlackboxBegin(final Timestamp blackboxBegin) {
        this.blackboxBegin = blackboxBegin;
    }

    /**
     * Sets the blackbox count.
     *
     * @param blackboxCount the new blackbox count
     */
    public void setBlackboxCount(final Integer blackboxCount) {
        this.blackboxCount = blackboxCount;
    }

    /**
     * Sets the blackbox done time.
     *
     * @param blackboxEnd the new blackbox end
     */
    public void setBlackboxEnd(final Timestamp blackboxEnd) {
        this.blackboxEnd = blackboxEnd;
    }

    /**
     * Sets the caller id.
     *
     * @param callerId the new caller id
     */
    public void setCallerId(final String callerId) {
        this.callerId = callerId;
    }

    /**
     * Sets the capture result time.
     *
     * @param captureResultBegin
     *            the new capture result time
     */
    public void setCaptureResultBegin(final Timestamp captureResultBegin) {
        this.captureResultBegin = captureResultBegin;
    }

    /**
     * Sets the capture result count.
     *
     * @param captureResultCount the new capture result count
     */
    public void setCaptureResultCount(final Integer captureResultCount) {
        this.captureResultCount = captureResultCount;
    }

    /**
     * Sets the capture result done time.
     *
     * @param captureResultEnd the new capture result done time
     */
    public void setCaptureResultEnd(final Timestamp captureResultEnd) {
        this.captureResultEnd = captureResultEnd;
    }

    /**
     * Sets the coding art.
     *
     * @param codingArt
     *            the new coding art
     */
    public void setCodingArt(final String codingArt) {
        this.codingArt = codingArt;
    }

    /**
     * Sets the coding quality.
     *
     * @param codingQuality
     *            the new coding quality
     */
    public void setCodingQuality(final String codingQuality) {
        this.codingQuality = codingQuality;
    }

    /**
     * Sets the destination station.
     *
     * @param destinationStation
     *            the new destination station
     */
    public void setDestinationStation(final String destinationStation) {
        this.destinationStation = destinationStation;
    }

    /**
     * Sets the dmc time.
     *
     * @param dmcBegin
     *            the new dmc time
     */
    public void setDmcBegin(final Timestamp dmcBegin) {
        this.dmcBegin = dmcBegin;
    }

    /**
     * Sets the dmc count.
     *
     * @param dmcCount the new dmc count
     */
    public void setDmcCount(final Integer dmcCount) {
        this.dmcCount = dmcCount;
    }

    /**
     * Sets the dmc done time.
     *
     * @param dmcEnd the new dmc done time
     */
    public void setDmcEnd(final Timestamp dmcEnd) {
        this.dmcEnd = dmcEnd;
    }

    /**
     * Sets the dmc sent.
     *
     * @param dmcSent the new dmc sent
     */
    public void setDmcSent(final Timestamp dmcSent) {
        this.dmcSent = dmcSent;
    }

    /**
     * Sets the dmc state.
     *
     * @param dmcState the new dmc state
     */
    public void setDmcState(final String dmcState) {
        this.dmcState = dmcState;
    }

    /**
     * Sets the file name.
     *
     * @param fileName
     *            the new file name
     */
    public void setFileName(final String fileName) {
        this.fileName = fileName;
    }

    /**
     * Sets the file path.
     *
     * @param filePath
     *            the new file path
     */
    public void setFilePath(final String filePath) {
        this.filePath = filePath;
    }

    /**
     * Sets the filtered by rule.
     *
     * @param filteredByRule the new filtered by rule
     */
    public void setFilteredByRule(final String filteredByRule) {
        this.filteredByRule = filteredByRule;
    }

    /**
     * Sets the finished processing time.
     *
     * @param finishedProcessingTime the new finished processing time
     */
    public void setFinishedProcessingTime(final Timestamp finishedProcessingTime) {
        this.finishedProcessingTime = finishedProcessingTime;
    }

    /**
     * Sets the full address.
     *
     * @param fullAddress
     *            the new full address
     */
    public void setFullAddress(final FullAddressEntity fullAddress) {
        this.fullAddress = fullAddress;
    }

    /**
     * Sets the checks for image.
     *
     * @param hasImage
     *            the new checks for image
     */
    public void setHasImage(final Boolean hasImage) {
        this.hasImage = hasImage;
    }

    /**
     * Sets the house number.
     *
     * @param houseNumber
     *            the new house number
     */
    public void setHouseNumber(final String houseNumber) {
        this.houseNumber = houseNumber;
    }

    /**
     * Sets the ident code.
     *
     * @param identCode
     *            the new ident code
     */
    public void setIdentCode(final String identCode) {
        this.identCode = identCode;
    }

    /**
     * Sets the key.
     *
     * @param key
     *            the new key
     */
    public void setKey(final String key) {
        this.key = key;
    }

    /**
     * Sets the look up done time.
     *
     * @param lookUpDoneTime the new look up done time
     */
    public void setLookUpDoneTime(final Timestamp lookUpDoneTime) {
        this.lookUpDoneTime = lookUpDoneTime;
    }

    /**
     * Sets the look up start time.
     *
     * @param lookUpStartTime the new look up start time
     */
    public void setLookUpStartTime(final Timestamp lookUpStartTime) {
        this.lookUpStartTime = lookUpStartTime;
    }

    /**
     * Sets the parcel info sent time.
     *
     * @param parcelInfoSentTime the new parcel info sent time
     */
    public void setParcelInfoSentTime(final Timestamp parcelInfoSentTime) {
        this.parcelInfoSentTime = parcelInfoSentTime;
    }

    /**
     * Sets the par pic id.
     *
     * @param parPicId
     *            the new par pic id
     */
    public void setParPicId(final String parPicId) {
        this.parPicId = parPicId;
    }

    /**
     * Sets the produkt zusatzleistung.
     *
     * @param produktZusatzleistung
     *            the new produkt zusatzleistung
     */
    public void setProduktZusatzleistung(final String produktZusatzleistung) {
        this.produktZusatzleistung = produktZusatzleistung;
    }

    /**
     * Sets the received time.
     *
     * @param receivedTime
     *            the new received time
     */
    public void setReceivedTime(final Timestamp receivedTime) {
        this.receivedTime = receivedTime;
    }

    /**
     * Sets the source station.
     *
     * @param sourceStation
     *            the new source station
     */
    public void setSourceStation(final String sourceStation) {
        this.sourceStation = sourceStation;
    }

    /**
     * Sets the start processing time.
     *
     * @param startProcessingTime the new start processing time
     */
    public void setStartProcessingTime(final Timestamp startProcessingTime) {
        this.startProcessingTime = startProcessingTime;
    }

    /**
     * Sets the state.
     *
     * @param state
     *            the new state
     */
    public void setState(final String state) {
        this.state = state;
    }

    /**
     * Sets the status code.
     *
     * @param statusCode the new status code
     */
    public void setStatusCode(final String statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Sets the stored data time.
     *
     * @param storedDataTime the new stored data time
     */
    public void setStoredDataTime(final Timestamp storedDataTime) {
        this.storedDataTime = storedDataTime;
    }

    /**
     * Sets the stored image time.
     *
     * @param storedImageTime the new stored image time
     */
    public void setStoredImageTime(final Timestamp storedImageTime) {
        this.storedImageTime = storedImageTime;
    }

    /**
     * Sets the street number.
     *
     * @param streetNumber
     *            the new street number
     */
    public void setStreetNumber(final String streetNumber) {
        this.streetNumber = streetNumber;
    }

    /**
     * Sets the time stamp.
     *
     * @param timeStamp
     *            the new time stamp
     */
    public void setTimeStamp(final Timestamp timeStamp) {
        this.timeStamp = timeStamp;
    }

    /**
     * Sets the vcs case.
     *
     * @param vcsCase
     *            the new vcs case
     */
    public void setVcsCase(final Integer vcsCase) {
        this.vcsCase = vcsCase;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(final Integer version) {
        this.version = version;
    }

    /**
     * Sets the zip.
     *
     * @param zip
     *            the new zip
     */
    public void setZip(final String zip) {
        this.zip = zip;
    }

    /**
     * Update info.
     *
     * @param parcelInfo the parcel info
     */
    public void updateInfo(final ParcelInfo parcelInfo) {
        this.setState(parcelInfo.getState());
        this.setStatusCode(parcelInfo.getStatusCode());
        this.setReceivedTime(DateUtil.milliTime2Timestamp(parcelInfo.getReceived()));
        this.setFilteredByRule(parcelInfo.getFilteredByRule());

        // PADASA BarcodeService
        this.setBarcodeDataBegin(DateUtil.milliTime2Timestamp(parcelInfo.getBarcodeBegin()));
        this.setBarcodeDataEnd(DateUtil.milliTime2Timestamp(parcelInfo.getBarcodeEnd()));

        // VAM CaptureResultService
        this.setCaptureResultBegin(DateUtil.milliTime2Timestamp(parcelInfo.getCaptureResultBegin()));
        this.setCaptureResultEnd(DateUtil.milliTime2Timestamp(parcelInfo.getCaptureResultEnd()));

        // BlackBox CaptureRerequestService
        this.setBlackboxBegin(DateUtil.milliTime2Timestamp(parcelInfo.getBlackboxBegin()));
        this.setBlackboxEnd(DateUtil.milliTime2Timestamp(parcelInfo.getBlackboxEnd()));

        // DMC
        this.setDmcBegin(DateUtil.milliTime2Timestamp(parcelInfo.getDmcBegin()));
        this.setDmcEnd(DateUtil.milliTime2Timestamp(parcelInfo.getDmcEnd()));
        this.setDmcSent(DateUtil.milliTime2Timestamp(parcelInfo.getDmcSent()));

        this.setStoredImageTime(DateUtil.milliTime2Timestamp(parcelInfo.getStoredImageTime()));
        this.setStoredDataTime(DateUtil.milliTime2Timestamp(parcelInfo.getStoredDataTime()));

        this.setStartProcessingTime(DateUtil.milliTime2Timestamp(parcelInfo.getProcessBegin()));
        this.setFinishedProcessingTime(DateUtil.milliTime2Timestamp(parcelInfo.getProcessEnd()));

        this.setLookUpStartTime(DateUtil.milliTime2Timestamp(parcelInfo.getLookupBegin()));
        this.setLookUpDoneTime(DateUtil.milliTime2Timestamp(parcelInfo.getLookupEnd()));

        this.setDmcCount(parcelInfo.getDmcCount());
        this.setCaptureResultCount(parcelInfo.getVamSentCount());
        this.setBarcodeDataCount(parcelInfo.getBarcodeCount());
        this.setBlackboxCount(parcelInfo.getBlackboxCount());

        this.setDmcState(parcelInfo.getDmcState().name());
    }
}
