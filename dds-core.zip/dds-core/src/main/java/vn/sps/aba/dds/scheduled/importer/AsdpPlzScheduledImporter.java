/*
 * Class: BarcodeScheduledSender
 *
 * Created on Oct 12, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.importer;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.config.task.scheduler.WorkspaceScheduleExecutor;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.repository.importing.IAsdpImporter;
import vn.sps.aba.dds.repository.importing.report.IAsdpImportingReport;
import vn.sps.aba.dds.scheduled.AbstractCronScheduler;
import vn.sps.aba.dds.scheduled.DdsScheduledTask;

/**
 * The Class MatchmakerScheduledSender.
 */
@Component("AsdpPlzScheduledImporter")
@Configuration
@ConfigurationProperties("schedule.import.asdp")
public class AsdpPlzScheduledImporter extends AbstractCronScheduler implements DdsScheduledTask {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(AsdpPlzScheduledImporter.class);

    /** The asdp plz importer. */
    @Autowired
    private IAsdpImporter asdpPlzImporter;

    /** The scheduled executor. */
    @Autowired
    private WorkspaceScheduleExecutor scheduledExecutor;

    /**
     * Config.
     */
    @PostConstruct
    protected void config() {
        this.scheduleConfigurar.registerScheduledTask(this, this.scheduledExecutor);
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.beans.factory.DisposableBean#destroy()
     */
    @Override
    public void destroy() throws Exception {
        this.scheduledExecutor.getScheduler().destroy();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#getCronExpression()
     */
    @Override
    public String getCronExpression() {
        return this.getCron();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#handleTask()
     */
    @Override
    public Runnable handleTask() {
        return () -> {
            if (this.isEnable()) {
                LOG.info("Import Asdp Plz...");
                this.importData();
            }
        };
    }

    /**
     * Import data.
     *
     * @return the i asdp importing report
     */
    public IAsdpImportingReport importData() {
        final IAsdpImportingReport report = this.asdpPlzImporter.importData();
        LOG.info(IndexMaker.indexes(report), "Asdp importing report");
        return report;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#taskName()
     */
    @Override
    public String taskName() {
        return "asdp-plz-import";
    }

}
