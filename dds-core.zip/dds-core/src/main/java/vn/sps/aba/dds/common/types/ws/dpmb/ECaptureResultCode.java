
package vn.sps.aba.dds.common.types.ws.dpmb;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for eCaptureResultCode.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="eCaptureResultCode">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Ok"/>
 *     &lt;enumeration value="BildKorrupt"/>
 *     &lt;enumeration value="BildQualitaetNOk"/>
 *     &lt;enumeration value="KeineAdresseAufBild"/>
 *     &lt;enumeration value="AdresseUnvollstaendigAufBild"/>
 *     &lt;enumeration value="AdresseUnleserlichGeschrieben"/>
 *     &lt;enumeration value="EmpfaengerAdresseNichtIdentifizierbar"/>
 *     &lt;enumeration value="MehrereFelderNichtInDenStammdaten"/>
 *     &lt;enumeration value="OrtNichtInDenStammdaten"/>
 *     &lt;enumeration value="StrasseNichtInDenStammdaten"/>
 *     &lt;enumeration value="HausnummerOderZusatzNichtInDenStammdaten"/>
 *     &lt;enumeration value="EmpfaengerMehrfachInDenStammdaten"/>
 *     &lt;enumeration value="EmpfaengerAufAdresseNichtEindeutig"/>
 *     &lt;enumeration value="AdridZuPostfachPickpostOderKaserneNichtGefunden"/>
 *     &lt;enumeration value="KeineAdridInZubofiGefunden"/>
 *     &lt;enumeration value="KeineAdridInKdpGefunden"/>
 *     &lt;enumeration value="ErfassteAdresseHatUnterschiedeZuStammdaten"/>
 *     &lt;enumeration value="DatenMitAngabenAusVgKdpSpecial"/>
 *     &lt;enumeration value="DatenMitAngabenAusVgDl"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "eCaptureResultCode")
@XmlEnum
public enum ECaptureResultCode {

    @XmlEnumValue("Ok")
    OK("Ok"),
    @XmlEnumValue("BildKorrupt")
    BILD_KORRUPT("BildKorrupt"),
    @XmlEnumValue("BildQualitaetNOk")
    BILD_QUALITAET_N_OK("BildQualitaetNOk"),
    @XmlEnumValue("KeineAdresseAufBild")
    KEINE_ADRESSE_AUF_BILD("KeineAdresseAufBild"),
    @XmlEnumValue("AdresseUnvollstaendigAufBild")
    ADRESSE_UNVOLLSTAENDIG_AUF_BILD("AdresseUnvollstaendigAufBild"),
    @XmlEnumValue("AdresseUnleserlichGeschrieben")
    ADRESSE_UNLESERLICH_GESCHRIEBEN("AdresseUnleserlichGeschrieben"),
    @XmlEnumValue("EmpfaengerAdresseNichtIdentifizierbar")
    EMPFAENGER_ADRESSE_NICHT_IDENTIFIZIERBAR("EmpfaengerAdresseNichtIdentifizierbar"),
    @XmlEnumValue("MehrereFelderNichtInDenStammdaten")
    MEHRERE_FELDER_NICHT_IN_DEN_STAMMDATEN("MehrereFelderNichtInDenStammdaten"),
    @XmlEnumValue("OrtNichtInDenStammdaten")
    ORT_NICHT_IN_DEN_STAMMDATEN("OrtNichtInDenStammdaten"),
    @XmlEnumValue("StrasseNichtInDenStammdaten")
    STRASSE_NICHT_IN_DEN_STAMMDATEN("StrasseNichtInDenStammdaten"),
    @XmlEnumValue("HausnummerOderZusatzNichtInDenStammdaten")
    HAUSNUMMER_ODER_ZUSATZ_NICHT_IN_DEN_STAMMDATEN("HausnummerOderZusatzNichtInDenStammdaten"),
    @XmlEnumValue("EmpfaengerMehrfachInDenStammdaten")
    EMPFAENGER_MEHRFACH_IN_DEN_STAMMDATEN("EmpfaengerMehrfachInDenStammdaten"),
    @XmlEnumValue("EmpfaengerAufAdresseNichtEindeutig")
    EMPFAENGER_AUF_ADRESSE_NICHT_EINDEUTIG("EmpfaengerAufAdresseNichtEindeutig"),
    @XmlEnumValue("AdridZuPostfachPickpostOderKaserneNichtGefunden")
    ADRID_ZU_POSTFACH_PICKPOST_ODER_KASERNE_NICHT_GEFUNDEN("AdridZuPostfachPickpostOderKaserneNichtGefunden"),
    @XmlEnumValue("KeineAdridInZubofiGefunden")
    KEINE_ADRID_IN_ZUBOFI_GEFUNDEN("KeineAdridInZubofiGefunden"),
    @XmlEnumValue("KeineAdridInKdpGefunden")
    KEINE_ADRID_IN_KDP_GEFUNDEN("KeineAdridInKdpGefunden"),
    @XmlEnumValue("ErfassteAdresseHatUnterschiedeZuStammdaten")
    ERFASSTE_ADRESSE_HAT_UNTERSCHIEDE_ZU_STAMMDATEN("ErfassteAdresseHatUnterschiedeZuStammdaten"),
    @XmlEnumValue("DatenMitAngabenAusVgKdpSpecial")
    DATEN_MIT_ANGABEN_AUS_VG_KDP_SPECIAL("DatenMitAngabenAusVgKdpSpecial"),
    @XmlEnumValue("DatenMitAngabenAusVgDl")
    DATEN_MIT_ANGABEN_AUS_VG_DL("DatenMitAngabenAusVgDl");
    private final String value;

    ECaptureResultCode(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ECaptureResultCode fromValue(String v) {
        for (ECaptureResultCode c: ECaptureResultCode.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
