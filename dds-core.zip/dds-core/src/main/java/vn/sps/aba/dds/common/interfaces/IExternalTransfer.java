/*
 * Class: IExternalTransfer
 *
 * Created on Jul 1, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.interfaces;

/**
 * The Interface IExternalTransfer.
 *
 * @param <T> the generic type
 * @param <R> the generic type
 */
public interface IExternalTransfer<T, R> {

    /**
     * Transfer.
     *
     * @param transferedObject the transfered object
     * @return the r
     */
    R transfer(T transferedObject);

    /**
     * Transfer cascade.
     *
     * @param transferedObject the transfered object
     * @return the r
     */
    R transferCancade(T transferedObject);
}
