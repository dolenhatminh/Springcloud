/*
 * Class: EnhancedDirectoryProvider
 *
 * Created on Aug 10, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.io.impl;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.config.CommonConfiguration;
import vn.sps.aba.dds.io.IImageStorageProvider;
import vn.sps.aba.dds.service.pds.parcel.IImageInfo;

/**
 * The Class EnhancedDirectoryProvider.
 */
@Profile(Profiles.PARCEL)
@Component
public class ImageDirectoryProvider implements IImageStorageProvider {

    /**
     * The Class DateDir.
     */
    private class DateDir {
        /** The counter. */
        private final AtomicInteger counter;

        /** The date. */
        @SuppressWarnings("unused")
        private final LocalDate date;

        /** The current dir. */
        private File todayDir;

        /**
         * Instantiates a new date dir.
         *
         * @param date the date
         */
        public DateDir(final LocalDate date) {
            this.date = date;
            this.counter = new AtomicInteger();
        }
    }

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ImageDirectoryProvider.class);

    /** The common configuration. */
    @Autowired
    private CommonConfiguration configuration;

    /** The date dirs. */
    private final Map<LocalDate, DateDir> dateDirs = new HashMap<>();

    /** The wall clock. */
    // Warning: dont remove this autowire although it is not used
    //  This autowire to make Spring initialize the bean DiscoWallClock
    //  If we do not do this, the initialize() function will be malfunction with null pointer
    @SuppressWarnings("unused")
    @Autowired
    private DiscoWallClock wallClock;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.io.IImageStorageProvider#addFolder(java.time.LocalDate, int)
     */
    @Override
    public void addFolder(final LocalDate date, final int order) {

        DateDir dir = this.dateDirs.get(date);

        if (dir == null) {
            dir = new DateDir(date);
            dir.counter.set(order);
        }
        else if (dir.counter.get() < order) {
            dir.counter.set(order);
        }

        this.dateDirs.put(date, dir);
        LOG.info("Atom integer: {}", dir.counter.get());
    }

    /**
     * Count num of files.
     *
     * @param dir the dir
     * @return the int
     */
    private int countNumOfFiles(final File dir) {
        int totalFiles = 0;

        final List<File> listFiles = Arrays.asList(dir.listFiles());

        if (!CollectionUtils.isEmpty(listFiles)) {
            totalFiles += listFiles.parallelStream().filter(f -> f.isFile()).count();
            totalFiles += listFiles.parallelStream().filter(f -> f.isDirectory()).mapToLong(f -> this.countNumOfFiles(f)).sum();
        }

        return totalFiles;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.io.IImageStorageProvider#fileCount(java.time.LocalDate)
     */
    @Override
    public int fileCount(final LocalDate date) {
        final DateDir dateDir = this.dateDirs.get(date);
        if (dateDir != null) {
            return dateDir.counter.get();
        }
        return -1;
    }

    /**
     * Gets the by date.
     *
     * @param date the date
     * @return the by date
     */
    private synchronized DateDir getByDate(final LocalDate date) {
        DateDir dateDir = this.dateDirs.get(date);

        if (dateDir == null) {
            this.scanDirectory(date);
            dateDir = this.dateDirs.get(date);
        }

        return dateDir;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.io.IImageStorageProvider#getFolder(java.time.LocalDate)
     */
    @Override
    public File getFolder(final LocalDate date) {
        final DateDir dateDir = this.getByDate(date);
        final long folderId = (dateDir.counter.getAndIncrement() / this.configuration.getImagePerFolder()) + 1;
        return new File(dateDir.todayDir.getAbsolutePath() + Constant.FILE_SEPARATOR + folderId);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.io.IImageStorageProvider#getFolder(java.time.LocalDate, vn.sps.aba.dds.service.pds.parcel.IImageInfo)
     */
    @Override
    public void getFolder(final LocalDate date, final IImageInfo imageInfo) {
        final DateDir dateDir = this.getByDate(date);
        final int order = dateDir.counter.getAndIncrement();
        final int folderId = (order / this.configuration.getImagePerFolder()) + 1;
        imageInfo.setDirectory(dateDir.todayDir.getAbsolutePath() + Constant.FILE_SEPARATOR + folderId);
        imageInfo.setOrder(order);
    }

    /**
     * Initialize.
     */
    @PostConstruct
    protected void initialize() {
        final LocalDate today = LocalDate.now(DiscoWallClock.zone());
        this.scanDirectory(today);
        final LocalDate tomorrow = today.plusDays(1);
        this.scanDirectory(tomorrow);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.io.IImageStorageProvider#scanDirectory(java.time.LocalDate)
     */
    @Override
    public void scanDirectory(final LocalDate date) {
        final File imageDir = new File(this.configuration.getSharedStorage());
        if (!imageDir.isDirectory()) {
            throw new IllegalArgumentException("Cannot find image directory " + this.configuration.getSharedStorage());
        }
        if (!imageDir.canWrite()) {
            throw new IllegalArgumentException("Cannot write image to directory " + this.configuration.getSharedStorage());
        }
        final String imageFolderFormat = this.configuration.getImageDirFormat();
        final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(imageFolderFormat);
        final String folderName = formatter.format(date);
        final String datePath = String.join(Constant.FILE_SEPARATOR, imageDir.getAbsolutePath(), folderName);
        final File currentDateDir = new File(datePath);

        final DateDir dateDir = new DateDir(date);
        dateDir.todayDir = currentDateDir;

        if (currentDateDir.isDirectory()) {
            LOG.info("Image directory for date {} exists. Scan this directory...", date);

            final long begin = DiscoWallClock.milli();
            final int count = this.countNumOfFiles(currentDateDir);
            LOG.info("Total {} files. It takes {} milliseconds to scan", count, (DiscoWallClock.milli() - begin));
            dateDir.counter.set(count);
        }
        else {
            LOG.info("Create image directory for new date {}", date);
            currentDateDir.mkdirs();
            dateDir.counter.set(0);
        }

        this.dateDirs.put(date, dateDir);
    }

}
