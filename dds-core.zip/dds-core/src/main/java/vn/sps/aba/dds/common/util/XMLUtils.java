/*
 * Class: XMLUtils
 *
 * Created on Jun 25, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.util;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;

import com.thoughtworks.xstream.XStream;

/**
 * The Class XMLUtils.
 */
public final class XMLUtils {

    /** The Constant BUFFER_SIZE. */
    private static final int BUFFER_SIZE = 1024;

    /**
     * Close.
     *
     * @param o the o
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private static final void close(final Closeable o) throws IOException {
        if (o != null) {
            o.close();
        }
    }

    /**
     * Convert stream to string.
     *
     * @param is the is
     * @return the string
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private static String convertStreamToString(final InputStream is) throws IOException {
        String result = null;

        if (is != null) {
            final Writer writer = new StringWriter();

            final char[] buffer = new char[XMLUtils.BUFFER_SIZE];
            try {
                final Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                int n;
                while ((n = reader.read(buffer)) != -1) {
                    writer.write(buffer, 0, n);
                }
                result = writer.toString();
            }
            finally {
                XMLUtils.close(writer);
                XMLUtils.close(is);
            }
        }
        return result;
    }

    /**
     * Deserialize.
     *
     * @param <T> the generic type
     * @param inputStream the input stream
     * @param clazz the clazz
     * @return the t
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static <T> T deserialize(final InputStream inputStream, final Class<T> clazz) throws IOException {
        final XStream serialize = new XStream();
        T manifest = null;

        serialize.autodetectAnnotations(true);
        serialize.processAnnotations(clazz);
        final String stream = XMLUtils.convertStreamToString(inputStream);

        if (stream != null) {
            manifest = clazz.cast(serialize.fromXML(stream));
        }

        return manifest;
    }

    /**
     * Deserialize.
     *
     * @param <T> the generic type
     * @param inputStream the input stream
     * @param clazz the clazz
     * @param alias the alias
     * @return the t
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static <T> T deserialize(final InputStream inputStream, final Class<T> clazz, final Map<String, Class<?>> alias) throws IOException {
        final XStream serialize = new XStream();

        for (final Entry<String, Class<?>> iter : alias.entrySet()) {
            if ((iter != null) && (iter.getValue() != null)) {
                serialize.alias(iter.getKey(), iter.getValue());
            }
        }

        T manifest = null;

        serialize.autodetectAnnotations(true);
        final String stream = XMLUtils.convertStreamToString(inputStream);

        if (stream != null) {
            manifest = clazz.cast(serialize.fromXML(stream));
        }

        return manifest;
    }

    /**
     * Deserialize.
     *
     * @param <T> the generic type
     * @param text the text
     * @param clazz the clazz
     * @return the t
     */
    public static <T> T deserialize(final String text, final Class<T> clazz) {
        final XStream serialize = new XStream();
        T manifest = null;

        serialize.autodetectAnnotations(true);
        if (text != null) {
            final Object obj = serialize.fromXML(text);
            manifest = clazz.cast(obj);
        }

        return manifest;
    }

    /**
     * Marshall.
     *
     * @param object the object
     * @param marshaller the marshaller
     * @return the document
     * @throws ParserConfigurationException the parser configuration exception
     * @throws JAXBException the JAXB exception
     */
    public static Document marshall(final Object object, final Marshaller marshaller) throws ParserConfigurationException, JAXBException {
        final DocumentBuilderFactory documentBuilder = DocumentBuilderFactory.newInstance();
        documentBuilder.setNamespaceAware(true);
        final DocumentBuilder db = documentBuilder.newDocumentBuilder();
        final Document ret = db.newDocument();
        marshaller.marshal(object, ret);
        return ret;
    }

    /**
     * Serialize.
     *
     * @param object the object
     * @param outputFile the output file
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static void serialize(final Object object, final String outputFile) throws IOException {
        final XStream xStream = new XStream();
        FileOutputStream fos = null;

        try {
            fos = new FileOutputStream(outputFile);
            xStream.autodetectAnnotations(true);
            xStream.toXML(object, fos);
            fos.flush();
        }
        finally {
            XMLUtils.close(fos);
        }
    }

    /**
     * Instantiates a new xML utils.
     */
    private XMLUtils() {
    }

}
