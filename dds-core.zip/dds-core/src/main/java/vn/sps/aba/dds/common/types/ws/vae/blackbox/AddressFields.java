
package vn.sps.aba.dds.common.types.ws.vae.blackbox;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddressFields complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddressFields">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Anrede" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CoAdresse" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Firmenname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Hausnummer" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="HausnummerZusatz" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Land" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NameZusatz" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ort" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Postfach" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Postleitzahl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Stockwerk" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Strasse" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Vorname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddressFields", propOrder = {
    "anrede",
    "coAdresse",
    "firmenname",
    "hausnummer",
    "hausnummerZusatz",
    "land",
    "name",
    "nameZusatz",
    "ort",
    "postfach",
    "postleitzahl",
    "stockwerk",
    "strasse",
    "vorname"
})
public class AddressFields {

    @XmlElementRef(name = "Anrede", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> anrede;
    @XmlElementRef(name = "CoAdresse", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> coAdresse;
    @XmlElementRef(name = "Firmenname", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> firmenname;
    @XmlElement(name = "Hausnummer")
    protected Integer hausnummer;
    @XmlElementRef(name = "HausnummerZusatz", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> hausnummerZusatz;
    @XmlElementRef(name = "Land", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> land;
    @XmlElementRef(name = "Name", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> name;
    @XmlElementRef(name = "NameZusatz", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> nameZusatz;
    @XmlElementRef(name = "Ort", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> ort;
    @XmlElement(name = "Postfach")
    protected Integer postfach;
    @XmlElementRef(name = "Postleitzahl", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> postleitzahl;
    @XmlElementRef(name = "Stockwerk", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> stockwerk;
    @XmlElementRef(name = "Strasse", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> strasse;
    @XmlElementRef(name = "Vorname", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> vorname;

    /**
     * Gets the value of the anrede property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAnrede() {
        return anrede;
    }

    /**
     * Sets the value of the anrede property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAnrede(JAXBElement<String> value) {
        this.anrede = value;
    }

    /**
     * Gets the value of the coAdresse property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCoAdresse() {
        return coAdresse;
    }

    /**
     * Sets the value of the coAdresse property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCoAdresse(JAXBElement<String> value) {
        this.coAdresse = value;
    }

    /**
     * Gets the value of the firmenname property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFirmenname() {
        return firmenname;
    }

    /**
     * Sets the value of the firmenname property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFirmenname(JAXBElement<String> value) {
        this.firmenname = value;
    }

    /**
     * Gets the value of the hausnummer property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getHausnummer() {
        return hausnummer;
    }

    /**
     * Sets the value of the hausnummer property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setHausnummer(Integer value) {
        this.hausnummer = value;
    }

    /**
     * Gets the value of the hausnummerZusatz property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getHausnummerZusatz() {
        return hausnummerZusatz;
    }

    /**
     * Sets the value of the hausnummerZusatz property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setHausnummerZusatz(JAXBElement<String> value) {
        this.hausnummerZusatz = value;
    }

    /**
     * Gets the value of the land property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLand() {
        return land;
    }

    /**
     * Sets the value of the land property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLand(JAXBElement<String> value) {
        this.land = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setName(JAXBElement<String> value) {
        this.name = value;
    }

    /**
     * Gets the value of the nameZusatz property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNameZusatz() {
        return nameZusatz;
    }

    /**
     * Sets the value of the nameZusatz property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNameZusatz(JAXBElement<String> value) {
        this.nameZusatz = value;
    }

    /**
     * Gets the value of the ort property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOrt() {
        return ort;
    }

    /**
     * Sets the value of the ort property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOrt(JAXBElement<String> value) {
        this.ort = value;
    }

    /**
     * Gets the value of the postfach property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPostfach() {
        return postfach;
    }

    /**
     * Sets the value of the postfach property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPostfach(Integer value) {
        this.postfach = value;
    }

    /**
     * Gets the value of the postleitzahl property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPostleitzahl() {
        return postleitzahl;
    }

    /**
     * Sets the value of the postleitzahl property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPostleitzahl(JAXBElement<String> value) {
        this.postleitzahl = value;
    }

    /**
     * Gets the value of the stockwerk property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getStockwerk() {
        return stockwerk;
    }

    /**
     * Sets the value of the stockwerk property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setStockwerk(JAXBElement<String> value) {
        this.stockwerk = value;
    }

    /**
     * Gets the value of the strasse property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getStrasse() {
        return strasse;
    }

    /**
     * Sets the value of the strasse property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setStrasse(JAXBElement<String> value) {
        this.strasse = value;
    }

    /**
     * Gets the value of the vorname property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getVorname() {
        return vorname;
    }

    /**
     * Sets the value of the vorname property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setVorname(JAXBElement<String> value) {
        this.vorname = value;
    }

}
