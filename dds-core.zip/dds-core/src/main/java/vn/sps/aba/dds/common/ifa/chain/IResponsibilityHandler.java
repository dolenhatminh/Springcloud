/*
 * Class: IReponsibilityExecutor
 *
 * Created on Jun 21, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.ifa.chain;

/**
 * The Interface IResponsibilityHandler.
 *
 * @param <T> the generic type
 * @param <R> the generic type
 */
public interface IResponsibilityHandler<T, R extends IStepResult> {

    /**
     * Handle.
     *
     * @param entry the entry
     * @return the r
     */
    R handleRequest(T entry);

    /**
     * Sets the next handler.
     *
     * @param nextHandler the next handler
     */
    void setNextHandler(IResponsibilityHandler<T, R> nextHandler);
}
