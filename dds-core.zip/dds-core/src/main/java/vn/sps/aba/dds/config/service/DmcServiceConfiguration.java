/*
 * Class: DmcServiceConfiguration
 *
 * Created on Jul 6, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.util.Assert;

import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.model.dmc.DMCFormat;

/**
 * The Class DmcServiceConfiguration.
 */
@Configuration("DmcServiceConfiguration")
@ConfigurationProperties(prefix = "dmc")
@Profile(value = { Profiles.PARCEL })
public class DmcServiceConfiguration extends AbstractRestWsConfiguration {

    /** The check existing interval. */
    private long checkExistingInterval;

    /** The check existing retry time. */
    private int checkExistingRetryTime;

    /**
     * The DMC formats.
     */
    private List<DMCFormat> dmcFormats = new ArrayList<>();

    /** The request queue name. */
    @Value("${dmc.request.queue}")
    private String requestQueueName;

    /** The dmc response queue name. */
    @Value("${dmc.response.queue}")
    private String responseQueueName;

    /** The send only dmc matching pattern. */
    private boolean sendOnlyDmcMatchingPattern;

    /** The type. */
    private String type = "DMC";

    /**
     * Gets the check existing interval.
     *
     * @return the check existing interval
     */
    public long getCheckExistingInterval() {
        return this.checkExistingInterval;
    }

    /**
     * Gets the check existing retry time.
     *
     * @return the check existing retry time
     */
    public int getCheckExistingRetryTime() {
        return this.checkExistingRetryTime;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ServiceInfo#getContextPath()
     */
    @Override
    public String getContextPath() {
        return "";
    }

    /**
     * Gets the dmc formats.
     *
     * @return the dmc formats
     */
    public List<DMCFormat> getDmcFormats() {
        return this.dmcFormats;
    }

    /**
     * Gets the request queue name.
     *
     * @return the request queue name
     */
    public String getRequestQueueName() {
        return this.requestQueueName;
    }

    /**
     * Gets the response queue name.
     *
     * @return the response queue name
     */
    public String getResponseQueueName() {
        return this.responseQueueName;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getServiceName()
     */
    @Override
    public String getServiceName() {
        return "DMC";
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return this.type;
    }

    /**
     * Checks if is send only dmc matching pattern.
     *
     * @return true, if is send only dmc matching pattern
     */
    public boolean isSendOnlyDmcMatchingPattern() {
        return this.sendOnlyDmcMatchingPattern;
    }

    /**
     * Prints the dmc formats.
     *
     * @return the string[]
     */
    @ManagedOperation
    public String[] printDmcFormats() {

        final List<String> formats = new ArrayList<>();

        for (final DMCFormat dmcFormat : this.dmcFormats) {
            formats.add(dmcFormat.toString());
        }

        return formats.toArray(new String[formats.size()]);
    }

    /**
     * Sets the check existing interval.
     *
     * @param checkExistingInterval the new check existing interval
     */
    public void setCheckExistingInterval(final long checkExistingInterval) {
        Assert.isTrue(checkExistingInterval > 0, "Invalid sleeping time.");
        this.checkExistingInterval = checkExistingInterval;
    }

    /**
     * Sets the check existing retry time.
     *
     * @param checkExistingRetryTime the new check existing retry time
     */
    public void setCheckExistingRetryTime(final int checkExistingRetryTime) {
        Assert.isTrue(checkExistingRetryTime >= 0, "Invalid retry value.");
        this.checkExistingRetryTime = checkExistingRetryTime;
    }

    /**
     * Sets the dmc formats.
     *
     * @param dmcFormats
     *            the new dmc formats
     */
    public void setDmcFormats(final List<DMCFormat> dmcFormats) {
        this.dmcFormats = dmcFormats;
    }

    /**
     * Sets the request queue name.
     *
     * @param requestQueueName the new request queue name
     */
    public void setRequestQueueName(final String requestQueueName) {
        this.requestQueueName = requestQueueName;
    }

    /**
     * Sets the response queue name.
     *
     * @param responseQueueName the new response queue name
     */
    public void setResponseQueueName(final String responseQueueName) {
        this.responseQueueName = responseQueueName;
    }

    /**
     * Sets the send only dmc matching pattern.
     *
     * @param sendOnlyDmcMatchingPattern the new send only dmc matching pattern
     */
    public void setSendOnlyDmcMatchingPattern(final boolean sendOnlyDmcMatchingPattern) {
        this.sendOnlyDmcMatchingPattern = sendOnlyDmcMatchingPattern;
    }

    /**
     * Sets the type.
     *
     * @param type the new type
     */
    public void setType(final String type) {
        this.type = type;
    }
}
