/*
 * Class: StateFilteringHandler
 *
 * Created on Jul 3, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.parcel.handers.impl;

import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.parcel.handers.IParcelStepHandler;
import vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext;

/**
 * The Class StateFilteringHandler.
 */
public class FilteringHandler extends AbstractParcelStepHandler implements IParcelStepHandler {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(FilteringHandler.class);

    /**
     * Instantiates a new state filtering handler.
     */
    public FilteringHandler() {
        super(PARCEL_STATE_FILTERING);
    }

    /**
     * Handle.
     *
     * @param context            the context
     * @param parcelInfo            the parcel info
     * @throws InterruptedException the interrupted exception
     * @throws ExecutionException the execution exception
     */
    @Override
    public void handle(final IParcelStateHandlerContext context, final ParcelInfo parcelInfo) throws InterruptedException, ExecutionException {

        context.getParcelInfoFilterer().handleRequest(parcelInfo);

        if (ParcelState.FILTERING == parcelInfo.getParcelState()) {

            final ParcelState defaultStateAfterFiltering = context.getDefaultStatusAfterFilter();
            parcelInfo.setState(defaultStateAfterFiltering);
            LOG.info(IndexMaker.index(parcelInfo), "There is no matching rule. Find a receiver info with the same ident code");
        }

        context.updateParcelInfo(parcelInfo);
        LOG.debug(IndexMaker.index(parcelInfo), "Filtering done");

        switch (parcelInfo.getParcelState()) {
        case DMC_PROCESSING:
            context.handle(PARCEL_STATE_DMCING, parcelInfo);
            break;

        case MATCHING_READY:
            context.handle(PARCEL_STATE_MATCHING_DPM, parcelInfo);
            break;

        default:
            LOG.info(IndexMaker.indexes(parcelInfo), "The parcel needs no further processing");
            break;
        }
    }

}
