/*
 * Class: AbstractParcelInfoSender
 *
 * Created on Oct 17, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.sender.parcel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import vn.sps.aba.dds.common.ifa.TaskWatcher;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.repository.cache.interfaces.IParcelInfoCacheDao;
import vn.sps.aba.dds.scheduled.sender.AbstractScheduledSender;

/**
 * The Class AbstractParcelInfoSender.
 */
abstract class AbstractParcelInfoSender extends AbstractScheduledSender<ParcelInfo> {

    /** The parcel info dao. */
    @Autowired
    protected IParcelInfoCacheDao parcelInfoDao;

    /** The watcher. */
    @Autowired
    @Qualifier("DmcReceiver")
    protected TaskWatcher watcher;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.AbstractScheduledSender#checkBeforeStore(java.lang.String)
     */
    @Override
    protected boolean checkBeforeStore(final String key) {
        return this.watcher.isDone(key);
    }
}
