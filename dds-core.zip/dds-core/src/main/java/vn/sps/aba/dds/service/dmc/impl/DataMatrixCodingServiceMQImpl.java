/*
 * Class: DataMatrixCodingService
 *
 * Created on Aug 29, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.dmc.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import vn.sps.aba.dds.common.constant.Enumeration.DmcState;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.dmc.DMCRequest;
import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.config.service.AbstractRestWsConfiguration;
import vn.sps.aba.dds.config.service.DmcServiceConfiguration;
import vn.sps.aba.dds.jms.IDmcMQConnector;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate;
import vn.sps.aba.dds.service.dmc.IDataMatrixCodingService;

/**
 * The Class DataMatrixCodingServiceMQImpl.
 */
@Service(value = "DataMatrixCodingService")
@ConditionalOnProperty(name = "dmc.activemq", havingValue = "true")
public class DataMatrixCodingServiceMQImpl extends AbstractRestWsTemplate<DMCResponse> implements IDataMatrixCodingService {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DataMatrixCodingServiceMQImpl.class);

    /** The dmc MQ connector. */
    @Autowired
    private IDmcMQConnector dmcMQConnector;

    /** The service configuration. */
    @Autowired
    private DmcServiceConfiguration serviceConfiguration;

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.service.dmc.IDataMatrixCodingService#forwardToDmc(vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public DMCResponse forwardToDmc(final ParcelInfo parcelInfo) {

        DMCResponse ret = null;

        try {
            final String key = parcelInfo.getKey();

            final DMCRequest request = new DMCRequest();
            {
                request.setKey(key);
                request.setIdentCode(parcelInfo.getIdentCode());
                request.setDirectory(parcelInfo.getFilePath());
                request.setFileName(parcelInfo.getFileName());
                request.setResponseQueueName(this.serviceConfiguration.getResponseQueueName());
            }

            parcelInfo.setDmcBegin(DiscoWallClock.milli());
            this.dmcMQConnector.send(request, this.serviceConfiguration.getRequestQueueName());
            parcelInfo.setDmcSent(DiscoWallClock.milli());
            parcelInfo.countDmcUp();
            ret = new DMCResponse();
            ret.setState(DmcState.DMC_SENT.name());
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.indexes(parcelInfo), "There is error when request for DMC processing for parcel.", e);
        }

        return ret;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate#getConfiguration()
     */
    @Override
    protected AbstractRestWsConfiguration getConfiguration() {
        return this.serviceConfiguration;
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate#isResponseOk(java.lang.Object)
     */
    @Override
    protected boolean isResponseOk(final IdentifiedEntry entry, final DMCResponse ret) {
        return ret != null;
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate#send(java.lang.String,
     * java.lang.Object, int, java.lang.Class)
     */
    @Override
    protected DMCResponse send(final IdentifiedEntry entry, final String url, final Object message, final int readTimeOut, final Class<DMCResponse> clazz) {
        DMCResponse response = null;

        try {
            this.restTemplate.postForObject(url, message, clazz);
            response = new DMCResponse();
            response.setState(DmcState.DMC_SENT.name());
        }
        catch (final Exception e) {
            LOG.warn(IndexMaker.indexes(entry), "Error when request for DMC processing to url {}", url, e);
        }

        return response;
    }
}
