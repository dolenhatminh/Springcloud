package vn.sps.aba.dds.common.model;

/**
 * The Enum EProxyStatus.
 */
public enum EProxyStatus {

    /** The available. */
    AVAILABLE(1, 1),
    /** The captured. */
    CAPTURED(4, 1),
    /** The capturing. */
    CAPTURING(3, 1),
    /** The delivered. */
    DELIVERED(2, 1),
    /** The image error. */
    IMAGE_ERROR(2, -1),
    /** The qc completed. */
    QC_COMPLETED(12, 1),
    /** The qc processing. */
    QC_PROCESSING(11, 1),
    /** The qc ready. */
    QC_READY(10, 1),
    /** The reassign. */
    REASSIGN(6, 1),
    /** The returned. */
    RETURNED(5, 1),
    /** The returned fail. */
    RETURNED_FAIL(5, -1);

    /** The status. */
    private final int status;

    /** The sub status. */
    private final int subStatus;

    /**
     * Instantiates a new e proxy status.
     *
     * @param status the status
     * @param subStatus the sub status
     */
    EProxyStatus(final int status, final int subStatus) {
        this.status = status;
        this.subStatus = subStatus;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public int getStatus() {
        return this.status;
    }

    /**
     * Gets the sub status.
     *
     * @return the sub status
     */
    public int getSubStatus() {
        return this.subStatus;
    }
}
