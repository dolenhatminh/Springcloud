/*
 * Class: IMatchMakerDatenService
 *
 * Created on Jun 30, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.padasa.matchmakerdaten;

import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;

/**
 * The Interface IMatchMakerDatenService.
 */
public interface IMatchMakerDatenService {

    /**
     * Transfer.
     *
     * @param receiverInfo
     *            the receiver info
     * @return true, if successful
     */
    boolean transferToMatchMaker(ReceiverInfo receiverInfo);

}
