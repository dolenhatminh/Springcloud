/*
 * Class: IReceiverInfoRepository
 *
 * Created on Jul 15, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.jpa;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import vn.sps.aba.dds.repository.entity.receiver.ReceiverInfoEntity;

/**
 * The Interface IReceiverInfoRepository.
 */
public interface IReceiverInfoRepository extends CrudRepository<ReceiverInfoEntity, String> {

    /**
     * Count.
     *
     * @param now the now
     * @param fromTime the from time
     * @param toTime the to time
     * @return the int
     */
    @Query(value = "select count(r) from ReceiverInfoEntity r where identCode is not null AND created >= ?2 and created <= ?3 AND (created + lifespan) > ?1")
    int count(long now, long fromTime, long toTime);

    /**
     * List.
     *
     * @param now the now
     * @param fromTime the from time
     * @param toTime the to time
     * @param pageable the pageable
     * @return the page
     */
    @Query(value = "select r from ReceiverInfoEntity r where identCode is not null AND created >= ?2 and created <= ?3 AND (created + lifespan) > ?1")
    Page<ReceiverInfoEntity> list(long now, long fromTime, long toTime, Pageable pageable);

    /**
     * List all.
     *
     * @param pageable the pageable
     * @return the page
     */
    @Query(value = "select r from ReceiverInfoEntity r where identCode is not null")
    Page<ReceiverInfoEntity> listAll(Pageable pageable);

    /**
     * List with received time.
     *
     * @param now the now
     * @param fromTime the from time
     * @param toTime the to time
     * @return the list
     */
    @Query(nativeQuery = true, value = "select * from (select *, row_number() over (partition by ident_code order by created desc) as row_number  FROM dds.rec_receiver_info where ident_code <> '' AND ident_code is not null AND created >= ?2 and created <= ?3 AND (created+lifespan)>?1 )t where row_number=1")
    List<ReceiverInfoEntity> listWithReceivedTime(long now, long fromTime, long toTime);

    /**
     * List with received time.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @return the list
     */
    @Query(nativeQuery = true, value = "select * from (select *, row_number() over (partition by ident_code order by received_time desc) as row_number  FROM dds.rec_receiver_info where ident_code <> '' AND ident_code is not null AND received_time between ?1 and ?2)t where row_number=1")
    List<ReceiverInfoEntity> listWithReceivedTime(Timestamp fromTime, Timestamp toTime);
}
