/*
 * Class: FilterRule
 *
 * Created on Jun 21, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.filterrule;

import java.util.ArrayList;
import java.util.List;

import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;

/**
 * The Class FilterRule.
 */
public class FilterRule {

    /** The active. */
    private boolean active;

    /** The constraints. */
    private final List<Constraint> constraints = new ArrayList<>();

    /** The match any. */
    private boolean matchAny;

    /** The name. */
    private String name;

    /** The destination. */
    private ParcelState updatedState;

    /**
     * Constructs a new <tt>FilterRule</tt>.
     */
    public FilterRule() {
        this.setActive(false);
    }

    /**
     * Gets the constraints.
     *
     * @return Returns the constraints.
     */
    public List<Constraint> getConstraints() {
        return this.constraints;
    }

    /**
     * Gets the name.
     *
     * @return Returns the name.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Gets the updated staus.
     *
     * @return Returns the updatedStaus.
     */
    public ParcelState getUpdatedState() {
        return this.updatedState;
    }

    /**
     * Checks if is active.
     *
     * @return Returns the active.
     */
    public boolean isActive() {
        return this.active;
    }

    /**
     * Checks if is match any.
     *
     * @return Returns the matchAny.
     */
    public boolean isMatchAny() {
        return this.matchAny;
    }

    /**
     * Sets the active.
     *
     * @param active The active to set.
     */
    public void setActive(final boolean active) {
        this.active = active;
    }

    /**
     * Sets the match any.
     *
     * @param matchAny The matchAny to set.
     */
    public void setMatchAny(final boolean matchAny) {
        this.matchAny = matchAny;
    }

    /**
     * Sets the name.
     *
     * @param name The name to set.
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * Sets the updated state.
     *
     * @param updatedState the new updated state
     */
    public void setUpdatedState(ParcelState updatedState) {
        this.updatedState = updatedState;
    }

    /**
     * Sets the updated staus.
     *
     * @param updatedState the new updated state
     */
    public void setUpdatedState(final String updatedState) {
        this.updatedState = ParcelState.valueOf(updatedState);
    }

    /**
     * {@inheritDoc}
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();

        sb.append("Name:").append(this.getName()).append(";Active:").append(this.isActive()).append(";UpdatedStatus:").append(this.getUpdatedState())
            .append(";Constraint:").append("[");
        for (final Constraint constraint : this.constraints) {
            sb.append("[").append(constraint.toString()).append("]");
        }
        sb.append("]");

        return sb.toString();
    }
}
