package vn.sps.aba.dds.service.lookup.zubofi.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import vn.sps.aba.dds.common.model.lookup.AsdpPlz;
import vn.sps.aba.dds.config.service.AbstractRestWsConfiguration;
import vn.sps.aba.dds.config.service.AsdpServiceConfiguration;
import vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate;
import vn.sps.aba.dds.service.lookup.asdp.impl.AsdpLookupService;
import vn.sps.aba.dds.service.lookup.zubofi.IZubofiLookupService;

/**
 * The Class ZubofiLookupService.
 */
public class ZubofiLookupService extends AbstractRestWsTemplate<AsdpPlz> implements IZubofiLookupService {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(AsdpLookupService.class);

    /** The service configuration. */
    @Autowired
    private AsdpServiceConfiguration serviceConfiguration;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate#getConfiguration()
     */
    @Override
    protected AbstractRestWsConfiguration getConfiguration() {
        return this.serviceConfiguration;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.lookup.zubofi.IZubofiLookupService#getZubofi(java.lang.String)
     */
    @Override
    public AsdpPlz getZubofi(final String plz) {
        AsdpPlz response = null;

        try {
            final ResponseEntity<AsdpPlz> entity = this.restTemplate.getForEntity(this.getConfiguration().getServiceUrl() + "/" + plz, AsdpPlz.class);

            response = entity.getBody();

        }
        catch (final Exception e) {
            LOG.error("There is error while lookup Zobofi data", e);
        }

        return response;
    }
}
