
package vn.sps.aba.dds.common.types.ws.pds.parcel.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ParcelInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ParcelInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Barcodes" type="{Ch.Post.PL.Vae.VG.ParcelInfoService}ArrayOfBarcode" minOccurs="0"/>
 *         &lt;element name="DestinationStation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FullAddress" type="{Ch.Post.PL.Vae.VG.ParcelInfoService}FullAddress" minOccurs="0"/>
 *         &lt;element name="Identcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Image" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/>
 *         &lt;element name="ParPicId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ParcelAddress" type="{Ch.Post.PL.Vae.VG.ParcelInfoService}ParcelAddress" minOccurs="0"/>
 *         &lt;element name="ParcelCodingInfo" type="{Ch.Post.PL.Vae.VG.ParcelInfoService}ParcelCodingInfo" minOccurs="0"/>
 *         &lt;element name="ProduktZusatzleistungen" type="{Ch.Post.PL.Vae.VG.ParcelInfoService}ArrayOfProduktZusatzleistung" minOccurs="0"/>
 *         &lt;element name="SourceStation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Timestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="VcsCase" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ParcelInfo", propOrder = {
    "barcodes",
    "destinationStation",
    "fullAddress",
    "identcode",
    "image",
    "parPicId",
    "parcelAddress",
    "parcelCodingInfo",
    "produktZusatzleistungen",
    "sourceStation",
    "timestamp",
    "vcsCase"
})
public class ParcelInfo {

    @XmlElementRef(name = "Barcodes", namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfBarcode> barcodes;
    @XmlElement(name = "DestinationStation", required = true, nillable = true)
    protected String destinationStation;
    @XmlElementRef(name = "FullAddress", namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<FullAddress> fullAddress;
    @XmlElement(name = "Identcode", required = true, nillable = true)
    protected String identcode;
    @XmlElement(name = "Image", required = true, nillable = true)
    protected byte[] image;
    @XmlElement(name = "ParPicId", required = true, nillable = true)
    protected String parPicId;
    @XmlElementRef(name = "ParcelAddress", namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<ParcelAddress> parcelAddress;
    @XmlElementRef(name = "ParcelCodingInfo", namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<ParcelCodingInfo> parcelCodingInfo;
    @XmlElementRef(name = "ProduktZusatzleistungen", namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfProduktZusatzleistung> produktZusatzleistungen;
    @XmlElement(name = "SourceStation", required = true, nillable = true)
    protected String sourceStation;
    @XmlElement(name = "Timestamp", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar timestamp;
    @XmlElement(name = "VcsCase")
    protected int vcsCase;

    /**
     * Gets the value of the barcodes property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBarcode }{@code >}
     *     
     */
    public JAXBElement<ArrayOfBarcode> getBarcodes() {
        return barcodes;
    }

    /**
     * Sets the value of the barcodes property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBarcode }{@code >}
     *     
     */
    public void setBarcodes(JAXBElement<ArrayOfBarcode> value) {
        this.barcodes = value;
    }

    /**
     * Gets the value of the destinationStation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationStation() {
        return destinationStation;
    }

    /**
     * Sets the value of the destinationStation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationStation(String value) {
        this.destinationStation = value;
    }

    /**
     * Gets the value of the fullAddress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link FullAddress }{@code >}
     *     
     */
    public JAXBElement<FullAddress> getFullAddress() {
        return fullAddress;
    }

    /**
     * Sets the value of the fullAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link FullAddress }{@code >}
     *     
     */
    public void setFullAddress(JAXBElement<FullAddress> value) {
        this.fullAddress = value;
    }

    /**
     * Gets the value of the identcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentcode() {
        return identcode;
    }

    /**
     * Sets the value of the identcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentcode(String value) {
        this.identcode = value;
    }

    /**
     * Gets the value of the image property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getImage() {
        return image;
    }

    /**
     * Sets the value of the image property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setImage(byte[] value) {
        this.image = value;
    }

    /**
     * Gets the value of the parPicId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParPicId() {
        return parPicId;
    }

    /**
     * Sets the value of the parPicId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParPicId(String value) {
        this.parPicId = value;
    }

    /**
     * Gets the value of the parcelAddress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ParcelAddress }{@code >}
     *     
     */
    public JAXBElement<ParcelAddress> getParcelAddress() {
        return parcelAddress;
    }

    /**
     * Sets the value of the parcelAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ParcelAddress }{@code >}
     *     
     */
    public void setParcelAddress(JAXBElement<ParcelAddress> value) {
        this.parcelAddress = value;
    }

    /**
     * Gets the value of the parcelCodingInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ParcelCodingInfo }{@code >}
     *     
     */
    public JAXBElement<ParcelCodingInfo> getParcelCodingInfo() {
        return parcelCodingInfo;
    }

    /**
     * Sets the value of the parcelCodingInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ParcelCodingInfo }{@code >}
     *     
     */
    public void setParcelCodingInfo(JAXBElement<ParcelCodingInfo> value) {
        this.parcelCodingInfo = value;
    }

    /**
     * Gets the value of the produktZusatzleistungen property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfProduktZusatzleistung }{@code >}
     *     
     */
    public JAXBElement<ArrayOfProduktZusatzleistung> getProduktZusatzleistungen() {
        return produktZusatzleistungen;
    }

    /**
     * Sets the value of the produktZusatzleistungen property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfProduktZusatzleistung }{@code >}
     *     
     */
    public void setProduktZusatzleistungen(JAXBElement<ArrayOfProduktZusatzleistung> value) {
        this.produktZusatzleistungen = value;
    }

    /**
     * Gets the value of the sourceStation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceStation() {
        return sourceStation;
    }

    /**
     * Sets the value of the sourceStation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceStation(String value) {
        this.sourceStation = value;
    }

    /**
     * Gets the value of the timestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTimestamp() {
        return timestamp;
    }

    /**
     * Sets the value of the timestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTimestamp(XMLGregorianCalendar value) {
        this.timestamp = value;
    }

    /**
     * Gets the value of the vcsCase property.
     * 
     */
    public int getVcsCase() {
        return vcsCase;
    }

    /**
     * Sets the value of the vcsCase property.
     * 
     */
    public void setVcsCase(int value) {
        this.vcsCase = value;
    }

}
