/*
 * Class: IReceiverInfoValidator
 *
 * Created on Jun 13, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.dts;

import vn.sps.aba.dds.common.types.ws.dts.model.ReceiverInfoRecord;
import vn.sps.aba.dds.service.validation.IGenericValidator;
import vn.sps.aba.dds.service.validation.model.ReceiverInfoValidationResult;

/**
 * The Interface IReceiverInfoValidator.
 */
public interface IDataTransferValidator extends IGenericValidator<ReceiverInfoRecord, ReceiverInfoValidationResult> {
}
