/*
 * Class: IImageInfo
 * 
 * Created on Oct 6, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.pds.parcel;

/**
 * The Interface IImageInfo.
 */
public interface IImageInfo {

    /**
     * Sets the order.
     *
     * @param order the new order
     */
    void setOrder(int order);

    /**
     * Sets the file name.
     *
     * @param fileName the new file name
     */
    void setFileName(String fileName);

    /**
     * Sets the directory.
     *
     * @param directory the new directory
     */
    void setDirectory(String directory);
}
