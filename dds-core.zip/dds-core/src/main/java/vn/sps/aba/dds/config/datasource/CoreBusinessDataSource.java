package vn.sps.aba.dds.config.datasource;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import vn.sps.aba.dds.repository.jpa.IParcelInfoRepository;

/**
 * The Class CoreBusinessDataSource.
 */
@Configuration
@EnableAutoConfiguration
@EnableTransactionManagement
@EnableJpaRepositories(basePackageClasses = { IParcelInfoRepository.class })
public class CoreBusinessDataSource {

}