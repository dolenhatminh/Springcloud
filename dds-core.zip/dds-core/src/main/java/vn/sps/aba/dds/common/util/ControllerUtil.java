/*
 * Class: DateUtil
 *
 * Created on Jun 23, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.model.cache.IDDSCacheEntry;
import vn.sps.aba.dds.common.time.DiscoWallClock;

/**
 * The Class DateUtil.
 */
public final class ControllerUtil {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ControllerUtil.class);

    /**
     * Local date time 2 instant.
     *
     * @param time the time
     * @return the long
     */
    public static long localDateTime2Instant(final LocalDateTime time) {
        return time == null ? -1 : DateUtil.localDateTime2EpochMillis(time, DiscoWallClock.zone());
    }

    /**
     * Sort managed info.
     *
     * @param entries the entries
     */
    public static void sortManagedInfo(final List<IDDSCacheEntry> entries) {
        if ((entries != null) && (entries.size() > 1)) {
            entries.sort((e1, e2) -> Long.valueOf(e2.getReceived()).compareTo(Long.valueOf(e1.getReceived())));
        }
    }

    /**
     * From string.
     *
     * @param value the value
     * @return the local date time
     */
    public static LocalDateTime string2LocalDateTime(final String value) {
        LocalDateTime ret = null;

        try {
            if (StringUtil.notNullOrEmpty(value)) {
                ret = DateUtil.localDateTimeFrom(value, DDSConstant.FORMAT_DEFAULT_DATE_TIME);
            }
        }
        catch (final DateTimeParseException e) {
            LOG.warn("Incorrect date time format {} ({})", value, DDSConstant.FORMAT_DEFAULT_DATE_TIME);
            LOG.error("Error when parse date time format", e);
        }

        return ret;
    }

    /**
     * Constructs a new <tt>DateUtil</tt>.
     */
    private ControllerUtil() {
    }
}
