/*
 * Class: StepVerifyingHandler
 *
 * Created on Jul 11, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.receiver.handers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.constant.Enumeration.VerifiedField;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.types.verifying.VerifiedRule;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext;

/**
 * The Class StepVerifyingHandler.
 */
public class RuleVerifyingHandler extends AbstractReceiverStepHandler implements IReceiverStepHandler {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(RuleVerifyingHandler.class);

    /**
     * Instantiates a new step verifying handler.
     */
    public RuleVerifyingHandler() {
        super(STEP_VERIFYING_HANDLER);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.receiver.handers.IReceiverStepHandler#handle(vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext, vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    public void handle(final IReceiverProcessingContext context, final ReceiverInfo receiverInfo) {

        LOG.info(IndexMaker.index(receiverInfo), "Verify receiver info");

        final boolean isVerified = this.isVerifiedReceiverInfo(receiverInfo, context.getRules());

        if (isVerified) {

            context.transmitStateTo(receiverInfo, ReceiverState.VERIFIED);
            context.handle(STEP_FORWARDING_HANDLER, receiverInfo);
        }
        else {
            context.transmitStateTo(receiverInfo, ReceiverState.REJECTED);
            LOG.info(IndexMaker.index(receiverInfo), "No verified rule match with this receiver info");
        }
    }

    /**
     * Checks if is verified receiver info.
     *
     * @param receiverInfo            the receiver info
     * @param verifiedRules the verified rules
     * @return true, if is verified receiver info
     */
    private boolean isVerifiedReceiverInfo(final ReceiverInfo receiverInfo, final List<VerifiedRule> verifiedRules) {

        for (final VerifiedRule verifiedRule : verifiedRules) {

            boolean isMatch = true;
            final VerifiedField[] rules = verifiedRule.getRules();

            for (final VerifiedField rule : rules) {

                isMatch = this.match(receiverInfo, rule);

                if (!isMatch) {
                    break;
                }
            }

            if (isMatch) {
                LOG.info(IndexMaker.index(receiverInfo), "Receiver info is verified with rule {}", verifiedRule.getName());
                receiverInfo.setVerifiedByRule(verifiedRule.getName());
                return isMatch;
            }
        }

        return false;
    }

    /**
     * Match.
     *
     * @param receiverInfo
     *            the receiver info
     * @param rule
     *            the rule
     * @return true, if successful
     */
    private boolean match(final ReceiverInfo receiverInfo, final VerifiedField rule) {
        boolean ret = false;

        switch (rule) {
        case AmpKey:

            ret = (receiverInfo.getKdpId() != null) && !receiverInfo.getKdpId().isEmpty();
            break;
        case DomizilHausKey:

            ret = (receiverInfo.getHausKey() != null) && !receiverInfo.getHausKey().isEmpty();
            break;
        case ParcelHausKey:

            ret = (receiverInfo.getParcelHausKey() != null) && !receiverInfo.getParcelHausKey().isEmpty();
            break;
        case PersKey:
        default:
            ret = false;
            break;
        }

        return ret;
    }
}
