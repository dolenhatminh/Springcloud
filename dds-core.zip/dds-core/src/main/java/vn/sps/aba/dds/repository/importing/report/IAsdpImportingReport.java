/*
 * Class: IAsdpImportingReport
 * 
 * Created on Oct 13, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.importing.report;

/**
 * The Interface IAsdpImportingReport.
 */
public interface IAsdpImportingReport {
    
    /**
     * Gets the number of item.
     *
     * @return the number of item
     */
    int getNumberOfItem();
}
