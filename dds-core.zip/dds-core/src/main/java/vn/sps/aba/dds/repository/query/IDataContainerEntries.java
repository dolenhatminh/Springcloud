/*
 * Class: IContainerQuery
 *
 * Created on Dec 1, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.query;

import java.util.List;

import vn.sps.aba.dds.common.model.cache.IDDSCacheEntry;

/**
 * The Interface IDataContainerEntries.
 */
public interface IDataContainerEntries {

    /**
     * Gets the managed info.
     *
     * @param managedInfos the managed infos
     * @param fromTime the from time
     * @param toTime the to time
     * @param size the size
     * @return the managed info
     */
    void getManagedInfo(final List<IDDSCacheEntry> managedInfos, long fromTime, long toTime, int size);

    /**
     * Gets the managed info.
     *
     * @param managedInfos the managed infos
     * @param fromTime the from time
     * @param toTime the to time
     * @param state the state
     * @param minorState the minor state
     * @param size the size
     * @return the managed info
     */
    void getManagedInfo(final List<IDDSCacheEntry> managedInfos, long fromTime, long toTime, String state, String minorState, int size);

    /**
     * Gets the managed info.
     *
     * @param managedInfos the managed infos
     * @param key the key
     * @param identCode the ident code
     * @param size the size
     * @return the managed info
     */
    void getManagedInfo(final List<IDDSCacheEntry> managedInfos, String key, String identCode, int size);
}
