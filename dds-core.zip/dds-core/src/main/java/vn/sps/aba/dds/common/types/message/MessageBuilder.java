/*
 * Class: ResponseBuilder
 *
 * Created on Jun 25, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.message;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigInteger;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.enums.EnvelopVersion;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.dmc.DMCCode;
import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.parcel.Barcode;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.model.parcel.ProduktZusatzleistung;
import vn.sps.aba.dds.common.model.receiver.AdressErfassung;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.types.ws.dpm.model.ReceiverInfoResponseType;
import vn.sps.aba.dds.common.types.ws.dpm.model.StatusCodeType;
import vn.sps.aba.dds.common.types.ws.dpm.model.TransferReceiverInfoResponse;
import vn.sps.aba.dds.common.types.ws.dts.model.PutDeliveryInfoResponse;
import vn.sps.aba.dds.common.types.ws.padasa.matchmakerdaten.model.MatchMakerRequest;
import vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.AcsKeyInfo;
import vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.BarCodeData;
import vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.CodingKey;
import vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.MsgHeader;
import vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.MsgParcelBCData;
import vn.sps.aba.dds.common.types.ws.pds.parcel.model.ObjectFactory;
import vn.sps.aba.dds.common.types.ws.pds.parcel.model.TransferParcelInfoOut;
import vn.sps.aba.dds.common.types.ws.pds.parcel.model.TransferParcelInfoResponse;
import vn.sps.aba.dds.common.types.ws.vae.blackbox.CaptureRequestRecord;
import vn.sps.aba.dds.common.types.ws.vae.blackbox.IdentCodeOrientation;
import vn.sps.aba.dds.common.types.ws.vae.blackbox.ParcelAddress;
import vn.sps.aba.dds.common.types.ws.vam.capturing.EnumResolver;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.AddressFields;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.AdresseErfassung;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.ArrayOfProduktZusatzLeistung;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureInfo;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultIn;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultOut;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultRecord;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultResponse;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.ParcelData;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.Timestamps;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.VolleAdresse;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.common.util.FileUtil;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.service.BarcodeDataServiceConfiguration;
import vn.sps.aba.dds.config.service.CaptureResultServiceConfiguration;
import vn.sps.aba.dds.config.service.DpmsServiceConfiguration;
import vn.sps.aba.dds.config.service.MatchMakerServiceConfiguration;
import vn.sps.aba.dds.config.service.ParcelInfoServiceConfiguration;
import vn.sps.aba.dds.config.service.VaeBlackboxServiceConfiguration;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.service.validation.dpms.PackageValidatingInfo;
import vn.sps.aba.dds.service.validation.parcel.ParcelValidatingInfo;

/**
 * The Class ResponseBuilder.
 */
public final class MessageBuilder {

    /**
     * The LOG.
     */
    private static final Logger LOG = LoggerFactory.getLogger(MessageBuilder.class);

    /**
     * Builds the barcode data service.
     *
     * @param configuration the configuration
     * @param parcelInfo the parcel info
     * @param dmcData the dmc data
     * @return the msg parcel bc data
     */
    public static MsgParcelBCData buildBarcodeDataService(
        final BarcodeDataServiceConfiguration configuration,
        final ParcelInfo parcelInfo,
        final DMCResponse dmcData) {

        final vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.ObjectFactory factory = configuration.getObjectFactory();
        final MsgParcelBCData msgParcelBCData = factory.createMsgParcelBCData();

        final MsgHeader msgHeader = factory.createMsgHeader();
        {
            msgHeader.setMessageID(MessageBuilder.newBarcodeDataMessageId(configuration.getMessageIdFormat()));
            msgHeader.setVersion(configuration.getHeaderVersion());
        }
        msgParcelBCData.getMsgHeaderAndParcelData().add(msgHeader);

        final vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.ParcelData parcelData = factory.createParcelData();
        {
            final AcsKeyInfo acsKeyInfo = factory.createAcsKeyInfo();
            {
                acsKeyInfo.setSite(parcelInfo.getDestinationId());
                acsKeyInfo.setStation(parcelInfo.getSourceId());
                acsKeyInfo.setTimeStamp(DateUtil.gregorian2String(parcelInfo.getTimeStamp(), configuration.getAcsTimeStampFormat()));
            }
            parcelData.setACSKeyInfo(acsKeyInfo);

            if (dmcData != null) {
                final List<DMCCode> dmcCodes = dmcData.getDmcCodes();
                for (final DMCCode dmcCode : dmcCodes) {

                    if (dmcCode.getFormat() != null) {
                        final BarCodeData barCodeData = factory.createBarCodeData();
                        {
                            barCodeData.setBarcodeArt(BigInteger.valueOf(dmcCode.getFormat().getNo()));
                            barCodeData.setBarcodeInhalt(dmcCode.getContent());
                            barCodeData.setBarcodeTyp(dmcCode.getFormat().getType());
                        }
                        parcelData.getBarCodeData().add(barCodeData);
                    }
                }
            }

            final CodingKey codingKey = factory.createCodingKey();
            {
                codingKey.setCodingDate(DateUtil.currentTimeStampAsString(configuration.getCodingDateFormat()));
                codingKey.setCodingSiteID(resolveCodingSite(configuration, parcelInfo));
            }
            parcelData.setCodingKey(codingKey);

            parcelData.setIdentCode(parcelInfo.getIdentCode());
            parcelData.setPICID(parcelInfo.getParPicId());
        }
        msgParcelBCData.getMsgHeaderAndParcelData().add(parcelData);

        return msgParcelBCData;
    }

    /**
     * Builds the capture request1.
     *
     * @param parcelInfo the parcel info
     * @param configuration the configuration
     * @return the capture request record
     * @throws DatatypeConfigurationException the datatype configuration
     * exception
     * @throws FileNotFoundException the file not found exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static CaptureRequestRecord buildCaptureRequest(final ParcelInfo parcelInfo, final VaeBlackboxServiceConfiguration configuration)
            throws DatatypeConfigurationException, FileNotFoundException, IOException {

        final vn.sps.aba.dds.common.types.ws.vae.blackbox.ObjectFactory factory = configuration.getObjectFactory();
        final ReceiverInfo receiverInfo = parcelInfo.getReceiverInfo();

        final CaptureRequestRecord requestRecord = factory.createCaptureRequestRecord();
        {
            final vn.sps.aba.dds.common.types.ws.vae.blackbox.AddressFields addressFields = factory.createAddressFields();
            {
                if (receiverInfo != null) {

                    final AdressErfassung adressErfassung = receiverInfo.getAdressErfassung();
                    if ((adressErfassung != null) && (adressErfassung.getVolleAdresse() != null)) {
                        final vn.sps.aba.dds.common.model.receiver.AddressFields valueFields = adressErfassung.getVolleAdresse().getAddressFields();
                        {
                            if (valueFields != null) {
                                addressFields.setAnrede(factory.createAddressFieldsAnrede(valueFields.getAnrede()));
                                addressFields.setCoAdresse(factory.createAddressFieldsCoAdresse(valueFields.getCoAdress()));
                                addressFields.setFirmenname(factory.createAddressFieldsFirmenname(valueFields.getFirmeName()));
                                addressFields.setHausnummer(MessageBuilder.string2Integer(valueFields.getHausNummer(), parcelInfo, "Hausnummer"));
                                addressFields.setHausnummerZusatz(factory.createAddressFieldsHausnummerZusatz(valueFields.getHausNummerZusatz()));
                                addressFields.setLand(factory.createAddressFieldsLand(valueFields.getLand()));
                                addressFields.setName(factory.createAddressFieldsName(valueFields.getName()));
                                addressFields.setNameZusatz(factory.createAddressFieldsNameZusatz(valueFields.getNameZusatz()));
                                addressFields.setOrt(factory.createAddressFieldsOrt(valueFields.getOrt()));
                                addressFields.setPostfach(MessageBuilder.string2Integer(valueFields.getPostfach(), parcelInfo, "Postfach"));
                                addressFields.setPostleitzahl(factory.createAddressFieldsPostleitzahl(valueFields.getPostleizahl()));
                                addressFields.setStockwerk(factory.createAddressFieldsStockwerk(valueFields.getStockwerk()));
                                addressFields.setStrasse(factory.createAddressFieldsStrasse(valueFields.getStrasse()));
                                addressFields.setVorname(factory.createAddressFieldsVorname(valueFields.getVorname()));
                                requestRecord.setKundennummer(factory.createCaptureRequestRecordKundennummer(valueFields.getKundenNummer()));
                                requestRecord.setDienstleistung(
                                    factory.createCaptureRequestRecordDienstleistung(configuration.resolveDiensleistung(valueFields.getDienstleistung())));
                            }
                        }
                    }
                    final vn.sps.aba.dds.common.types.ws.vae.blackbox.AdresseErfassung adresseErfassung = factory.createAdresseErfassung();
                    {
                        adresseErfassung.setHAUSKEY(
                            factory.createAdresseErfassungHAUSKEY(
                                MessageBuilder.string2Integer(receiverInfo.getHausKey(), parcelInfo, "AdresseErfassungHAUSKEY")));
                    }
                    requestRecord.setAdresseErfassung(adresseErfassung);
                }
                else if (parcelInfo.getFullAddress() != null) {
                    addressFields.setOrt(factory.createAddressFieldsOrt(parcelInfo.getFullAddress().getOrt()));
                    addressFields.setPostleitzahl(factory.createAddressFieldsPostleitzahl(parcelInfo.getFullAddress().getPostleitzahl()));
                    addressFields.setStrasse(factory.createAddressFieldsStrasse(parcelInfo.getFullAddress().getStrasse()));
                }
            }
            requestRecord.setAddressFields(addressFields);

            requestRecord.setIdentCode(factory.createCaptureRequestRecordIdentCode(parcelInfo.getIdentCode()));
            requestRecord.setImage(FileUtil.readFileToByteArray(parcelInfo.getImageAbsolutePath()));

            final vn.sps.aba.dds.common.types.ws.vae.blackbox.ParcelData parcelData = factory.createParcelData();
            {
                parcelData.setDestinationStation(parcelInfo.getDestinationStation());
                parcelData.setParPicId(parcelInfo.getParPicId());
                parcelData.setSourceStation(parcelInfo.getSourceStation());
                parcelData.setProduktZusatzleistungen(factory.createArrayOfProduktZusatzleistung());

                final List<ProduktZusatzleistung> produktZusatzleistungens = parcelInfo.getProduktZusatzleistungens();
                for (final ProduktZusatzleistung produktZusatzleistung : produktZusatzleistungens) {

                    final vn.sps.aba.dds.common.types.ws.vae.blackbox.ProduktZusatzleistung e = new vn.sps.aba.dds.common.types.ws.vae.blackbox.ProduktZusatzleistung();
                    final Integer serviceCode = MessageBuilder.string2Integer(produktZusatzleistung.getCode(), parcelInfo, "serviceCode");
                    if (serviceCode != null) {
                        e.setCode(serviceCode);
                        parcelData.getProduktZusatzleistungen().getProduktZusatzleistung().add(e);
                    }
                }

                parcelData.setTimeStamp(parcelInfo.getTimeStamp());
                parcelData.setVcsCase(parcelInfo.getVcsCase());
            }
            requestRecord.setParcelData(parcelData);

            final ParcelAddress parcelAddress = factory.createParcelAddress();
            {
                final vn.sps.aba.dds.common.model.parcel.ParcelAddress parcelAddr = parcelInfo.getParcelAddress();
                if (parcelAddr != null) {
                    parcelAddress.setAddressType(parcelAddr.getAddressType());
                    parcelAddress.setStreetNumber(MessageBuilder.string2Integer(parcelAddr.getStreetNumber(), parcelInfo, "StreetNumber"));
                }
            }
            requestRecord.setParcelAddress(parcelAddress);

            requestRecord.setPDSTimestamp(parcelInfo.getParcelInfoSentTimestamp());
            requestRecord.setDiscoTimestamp(DateUtil.milli2GregorianCalendar(parcelInfo.getBlackboxBegin()));
            requestRecord.setPriority(null);

            final IdentCodeOrientation orientation = factory.createIdentCodeOrientation();
            {
                final List<Barcode> barcodes = parcelInfo.getBarcodes();
                boolean hasBarcode = false;
                if ((barcodes != null) && !barcodes.isEmpty()) {
                    for (final Barcode barcode : barcodes) {
                        if (checkVaeCondition(parcelInfo.getKey(), barcode, configuration)) {
                            orientation.setUpperLeftX(MessageBuilder.string2Double(barcode.getBoundary().getX1()));
                            orientation.setUpperLeftY(MessageBuilder.string2Double(barcode.getBoundary().getY1()));
                            orientation.setLowerLeftX(MessageBuilder.string2Double(barcode.getBoundary().getX2()));
                            orientation.setLowerLeftY(MessageBuilder.string2Double(barcode.getBoundary().getY2()));
                            orientation.setLowerRightX(MessageBuilder.string2Double(barcode.getBoundary().getX3()));
                            orientation.setLowerRightY(MessageBuilder.string2Double(barcode.getBoundary().getY3()));
                            orientation.setUpperRightX(MessageBuilder.string2Double(barcode.getBoundary().getX4()));
                            orientation.setUpperRightY(MessageBuilder.string2Double(barcode.getBoundary().getY4()));
                            hasBarcode = true;
                            break;
                        }
                    }
                }
                if (!hasBarcode) {
                    orientation.setUpperLeftX(0.0);
                    orientation.setUpperLeftY(0.0);
                    orientation.setLowerLeftX(0.0);
                    orientation.setLowerLeftY(0.0);
                    orientation.setLowerRightX(0.0);
                    orientation.setLowerRightY(0.0);
                    orientation.setUpperRightX(0.0);
                    orientation.setUpperRightY(0.0);
                }
            }
            requestRecord.setIdentCodeOrientation(orientation);

        }
        return requestRecord;
    }

    /**
     * Builds the capture result rpc.
     *
     * @param configuration the configuration
     * @param parcelInfo the parcel info
     * @return the capture result in
     * @throws DatatypeConfigurationException the datatype configuration
     * exception
     */
    public static CaptureResultIn buildCaptureResult(final CaptureResultServiceConfiguration configuration, final ParcelInfo parcelInfo)
            throws DatatypeConfigurationException {

        final vn.sps.aba.dds.common.types.ws.vam.capturing.model.ObjectFactory factory = configuration.getObjectFactory();
        // Make sure this receiver info not null because only when the there is one verified receiver info matching with this parcel info, they are included together to VAM
        final ReceiverInfo receiverInfo = parcelInfo.getReceiverInfo();

        final CaptureResultIn captureResultIn = factory.createCaptureResultIn();
        {
            captureResultIn.setCallerId(configuration.getCallerId());
            captureResultIn.setVersion(parcelInfo.getVersion());

            final CaptureResultRecord captureResultRecord = factory.createCaptureResultRecord();
            {
                final AdresseErfassung adresseErfassung = factory.createAdresseErfassung();
                {
                    adresseErfassung.setHausKey(receiverInfo.getHausKey());

                    final AddressFields typedFields = factory.createAddressFields();
                    {
                        final vn.sps.aba.dds.common.model.receiver.AddressFields addressFields = receiverInfo.getAdressErfassung().getAddressFields();

                        if (addressFields != null) {

                            typedFields.setAdressZusatz(factory.createAddressFieldsAdressZusatz(addressFields.getAdressZusatz()));
                            typedFields.setAnrede(factory.createAddressFieldsAnrede(addressFields.getAnrede()));
                            typedFields.setCoAdresse(factory.createAddressFieldsCoAdresse(addressFields.getCoAdress()));
                            typedFields.setDienstleistung(
                                factory.createAddressFieldsDienstleistung(EnumResolver.resolveDienstleistung(addressFields.getDienstleistung())));
                            typedFields.setFirmenname(factory.createAddressFieldsFirmenname(addressFields.getFirmeName()));
                            typedFields.setHausnummer(MessageBuilder.string2Integer(addressFields.getHausNummer(), parcelInfo, "Hausnummer-Typed"));
                            typedFields.setHausnummerZusatz(factory.createAddressFieldsHausnummerZusatz(addressFields.getHausNummerZusatz()));
                            typedFields.setKundennummer(factory.createAddressFieldsKundennummer(addressFields.getKundenNummer()));
                            typedFields.setLaenderCode(factory.createAddressFieldsLaenderCode(addressFields.getLaenderCode()));
                            typedFields.setLand(factory.createAddressFieldsLand(addressFields.getLand()));
                            typedFields.setName(factory.createAddressFieldsName(addressFields.getName()));
                            typedFields.setNameZusatz(factory.createAddressFieldsNameZusatz(addressFields.getNameZusatz()));
                            typedFields.setOrt(factory.createAddressFieldsOrt(addressFields.getOrt()));
                            typedFields.setPostfach(factory.createAddressFieldsPostfach(addressFields.getPostfach()));
                            typedFields.setPostleitzahl(factory.createAddressFieldsPostleitzahl(addressFields.getPostleizahl()));
                            typedFields.setStockwerk(factory.createAddressFieldsStockwerk(addressFields.getStockwerk()));
                            typedFields.setStrasse(factory.createAddressFieldsStrasse(addressFields.getStrasse()));
                            typedFields.setVorname(factory.createAddressFieldsVorname(addressFields.getVorname()));
                        }
                    }
                    adresseErfassung.setTypedFields(factory.createAdresseErfassungTypedFields(typedFields));

                    final VolleAdresse volleAdresse = factory.createVolleAdresse();
                    {

                        final AddressFields valueFields = factory.createAddressFields();
                        {
                            final vn.sps.aba.dds.common.model.receiver.AddressFields addressFields = receiverInfo.getAdressErfassung().getVolleAdresse()
                                .getAddressFields();
                            {
                                valueFields.setAdressZusatz(factory.createAddressFieldsAdressZusatz(addressFields.getAdressZusatz()));
                                valueFields.setAnrede(factory.createAddressFieldsAnrede(addressFields.getAnrede()));
                                valueFields.setCoAdresse(factory.createAddressFieldsCoAdresse(addressFields.getCoAdress()));
                                valueFields.setDienstleistung(
                                    factory.createAddressFieldsDienstleistung(EnumResolver.resolveDienstleistung(addressFields.getDienstleistung())));
                                valueFields.setFirmenname(factory.createAddressFieldsFirmenname(addressFields.getFirmeName()));
                                valueFields.setHausnummer(MessageBuilder.string2Integer(addressFields.getHausNummer(), parcelInfo, "Hausnummer-Value"));
                                valueFields.setHausnummerZusatz(factory.createAddressFieldsHausnummerZusatz(addressFields.getHausNummerZusatz()));
                                valueFields.setKundennummer(factory.createAddressFieldsKundennummer(addressFields.getKundenNummer()));
                                valueFields.setLaenderCode(factory.createAddressFieldsLaenderCode(addressFields.getLaenderCode()));
                                valueFields.setLand(factory.createAddressFieldsLand(addressFields.getLand()));
                                valueFields.setName(factory.createAddressFieldsName(addressFields.getName()));
                                valueFields.setNameZusatz(factory.createAddressFieldsNameZusatz(addressFields.getNameZusatz()));
                                valueFields.setOrt(factory.createAddressFieldsOrt(addressFields.getOrt()));
                                valueFields.setPostfach(factory.createAddressFieldsPostfach(addressFields.getPostfach()));
                                valueFields.setPostleitzahl(factory.createAddressFieldsPostleitzahl(addressFields.getPostleizahl()));
                                valueFields.setStockwerk(factory.createAddressFieldsStockwerk(addressFields.getStockwerk()));
                                valueFields.setStrasse(factory.createAddressFieldsStrasse(addressFields.getStrasse()));
                                valueFields.setVorname(factory.createAddressFieldsVorname(addressFields.getVorname()));
                            }
                        }
                        volleAdresse.setFields(valueFields);

                        final vn.sps.aba.dds.common.model.receiver.VolleAdresse volleAdr = receiverInfo.getAdressErfassung().getVolleAdresse();

                        volleAdresse.setKdpId(factory.createVolleAdresseKdpId(receiverInfo.getKdpId()));
                        volleAdresse.setParcelAdrAmpStatus(EnumResolver.resolveAmpStatus(volleAdr.getParcelAdrAmpStatus()));

                        volleAdresse.getParcelAdrType().add(volleAdr.getParcelAdrType());

                        final String parcelHausKey = StringUtil.notNullOrEmpty(receiverInfo.getParcelHausKey()) ? receiverInfo.getParcelHausKey()
                                : receiverInfo.getHausKey();
                        volleAdresse.setParcelHausKey(factory.createVolleAdresseParcelHausKey(parcelHausKey));
                        volleAdresse.setParcelStreetNr(string2Integer(volleAdr.getParcelStreetNumber(), parcelInfo, "ParcelStreetNr"));
                        volleAdresse.setPersType(factory.createVolleAdressePersType(EnumResolver.resolvePersType(volleAdr.getPersType())));
                        volleAdresse.setPersStatus(factory.createVolleAdressePersStatus(EnumResolver.resolvePersStatus(volleAdr.getPersStatus())));
                    }
                    adresseErfassung.setVolleAdresse(volleAdresse);

                }
                captureResultRecord.setAdresseErfassung(adresseErfassung);

                final CaptureInfo captureInfo = factory.createCaptureInfo();
                {
                    final vn.sps.aba.dds.common.model.receiver.CaptureInfo capture = receiverInfo.getCaptureInfo();

                    captureInfo.setCaptureResultCode(EnumResolver.resolveCaptureResultCode(capture.getCaptureResultCode()));
                    captureInfo.setCoderId(capture.getCoderId());
                    captureInfo.setCodingStation(capture.getCodingStation());
                    captureInfo.setCodingTimestamp(DateUtil.string2Gregorian(capture.getCodingTimeStamp()));
                }
                captureResultRecord.setCaptureInfo(captureInfo);

                captureResultRecord.setIdentcode(parcelInfo.getIdentCode());

                final ParcelData parcelData = factory.createParcelData();
                {
                    parcelData.setAcsTimestamp(parcelInfo.getTimeStamp());
                    parcelData.setDestinationStation(parcelInfo.getDestinationStation());
                    parcelData.setParPicId(parcelInfo.getParPicId());
                    parcelData.setSourceStation(parcelInfo.getSourceStation());
                    parcelData.setVcsCase(parcelInfo.getVcsCase());
                    {
                        final ArrayOfProduktZusatzLeistung aopzl = factory.createArrayOfProduktZusatzLeistung();

                        for (final vn.sps.aba.dds.common.model.parcel.ProduktZusatzleistung produktZusatzleistungen : parcelInfo
                            .getProduktZusatzleistungens()) {

                            final Integer serviceCode = string2Integer(produktZusatzleistungen.getCode(), parcelInfo, "serviceCode");
                            if (serviceCode != null) {
                                final vn.sps.aba.dds.common.types.ws.vam.capturing.model.ProduktZusatzLeistung produkt = factory.createProduktZusatzLeistung();
                                produkt.setCode(serviceCode);
                                aopzl.getProduktZusatzLeistung().add(produkt);
                            }
                        }
                        parcelData.setZusatzLeistungen(aopzl);
                    }
                }
                captureResultRecord.setParcelData(factory.createCaptureResultRecordParcelData(parcelData));

                final Timestamps timestamps = factory.createTimestamps();
                {
                    timestamps.setDisCoTimestamp(DateUtil.milli2GregorianCalendar(parcelInfo.getBlackboxBegin()));
                    timestamps.setPdsTimestamp(parcelInfo.getParcelInfoSentTimestamp());
                    timestamps.setVGTimestamp(DateUtil.string2Gregorian(receiverInfo.getVgTimestamp()));
                }
                captureResultRecord.setTimestamps(timestamps);
            }
            captureResultIn.setCaptureResultRecord(captureResultRecord);
        }

        return captureResultIn;

    }

    /**
     * Builds the capture result rpc.
     *
     * @param configuration the configuration
     * @param receiverInfo the receiver info
     * @return the capture result in
     * @throws DatatypeConfigurationException the datatype configuration
     * exception
     */
    public static CaptureResultIn buildCaptureResult(final CaptureResultServiceConfiguration configuration, final ReceiverInfo receiverInfo)
            throws DatatypeConfigurationException {

        final vn.sps.aba.dds.common.types.ws.vam.capturing.model.ObjectFactory factory = configuration.getObjectFactory();
        final CaptureResultIn captureResultIn = factory.createCaptureResultIn();
        {
            final Integer versionInt = string2Integer(receiverInfo.getVersion(), receiverInfo, "versionInt");
            captureResultIn.setVersion(versionInt == null ? 0 : versionInt.intValue());
            captureResultIn.setCallerId(configuration.getCallerId());

            final CaptureResultRecord captureResultRecord = factory.createCaptureResultRecord();
            {
                final AdresseErfassung adresseErfassung = factory.createAdresseErfassung();
                {
                    // If the HausKey is less than 1, set the value to null
                    final String hausKey = nullOrGreaterThanZeroString(receiverInfo.getHausKey(), receiverInfo, "HausKey");
                    adresseErfassung.setHausKey(hausKey);

                    // Note: remove by customer's requirement
                    //                    final AddressFields typedFields = factory.createAddressFields();
                    //                    {
                    //                        final vn.sps.aba.dds.common.model.receiver.AddressFields addressFields = receiverInfo.getAdressErfassung().getAddressFields();
                    //
                    //                        if (addressFields != null) {
                    //
                    //                            typedFields.setAdressZusatz(factory.createAddressFieldsAdressZusatz(addressFields.getAdressZusatz()));
                    //                            typedFields.setAnrede(factory.createAddressFieldsAnrede(addressFields.getAnrede()));
                    //                            typedFields.setCoAdresse(factory.createAddressFieldsCoAdresse(addressFields.getCoAdress()));
                    //                            typedFields
                    //                                .setDienstleistung(factory.createAddressFieldsDienstleistung(EDienstleistung.fromValue(addressFields.getDienstleistung())));
                    //                            typedFields.setFirmenname(factory.createAddressFieldsFirmenname(addressFields.getFirmeName()));
                    //                            typedFields.setHausnummer(MessageBuilder.string2Integer(addressFields.getHausNummer(), key));
                    //                            typedFields.setHausnummerZusatz(factory.createAddressFieldsHausnummerZusatz(addressFields.getHausNummerZusatz()));
                    //                            typedFields.setKundennummer(factory.createAddressFieldsKundennummer(addressFields.getKundenNummer()));
                    //                            typedFields.setLaenderCode(factory.createAddressFieldsLaenderCode(addressFields.getLaenderCode()));
                    //                            typedFields.setLand(factory.createAddressFieldsLand(addressFields.getLand()));
                    //                            typedFields.setName(factory.createAddressFieldsName(addressFields.getName()));
                    //                            typedFields.setNameZusatz(factory.createAddressFieldsNameZusatz(addressFields.getNameZusatz()));
                    //                            typedFields.setOrt(factory.createAddressFieldsOrt(addressFields.getOrt()));
                    //                            typedFields.setPostfach(factory.createAddressFieldsPostfach(addressFields.getPostfach()));
                    //                            typedFields.setPostleitzahl(factory.createAddressFieldsPostleitzahl(addressFields.getPostleizahl()));
                    //                            typedFields.setStockwerk(factory.createAddressFieldsStockwerk(addressFields.getStockwerk()));
                    //                            typedFields.setStrasse(factory.createAddressFieldsStrasse(addressFields.getStrasse()));
                    //                            typedFields.setVorname(factory.createAddressFieldsVorname(addressFields.getVorname()));
                    //                        }
                    //                    }
                    //                    adresseErfassung.setTypedFields(factory.createAdresseErfassungTypedFields(typedFields));
                    final VolleAdresse volleAdresse = factory.createVolleAdresse();
                    {

                        boolean hasName = false;
                        final AddressFields valueFields = factory.createAddressFields();
                        {
                            final vn.sps.aba.dds.common.model.receiver.AddressFields addressFields = receiverInfo.getAdressErfassung().getVolleAdresse()
                                .getAddressFields();

                            if (addressFields != null) {
                                // Note: remove by customer's requirement these fields do not have values
                                //valueFields.setAdressZusatz(factory.createAddressFieldsAdressZusatz(addressFields.getAdressZusatz()));
                                //valueFields.setCoAdresse(factory.createAddressFieldsCoAdresse(addressFields.getCoAdress()));
                                //valueFields.setStockwerk(factory.createAddressFieldsStockwerk(addressFields.getStockwerk()));

                                valueFields.setAnrede(factory.createAddressFieldsAnrede(addressFields.getAnrede()));
                                valueFields.setDienstleistung(
                                    factory.createAddressFieldsDienstleistung(EnumResolver.resolveDienstleistung(addressFields.getDienstleistung())));
                                String name = addressFields.getName();
                                valueFields.setName(factory.createAddressFieldsName(name));
                                String firmeName = addressFields.getFirmeName();
                                valueFields.setFirmenname(factory.createAddressFieldsFirmenname(firmeName));
                                hasName = StringUtil.notNullOrEmpty(name) || StringUtil.notNullOrEmpty(firmeName);
                                valueFields.setHausnummer(MessageBuilder.string2Integer(addressFields.getHausNummer(), receiverInfo, "Hausnummer-Value"));
                                valueFields.setHausnummerZusatz(factory.createAddressFieldsHausnummerZusatz(addressFields.getHausNummerZusatz()));
                                valueFields.setKundennummer(factory.createAddressFieldsKundennummer(addressFields.getKundenNummer()));
                                valueFields.setLaenderCode(factory.createAddressFieldsLaenderCode(addressFields.getLaenderCode()));
                                valueFields.setLand(factory.createAddressFieldsLand(addressFields.getLand()));
                                valueFields.setNameZusatz(factory.createAddressFieldsNameZusatz(addressFields.getNameZusatz()));
                                valueFields.setOrt(factory.createAddressFieldsOrt(addressFields.getOrt()));
                                valueFields.setPostfach(factory.createAddressFieldsPostfach(addressFields.getPostfach()));
                                valueFields.setPostleitzahl(factory.createAddressFieldsPostleitzahl(addressFields.getPostleizahl()));
                                valueFields.setStrasse(factory.createAddressFieldsStrasse(addressFields.getStrasse()));
                                valueFields.setVorname(factory.createAddressFieldsVorname(addressFields.getVorname()));
                            }
                        }
                        volleAdresse.setFields(valueFields);

                        final vn.sps.aba.dds.common.model.receiver.VolleAdresse volleAdr = receiverInfo.getAdressErfassung().getVolleAdresse();

                        // Only set the AmpKey if the Name or FirmeName exists in the full address
                        if (hasName) {
                            // The AMP-Key must be greater than 0
                            final String kdpId = nullOrGreaterThanZeroString(receiverInfo.getKdpId(), receiverInfo, "AMP-Key");
                            if (kdpId != null) {
                                volleAdresse.setKdpId(factory.createVolleAdresseKdpId(kdpId));
                            }
                        }
                        volleAdresse.setParcelAdrAmpStatus(EnumResolver.resolveAmpStatus(volleAdr.getParcelAdrAmpStatus()));

                        volleAdresse.getParcelAdrType().add(volleAdr.getParcelAdrType());

                        // If the ParcelHausKey is a less than 0, take over the HausKey instead
                        final String realParcelHausKey = nullOrGreaterThanZeroString(receiverInfo.getParcelHausKey(), receiverInfo, "ParcelHausKey");
                        final String parcelHausKey = realParcelHausKey != null ? realParcelHausKey : hausKey;
                        volleAdresse.setParcelHausKey(factory.createVolleAdresseParcelHausKey(parcelHausKey));
                        volleAdresse.setParcelStreetNr(string2Integer(volleAdr.getParcelStreetNumber(), receiverInfo, "ParcelStreetNr"));
                        volleAdresse.setPersType(factory.createVolleAdressePersType(EnumResolver.resolvePersType(volleAdr.getPersType())));
                        volleAdresse.setPersStatus(factory.createVolleAdressePersStatus(EnumResolver.resolvePersStatus(volleAdr.getPersStatus())));

                    }
                    adresseErfassung.setVolleAdresse(volleAdresse);

                }
                captureResultRecord.setAdresseErfassung(adresseErfassung);

                final CaptureInfo captureInfo = factory.createCaptureInfo();
                {
                    final vn.sps.aba.dds.common.model.receiver.CaptureInfo capture = receiverInfo.getCaptureInfo();

                    captureInfo.setCaptureResultCode(EnumResolver.resolveCaptureResultCode(capture.getCaptureResultCode()));
                    captureInfo.setCoderId(capture.getCoderId());
                    captureInfo.setCodingStation(capture.getCodingStation());
                    captureInfo.setCodingTimestamp(DateUtil.string2Gregorian(capture.getCodingTimeStamp()));
                }
                captureResultRecord.setCaptureInfo(captureInfo);

                captureResultRecord.setIdentcode(receiverInfo.getIdentCode());

                // Customer requirement said ParcelData is null
                //                final ParcelData parcelData = factory.createParcelData();
                //                {
                //                    final vn.sps.aba.dds.common.model.receiver.ParcelData parcelInfo = receiverInfo.getParcelData();
                //                    {
                //                        if (parcelInfo != null) {
                //                            parcelData.setAcsTimestamp(DateUtil.string2Gregorian(parcelInfo.getAcsTimestamp()));
                //                            parcelData.setDestinationStation(parcelInfo.getDestinationStation());
                //                            parcelData.setParPicId(parcelInfo.getParPicId());
                //                            parcelData.setSourceStation(parcelInfo.getSourceStation());
                //                            parcelData.setVcsCase(string2Int(parcelInfo.getVcsCase(), key));
                //                            {
                //                                final ArrayOfProduktZusatzLeistung aopzl = factory.createArrayOfProduktZusatzLeistung();
                //
                //                                for (final String produktZusatzleistungen : parcelInfo.getZusatzLeistungen()) {
                //
                //                                    Integer code = string2Integer(produktZusatzleistungen, key);
                //                                    if (code != null) {
                //                                        final vn.sps.aba.dds.common.types.ws.vam.capturing.model.ProduktZusatzLeistung produkt = factory
                //                                            .createProduktZusatzLeistung();
                //                                        produkt.setCode(code);
                //                                        aopzl.getProduktZusatzLeistung().add(produkt);
                //                                    }
                //                                }
                //                                parcelData.setZusatzLeistungen(aopzl);
                //                            }
                //                        }
                //                    }
                //                }
                final Timestamps timestamps = factory.createTimestamps();
                {
                    timestamps.setDisCoTimestamp(DateUtil.milli2GregorianCalendar(receiverInfo.getCaptureResultBegin()));
                    timestamps.setVGTimestamp(DateUtil.string2Gregorian(receiverInfo.getVgTimestamp()));
                }
                captureResultRecord.setTimestamps(timestamps);
            }
            captureResultIn.setCaptureResultRecord(captureResultRecord);
        }

        return captureResultIn;
    }

    /**
     * Builds the data transfer response.
     *
     * @param objectFactory the object factory
     * @param resp the resp
     * @param reasons the reasons
     * @return the put delivery info response
     */
    public static PutDeliveryInfoResponse buildDataTransferResponse(
        final vn.sps.aba.dds.common.types.ws.dts.model.ObjectFactory objectFactory,
        final Response resp,
        final List<String> reasons) {

        final PutDeliveryInfoResponse putDeliveryInfoResponse = objectFactory.createPutDeliveryInfoResponse();

        putDeliveryInfoResponse.setRESPCODE(resp.getCode());
        String description = resp.getDescription() + Constant.LINE_SEPARATOR;

        for (final String reason : reasons) {
            description += reason + Constant.LINE_SEPARATOR;
        }
        putDeliveryInfoResponse.setRESPERROR(description);

        return putDeliveryInfoResponse;
    }

    /**
     * Builds the dpm batch response.
     *
     * @param objectFactory the object factory
     * @param response the response
     * @param description the description
     * @return the vn.sps.aba.dds.service.dpm.batch. capture result response
     */
    public static vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultResponse buildDPMBResponse(
        final vn.sps.aba.dds.common.types.ws.dpmb.ObjectFactory objectFactory,
        final Response response,
        final Description description) {

        final vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultResponse captureResultResponse = objectFactory.createCaptureResultResponse();

        final vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultOut captureResultOut = objectFactory.createCaptureResultOut();
        {
            captureResultOut.setStatusCode(Integer.valueOf(response.getCode()));
            captureResultOut.setStatusText(response.getDescription());
            String detailText = "";

            if (description.getMessages().size() > 0) {
                detailText = "Detail information:";
                for (final String reason : description.getMessages()) {

                    detailText += reason + Constant.CHAR_SEMICOLON;
                }
            }
            captureResultOut.setDetailText(detailText);
        }
        captureResultResponse.setCaptureResultResult(captureResultOut);

        return captureResultResponse;
    }

    /**
     * Builds the dpm response.
     *
     * @param objectFactory the object factory
     * @param response the response
     * @param description the description
     * @return the capture result response
     */
    public static CaptureResultResponse buildDPMResponse(
        final vn.sps.aba.dds.common.types.ws.vam.capturing.model.ObjectFactory objectFactory,
        final Response response,
        final Description description) {

        final CaptureResultResponse captureResultResponse = objectFactory.createCaptureResultResponse();

        final CaptureResultOut captureResultOut = objectFactory.createCaptureResultOut();
        {
            captureResultOut.setStatusCode(Integer.valueOf(response.getCode()));
            captureResultOut.setStatusText(response.getDescription());
            String detailText = response.getDescription() + Constant.LINE_SEPARATOR;

            for (final String reason : description.getMessages()) {

                detailText += reason + Constant.LINE_SEPARATOR;
            }
            captureResultOut.setDetailText(detailText);
        }
        captureResultResponse.setCaptureResultResult(objectFactory.createCaptureResultResponseCaptureResultResult(captureResultOut));

        return captureResultResponse;
    }

    /**
     * Builds the dpms response.
     *
     * @param serviceConfiguration the service configuration
     * @param response the response
     * @param validatingInfo the description
     * @return the vn.sps.aba.dds.common.types.ws.dpms. capture result response
     */
    public static vn.sps.aba.dds.common.types.ws.dpms.CaptureResultResponse buildDPMSResponse(
        final DpmsServiceConfiguration serviceConfiguration,
        final Response response,
        final PackageValidatingInfo validatingInfo) {
        final vn.sps.aba.dds.common.types.ws.dpms.ObjectFactory objectFactory = serviceConfiguration.getObjectFactory();
        final vn.sps.aba.dds.common.types.ws.dpms.CaptureResultResponse captureResultResponse = objectFactory.createCaptureResultResponse();

        final vn.sps.aba.dds.common.types.ws.dpms.CaptureResultOut captureResultOut = objectFactory.createCaptureResultOut();
        {
            captureResultOut.setStatusCode(Integer.valueOf(response.getCode()));
            captureResultOut.setStatusText(response.getDescription());

            String detailText = null;
            if (serviceConfiguration.isAddValidationErrorDetail()) {
                if (validatingInfo.getErrors().size() > 0) {
                    detailText = String.join(Constant.CHAR_SEMICOLON, validatingInfo.getErrors());
                }
            }
            captureResultOut.setDetailText(detailText);
        }
        captureResultResponse.setCaptureResultResult(captureResultOut);

        return captureResultResponse;
    }

    /**
     * Builds the match maker message.
     *
     * @param receiverInfo the receiver info
     * @param serviceConfiguration the service configuration
     * @return the match maker request
     * @throws DatatypeConfigurationException the datatype configuration
     * exception
     */
    public static MatchMakerRequest buildMatchMakerMessage(final ReceiverInfo receiverInfo, final MatchMakerServiceConfiguration serviceConfiguration)
            throws DatatypeConfigurationException {

        final vn.sps.aba.dds.common.types.ws.padasa.matchmakerdaten.model.ObjectFactory objectFactory = serviceConfiguration.getObjectFactory();
        final MatchMakerRequest matchMakerRequest = objectFactory.createMatchMakerRequest();
        {
            matchMakerRequest.setIdentCode(receiverInfo.getIdentCode());

            // If HausKey, ParcelHausKey or KdpId is less than one, don't send them to PADASA MatchMaker service
            Integer hausKey = nullOrGreaterThanZeroInt(receiverInfo.getHausKey(), receiverInfo, "KDPHauskey");
            matchMakerRequest.setKDPHauskey(hausKey);
            Integer parcelHausKey = nullOrGreaterThanZeroInt(receiverInfo.getParcelHausKey(), receiverInfo, "ParcelHauskey");
            matchMakerRequest.setParcelHauskey(parcelHausKey == null ? hausKey : parcelHausKey);
            /* Before ABA-89: matchMakerRequest.setKDPId(nullOrGreaterThanZeroInt(receiverInfo.getKdpId(), receiverInfo, "AMP-Key"));*/

            // Note: Remove by customer's requirement (DPM doesn't send parcel data to Disco)
            //            if (receiverInfo.getParcelData() != null) {
            //                matchMakerRequest.setDienstleistung(String.join(Constant.CHAR_COMMA, receiverInfo.getParcelData().getZusatzLeistungenAsString()));
            //            }
            if (receiverInfo.getAdressErfassung() != null) {

                final vn.sps.aba.dds.common.model.receiver.VolleAdresse volleAdresse = receiverInfo.getAdressErfassung().getVolleAdresse();
                if (volleAdresse != null) {
                    matchMakerRequest.setKDPPersTyp(serviceConfiguration.resolvePersType(volleAdresse.getPersType()));
                    final Integer ampStatus = serviceConfiguration.resolveAmpStatus(volleAdresse.getParcelAdrAmpStatus());
                    matchMakerRequest.setKDPAMPStatus(ampStatus == null ? 0 : ampStatus);
                    final Integer vaeAddressType = serviceConfiguration.resolveVaeAddressType(volleAdresse.getParcelAdrType());
                    matchMakerRequest.setVaeAddressType(vaeAddressType);
                    final String parcelStreetNumber = volleAdresse.getParcelStreetNumber();
                    matchMakerRequest.setStreetnumber(StringUtil.notNullOrEmpty(parcelStreetNumber) ? parcelStreetNumber : "0");
                    
                    final vn.sps.aba.dds.common.model.receiver.AddressFields addressFields = volleAdresse.getAddressFields();
                    if (addressFields != null) {
                        matchMakerRequest.setKundennummer(addressFields.getKundenNummer());
                        matchMakerRequest.setCountryCode(addressFields.getLaenderCode());
                        matchMakerRequest.setOrt(addressFields.getOrt());
                        matchMakerRequest.setAnrede(addressFields.getAnrede());
                        matchMakerRequest.setName(addressFields.getName());
                        matchMakerRequest.setVorname(addressFields.getVorname());
                        matchMakerRequest.setNamezusatz(addressFields.getNameZusatz());
                        matchMakerRequest.setFirmenname(addressFields.getFirmeName());
                        matchMakerRequest.setStrasse(addressFields.getStrasse());
                        matchMakerRequest.setHausnummer(MessageBuilder.string2Integer(addressFields.getHausNummer(), receiverInfo, "Hausnummer"));
                        matchMakerRequest.setHausnummerzusatz(addressFields.getHausNummerZusatz());
                        matchMakerRequest.setPostfach(addressFields.getPostfach());
                        matchMakerRequest.setPLZ(addressFields.getPostleizahl());
                        matchMakerRequest.setDienstleistung(addressFields.getDienstleistung());
                        
                        /** Since ABA-89:BUC_3: remove ident_code if Parcel has NOT Name or Firname*/
                        String name = addressFields.getName();
                        String firmeName = addressFields.getFirmeName();
                        boolean hasName = StringUtil.notNullOrEmpty(name) || StringUtil.notNullOrEmpty(firmeName);
                        if (hasName) {
                        	 matchMakerRequest.setKDPId(nullOrGreaterThanZeroInt(receiverInfo.getKdpId(), receiverInfo, "AMP-Key"));
						}
                    }
                }
            }

            final vn.sps.aba.dds.common.model.receiver.CaptureInfo captureInfo = receiverInfo.getCaptureInfo();
            {
                matchMakerRequest.setMatchmakerResponseCode(serviceConfiguration.resolveMatchMakerResponseCode(captureInfo.getCaptureResultCode()));
            }
            matchMakerRequest.setLastUpdate(DateUtil.milli2GregorianCalendar(receiverInfo.getMatchMakerBegin()));
        }

        return matchMakerRequest;
    }

    /**
     * Builds the parcel response.
     *
     * @param serviceConfiguration the service configuration
     * @param validatingInfo the reasons
     * @return the transfer parcel info response
     */
    public static TransferParcelInfoResponse buildParcelResponse(
        final ParcelInfoServiceConfiguration serviceConfiguration,
        final ParcelValidatingInfo validatingInfo) {

        final ObjectFactory factory = serviceConfiguration.getObjectFactory();
        final TransferParcelInfoOut parcelInfoOut = factory.createTransferParcelInfoOut();
        final Response resp = validatingInfo.getResponse();
        final TransferParcelInfoResponse response = factory.createTransferParcelInfoResponse();
        {
            parcelInfoOut.setVersion(EnvelopVersion.VERSION_1_1.getValue());
            parcelInfoOut.setStatusCode(Integer.valueOf(resp.getCode()));
            parcelInfoOut.setStatusText(resp.getDescription());
            if (serviceConfiguration.isAddValidationErrorDetail()) {
                final String detailText = String.join(Constant.CHAR_SEMICOLON, validatingInfo.getErrors());
                parcelInfoOut.setDetailText(factory.createTransferParcelInfoOutDetailText(detailText));
            }

            response.setTransferParcelInfoResult(factory.createTransferParcelInfoResponseTransferParcelInfoResult(parcelInfoOut));
        }
        return response;
    }

    /**
     * Builds the transfer receiver info response.
     *
     * @param objectFactory the object factory
     * @param response the response
     * @param reasons the reasons
     * @return the transfer receiver info response
     */
    public static TransferReceiverInfoResponse buildTransferReceiverInfoResponse(
        final vn.sps.aba.dds.common.types.ws.dpm.model.ObjectFactory objectFactory,
        final Response response,
        final Description reasons) {

        final TransferReceiverInfoResponse transferReceiverInfoResponse = objectFactory.createTransferReceiverInfoResponse();
        final ReceiverInfoResponseType receiverInfoResponse = objectFactory.createReceiverInfoResponseType();

        receiverInfoResponse.setStatusCode(StatusCodeType.forName(response.getCode()));
        String description = response.getDescription() + Constant.LINE_SEPARATOR;

        for (final String reason : reasons.getMessages()) {
            description += reason + Constant.LINE_SEPARATOR;
        }
        receiverInfoResponse.setDescription(objectFactory.createReceiverInfoResponseTypeDescription(description));

        transferReceiverInfoResponse.setReceiverInfoResponse(objectFactory.createTransferReceiverInfoResponseReceiverInfoResponse(receiverInfoResponse));

        return transferReceiverInfoResponse;
    }

    /**
     * Check vae condition.
     *
     * @param key the key
     * @param barcode the barcode
     * @param configuration the configuration
     * @return true, if successful
     */
    private static boolean checkVaeCondition(final String key, final Barcode barcode, final VaeBlackboxServiceConfiguration configuration) {
        boolean ret = false;

        try {
            final String type = barcode.getType();
            final String code = barcode.getCode();
            if ((type == null) || type.isEmpty() || (code == null)) {
                return false;
            }
            ret = configuration.getValidType().equals(type) && code.matches(configuration.getValidCode());
        }
        catch (final Exception e) {
            LOG.warn(IndexMaker.index(key), "Error when check barcode", e);
        }

        return ret;
    }

    /**
     * New barcode data message id.
     *
     * @param pattern the pattern
     * @return the string
     */
    private static String newBarcodeDataMessageId(final String pattern) {

        return DateUtil.currentDateAsString(pattern);
    }

    /**
     * Null or greater than zero int.
     *
     * @param value the value
     * @param entry the entry
     * @param fieldName the field name
     * @return the integer
     */
    private static Integer nullOrGreaterThanZeroInt(final String value, final IdentifiedEntry entry, final String fieldName) {
        Integer ret = null;

        if (value != null) {
            try {
                final Integer integer = Integer.valueOf(value);
                if ((integer != null) && (integer.intValue() > 0)) {
                    ret = integer;
                }
            }
            catch (final Exception e) {
                LOG.debug(IndexMaker.index(entry), "Cannot parse " + fieldName + " to integer", e);
            }
        }

        return ret;
    }

    /**
     * Less than one.
     *
     * @param value the value
     * @param entry the entry
     * @param fieldName the field name
     * @return true, if successful
     */
    private static String nullOrGreaterThanZeroString(final String value, final IdentifiedEntry entry, final String fieldName) {
        String ret = null;

        if (value != null) {
            try {
                final Integer integer = Integer.valueOf(value);
                if ((integer != null) && (integer.intValue() > 0)) {
                    ret = value;
                }
            }
            catch (final Exception e) {
                LOG.debug(IndexMaker.index(entry), "Cannot parse " + fieldName + " to integer", e);
            }
        }

        return ret;
    }

    /**
     * Resolve coding site.
     *
     * @param configuration the configuration
     * @param parcelInfo the parcel info
     * @return the string
     */
    private static String resolveCodingSite(final BarcodeDataServiceConfiguration configuration, final ParcelInfo parcelInfo) {
        String codingSiteId = null;

        final String callerId = parcelInfo.getCallerId();
        if (callerId != null) {
            codingSiteId = configuration.getCodingSites().get(callerId);
        }
        if ((codingSiteId == null) && (parcelInfo.getParcelAddress() != null)) {
            codingSiteId = parcelInfo.getParcelAddress().getZip();
        }

        return codingSiteId;
    }

    /**
     * String2 double.
     *
     * @param s the s
     * @return the double
     */
    private static Double string2Double(final String s) {
        try {
            return s == null ? 0 : Double.parseDouble(s);
        }
        catch (final NumberFormatException e) {
            return 0.0;
        }
    }

    /**
     * String2 int.
     *
     * @param string the string
     * @param entry the entry
     * @return the int
     */
    @SuppressWarnings("unused")
    private static int string2Int(final String string, final IdentifiedEntry entry) {
        try {
            return Integer.valueOf(string).intValue();
        }
        catch (final NumberFormatException e) {
            LOG.error(IndexMaker.index(entry), "Cannot parse value {} to integer", string);
            return 0;
        }
    }

    /**
     * String2 integer.
     *
     * @param string the string
     * @param entry the entry
     * @param defaultValue the default value
     * @param fieldName the field name
     * @return the integer
     */
    @SuppressWarnings("unused")
    private static Integer string2Integer(final String string, final IdentifiedEntry entry, final Integer defaultValue, final String fieldName) {
        try {
            return Integer.valueOf(string);
        }
        catch (final NumberFormatException e) {
            LOG.error(IndexMaker.index(entry), "Cannot parse {} field with value {} to integer. Default value is {}", fieldName, string, defaultValue);
            return defaultValue;
        }
    }

    /**
     * String2 integer.
     *
     * @param string the string
     * @param entry the entry
     * @param fieldName the field name
     * @return the integer
     */
    private static Integer string2Integer(final String string, final IdentifiedEntry entry, final String fieldName) {
        try {
            return Integer.valueOf(string);
        }
        catch (final NumberFormatException e) {
            LOG.error(IndexMaker.index(entry), "Cannot parse {} field with value {} to integer", fieldName, string);
            return null;
        }
    }

    /**
     * Constructs a new <tt>ResponseBuilder</tt>.
     */
    private MessageBuilder() {
    }
}
