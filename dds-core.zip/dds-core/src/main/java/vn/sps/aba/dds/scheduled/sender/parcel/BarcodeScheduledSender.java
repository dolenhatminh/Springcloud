/*
 * Class: BarcodeScheduledSender
 *
 * Created on Oct 12, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.sender.parcel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.Enumeration.DmcState;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.scheduler.DdsScheduler;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.service.padasa.vgparcelbcdataresult.IVgParcelBcDataResultService;

/**
 * The Class BarcodeScheduledSender.
 */
@Configuration
@Component("BarcodeScheduledSender")
@ConfigurationProperties("schedule.resend.padasa.barcode")
public class BarcodeScheduledSender extends AbstractParcelInfoSender {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(BarcodeScheduledSender.class);

    /** The vg parcel bc data result service. */
    @Autowired
    private IVgParcelBcDataResultService vgParcelBcDataResultService;

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.scheduled.sender.AbstractScheduledSender#buildSenderExecutor()
     */
    @Override
    protected void buildSenderExecutor() {
        this.scheduledExecutor = new DdsScheduler() {

            @Override
            public String getName() {
                return "resend-barcode-scheduler-";
            }

            @Override
            public ThreadPoolTaskScheduler getScheduler() {
                final ThreadPoolTaskScheduler executor = new ThreadPoolTaskScheduler();
                {
                    final ThreadPoolTaskScheduler scheduler = executor;
                    scheduler.setBeanName(this.getName());
                    scheduler.setThreadNamePrefix(TaskConfiguration.TASK_PREFIX + this.getName());
                    scheduler.setPoolSize(getParallel());
                    scheduler.setRemoveOnCancelPolicy(isRemoveOnCancel());
                    scheduler.initialize();
                    LOG.info(
                        "Create sender thread pool task executor {}. Core pool: {}. Max pool: {}",
                        getName(),
                        scheduler.getPoolSize(),
                        scheduler.getScheduledThreadPoolExecutor().getMaximumPoolSize());
                }
                return executor;
            }
        };
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#getDestinationServiceName()
     */
    @Override
    protected String getDestinationServiceName() {
        return "PADASA Barcode";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#mergeAndStore(java.lang.String, java.util.Iterator, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    protected void mergeAndStore(final String key, final ParcelInfo parcelInfo) {
        try {
            ParcelInfo ret = this.parcelInfoDao.get(key);
            if (ret != null) {
                ret.setDmcState(parcelInfo.getDmcState());
                ret.setBarcodeBegin(parcelInfo.getBarcodeBegin());
                ret.setBarcodeEnd(parcelInfo.getBarcodeEnd());
                ret.setBarcodeCount(parcelInfo.getBarcodeCount());
            }
            else {
                LOG.info(IndexMaker.index(key), "Cannot find any parcel match with key");
                ret = parcelInfo;
            }
            this.parcelInfoDao.store(key, ret);
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when merge and store parcel into database.", e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#needToSent(java.lang.String, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    protected boolean needToSent(final String key, final ParcelInfo parcelInfo) {
        return DmcState.PADASA_BARCODE_READY == parcelInfo.getDmcState();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#resendParcel(java.lang.String, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    protected boolean resend(final String key, final ParcelInfo parcelInfo) {
        try {
            if (BarcodeScheduledSender.this.vgParcelBcDataResultService.transferToBarcodeDataService(parcelInfo)) {

                parcelInfo.setDmcState(DmcState.PADASA_BARCODE_SENT);
                LOG.info(IndexMaker.index(parcelInfo), "Forwarded Barcode data of parcel to PADASA BarcodeDataService successfully");
                return true;
            }
            else {
                LOG.info(IndexMaker.index(parcelInfo), "Failed to send Barcode data of parcel to PADASA BarcodeDataService");
            }
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when re-send PADASA Barcode.", e);
        }

        return false;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#taskName()
     */
    @Override
    public String taskName() {
        return "padasa-barcode-scheduled-sender";
    }

}
