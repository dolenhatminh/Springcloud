
package vn.sps.aba.dds.common.types.ws.vae.blackbox;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for CaptureRequestRecord complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CaptureRequestRecord">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AddressFields" type="{http://schemas.datacontract.org/2004/07/DisCoService}AddressFields"/>
 *         &lt;element name="AdresseErfassung" type="{http://schemas.datacontract.org/2004/07/DisCoService}AdresseErfassung"/>
 *         &lt;element name="IdentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Image" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/>
 *         &lt;element name="ParcelData" type="{http://schemas.datacontract.org/2004/07/DisCoService}ParcelData"/>
 *         &lt;element name="ParcelAddress" type="{http://schemas.datacontract.org/2004/07/DisCoService}ParcelAddress"/>
 *         &lt;element name="PDSTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="DiscoTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="Priority" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Kundennummer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Dienstleistung" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="IdentCodeOrientation" type="{http://schemas.datacontract.org/2004/07/DisCoService}IdentCodeOrientation"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CaptureRequestRecord", propOrder = {
    "addressFields",
    "adresseErfassung",
    "identCode",
    "image",
    "parcelData",
    "parcelAddress",
    "pdsTimestamp",
    "discoTimestamp",
    "priority",
    "kundennummer",
    "dienstleistung",
    "identCodeOrientation"
})
public class CaptureRequestRecord {

    @XmlElement(name = "AddressFields", required = true, nillable = true)
    protected AddressFields addressFields;
    @XmlElement(name = "AdresseErfassung", required = true, nillable = true)
    protected AdresseErfassung adresseErfassung;
    @XmlElementRef(name = "IdentCode", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> identCode;
    @XmlElement(name = "Image", required = true, nillable = true)
    protected byte[] image;
    @XmlElement(name = "ParcelData", required = true, nillable = true)
    protected ParcelData parcelData;
    @XmlElement(name = "ParcelAddress", required = true, nillable = true)
    protected ParcelAddress parcelAddress;
    @XmlElement(name = "PDSTimestamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar pdsTimestamp;
    @XmlElement(name = "DiscoTimestamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar discoTimestamp;
    @XmlElement(name = "Priority", required = true, type = Integer.class, nillable = true)
    protected Integer priority;
    @XmlElementRef(name = "Kundennummer", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<String> kundennummer;
    @XmlElementRef(name = "Dienstleistung", namespace = "http://schemas.datacontract.org/2004/07/DisCoService", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> dienstleistung;
    @XmlElement(name = "IdentCodeOrientation", required = true, nillable = true)
    protected IdentCodeOrientation identCodeOrientation;

    /**
     * Gets the value of the addressFields property.
     * 
     * @return
     *     possible object is
     *     {@link AddressFields }
     *     
     */
    public AddressFields getAddressFields() {
        return addressFields;
    }

    /**
     * Sets the value of the addressFields property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressFields }
     *     
     */
    public void setAddressFields(AddressFields value) {
        this.addressFields = value;
    }

    /**
     * Gets the value of the adresseErfassung property.
     * 
     * @return
     *     possible object is
     *     {@link AdresseErfassung }
     *     
     */
    public AdresseErfassung getAdresseErfassung() {
        return adresseErfassung;
    }

    /**
     * Sets the value of the adresseErfassung property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdresseErfassung }
     *     
     */
    public void setAdresseErfassung(AdresseErfassung value) {
        this.adresseErfassung = value;
    }

    /**
     * Gets the value of the identCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getIdentCode() {
        return identCode;
    }

    /**
     * Sets the value of the identCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setIdentCode(JAXBElement<String> value) {
        this.identCode = value;
    }

    /**
     * Gets the value of the image property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getImage() {
        return image;
    }

    /**
     * Sets the value of the image property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setImage(byte[] value) {
        this.image = value;
    }

    /**
     * Gets the value of the parcelData property.
     * 
     * @return
     *     possible object is
     *     {@link ParcelData }
     *     
     */
    public ParcelData getParcelData() {
        return parcelData;
    }

    /**
     * Sets the value of the parcelData property.
     * 
     * @param value
     *     allowed object is
     *     {@link ParcelData }
     *     
     */
    public void setParcelData(ParcelData value) {
        this.parcelData = value;
    }

    /**
     * Gets the value of the parcelAddress property.
     * 
     * @return
     *     possible object is
     *     {@link ParcelAddress }
     *     
     */
    public ParcelAddress getParcelAddress() {
        return parcelAddress;
    }

    /**
     * Sets the value of the parcelAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link ParcelAddress }
     *     
     */
    public void setParcelAddress(ParcelAddress value) {
        this.parcelAddress = value;
    }

    /**
     * Gets the value of the pdsTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPDSTimestamp() {
        return pdsTimestamp;
    }

    /**
     * Sets the value of the pdsTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPDSTimestamp(XMLGregorianCalendar value) {
        this.pdsTimestamp = value;
    }

    /**
     * Gets the value of the discoTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDiscoTimestamp() {
        return discoTimestamp;
    }

    /**
     * Sets the value of the discoTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDiscoTimestamp(XMLGregorianCalendar value) {
        this.discoTimestamp = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPriority(Integer value) {
        this.priority = value;
    }

    /**
     * Gets the value of the kundennummer property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getKundennummer() {
        return kundennummer;
    }

    /**
     * Sets the value of the kundennummer property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setKundennummer(JAXBElement<String> value) {
        this.kundennummer = value;
    }

    /**
     * Gets the value of the dienstleistung property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getDienstleistung() {
        return dienstleistung;
    }

    /**
     * Sets the value of the dienstleistung property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setDienstleistung(JAXBElement<Integer> value) {
        this.dienstleistung = value;
    }

    /**
     * Gets the value of the identCodeOrientation property.
     * 
     * @return
     *     possible object is
     *     {@link IdentCodeOrientation }
     *     
     */
    public IdentCodeOrientation getIdentCodeOrientation() {
        return identCodeOrientation;
    }

    /**
     * Sets the value of the identCodeOrientation property.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentCodeOrientation }
     *     
     */
    public void setIdentCodeOrientation(IdentCodeOrientation value) {
        this.identCodeOrientation = value;
    }

}
