
package vn.sps.aba.dds.common.types.ws.dpmb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CaptureResultResult" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}CaptureResultOut" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "captureResultResult"
})
@XmlRootElement(name = "CaptureResultResponse")
public class CaptureResultResponse {

    @XmlElement(name = "CaptureResultResult")
    protected CaptureResultOut captureResultResult;

    /**
     * Gets the value of the captureResultResult property.
     * 
     * @return
     *     possible object is
     *     {@link CaptureResultOut }
     *     
     */
    public CaptureResultOut getCaptureResultResult() {
        return captureResultResult;
    }

    /**
     * Sets the value of the captureResultResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link CaptureResultOut }
     *     
     */
    public void setCaptureResultResult(CaptureResultOut value) {
        this.captureResultResult = value;
    }

}
