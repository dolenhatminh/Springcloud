/*
 * Class: DpmServiceEnpoint
 *
 * Created on Jul 22, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.service.dpmb;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import net.logstash.logback.marker.Markers;
import vn.sps.aba.dds.common.constant.DDSConstant.Namespace;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.message.Description;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureResult;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultIn;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultIn.CaptureResultRecords;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultRecord;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultResponse;
import vn.sps.aba.dds.common.types.ws.dpmb.ObjectFactory;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.service.DpmbServiceConfiguration;
import vn.sps.aba.dds.config.task.validator.ReceiverValidatingExecutor;
import vn.sps.aba.dds.processor.receiver.ReceiverProcessingManager;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;

/**
 * The Class DpmServiceEnpoint.
 */
@Endpoint
@Profile(Profiles.DPMB)
public class EnhancedDpmbServiceEnpoint {

    /**
     * The Class DelegateReceiverInfoValidator.
     */
    private class DelegateReceiverInfoValidator {

        /** The capture result records. */
        private CaptureResultRecords captureResultRecords;

        /**
         * {@inheritDoc}
         *
         * @see java.util.concurrent.RecursiveTask#compute()
         */
        protected List<ReceiverInfoWrapper> compute() {

            final List<ReceiverInfoWrapper> ret = new ArrayList<>();
            final List<Future<ReceiverInfoWrapper>> tasks = new ArrayList<>();
            final AsyncTaskExecutor executor = EnhancedDpmbServiceEnpoint.this.taskDpmbReception.getAsyncExecutor();

            for (final CaptureResultRecord record : this.captureResultRecords.getCaptureResultRecord()) {

                tasks.add(executor.submit(() -> {
                    final EnhancedReceiverInfoValidator validator = new EnhancedReceiverInfoValidator(record,
                        EnhancedDpmbServiceEnpoint.this.serviceConfiguration);
                    return validator.validate();
                }));
            }
            for (final Future<ReceiverInfoWrapper> future : tasks) {
                try {
                    ret.add(future.get());
                }
                catch (final Exception e) {
                    LOG.error(e.getMessage(), e);
                }
            }

            return ret;
        }

        /**
         * Sets the capture result records.
         *
         * @param captureResultRecords the new capture result records
         */
        public void setCaptureResultRecords(final CaptureResultRecords captureResultRecords) {
            this.captureResultRecords = captureResultRecords;
        }

    }

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(EnhancedDpmbServiceEnpoint.class);

    /** The process manager. */
    @Autowired
    private ReceiverProcessingManager processManager;

    /** The receiver info DAO. */
    @Autowired
    private IReceiverInfoCacheDao receiverInfoDao;

    /** The service configuration. */
    @Autowired
    private DpmbServiceConfiguration serviceConfiguration;

    /** The task dpmb reception. */
    @Autowired
    private ReceiverValidatingExecutor taskDpmbReception;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.types.ws.vam.capturing.model.ICaptureResultService#captureResult(vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultIn)
     */
    @PayloadRoot(namespace = Namespace.E190_NAMESPACE, localPart = "CaptureResult")
    public @ResponsePayload CaptureResultResponse captureResult(@RequestPayload final CaptureResult captureResult) {

        Response response = this.serviceConfiguration.successful();

        final Description description = new Description();
        final boolean isInvalidArgumentError = this.isInvalidArgument(captureResult, description);

        final ObjectFactory objectFactory = this.serviceConfiguration.getObjectFactory();
        final long receivedTime = DiscoWallClock.milli();
        try {
            final CaptureResultIn request = captureResult.getRequest();
            if (!isInvalidArgumentError) {

                final CaptureResultRecords captureResultRecords = request.getCaptureResultRecords();
                final DelegateReceiverInfoValidator delegateValidator = new DelegateReceiverInfoValidator();
                delegateValidator.setCaptureResultRecords(captureResultRecords);

                final List<ReceiverInfoWrapper> wrappers = delegateValidator.compute();
                this.processTheValidOnes(receivedTime, request, wrappers, description);

                if (description.getMessages().size() > 0) {
                    response = this.serviceConfiguration.invalidCaptureResultRecordsError();
                }
            }
            else {
                response = this.serviceConfiguration.invalidArgumentError();
                final String key = StringUtil.newUuidString();
                final ReceiverInfo receiverInfo = new ReceiverInfo(key, request.getCallerId(), request.getVersion(), receivedTime);
                receiverInfo.setState(ReceiverState.REJECTED);
                receiverInfo.setStatusCode(response.getCode());
                this.receiverInfoDao.put(key, receiverInfo);

                LOG.error(Markers.appendFields(receiverInfo), "Invalid argument error");
            }
        }
        catch (final Exception e) {

            response = this.serviceConfiguration.unexpectedError();
            LOG.error("Error while processing the ReceiverInfo data", e);
        }

        return MessageBuilder.buildDPMBResponse(objectFactory, response, description);
    }

    /**
     * Checks if is invalid argument.
     *
     * @param captureResult the capture result
     * @param description the description
     * @return true, if is invalid argument
     */
    private boolean isInvalidArgument(final CaptureResult captureResult, final Description description) {

        final CaptureResultIn request = captureResult.getRequest();
        final boolean ret = (captureResult == null) || (request == null) || (request.getCaptureResultRecords() == null)
                || (request.getCaptureResultRecords().getCaptureResultRecord().size() <= 0);

        if (ret) {
            description.addMessage("There is no ReceiverInfo found");
            return ret;
        }
        if ((request.getCallerId() == null) || !request.getCallerId().matches(this.serviceConfiguration.getCallerIdFormat())) {
            description.addMessage("CallerId must match format " + this.serviceConfiguration.getCallerIdFormat());
        }
        if (request.getVersion() < 1) {
            description.addMessage("Version must be integer greater than 0");
        }

        return ret;
    }

    /**
     * Process the valid ones.
     *
     * @param receivedTime the received time
     * @param request the request
     * @param wrappers the wrappers
     * @param description the description
     */
    private void processTheValidOnes(
        final long receivedTime,
        final CaptureResultIn request,
        final List<ReceiverInfoWrapper> wrappers,
        final Description description) {

        final String successCode = this.serviceConfiguration.successful().getCode();
        final String invalidCode = this.serviceConfiguration.invalidCaptureResultRecordsError().getCode();
        for (final ReceiverInfoWrapper wrapper : wrappers) {

            final CaptureResultRecord receiverInfoRecord = wrapper.getReceiverInfo();
            final String identCode = receiverInfoRecord.getIdentcode();

            final String key = StringUtil.newUuidString();
            if (!wrapper.isInValid()) {

                final ReceiverInfo receiverInfo = new ReceiverInfo(request.getCallerId(), request.getVersion(), receiverInfoRecord);

                receiverInfo.setReceived(receivedTime);
                receiverInfo.setKey(key);
                receiverInfo.setStatusCode(successCode);
                this.receiverInfoDao.put(identCode, receiverInfo);
                this.processManager.submit(receiverInfo);
            }
            else {
                try {
                    description.getMessages().addAll(wrapper.getCauses());
                    final ReceiverInfo receiverInfo = new ReceiverInfo(request.getCallerId(), request.getVersion(), receiverInfoRecord);
                    receiverInfo.setReceived(receivedTime);
                    receiverInfo.setState(ReceiverState.REJECTED);
                    receiverInfo.setStatusCode(invalidCode);
                    receiverInfo.setKey(key);
                    this.receiverInfoDao.put(key, receiverInfo);
                    LOG.error(Markers.appendFields(receiverInfo), "Invalid ReceiverInfo");
                }
                catch (final Exception e) {
                    LOG.error("Error while trying to create ReceiverInfo from invalid source", e);
                }
            }
        }
    }

}
