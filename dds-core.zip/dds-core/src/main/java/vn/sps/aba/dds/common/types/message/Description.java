/*
 * Class: Reason
 *
 * Created on Jun 25, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.message;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class Reason.
 */
public class Description {

    /** The messages. */
    private List<String> messages = new ArrayList<>();

    /**
     * Adds the message.
     *
     * @param message the message
     */
    public void addMessage(final String message) {
        this.messages.add(message);
    }

    /**
     * Gets the messages.
     *
     * @return the messages
     */
    public List<String> getMessages() {
        return this.messages;
    }

    /**
     * Sets the messages.
     *
     * @param messages the new messages
     */
    public void setMessages(final List<String> messages) {
        this.messages = messages;
    }

}