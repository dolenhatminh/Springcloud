/*
 * Class: CacheParcelScheduledCleaner
 *
 * Created on Oct 17, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.preparer;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.ifa.ImmortalCollector;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.config.task.scheduler.WorkspaceScheduleExecutor;
import vn.sps.aba.dds.controller.interfaces.IEntriesController;
import vn.sps.aba.dds.io.IImageStorageProvider;
import vn.sps.aba.dds.jmx.WorkspaceInfo;
import vn.sps.aba.dds.scheduled.AbstractCronScheduler;
import vn.sps.aba.dds.scheduled.DdsScheduledTask;

/**
 * The Class CacheParcelScheduledCleaner.
 */
@Component("WorkspacePreparer")
@Configuration
@ConfigurationProperties("schedule.prepare.workspace")
public class WorkspacePreparer extends AbstractCronScheduler implements DdsScheduledTask, WorkspaceInfo {

    /** The Constant DATE_FORMAT. */
    private static final String DATE_FORMAT = "yyyy-MM-dd";

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(WorkspacePreparer.class);

    /** The barcode sender. */
    @Autowired
    @Qualifier("BarcodeSendingHandler")
    private ImmortalCollector barcodeSender;

    /** The blackbox sender. */
    @Autowired
    @Qualifier("BlackboxSendingHandler")
    private ImmortalCollector blackboxSender;

    /** The cleaner. */
    @Autowired
    @Qualifier("ParcelInfoController")
    private IEntriesController cleaner;

    /** The db error checker. */
    @Autowired
    private DBErrorChecker dbErrorChecker;

    /** The dmc process watcher. */
    @Autowired
    @Qualifier("DmcReceiver")
    private ImmortalCollector dmcProcessWatcher;

    /** The dmc receiver. */
    @Autowired
    @Qualifier("DmcReceiver")
    private ImmortalCollector dmcReceiver;

    /** The dmc sender. */
    @Autowired
    @Qualifier("DmcSendingHandler")
    private ImmortalCollector dmcSender;

    /** The match maker sender. */
    @Autowired
    @Qualifier("MatchMakerSendingHandler")
    private ImmortalCollector matchMakerSender;

    /** The parcel2 vam sender. */
    @Autowired
    @Qualifier("Parcel2VamSendingHandler")
    private ImmortalCollector parcel2VamSender;

    /** The parcel info dao. */
    @Autowired
    @Qualifier("ParcelInfoCacheDao")
    private ImmortalCollector parcelInfoDao;

    /** The parcel process watcher. */
    @Autowired
    @Qualifier("ParcelProcessingManager")
    private ImmortalCollector parcelProcessWatcher;

    /** The receiver2 vam sender. */
    @Autowired
    @Qualifier("Receiver2VamSendingHandler")
    private ImmortalCollector receiver2VamSender;

    /** The receiver info dao. */
    @Autowired
    @Qualifier("ReceiverInfoCacheDao")
    private ImmortalCollector receiverInfoDao;

    /** The scheduled executor. */
    @Autowired
    private WorkspaceScheduleExecutor scheduledExecutor;

    /** The storage provider. */
    @Autowired
    private IImageStorageProvider storageProvider;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.WorkspaceInfo#cleanFinishedTaskFromWatchers()
     */
    @Override
    public String cleanFinishedTaskFromWatchers() {
        int count = 0;
        {
            final long begin = DiscoWallClock.milli();
            LOG.info("Begin clean up the finished task from collector................");

            final boolean force = false;

            // Note: This is just a work around for sonar bug
            // Original code: dbErrorChecker.handleTask().run()
            ExecutorService singlePool = null;
            try {
                singlePool = Executors.newSingleThreadExecutor();
                singlePool.submit(this.dbErrorChecker.handleTask()).get();
            }
            catch (Exception e) {
                LOG.error("Error occured when process error database worker", e);
            }
            finally {
                if (singlePool != null) {
                    singlePool.shutdown();
                }
            }

            LOG.info("Remove the finished task from database worker watcher");
            count += this.parcelInfoDao.cleanFinishedTasks(force);
            LOG.info("Remove the finished task from parcel processor watcher");
            count += this.parcelProcessWatcher.cleanFinishedTasks(force);
            LOG.info("Remove the finished task from dmc processor watcher");
            count += this.dmcProcessWatcher.cleanFinishedTasks(force);
            LOG.info("Remove the finished task from dmc sender");
            count += this.dmcSender.cleanFinishedTasks(force);
            LOG.info("Remove the finished task from barcode sender");
            count += this.barcodeSender.cleanFinishedTasks(force);
            LOG.info("Remove the finished task from blackbox sender");
            count += this.blackboxSender.cleanFinishedTasks(force);
            LOG.info("Remove the finished task from parcel-2-vam sender");
            count += this.parcel2VamSender.cleanFinishedTasks(force);
            LOG.info("Remove the finished task from matchmaker sender");
            count += this.matchMakerSender.cleanFinishedTasks(force);
            LOG.info("Remove the finished task from receiver-2-vam sender");
            count += this.receiver2VamSender.cleanFinishedTasks(force);
            LOG.info("Remove the finished task from parcel storer");
            count += this.dmcReceiver.cleanFinishedTasks(force);
            LOG.info("Remove the finished task from receiver storer");
            count += this.receiverInfoDao.cleanFinishedTasks(force);
            LOG.info("Finished removal finished tasks. It took {} milliseconds", (DiscoWallClock.milli() - begin));
        }
        return String.format("Remmove %d finished tasks from watcher", count);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.WorkspaceInfo#cleanUp()
     */
    @Override
    public String cleanUp() {
        return "Currently not support";
    }

    /**
     * Config.
     */
    @PostConstruct
    protected void config() {
        this.scheduleConfigurar.registerScheduledTask(this, this.scheduledExecutor);
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.beans.factory.DisposableBean#destroy()
     */
    @Override
    public void destroy() throws Exception {
        this.scheduledExecutor.getScheduler().destroy();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#getCronExpression()
     */
    @Override
    public String getCronExpression() {
        return this.getCron();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#handleTask()
     */
    @Override
    public Runnable handleTask() {
        return () -> {
            if (this.isEnable()) {
                this.cleanFinishedTaskFromWatchers();
                final LocalDate tomorrow = LocalDate.now(DiscoWallClock.zone()).plusDays(1);
                this.prepareDate(tomorrow);
            }
        };
    }

    /**
     * Prepare date.
     *
     * @param tomorrow the tomorrow
     */
    private void prepareDate(final LocalDate tomorrow) {
        LOG.info("Prepare image directory for date {}", tomorrow);
        this.storageProvider.scanDirectory(tomorrow);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.WorkspaceInfo#scanDirectory(java.lang.String)
     */
    @Override
    public String scanDirectory(final String dateString) {
        final LocalDate date = LocalDate.parse(dateString, DateTimeFormatter.ofPattern(DATE_FORMAT));
        if (date != null) {
            this.prepareDate(date);
        }
        return String.format("Number of file in directory %s is %d", dateString, this.storageProvider.fileCount(date));
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#taskName()
     */
    @Override
    public String taskName() {
        return "prepare-workspace";
    }

}
