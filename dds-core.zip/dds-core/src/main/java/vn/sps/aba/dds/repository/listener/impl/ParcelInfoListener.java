/*
 * Class: CacheCollectionsListener
 *
 * Created on May 5, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.listener.impl;

import org.infinispan.notifications.cachelistener.annotation.CacheEntryCreated;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryExpired;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryModified;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryRemoved;
import org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryExpiredEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import net.logstash.logback.marker.Markers;
import vn.sps.aba.dds.common.constant.Enumeration;
import vn.sps.aba.dds.common.model.dmc.DMCCode;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.repository.entity.parcel.BarcodeEntity;
import vn.sps.aba.dds.repository.entity.parcel.ParcelInfoEntity;
import vn.sps.aba.dds.repository.jpa.IParcelInfoRepository;
import vn.sps.aba.dds.repository.listener.ICacheListener;

/**
 * The listener interface for receiving cacheCollections events. The class that
 * is interested in processing a cacheCollections event implements this
 * interface, and the object created with that class is registered with a
 * component using the component's <code>addCacheCollectionsListener <code>
 * method. When the cacheCollections event occurs, that object's appropriate
 * method is invoked.
 *
 * @see CacheCollectionsEvent
 */
//@Profile(value = { Profiles.PARCEL })
//@Component
//@Listener(sync = false, primaryOnly = true, clustered = false, includeCurrentState = false, observation = Observation.POST)
public class ParcelInfoListener extends AbstractCacheListener<String, ParcelInfo> implements ICacheListener<String, ParcelInfo> {

    /**
     * The LOG.
     */
    private static final Logger LOG = LoggerFactory.getLogger(ParcelInfoListener.class);

    /**
     * The parcel info repository.
     */
    @Autowired
    private IParcelInfoRepository parcelInfoRepository;

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.repository.listener.ICacheListener#add(org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent)
     */
    @Override
    @CacheEntryCreated
    public void add(final CacheEntryCreatedEvent<String, ParcelInfo> event) {

        try {
            if (this.isValidAddedEvent(event)) {
                final ParcelInfo parcelInfo = event.getValue();

                LOG.info(Markers.appendFields(parcelInfo), "ParcelInfo added");

                final ParcelInfoEntity parcelInfoEntity = new ParcelInfoEntity(parcelInfo);
                this.parcelInfoRepository.save(parcelInfoEntity);

            }
        }
        catch (final Exception ex) {

            LOG.error("There is error while persisting parcel data", ex);
        }
    }

    /**
     * Creates the the barcode data.
     *
     * @param parcelInfoEntity the parcel info entity
     * @param parcelInfo the parcel info
     */
    private void createTheBarcodeData(final ParcelInfoEntity parcelInfoEntity, final ParcelInfo parcelInfo) {
        if ((parcelInfo.getDmcCode() != null) && (Enumeration.DmcState.DMC_SENT.name().equalsIgnoreCase(parcelInfoEntity.getDmcState()))) {
            for (final DMCCode barcode : parcelInfo.getDmcCode().getDmcCodes()) {

                final BarcodeEntity barcodeEntity = new BarcodeEntity();

                barcodeEntity.setParcelInfo(parcelInfoEntity);
                barcodeEntity.setCode(barcode.getContent());

                if (barcode.getFormat() != null) {
                    barcodeEntity.setType(barcode.getFormat().getType());
                    barcodeEntity.setFormat(barcode.getFormat().toString());
                }

                parcelInfoEntity.getBarcodes().add(barcodeEntity);
            }
        }
    }

    /**
     * Expired.
     *
     * @param event the event
     */
    @CacheEntryExpired
    public void expired(final CacheEntryExpiredEvent<String, ParcelInfo> event) {
        try {
            final ParcelInfo parcelInfo = event.getValue();
            if (parcelInfo != null) {

                LOG.info(Markers.appendFields(parcelInfo), "ParcelInfo expired");

                //                final ParcelInfoEntity parcelInfoEntity = new ParcelInfoEntity(parcelInfo);
                //                this.parcelInfoRepository.save(parcelInfoEntity);
            }
        }
        catch (final Exception ex) {

            LOG.error("There is error while persisting parcel data", ex);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.repository.listener.ICacheListener#modify(org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent)
     */
    @Override
    @CacheEntryModified
    public void modify(final CacheEntryModifiedEvent<String, ParcelInfo> event) {
        try {
            if (this.isValidModifiedEvent(event)) {
                final ParcelInfo parcelInfo = event.getValue();
                LOG.info(Markers.appendFields(parcelInfo), "ParcelInfo modified");

                ParcelInfoEntity parcelInfoEntity = this.parcelInfoRepository.findOne(parcelInfo.getKey());

                if (parcelInfoEntity != null) {

                    parcelInfoEntity.setState(parcelInfo.getState());
                    parcelInfoEntity.setStatusCode(parcelInfo.getStatusCode());
                    parcelInfoEntity.setReceivedTime(DateUtil.milliTime2Timestamp(parcelInfo.getReceived()));
                    parcelInfoEntity.setFilteredByRule(parcelInfo.getFilteredByRule());

                    // PADASA BarcodeService
                    parcelInfoEntity.setBarcodeDataBegin(DateUtil.milliTime2Timestamp(parcelInfo.getBarcodeBegin()));
                    parcelInfoEntity.setBarcodeDataEnd(DateUtil.milliTime2Timestamp(parcelInfo.getBarcodeEnd()));

                    // VAM CaptureResultService
                    parcelInfoEntity.setCaptureResultBegin(DateUtil.milliTime2Timestamp(parcelInfo.getCaptureResultBegin()));
                    parcelInfoEntity.setCaptureResultEnd(DateUtil.milliTime2Timestamp(parcelInfo.getCaptureResultEnd()));

                    // BlackBox CaptureRerequestService
                    parcelInfoEntity.setBlackboxBegin(DateUtil.milliTime2Timestamp(parcelInfo.getBlackboxBegin()));
                    parcelInfoEntity.setBlackboxEnd(DateUtil.milliTime2Timestamp(parcelInfo.getBlackboxEnd()));

                    // DMC
                    parcelInfoEntity.setDmcBegin(DateUtil.milliTime2Timestamp(parcelInfo.getDmcBegin()));
                    parcelInfoEntity.setDmcEnd(DateUtil.milliTime2Timestamp(parcelInfo.getDmcEnd()));

                    parcelInfoEntity.setStoredImageTime(DateUtil.milliTime2Timestamp(parcelInfo.getStoredImageTime()));
                    parcelInfoEntity.setStoredDataTime(DateUtil.milliTime2Timestamp(parcelInfo.getStoredDataTime()));

                    parcelInfoEntity.setStartProcessingTime(DateUtil.milliTime2Timestamp(parcelInfo.getProcessBegin()));
                    parcelInfoEntity.setFinishedProcessingTime(DateUtil.milliTime2Timestamp(parcelInfo.getProcessEnd()));

                    parcelInfoEntity.setLookUpStartTime(DateUtil.milliTime2Timestamp(parcelInfo.getLookupBegin()));
                    parcelInfoEntity.setLookUpDoneTime(DateUtil.milliTime2Timestamp(parcelInfo.getLookupEnd()));

                    this.createTheBarcodeData(parcelInfoEntity, parcelInfo);
                    parcelInfoEntity.setDmcState(parcelInfo.getDmcState().name());
                }
                else {
                    parcelInfoEntity = new ParcelInfoEntity(parcelInfo);
                    this.parcelInfoRepository.save(parcelInfoEntity);
                }
            }
        }
        catch (final Exception ex) {
            LOG.error("There is error while persisting parcel data", ex);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.repository.listener.ICacheListener#remove(org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent)
     */
    @Override
    @CacheEntryRemoved
    public void remove(final CacheEntryRemovedEvent<String, ParcelInfo> event) {
        LOG.info(Markers.appendFields(event.getValue()), "ParcelInfo removed");
    }

}
