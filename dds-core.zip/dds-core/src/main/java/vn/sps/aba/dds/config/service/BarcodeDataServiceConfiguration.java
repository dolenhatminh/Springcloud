/*
 * Class: BarcodeDataServiceConfiguration
 *
 * Created on Jun 30, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.DDSConstant.Namespace;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.ObjectFactory;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.reponsecode.ICommonResponseCode;

/**
 * The Class BarcodeDataServiceConfiguration.
 */
@Configuration("BarcodeDataServiceConfiguration")
@ConfigurationProperties(prefix = "ws.padasa.barcodedata")
@Profile(value = { Profiles.PARCEL })
public class BarcodeDataServiceConfiguration extends AbstractSoapWsConfiguration implements ICommonResponseCode {

    /**
     * The Enum ResponseCode.
     */
    private enum ResponseCode {

        /** The Failed to store data. */
        FailedToStoreData,
        /** The Invalid data. */
        InvalidData,
        /** The Service available. */
        ServiceAvailable,
        /** The Successful. */
        Successful,
        /** The Unexpected error. */
        UnexpectedError
    }

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(BarcodeDataServiceConfiguration.class);

    /** The Constant SOUCE. */
    private static final String SOUCE = DDSConstant.Source.E134;

    /** The acs time stamp format. */
    private String acsTimeStampFormat;

    /** The coding date format. */
    private String codingDateFormat;

    /** The coding sites. */
    private final Map<String, String> codingSites = new HashMap<>();

    /** The header version. */
    private String headerVersion;

    /** The message id format. */
    private String messageIdFormat;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#failedToStoreData()
     */
    @Override
    public Response failedToStoreData() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.FailedToStoreData.name());
    }

    /**
     * Gets the acs time stamp format.
     *
     * @return the acs time stamp format
     */
    public String getAcsTimeStampFormat() {
        return this.acsTimeStampFormat;
    }

    /**
     * Gets the coding date format.
     *
     * @return the coding date format
     */
    public String getCodingDateFormat() {
        return this.codingDateFormat;
    }

    /**
     * Gets the coding sites.
     *
     * @return the coding sites
     */
    public Map<String, String> getCodingSites() {
        return this.codingSites;
    }

    /**
     * Gets the header version.
     *
     * @return the header version
     */
    public String getHeaderVersion() {
        return this.headerVersion;
    }

    /**
     * Gets the message id format.
     *
     * @return the message id format
     */
    public String getMessageIdFormat() {
        return this.messageIdFormat;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getNamespaceURI()
     */
    @Override
    public String getNamespaceURI() {
        return Namespace.E134_NAMESPACE;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getObjectFactory()
     */
    @Override
    public ObjectFactory getObjectFactory() {
        return (ObjectFactory) super.getObjectFactory();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getServiceName()
     */
    @Override
    public String getServiceName() {
        return "PADASA Barcode";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#initialize()
     */
    @Override
    @PostConstruct
    public void initialize() throws Exception {
        super.initialize();
        LOG.info(StringUtil.printMap("CodingSites", this.codingSites));
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#invalidData()
     */
    @Override
    public Response invalidData() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.InvalidData.name());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#serviceAvailable()
     */
    @Override
    public Response serviceAvailable() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.ServiceAvailable.name());
    }

    /**
     * Sets the acs time stamp format.
     *
     * @param acsTimeStampFormat
     *            the new acs time stamp format
     */
    public void setAcsTimeStampFormat(final String acsTimeStampFormat) {
        this.acsTimeStampFormat = acsTimeStampFormat;
    }

    /**
     * Sets the coding date format.
     *
     * @param codingDateFormat
     *            the new coding date format
     */
    public void setCodingDateFormat(final String codingDateFormat) {
        this.codingDateFormat = codingDateFormat;
    }

    /**
     * Sets the header version.
     *
     * @param headerVersion the new header version
     */
    public void setHeaderVersion(final String headerVersion) {
        this.headerVersion = headerVersion;
    }

    /**
     * Sets the message id format.
     *
     * @param messageIdFormat the new message id format
     */
    public void setMessageIdFormat(final String messageIdFormat) {
        this.messageIdFormat = messageIdFormat;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#successful()
     */
    @Override
    public Response successful() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.Successful.name());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#unexpectedError()
     */
    @Override
    public Response unexpectedError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.UnexpectedError.name());
    }

}
