/*
 * Class: ICacheQuery
 *
 * Created on Jun 22, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.query;

import java.util.List;

import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.types.statistic.Status;

/**
 * The Interface ICacheQuery.
 *
 * @param <T> the generic type
 */
public interface ICacheQuery<T extends IdentifiedEntry> {

    /**
     * Count state.
     *
     * @param states the states
     * @param fromTime the from time
     * @param toTime the to time
     * @return the list
     */
    void countState(final List<Status> states, final long fromTime, final long toTime);

    /**
     * Count status.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @return the list
     */
    List<Status> countStatus(final long fromTime, final long toTime);

    /**
     * List.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @param state the state
     * @param minorState the minor state
     * @param maxResult the max result
     * @return the list
     */
    List<T> list(final long fromTime, final long toTime, String state, String minorState, int maxResult);

    /**
     * List.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @param state the state
     * @param minorState the minor state
     * @param maxResult the max result
     * @param processed the processed
     * @return the list
     */
    List<T> list(final long fromTime, final long toTime, String state, String minorState, int maxResult, boolean processed);

    /**
     * List by ident code.
     *
     * @param identCode the ident code
     * @return the list
     */
    List<T> listByIdentCode(String identCode);
}
