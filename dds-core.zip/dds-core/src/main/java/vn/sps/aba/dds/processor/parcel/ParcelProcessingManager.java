/*
 * Class: ParcelDataController
 *
 * Created on Jun 20, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.parcel;

import java.util.concurrent.Future;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.ifa.TaskWatcher;
import vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.config.filtering.IMatchingConfig;
import vn.sps.aba.dds.config.filtering.impl.FilteringRuleConfiguration;
import vn.sps.aba.dds.config.service.interfaces.IParcelInfoServiceConfiguration;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.processor.ParcelProcessingExecutor;
import vn.sps.aba.dds.processor.parcel.filtering.IParcelInfoFilterer;
import vn.sps.aba.dds.repository.cache.interfaces.IParcelInfoCacheDao;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;
import vn.sps.aba.dds.sender.parcel.BlackboxSendingHandler;
import vn.sps.aba.dds.sender.parcel.interfaces.IDmcSender;
import vn.sps.aba.dds.sender.parcel.interfaces.IParcel2VamSender;
import vn.sps.aba.dds.service.lookup.asdp.IAsdpLookupService;

/**
 * The Class ParcelDataController.
 */
@Profile(Profiles.PARCEL)
@Component("ParcelProcessingManager")
public class ParcelProcessingManager extends AbstractAsyncWorker implements TaskWatcher {

    /** The asdp lookup service. */
    @Autowired
    private IAsdpLookupService asdpLookupService;

    /** The black box sender. */
    @Autowired
    private BlackboxSendingHandler blackBoxSender;

    /** The context. */
    private ParcelProcessingContext context;

    /** The dmc sender. */
    @Autowired
    private IDmcSender dmcSender;

    /** The filter rules. */
    @Autowired
    private FilteringRuleConfiguration filterRuleConfiguration;

    /** The parcel info data access object. */
    @Autowired
    private IParcelInfoCacheDao parcelInfoDao;

    /** The parcel info service configuration. */
    @Autowired
    private IParcelInfoServiceConfiguration parcelInfoServiceConfiguration;

    /** The filtering thread pool configuration. */
    @Autowired
    private ParcelProcessingExecutor parcelProcessingExecutor;

    /** The receiver info dpm dao. */
    @Autowired
    private IReceiverInfoCacheDao receiverInfoDpmDao;

    /** The vam sending handler. */
    @Autowired
    private IParcel2VamSender vamSender;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.TaskWatcher#cleanFinishedTasks()
     */
    @Override
    public int cleanFinishedTasks(final boolean force) {
        return this.watcher.cleanFinishedTasks(force);
    }

    /**
     * Gets the asdp lookup service.
     *
     * @return Returns the asdpLookupService.
     */
    IAsdpLookupService getAsdpLookupService() {
        return this.asdpLookupService;
    }

    /**
     * Gets the black box sender.
     *
     * @return the black box sender
     */
    BlackboxSendingHandler getBlackBoxSender() {
        return this.blackBoxSender;
    }

    /**
     * Gets the dmc sender.
     *
     * @return the dmc sender
     */
    IDmcSender getDmcSender() {
        return this.dmcSender;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected TaskConfiguration getExecutor() {
        return this.parcelProcessingExecutor;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.ImmortalCollector#getNumberWatchingTask()
     */
    @Override
    public int getNumberWatchingTask() {
        return this.watcher.getNumberWatchingTask();
    }

    /**
     * Gets the parcel info data access object.
     *
     * @return Returns the parcelInfoDao.
     */
    IParcelInfoCacheDao getParcelInfoDao() {
        return this.parcelInfoDao;
    }

    /**
     * Gets the parcel info filterer.
     *
     * @return Returns the parcelInfoFilterer.
     */
    IParcelInfoFilterer getParcelInfoFilterer() {
        return this.filterRuleConfiguration.getParcelInfoFilterer();
    }

    /**
     * Gets the parcel info service configuration.
     *
     * @return the parcel info service configuration
     */
    IParcelInfoServiceConfiguration getParcelInfoServiceConfiguration() {
        return this.parcelInfoServiceConfiguration;
    }

    /**
     * Gets the receiver info dpm dao.
     *
     * @return the receiver info dpm dao
     */
    IReceiverInfoCacheDao getReceiverInfoDpmDao() {
        return this.receiverInfoDpmDao;
    }

    /**
     * Gets the rule loader.
     *
     * @return Returns the ruleLoader.
     */
    IMatchingConfig getRuleLoader() {
        return this.filterRuleConfiguration;
    }

    /**
     * Gets the vam sender.
     *
     * @return the vam sender
     */
    IParcel2VamSender getVamSender() {
        return this.vamSender;
    }

    /**
     * Initialize.
     */
    @PostConstruct
    protected void initialize() {
        this.context = new ParcelProcessingContext(this);
    }

    /**
     * Submit.
     *
     * @param parcelInfo the parcel info
     */
    public void submit(final ParcelInfo parcelInfo) {

        final String key = parcelInfo.getKey();

        final Future<?> worker = this.parcelProcessingExecutor.getAsyncExecutor().submit(() -> {
            try {
                this.context.handle(parcelInfo);
            }
            finally {
                this.watcher.unWatch(key);
            }
        });

        this.watcher.watch(key, worker);
    }
}
