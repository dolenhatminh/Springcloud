/*
 * Class: IEntireCacheEntries
 *
 * Created on Nov 30, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.controller.interfaces;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import vn.sps.aba.dds.common.model.cache.IDDSCacheEntry;

/**
 * The Interface INoVisibleEntries.
 */
public interface INoVisibleEntries {

    /**
     * List all no visible enitries.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @param size the size
     * @return the list
     */
    @RequestMapping(value = "/nov/list-all", method = RequestMethod.GET)
    List<IDDSCacheEntry> listAllNoVisibleEnitries(LocalDateTime fromTime, LocalDateTime toTime, int size);

    /**
     * List by ident code.
     *
     * @param identCode the ident code
     * @param size the size
     * @return the list
     */
    @RequestMapping(value = "/nov/list-by-identcode", method = RequestMethod.GET)
    List<IDDSCacheEntry> listByIdentCodeNoVisibleEnitries(String identCode, int size);

    /**
     * List by key.
     *
     * @param key the key
     * @return the list
     */
    @RequestMapping(value = "/nov/list-by-key", method = RequestMethod.GET)
    IDDSCacheEntry listByKeyNoVisibleEnitries(String key);

    /**
     * List by state.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @param state the state
     * @param size the size
     * @return the list
     */
    @RequestMapping(value = "/nov/list-by-state", method = RequestMethod.GET)
    List<IDDSCacheEntry> listByStateNoVisibleEnitries(LocalDateTime fromTime, LocalDateTime toTime, String state, int size);
}
