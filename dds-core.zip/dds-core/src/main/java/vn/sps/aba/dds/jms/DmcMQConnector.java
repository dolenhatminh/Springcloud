/*
 * Class: DmcMQConnector
 *
 * Created on Nov 9, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.jms;

import javax.jms.ConnectionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.MessageType;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.model.dmc.DMCRequest;
import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.receiver.dmc.IDmcReceiver;

/**
 * The Class DmcMQConnector.
 */
@Component
@EnableJms
@ConditionalOnProperty(name = "dmc.activemq", havingValue = "true")
public class DmcMQConnector implements IDmcMQConnector {

    /** The dmc receiver. */
    @Autowired
    private IDmcReceiver dmcReceiver;

    /** The template. */
    @Autowired
    private JmsTemplate template;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jms.IDmcMQConnector#consume(vn.sps.aba.dds.common.model.dmc.DMCResponse)
     */
    @Override
    @JmsListener(destination = "${dmc.response.queue}", containerFactory = "jmsListenerFactory")
    public void consume(final DMCResponse response) {
        this.dmcReceiver.receive(response);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jms.IDmcMQConnector#consume(java.lang.String)
     */
    @Override
    public DMCResponse consume(final String dmcMsgQueueName) {
        DMCResponse ret = null;

        final Object msg = this.template.receiveAndConvert(dmcMsgQueueName);
        if (msg instanceof DMCResponse) {
            ret = (DMCResponse) msg;
            this.dmcReceiver.receive(ret);
        }

        return ret;
    }

    /**
     * Jackson jms message converter.
     *
     * @return the message converter
     */
    @Bean
    public MessageConverter jacksonJmsMessageConverter() {
        final MappingJackson2MessageConverter converter = new MappingJackson2MessageConverter();
        converter.setTargetType(MessageType.TEXT);
        converter.setTypeIdPropertyName("_type");
        return converter;
    }

    /**
     * Jms listener factory.
     *
     * @param connectionFactory the connection factory
     * @param configurer the configurer
     * @return the jms listener container factory
     */
    @Bean
    public JmsListenerContainerFactory<?> jmsListenerFactory(
        final ConnectionFactory connectionFactory,
        final DefaultJmsListenerContainerFactoryConfigurer configurer) {
        final DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        configurer.configure(factory, connectionFactory);
        return factory;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jms.IDmcMQConnector#send(vn.sps.aba.dds.common.model.dmc.DMCRequest)
     */
    @Override
    public void send(final DMCRequest request) {
        this.send(request, Constant.QUEUE_DMC_PROCESS_REQUEST);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jms.IDmcMQConnector#send(vn.sps.aba.dds.common.model.dmc.DMCRequest, java.lang.String)
     */
    @Override
    public void send(final DMCRequest request, final String dmcMsgQueueName) {
        this.template.convertAndSend(dmcMsgQueueName, request);
    }
}
