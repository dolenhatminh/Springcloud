/*
 * Class: TaskReceiverInfoRecepton
 *
 * Created on Aug 1, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.task.validator;

import java.util.concurrent.ForkJoinPool;

import javax.annotation.PostConstruct;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;

/**
 * The Class TaskReceiverInfoRecepton.
 */
@Profile(value = { Profiles.DPMB })
@Configuration("TaskReceiverInfoRecepton")
@ConfigurationProperties(prefix = "task.receiver.reception")
public class TaskReceiverInfoRecepton {

    /** The parallelism. */
    private int parallelism;

    /** The validator pool. */
    private ForkJoinPool validatorPool;

    /**
     * Gets the parallelism.
     *
     * @return the parallelism
     */
    public int getParallelism() {
        return this.parallelism;
    }

    /**
     * Gets the validator pool.
     *
     * @return the validator pool
     */
    public ForkJoinPool getValidatorPool() {
        return this.validatorPool;
    }

    /**
     * Initialize.
     */
    @PostConstruct
    public void initialize() {
        this.validatorPool = new ForkJoinPool(this.getParallelism());
    }

    /**
     * Sets the parallelism.
     *
     * @param parallelism the new parallelism
     */
    public void setParallelism(final int parallelism) {
        this.parallelism = parallelism;
    }
}
