/*
 * Class: IParcelInfoDao
 *
 * Created on Jun 16, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.cache.interfaces;

import java.util.List;

import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.repository.query.ICacheQuery;
import vn.sps.aba.dds.repository.query.IDataContainerEntries;

/**
 * The Interface IParcelInfoDao.
 */
public interface IParcelInfoCacheDao extends ICacheCommonCacheDao<String, ParcelInfo>, ICacheQuery<ParcelInfo>, IDataContainerEntries {

    /**
     * Gets the ident code after time.
     *
     * @param identCode
     *            the ident code
     * @param sinceTime
     *            the time
     * @return the ident code after time
     */
    List<ParcelInfo> getIdentCodeAfterTime(String identCode, long sinceTime);

    /**
     * List parcel entry based on their status.
     *
     * @param status
     *            the status
     * @return the list
     */
    List<ParcelInfo> listParcelMarked(String status);

    /**
     * Store dmc code.
     *
     * @param parcelInfo the parcel info
     */
    void storeDmcCode(final ParcelInfo parcelInfo);
}
