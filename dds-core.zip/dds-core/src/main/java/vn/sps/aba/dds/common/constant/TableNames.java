package vn.sps.aba.dds.common.constant;

/**
 * The Class TableNames.
 */
public final class TableNames {

    /** The Constant PAR_BARCODE. */
    public static final String PAR_BARCODE = "par_barcode";

    /** The Constant PAR_FULL_ADDRESS. */
    public static final String PAR_FULL_ADDRESS = "par_full_address";

    /** The Constant PAR_PARCEL_INFO. */
    public static final String PAR_PARCEL_INFO = "par_parcel_info";

    /** The Constant REC_ADDRESS_FIELDS. */
    public static final String REC_ADDRESS_FIELDS = "rec_address_fields";

    /** The Constant REC_CAPTURE_INFO. */
    public static final String REC_CAPTURE_INFO = "rec_capture_info";

    /** The Constant REC_PARCEL_DATA. */
    public static final String REC_PARCEL_DATA = "rec_parcel_data";

    /** The Constant REC_RECEIVER_INFO. */
    public static final String REC_RECEIVER_INFO = "rec_receiver_info";

    /** The Constant REC_VOLLE_ADDRESS. */
    public static final String REC_VOLLE_ADDRESS = "rec_volle_address";

    /**
     * Instantiates a new table names.
     */
    private TableNames() {
    }
}
