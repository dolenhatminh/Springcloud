/*
 * Class: ParcelInfoServiceAdapter
 *
 * Created on May 16, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.pds.parcel;

import java.io.File;
import java.time.LocalDate;

import javax.xml.bind.JAXBElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.pds.parcel.model.TransferParcelInfo;
import vn.sps.aba.dds.common.types.ws.pds.parcel.model.TransferParcelInfoIn;
import vn.sps.aba.dds.common.types.ws.pds.parcel.model.TransferParcelInfoResponse;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.common.util.FileUtil;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.service.ParcelInfoServiceConfiguration;
import vn.sps.aba.dds.io.IImageStorageProvider;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.logging.report.ParcelContent;
import vn.sps.aba.dds.processor.parcel.ParcelProcessingManager;
import vn.sps.aba.dds.repository.cache.interfaces.IParcelInfoCacheDao;
import vn.sps.aba.dds.service.validation.parcel.ParcelValidatingInfo;

/**
 * The Class ParcelInfoServiceAdapter.
 */
@Profile(Profiles.PARCEL)
@Endpoint
public class ParcelInfoServiceEndpoint {

    /**
     * The Enum ImageStoreId.
     */
    private enum ImageStoreId {

        /** The failed. */
        FAILED,
        /** The invalid. */
        INVALID,
        /** The success. */
        SUCCESS;
    }

    /**
     * The Class ImageInfo.
     */
    private class StoreImageInfo implements IImageInfo {

        /** The directory. */
        String directory;

        /** The file name. */
        String fileName;

        /** The order. */
        int order;

        /**  0: success, 1: customer sent empty base64, 2: store failed. */
        ImageStoreId resultId = ImageStoreId.SUCCESS;

        /**
         * {@inheritDoc}
         *
         * @see vn.sps.aba.dds.service.pds.parcel.IImageInfo#setDirectory(java.lang.String)
         */
        @Override
        public void setDirectory(final String directory) {
            this.directory = directory;
        }

        /**
         * {@inheritDoc}
         *
         * @see vn.sps.aba.dds.service.pds.parcel.IImageInfo#setFileName(java.lang.String)
         */
        @Override
        public void setFileName(final String fileName) {
            this.fileName = fileName;
        }

        /**
         * {@inheritDoc}
         *
         * @see vn.sps.aba.dds.service.pds.parcel.IImageInfo#setOrder(int)
         */
        @Override
        public void setOrder(final int order) {
            this.order = order;
        }

    }

    /** The Constant FIELD_PARCEL_CONTENT. */
    private static final String FIELD_PARCEL_CONTENT = "parcelContent";

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ParcelInfoServiceEndpoint.class);

    /** The image dir provider. */
    @Autowired
    private IImageStorageProvider imageDirProvider;

    /** The parcel info data access object. */
    @Autowired
    private IParcelInfoCacheDao parcelInfoDao;

    /** The parcel data processor. */
    @Autowired
    private ParcelProcessingManager parcelProcessManager;

    /** The service configuration. */
    @Autowired
    private ParcelInfoServiceConfiguration serviceConfiguration;

    /**
     * Creates the parcel model.
     *
     * @param request the request
     * @param imageInfo the image info
     * @param validatingInfo the validating info
     * @return the  parcel info
     */
    private ParcelInfo createParcelModel(final TransferParcelInfoIn request, final StoreImageInfo imageInfo, final ParcelValidatingInfo validatingInfo) {

        ParcelInfo parcelInfo = null;

        try {
            parcelInfo = new ParcelInfo(request);
            {
                parcelInfo.setParcelOrder(imageInfo.order);
                parcelInfo.setKey(validatingInfo.getKey());
                parcelInfo.setReceived(validatingInfo.getReceived());
                parcelInfo.setStoredImageTime(validatingInfo.getStoredImageTime());
                switch (imageInfo.resultId) {
                case SUCCESS:
                    parcelInfo.setFileName(imageInfo.fileName);
                    parcelInfo.setFilePath(imageInfo.directory);
                    parcelInfo.setState(ParcelState.RECEIVED);
                    break;
                case INVALID:
                    // Note: in case the image byte array is null or empty, we just leave this as OK.
                    // Parcel with empty image byte array will be filtered by the filter rule later then
                    parcelInfo.setState(ParcelState.RECEIVED);
                    break;
                case FAILED:
                    parcelInfo.setState(ParcelState.REJECTED);
                    break;
                default:
                    break;
                }
            }
        }
        catch (final Exception e) {
            if (parcelInfo != null) {
                parcelInfo.setState(ParcelState.REJECTED);
            }
            LOG.error(IndexMaker.index(validatingInfo), "There is error when contruct the parcel model", e);
        }

        return parcelInfo;
    }

    /**
     * Store image.
     *
     * @param image the image
     * @param date the date
     * @param validatingInfo the validating info
     * @return the store image info
     */
    private StoreImageInfo storeImage(final byte[] image, final LocalDate date, final ParcelValidatingInfo validatingInfo) {

        final StoreImageInfo imageInfo = new StoreImageInfo();

        try {
            final boolean hasImage = (image != null) && (image.length > 0);
            if (hasImage) {
                final String fileName = StringUtil.buildTIFFileName(validatingInfo.getKey());
                imageInfo.setFileName(fileName);
                this.imageDirProvider.getFolder(date, imageInfo);

                FileUtil.writeByteArrayToFile(new File(imageInfo.directory + Constant.FILE_SEPARATOR + fileName), image);
            }
            else {
                imageInfo.resultId = ImageStoreId.INVALID;
            }
        }
        catch (final Exception e) {
            imageInfo.resultId = ImageStoreId.FAILED;
            LOG.error(IndexMaker.index(validatingInfo), "Failed to store image of parcel info to disk", e);
        }
        finally {
            validatingInfo.setStoredImageTime(DiscoWallClock.milli());
        }

        return imageInfo;
    }

    /**
     * Transfer parcel info. <br>
     * The function returns response with code equals:
     * <ul>
     * <li>0: If the function can store the image file and create the parcel
     * models and store the objects into cache successfully</li>
     * <li>1: If the request message has no ParcelInfo. This is just the testing
     * request</li>
     * <li>11: If there is any error while store image file, create the model or
     * caching the data</li>
     * </ul>
     *
     * @param transferParcelInfo
     *            the request
     * @return the transfer parcel info response
     */
    @PayloadRoot(namespace = DDSConstant.Namespace.E132_NAMESPACE, localPart = "TransferParcelInfo")
    public @ResponsePayload TransferParcelInfoResponse transferParcelInfo(@RequestPayload final TransferParcelInfo transferParcelInfo) {

        final long receivedTime = DiscoWallClock.milli();
        final LocalDate currentDate = DateUtil.currentDate(DiscoWallClock.zone());
        Response response = this.serviceConfiguration.successful();
        final ParcelValidatingInfo validatingInfo = new ParcelValidatingInfo();
        validatingInfo.setResponse(response);

        final JAXBElement<TransferParcelInfoIn> request = transferParcelInfo.getRequest();

        final boolean isDiagnosableRequest = (request == null) || (request.getValue() == null) || (request.getValue().getParcelInfo() == null);

        if (!isDiagnosableRequest) {

            final TransferParcelInfoIn requestItem = request.getValue();

            final vn.sps.aba.dds.common.types.ws.pds.parcel.model.ParcelInfo parcelData = requestItem.getParcelInfo();
            final String identCode = parcelData.getIdentcode();

            try {

                final String key = StringUtil.newUuidString();

                // TODO -- This should collect field storeImageBegin and storeDataBegin make the evidences for storing duration
                // This is hard to do because the database table's fields must be added
                
                validatingInfo.setKey(key);
                validatingInfo.setIdentCode(identCode);
                validatingInfo.setReceivedTime(receivedTime);
                // LOG.info(IndexMaker.index(validatingInfo), "Receive parcel info data");
                final StoreImageInfo imageInfo = this.storeImage(parcelData.getImage(), currentDate, validatingInfo);
                parcelData.setImage(null);
                ParcelInfo parcelInfo = this.createParcelModel(requestItem, imageInfo, validatingInfo);
                LOG.info(IndexMaker.indexes(key, identCode, new ParcelContent(requestItem, parcelInfo), FIELD_PARCEL_CONTENT), "Detail of the parcel. The image byte array was removed");

                if (parcelInfo == null) {
                    parcelInfo = new ParcelInfo();
                    parcelInfo.setIdentCode(identCode);
                    parcelInfo.setKey(key);
                    parcelInfo.setReceived(receivedTime);
                    parcelInfo.setStoredImageTime(validatingInfo.getStoredImageTime());
                    parcelInfo.setState(ParcelState.REJECTED);
                }

                if (ParcelState.RECEIVED == parcelInfo.getParcelState()) {

                    // Note: This will cause a bit latency, if you query data from database there are several parcel will not have the stored_data_time.
                    // This usually happens when the core business worker thread pool is full. The later incoming parcel will be queued up
                    // Even when he is processed, he is stored into cache gain.
                    // => This is because, i want to get exactly the time he is put into cache for the first time.

                    parcelInfo.setStatusCode(response.getCode());
                    this.parcelInfoDao.put(key, parcelInfo);
                    final long storedDataTime = DiscoWallClock.milli();
                    parcelInfo.setStoredDataTime(storedDataTime);
                    this.parcelProcessManager.submit(parcelInfo);
                    validatingInfo.setStoredDataTime(storedDataTime);
                }
                else {
                    response = this.serviceConfiguration.unexpectedError();
                    parcelInfo.setStatusCode(response.getCode());
                    // The invalid card will be ignored, so set storedDataTime at this point
                    final long storedDataTime = DiscoWallClock.milli();
                    parcelInfo.setStoredDataTime(storedDataTime);
                    validatingInfo.setStoredDataTime(storedDataTime);
                    this.parcelInfoDao.store(key, parcelInfo);
                }
            }
            catch (final Exception e) {
                response = this.serviceConfiguration.unexpectedError();
                LOG.info(IndexMaker.index(validatingInfo), "Error occured when store image and data of parcel", e);
            }
            finally {
                LOG.info(IndexMaker.indexes(validatingInfo), "Parcel validating info");
            }
        }
        else {
            response = this.serviceConfiguration.serviceAvailable();
            validatingInfo.setResponse(response);
            LOG.info(IndexMaker.indexes(validatingInfo), "Diagnosable request - Service available");
        }

        return MessageBuilder.buildParcelResponse(this.serviceConfiguration, validatingInfo);
    }
}
