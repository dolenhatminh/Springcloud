/*
 * Class: TaskWatcher
 * 
 * Created on Oct 11, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.ifa;

import java.util.concurrent.Future;

/**
 * The Interface TaskWatcher.
 */
public interface TaskWatcher {
    
    /**
     * Un watch.
     *
     * @param key the key
     * @return the future
     */
    Future<?> unWatch(final String key);
    
    /**
     * Checks if is done.
     *
     * @param key the key
     * @return true, if is done
     */
    boolean isDone(final String key);
}
