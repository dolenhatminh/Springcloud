/*
 * Class: AsdpPlzCacheDao
 *
 * Created on Oct 13, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.model.asdp.AsdpPlzz;
import vn.sps.aba.dds.config.cache.CacheAsdpPlzConfiguration;
import vn.sps.aba.dds.config.cache.CacheConfiguration;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.repository.cache.interfaces.IAsdpPlzCacheDao;
import vn.sps.aba.dds.repository.listener.ICacheListener;

/**
 * The Class AsdpPlzCacheDao.
 */
@Configuration
@Repository("AsdpPlzCacheDao")
public class AsdpPlzCacheDao extends AbstractCacheDao<String, AsdpPlzz> implements IAsdpPlzCacheDao {

    /** The cache configuration. */
    @Autowired
    private CacheAsdpPlzConfiguration cacheConfiguration;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.DdsCacheInfo#countEntriesWithMinorState(java.lang.String)
     */
    @Override
    public int countEntriesWithMinorState(final String minorState) {
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.DdsCacheInfo#countEntriesWithState(java.lang.String)
     */
    @Override
    public int countEntriesWithState(final String state) {
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.AbstractCacheDao#getCacheConfiguration()
     */
    @Override
    protected CacheConfiguration getCacheConfiguration() {
        return this.cacheConfiguration;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.AbstractCacheDao#getCacheName()
     */
    @Override
    public String getCacheName() {
        return DDSConstant.CacheName.CACHE_ASDP_PLZ;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.AbstractCacheDao#getClassType()
     */
    @Override
    protected Class<AsdpPlzz> getClassType() {
        return AsdpPlzz.class;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected TaskConfiguration getExecutor() {
        return new TaskConfiguration() {
        };
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.AbstractCacheDao#getListener()
     */
    @SuppressWarnings("rawtypes")
    @Override
    protected ICacheListener getListener() {
        return null;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.AbstractCacheDao#isListenable()
     */
    @Override
    protected boolean isListenable() {
        return false;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#put(java.lang.Object, java.io.Serializable)
     */
    @Override
    public AsdpPlzz put(final String key, final AsdpPlzz value) {
        return super.put(key, value, this.cacheConfiguration.getExpiredLifeSpan());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#store(java.lang.Object, java.io.Serializable)
     */
    @Override
    public AsdpPlzz store(final String key, final AsdpPlzz value) {
        return null;
    }
}
