/*
 * Class: StepForwardingHandler
 *
 * Created on Jul 11, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.receiver.handers;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext;

/**
 * The Class StepForwardingHandler.
 */
public class StepForwardingHandler extends AbstractReceiverStepHandler implements IReceiverStepHandler {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(StepForwardingHandler.class);

    /**
     * Instantiates a new step forwarding handler.
     */
    public StepForwardingHandler() {
        super(STEP_FORWARDING_HANDLER);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.receiver.handers.IReceiverStepHandler#handle(vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext, vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    public void handle(final IReceiverProcessingContext context, final ReceiverInfo receiverInfo) {
        LOG.info(IndexMaker.index(receiverInfo), "Submit receiver info to VAM sender and PADASA sender");
        context.getReceiverSendingExecutor().submit(() -> {
            try {
                ExecutorService pool = Executors.newFixedThreadPool(2);
                Future<Boolean> matchMakerTask = pool.submit(() -> {
                    if (context.transferToMatchMaker(receiverInfo)) {
                        LOG.info(IndexMaker.index(receiverInfo), "Forwarded receiver info to PADASA MatchMaker service station successfully");
                        return true;
                    }
                    else {
                        LOG.info(IndexMaker.index(receiverInfo), "Failed to forward ReceiverInfo to PADASA MatchMaker service !");
                    }
                    return false;
                });
                Future<Boolean> vamTask = pool.submit(() -> {
                    if (context.transferToVamStation(receiverInfo)) {
                        LOG.info(IndexMaker.index(receiverInfo), "Forwarded receiver info to VAM station successfully");
                        return true;
                    }
                    else {
                        LOG.info(IndexMaker.index(receiverInfo), "Failed to forward ReceiverInfo to VAM station.");
                    }
                    return false;
                });
                pool.shutdown();
                ReceiverState state = receiverInfo.getReceiverState();
                Boolean matchMakerResult = matchMakerTask.get();
                Boolean vamResult = vamTask.get();
                if (matchMakerResult && vamResult) {
                    state = ReceiverState.VAM_PADASA_SENT;
                }
                else if (matchMakerResult) {
                    state = ReceiverState.PADASA_SENT;
                }
                else if (vamResult) {
                    state = ReceiverState.VAM_SENT;
                }
                receiverInfo.setState(state);
                context.updateReceiverInfo(receiverInfo);
            }
            catch (InterruptedException | ExecutionException e) {
                LOG.error(IndexMaker.indexes(receiverInfo), "Error while forward data to VAM and PADASA", e);
            }
        });
    }
}
