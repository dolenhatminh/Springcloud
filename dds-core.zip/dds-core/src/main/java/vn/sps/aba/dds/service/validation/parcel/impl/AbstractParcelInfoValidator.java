/*
 * Class: ParcelInfoGenericValidator
 *
 * Created on Jun 14, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.parcel.impl;

import vn.sps.aba.dds.common.types.ws.pds.parcel.model.ParcelInfo;
import vn.sps.aba.dds.service.validation.AbstractGenericValidator;
import vn.sps.aba.dds.service.validation.model.ParcelInfoValidationResult;
import vn.sps.aba.dds.service.validation.parcel.IParcelInfoValidator;

/**
 * The Class ParcelInfoGenericValidator.
 */
abstract class AbstractParcelInfoValidator extends AbstractGenericValidator<ParcelInfo, ParcelInfoValidationResult> implements IParcelInfoValidator {

    /**
     * Constructs a new <tt>ParcelInfoGenericValidator</tt>.
     */
    public AbstractParcelInfoValidator() {
        super(ParcelInfoValidationResult.class);
    }

}
