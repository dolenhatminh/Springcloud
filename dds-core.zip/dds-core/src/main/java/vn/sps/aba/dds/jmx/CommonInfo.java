/*
 * Class: CommonInfo
 *
 * Created on Oct 24, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.jmx;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

/**
 * The Interface CommonInfo.
 */
@ManagedResource
public interface CommonInfo {

    /**
     * Gets the application url.
     *
     * @return the application url
     */
    @ManagedAttribute
    String getApplicationUrl();

    /**
     * Gets the image dir format.
     *
     * @return the image dir format
     */
    @ManagedAttribute
    String getImageDirFormat();

    /**
     * Gets the image per folder.
     *
     * @return the image per folder
     */
    @ManagedAttribute
    int getImagePerFolder();

    /**
     * Gets the shared storage.
     *
     * @return the shared storage
     */
    @ManagedAttribute
    String getSharedStorage();

    /**
     * Gets the time zone.
     *
     * @return the time zone
     */
    @ManagedAttribute
    String getTimeZone();
}
