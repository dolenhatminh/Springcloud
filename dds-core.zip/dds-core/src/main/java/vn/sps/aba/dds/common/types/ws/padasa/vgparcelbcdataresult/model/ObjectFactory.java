
package vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the vn.sps.aba.dds.service.padasa.vgparcelbcdataresult.model package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _JavaException_QNAME = new QName("urn:stc:egate:jce:JavaException", "JavaException");
    private final static QName _VGParcelBCData_QNAME = new QName("http://www.post.ch/esb/PdsWSTypes", "VGParcelBCData");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: vn.sps.aba.dds.service.padasa.vgparcelbcdataresult.model
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link JavaExceptionType }
     * 
     */
    public JavaExceptionType createJavaExceptionType() {
        return new JavaExceptionType();
    }

    /**
     * Create an instance of {@link MsgParcelBCData }
     * 
     */
    public MsgParcelBCData createMsgParcelBCData() {
        return new MsgParcelBCData();
    }

    /**
     * Create an instance of {@link VGParcelBCDataResult }
     * 
     */
    public VGParcelBCDataResult createVGParcelBCDataResult() {
        return new VGParcelBCDataResult();
    }

    /**
     * Create an instance of {@link CodingKey }
     * 
     */
    public CodingKey createCodingKey() {
        return new CodingKey();
    }

    /**
     * Create an instance of {@link AcsKeyInfo }
     * 
     */
    public AcsKeyInfo createAcsKeyInfo() {
        return new AcsKeyInfo();
    }

    /**
     * Create an instance of {@link MsgHeader }
     * 
     */
    public MsgHeader createMsgHeader() {
        return new MsgHeader();
    }

    /**
     * Create an instance of {@link ParcelData }
     * 
     */
    public ParcelData createParcelData() {
        return new ParcelData();
    }

    /**
     * Create an instance of {@link BarCodeData }
     * 
     */
    public BarCodeData createBarCodeData() {
        return new BarCodeData();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link JavaExceptionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:stc:egate:jce:JavaException", name = "JavaException")
    public JAXBElement<JavaExceptionType> createJavaException(JavaExceptionType value) {
        return new JAXBElement<JavaExceptionType>(_JavaException_QNAME, JavaExceptionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsgParcelBCData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.post.ch/esb/PdsWSTypes", name = "VGParcelBCData")
    public JAXBElement<MsgParcelBCData> createVGParcelBCData(MsgParcelBCData value) {
        return new JAXBElement<MsgParcelBCData>(_VGParcelBCData_QNAME, MsgParcelBCData.class, null, value);
    }

}
