/*
 * Class: ICacheImporter
 *
 * Created on Sep 14, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.importing;

import vn.sps.aba.dds.common.types.report.ImportingResult;

/**
 * The Interface ICacheDataImporter.
 */
public interface ICacheDataImporter {

    /**
     * Import data.
     *
     * @param fromEpoch the from epoch
     * @param toEpoch the to epoch
     * @return the int
     */
    @Deprecated
    int importData(long fromEpoch, long toEpoch);

    /**
     * Load data.
     *
     * @param result the result
     */
    void loadData(ImportingResult result);

    /**
     * Load data by default value.
     *
     * @return the importing result
     */
    ImportingResult loadDataByDefaultValue();
}
