/*
 * Class: ScheduledSenderInfo
 *
 * Created on Oct 29, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.jmx;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

/**
 * The Interface ScheduledSenderInfo.
 */
@ManagedResource
public interface ScheduledSenderInfo {

    /**
     * Gets the max count.
     *
     * @return the max count
     */
    @ManagedAttribute
    int getMaxCount();

    /**
     * Gets the max for once.
     *
     * @return the max for once
     */
    @ManagedAttribute
    int getMaxForOnce();

    /**
     * Removes the item more than count.
     *
     * @param count the count
     */
    @ManagedOperation
    void removeItemMoreThanCount(int count);

    /**
     * Sets the max count.
     *
     * @param maxCount the new max count
     */
    @ManagedOperation
    void setMaxCount(final int maxCount);

    /**
     * Sets the max for once.
     *
     * @param maxForOnce the new max for once
     */
    @ManagedOperation
    void setMaxForOnce(final int maxForOnce);
}
