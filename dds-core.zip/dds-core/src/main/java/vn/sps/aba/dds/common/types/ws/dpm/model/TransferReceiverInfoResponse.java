
package vn.sps.aba.dds.common.types.ws.dpm.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ReceiverInfoResponse" type="{Ch.Post.PL.DisCo.ReceiverInfoService}ReceiverInfoResponseType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "receiverInfoResponse"
})
@XmlRootElement(name = "TransferReceiverInfoResponse")
public class TransferReceiverInfoResponse {

    @XmlElementRef(name = "ReceiverInfoResponse", namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<ReceiverInfoResponseType> receiverInfoResponse;

    /**
     * Gets the value of the receiverInfoResponse property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ReceiverInfoResponseType }{@code >}
     *     
     */
    public JAXBElement<ReceiverInfoResponseType> getReceiverInfoResponse() {
        return receiverInfoResponse;
    }

    /**
     * Sets the value of the receiverInfoResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ReceiverInfoResponseType }{@code >}
     *     
     */
    public void setReceiverInfoResponse(JAXBElement<ReceiverInfoResponseType> value) {
        this.receiverInfoResponse = value;
    }

}
