/*
 * Class: ParcelInfoListener
 *
 * Created on Sep 4, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.listener.impl09;

import java.time.LocalDate;

import org.infinispan.notifications.Listener;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryCreated;
import org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.transaction.TransactionException;

import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.model.dmc.DMCCode;
import vn.sps.aba.dds.common.model.dmc.DMCFormat;
import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.config.service.DmcServiceConfiguration;
import vn.sps.aba.dds.io.IImageStorageProvider;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.repository.cache.event.CacheEvent;
import vn.sps.aba.dds.repository.entity.parcel.BarcodeEntity;
import vn.sps.aba.dds.repository.entity.parcel.ParcelInfoEntity;
import vn.sps.aba.dds.repository.jpa.IParcelInfoRepository;
import vn.sps.aba.dds.repository.listener.ICacheListener;
import vn.sps.aba.dds.repository.listener.impl.AbstractCacheListener;

/**
 * The listener interface for receiving parcelInfo events. The class that is
 * interested in processing a parcelInfo event implements this interface, and
 * the object created with that class is registered with a component using the
 * component's <code>addParcelInfoListener<code> method. When
 * the parcelInfo event occurs, that object's appropriate
 * method is invoked.
 *
 * @see ParcelInfoEvent
 */
@Component("ParcelInfoListener")
@Profile(Profiles.PARCEL)
@Listener(sync = false, primaryOnly = true, clustered = true, includeCurrentState = false)
public class ParcelInfoListener extends AbstractCacheListener<String, ParcelInfo> implements ICacheListener<String, ParcelInfo> {

    /**
     * The Constant LOG.
     */
    private static final Logger LOG = LoggerFactory.getLogger(ParcelInfoListener.class);

    /**
     * The dmc configuration.
     */
    @Autowired
    private DmcServiceConfiguration dmcConfiguration;

    /**
     * The image provider.
     */
    @Autowired
    private IImageStorageProvider imageProvider;

    /**
     * The parcel info repository.
     */
    @Autowired
    private IParcelInfoRepository parcelInfoRepository;

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.repository.listener.ICacheListener#add(org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent)
     */
    @Override
    public void add(final CacheEntryCreatedEvent<String, ParcelInfo> event) {
        final ParcelInfo parcelInfo = event.getValue();

        try {

            if (parcelInfo != null) {
                final ParcelInfoEntity parcelInfoEntity = new ParcelInfoEntity(parcelInfo);
                this.parcelInfoRepository.save(parcelInfoEntity);
            }
        }
        catch (final TransactionException e) {
            throw e;
        }
        catch (final Exception ex) {
            LOG.error(IndexMaker.index(parcelInfo), "There is error while persisting parcel data", ex);
        }
    }

    /**
     * Creates the the DMC barcode data from DMC response.
     *
     * @param dmcCode the dmc code
     * @param parcelInfoEntity the parcel info entity
     */
    private void createDmcCodes(final DMCResponse dmcCode, final ParcelInfoEntity parcelInfoEntity) {
        if (dmcCode != null) {
            for (final DMCCode barcode : dmcCode.getDmcCodes()) {

                final BarcodeEntity barcodeEntity = new BarcodeEntity();

                barcodeEntity.setParcelInfo(parcelInfoEntity);
                barcodeEntity.setCode(barcode.getContent());

                final DMCFormat format = barcode.getFormat();
                if (format != null) {
                    barcodeEntity.setType(this.dmcConfiguration.getType());
                    barcodeEntity.setFormat(format.toString());
                }
                parcelInfoEntity.getBarcodes().add(barcodeEntity);
            }
        }

    }

    /**
     * {@inheritDoc}
     *
     * @throws Exception
     *
     * @see
     * vn.sps.aba.dds.repository.listener.ICacheListener#modify(org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent)
     */
    @Override
    public void modify(final CacheEntryModifiedEvent<String, ParcelInfo> event) throws TransactionException {

        final ParcelInfo parcelInfo = event.getValue();
        String key = null;
        try {

            if (parcelInfo != null) {

                long created = 0;
                long lifespan = 0;

                if (event instanceof CacheEvent) {
                    created = ((CacheEvent<String, ParcelInfo>) event).getCreated();
                    lifespan = ((CacheEvent<String, ParcelInfo>) event).getLifespan();
                }

                key = parcelInfo.getKey();
                ParcelInfoEntity parcelInfoEntity = this.parcelInfoRepository.findOne(key);
                if (parcelInfoEntity != null) {
                    final DMCResponse dmcCode = parcelInfo.getDmcCode();
                    if (parcelInfoEntity.getDmcEnd() == null) {
                        this.createDmcCodes(dmcCode, parcelInfoEntity);
                    }
                    parcelInfoEntity.updateInfo(parcelInfo);
                }
                else {
                    parcelInfoEntity = new ParcelInfoEntity(parcelInfo);
                    this.createDmcCodes(parcelInfo.getDmcCode(), parcelInfoEntity);
                }
                parcelInfoEntity.setCreated(created);
                parcelInfoEntity.setLifespan(lifespan);

                this.parcelInfoRepository.save(parcelInfoEntity);
                LOG.info(IndexMaker.index(parcelInfo), "Done persisting parcel info.");
            }
        }
        catch (final TransactionException e) {
            throw e;
        }
        catch (final Exception ex) {
            LOG.error(IndexMaker.index(parcelInfo), "There is error while persisting parcel data", ex);
        }
    }

    /**
     * New parcel.
     *
     * @param event the event
     */
    @CacheEntryCreated
    public void newParcel(final CacheEntryCreatedEvent<String, ParcelInfo> event) {
        try {
            LOG.info("There was a new parcel added");
            final ParcelInfo parcelInfo = event.getValue();
            if (parcelInfo != null) {
                final LocalDate localDate = DateUtil.milli2LocalDateTime(parcelInfo.getReceived()).toLocalDate();
                this.imageProvider.addFolder(localDate, parcelInfo.getParcelOrder());
            }
        }
        catch (final Exception e) {
            LOG.error("Failed to update image directory", e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.repository.listener.ICacheListener#remove(org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent)
     */
    @Override
    public void remove(final CacheEntryRemovedEvent<String, ParcelInfo> event) {

    }
}
