/*
 * Class: ParcelServiceConfiguration
 *
 * Created on Jun 15, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.wsdl.wsdl11.SimpleWsdl11Definition;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.pds.parcel.model.ObjectFactory;
import vn.sps.aba.dds.config.reponsecode.ICommonResponseCode;
import vn.sps.aba.dds.config.service.interfaces.IParcelInfoServiceConfiguration;
import vn.sps.aba.dds.service.interceptor.logging.DDSLoggingInterceptor;
import vn.sps.aba.dds.service.interceptor.parcel.ParcelInfoInterceptor;

/**
 * The Class ParcelServiceConfiguration.
 */
@Profile(Profiles.PARCEL)
@Configuration("ParcelInfoServiceConfiguration")
@ConfigurationProperties(prefix = "ws.parcel")
public class ParcelInfoServiceConfiguration extends AbstractSoapWsConfiguration implements ICommonResponseCode, IParcelInfoServiceConfiguration {

    /**
     * The Enum ResponseCode.
     */
    private enum ResponseCode implements IParcelInfoServiceConfiguration {

        /**
         * The Failed to store data.
         */
        FailedToStoreData,
        /**
         * The Invalid data.
         */
        InvalidData,
        /**
         * The Service available.
         */
        ServiceAvailable,
        /**
         * The Successful.
         */
        Successful,
        /**
         * The Unexpected error.
         */
        UnexpectedError;

        /**
         * {@inheritDoc}
         *
         * @see
         * vn.sps.aba.dds.config.service.interfaces.IParcelInfoServiceConfiguration#getDestinationPattern()
         */
        @Override
        public String getDestinationPattern() {
            return null;
        }

        /**
         * {@inheritDoc}
         *
         * @see
         * vn.sps.aba.dds.config.service.interfaces.IParcelInfoServiceConfiguration#getSourcePattern()
         */
        @Override
        public String getSourcePattern() {
            return null;
        }
    }

    /** The Constant INVALID_PARCEL_INFO_INDEX_FIELD. */
    private static final String INVALID_PARCEL_INFO_INDEX_FIELD = "invalidParcelInfo";

    /**
     * The Constant SOUCE.
     */
    private static final String SOUCE = DDSConstant.Source.E132;

    /**
     * The Constant WSDL_NAME.
     */
    private static final String WSDL_NAME = "parcelService";

    /** The destination pattern. */
    private String destinationPattern;

    /** The incorrect base64 sign. */
    private String incorrectBase64Sign;

    /**
     * The incorrect image base64 message.
     */
    private String incorrectImageBase64Message;

    /** The invalid parcel info field name. */
    private String invalidParcelInfoFieldName = INVALID_PARCEL_INFO_INDEX_FIELD;

    /**
     * The logging interceptor.
     */
    @Autowired
    private DDSLoggingInterceptor loggingInterceptor;

    /**
     * The parcel info sent time stamp format.
     */
    private String parcelInfoSentTimeStampFormat;

    /**
     * The parcel info time stamp format.
     */
    private String parcelInfoTimeStampFormat;

    /**
     * The source pattern.
     */
    private String sourcePattern;

    /**
     * {@inheritDoc}
     *
     * @see
     * org.springframework.ws.config.annotation.WsConfigurerAdapter#addInterceptors(java.util.List)
     */
    @Override
    public void addInterceptors(final List<EndpointInterceptor> interceptors) {

        interceptors.add(this.loggingInterceptor);
        interceptors.add(new ParcelInfoInterceptor(this));
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#failedToStoreData()
     */
    @Override
    public Response failedToStoreData() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.FailedToStoreData.name());
    }

    /**
     * Gets the destination pattern.
     *
     * @return the destination pattern
     */
    @Override
    public String getDestinationPattern() {
        return this.destinationPattern;
    }

    /**
     * Gets the incorrect base64 sign.
     *
     * @return the incorrect base64 sign
     */
    public String getIncorrectBase64Sign() {
        return this.incorrectBase64Sign;
    }

    /**
     * Gets the incorrect image base64 message.
     *
     * @return the incorrect image base64 message
     */
    public String getIncorrectImageBase64Message() {
        return this.incorrectImageBase64Message;
    }

    /**
     * Gets the invalid parcel info field name.
     *
     * @return the invalid parcel info field name
     */
    public String getInvalidParcelInfoFieldName() {
        return this.invalidParcelInfoFieldName;
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getNamespaceURI()
     */
    @Override
    public String getNamespaceURI() {
        return DDSConstant.Namespace.E132_NAMESPACE;
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getObjectFactory()
     */
    @Override
    public ObjectFactory getObjectFactory() {
        return (ObjectFactory) super.getObjectFactory();
    }

    /**
     * Gets the parcel info sent time stamp format.
     *
     * @return the parcel info sent time stamp format
     */
    public String getParcelInfoSentTimeStampFormat() {
        return this.parcelInfoSentTimeStampFormat;
    }

    /**
     * Gets the parcel info time stamp format.
     *
     * @return the parcel info time stamp format
     */
    public String getParcelInfoTimeStampFormat() {
        return this.parcelInfoTimeStampFormat;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getServiceName()
     */
    @Override
    public String getServiceName() {
        return "ParcelInfo";
    }

    /**
     * Gets the source pattern.
     *
     * @return the source pattern
     */
    @Override
    public String getSourcePattern() {
        return this.sourcePattern;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#initialize()
     */
    @Override
    @PostConstruct
    public void initialize() throws Exception {
        super.initialize();
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#invalidData()
     */
    @Override
    public Response invalidData() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.InvalidData.name());
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#serviceAvailable()
     */
    @Override
    public Response serviceAvailable() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.ServiceAvailable.name());
    }

    /**
     * Sets the destination pattern.
     *
     * @param destinationPattern the new destination pattern
     */
    public void setDestinationPattern(final String destinationPattern) {
        this.destinationPattern = destinationPattern;
    }

    /**
     * Sets the incorrect base64 sign.
     *
     * @param incorrectBase64Sign the new incorrect base64 sign
     */
    public void setIncorrectBase64Sign(final String incorrectBase64Sign) {
        this.incorrectBase64Sign = incorrectBase64Sign;
    }

    /**
     * Sets the incorrect image base64 message.
     *
     * @param incorrectImageBase64Message the new incorrect image base64 message
     */
    public void setIncorrectImageBase64Message(final String incorrectImageBase64Message) {
        this.incorrectImageBase64Message = incorrectImageBase64Message;
    }

    /**
     * Sets the invalid parcel info field name.
     *
     * @param invalidParcelInfoFieldName the new invalid parcel info field name
     */
    public void setInvalidParcelInfoFieldName(final String invalidParcelInfoFieldName) {
        this.invalidParcelInfoFieldName = invalidParcelInfoFieldName;
    }

    /**
     * Sets the parcel info sent time stamp format.
     *
     * @param parcelInfoSentTimeStampFormat the new parcel info sent time stamp
     * format
     */
    public void setParcelInfoSentTimeStampFormat(final String parcelInfoSentTimeStampFormat) {
        this.parcelInfoSentTimeStampFormat = parcelInfoSentTimeStampFormat;
    }

    /**
     * Sets the parcel info time stamp format.
     *
     * @param parcelInfoTimeStampFormat the new parcel info time stamp format
     */
    public void setParcelInfoTimeStampFormat(final String parcelInfoTimeStampFormat) {
        this.parcelInfoTimeStampFormat = parcelInfoTimeStampFormat;
    }

    /**
     * Sets the source pattern.
     *
     * @param sourcePattern the new source pattern
     */
    public void setSourcePattern(final String sourcePattern) {
        this.sourcePattern = sourcePattern;
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#successful()
     */
    @Override
    public Response successful() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.Successful.name());
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#unexpectedError()
     */
    @Override
    public Response unexpectedError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.UnexpectedError.name());
    }

    /**
     * Orders.
     *
     * @return the simple wsdl11 definition
     */
    @Bean(name = WSDL_NAME)
    public SimpleWsdl11Definition wsdlDefinition() {
        return new SimpleWsdl11Definition(this.wsdlResource);
    }
}
