/*
 * Class: DpmsServiceEndpoint
 *
 * Created on Aug 18, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.dpms;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import vn.sps.aba.dds.common.constant.DDSConstant.Namespace;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.dpms.CaptureResult;
import vn.sps.aba.dds.common.types.ws.dpms.CaptureResultIn;
import vn.sps.aba.dds.common.types.ws.dpms.CaptureResultIn.CaptureResultRecords;
import vn.sps.aba.dds.common.types.ws.dpms.CaptureResultRecord;
import vn.sps.aba.dds.common.types.ws.dpms.CaptureResultResponse;
import vn.sps.aba.dds.common.util.DpmsUtil;
import vn.sps.aba.dds.common.util.JaxbUtil;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.service.DpmsServiceConfiguration;
import vn.sps.aba.dds.config.task.validator.ReceiverValidatingExecutor;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.service.validation.dpms.IReceiverValidator;
import vn.sps.aba.dds.service.validation.dpms.PackageValidatingInfo;
import vn.sps.aba.dds.service.validation.dpms.ReceiverValidatingInfo;

/**
 * The Class DpmsServiceEndpoint.
 */
@Endpoint
@Profile(Profiles.DPMS)
public class DpmsServiceEndpoint {

    /**
     * The Class DelegateReceiverInfoValidator.
     */
    private class DelegateReceiverInfoValidator {

        /**
         * {@inheritDoc}
         *
         * @see java.util.concurrent.RecursiveTask#compute()
         */
        protected List<ReceiverValidatingInfo> compute(final CaptureResultRecords captureResultRecords, final PackageValidatingInfo packageValidatingInfo) {

            final List<ReceiverValidatingInfo> validationResults = new ArrayList<>();
            final List<Future<ReceiverValidatingInfo>> tasks = new ArrayList<>();
            final AsyncTaskExecutor executor = DpmsServiceEndpoint.this.validatingExecutor.getAsyncExecutor();

            for (final CaptureResultRecord captureResultRecord : captureResultRecords.getCaptureResultRecord()) {

                tasks.add(executor.submit(() -> {
                    final String key = StringUtil.newUuidString();
                    final ReceiverValidatingInfo result = new ReceiverValidatingInfo();
                    {
                        result.setPackageId(packageValidatingInfo.getPackageId());
                        result.setKey(key);
                        result.setReceiverInfo(captureResultRecord);
                        DpmsServiceEndpoint.this.receiverValidator.validate(result, packageValidatingInfo);
                    }
                    return result;
                }));
            }
            for (final Future<ReceiverValidatingInfo> future : tasks) {
                ReceiverValidatingInfo validator = null;
                try {
                    validationResults.add(validator = future.get());
                }
                catch (InterruptedException | ExecutionException e) {
                    LOG.error(IndexMaker.indexes(validator), "There is error with thread when validating receiver info", e);
                }
            }

            return validationResults;
        }

    }

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DpmsServiceEndpoint.class);

    /** The receiver validator. */
    @Autowired
    private IReceiverValidator receiverValidator;

    /** The service configuration. */
    @Autowired
    private DpmsServiceConfiguration serviceConfiguration;

    /** The task DPM reception. */
    @Autowired
    private ReceiverValidatingExecutor validatingExecutor;

    /**
     * Capture result.
     *
     * @param captureResult the capture result
     * @return the capture result response
     */
    @PayloadRoot(namespace = Namespace.E190_NAMESPACE, localPart = "CaptureResult")
    public @ResponsePayload CaptureResultResponse captureResult(@RequestPayload final CaptureResult captureResult) {

        Response response = this.serviceConfiguration.successful();

        final PackageValidatingInfo packageValidatingInfo = new PackageValidatingInfo();
        packageValidatingInfo.setPackageId(StringUtil.newUuidString());
        final boolean isInvalidArgumentError = this.isInvalidArgument(captureResult, packageValidatingInfo);

        final long receivedTime = DiscoWallClock.milli();
        try {
            packageValidatingInfo.setReceivedTime(receivedTime);
            final CaptureResultIn request = captureResult.getRequest();
            if (!isInvalidArgumentError) {

                if (packageValidatingInfo.getTotalCount() > 0) {

                    final CaptureResultRecords captureResultRecords = request.getCaptureResultRecords();
                    final DelegateReceiverInfoValidator delegateValidator = new DelegateReceiverInfoValidator();

                    final List<ReceiverValidatingInfo> receiverValidatingResults = delegateValidator.compute(captureResultRecords, packageValidatingInfo);
                    this.mergeResult(receiverValidatingResults, packageValidatingInfo);

                    if (packageValidatingInfo.getErrorCount() > 0) {
                        response = this.serviceConfiguration.invalidCaptureResultRecordsError();
                        packageValidatingInfo.setResponse(response);
                        LOG.info(IndexMaker.indexes(packageValidatingInfo), "DPM package has some invalid records");
                    }
                    else {
                        packageValidatingInfo.setResponse(response);
                        LOG.info(IndexMaker.indexes(packageValidatingInfo), "Valid DPM package");
                    }
                }
                else {
                    LOG.info(IndexMaker.indexes(packageValidatingInfo), "Valid DPM package with no receiver info");
                }
            }
            else {
                response = this.serviceConfiguration.invalidArgumentError();
                packageValidatingInfo.setResponse(response);
                LOG.error(IndexMaker.indexes(packageValidatingInfo), "Invalid DPM package");
            }
        }
        catch (final Exception e) {

            response = this.serviceConfiguration.unexpectedError();
            packageValidatingInfo.setResponse(response);
            LOG.error(IndexMaker.indexes(packageValidatingInfo), "Unexpected error when validating DPM package", e);
        }

        return MessageBuilder.buildDPMSResponse(this.serviceConfiguration, response, packageValidatingInfo);
    }

    /**
     * Checks if is invalid argument.
     *
     * @param captureResult the capture result
     * @param validatingInfo the validating info
     * @return true, if is invalid argument
     */
    private boolean isInvalidArgument(final CaptureResult captureResult, final PackageValidatingInfo validatingInfo) {

        final CaptureResultIn request = captureResult.getRequest();
        boolean ret = false;

        if (request == null) {
            validatingInfo.addError("Request object is null");
            ret = true;
        }
        else {

            if (request.getCaptureResultRecords() != null) {
                validatingInfo.setTotalCount(request.getCaptureResultRecords().getCaptureResultRecord().size());
            }

            final String callerId = JaxbUtil.element2String(request.getCallerId());
            final String version = JaxbUtil.element2String(request.getVersion());

            validatingInfo.setCallerId(callerId);
            validatingInfo.setVersion(version);

            if ((callerId == null) || !callerId.matches(this.serviceConfiguration.getCallerIdFormat())) {
                validatingInfo.addError("CallerId must match format " + this.serviceConfiguration.getCallerIdFormat());
                ret = true;
            }

            final int[] versionRange = this.serviceConfiguration.getVersionRange();
            if (!DpmsUtil.checkVersion(version, versionRange)) {
                validatingInfo.addError("Version must " + this.serviceConfiguration.getVersionRangeString());
                ret = true;
            }
        }

        return ret;
    }

    /**
     * Check result.
     *
     * @param validationResults the validation results
     * @param packageValidatingInfo the package validating info
     */
    private void mergeResult(final List<ReceiverValidatingInfo> validationResults, final PackageValidatingInfo packageValidatingInfo) {

        int errorCount = 0;

        for (final ReceiverValidatingInfo validationResult : validationResults) {
            if (!validationResult.isValid()) {
                errorCount++;
            }
        }

        packageValidatingInfo.setErrorCount(errorCount);
    }
}
