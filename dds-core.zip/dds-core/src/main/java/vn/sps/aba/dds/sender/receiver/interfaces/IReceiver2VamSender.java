/*
 * Class: IReceiver2VamSender
 * 
 * Created on Oct 28, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.sender.receiver.interfaces;

import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.sender.IExternalSender;

/**
 * The Interface IReceiver2VamSender.
 */
public interface IReceiver2VamSender extends IExternalSender<ReceiverInfo>  {

}
