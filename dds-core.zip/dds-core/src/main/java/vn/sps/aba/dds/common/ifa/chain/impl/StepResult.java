/*
 * Class: StepResult
 *
 * Created on Jun 21, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.ifa.chain.impl;

import vn.sps.aba.dds.common.ifa.chain.IStepResult;

/**
 * The Class StepResult.
 */
public class StepResult implements IStepResult {

    /** The is handled in this step. */
    private boolean isHandledInThisStep;

    /** The message. */
    private String message;

    /**
     * Constructs a new <tt>StepResult</tt>.
     */
    public StepResult() {
    }

    /**
     * Instantiates a new step result.
     *
     * @param isHandledInThisStep the is handled in this step
     */
    public StepResult(final boolean isHandledInThisStep) {
        this.setHandledInThisStep(isHandledInThisStep);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.chain.IStepResult#getMessage()
     */
    @Override
    public String getMessage() {
        return this.message;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.chain.IStepResult#isHandledInThisStep()
     */
    @Override
    public boolean isHandledInThisStep() {
        return this.isHandledInThisStep;
    }

    /**
     * Sets the handled in this step.
     *
     * @param isHandledInThisStep The isHandledInThisStep to set.
     */
    public void setHandledInThisStep(final boolean isHandledInThisStep) {
        this.isHandledInThisStep = isHandledInThisStep;
    }

    /**
     * Sets the message.
     *
     * @param message The message to set.
     */
    public void setMessage(final String message) {
        this.message = message;
    }

}
