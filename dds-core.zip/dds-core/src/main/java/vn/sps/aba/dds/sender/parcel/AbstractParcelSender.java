/*
 * Class: AbstractParcelSender
 *
 * Created on Oct 19, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.sender.parcel;

import java.util.concurrent.Future;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;

import vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.repository.cache.interfaces.IParcelInfoCacheDao;
import vn.sps.aba.dds.scheduled.sender.IScheduledSender;

/**
 * The Class AbstractParcelSender.
 */
public abstract class AbstractParcelSender extends AbstractAsyncWorker {

    /** The parcel info dao. */
    @Autowired
    protected IParcelInfoCacheDao parcelInfoDao;

    /**
     * Gets the scheduled sender.
     *
     * @return the scheduled sender
     */
    protected abstract IScheduledSender<ParcelInfo> getScheduledSender();

    /**
     * Handle item.
     *
     * @param parcelInfo the parcel info
     * @param isRetry the is retry
     * @return the runnable
     */
    protected Runnable handleItem(final ParcelInfo parcelInfo, final boolean isRetry) {
        return null;
    }

    /**
     * Initialize.
     */
    @PostConstruct
    protected void initialize() {

    }

    /**
     * Rubmit item.
     *
     * @param parcelInfo the parcel info
     */
    public void rubmitItem(final ParcelInfo parcelInfo) {
        final String key = parcelInfo.getKey();
        if (this.watcher.isDone(key)) {
            this.getScheduledSender().cancelScheduledItem(key);
            final Runnable r = this.handleItem(parcelInfo, true);
            final Future<?> worker = this.getExecutor().getAsyncExecutor().submit(r);
            this.watcher.watch(key, worker);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.sender.IExternalSender#submitItem(java.lang.Object)
     */
    public void submitItem(final ParcelInfo parcelInfo) {
        final String key = parcelInfo.getKey();
        if (this.watcher.isDone(key)) {
            final Runnable r = this.handleItem(parcelInfo, false);
            final Future<?> worker = this.getExecutor().getAsyncExecutor().submit(r);
            this.watcher.watch(key, worker);
        }
    }
}
