package vn.sps.aba.dds.service.lookup.ampplus.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import vn.sps.aba.dds.common.model.lookup.AsdpPlz;
import vn.sps.aba.dds.config.service.AbstractRestWsConfiguration;
import vn.sps.aba.dds.config.service.AsdpServiceConfiguration;
import vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate;
import vn.sps.aba.dds.service.lookup.ampplus.IAMPPlusLookupService;
import vn.sps.aba.dds.service.lookup.asdp.impl.AsdpLookupService;

/**
 * The Class AMPPlusLookupService.
 */
public class AMPPlusLookupService extends AbstractRestWsTemplate<AsdpPlz> implements IAMPPlusLookupService {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(AsdpLookupService.class);

    /** The service configuration. */
    @Autowired
    private AsdpServiceConfiguration serviceConfiguration;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.lookup.ampplus.IAMPPlusLookupService#getAmpPlus(java.lang.String)
     */
    @Override
    public AsdpPlz getAmpPlus(final String plz) {
        AsdpPlz response = null;

        try {
            final ResponseEntity<AsdpPlz> entity = this.restTemplate.getForEntity(this.getConfiguration().getServiceUrl() + "/" + plz, AsdpPlz.class);

            response = entity.getBody();

        }
        catch (final Exception e) {
            LOG.error("There is error while lookup AmpPlus data", e);
        }

        return response;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate#getConfiguration()
     */
    @Override
    protected AbstractRestWsConfiguration getConfiguration() {
        return this.serviceConfiguration;
    }
}