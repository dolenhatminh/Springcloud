/*
 * Class: BlackboxScheduledSender
 *
 * Created on Oct 12, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.sender.parcel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.scheduler.DdsScheduler;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.logging.report.VaeRecordReport;
import vn.sps.aba.dds.service.blackbox.IVaeBlackboxService;

/**
 * The Class BlackboxScheduledSender.
 */
@Configuration
@Component("BlackboxScheduledSender")
@ConfigurationProperties("schedule.resend.vae.blackbox")
public class BlackboxScheduledSender extends AbstractParcelInfoSender {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(BlackboxScheduledSender.class);

    /** The black box service. */
    @Autowired
    private IVaeBlackboxService blackBoxService;

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.scheduled.sender.AbstractScheduledSender#buildSenderExecutor()
     */
    @Override
    protected void buildSenderExecutor() {
        this.scheduledExecutor = new DdsScheduler() {

            @Override
            public String getName() {
                return "resend-blackbox-scheduler-";
            }

            @Override
            public ThreadPoolTaskScheduler getScheduler() {
                final ThreadPoolTaskScheduler executor = new ThreadPoolTaskScheduler();
                {
                    final ThreadPoolTaskScheduler scheduler = executor;
                    scheduler.setBeanName(this.getName());
                    scheduler.setThreadNamePrefix(TaskConfiguration.TASK_PREFIX + this.getName());
                    scheduler.setPoolSize(getParallel());
                    scheduler.setRemoveOnCancelPolicy(isRemoveOnCancel());
                    scheduler.initialize();
                    LOG.info(
                        "Create sender thread pool task executor {}. Core pool: {}. Max pool: {}",
                        getName(),
                        scheduler.getPoolSize(),
                        scheduler.getScheduledThreadPoolExecutor().getMaximumPoolSize());
                }
                return executor;
            }
        };
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#getDestinationServiceName()
     */
    @Override
    protected String getDestinationServiceName() {
        return "VAE Blackbox";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#mergeAndStore(java.lang.String, java.util.Iterator, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    protected void mergeAndStore(final String key, final ParcelInfo parcelInfo) {
        try {
            ParcelInfo ret = this.parcelInfoDao.get(key);
            if (ret != null) {
                ret.setState(parcelInfo.getParcelState());
                ret.setBlackboxBegin(parcelInfo.getBlackboxBegin());
                ret.setBlackboxEnd(parcelInfo.getBlackboxEnd());
                ret.setBlackboxCount(parcelInfo.getBlackboxCount());
            }
            else {
                LOG.info(IndexMaker.index(key), "Cannot find any parcel match with key");
                ret = parcelInfo;
            }
            this.parcelInfoDao.store(key, ret);
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when merge and store parcel into database.", e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#needToSent(java.lang.String, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    protected boolean needToSent(final String key, final ParcelInfo parcelInfo) {
        return ParcelState.BLACKBOX_READY == parcelInfo.getParcelState();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#resendParcel(java.lang.String, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    protected boolean resend(final String key, final ParcelInfo parcelInfo) {
        try {
            LOG.info(IndexMaker.index(parcelInfo), "Re-send to VAE BlackBox");
            if (BlackboxScheduledSender.this.blackBoxService.forwardToBlackbox(parcelInfo)) {

                parcelInfo.setState(ParcelState.BLACKBOX_SENT);
                LOG.info(IndexMaker.indexes(new VaeRecordReport(parcelInfo), "vaeBlackBoxReport"), "Insert log VAE_BlackBox Report");
                LOG.info(IndexMaker.index(parcelInfo), "Forwarded parcel info to VAE BlackBox successfully");
                return true;
            }
            else {
                LOG.info(IndexMaker.index(parcelInfo), "Failed to forward parcel info to VAE BlackBox !");
            }
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when re-send parcel info to VAE Blackbox.", e);
        }
        return false;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#taskName()
     */
    @Override
    public String taskName() {
        return "blackbox-scheduled-sender";
    }
}
