/*
 * Class: AbstractResponsibilityExecutor
 *
 * Created on Jun 21, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.ifa.chain.impl;

import vn.sps.aba.dds.common.ifa.chain.IResponsibilityHandler;
import vn.sps.aba.dds.common.ifa.chain.IStepResult;

/**
 * The Class AbstractResponsibilityExecutor.
 *
 * @param <T> the generic type
 * @param <R> the generic type
 */
public abstract class AbstractResponsibilityHandler<T, R extends IStepResult> implements IResponsibilityHandler<T, R> {

    /** The next executor. */
    private IResponsibilityHandler<T, R> nextHandler;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.chain.IResponsibilityHandler#handleRequest(java.lang.Object)
     */
    @SuppressWarnings("unchecked")
    @Override
    public R handleRequest(final T entry) {
        R ret = this.process(entry);

        if (!ret.isHandledInThisStep()) {
            if (this.nextHandler != null) {
                ret = this.nextHandler.handleRequest(entry);
            }
            else {
                ret = (R) new IStepResult() {

                    @Override
                    public String getMessage() {
                        return "No more handler";
                    }

                    @Override
                    public boolean isHandledInThisStep() {
                        return false;
                    }
                };
            }
        }

        return ret;
    }

    /**
     * Must implement this for specific business rule.<br>
     *
     * @param entry the entry
     * @return true, if successful
     */
    protected abstract R process(T entry);

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.chain.IResponsibilityHandler#setNextHandler(vn.sps.aba.dds.common.ifa.chain.IResponsibilityHandler)
     */
    @Override
    public void setNextHandler(final IResponsibilityHandler<T, R> nextHandler) {
        this.nextHandler = nextHandler;
    }
}
