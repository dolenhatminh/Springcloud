/*
 * Class: ParcelInfoController
 *
 * Created on Jul 7, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Profile;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.constant.Enumeration.DmcState;
import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.cache.IDDSCacheEntry;
import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.statistic.Status;
import vn.sps.aba.dds.common.util.ControllerUtil;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.controller.interfaces.IEntriesController;
import vn.sps.aba.dds.controller.interfaces.INoVisibleEntries;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.receiver.dmc.IDmcReceiver;
import vn.sps.aba.dds.repository.cache.interfaces.IParcelInfoCacheDao;
import vn.sps.aba.dds.repository.importing.report.IAsdpImportingReport;
import vn.sps.aba.dds.repository.listener.IMightBeErrorCollector;
import vn.sps.aba.dds.scheduled.importer.AsdpPlzScheduledImporter;
import vn.sps.aba.dds.sender.IExternalSender;
import vn.sps.aba.dds.sender.parcel.interfaces.IBarcodeSender;
import vn.sps.aba.dds.sender.parcel.interfaces.IBlackboxSender;
import vn.sps.aba.dds.sender.parcel.interfaces.IDmcSender;
import vn.sps.aba.dds.sender.parcel.interfaces.IParcel2VamSender;

/**
 * The Class ParcelInfoController.
 */
@ConfigurationProperties
@RestController("ParcelInfoController")
@RequestMapping("/aba/dds/parcel")
@Profile(value = { Profiles.PARCEL })
public class ParcelInfoController implements IEntriesController, INoVisibleEntries {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ParcelInfoController.class);

    /** The asdp plz importer. */
    @Autowired
    private AsdpPlzScheduledImporter asdpPlzImporter;

    /** The barcode in progress states. */
    private String[] barcodeInProgressStates;

    /** The barcode sender. */
    @Autowired
    private IBarcodeSender barcodeSender;

    /** The blackbox in progress states. */
    private String[] blackboxInProgressStates;

    /** The blackbox sender. */
    @Autowired
    private IBlackboxSender blackboxSender;

    /** The capture result in progress states. */
    private String[] captureResultInProgressStates;

    /** The dmc in progress states. */
    @SuppressWarnings("unused")
    private String[] dmcInProgressStates;

    /** The dmc processor. */
    @Autowired
    private IDmcReceiver dmcProcessor;

    /** The dmc sender. */
    @Autowired
    private IDmcSender dmcSender;

    /** The error collector. */
    @Autowired
    @Qualifier("ParcelInfoCacheDao")
    private IMightBeErrorCollector errorCollector;

    /** The parcel info dao. */
    @Autowired
    private IParcelInfoCacheDao parcelInfoDao;

    /** The vam sender. */
    @Autowired
    private IParcel2VamSender vamSender;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.interfaces.IEntriesController#checkAndPersist(java.lang.String)
     */
    @Override
    public int checkAndPersist(final String key) {
        return this.checkAndPersist(key, true);
    }

    /**
     * Check and persist.
     *
     * @param key
     *            the key
     * @param sync
     *            the sync
     * @return the int
     */
    private int checkAndPersist(final String key, final boolean sync) {
        int ret = 0;

        if (StringUtil.notNullOrEmpty(key)) {
            final ParcelInfo parcelInfo = this.parcelInfoDao.get(key);
            try {
                ret = this.parcelInfoDao.persist(key, parcelInfo, sync) ? 1 : -1;
            }
            catch (final Exception e) {
                ret = -1;
                LOG.error("There is error when persist parcel into dabase", e);
            }
        }

        return ret;
    }

    /**
     * Clear cache.
     */
    @Override
    public void clearCache() {
        this.parcelInfoDao.clear();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.interfaces.IEntriesController#count()
     */
    @Override
    public List<Status> count() {
        return this.count(null, null);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.interfaces.IEntriesController#count(java.time.LocalDateTime,
     *      java.time.LocalDateTime)
     */
    @Override
    public List<Status> count(final String fromTime, final String toTime) {

        final List<Status> ret = new ArrayList<>();

        final LocalDateTime fromLocalTime = ControllerUtil.string2LocalDateTime(fromTime);
        final LocalDateTime toLocalTime = ControllerUtil.string2LocalDateTime(toTime);

        final long fromInstant = ControllerUtil.localDateTime2Instant(fromLocalTime);
        final long toInstant = ControllerUtil.localDateTime2Instant(toLocalTime);
        this.parcelInfoDao.countState(ret, fromInstant, toInstant);

        return ret;
    }

    /**
     * Find and submit.
     *
     * @param states
     *            the states
     * @param sender
     *            the sender
     * @param fromTime
     *            the from time
     * @param toTime
     *            the to time
     * @param maxResult
     *            the max result
     * @param isDmcState
     *            the is dmc state
     * @return the int
     */
    private int findAndSubmit(
        final String[] states,
        final IExternalSender<ParcelInfo> sender,
        final LocalDateTime fromTime,
        final LocalDateTime toTime,
        final int maxResult,
        final boolean isDmcState) {
        final List<ParcelInfo> parcelInfos = new ArrayList<>();

        try {
            if ((states != null) && (states.length > 0)) {

                final long fromInstant = fromTime == null ? -1 : DateUtil.localDateTime2EpochMillis(fromTime, DiscoWallClock.zone());
                final long toInstant = toTime == null ? -1 : DateUtil.localDateTime2EpochMillis(toTime, DiscoWallClock.zone());
                for (final String state : states) {
                    final List<ParcelInfo> results = isDmcState ? this.parcelInfoDao.list(fromInstant, toInstant, null, state, maxResult)
                            : this.parcelInfoDao.list(fromInstant, toInstant, state, null, maxResult);
                    if ((results != null) && !results.isEmpty()) {
                        parcelInfos.addAll(results);
                    }
                }
                if (!parcelInfos.isEmpty()) {
                    parcelInfos.stream().forEach(t -> sender.rubmitItem(t));
                    LOG.info(
                        "Found and submitted {} parcel has received time between {} and {} and state is one of {} to {}",
                        parcelInfos.size(),
                        fromTime,
                        toTime,
                        Arrays.toString(states),
                        sender.getSenderName());
                }
            }
            else {
                LOG.info("No state specified");
            }
        }
        catch (final Exception e) {
            LOG.error("Error while finding and submitting parcels to " + sender.getSenderName(), e);
        }

        return parcelInfos.size();
    }

    /**
     * Find and submit dmc.
     *
     * @param fromTime
     *            the from time
     * @param toTime
     *            the to time
     * @param maxResult
     *            the max result
     * @return the int
     */
    @RequestMapping(value = "/find/submit/barcode", method = RequestMethod.POST)
    public int findAndSubmitBarcode(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        @RequestParam(value = "size") final int maxResult) {

        return this.findAndSubmit(this.barcodeInProgressStates, this.barcodeSender, fromTime, toTime, maxResult, true);
    }

    /**
     * Find and submit blackbox.
     *
     * @param fromTime
     *            the from time
     * @param toTime
     *            the to time
     * @param maxResult
     *            the max result
     * @return the int
     */
    @RequestMapping(value = "/find/submit/blackbox", method = RequestMethod.POST)
    public int findAndSubmitBlackbox(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        @RequestParam(value = "size") final int maxResult) {

        return this.findAndSubmit(this.blackboxInProgressStates, this.blackboxSender, fromTime, toTime, maxResult, false);
    }

    /**
     * Find and submit dmc.
     *
     * @param fromTime
     *            the from time
     * @param toTime
     *            the to time
     * @param maxResult
     *            the max result
     * @param dmcState
     *            the dmc state
     * @return the int
     */
    @RequestMapping(value = "/find/submit/dmc", method = RequestMethod.POST)
    public int findAndSubmitDmc(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        @RequestParam(value = "size") final int maxResult,
        @RequestParam(value = "dmcState", defaultValue = "${controller.parcel.dmc.in-progress-states}") final String[] dmcState) {

        return this.findAndSubmit(dmcState, this.dmcSender, fromTime, toTime, maxResult, true);
    }
    // TODO -- Add another API to re-send parcel and receiver info in case it was expired

    /**
     * Find and submit vam.
     *
     * @param fromTime
     *            the from time
     * @param toTime
     *            the to time
     * @param maxResult
     *            the max result
     * @return the int
     */
    @RequestMapping(value = "/find/submit/capture-result", method = RequestMethod.POST)
    public int findAndSubmitVam(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        @RequestParam(value = "size") final int maxResult) {

        return this.findAndSubmit(this.captureResultInProgressStates, this.vamSender, fromTime, toTime, maxResult, false);
    }

    /**
     * Import asdp.
     *
     * @return the i asdp importing report
     */
    @RequestMapping(value = "/import/asdpplz", method = RequestMethod.POST)
    public IAsdpImportingReport importAsdp() {
        return this.asdpPlzImporter.importData();
    }

    /**
     * List all no visible enitries.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @param size the size
     * @return the list
     * @see vn.sps.aba.dds.controller.interfaces.INoVisibleEntries#listAllNoVisibleEnitries(java.lang.String, java.lang.String, int)
     */
    @Override
    public List<IDDSCacheEntry> listAllNoVisibleEnitries(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        final int size) {
        final List<IDDSCacheEntry> ret = new ArrayList<>();

        if (size != 0) {

            final long fromInstant = ControllerUtil.localDateTime2Instant(fromTime);
            final long toInstant = ControllerUtil.localDateTime2Instant(toTime);

            this.parcelInfoDao.getManagedInfo(ret, fromInstant, toInstant, size);
            if (!ret.isEmpty()) {
                LOG.info("Found {} parcel has receive time between [{}] and [{}]", ret.size(), fromTime, toTime);
            }
            else {
                LOG.info("Cannot find any parcel has receive time between [{}] and [{}]", fromTime, toTime);
            }
            ret.stream().forEach((p) -> {
                this.parcelInfoDao.get(p.getKey());
            });
        }

        return ret;
    }

    /**
     * List by ident code no visible enitries.
     *
     * @param identCode the ident code
     * @return the IDDS cache entry
     * @see vn.sps.aba.dds.controller.interfaces.INoVisibleEntries#listByIdentCodeNoVisibleEnitries(java.lang.String)
     */
    @Override
    public List<IDDSCacheEntry> listByIdentCodeNoVisibleEnitries(
        @RequestParam(value = "identCode") final String identCode,
        @RequestParam(value = "size", defaultValue = "-1") final int size) {
        final List<IDDSCacheEntry> ret = new ArrayList<>();

        if ((size != 0) && (identCode != null)) {
            this.parcelInfoDao.getManagedInfo(ret, null, identCode, size);
            ControllerUtil.sortManagedInfo(ret);
            if (ret.isEmpty()) {
                LOG.info("Cannot find any parcel has ident code {}", identCode);
            }
        }

        return ret;
    }

    /**
     * List by key no visible enitries.
     *
     * @param key the key
     * @return the IDDS cache entry
     * @see vn.sps.aba.dds.controller.interfaces.INoVisibleEntries#listByKeyNoVisibleEnitries(java.lang.String)
     */
    @Override
    public IDDSCacheEntry listByKeyNoVisibleEnitries(@RequestParam(value = "key") final String key) {
        IDDSCacheEntry ret = null;

        if (key != null) {
            final List<IDDSCacheEntry> entries = new ArrayList<>();
            this.parcelInfoDao.getManagedInfo(entries, key, null, -1);
            if (entries.isEmpty()) {
                LOG.info("Cannot find any parcel has key {}", key);
            }
            else {
                ret = entries.get(0);
            }
        }

        return ret;
    }

    /**
     * List by state no visible enitries.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @param state the state
     * @param size the size
     * @return the list
     * @see vn.sps.aba.dds.controller.interfaces.INoVisibleEntries#listByStateNoVisibleEnitries(java.lang.String, java.lang.String, java.lang.String, int)
     */
    @Override
    public List<IDDSCacheEntry> listByStateNoVisibleEnitries(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        final String state,
        final int size) {
        return this.listByStateNoVisibleEnitries(fromTime, toTime, state, null, size);
    }

    /**
     * List by state no visible enitries.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @param state the state
     * @param dmcState the dmc state
     * @param size the size
     * @return the list
     */
    @RequestMapping(value = "/nov/list-by-states", method = RequestMethod.GET)
    public List<IDDSCacheEntry> listByStateNoVisibleEnitries(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        final String state,
        final String dmcState,
        final int size) {
        final List<IDDSCacheEntry> ret = new ArrayList<>();

        if (size != 0) {
            final long fromInstant = ControllerUtil.localDateTime2Instant(fromTime);
            final long toInstant = ControllerUtil.localDateTime2Instant(toTime);

            if (state == null) {
                this.parcelInfoDao.getManagedInfo(ret, fromInstant, toInstant, StringUtil.toNullString(state), StringUtil.toNullString(dmcState), size);
            }
            if (!ret.isEmpty()) {
                LOG.info("Found {} parcel has receive time between [{}] and [{}]", ret.size(), fromTime, toTime);
            }
            else {
                LOG.info("Cannot find any parcel has receive time between [{}] and [{}]", fromTime, toTime);
            }
        }

        return ret;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.interfaces.IEntriesController#persist(java.time.LocalDateTime,
     *      java.time.LocalDateTime)
     */
    @Override
    public String[] persist(
        @RequestParam(value = "fromTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime fromTime,
        @RequestParam(value = "toTime") @DateTimeFormat(pattern = DDSConstant.FORMAT_DEFAULT_DATE_TIME) final LocalDateTime toTime,
        @RequestParam(value = "size") final int size) {
        final List<String> ret = new ArrayList<>();

        if (fromTime.isBefore(toTime)) {
            final long fromInstant = ControllerUtil.localDateTime2Instant(fromTime);
            final long toInstant = ControllerUtil.localDateTime2Instant(toTime);
            final List<ParcelInfo> parcelInfos = this.parcelInfoDao.list(fromInstant, toInstant, null, null, size);
            if ((parcelInfos != null) && (parcelInfos.size() > 0)) {

                LOG.info("Found {} parcel info has receivedTime between {} and {}", parcelInfos.size(), fromTime, toTime);
                final String retPattern = "%s:%s";
                for (final ParcelInfo parcelInfo : parcelInfos) {
                    final String key = parcelInfo.getKey();
                    String result = null;
                    try {
                        if (this.parcelInfoDao.persist(key, parcelInfo, true)) {
                            result = String.format(retPattern, key, "successful");
                        }
                        else {
                            result = String.format(retPattern, key, "failed");
                        }
                    }
                    catch (final Exception e) {
                        result = String.format(retPattern, key, "failed");
                        LOG.error(IndexMaker.index(key), "Failed trying to persist parcel info " + key, e);
                    }
                    ret.add(result);
                }
            }
            else {
                LOG.info("Cannot find any parcel info has receivedTime between {} and {}", fromTime, toTime);
            }
        }

        return ret.toArray(new String[ret.size()]);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.interfaces.IEntriesController#processDBError()
     */
    @Override
    public String processDBError(final boolean wait) {
        final String pattern = "Found %d error items, persist %d successfully";

        final List<String> errorItems = this.errorCollector.listErrorItem();
        int count = 0;

        for (final String key : errorItems) {
            count += this.checkAndPersist(key, wait) == 1 ? 1 : 0;
        }

        return String.format(pattern, errorItems.size(), count);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.interfaces.IEntriesController#processDuplicatedEntries()
     */
    @Override
    public void processDuplicatedEntries() {
        // Not supported
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduleConfigurar#processExpiredEntries()
     */
    @Override
    public void processExpiredEntries() {
        LOG.info("Trying to remove expired parcel info");
        this.parcelInfoDao.removeExpiredEntries();
    }

    /**
     * Receiver from dmc.
     *
     * @param response
     *            the response
     */
    @RequestMapping(value = "/dmcdata", method = RequestMethod.POST)
    public void receiverFromDMC(@RequestBody(required = true) final DMCResponse response) {
        this.dmcProcessor.receive(response);
    }

    /**
     * Sets the barcode in progress states.
     *
     * @param barcodeInProgressStates
     *            the new barcode in progress states
     */
    @Value("${controller.parcel.barcode.in-progress-states}")
    public void setBarcodeInProgressStates(final String[] barcodeInProgressStates) {
        StringUtil.assertEnum(DmcState.class, barcodeInProgressStates);
        this.barcodeInProgressStates = barcodeInProgressStates;
    }

    /**
     * Sets the blackbox in progress states.
     *
     * @param blackboxInProgressStates
     *            the new blackbox in progress states
     */
    @Value("${controller.parcel.blackbox.in-progress-states}")
    public void setBlackboxInProgressStates(final String[] blackboxInProgressStates) {
        StringUtil.assertEnum(ParcelState.class, blackboxInProgressStates);
        this.blackboxInProgressStates = blackboxInProgressStates;
    }

    /**
     * Sets the capture result in progress states.
     *
     * @param captureResultInProgressStates
     *            the new capture result in progress states
     */
    @Value("${controller.parcel.capture-result.in-progress-states}")
    public void setCaptureResultInProgressStates(final String[] captureResultInProgressStates) {
        StringUtil.assertEnum(ParcelState.class, captureResultInProgressStates);
        this.captureResultInProgressStates = captureResultInProgressStates;
    }

    /**
     * Sets the dmc in progress states.
     *
     * @param dmcInProgressStates
     *            the new dmc in progress states
     */
    @Value("${controller.parcel.dmc.in-progress-states}")
    public void setDmcInProgressStates(final String[] dmcInProgressStates) {
        StringUtil.assertEnum(DmcState.class, dmcInProgressStates);
        this.dmcInProgressStates = dmcInProgressStates;
    }
}
