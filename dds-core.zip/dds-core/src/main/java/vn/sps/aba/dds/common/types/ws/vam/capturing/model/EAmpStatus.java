
package vn.sps.aba.dds.common.types.ws.vam.capturing.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for eAmpStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="eAmpStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Unbekannt"/>
 *     &lt;enumeration value="ZurPruefung"/>
 *     &lt;enumeration value="Geprueft"/>
 *     &lt;enumeration value="Geloescht"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "eAmpStatus")
@XmlEnum
public enum EAmpStatus {

    @XmlEnumValue("Unbekannt")
    UNBEKANNT("Unbekannt"),
    @XmlEnumValue("ZurPruefung")
    ZUR_PRUEFUNG("ZurPruefung"),
    @XmlEnumValue("Geprueft")
    GEPRUEFT("Geprueft"),
    @XmlEnumValue("Geloescht")
    GELOESCHT("Geloescht");
    private final String value;

    EAmpStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static EAmpStatus fromValue(String v) {
        for (EAmpStatus c: EAmpStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
