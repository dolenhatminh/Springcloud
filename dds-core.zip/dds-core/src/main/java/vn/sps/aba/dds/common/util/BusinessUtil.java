/*
 * Class: BusinessUtil
 *
 * Created on Jul 28, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The Class BusinessUtil.
 */
public final class BusinessUtil {

    /**
     * Extract destination station.
     *
     * @param destinationStation the destination station
     * @return the string
     */
    public static String extractDestinationStation(final String destinationStation) {
        return destinationStation.substring(0, 3);
    }

    /**
     * Extract group.
     *
     * @param string the string
     * @param pattern the pattern
     * @return the string
     */
    public static String extractGroup(final String string, final String pattern) {
        final Pattern patt = Pattern.compile(pattern);
        final Matcher matcher = patt.matcher(string);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    /**
     * Instantiates a new business util.
     */
    private BusinessUtil() {
    }
}
