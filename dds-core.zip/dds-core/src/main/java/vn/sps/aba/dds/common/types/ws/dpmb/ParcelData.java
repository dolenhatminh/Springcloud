
package vn.sps.aba.dds.common.types.ws.dpmb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ParcelData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ParcelData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AcsTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="DestinationStation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ParPicId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SourceStation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="VcsCase" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ZusatzLeistungen" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}ArrayOfProduktZusatzLeistung"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ParcelData", propOrder = {
    "acsTimestamp",
    "destinationStation",
    "parPicId",
    "sourceStation",
    "vcsCase",
    "zusatzLeistungen"
})
public class ParcelData {

    @XmlElement(name = "AcsTimestamp", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar acsTimestamp;
    @XmlElement(name = "DestinationStation", required = true, nillable = true)
    protected String destinationStation;
    @XmlElement(name = "ParPicId", required = true, nillable = true)
    protected String parPicId;
    @XmlElement(name = "SourceStation", required = true, nillable = true)
    protected String sourceStation;
    @XmlElement(name = "VcsCase")
    protected int vcsCase;
    @XmlElement(name = "ZusatzLeistungen", required = true, nillable = true)
    protected ArrayOfProduktZusatzLeistung zusatzLeistungen;

    /**
     * Gets the value of the acsTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getAcsTimestamp() {
        return acsTimestamp;
    }

    /**
     * Sets the value of the acsTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setAcsTimestamp(XMLGregorianCalendar value) {
        this.acsTimestamp = value;
    }

    /**
     * Gets the value of the destinationStation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationStation() {
        return destinationStation;
    }

    /**
     * Sets the value of the destinationStation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationStation(String value) {
        this.destinationStation = value;
    }

    /**
     * Gets the value of the parPicId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParPicId() {
        return parPicId;
    }

    /**
     * Sets the value of the parPicId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParPicId(String value) {
        this.parPicId = value;
    }

    /**
     * Gets the value of the sourceStation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceStation() {
        return sourceStation;
    }

    /**
     * Sets the value of the sourceStation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceStation(String value) {
        this.sourceStation = value;
    }

    /**
     * Gets the value of the vcsCase property.
     * 
     */
    public int getVcsCase() {
        return vcsCase;
    }

    /**
     * Sets the value of the vcsCase property.
     * 
     */
    public void setVcsCase(int value) {
        this.vcsCase = value;
    }

    /**
     * Gets the value of the zusatzLeistungen property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfProduktZusatzLeistung }
     *     
     */
    public ArrayOfProduktZusatzLeistung getZusatzLeistungen() {
        return zusatzLeistungen;
    }

    /**
     * Sets the value of the zusatzLeistungen property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfProduktZusatzLeistung }
     *     
     */
    public void setZusatzLeistungen(ArrayOfProduktZusatzLeistung value) {
        this.zusatzLeistungen = value;
    }

}
