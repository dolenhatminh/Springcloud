/*
 * Class: DDSConstant
 *
 * Created on Jun 25, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.constant;

/**
 * The Class DDSConstant.
 */
public final class DDSConstant {

    /**
     * The Class CacheName.
     */
    public class CacheName {

        /** The Constant CACHE_ASDP_PLZ. */
        public static final String CACHE_ASDP_PLZ = "asdpplz";

        /**
         * The Constant CACHE_PARCEL_INFO.
         */
        public static final String CACHE_PARCEL_INFO = "parcel_info";

        /**
         * The Constant CACHE_RECEIVER_INFO.
         */
        public static final String CACHE_RECEIVER_INFO = "receiver_info";
    }

    /**
     * The class common constant.
     */
    public class Common {

        /** The Constant CHAR_SLASH. */
        public static final String CHAR_SLASH = "/";

        /** The Constant CLOSED_BRACKET. */
        public static final String CLOSED_BRACKET = ")";

        /** The Constant COLON. */
        public static final String COLON = ":";

        /** The Constant OPEN_BRACKET. */
        public static final String OPEN_BRACKET = "(";

        /** The Constant SERVER_PORT_KEY. */
        public static final String SERVER_PORT_KEY = "server.port";

        /** The Constant VERTICAL_SLASH. */
        public static final String VERTICAL_SLASH = "|";

    }

    /**
     * The Class Namespace.
     */
    public class Namespace {

        /**
         * The Constant E119_NAMESPACE.
         */
        public static final String E119_NAMESPACE = "http://tempuri.org/";

        /**
         * The Constant E120_NAMESPACE.
         */
        public static final String E120_NAMESPACE = "Ch.Post.PL.DisCo.ReceiverInfoService";

        /**
         * The Constant Data Transfer NAMESPACE.
         */
        public static final String E125_NAMESPACE = "http://www.postlogistics.ch/PLDTVG/V10/";

        /**
         * The Constant Capture Result (VAM) NAMESPACE.
         */
        public static final String E128_NAMESPACE = "Ch.Post.PL.Vae.Vam.CaptureResultService";

        /**
         * The Constant Parcel Info NAMESPACE.
         */
        public static final String E132_NAMESPACE = "Ch.Post.PL.Vae.VG.ParcelInfoService";

        /**
         * The Constant Barcode Data NAMESPACE.
         */
        public static final String E134_NAMESPACE = "urn:stc:egate:jce:prjPADA_prjPADASA_prjWsOrwell_OTDs_jcdBCParcelData";

        /**
         * The Constant MatchMaker NAMESPACE.
         */
        public static final String E138_NAMESPACE = "http://xmlns.oracle.com/SOASDEV_Application/PADASAxMatchMakerDaten/MatchMakerInsertPadasa";

        /**
         * The Constant DPM NAMESPACE.
         */
        public static final String E189_NAMESPACE = "Ch.Post.PL.Vae.Vam.CaptureResultService";

        /**
         * The Constant E190_NAMESPACE.
         */
        public static final String E190_NAMESPACE = "Ch.Post.PL.Vae.Vam.CaptureResultService";
    }

    /**
     * The Class ParcelFields.
     */
    public class ParcelFields {

        /** The Constant FIELD_DMC_CODE. */
        public static final String FIELD_DMC_CODE = "dmcCode";

        /** The Constant FIELD_DMC_STATE. */
        public static final String FIELD_DMC_STATE = "dmcState";

        /** The Constant FIELD_IDENT_CODE. */
        public static final String FIELD_IDENT_CODE = "identCode";

        /** The Constant FIELD_KEY. */
        public static final String FIELD_KEY = "key";

        /** The Constant FIELD_PROCESS_END_TIME. */
        public static final String FIELD_PROCESS_END_TIME = "processEnd";

        /** The Constant FIELD_RECEIVED_TIME. */
        public static final String FIELD_RECEIVED_TIME = "received";

        /** The Constant FIELD_STATE. */
        public static final String FIELD_STATE = "state";
    }

    /**
     * The Class Profiles.
     */
    public static class Profiles {

        /**
         * The Constant DPM.
         */
        public static final String DPM = "dpm";

        /**
         * The Constant DPMB.
         */
        public static final String DPMB = "dpmb";

        /**
         * The Constant DPMBS.
         */
        public static final String DPMS = "dpms";

        /**
         * The Constant PARCEL.
         */
        public static final String PARCEL = "par";

        /**
         * The Constant RECEIVER.
         */
        public static final String RECEIVER = "rec";

        /**
         * The Constant RULE.
         */
        public static final String RULE = "rule";
    }

    /**
     * The Class ReceiverFields.
     */
    public class ReceiverFields {

        /** The Constant FIELD_IDENT_CODE. */
        public static final String FIELD_IDENT_CODE = "identCode";

        /** The Constant FIELD_KEY. */
        public static final String FIELD_KEY = "key";

        /** The Constant FIELD_PADASA_END. */
        public static final String FIELD_PADASA_END = "matchMakerEnd";

        /** The Constant FIELD_PROCESS_END. */
        public static final String FIELD_PROCESS_END = "processEnd";

        /** The Constant FIELD_RECEIVED_TIME. */
        public static final String FIELD_RECEIVED_TIME = "received";

        /** The Constant FIELD_STATE. */
        public static final String FIELD_STATE = "state";

        /** The Constant FIELD_VAM_END. */
        public static final String FIELD_VAM_END = "captureResultEnd";
    }

    /**
     * The Class Response.
     */
    public class Response {

        /**
         * The Constant E132_0099.
         */
        public static final String E120_FailedToStoreData = "E120.FailedToStoreData";

        /**
         * The Constant E120_InvalidData.
         */
        public static final String E120_InvalidData = "E120.InvalidData";

        /**
         * The Constant E132_0001.
         */
        public static final String E120_ServiceAvailable = "E120.ServiceAvailable";

        /**
         * The Constant E132_0000.
         */
        public static final String E120_Successful = "E120.Successful";

        /**
         * The Constant E120_UnexpectedError.
         */
        public static final String E120_UnexpectedError = "E120.UnexpectedError";

        /**
         * The Constant E125_0000.
         */
        public static final String E125_0000 = "E125.0000";

        /**
         * The Constant E125_1000.
         */
        public static final String E125_1000 = "E125.1000";

        /**
         * The Constant E125_2000.
         */
        public static final String E125_2000 = "E125.2000";

        /**
         * The Constant E125_9999.
         */
        public static final String E125_9999 = "E125.9999";

        /**
         * The Constant E132_InvalidData.
         */
        public static final String E132_InvalidData = "E132.InvalidData";

        /**
         * The Constant E132_0001.
         */
        public static final String E132_ServiceAvailable = "E132.ServiceAvailable";

        /**
         * The Constant E132_0000.
         */
        public static final String E132_Successful = "E132.Successful";

        /**
         * The Constant E132_0099.
         */
        public static final String E132_UnexpectedError = "E132.UnexpectedError";

        /**
         * The Constant E189_FailedToStoreData.
         */
        public static final String E189_FailedToStoreData = "E189.FailedToStoreData";

        /**
         * The Constant E189_InvalidData.
         */
        public static final String E189_InvalidData = "E189.InvalidData";

        /**
         * The Constant E189_ServiceAvailable.
         */
        public static final String E189_ServiceAvailable = "E189.ServiceAvailable";

        /**
         * The Constant E189_Successful.
         */
        public static final String E189_Successful = "E189.Successful";

        /**
         * The Constant E189_UnexpectedError.
         */
        public static final String E189_UnexpectedError = "E189.UnexpectedError";
    }

    /**
     * The Class Source.
     */
    public class Source {

        /**
         * The Constant E119 BLACKBOX CaptureRequestService.
         */
        public static final String E119 = "E119";

        /**
         * The Constant E120 ReceiverInfoService.
         */
        public static final String E120 = "E120";

        /**
         * The Constant E125 DataTransfer.
         */
        public static final String E125 = "E125";

        /**
         * The Constant E128 VAM CaptureResultService.
         */
        public static final String E128 = "E128";

        /**
         * The Constant E132 ParcelService.
         */
        public static final String E132 = "E132";

        /**
         * The Constant E134 PADASA BarcodeService.
         */
        public static final String E134 = "E134";

        /**
         * The Constant E138 PADASA MatchMakerService.
         */
        public static final String E138 = "E138";

        /**
         * The Constant E189 DPMService.
         */
        public static final String E189 = "E189";

        /**
         * The Constant E190.
         */
        public static final String E190 = "E190";
    }

    /**
     * The Interface WsProperties.
     */
    public interface WsProperties {

        /** The Constant ADDRESSING_ACTION. */
        public static final java.lang.String ADDRESSING_ACTION = "com.sun.xml.internal.ws.api.addressing.action";

        /** The Constant ADDRESSING_FROM. */
        public static final java.lang.String ADDRESSING_FROM = "com.sun.xml.internal.ws.api.addressing.from";

        /** The Constant ADDRESSING_MESSAGEID. */
        public static final java.lang.String ADDRESSING_MESSAGEID = "com.sun.xml.internal.ws.api.addressing.messageId";

        /** The Constant ADDRESSING_TO. */
        public static final java.lang.String ADDRESSING_TO = "com.sun.xml.internal.ws.api.addressing.to";

        /** The Constant CONNECT_TIMEOUT. */
        public static final java.lang.String CONNECT_TIMEOUT = "com.sun.xml.internal.ws.connect.timeout";

        /** The Constant HOSTNAME_VERIFIER. */
        public static final java.lang.String HOSTNAME_VERIFIER = "com.sun.xml.internal.ws.transport.https.client.hostname.verifier";

        /** The Constant HTTP_CLIENT_STREAMING_CHUNK_SIZE. */
        public static final java.lang.String HTTP_CLIENT_STREAMING_CHUNK_SIZE = "com.sun.xml.internal.ws.transport.http.client.streaming.chunk.size";

        /** The Constant HTTP_REQUEST_URL. */
        public static final java.lang.String HTTP_REQUEST_URL = "com.sun.xml.internal.ws.transport.http.servlet.requestURL";

        /** The Constant INBOUND_HEADER_LIST_PROPERTY. */
        public static final java.lang.String INBOUND_HEADER_LIST_PROPERTY = "com.sun.xml.internal.ws.api.message.HeaderList";

        /** The Constant REQUEST_TIMEOUT. */
        public static final java.lang.String REQUEST_TIMEOUT = "com.sun.xml.internal.ws.request.timeout";

        /** The Constant REST_BINDING. */
        public static final java.lang.String REST_BINDING = "http://jax-ws.dev.java.net/rest";

        /** The Constant SSL_SOCKET_FACTORY. */
        public static final java.lang.String SSL_SOCKET_FACTORY = "com.sun.xml.internal.ws.transport.https.client.SSLSocketFactory";

        /** The Constant WSENDPOINT. */
        public static final java.lang.String WSENDPOINT = "com.sun.xml.internal.ws.api.server.WSEndpoint";
    }

    /** The Constant EMPTY_KEY. */
    public static final String EMPTY_KEY = "3010";

    /** The Constant FORMAT_DEFAULT_DATE_TIME. */
    public static final String FORMAT_DEFAULT_DATE_TIME = "yyyy-MM-dd HH:mm:ss";

    /**
     * Constructs a new <tt>DDSConstant</tt>.
     */
    private DDSConstant() {
    }
}
