/*
 * Class: AbstractCacheListener
 *
 * Created on May 5, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.listener.impl;

import org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent;

/**
 * The listener interface for receiving abstractCache events. The class that is
 * interested in processing a abstractCache event implements this interface, and
 * the object created with that class is registered with a component using the
 * component's <code>addAbstractCacheListener<code> method. When the
 * abstractCache event occurs, that object's appropriate method is invoked.
 *
 * @param <K>
 *            the key type
 * @param <V>
 *            the value type
 * @see AbstractCacheEvent
 */
public abstract class AbstractCacheListener<K, V> {

    /**
     * Checks if is valid.
     *
     * @param event
     *            the event
     * @return true, if is valid
     */
    private boolean isValid(final CacheEntryEvent<K, V> event) {
        return (event != null) && (event.getValue() != null) && !event.isPre();// && event.isOriginLocal();
    }

    /**
     * Checks if is valid added event.
     *
     * @param event
     *            the event
     * @return true, if is valid added event
     */
    protected boolean isValidAddedEvent(final CacheEntryCreatedEvent<K, V> event) {
        return this.isValid(event) && !event.isCommandRetried();
    }

    /**
     * Checks if is valid modified event.
     *
     * @param event the event
     * @return true, if is valid modified event
     */
    protected boolean isValidModifiedEvent(final CacheEntryModifiedEvent<K, V> event) {
        return this.isValid(event) && !event.isCommandRetried();
    }

}
