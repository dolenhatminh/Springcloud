
package vn.sps.aba.dds.common.types.ws.pds.parcel.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FullAddress complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FullAddress">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AddressType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Angle" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Ort" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Postleitzahl" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Strasse" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Strassennummer" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Vertices" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="X1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="X2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="X3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="X4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Y1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Y2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Y3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Y4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ZipBase" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FullAddress", propOrder = {
    "addressType",
    "angle",
    "ort",
    "postleitzahl",
    "strasse",
    "strassennummer",
    "vertices",
    "x1",
    "x2",
    "x3",
    "x4",
    "y1",
    "y2",
    "y3",
    "y4",
    "zipBase"
})
public class FullAddress {

    @XmlElement(name = "AddressType", required = true, nillable = true)
    protected String addressType;
    @XmlElement(name = "Angle", required = true, nillable = true)
    protected String angle;
    @XmlElement(name = "Ort", required = true, nillable = true)
    protected String ort;
    @XmlElement(name = "Postleitzahl", required = true, nillable = true)
    protected String postleitzahl;
    @XmlElement(name = "Strasse", required = true, nillable = true)
    protected String strasse;
    @XmlElement(name = "Strassennummer", required = true, nillable = true)
    protected String strassennummer;
    @XmlElement(name = "Vertices", required = true, nillable = true)
    protected String vertices;
    @XmlElement(name = "X1", required = true, nillable = true)
    protected String x1;
    @XmlElement(name = "X2", required = true, nillable = true)
    protected String x2;
    @XmlElement(name = "X3", required = true, nillable = true)
    protected String x3;
    @XmlElement(name = "X4", required = true, nillable = true)
    protected String x4;
    @XmlElement(name = "Y1", required = true, nillable = true)
    protected String y1;
    @XmlElement(name = "Y2", required = true, nillable = true)
    protected String y2;
    @XmlElement(name = "Y3", required = true, nillable = true)
    protected String y3;
    @XmlElement(name = "Y4", required = true, nillable = true)
    protected String y4;
    @XmlElement(name = "ZipBase", required = true, nillable = true)
    protected String zipBase;

    /**
     * Gets the value of the addressType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressType() {
        return addressType;
    }

    /**
     * Sets the value of the addressType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressType(String value) {
        this.addressType = value;
    }

    /**
     * Gets the value of the angle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAngle() {
        return angle;
    }

    /**
     * Sets the value of the angle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAngle(String value) {
        this.angle = value;
    }

    /**
     * Gets the value of the ort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrt() {
        return ort;
    }

    /**
     * Sets the value of the ort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrt(String value) {
        this.ort = value;
    }

    /**
     * Gets the value of the postleitzahl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostleitzahl() {
        return postleitzahl;
    }

    /**
     * Sets the value of the postleitzahl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostleitzahl(String value) {
        this.postleitzahl = value;
    }

    /**
     * Gets the value of the strasse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrasse() {
        return strasse;
    }

    /**
     * Sets the value of the strasse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrasse(String value) {
        this.strasse = value;
    }

    /**
     * Gets the value of the strassennummer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrassennummer() {
        return strassennummer;
    }

    /**
     * Sets the value of the strassennummer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrassennummer(String value) {
        this.strassennummer = value;
    }

    /**
     * Gets the value of the vertices property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVertices() {
        return vertices;
    }

    /**
     * Sets the value of the vertices property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVertices(String value) {
        this.vertices = value;
    }

    /**
     * Gets the value of the x1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX1() {
        return x1;
    }

    /**
     * Sets the value of the x1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX1(String value) {
        this.x1 = value;
    }

    /**
     * Gets the value of the x2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX2() {
        return x2;
    }

    /**
     * Sets the value of the x2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX2(String value) {
        this.x2 = value;
    }

    /**
     * Gets the value of the x3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX3() {
        return x3;
    }

    /**
     * Sets the value of the x3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX3(String value) {
        this.x3 = value;
    }

    /**
     * Gets the value of the x4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX4() {
        return x4;
    }

    /**
     * Sets the value of the x4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX4(String value) {
        this.x4 = value;
    }

    /**
     * Gets the value of the y1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getY1() {
        return y1;
    }

    /**
     * Sets the value of the y1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setY1(String value) {
        this.y1 = value;
    }

    /**
     * Gets the value of the y2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getY2() {
        return y2;
    }

    /**
     * Sets the value of the y2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setY2(String value) {
        this.y2 = value;
    }

    /**
     * Gets the value of the y3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getY3() {
        return y3;
    }

    /**
     * Sets the value of the y3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setY3(String value) {
        this.y3 = value;
    }

    /**
     * Gets the value of the y4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getY4() {
        return y4;
    }

    /**
     * Sets the value of the y4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setY4(String value) {
        this.y4 = value;
    }

    /**
     * Gets the value of the zipBase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZipBase() {
        return zipBase;
    }

    /**
     * Sets the value of the zipBase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZipBase(String value) {
        this.zipBase = value;
    }

}
