
package vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.NormalizedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for parcelData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="parcelData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CodingKey" type="{http://www.post.ch/esb/PdsWSTypes}codingKey" minOccurs="0"/>
 *         &lt;element name="ACSKeyInfo" type="{http://www.post.ch/esb/PdsWSTypes}acsKeyInfo"/>
 *         &lt;element name="IdentCode" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.post.ch/esb/PdsWSTypes}identCode">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="PICID" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.post.ch/esb/PdsWSTypes}PICID">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="BarCodeData" type="{http://www.post.ch/esb/PdsWSTypes}barCodeData" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "parcelData", propOrder = {
    "codingKey",
    "acsKeyInfo",
    "identCode",
    "picid",
    "barCodeData"
})
public class ParcelData {

    @XmlElement(name = "CodingKey")
    protected CodingKey codingKey;
    @XmlElement(name = "ACSKeyInfo", required = true)
    protected AcsKeyInfo acsKeyInfo;
    @XmlElement(name = "IdentCode")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String identCode;
    @XmlElement(name = "PICID")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String picid;
    @XmlElement(name = "BarCodeData")
    protected List<BarCodeData> barCodeData;

    /**
     * Gets the value of the codingKey property.
     * 
     * @return
     *     possible object is
     *     {@link CodingKey }
     *     
     */
    public CodingKey getCodingKey() {
        return codingKey;
    }

    /**
     * Sets the value of the codingKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link CodingKey }
     *     
     */
    public void setCodingKey(CodingKey value) {
        this.codingKey = value;
    }

    /**
     * Gets the value of the acsKeyInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AcsKeyInfo }
     *     
     */
    public AcsKeyInfo getACSKeyInfo() {
        return acsKeyInfo;
    }

    /**
     * Sets the value of the acsKeyInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AcsKeyInfo }
     *     
     */
    public void setACSKeyInfo(AcsKeyInfo value) {
        this.acsKeyInfo = value;
    }

    /**
     * Gets the value of the identCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentCode() {
        return identCode;
    }

    /**
     * Sets the value of the identCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentCode(String value) {
        this.identCode = value;
    }

    /**
     * Gets the value of the picid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPICID() {
        return picid;
    }

    /**
     * Sets the value of the picid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPICID(String value) {
        this.picid = value;
    }

    /**
     * Gets the value of the barCodeData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the barCodeData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBarCodeData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BarCodeData }
     * 
     * 
     */
    public List<BarCodeData> getBarCodeData() {
        if (barCodeData == null) {
            barCodeData = new ArrayList<BarCodeData>();
        }
        return this.barCodeData;
    }

}
