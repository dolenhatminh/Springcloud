/*
 * Class: ScheduledTaskInfo
 *
 * Created on Oct 24, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.jmx;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;

/**
 * The Interface ScheduledTaskInfo.
 */
public interface ScheduledTaskInfo {

    /**
     * Empty queue.
     *
     * @param key the key
     * @return the int
     */
    @ManagedOperation
    int emptyQueue(String key);

    /**
     * Gets the cron expression.
     *
     * @return the cron expression
     */
    @ManagedAttribute
    String getCronExpression();

    /**
     * Gets the number of remain items.
     *
     * @return the number of remain items
     */
    @ManagedAttribute
    int getNumberOfRemainItems();

    /**
     * Gets the task name.
     *
     * @return the task name
     */
    @ManagedAttribute
    String getTaskName();

    /**
     * Sets the enable.
     *
     * @param enable the new enable
     */
    @ManagedOperation
    void setEnable(boolean enable);
}
