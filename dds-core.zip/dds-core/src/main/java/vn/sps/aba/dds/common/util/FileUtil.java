package vn.sps.aba.dds.common.util;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;

import vn.sps.aba.dds.common.constant.Constant;

/**
 * The Class FileUtil.
 */
public final class FileUtil {

    /**
     * Gets the location.
     *
     * @return the location
     */
    public static String currentLocation() {
        return System.getProperty("user.dir");
    }

    /**
     * Exist.
     *
     * @param filePath
     *            the file path
     * @return true, if successful
     */
    public static boolean exist(final String filePath) {
        boolean ret = false;

        if ((filePath != null) && !filePath.isEmpty()) {
            ret = new File(filePath).exists();
        }

        return ret;
    }

    /**
     * Read file to byte array.
     *
     * @param filePath the file path
     * @return the byte[]
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static byte[] readFileToByteArray(final String filePath) throws IOException {
        return FileUtils.readFileToByteArray(new File(filePath));
    }

    /**
     * Relative path2 absolute path.
     *
     * @param relativePath
     *            the relative path
     * @return the string
     */
    public static String relativePath2AbsolutePath(final String relativePath) {
        String ret = FileUtil.currentLocation();

        if (relativePath != null) {
            ret = ret + Constant.FILE_SEPARATOR + relativePath;
            ret = ret.replace("//", "/");
        }

        return ret;
    }

    /**
     * Write byte array to file.
     *
     * @param file the file
     * @param bytes the bytes
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static void writeByteArrayToFile(final File file, final byte[] bytes) throws IOException {
        FileUtils.writeByteArrayToFile(file, bytes);
    }

    /**
     * Write byte array to file.
     *
     * @param directory
     *            the directory
     * @param fileName
     *            the file name
     * @param bytes
     *            the bytes
     * @return the string
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public static String writeByteArrayToFile(final String directory, final String fileName, final byte[] bytes) throws IOException {

        final String filePath = directory + Constant.FILE_SEPARATOR + fileName;

        FileUtils.writeByteArrayToFile(new File(filePath), bytes);

        return filePath;
    }

    /**
     * Instantiates a new file utility.
     */
    private FileUtil() {
    }

    /**
     * Get alternative file, will return a non-existed file if the file in
     * <tt>filePath</tt> is already existed.
     *
     * @param file
     *            the file that may need a non-existed alternative
     * @return a non-existed file, if the inputed file is not existed, itself
     *         will be returned.
     */
    public File getAlternativeFile(final File file) {

        if (!file.isFile() || !file.exists()) {
            return file;
        }
        final String fileName = file.getName();
        String altName = fileName + Calendar.getInstance().getTimeInMillis();
        if (fileName.contains(Constant.CHAR_DOT)) {
            altName = fileName.substring(0, fileName.lastIndexOf(Constant.CHAR_DOT)) + Calendar.getInstance().getTimeInMillis()
                    + fileName.substring(fileName.lastIndexOf(Constant.CHAR_DOT), fileName.length());
        }
        final File alt = new File(file.getParentFile(), altName);
        return this.getAlternativeFile(alt);
    }

}
