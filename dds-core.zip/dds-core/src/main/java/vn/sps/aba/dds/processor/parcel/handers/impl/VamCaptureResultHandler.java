/*
 * Class: VamCaptureResultHandler
 *
 * Created on Jul 21, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.parcel.handers.impl;

import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.parcel.handers.IParcelStepHandler;
import vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext;

/**
 * The Class VamCaptureResultHandler.
 */
public class VamCaptureResultHandler extends AbstractParcelStepHandler implements IParcelStepHandler {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(VamCaptureResultHandler.class);

    /**
     * Instantiates a new vam capture result handler.
     */
    public VamCaptureResultHandler() {
        super(PARCEL_STATE_VAM_CAPTURE_RESULT_HANDLER);
    }

    /**
     * {@inheritDoc}
     *
     * @throws ExecutionException
     * @throws InterruptedException
     *
     * @see vn.sps.aba.dds.processor.parcel.handers.IParcelStepHandler#handle(vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public void handle(final IParcelStateHandlerContext context, final ParcelInfo parcelInfo) throws InterruptedException, ExecutionException {

        LOG.info(IndexMaker.index(parcelInfo), "Submit parcel info to VAM sender.");
        context.submitCaptureResult(parcelInfo);
        context.handle(PARCEL_STATE_DMCING, parcelInfo);
    }
}
