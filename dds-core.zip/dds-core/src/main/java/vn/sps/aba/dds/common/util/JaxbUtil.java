/*
 * Class: JaxbUtil
 *
 * Created on Jul 12, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.util;

import javax.xml.bind.JAXBElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class JaxbUtil.
 */
public final class JaxbUtil {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(JaxbUtil.class);

    /**
     * Element2 string.
     *
     * @param element the element
     * @return the string
     */
    public static String element2String(final JAXBElement<String> element) {
        return element == null ? null : element.getValue();
    }

    /**
     * Less than one number.
     *
     * @param element the element
     * @return true, if successful
     */
    public static boolean lessThanOne(final JAXBElement<String> element) {
        boolean ret = true;

        if ((element != null) && (element.getValue() != null)) {
            try {
                ret = Integer.valueOf(element.getValue()).intValue() <= 0;
            }
            catch (final Exception e) {
                LOG.debug("Invalid integer format", e);
            }
        }

        return ret;
    }

    /**
     * Null or empty.
     *
     * @param element the element
     * @return true, if successful
     */
    public static boolean nullOrEmpty(final JAXBElement<String> element) {
        return (element == null) || (element.getValue() == null) || element.getValue().isEmpty();
    }

    /**
     * Instantiates a new jaxb util.
     */
    private JaxbUtil() {
    }
}