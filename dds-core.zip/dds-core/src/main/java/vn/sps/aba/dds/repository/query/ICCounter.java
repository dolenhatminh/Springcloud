/*
 * Class: ICCounter
 *
 * Created on Nov 4, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.query;

/**
 * The Class ICCounter.
 */
public class ICCounter {

    /** The count. */
    private int count;

    /** The ident code. */
    private String identCode;

    /**
     * Instantiates a new IC counter.
     */
    public ICCounter() {
    }

    /**
     * Instantiates a new IC counter.
     *
     * @param identCode the ident code
     * @param count the count
     */
    public ICCounter(final String identCode, final int count) {
        this.identCode = identCode;
        this.count = count;
    }

    /**
     * Gets the count.
     *
     * @return the count
     */
    public int getCount() {
        return this.count;
    }

    /**
     * Gets the ident code.
     *
     * @return the ident code
     */
    public String getIdentCode() {
        return this.identCode;
    }

    /**
     * Sets the count.
     *
     * @param count the new count
     */
    public void setCount(final int count) {
        this.count = count;
    }

    /**
     * Sets the ident code.
     *
     * @param identCode the new ident code
     */
    public void setIdentCode(final String identCode) {
        this.identCode = identCode;
    }
}
