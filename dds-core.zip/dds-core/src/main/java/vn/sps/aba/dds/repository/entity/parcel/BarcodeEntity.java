package vn.sps.aba.dds.repository.entity.parcel;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import vn.sps.aba.dds.common.constant.TableNames;
import vn.sps.aba.dds.common.model.parcel.Barcode;

/**
 * The Class BarcodeEntity.
 */
@Entity
@Table(name = TableNames.PAR_BARCODE, indexes = { @Index(name = "par_barcode_id", columnList = "id") })
@Access(AccessType.PROPERTY)
public class BarcodeEntity implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1049337442215662645L;

    /** The code. */
    private String code;

    /** The confidence. */
    private Integer confidence;

    /** The edges. */
    private String edges;

    /** The format. */
    private String format;

    /** The id. */
    private Long id;

    /** The kind. */
    private int kind;

    /** The parcel info. */
    private ParcelInfoEntity parcelInfo;

    /** The type. */
    private String type;

    /** The x1. */
    private String x1;

    /** The x2. */
    private String x2;

    /** The x3. */
    private String x3;

    /** The x4. */
    private String x4;

    /** The y1. */
    private String y1;

    /** The y2. */
    private String y2;

    /** The y3. */
    private String y3;

    /** The y4. */
    private String y4;

    /**
     * Instantiates a new barcode entity.
     */
    public BarcodeEntity() {
    }

    /**
     * Instantiates a new barcode entity.
     *
     * @param barcode
     *            the barcode
     */
    public BarcodeEntity(final Barcode barcode) {
        this.setCode(barcode.getCode());
        this.setEdges(barcode.getEdges());
        this.setKind(barcode.getKind());
        this.setType(barcode.getType());

        if (barcode.getBoundary() != null) {
            this.setX1(barcode.getBoundary().getX1());
            this.setX2(barcode.getBoundary().getX2());
            this.setX3(barcode.getBoundary().getX3());
            this.setX4(barcode.getBoundary().getX4());
            this.setY1(barcode.getBoundary().getY1());
            this.setY2(barcode.getBoundary().getY2());
            this.setY3(barcode.getBoundary().getY3());
            this.setY4(barcode.getBoundary().getY4());
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.parcel.Barcode#getCode()
     **/

    @Column(name = "code", length = 250)
    public String getCode() {
        return this.code;
    }

    /**
     * Gets the confidence.
     *
     * @return the confidence
     */
    @Column(name = "confidence")
    public Integer getConfidence() {
        return this.confidence;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.parcel.Barcode#getEdges()
     **/

    @Column(name = "edges", length = 100)
    public String getEdges() {
        return this.edges;
    }

    /**
     * Gets the format.
     *
     * @return the format
     */
    @Column(name = "format")
    public String getFormat() {
        return this.format;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    @Id
    @SequenceGenerator(name = "barcode_generator", sequenceName = "par_barcode_seq", initialValue = 1, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "barcode_generator")
    @Column(name = "id", columnDefinition = "bigserial")
    public Long getId() {
        return this.id;
    }

    /**
     * Gets the kind.
     *
     * @return the kind
     */
    public int getKind() {
        return this.kind;
    }

    /**
     * Gets the parcel info.
     *
     * @return the parcel info
     */
    @ManyToOne
    @JoinColumn(name = "parcel_info_id")
    public ParcelInfoEntity getParcelInfo() {
        return this.parcelInfo;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.parcel.Barcode#getType()
     **/

    @Column(name = "type", length = 50)
    public String getType() {
        return this.type;
    }

    /**
     * Gets the x1.
     *
     * @return the x1
     */
    @Column(name = "x1", length = 10)
    public String getX1() {
        return this.x1;
    }

    /**
     * Gets the x2.
     *
     * @return the x2
     */
    @Column(name = "x2", length = 10)
    public String getX2() {
        return this.x2;
    }

    /**
     * Gets the x3.
     *
     * @return the x3
     */
    @Column(name = "x3", length = 10)
    public String getX3() {
        return this.x3;
    }

    /**
     * Gets the x4.
     *
     * @return the x4
     */
    @Column(name = "x4", length = 10)
    public String getX4() {
        return this.x4;
    }

    /**
     * Gets the y1.
     *
     * @return the y1
     */
    @Column(name = "y1", length = 10)
    public String getY1() {
        return this.y1;
    }

    /**
     * Gets the y2.
     *
     * @return the y2
     */
    @Column(name = "y2", length = 10)
    public String getY2() {
        return this.y2;
    }

    /**
     * Gets the y3.
     *
     * @return the y3
     */
    @Column(name = "y3", length = 10)
    public String getY3() {
        return this.y3;
    }

    /**
     * Gets the y4.
     *
     * @return the y4
     */
    @Column(name = "y4", length = 10)
    public String getY4() {
        return this.y4;
    }

    /**
     * Sets the code.
     *
     * @param code
     *            the new code
     */
    public void setCode(final String code) {
        this.code = code;
    }

    /**
     * Sets the confidence.
     *
     * @param confidence the new confidence
     */
    public void setConfidence(final Integer confidence) {
        this.confidence = confidence;
    }

    /**
     * Sets the edges.
     *
     * @param edges
     *            the new edges
     */
    public void setEdges(final String edges) {
        this.edges = edges;
    }

    /**
     * Sets the format.
     *
     * @param format the new format
     */
    public void setFormat(final String format) {
        this.format = format;
    }

    /**
     * Sets the id.
     *
     * @param id
     *            the new id
     */
    public void setId(final Long id) {
        this.id = id;
    }

    /**
     * Sets the kind.
     *
     * @param kind
     *            the new kind
     */
    public void setKind(final int kind) {
        this.kind = kind;
    }

    /**
     * Sets the parcel info.
     *
     * @param parcelInfo
     *            the new parcel info
     */
    public void setParcelInfo(final ParcelInfoEntity parcelInfo) {
        this.parcelInfo = parcelInfo;
    }

    /**
     * Sets the type.
     *
     * @param type
     *            the new type
     */
    public void setType(final String type) {
        this.type = type;
    }

    /**
     * Sets the x1.
     *
     * @param x1
     *            the new x1
     */
    public void setX1(final String x1) {
        this.x1 = x1;
    }

    /**
     * Sets the x2.
     *
     * @param x2
     *            the new x2
     */
    public void setX2(final String x2) {
        this.x2 = x2;
    }

    /**
     * Sets the x3.
     *
     * @param x3
     *            the new x3
     */
    public void setX3(final String x3) {
        this.x3 = x3;
    }

    /**
     * Sets the x4.
     *
     * @param x4
     *            the new x4
     */
    public void setX4(final String x4) {
        this.x4 = x4;
    }

    /**
     * Sets the y1.
     *
     * @param y1
     *            the new y1
     */
    public void setY1(final String y1) {
        this.y1 = y1;
    }

    /**
     * Sets the y2.
     *
     * @param y2
     *            the new y2
     */
    public void setY2(final String y2) {
        this.y2 = y2;
    }

    /**
     * Sets the y3.
     *
     * @param y3
     *            the new y3
     */
    public void setY3(final String y3) {
        this.y3 = y3;
    }

    /**
     * Sets the y4.
     *
     * @param y4
     *            the new y4
     */
    public void setY4(final String y4) {
        this.y4 = y4;
    }
}
