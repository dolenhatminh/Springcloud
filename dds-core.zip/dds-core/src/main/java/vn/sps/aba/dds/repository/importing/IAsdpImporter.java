/*
 * Class: IAsdpImporter
 * 
 * Created on Sep 14, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.importing;

import vn.sps.aba.dds.repository.importing.report.IAsdpImportingReport;

/**
 * The Interface IAsdpImporter.
 */
public interface IAsdpImporter {
    
    /**
     * Import data.
     *
     * @return the int
     */
    IAsdpImportingReport importData();
}
