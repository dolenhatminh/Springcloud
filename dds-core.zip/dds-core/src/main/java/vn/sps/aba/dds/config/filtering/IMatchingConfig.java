/*
 * Class: IMatchingConfig
 *
 * Created on Jul 25, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.config.filtering;

import java.util.List;

import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;

/**
 * The Interface IMatchingConfig.
 */
public interface IMatchingConfig {

    /**
     * Gets the default status after filter.
     *
     * @return the default status after filter
     */
    ParcelState getDefaultStatusAfterFilter();

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.task.IParcelProcessConfig#getMatchedStates()
     */
    List<String> getMatchedStates();

}