/*
 * Class: GenericValidator
 *
 * Created on Jun 13, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.dts.impl;

import vn.sps.aba.dds.common.types.ws.dts.model.ReceiverInfoRecord;
import vn.sps.aba.dds.service.validation.AbstractGenericValidator;
import vn.sps.aba.dds.service.validation.dts.IDataTransferValidator;
import vn.sps.aba.dds.service.validation.model.ReceiverInfoValidationResult;

/**
 * The Class GenericReceiverInfoValidator.
 */
abstract class AbstractReceiverInfoValidator extends AbstractGenericValidator<ReceiverInfoRecord, ReceiverInfoValidationResult>
        implements IDataTransferValidator {

    /**
     * Constructs a new <tt>GenericReceiverInfoValidator</tt>.
     */
    public AbstractReceiverInfoValidator() {
        super(ReceiverInfoValidationResult.class);
    }
}
