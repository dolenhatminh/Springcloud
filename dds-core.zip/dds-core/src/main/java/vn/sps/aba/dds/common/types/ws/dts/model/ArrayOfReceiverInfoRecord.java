
package vn.sps.aba.dds.common.types.ws.dts.model;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArrayOfReceiverInfoRecord complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfReceiverInfoRecord">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ReceiverInfoRecord" type="{http://www.postlogistics.ch/PLDTVG/V10/}ReceiverInfoRecord" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfReceiverInfoRecord", propOrder = {
    "receiverInfoRecord"
})
public class ArrayOfReceiverInfoRecord {

    @XmlElement(name = "ReceiverInfoRecord", namespace = "http://www.postlogistics.ch/PLDTVG/V10/", required = true)
    protected List<ReceiverInfoRecord> receiverInfoRecord;

    /**
     * Gets the value of the receiverInfoRecord property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the receiverInfoRecord property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReceiverInfoRecord().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReceiverInfoRecord }
     * 
     * 
     */
    public List<ReceiverInfoRecord> getReceiverInfoRecord() {
        if (receiverInfoRecord == null) {
            receiverInfoRecord = new ArrayList<ReceiverInfoRecord>();
        }
        return this.receiverInfoRecord;
    }

}
