/*
 * Class: IdentCodeValidator
 *
 * Created on Jun 13, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.dts.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.types.ws.dts.model.ReceiverInfoRecord;

/**
 * The Class IdentCodeValidator.
 */
public class IdentCodeValidator extends AbstractReceiverInfoValidator {

    /** The Constant LOG. */
    private final static Logger LOG = LoggerFactory.getLogger(IdentCodeValidator.class);

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.validation.dts.impl.AbstractReceiverInfoValidator#getMessage()
     */
    @Override
    protected String getMessage() {
        return "The IdentCode length must be 18 characters";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.validation.AbstractGenericValidator#getResponseCode()
     */
    @Override
    protected int getResponseCode() {
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.validation.dts.impl.AbstractReceiverInfoValidator#isPassed(vn.sps.aba.dds.common.types.ws.dts.model.ReceiverInfoRecord)
     */
    @Override
    protected boolean isPassed(final ReceiverInfoRecord entry) {
        LOG.debug("Validating ident code...");
        return (entry.getIdentCode() != null) && (entry.getIdentCode().length() == 18);
    }

}
