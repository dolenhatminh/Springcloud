/*
 * Class: FullAddress
 *
 * Created on May 19, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.parcel;

import java.io.Serializable;

/**
 * The Class FullAddress.
 */
public class FullAddress implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -5103659691918439607L;

    /** The address type. */
    private String addressType;

    /** The angle. */
    private String angle;

    /** The siemens. */
    private Boundary boundary;

    /** The ort. */
    private String ort;

    /** The postleitzahl. */
    private String postleitzahl;

    /** The strasse. */
    private String strasse;

    /** The strassen nummer. */
    private String strassenNummer;

    /** The vertices. */
    private String vertices;

    /** The zip base. */
    private String zipBase;

    /**
     * Constructs a new <tt>FullAddress</tt>.
     */
    public FullAddress() {
    }

    /**
     * Instantiates a new full address.
     *
     * @param address
     *            the <tt>FullAddress</tt> object sent/received via SOAP web
     *            service
     */
    public FullAddress(final vn.sps.aba.dds.common.types.ws.pds.parcel.model.FullAddress address) {
        this.addressType = address.getAddressType();
        this.angle = address.getAngle();
        this.ort = address.getOrt();
        this.strasse = address.getStrasse();
        this.strassenNummer = address.getStrassennummer();
        this.postleitzahl = address.getPostleitzahl();
        this.vertices = address.getVertices();
        this.zipBase = address.getZipBase();

        this.boundary = new Boundary(address);
    }

    /**
     * Gets the address type.
     *
     * @return the address type
     */
    public String getAddressType() {
        return this.addressType;
    }

    /**
     * Gets the angle.
     *
     * @return the angle
     */
    public String getAngle() {
        return this.angle;
    }

    /**
     * Gets the boundary.
     *
     * @return Returns the boundary.
     */
    public Boundary getBoundary() {
        return this.boundary;
    }

    /**
     * Gets the ort.
     *
     * @return Returns the ort.
     */
    public String getOrt() {
        return this.ort;
    }

    /**
     * Gets the postleitzahl.
     *
     * @return Returns the postleitzahl.
     */
    public String getPostleitzahl() {
        return this.postleitzahl;
    }

    /**
     * Gets the strasse.
     *
     * @return Returns the strasse.
     */
    public String getStrasse() {
        return this.strasse;
    }

    /**
     * Gets the strassen nummber.
     *
     * @return Returns the strassenNummber.
     */
    public String getStrassenNummer() {
        return this.strassenNummer;
    }

    /**
     * Gets the vertices.
     *
     * @return the vertices
     */
    public String getVertices() {
        return this.vertices;
    }

    /**
     * Gets the zip base.
     *
     * @return Returns the zipBase.
     */
    public String getZipBase() {
        return this.zipBase;
    }

    /**
     * Sets the address type.
     *
     * @param addressType the new address type
     */
    public void setAddressType(final String addressType) {
        this.addressType = addressType;
    }

    /**
     * Sets the angle.
     *
     * @param angle the new angle
     */
    public void setAngle(final String angle) {
        this.angle = angle;
    }

    /**
     * Sets the boundary.
     *
     * @param boundary
     *            The boundary to set.
     */
    public void setBoundary(final Boundary boundary) {
        this.boundary = boundary;
    }

    /**
     * Sets the ort.
     *
     * @param ort
     *            The ort to set.
     */
    public void setOrt(final String ort) {
        this.ort = ort;
    }

    /**
     * Sets the postleitzahl.
     *
     * @param postleitzahl
     *            The postleitzahl to set.
     */
    public void setPostleitzahl(final String postleitzahl) {
        this.postleitzahl = postleitzahl;
    }

    /**
     * Sets the strasse.
     *
     * @param strasse
     *            The strasse to set.
     */
    public void setStrasse(final String strasse) {
        this.strasse = strasse;
    }

    /**
     * Sets the strassen nummber.
     *
     * @param strassenNummer
     *            The strassenNummber to set.
     */
    public void setStrassenNummer(final String strassenNummer) {
        this.strassenNummer = strassenNummer;
    }

    /**
     * Sets the vertices.
     *
     * @param vertices the new vertices
     */
    public void setVertices(final String vertices) {
        this.vertices = vertices;
    }

    /**
     * Sets the zip base.
     *
     * @param zipBase
     *            The zipBase to set.
     */
    public void setZipBase(final String zipBase) {
        this.zipBase = zipBase;
    }

    /**
     * {@inheritDoc}
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {

        final StringBuilder sb = new StringBuilder();

        sb.append("Postleitzahl:").append(this.postleitzahl).append(";Strasse:").append(this.strasse).append(";StrasseNummer:").append(this.strassenNummer)
            .append(";Ort:").append(this.ort).append(";ZipBase:").append(this.zipBase).append(";AddressType:").append(this.addressType);

        return sb.toString();
    }

}
