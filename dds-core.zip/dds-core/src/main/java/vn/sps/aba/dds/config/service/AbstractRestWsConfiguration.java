/*
 * Class: AbstractRestWsConfiguration
 *
 * Created on Oct 25, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service;

/**
 * The Class AbstractRestWsConfiguration.
 */
public abstract class AbstractRestWsConfiguration extends WsTemplaceConfiguration {

    /** The conn time to live. */
    // TODO -- Check why the connection to live is not work, the pool report the avaiable = 0
    private long connTimeToLive = -1;

    /** The disable automatic retries. */
    private boolean disableAutomaticRetries = true;

    /** The max conn per route. */
    private int maxConnPerRoute;

    /** The max conn total. */
    private int maxConnTotal;

    /** The use custom http client. */
    private boolean useCustomHttpClient = false;

    /**
     * Gets the conn time to live.
     *
     * @return the conn time to live
     */
    public long getConnTimeToLive() {
        return this.connTimeToLive;
    }

    /**
     * Gets the max conn per route.
     *
     * @return the max conn per route
     */
    public int getMaxConnPerRoute() {
        return this.maxConnPerRoute;
    }

    /**
     * Gets the max conn total.
     *
     * @return the max conn total
     */
    public int getMaxConnTotal() {
        return this.maxConnTotal;
    }

    /**
     * Checks if is disable automatic retries.
     *
     * @return true, if is disable automatic retries
     */
    public boolean isDisableAutomaticRetries() {
        return this.disableAutomaticRetries;
    }

    /**
     * Checks if is use custom http client.
     *
     * @return true, if is use custom http client
     */
    public boolean isUseCustomHttpClient() {
        return this.useCustomHttpClient;
    }

    /**
     * Sets the conn time to live.
     *
     * @param connTimeToLive the new conn time to live
     */
    public void setConnTimeToLive(final long connTimeToLive) {
        this.connTimeToLive = connTimeToLive;
    }

    /**
     * Sets the disable automatic retries.
     *
     * @param disableAutomaticRetries the new disable automatic retries
     */
    public void setDisableAutomaticRetries(final boolean disableAutomaticRetries) {
        this.disableAutomaticRetries = disableAutomaticRetries;
    }

    /**
     * Sets the max conn per route.
     *
     * @param maxConnPerRoute the new max conn per route
     */
    public void setMaxConnPerRoute(final int maxConnPerRoute) {
        this.maxConnPerRoute = maxConnPerRoute;
    }

    /**
     * Sets the max conn total.
     *
     * @param maxConnTotal the new max conn total
     */
    public void setMaxConnTotal(final int maxConnTotal) {
        this.maxConnTotal = maxConnTotal;
    }

    /**
     * Sets the use custom http client.
     *
     * @param useCustomHttpClient the new use custom http client
     */
    public void setUseCustomHttpClient(final boolean useCustomHttpClient) {
        this.useCustomHttpClient = useCustomHttpClient;
    }

}
