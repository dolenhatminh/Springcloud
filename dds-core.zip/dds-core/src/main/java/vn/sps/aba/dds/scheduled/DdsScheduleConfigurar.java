/*
 * Class: AbstractScheduledController
 *
 * Created on Aug 19, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled;

import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ScheduledFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.support.CronSequenceGenerator;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.task.scheduler.DdsScheduler;

/**
 * The Class ScheduledController.
 */
@Configuration
@EnableScheduling
@Component
public class DdsScheduleConfigurar implements InitializingBean, DisposableBean {

    /**
     * The Class EvictionTrigger.
     */
    private class ImmortalCronTrigger implements Trigger {

        /** The sequence generator. */
        private CronSequenceGenerator sequenceGenerator;

        /**
         * {@inheritDoc}
         *
         * @param obj
         * @return
         */
        @Override
        public boolean equals(final Object obj) {
            if (!(obj instanceof ImmortalCronTrigger)) {
                return false;
            }
            final ImmortalCronTrigger et = (ImmortalCronTrigger) obj;
            return this.hashCode() == et.hashCode();
        }

        /**
         * {@inheritDoc}
         *
         * @see java.lang.Object#hashCode()
         */
        @Override
        public int hashCode() {
            return this.sequenceGenerator.hashCode();
        }

        /**
         * {@inheritDoc}
         *
         * @see org.springframework.scheduling.Trigger#nextExecutionTime(org.springframework.scheduling.TriggerContext)
         */
        @Override
        public Date nextExecutionTime(final TriggerContext triggerContext) {
            Date date = triggerContext.lastCompletionTime();
            if (date != null) {
                final Date scheduled = triggerContext.lastScheduledExecutionTime();
                if ((scheduled != null) && date.before(scheduled)) {
                    date = scheduled;
                }
            }
            else {
                date = new Date();
            }
            return this.sequenceGenerator.next(date);
        }

        /**
         * Sets the sequence generator.
         *
         * @param taskName the task name
         * @param expression the new sequence generator
         */
        public void setSequenceGenerator(final String taskName, final String expression) {
            this.sequenceGenerator = new CronSequenceGenerator(expression);
            LOG.debug("Initialize cron scheduler for {} with cron expression {}", taskName, expression);
        }

        /**
         * {@inheritDoc}
         *
         * @see java.lang.Object#toString()
         */
        @Override
        public String toString() {
            return this.sequenceGenerator.toString();
        }
    }

    /**
     * The Class ScheduledTask.
     */
    private class ScheduledTask {

        /** The future. */
        private ScheduledFuture<?> future;

        /** The name. */
        private String name;
    }

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DdsScheduleConfigurar.class);

    /** The scheduled futures. */
    private final Set<ScheduledTask> scheduledFutures = new LinkedHashSet<>();

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        // This method is not used
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.beans.factory.DisposableBean#destroy()
     */
    @Override
    public void destroy() throws Exception {

    }

    /**
     * Destroy.
     *
     * @param name the name
     */
    public void destroy(final String name) {
        LOG.debug("Find and cancel tasks with name {}", name);
        for (final ScheduledTask scheduledTask : this.scheduledFutures) {

            if (scheduledTask.name.equals(name)) {

                scheduledTask.future.cancel(true);
            }
        }
    }

    /**
     * Register scheduled task.
     *
     * @param task the task
     * @param scheduler the scheduler
     */
    public void registerScheduledTask(final DdsScheduledTask task, final DdsScheduler scheduler) {
        if (!StringUtil.notNullOrEmpty(task.taskName())) {
            throw new IllegalArgumentException("Task name must not null or empty.");
        }
        if (scheduler == null) {
            throw new IllegalArgumentException("Must provide a scheduler");
        }
        this.destroy(task.taskName());
        LOG.info("Configure scheduled task {} with cron {} ...", task.taskName(), task.getCronExpression());
        final ImmortalCronTrigger trigger = new ImmortalCronTrigger();
        trigger.setSequenceGenerator(task.taskName(), task.getCronExpression());

        final ScheduledTask scheduledTask = new ScheduledTask();
        {
            scheduledTask.name = task.taskName();
            scheduledTask.future = scheduler.getScheduler().schedule(task.handleTask(), trigger);
        }
        this.scheduledFutures.add(scheduledTask);
    }
}