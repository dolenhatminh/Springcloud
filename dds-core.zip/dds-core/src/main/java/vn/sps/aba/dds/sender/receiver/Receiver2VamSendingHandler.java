/*
 * Class: MatchMakerSendingHandler
 *
 * Created on Oct 27, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.sender.receiver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.sender.Receiver2VamSendingExecutor;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.logging.report.ReceiverInfoReport;
import vn.sps.aba.dds.scheduled.sender.IScheduledSender;
import vn.sps.aba.dds.sender.receiver.interfaces.IReceiver2VamSender;
import vn.sps.aba.dds.service.vam.ICaptureResultService;

/**
 * The Class MatchMakerSendingHandler.
 */
@Component("Receiver2VamSendingHandler")
public class Receiver2VamSendingHandler extends AbstractReceiverSender implements IReceiver2VamSender {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(Receiver2VamSendingHandler.class);

    /** The executor. */
    @Autowired
    private Receiver2VamSendingExecutor executor;

    /** The matchmaker scheduled sender. */
    @Autowired
    @Qualifier("Receiver2VamScheduledSender")
    private IScheduledSender<ReceiverInfo> scheduledSender;

    /** The match maker daten service. */
    @Autowired
    private ICaptureResultService service;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected TaskConfiguration getExecutor() {
        return this.executor;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.sender.receiver.AbstractReceiverSender#getScheduledSender()
     */
    @Override
    protected IScheduledSender<ReceiverInfo> getScheduledSender() {
        return this.scheduledSender;
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.sender.IExternalSender#getSenderName()
     */
    @Override
    public String getSenderName() {
        return "RCaptureResult sender";
    }

    /**
     * {@inheritDoc}
     * NOTE: SINCE ABA-89 HAS ONLY USED ENUM: 
     * ReceiverState.VAM_PADASA_READY_NOT_MATCHING; VAM_PADASA_READY 
     * ReceiverState.VAM_PADASA_SENT
     * ReceiverState.PADASA_SENT_NOT_MATCHING; PADASA_SENT
     * ReceiverState.VAM_SENT
     * @see vn.sps.aba.dds.sender.receiver.AbstractReceiverSender#handleItem(vn.sps.aba.dds.common.model.receiver.ReceiverInfo, boolean)
     */
    @Override
    protected Runnable handleItem(final ReceiverInfo receiverInfo, final boolean isRetry) {
        return () -> {

            try {
                LOG.info(IndexMaker.index(receiverInfo), "Transfer receiver to VAM CaptureResult service");
                if (this.service.transferToVamStation(receiverInfo)) {
                    switch (receiverInfo.getReceiverState()) {
                    case VAM_PADASA_READY_NOT_MATCHING:
                    	 receiverInfo.setState(ReceiverState.VAM_SENT_NOT_MATCHING);
                         break;
                    case VAM_PADASA_READY:
                        receiverInfo.setState(ReceiverState.VAM_SENT);
                        break;
                    case PADASA_SENT_NOT_MATCHING:
                    	receiverInfo.setState(ReceiverState.VAM_PADASA_SENT_NOT_MATCHING);
                    	LOG.info(IndexMaker.indexes(new ReceiverInfoReport(receiverInfo), "receiverInfoReport"), "Insert logs receiver_info");
                        break;
                    case PADASA_SENT:
                        receiverInfo.setState(ReceiverState.VAM_PADASA_SENT);
                        LOG.info(IndexMaker.indexes(new ReceiverInfoReport(receiverInfo), "receiverInfoReport"), "Insert logs receiver_info");
                        break;
                        
                    /* NOT USE */
                    case VAM_READY:
                        receiverInfo.setState(ReceiverState.VAM_DONE);
                        break;
                    case VERIFIED:
                        receiverInfo.setState(ReceiverState.VAM_SENT);
                        break;
                    default:
                        break;
                    }
                    LOG.info(IndexMaker.index(receiverInfo), "Transfer receiver to VAM CaptureResult service successfully");
                }
                else {
                    LOG.info(IndexMaker.index(receiverInfo), "Failed to forward receiver to VAM CaptureResult service!");
                    this.scheduledSender.queue(receiverInfo);
                    LOG.info(IndexMaker.index(receiverInfo), "Parcel was queued up to re-send to VAM CaptureResult service");
                }
                this.receiverInfoDao.store(receiverInfo.getKey(), receiverInfo);
            }
            catch (final Exception e) {
                LOG.debug(IndexMaker.index(receiverInfo), "There is error when transfer receiver to VAM CaptureResult service", e);
            }
            finally {
                this.watcher.unWatch(receiverInfo.getKey());
                LOG.info(IndexMaker.index(receiverInfo), "Transfer receiver to VAM CaptureResult service done");
            }
        };
    }
}
