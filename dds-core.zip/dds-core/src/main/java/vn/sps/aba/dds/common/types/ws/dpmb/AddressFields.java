
package vn.sps.aba.dds.common.types.ws.dpmb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddressFields complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddressFields">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AdressZusatz" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Anrede" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CoAdresse" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Dienstleistung" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}eDienstleistung" minOccurs="0"/>
 *         &lt;element name="Firmenname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Hausnummer" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="HausnummerZusatz" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Kundennummer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LaenderCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Land" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NameZusatz" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ort" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Postfach" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Postleitzahl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Stockwerk" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Strasse" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Vorname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddressFields", propOrder = {
    "adressZusatz",
    "anrede",
    "coAdresse",
    "dienstleistung",
    "firmenname",
    "hausnummer",
    "hausnummerZusatz",
    "kundennummer",
    "laenderCode",
    "land",
    "name",
    "nameZusatz",
    "ort",
    "postfach",
    "postleitzahl",
    "stockwerk",
    "strasse",
    "vorname"
})
public class AddressFields {

    @XmlElement(name = "AdressZusatz")
    protected String adressZusatz;
    @XmlElement(name = "Anrede")
    protected String anrede;
    @XmlElement(name = "CoAdresse")
    protected String coAdresse;
    @XmlElement(name = "Dienstleistung")
    @XmlSchemaType(name = "string")
    protected EDienstleistung dienstleistung;
    @XmlElement(name = "Firmenname")
    protected String firmenname;
    @XmlElement(name = "Hausnummer")
    protected Integer hausnummer;
    @XmlElement(name = "HausnummerZusatz")
    protected String hausnummerZusatz;
    @XmlElement(name = "Kundennummer")
    protected String kundennummer;
    @XmlElement(name = "LaenderCode")
    protected String laenderCode;
    @XmlElement(name = "Land")
    protected String land;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "NameZusatz")
    protected String nameZusatz;
    @XmlElement(name = "Ort")
    protected String ort;
    @XmlElement(name = "Postfach")
    protected String postfach;
    @XmlElement(name = "Postleitzahl")
    protected String postleitzahl;
    @XmlElement(name = "Stockwerk")
    protected String stockwerk;
    @XmlElement(name = "Strasse")
    protected String strasse;
    @XmlElement(name = "Vorname")
    protected String vorname;

    /**
     * Gets the value of the adressZusatz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdressZusatz() {
        return adressZusatz;
    }

    /**
     * Sets the value of the adressZusatz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdressZusatz(String value) {
        this.adressZusatz = value;
    }

    /**
     * Gets the value of the anrede property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnrede() {
        return anrede;
    }

    /**
     * Sets the value of the anrede property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnrede(String value) {
        this.anrede = value;
    }

    /**
     * Gets the value of the coAdresse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoAdresse() {
        return coAdresse;
    }

    /**
     * Sets the value of the coAdresse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoAdresse(String value) {
        this.coAdresse = value;
    }

    /**
     * Gets the value of the dienstleistung property.
     * 
     * @return
     *     possible object is
     *     {@link EDienstleistung }
     *     
     */
    public EDienstleistung getDienstleistung() {
        return dienstleistung;
    }

    /**
     * Sets the value of the dienstleistung property.
     * 
     * @param value
     *     allowed object is
     *     {@link EDienstleistung }
     *     
     */
    public void setDienstleistung(EDienstleistung value) {
        this.dienstleistung = value;
    }

    /**
     * Gets the value of the firmenname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirmenname() {
        return firmenname;
    }

    /**
     * Sets the value of the firmenname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirmenname(String value) {
        this.firmenname = value;
    }

    /**
     * Gets the value of the hausnummer property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getHausnummer() {
        return hausnummer;
    }

    /**
     * Sets the value of the hausnummer property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setHausnummer(Integer value) {
        this.hausnummer = value;
    }

    /**
     * Gets the value of the hausnummerZusatz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHausnummerZusatz() {
        return hausnummerZusatz;
    }

    /**
     * Sets the value of the hausnummerZusatz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHausnummerZusatz(String value) {
        this.hausnummerZusatz = value;
    }

    /**
     * Gets the value of the kundennummer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKundennummer() {
        return kundennummer;
    }

    /**
     * Sets the value of the kundennummer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKundennummer(String value) {
        this.kundennummer = value;
    }

    /**
     * Gets the value of the laenderCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLaenderCode() {
        return laenderCode;
    }

    /**
     * Sets the value of the laenderCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLaenderCode(String value) {
        this.laenderCode = value;
    }

    /**
     * Gets the value of the land property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLand() {
        return land;
    }

    /**
     * Sets the value of the land property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLand(String value) {
        this.land = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the nameZusatz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameZusatz() {
        return nameZusatz;
    }

    /**
     * Sets the value of the nameZusatz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameZusatz(String value) {
        this.nameZusatz = value;
    }

    /**
     * Gets the value of the ort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrt() {
        return ort;
    }

    /**
     * Sets the value of the ort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrt(String value) {
        this.ort = value;
    }

    /**
     * Gets the value of the postfach property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostfach() {
        return postfach;
    }

    /**
     * Sets the value of the postfach property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostfach(String value) {
        this.postfach = value;
    }

    /**
     * Gets the value of the postleitzahl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostleitzahl() {
        return postleitzahl;
    }

    /**
     * Sets the value of the postleitzahl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostleitzahl(String value) {
        this.postleitzahl = value;
    }

    /**
     * Gets the value of the stockwerk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStockwerk() {
        return stockwerk;
    }

    /**
     * Sets the value of the stockwerk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStockwerk(String value) {
        this.stockwerk = value;
    }

    /**
     * Gets the value of the strasse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrasse() {
        return strasse;
    }

    /**
     * Sets the value of the strasse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrasse(String value) {
        this.strasse = value;
    }

    /**
     * Gets the value of the vorname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVorname() {
        return vorname;
    }

    /**
     * Sets the value of the vorname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVorname(String value) {
        this.vorname = value;
    }

}
