/*
 * Class: IReceiverInfoProcessor
 *
 * Created on Jul 11, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.receiver.handers;

import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext;

/**
 * The Interface IReceiverInfoProcessor.
 */
public interface IReceiverStepHandler {

    /** The receiver info initial state. */
    static String RECEIVER_INFO_INITIAL_STATE = "RECEIVER_INFO_STATE_NEW";

    /**
     * Gets the processor name.
     *
     * @return the processor name
     */
    String getHandlerName();

    /**
     * Process.
     *
     * @param context
     *            the context
     * @param receiverInfo
     *            the receiver info
     */
    void handle(IReceiverProcessingContext context, ReceiverInfo receiverInfo);
}
