/*
 * Class: ReceiverInfo
 *
 * Created on Jul 11, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.entity.receiver;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.constant.TableNames;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.repository.entity.InternalEntity;

/**
 * The Class ReceiverInfoEntity.
 */
@Entity
@Table(name = TableNames.REC_RECEIVER_INFO, indexes = { @Index(name = "receiver_key", columnList = "key"),
    @Index(name = "receiver_state", columnList = "state"), @Index(name = "receiver_ident_code", columnList = "ident_code"),
    @Index(name = "receiver_created_time", columnList = "created"), @Index(name = "receiver_received_time", columnList = "received_time"),
    @Index(name = "receiver_lifespan", columnList = "lifespan") })
@Access(AccessType.PROPERTY)
public class ReceiverInfoEntity extends InternalEntity implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 222424144404484306L;

    /** The address fields. */
    private AddressFieldsEntity addressFields;

    /** The caller id. */
    private String callerId;

    /** The capture info. */
    private CaptureInfoEntity captureInfo;

    /** The capture result time. */
    private Timestamp captureResultBegin;

    /** The capture result count. */
    private Integer captureResultCount;

    /** The capture result done time. */
    private Timestamp captureResultEnd;

    /** The dis co timestamp. */
    private String disCoTimestamp;

    /** The dpm timestamp. */
    private String dpmTimestamp;

    /** The haus key. */
    private String hausKey;

    /** The ident code. */
    private String identCode;

    /** The kdp id. */
    private String kdpId;

    /** The key. */
    private String key;

    /** The match maker time. */
    private Timestamp matchMakerBegin;

    /** The match maker count. */
    private Integer matchMakerCount;

    /** The match maker done time. */
    private Timestamp matchMakerEnd;

    /** The package id. */
    private String packageId;

    /** The parcel data. */
    private ParcelDataEntity parcelData;

    /** The parcel haus key. */
    private String parcelHausKey;

    /** The pds timestamp. */
    private String pdsTimestamp;

    /** The person key. */
    private Integer personKey;

    /** The process end. */
    private Timestamp processEnd;

    /** The process start. */
    private Timestamp processStart;

    /** The received time. */
    private Timestamp receivedTime;

    /** The sender id. */
    private String senderId;

    /** The state. */
    private String state;

    /** The status code. */
    private String statusCode;

    /** The vam station sent. */
    private String vamStationSent;

    /** The verified by rule. */
    private String verifiedByRule;

    /** The version. */
    private String version;

    /** The vg timestamp. */
    private String vgTimestamp;

    /** The vn timestamp. */
    private String vnTimestamp;

    /** The volle address. */
    private VolleAddressEntity volleAddress;

    /**
     * Instantiates a new receiver info entity.
     */
    public ReceiverInfoEntity() {
    }

    /**
     * Instantiates a new receiver info entity.
     *
     * @param receiverInfo
     *            the receiver info
     */
    public ReceiverInfoEntity(final ReceiverInfo receiverInfo) {

        this.key = receiverInfo.getKey();

        this.setPackageId(receiverInfo.getPackageId());
        this.setIdentCode(receiverInfo.getIdentCode());
        this.setKdpId(receiverInfo.getKdpId());
        this.setPersonKey(receiverInfo.getPersonKey());
        this.setHausKey(receiverInfo.getHausKey());
        this.setParcelHausKey(receiverInfo.getParcelHausKey());
        this.setCallerId(receiverInfo.getCallerId());
        this.setSenderId(receiverInfo.getSenderId());
        this.setVersion(receiverInfo.getVersion());
        this.setDpmTimestamp(receiverInfo.getDpmTimeStamp());

        if (receiverInfo.getAdressErfassung() != null) {
            if (receiverInfo.getAdressErfassung().getAddressFields() != null) {
                this.addressFields = new AddressFieldsEntity(receiverInfo.getAdressErfassung().getAddressFields());
            }
            if (receiverInfo.getAdressErfassung().getVolleAdresse() != null) {
                this.volleAddress = new VolleAddressEntity(receiverInfo.getAdressErfassung().getVolleAdresse());
            }
        }
        if (receiverInfo.getCaptureInfo() != null) {
            this.captureInfo = new CaptureInfoEntity(receiverInfo.getCaptureInfo());
        }
        if (receiverInfo.getParcelData() != null) {
            this.parcelData = new ParcelDataEntity(receiverInfo.getParcelData());
        }
        this.setDisCoTimestamp(receiverInfo.getDisCoTimestamp());
        this.setPdsTimestamp(receiverInfo.getPdsTimestamp());
        this.setVgTimestamp(receiverInfo.getVgTimestamp());
        this.setVnTimestamp(receiverInfo.getVnTimestamp());

        this.updateInfo(receiverInfo);
    }

    /**
     * Gets the address fields.
     *
     * @return the address fields
     */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "address_fields_id")
    public AddressFieldsEntity getAddressFields() {
        return this.addressFields;
    }

    /**
     * Gets the caller id.
     *
     * @return the caller id
     */
    @Column(name = "caller_id", length = 50)
    public String getCallerId() {
        return this.callerId;
    }

    /**
     * Gets the capture info.
     *
     * @return the capture info
     */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "capture_info_id")
    public CaptureInfoEntity getCaptureInfo() {
        return this.captureInfo;
    }

    /**
     * Gets the capture result time.
     *
     * @return the capture result time
     */
    @Column(name = "capture_result_begin")
    public Timestamp getCaptureResultBegin() {
        return this.captureResultBegin;
    }

    /**
     * Gets the capture result count.
     *
     * @return the capture result count
     */
    @Column(name = "capture_result_count")
    public Integer getCaptureResultCount() {
        return this.captureResultCount;
    }

    /**
     * Gets the capture result done time.
     *
     * @return the capture result done time
     */
    @Column(name = "capture_result_end")
    public Timestamp getCaptureResultEnd() {
        return this.captureResultEnd;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.entity.InternalEntity#getCreated()
     */
    @Override
    @Column(name = "created")
    public long getCreated() {
        return super.getCreated();
    }

    /**
     * Gets the dis co timestamp.
     *
     * @return the dis co timestamp
     */
    @Column(name = "disco_timestamp", length = 100)
    public String getDisCoTimestamp() {
        return this.disCoTimestamp;
    }

    /**
     * Gets the dpm timestamp.
     *
     * @return the dpm timestamp
     */
    @Column(name = "dpm_timestamp", length = 100)
    public String getDpmTimestamp() {
        return this.dpmTimestamp;
    }

    /**
     * Gets the haus key.
     *
     * @return the haus key
     */
    @Column(name = "hauskey", length = 50)
    public String getHausKey() {
        return this.hausKey;
    }

    /**
     * Gets the ident code.
     *
     * @return the ident code
     */

    @Column(name = "ident_code", length = 50)
    public String getIdentCode() {
        return this.identCode;
    }

    /**
     * Gets the kdp id.
     *
     * @return the kdp id
     */
    @Column(name = "kdp_id", length = 50)
    public String getKdpId() {
        return this.kdpId;
    }

    /**
     * Gets the key.
     *
     * @return the key
     */
    @Id
    @Column(name = "key", length = 50)
    public String getKey() {
        return this.key;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.entity.InternalEntity#getLifespan()
     */
    @Override
    @Column(name = "lifespan")
    public long getLifespan() {
        return super.getLifespan();
    }

    /**
     * Gets the match maker time.
     *
     * @return the match maker time
     */
    @Column(name = "matchmaker_begin")
    public Timestamp getMatchMakerBegin() {
        return this.matchMakerBegin;
    }

    /**
     * Gets the match maker count.
     *
     * @return the match maker count
     */
    @Column(name = "matchmaker_count")
    public Integer getMatchMakerCount() {
        return this.matchMakerCount;
    }

    /**
     * Gets the match maker done time.
     *
     * @return the match maker done time
     */
    @Column(name = "matchmaker_end")
    public Timestamp getMatchMakerEnd() {
        return this.matchMakerEnd;
    }

    /**
     * Gets the package id.
     *
     * @return the package id
     */
    @Column(name = "package_id", length = 50)
    public String getPackageId() {
        return this.packageId;
    }

    /**
     * Gets the parcel data.
     *
     * @return the parcel data
     */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "parcel_data_id")
    public ParcelDataEntity getParcelData() {
        return this.parcelData;
    }

    /**
     * Gets the parcel haus key.
     *
     * @return the parcel haus key
     */
    @Column(name = "parcel_hauskey", length = 50)
    public String getParcelHausKey() {
        return this.parcelHausKey;
    }

    /**
     * Gets the pds timestamp.
     *
     * @return the pds timestamp
     */
    @Column(name = "pds_timestamp", length = 100)
    public String getPdsTimestamp() {
        return this.pdsTimestamp;
    }

    /**
     * Gets the person key.
     *
     * @return the person key
     */
    @Column(name = "person_key")
    public Integer getPersonKey() {
        return this.personKey;
    }

    /**
     * Gets the process end.
     *
     * @return the process end
     */
    @Column(name = "processing_end", length = 100)
    public Timestamp getProcessEnd() {
        return this.processEnd;
    }

    /**
     * Gets the process start.
     *
     * @return the process start
     */
    @Column(name = "processing_begin", length = 100)
    public Timestamp getProcessStart() {
        return this.processStart;
    }

    /**
     * Gets the received time.
     *
     * @return the received time
     */
    @Column(name = "received_time")
    public Timestamp getReceivedTime() {
        return this.receivedTime;
    }

    /**
     * Gets the sender id.
     *
     * @return the sender id
     */
    @Column(name = "sender_id")
    public String getSenderId() {
        return this.senderId;
    }

    /**
     * Gets the state.
     *
     * @return the state
     */
    @Column(name = "state", length = 50)
    public String getState() {
        return this.state;
    }

    /**
     * Gets the status code.
     *
     * @return the status code
     */
    @Column(name = "status_code", length = 20)
    public String getStatusCode() {
        return this.statusCode;
    }

    /**
     * Gets the vam station sent.
     *
     * @return the vam station sent
     */
    @Column(name = "vam_stations", length = 100)
    public String getVamStationSent() {
        return this.vamStationSent;
    }

    /**
     * Gets the verified by rule.
     *
     * @return the verified by rule
     */
    @Column(name = "verified_by_rule", length = 255)
    public String getVerifiedByRule() {
        return this.verifiedByRule;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    @Column(name = "version")
    public String getVersion() {
        return this.version;
    }

    /**
     * Gets the vg timestamp.
     *
     * @return the vg timestamp
     */
    @Column(name = "vg_timestamp", length = 100)
    public String getVgTimestamp() {
        return this.vgTimestamp;
    }

    /**
     * Gets the vn timestamp.
     *
     * @return the vn timestamp
     */
    @Column(name = "vn_timestamp", length = 100)
    public String getVnTimestamp() {
        return this.vnTimestamp;
    }

    /**
     * Gets the volle address.
     *
     * @return the volle address
     */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "volle_address_id")
    public VolleAddressEntity getVolleAddress() {
        return this.volleAddress;
    }

    /**
     * Sets the address fields.
     *
     * @param addressFields
     *            the new address fields
     */
    public void setAddressFields(final AddressFieldsEntity addressFields) {
        this.addressFields = addressFields;
    }

    /**
     * Sets the caller id.
     *
     * @param callerId
     *            the new caller id
     */
    public void setCallerId(final String callerId) {
        this.callerId = callerId;
    }

    /**
     * Sets the capture info.
     *
     * @param captureInfo
     *            the new capture info
     */
    public void setCaptureInfo(final CaptureInfoEntity captureInfo) {
        this.captureInfo = captureInfo;
    }

    /**
     * Sets the capture result time.
     *
     * @param captureResultTime
     *            the new capture result time
     */
    public void setCaptureResultBegin(final Timestamp captureResultTime) {
        this.captureResultBegin = captureResultTime;
    }

    /**
     * Sets the capture result count.
     *
     * @param captureResultCount the new capture result count
     */
    public void setCaptureResultCount(final Integer captureResultCount) {
        this.captureResultCount = captureResultCount;
    }

    /**
     * Sets the capture result done time.
     *
     * @param captureResultDoneTime the new capture result done time
     */
    public void setCaptureResultEnd(final Timestamp captureResultDoneTime) {
        this.captureResultEnd = captureResultDoneTime;
    }

    /**
     * Sets the dis co timestamp.
     *
     * @param disCoTimestamp the new dis co timestamp
     */
    public void setDisCoTimestamp(final String disCoTimestamp) {
        this.disCoTimestamp = disCoTimestamp;
    }

    /**
     * Sets the dpm timestamp.
     *
     * @param dpmTimestamp
     *            the new dpm timestamp
     */
    public void setDpmTimestamp(final String dpmTimestamp) {
        this.dpmTimestamp = dpmTimestamp;
    }

    /**
     * Sets the haus key.
     *
     * @param hausKey
     *            the new haus key
     */
    public void setHausKey(final String hausKey) {
        this.hausKey = hausKey;
    }

    /**
     * Sets the ident code.
     *
     * @param identCode
     *            the new ident code
     */
    public void setIdentCode(final String identCode) {
        this.identCode = identCode;
    }

    /**
     * Sets the kdp id.
     *
     * @param kdpId
     *            the new kdp id
     */
    public void setKdpId(final String kdpId) {
        this.kdpId = kdpId;
    }

    /**
     * Sets the key.
     *
     * @param key the new key
     */
    public void setKey(final String key) {
        this.key = key;
    }

    /**
     * Sets the match maker time.
     *
     * @param matchMakerTime
     *            the new match maker time
     */
    public void setMatchMakerBegin(final Timestamp matchMakerTime) {
        this.matchMakerBegin = matchMakerTime;
    }

    /**
     * Sets the match maker count.
     *
     * @param matchMakerCount the new match maker count
     */
    public void setMatchMakerCount(final Integer matchMakerCount) {
        this.matchMakerCount = matchMakerCount;
    }

    /**
     * Sets the match maker done time.
     *
     * @param matchMakerEnd the new match maker done time
     */
    public void setMatchMakerEnd(final Timestamp matchMakerEnd) {
        this.matchMakerEnd = matchMakerEnd;
    }

    /**
     * Sets the package id.
     *
     * @param packageId the new package id
     */
    public void setPackageId(final String packageId) {
        this.packageId = packageId;
    }

    /**
     * Sets the parcel data.
     *
     * @param parcelData the new parcel data
     */
    public void setParcelData(final ParcelDataEntity parcelData) {
        this.parcelData = parcelData;
    }

    /**
     * Sets the parcel haus key.
     *
     * @param parcelHausKey
     *            the new parcel haus key
     */
    public void setParcelHausKey(final String parcelHausKey) {
        this.parcelHausKey = parcelHausKey;
    }

    /**
     * Sets the pds timestamp.
     *
     * @param pdsTimestamp the new pds timestamp
     */
    public void setPdsTimestamp(final String pdsTimestamp) {
        this.pdsTimestamp = pdsTimestamp;
    }

    /**
     * Sets the person key.
     *
     * @param personKey
     *            the new person key
     */
    public void setPersonKey(final Integer personKey) {
        this.personKey = personKey;
    }

    /**
     * Sets the process end.
     *
     * @param processEnd the new process end
     */
    public void setProcessEnd(final Timestamp processEnd) {
        this.processEnd = processEnd;
    }

    /**
     * Sets the process start.
     *
     * @param processStart the new process start
     */
    public void setProcessStart(final Timestamp processStart) {
        this.processStart = processStart;
    }

    /**
     * Sets the received time.
     *
     * @param receivedTime
     *            the new received time
     */
    public void setReceivedTime(final Timestamp receivedTime) {
        this.receivedTime = receivedTime;
    }

    /**
     * Sets the sender id.
     *
     * @param senderId
     *            the new sender id
     */
    public void setSenderId(final String senderId) {
        this.senderId = senderId;
    }

    /**
     * Sets the state.
     *
     * @param state
     *            the new state
     */
    public void setState(final ReceiverState state) {
        if (state != null) {
            this.state = state.name();
        }
    }

    /**
     * Sets the state.
     *
     * @param state
     *            the new state
     */
    public void setState(final String state) {
        this.state = state;
    }

    /**
     * Sets the status code.
     *
     * @param statusCode the new status code
     */
    public void setStatusCode(final String statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Sets the vam station sent.
     *
     * @param vamStationSent the new vam station sent
     */
    public void setVamStationSent(final String vamStationSent) {
        this.vamStationSent = vamStationSent;
    }

    /**
     * Sets the verified by rule.
     *
     * @param verifiedByRule
     *            the new verified by rule
     */
    public void setVerifiedByRule(final String verifiedByRule) {
        this.verifiedByRule = verifiedByRule;
    }

    /**
     * Sets the version.
     *
     * @param version
     *            the new version
     */
    public void setVersion(final String version) {
        this.version = version;
    }

    /**
     * Sets the vg timestamp.
     *
     * @param vgTimestamp the new vg timestamp
     */
    public void setVgTimestamp(final String vgTimestamp) {
        this.vgTimestamp = vgTimestamp;
    }

    /**
     * Sets the vn timestamp.
     *
     * @param vnTimestamp the new vn timestamp
     */
    public void setVnTimestamp(final String vnTimestamp) {
        this.vnTimestamp = vnTimestamp;
    }

    /**
     * Sets the volle address.
     *
     * @param volleAddress
     *            the new volle address
     */
    public void setVolleAddress(final VolleAddressEntity volleAddress) {
        this.volleAddress = volleAddress;
    }

    /**
     * Update info.
     *
     * @param receiverInfo the receiver info
     */
    public void updateInfo(final ReceiverInfo receiverInfo) {
        this.setState(receiverInfo.getState());
        this.setStatusCode(receiverInfo.getStatusCode());

        this.setReceivedTime(DateUtil.milliTime2Timestamp(receiverInfo.getReceived()));

        this.setCaptureResultBegin(DateUtil.milliTime2Timestamp(receiverInfo.getCaptureResultBegin()));
        this.setCaptureResultEnd(DateUtil.milliTime2Timestamp(receiverInfo.getCaptureResultEnd()));

        this.setMatchMakerBegin(DateUtil.milliTime2Timestamp(receiverInfo.getMatchMakerBegin()));
        this.setMatchMakerEnd(DateUtil.milliTime2Timestamp(receiverInfo.getMatchMakerEnd()));

        this.setVerifiedByRule(receiverInfo.getVerifiedByRule());
        this.setVamStationSent(receiverInfo.getVamStationSent());
        this.setProcessStart(DateUtil.milliTime2Timestamp(receiverInfo.getProcessBegin()));
        this.setProcessEnd(DateUtil.milliTime2Timestamp(receiverInfo.getProcessEnd()));

        this.setMatchMakerCount(receiverInfo.getMatchMakerCount());
        this.setCaptureResultCount(receiverInfo.getCaptureResultCount());
    }
}
