/*
 * Class: VgParcelBcDataResultService
 *
 * Created on Jun 30, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.padasa.vgparcelbcdataresult.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import net.logstash.logback.marker.Markers;
import vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.ExecutePortType;
import vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.JavaExceptionMessage;
import vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.MsgParcelBCData;
import vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.PrjPADAPrjPADASAPrjWsOrwellOTDsJcdBCParcelDataService;
import vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model.VGParcelBCDataResult;
import vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration;
import vn.sps.aba.dds.config.service.BarcodeDataServiceConfiguration;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.service.padasa.vgparcelbcdataresult.IVgParcelBcDataResultService;

/**
 * The Class VgParcelBcDataResultService.
 */
@Service
public class PadasaVgParcelBcDataResultService extends AbstractSoapWsConsumer<ExecutePortType, MsgParcelBCData, VGParcelBCDataResult>
        implements IVgParcelBcDataResultService {

    /** The Constant LOG. */
    private final static Logger LOG = LoggerFactory.getLogger(PadasaVgParcelBcDataResultService.class);

    /** The client. */
    private ExecutePortType client;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#checkResponse(java.lang.Object)
     */
    @Override
    protected boolean checkResponse(final IdentifiedEntry entry, final VGParcelBCDataResult response) {
        try {
            LOG.info(IndexMaker.index(entry, response), "PADASA BarcodeService response");
            if (response != null) {

                final BarcodeDataServiceConfiguration serviceConfiguration = this.getConfiguration(BarcodeDataServiceConfiguration.class);

                return response.getCode().longValue() == Long.valueOf(serviceConfiguration.successful().getCode());
            }
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.indexes(entry), "Error while checking response from BarcodeService", e);
        }

        return false;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#getClients()
     */
    @Override
    protected Object[] getClients() {
        return new Object[] { this.client };
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsTemplate#getPayloadName()
     */
    @Override
    protected String getServiceName() {
        return "VgParcelBcDataResult";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#initGateway()
     */
    @Override
    public void initGateway() throws Exception {

        final BarcodeDataServiceConfiguration serviceConfiguration = this.getConfiguration(BarcodeDataServiceConfiguration.class);
        final PrjPADAPrjPADASAPrjWsOrwellOTDsJcdBCParcelDataService service = new PrjPADAPrjPADASAPrjWsOrwellOTDsJcdBCParcelDataService(
            serviceConfiguration.getWsdlLocation());
        this.client = service.getPort(ExecutePortType.class);
        super.initGateway();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#setConfiguration(vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration)
     */
    @Autowired
    @Override
    public void setConfiguration(@Qualifier("BarcodeDataServiceConfiguration") final AbstractSoapWsConfiguration configuration) {
        this.configuration = configuration;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#transfer(java.lang.Object, java.lang.Object)
     */
    @Override
    protected VGParcelBCDataResult transfer(final IdentifiedEntry entry, final MsgParcelBCData payload, final ExecutePortType client)
            throws JavaExceptionMessage {
        return client.receive(payload);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.padasa.vgparcelbcdataresult.IVgParcelBcDataResultService#transferToBarcodeDataService(vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public boolean transferToBarcodeDataService(final ParcelInfo parcelInfo) {
        return this.transferToBarcodeDataService(parcelInfo, parcelInfo.getDmcCode());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.padasa.vgparcelbcdataresult.IVgParcelBcDataResultService#transferToBarcodeDataService(vn.sps.aba.dds.common.model.parcel.ParcelInfo,
     *      vn.sps.aba.dds.common.model.dmc.DMCResponse)
     */
    @Override
    public boolean transferToBarcodeDataService(final ParcelInfo parcelInfo, final DMCResponse response) {

        try {
            final BarcodeDataServiceConfiguration serviceConfiguration = this.getConfiguration(BarcodeDataServiceConfiguration.class);

            final MsgParcelBCData message = MessageBuilder.buildBarcodeDataService(serviceConfiguration, parcelInfo, response);
            final String url = serviceConfiguration.getServiceUrl();

            parcelInfo.setBarcodeBegin(DiscoWallClock.milli());
            final boolean ret = this.transferCascade(parcelInfo, message, this.client, url) != null;
            parcelInfo.setBarcodeEnd(DiscoWallClock.milli());
            parcelInfo.countPadUp();
            if (!ret) {
                LOG.error(Markers.appendFields(parcelInfo), "Failed to transfer ParcelInfo to Padasa BarcodeService at url " + url);
            }

            return ret;
        }
        catch (final Exception e) {

            LOG.error(Markers.appendFields(parcelInfo), "There are error while building the BarcodeData message", e);
        }

        return false;
    }

}
