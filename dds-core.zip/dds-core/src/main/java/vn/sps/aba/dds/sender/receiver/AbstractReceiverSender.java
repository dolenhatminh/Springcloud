/*
 * Class: AbstractReceiverSender
 *
 * Created on Oct 27, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.sender.receiver;

import java.util.concurrent.Future;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;

import vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;
import vn.sps.aba.dds.scheduled.sender.IScheduledSender;

/**
 * The Class AbstractReceiverSender.
 */
abstract class AbstractReceiverSender extends AbstractAsyncWorker {

    /** The receiver info dao. */
    @Autowired
    protected IReceiverInfoCacheDao receiverInfoDao;

    /**
     * Gets the scheduled sender.
     *
     * @return the scheduled sender
     */
    protected abstract IScheduledSender<ReceiverInfo> getScheduledSender();

    /**
     * Handle item.
     *
     * @param receiverInfo the receiver info
     * @param isRetry the is retry
     * @return the runnable
     */
    protected Runnable handleItem(final ReceiverInfo receiverInfo, final boolean isRetry) {
        return null;
    }

    /**
     * Initialize.
     */
    @PostConstruct
    protected void initialize() {

    }

    /**
     * Submit item for re-sending.
     *
     * @param receiverInfo the receiver info
     */
    public void rubmitItem(final ReceiverInfo receiverInfo) {
        final String key = receiverInfo.getKey();
        if (this.watcher.isDone(key)) {
            this.getScheduledSender().cancelScheduledItem(key);
            final Runnable r = this.handleItem(receiverInfo, true);
            final Future<?> worker = this.getExecutor().getAsyncExecutor().submit(r);
            this.watcher.watch(key, worker);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.sender.IExternalSender#submitItem(java.lang.Object, boolean)
     */
    public void submitItem(final ReceiverInfo receiverInfo) {
        final String key = receiverInfo.getKey();
        if (this.watcher.isDone(key)) {
            final Runnable r = this.handleItem(receiverInfo, false);
            final Future<?> worker = this.getExecutor().getAsyncExecutor().submit(r);
            this.watcher.watch(key, worker);
        }
    }
}
