
package vn.sps.aba.dds.common.types.ws.vae.blackbox;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ParcelData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ParcelData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DestinationStation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ParPicId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ProduktZusatzleistungen" type="{http://schemas.datacontract.org/2004/07/DisCoService}ArrayOfProduktZusatzleistung"/>
 *         &lt;element name="SourceStation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="VcsCase" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ParcelData", propOrder = {
    "destinationStation",
    "parPicId",
    "produktZusatzleistungen",
    "sourceStation",
    "timeStamp",
    "vcsCase"
})
public class ParcelData {

    @XmlElement(name = "DestinationStation", required = true, nillable = true)
    protected String destinationStation;
    @XmlElement(name = "ParPicId", required = true, nillable = true)
    protected String parPicId;
    @XmlElement(name = "ProduktZusatzleistungen", required = true, nillable = true)
    protected ArrayOfProduktZusatzleistung produktZusatzleistungen;
    @XmlElement(name = "SourceStation", required = true, nillable = true)
    protected String sourceStation;
    @XmlElement(name = "TimeStamp", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar timeStamp;
    @XmlElement(name = "VcsCase")
    protected Integer vcsCase;

    /**
     * Gets the value of the destinationStation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationStation() {
        return destinationStation;
    }

    /**
     * Sets the value of the destinationStation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationStation(String value) {
        this.destinationStation = value;
    }

    /**
     * Gets the value of the parPicId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParPicId() {
        return parPicId;
    }

    /**
     * Sets the value of the parPicId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParPicId(String value) {
        this.parPicId = value;
    }

    /**
     * Gets the value of the produktZusatzleistungen property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfProduktZusatzleistung }
     *     
     */
    public ArrayOfProduktZusatzleistung getProduktZusatzleistungen() {
        return produktZusatzleistungen;
    }

    /**
     * Sets the value of the produktZusatzleistungen property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfProduktZusatzleistung }
     *     
     */
    public void setProduktZusatzleistungen(ArrayOfProduktZusatzleistung value) {
        this.produktZusatzleistungen = value;
    }

    /**
     * Gets the value of the sourceStation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceStation() {
        return sourceStation;
    }

    /**
     * Sets the value of the sourceStation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceStation(String value) {
        this.sourceStation = value;
    }

    /**
     * Gets the value of the timeStamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTimeStamp() {
        return timeStamp;
    }

    /**
     * Sets the value of the timeStamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTimeStamp(XMLGregorianCalendar value) {
        this.timeStamp = value;
    }

    /**
     * Gets the value of the vcsCase property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getVcsCase() {
        return vcsCase;
    }

    /**
     * Sets the value of the vcsCase property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setVcsCase(Integer value) {
        this.vcsCase = value;
    }

}
