/*
 * Class: PDSWebserviceConfiguration
 *
 * Created on May 12, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.util.Assert;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.xml.xsd.XsdSchemaCollection;
import org.springframework.xml.xsd.commons.CommonsXsdSchemaCollection;

import vn.sps.aba.dds.config.reponsecode.IResponseCodeProvider;

/**
 * The Class MessageDispatcherConfiguration.
 */
public abstract class AbstractSoapWsConfiguration extends WsTemplaceConfiguration implements ResourceLoaderAware {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(AbstractSoapWsConfiguration.class);

    /** The add validation error detail. */
    private boolean addValidationErrorDetail;

    /** The context path. */
    private String contextPath;

    /** The jaxb context. */
    private JAXBContext jaxbContext;

    /** The marshaller. */
    private Jaxb2Marshaller marshaller;

    /** The object factory. */
    private Object objectFactory;

    /** The password. */
    private String password;

    /** The resource loader. */
    protected ResourceLoader resourceLoader;

    /** The response code provider. */
    @Autowired
    protected IResponseCodeProvider responseCodeProvider;

    /** The username. */
    private String username;

    /** The validate request. */
    private boolean validateRequest;

    /** The validate response. */
    private boolean validateResponse;

    /** The wsdl location. */
    private URL wsdlLocation;

    /** The wsdl resource. */
    protected Resource wsdlResource;

    /** The schemas for create the service end point. */
    private XsdSchemaCollection xsdSchemas;

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.ws.config.annotation.WsConfigurerAdapter#addInterceptors(java.util.List)
     */
    @Override
    public void addInterceptors(final List<EndpointInterceptor> interceptors) {
        // TODO -- Low priority -- create the logging interceptor for logging output message
        super.addInterceptors(interceptors);
    }

    /**
     * Gets the context path.
     *
     * @return Returns the contextPath.
     */
    @Override
    public String getContextPath() {
        return this.contextPath;
    }

    /**
     * Gets the jaxb context.
     *
     * @return the jaxb context
     */
    public JAXBContext getJaxbContext() {
        return this.jaxbContext;
    }

    /**
     * Gets the marshaller.
     *
     * @return Returns the marshaller.
     */
    public Marshaller getMarshaller() {
        return this.marshaller;
    }

    /**
     * Gets the namespace uri.
     *
     * @return the namespace uri
     */
    public abstract String getNamespaceURI();

    /**
     * Gets the object factory.
     *
     * @return the object factory
     */
    public Object getObjectFactory() {
        return this.objectFactory;
    }

    /**
     * Gets the object factory.
     *
     * @param <T> the generic type
     * @param responseType the response type
     * @return the object factory
     */
    @SuppressWarnings("unchecked")
    public <T> T getObjectFactory(final Class<T> responseType) {

        Assert.notNull(responseType, "'responseType' must not be null");

        return (T) this.objectFactory;
    }

    /**
     * Gets the password.
     *
     * @return the password
     */
    public String getPassword() {
        return this.password;
    }

    /**
     * Gets the username.
     *
     * @return the username
     */
    public String getUsername() {
        return this.username;
    }

    /**
     * Gets the wsdl location.
     *
     * @return the wsdl location
     */
    public URL getWsdlLocation() {
        return this.wsdlLocation;
    }

    /**
     * Gets the schemas.
     *
     * @return Returns the schemas.
     */
    public XsdSchemaCollection getXsdSchemas() {
        return this.xsdSchemas;
    }

    /**
     * Initialize.
     *
     * @throws Exception the exception
     */
    public void initialize() throws Exception {

        this.objectFactory = Class.forName(this.getContextPath() + ".ObjectFactory").newInstance();
        this.jaxbContext = JAXBContext.newInstance(this.getContextPath());
        this.marshaller = new Jaxb2Marshaller();
        this.marshaller.setContextPath(this.getContextPath());
        this.marshaller.afterPropertiesSet();
        LOG.info("Initialize the Jaxb context " + this.getContextPath());
    }

    /**
     * Checks if is adds the validation error detail.
     *
     * @return Returns the addValidationErrorDetail.
     */
    public boolean isAddValidationErrorDetail() {
        return this.addValidationErrorDetail;
    }

    /**
     * Checks if is validate request.
     *
     * @return Returns the validateRequest.
     */
    public boolean isValidateRequest() {
        return this.validateRequest;
    }

    /**
     * Checks if is validate response.
     *
     * @return Returns the validateResponse.
     */
    public boolean isValidateResponse() {
        return this.validateResponse;
    }

    /**
     * Load schemas.
     *
     * @param schemas the schemas
     * @return the xsd schema collection
     */
    protected XsdSchemaCollection loadSchemas(final String[] schemas) {
        if (schemas != null) {
            final List<Resource> tempSchemas = new ArrayList<>(schemas.length);
            for (final String schema : schemas) {
                tempSchemas.add(this.resourceLoader.getResource(schema));
            }

            return new CommonsXsdSchemaCollection(tempSchemas.toArray(new Resource[schemas.length]));
        }
        return null;
    }

    /**
     * Sets the adds the validation error detail.
     *
     * @param addValidationErrorDetail
     *            The addValidationErrorDetail to set.
     */
    public void setAddValidationErrorDetail(final boolean addValidationErrorDetail) {
        this.addValidationErrorDetail = addValidationErrorDetail;
    }

    /**
     * Sets the context path.
     *
     * @param contextPath
     *            The contextPath to set.
     */
    public void setContextPath(final String contextPath) {
        this.contextPath = contextPath;
    }

    /**
     * Sets the password.
     *
     * @param password the new password
     */
    public void setPassword(final String password) {
        this.password = password;
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.context.ResourceLoaderAware#setResourceLoader(org.springframework.core.io.ResourceLoader)
     */
    @Override
    public void setResourceLoader(final ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;

    }

    /**
     * Sets the username.
     *
     * @param username the new username
     */
    public void setUsername(final String username) {
        this.username = username;
    }

    /**
     * Sets the validate request.
     *
     * @param validateRequest
     *            The validateRequest to set.
     */
    public void setValidateRequest(final boolean validateRequest) {
        this.validateRequest = validateRequest;
    }

    /**
     * Sets the validate response.
     *
     * @param validateResponse
     *            The validateResponse to set.
     */
    public void setValidateResponse(final boolean validateResponse) {
        this.validateResponse = validateResponse;
    }

    /**
     * Sets the wsdl location.
     *
     * @param wsdlLocation the new wsdl location
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void setWsdlLocation(final String wsdlLocation) throws IOException {
        this.wsdlResource = this.resourceLoader.getResource(wsdlLocation);
        this.wsdlLocation = this.wsdlResource.getURL();
    }

    /**
     * Sets the schemas.
     *
     * @param schemas
     *            The schemas to set.
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public void setXsdSchemas(final String[] schemas) throws IOException {
        this.xsdSchemas = this.loadSchemas(schemas);
        ((CommonsXsdSchemaCollection) this.xsdSchemas).afterPropertiesSet();
    }
}
