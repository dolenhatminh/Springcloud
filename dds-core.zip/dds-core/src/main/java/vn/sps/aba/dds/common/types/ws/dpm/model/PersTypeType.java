
package vn.sps.aba.dds.common.types.ws.dpm.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PersTypeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PersTypeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Person"/>
 *     &lt;enumeration value="Company"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PersTypeType")
@XmlEnum
public enum PersTypeType {

    @XmlEnumValue("Person")
    PERSON("Person"),
    @XmlEnumValue("Company")
    COMPANY("Company");
    private final String value;

    PersTypeType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PersTypeType fromValue(String v) {
        for (PersTypeType c: PersTypeType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
