/*
 * Class: IBarcodeSender
 * 
 * Created on Oct 25, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.sender.parcel.interfaces;

import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.sender.IExternalSender;

/**
 * The Interface IBarcodeSender.
 */
public interface IBarcodeSender extends IExternalSender<ParcelInfo> {

    /**
     * Submit item.
     *
     * @param parcelInfo the parcel info
     * @param dmcData the dmc data
     */
    void submitItem(ParcelInfo parcelInfo, DMCResponse dmcData);
}
