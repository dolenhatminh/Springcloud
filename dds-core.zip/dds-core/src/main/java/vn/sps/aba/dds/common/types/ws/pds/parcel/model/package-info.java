@javax.xml.bind.annotation.XmlSchema(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package vn.sps.aba.dds.common.types.ws.pds.parcel.model;
