/*
 * Class: AbstractExternalSender
 *
 * Created on Nov 2, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.ifa.impl;

import java.util.concurrent.Future;

import vn.sps.aba.dds.common.ifa.ImmortalCollector;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.jmx.AsyncWorkerInfo;

/**
 * The Class AbstractAsyncWorker.
 */
public abstract class AbstractAsyncWorker implements AsyncWorkerInfo, ImmortalCollector {

    /** The watcher. */
    protected final TaskWatcherImpl watcher = new TaskWatcherImpl();

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.AsyncWorkerInfo#changePoolConfig(int, int)
     */
    @Override
    public void changePoolConfig(final int corePoolSize, final int maxPoolSize) {
        this.getExecutor().changePoolConfig(corePoolSize, maxPoolSize);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.ImmortalCollector#cleanFinishedTasks()
     */
    @Override
    public int cleanFinishedTasks(final boolean force) {
        return this.watcher.cleanFinishedTasks(force);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.AsyncWorkerInfo#countWatcherSize()
     */
    @Override
    public int countWatcherSize() {
        return this.watcher.size();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.AsyncWorkerInfo#emptyQueue(java.lang.String)
     */
    @Override
    public int emptyQueue(final String key) {
        final int ret = this.watcher.emptyQueue(key);
        this.getExecutor().emptyQueue(key);
        return ret;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.AsyncWorkerInfo#getActiveCount()
     */
    @Override
    public int getActiveCount() {
        return this.getExecutor().getActiveCount();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.AsyncWorkerInfo#getCorePoolSize()
     */
    @Override
    public int getCorePoolSize() {
        return this.getExecutor().getCorePoolSize();
    }

    /**
     * Gets the executor.
     *
     * @return the executor
     */
    protected abstract TaskConfiguration getExecutor();

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.AsyncWorkerInfo#getMaxPoolSize()
     */
    @Override
    public int getMaxPoolSize() {
        return this.getExecutor().getMaxPoolSize();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.ImmortalCollector#getNumberWatchingTask()
     */
    @Override
    public int getNumberWatchingTask() {
        return this.watcher.getNumberWatchingTask();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.AsyncWorkerInfo#getQueingCount()
     */
    @Override
    public int getQueingCount() {
        return this.getExecutor().getQueingCount();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.AsyncWorkerInfo#getQueueCapacity()
     */
    @Override
    public int getQueueCapacity() {
        return this.getExecutor().getQueueCapacity();
    }

    /**
     * Gets the task.
     *
     * @param key the key
     * @return the task
     */
    @SuppressWarnings("rawtypes")
    public Future getTask(final String key) {
        return this.watcher.unWatch(key);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.AsyncWorkerInfo#getThreadName()
     */
    @Override
    public String getThreadName() {
        return this.getExecutor().getThreadName();
    }

    /**
     * Checks if is done.
     *
     * @param key the key
     * @return true, if is done
     */
    public boolean isDone(final String key) {
        return this.watcher.isDone(key);
    }

    /**
     * Un watch.
     *
     * @param key the key
     * @return the future
     */
    public Future<?> unWatch(final String key) {
        return this.watcher.unWatch(key);
    }
}