
package vn.sps.aba.dds.common.types.ws.vam.capturing.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ePersType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ePersType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Person"/>
 *     &lt;enumeration value="Company"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ePersType")
@XmlEnum
public enum EPersType {

    @XmlEnumValue("Person")
    PERSON("Person"),
    @XmlEnumValue("Company")
    COMPANY("Company");
    private final String value;

    EPersType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static EPersType fromValue(String v) {
        for (EPersType c: EPersType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
