/*
 * Class: AbstractParcelStateHandler
 *
 * Created on Jul 4, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.parcel.handers.impl;

import vn.sps.aba.dds.processor.parcel.handers.IParcelStepHandler;

/**
 * The Class AbstractParcelStateHandler.
 */
abstract class AbstractParcelStepHandler implements IParcelStepHandler {

    /** The parcel state blackbox handler. */
    protected static String PARCEL_STATE_BLACKBOX_HANDLER = "PARCEL_STATE_BLACKBOX_HANDLER";

    /** The parcel state dmc. */
    protected static String PARCEL_STATE_DMCING = "PARCEL_STATE_DMCING";

    /** The parcel state filtering. */
    protected static String PARCEL_STATE_FILTERING = "PARCEL_STATE_FILTERING";

    /** The parcel state matching. */
    protected static String PARCEL_STATE_MATCHING = "PARCEL_STATE_MATCHING";

    /** The parcel state matching dpm. */
    protected static String PARCEL_STATE_MATCHING_DPM = "PARCEL_STATE_MATCHING_DPM";

    /** The parcel state new. */
    protected static String PARCEL_STATE_NEW = IParcelStepHandler.PARCEL_INITIAL_STATE_HANDLER;

    /** The parcel state padasa barcode. */
    protected static String PARCEL_STATE_PADASA_BARCODE = "PARCEL_STATE_PADASA_BARCODE";

    /** The parcel state vam capture result handler. */
    protected static String PARCEL_STATE_VAM_CAPTURE_RESULT_HANDLER = "PARCEL_STATE_VAM_CAPTURE_RESULT_HANDLER";

    /** The executor. */

    /** The state. */
    private final String name;

    /**
     * Instantiates a new abstract parcel state handler.
     *
     * @param name            the name
     */
    public AbstractParcelStepHandler(final String name) {
        this.name = name;
    }

    /**
     * Gets the state.
     *
     * @return the state
     */
    @Override
    public String getStateName() {
        return this.name;
    }
}
