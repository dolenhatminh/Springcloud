/*
 * Class: AbstractProcessStepHandler
 *
 * Created on Jul 11, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.receiver.handers;

/**
 * The Class AbstractProcessStepHandler.
 */
public abstract class AbstractReceiverStepHandler {

    /** The receiver info state forwarding. */
    protected static String STEP_FORWARDING_HANDLER = "STEP_FORWARDING_HANDLER";

    /** The step key datatype validator handler. */
    protected static String STEP_KEY_DATATYPE_VALIDATOR_HANDLER = "STEP_KEY_DATATYPE_VALIDATOR_HANDLER";

    /** The receiver info state new. */
    protected static String STEP_NEW_HANDLER = IReceiverStepHandler.RECEIVER_INFO_INITIAL_STATE;

    /** The receiver info state verifying. */
    protected static String STEP_VERIFYING_HANDLER = "STEP_VERIFYING_HANDLER";

    /** The state name. */
    private final String stateName;

    /**
     * Instantiates a new abstract receiver info processor.
     *
     * @param stateName
     *            the state name
     */
    public AbstractReceiverStepHandler(final String stateName) {
        this.stateName = stateName;
    }

    /**
     * Gets the state name.
     *
     * @return the state name
     */
    public String getHandlerName() {
        return this.stateName;
    }
}
