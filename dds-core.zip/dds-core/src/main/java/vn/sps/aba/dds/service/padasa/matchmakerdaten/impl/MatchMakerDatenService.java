/*
 * Class: MatchMakerDatenService
 *
 * Created on Jun 30, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.padasa.matchmakerdaten.impl;

import org.apache.http.auth.UsernamePasswordCredentials;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import net.logstash.logback.marker.Markers;
import vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.ws.padasa.matchmakerdaten.model.MatchMakerInsertPadasa;
import vn.sps.aba.dds.common.types.ws.padasa.matchmakerdaten.model.MatchMakerRequest;
import vn.sps.aba.dds.common.types.ws.padasa.matchmakerdaten.model.MatchMakerResponse;
import vn.sps.aba.dds.common.types.ws.padasa.matchmakerdaten.model.MatchmakerinsertpadasaClientEp;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration;
import vn.sps.aba.dds.config.service.MatchMakerServiceConfiguration;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.service.padasa.matchmakerdaten.IMatchMakerDatenService;

/**
 * The Class MatchMakerDatenService.
 */
@Service
public class MatchMakerDatenService extends AbstractSoapWsConsumer<MatchMakerInsertPadasa, MatchMakerRequest, MatchMakerResponse>
        implements IMatchMakerDatenService {

    /** The Constant LOG. */
    private final static Logger LOG = LoggerFactory.getLogger(MatchMakerDatenService.class);

    /** The client. */
    private MatchMakerInsertPadasa client;

    /** The url. */
    private String url;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#checkResponse(java.lang.Object)
     */
    @Override
    protected boolean checkResponse(final IdentifiedEntry entry, final MatchMakerResponse makerResponse) {
        try {
            LOG.info(IndexMaker.index(entry,makerResponse), "PADASA MatchMaker service response");

            if (makerResponse != null) {

                return makerResponse.getStatusCode().intValue() == Integer
                    .valueOf(this.getConfiguration(MatchMakerServiceConfiguration.class).successful().getCode());
            }
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.indexes(entry), "Error while checking response from MatchMakerService", e);
        }

        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#getClients()
     */
    @Override
    protected Object[] getClients() {
        return new Object[] { this.client };
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsTemplate#getPayloadName()
     */
    @Override
    protected String getServiceName() {
        return "PadasaMatchMakerDaten";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#initGateway()
     */
    @Override
    public void initGateway() throws Exception {
        final MatchMakerServiceConfiguration serviceConfiguration = this.getConfiguration(MatchMakerServiceConfiguration.class);
        final MatchmakerinsertpadasaClientEp service = new MatchmakerinsertpadasaClientEp(serviceConfiguration.getWsdlLocation());
        this.client = service.getPort(MatchMakerInsertPadasa.class);
        this.url = serviceConfiguration.getServiceUrl();
        super.initGateway();

        final HttpComponentsMessageSender messageSender = new HttpComponentsMessageSender();
        {
            String username = serviceConfiguration.getUsername();
            String password = serviceConfiguration.getPassword();
            if (StringUtil.notNullOrEmpty(username) && StringUtil.notNullOrEmpty(password)) {
                messageSender.setCredentials(new UsernamePasswordCredentials(username, password));
            }
            messageSender.setConnectionTimeout(serviceConfiguration.getConnectTimeout());
            messageSender.setReadTimeout(serviceConfiguration.getReadTimeout());
            messageSender.afterPropertiesSet();
        }
        this.getWebServiceTemplate().setMessageSender(messageSender);
        LOG.info("Initialized the http client sender");
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#setConfiguration(vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration)
     */
    @Autowired
    @Override
    public void setConfiguration(@Qualifier("MatchMakerServiceConfiguration") final AbstractSoapWsConfiguration configuration) {
        this.configuration = configuration;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.interfaces.AbstractSoapWsConsumer#transfer(java.lang.Object, java.lang.Object)
     */
    @Override
    protected MatchMakerResponse transfer(final IdentifiedEntry entry, final MatchMakerRequest payload, final MatchMakerInsertPadasa client) {
        return (MatchMakerResponse) this.getWebServiceTemplate().marshalSendAndReceive(this.url, payload);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.padasa.matchmakerdaten.IMatchMakerDatenService#transferToMatchMaker(vn.sps.aba.dds.common.model.datatransfer.ReceiverInfo)
     */
    @Override
    public boolean transferToMatchMaker(final ReceiverInfo receiverInfo) {

        try {
            final MatchMakerServiceConfiguration serviceConfiguration = this.getConfiguration(MatchMakerServiceConfiguration.class);

            receiverInfo.setMatchMakerBegin(DiscoWallClock.milli());
            final MatchMakerRequest matchMakerRequest = MessageBuilder.buildMatchMakerMessage(receiverInfo, serviceConfiguration);
            final boolean ret = this.transferCascade(receiverInfo, matchMakerRequest, this.client, this.url) != null;
            receiverInfo.setMatchMakerEnd(DiscoWallClock.milli());
            receiverInfo.countPadUp();
            if (!ret) {
                LOG.error(Markers.appendFields(receiverInfo), "Failed to transfer ReceiverInfo to Padasa MatchMakerService at url " + this.url);
            }
            return ret;
        }
        catch (final Exception e) {
            LOG.error(Markers.appendFields(receiverInfo), "There are error while building the MatchMaker message", e);
        }

        return false;
    }

}
