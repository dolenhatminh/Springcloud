/*
 * Class: ProduktZusatzleistung
 *
 * Created on May 19, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.parcel;

import java.io.Serializable;

/**
 * The Class ProduktZusatzleistung.
 */
public class ProduktZusatzleistung implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 5193335679286378381L;

    /** The code. */
    private String code;

    /**
     * Instantiates a new produkt zusatzleistung.
     */
    public ProduktZusatzleistung() {
    }

    /**
     * Instantiates a new produkt zusatzleistung.
     *
     * @param produkt the produkt
     */
    public ProduktZusatzleistung(final vn.sps.aba.dds.common.types.ws.pds.parcel.model.ProduktZusatzleistung produkt) {
        this.code = produkt.getCode();
    }

    /**
     * Gets the code.
     *
     * @return Returns the code.
     */
    public String getCode() {
        return this.code;
    }

    /**
     * Sets the code.
     *
     * @param code The code to set.
     */
    public void setCode(final String code) {
        this.code = code;
    }

    /**
     * {@inheritDoc}
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return this.code;
    }
}
