/*
 * Class: ReceiverInfoListener
 *
 * Created on Jul 9, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.listener.impl;

import org.infinispan.notifications.cachelistener.annotation.CacheEntryCreated;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryExpired;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryModified;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryRemoved;
import org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryExpiredEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import net.logstash.logback.marker.Markers;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.repository.entity.receiver.ReceiverInfoEntity;
import vn.sps.aba.dds.repository.jpa.IReceiverInfoRepository;
import vn.sps.aba.dds.repository.listener.ICacheListener;

/**
 * The listener interface for receiving receiverInfo events. The class that is
 * interested in processing a receiverInfo event implements this interface, and
 * the object created with that class is registered with a component using the
 * component's <code>addReceiverInfoListener<code> method. When the receiverInfo
 * event occurs, that object's appropriate method is invoked.
 *
 * @see ReceiverInfoEvent
 */
//@Profile(value = { Profiles.RECEIVER, Profiles.DPM, Profiles.DPMB, Profiles.DPMS })
//@Component
//@Listener(sync = false, primaryOnly = true, clustered = false, includeCurrentState = false, observation = Observation.POST)
public class ReceiverInfoListener extends AbstractCacheListener<String, ReceiverInfo> implements ICacheListener<String, ReceiverInfo> {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ReceiverInfoListener.class);

    /** The receiver info repository. */
    @Autowired
    private IReceiverInfoRepository receiverInfoRepository;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.listener.ICacheListener#add(org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent)
     */
    @Override
    @CacheEntryCreated
    public void add(final CacheEntryCreatedEvent<String, ReceiverInfo> event) {

        try {
            if (this.isValidAddedEvent(event)) {

                final ReceiverInfo receiverInfo = event.getValue();
                LOG.info(Markers.appendFields(receiverInfo), "ReceiverInfo added");
                final ReceiverInfoEntity receiverInfoEntity = new ReceiverInfoEntity(receiverInfo);

                this.receiverInfoRepository.save(receiverInfoEntity);
            }
        }
        catch (final Exception e) {
            LOG.error("Error while persisting data into database", e);
        }
    }

    /**
     * Expired.
     *
     * @param event the event
     */
    @CacheEntryExpired
    public void expired(final CacheEntryExpiredEvent<String, ReceiverInfo> event) {
        try {
            final ReceiverInfo receiverInfo = event.getValue();
            if (receiverInfo != null) {

                LOG.info(Markers.appendFields(receiverInfo), "ReceiverInfo expired");
                // Note: Don't use this event to re-store data into database

                //                final ReceiverInfoEntity receiverInfoEntity = new ReceiverInfoEntity(receiverInfo);
                //
                //                this.receiverInfoRepository.save(receiverInfoEntity);
            }
        }
        catch (final Exception e) {
            LOG.error("Error while persisting data into database", e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.listener.ICacheListener#modify(org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent)
     */
    @Override
    @CacheEntryModified
    public void modify(final CacheEntryModifiedEvent<String, ReceiverInfo> event) {

        try {
            if (this.isValidModifiedEvent(event)) {

                final ReceiverInfo receiverInfo = event.getValue();

                LOG.info(Markers.appendFields(receiverInfo), "ReceiverInfo modified");

                ReceiverInfoEntity receiverInfoEntity = this.receiverInfoRepository.findOne(receiverInfo.getKey());

                // DPM: Send an invalid message (e.g: HausKey is not under integer format ) to DPMService
                // DDS: Check the HausKey and feedback invalid message (code: 99) to DPM.
                // DPM: Correct the message and send that message to DisCo with the same IdentCode as before one.
                // DDS: Overwrite the ReceiverInfo on the cache and it will send out an modification event to this method.
                //      This method will first do: this.receiverInfoRepository.findOne(event.getKey()) => It returns the old invalid one
                //      Then it just update some specific fields in the below "else" statement
                //      => This cause a wrong update
                //      Solution for this problem: always instantiate the ReceiverInfoEntity when handle the modification event
                //          or use another primary key (Long id) in database, and ReceiverInfo cache will contains this id

                if (receiverInfoEntity != null) {
                    receiverInfoEntity.setState(receiverInfo.getState());
                    receiverInfoEntity.setStatusCode(receiverInfo.getStatusCode());

                    receiverInfoEntity.setReceivedTime(DateUtil.milliTime2Timestamp(receiverInfo.getReceived()));

                    receiverInfoEntity.setCaptureResultBegin(DateUtil.milliTime2Timestamp(receiverInfo.getCaptureResultBegin()));
                    receiverInfoEntity.setCaptureResultEnd(DateUtil.milliTime2Timestamp(receiverInfo.getCaptureResultEnd()));

                    receiverInfoEntity.setMatchMakerBegin(DateUtil.milliTime2Timestamp(receiverInfo.getMatchMakerBegin()));
                    receiverInfoEntity.setMatchMakerEnd(DateUtil.milliTime2Timestamp(receiverInfo.getCaptureResultEnd()));

                    receiverInfoEntity.setVerifiedByRule(receiverInfo.getVerifiedByRule());
                    receiverInfoEntity.setVamStationSent(receiverInfo.getVamStationSent());
                    receiverInfoEntity.setProcessStart(DateUtil.milliTime2Timestamp(receiverInfo.getProcessBegin()));
                    receiverInfoEntity.setProcessEnd(DateUtil.milliTime2Timestamp(receiverInfo.getProcessEnd()));
                }
                else {
                    receiverInfoEntity = new ReceiverInfoEntity(receiverInfo);
                }

                this.receiverInfoRepository.save(receiverInfoEntity);
            }
        }
        catch (final Exception e) {
            LOG.error("Error while persisting data into database", e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.listener.ICacheListener#remove(org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent)
     */
    @Override
    @CacheEntryRemoved
    public void remove(final CacheEntryRemovedEvent<String, ReceiverInfo> event) {
        LOG.info(Markers.appendFields(event.getValue()), "ReceiverInfo removed");
    }
}
