/*
 * Class: CacheCollectionsConfiguration
 *
 * Created on May 5, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.cache;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;

/**
 * The Class CacheCollectionsConfiguration.
 */
@Configuration
@ConfigurationProperties(prefix = "cache.receiverinfo")
public class CacheReceiverInfoConfiguration extends CacheConfiguration {

    /** The running states. */
    private String[] runningStates = new String[] { ReceiverState.RECEIVED.name(), ReceiverState.INVALID.name(), 
    	ReceiverState.VAM_PADASA_READY.name(), ReceiverState.VAM_PADASA_READY_NOT_MATCHING.name(),
        ReceiverState.VAM_PADASA_SENT.name(),ReceiverState.VAM_PADASA_SENT_NOT_MATCHING.name(),
        ReceiverState.VAM_SENT.name(), ReceiverState.VAM_SENT_NOT_MATCHING.name(),
        ReceiverState.PADASA_SENT.name(), ReceiverState.PADASA_SENT_NOT_MATCHING.name(),
        ReceiverState.VAM_READY.name(), ReceiverState.VAM_DONE.name()}; // Since ABA-89: Not use

    /**
     * Gets the running states.
     *
     * @return the running states
     */
    public String[] getRunningStates() {
        return this.runningStates;
    }

    /**
     * Sets the running states.
     *
     * @param runningStates the new running states
     */
   /* public void setRunningStates(final String[] runningStates) {
        this.runningStates = runningStates;
    }*/
}
