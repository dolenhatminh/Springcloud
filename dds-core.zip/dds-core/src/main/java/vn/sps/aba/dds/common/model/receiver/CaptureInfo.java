/*
 * Class: CaptureInfo
 *
 * Created on Jul 8, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.receiver;

import java.io.Serializable;

import vn.sps.aba.dds.common.types.ws.dpm.model.CaptureInfoType;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.common.util.JaxbUtil;

/**
 * The Class CaptureInfo.
 */
public class CaptureInfo implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -9071610186115067435L;

    /** The capture result code. */
    private String captureResultCode;

    /** The coder id. */
    private String coderId;

    /** The coding station. */
    private String codingStation;

    /** The coding time stamp. */
    private String codingTimeStamp;

    /**
     * Instantiates a new capture info.
     */
    public CaptureInfo() {
    }

    /**
     * Instantiates a new capture info.
     *
     * @param captureInfo the capture info
     */
    public CaptureInfo(final CaptureInfoType captureInfo) {

        this.setCoderId(captureInfo.getCoderId());
        this.setCodingStation(captureInfo.getCodingStation());
        this.setCodingTimeStamp(DateUtil.gregorian2String(captureInfo.getCodingTimestamp()));
        this.setCaptureResultCode(captureInfo.getCaptureResultCode().value());
    }

    /**
     * Instantiates a new capture info.
     *
     * @param captureInfo the capture info
     */
    public CaptureInfo(final vn.sps.aba.dds.common.types.ws.dpmb.CaptureInfo captureInfo) {

        this.setCoderId(captureInfo.getCoderId());
        this.setCodingStation(captureInfo.getCodingStation());
        this.setCodingTimeStamp(DateUtil.gregorian2String(captureInfo.getCodingTimestamp()));
        this.setCaptureResultCode(captureInfo.getCaptureResultCode() == null ? null : captureInfo.getCaptureResultCode().value());
    }

    /**
     * Instantiates a new capture info.
     *
     * @param captureInfo the capture info
     */
    public CaptureInfo(final vn.sps.aba.dds.common.types.ws.dpms.CaptureInfo captureInfo) {
        this.setCoderId(JaxbUtil.element2String(captureInfo.getCoderId()));
        this.setCodingStation(JaxbUtil.element2String(captureInfo.getCodingStation()));
        this.setCodingTimeStamp(JaxbUtil.element2String(captureInfo.getCodingTimestamp()));
        this.setCaptureResultCode(JaxbUtil.element2String(captureInfo.getCaptureResultCode()));
    }

    /**
     * Instantiates a new capture info.
     *
     * @param captureInfo the capture info
     */
    public CaptureInfo(final vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureInfo captureInfo) {

        this.setCoderId(captureInfo.getCoderId());
        this.setCodingStation(captureInfo.getCodingStation());
        this.setCodingTimeStamp(DateUtil.gregorian2String(captureInfo.getCodingTimestamp()));
        this.setCaptureResultCode(captureInfo.getCaptureResultCode().value());
    }

    /**
     * Gets the capture result code.
     *
     * @return the capture result code
     */
    public String getCaptureResultCode() {
        return this.captureResultCode;
    }

    /**
     * Gets the coder id.
     *
     * @return the coder id
     */
    public String getCoderId() {
        return this.coderId;
    }

    /**
     * Gets the coding station.
     *
     * @return the coding station
     */
    public String getCodingStation() {
        return this.codingStation;
    }

    /**
     * Gets the coding time stamp.
     *
     * @return the coding time stamp
     */
    public String getCodingTimeStamp() {
        return this.codingTimeStamp;
    }

    /**
     * Sets the capture result code.
     *
     * @param captureResultCode the new capture result code
     */
    public void setCaptureResultCode(final String captureResultCode) {
        this.captureResultCode = captureResultCode;
    }

    /**
     * Sets the coder id.
     *
     * @param coderId the new coder id
     */
    public void setCoderId(final String coderId) {
        this.coderId = coderId;
    }

    /**
     * Sets the coding station.
     *
     * @param codingStation the new coding station
     */
    public void setCodingStation(final String codingStation) {
        this.codingStation = codingStation;
    }

    /**
     * Sets the coding time stamp.
     *
     * @param codingTimeStamp the new coding time stamp
     */
    public void setCodingTimeStamp(final String codingTimeStamp) {
        this.codingTimeStamp = codingTimeStamp;
    }

}
