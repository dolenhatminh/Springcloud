/*
 * Class: ReceiverInfo
 *
 * Created on Jul 8, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.receiver;

import java.io.Serializable;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.types.ws.dpm.model.ReceiverInfoRequestType;
import vn.sps.aba.dds.common.types.ws.dpm.model.ReceiverInfoType;
import vn.sps.aba.dds.common.types.ws.dpmb.VolleAdresse;
import vn.sps.aba.dds.common.types.ws.dpms.Timestamps;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.AdresseErfassung;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultIn;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultRecord;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.common.util.JaxbUtil;
import vn.sps.aba.dds.common.util.StringUtil;

/**
 * The Class ReceiverInfo.
 */
@Indexed
public class ReceiverInfo implements Serializable, IdentifiedEntry {

	  /** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1835114235799277889L;

	/** The adress erfassung. */
    private AdressErfassung adressErfassung;

    /** The caller id. */
    private String callerId;

    /** The capture info. */
    private CaptureInfo captureInfo;

    /** The capture result time. */
    private volatile long captureResultBegin;

    /** The capture result count. */
    private int captureResultCount;

    /** The capture result done time. */
    private volatile long captureResultEnd;

    /** The dis co timestamp. */
    private String disCoTimestamp;

    /** The dpm time stamp. */
    private String dpmTimeStamp;

    /** The enough info. */
    @Deprecated
    private boolean enoughInfo;

    /** The haus key. */
    private String hausKey;

    /** The ident code. */
    private String identCode;

    /** The kdp id. */
    private String kdpId;

    /** The key. */
    private String key;

    /** The match maker time. */
    private volatile long matchMakerBegin;

    /** The match maker count. */
    private int matchMakerCount;

    /** The match maker done time. */
    private volatile long matchMakerEnd;

    /** The need empty amp key. */
    @Deprecated
    private boolean needEmptyAmpKey;

    /** The package id. */
    private String packageId;

    /** The parcel data. */
    private ParcelData parcelData;

    /** The parcel haus key. */
    private String parcelHausKey;

    /** The pds timestamp. */
    private String pdsTimestamp;

    /** The person key. */
    private Integer personKey;

    /** The process begin. */
    private long processBegin;

    /** The process end. */
    private long processEnd;

    /** The received. */
    private long received;

    /** The sender id. */
    private String senderId;

    /** The state. */
    private volatile ReceiverState state = ReceiverState.RECEIVED;

    /** The status code. */
    private String statusCode;

    /** The vam station sent. */
    private String vamStationSent;

    /** The verified by rule. */
    private String verifiedByRule;

    /** The version. */
    private String version;

    /** The vg timestamp. */
    private String vgTimestamp;

    /** The vn timestamp. */
    private String vnTimestamp;

    /**
     * Instantiates a new receiver info.
     */
    public ReceiverInfo() {
    }

    /**
     * Instantiates a new receiver info.
     *
     * @param captureResultRequest the capture result request
     */
    public ReceiverInfo(final CaptureResultIn captureResultRequest) {

        this.setCallerId(captureResultRequest.getCallerId());
        this.setVersion(StringUtil.integer2String(captureResultRequest.getVersion()));

        final CaptureResultRecord captureResultRecord = captureResultRequest.getCaptureResultRecord();
        {
            this.setIdentCode(captureResultRecord.getIdentcode());
            this.setSenderId(captureResultRecord.getSenderId() == null ? null : String.valueOf(captureResultRecord.getSenderId().getValue()));

            this.captureInfo = new CaptureInfo(captureResultRecord.getCaptureInfo());

            final AdresseErfassung adresseErfassung = captureResultRecord.getAdresseErfassung();
            {
                this.adressErfassung = new AdressErfassung(adresseErfassung);

                if (adresseErfassung.getHausKey() != null) {

                    this.setHausKey(adresseErfassung.getHausKey());
                }

                if (adresseErfassung.getVolleAdresse() != null) {

                    if (adresseErfassung.getVolleAdresse().getKdpId() != null) {

                        this.setKdpId(adresseErfassung.getVolleAdresse().getKdpId().getValue());
                    }
                    if (adresseErfassung.getVolleAdresse().getParcelHausKey() != null) {

                        this.setParcelHausKey(adresseErfassung.getVolleAdresse().getParcelHausKey().getValue());
                    }
                }
            }
            if (captureResultRecord.getParcelData() != null) {
                this.parcelData = new ParcelData(captureResultRecord.getParcelData().getValue());
            }

            final vn.sps.aba.dds.common.types.ws.vam.capturing.model.Timestamps timestamps = captureResultRecord.getTimestamps();
            this.disCoTimestamp = DateUtil.gregorian2String(timestamps.getDisCoTimestamp());
            this.pdsTimestamp = DateUtil.gregorian2String(timestamps.getPdsTimestamp());
            this.vgTimestamp = DateUtil.gregorian2String(timestamps.getVGTimestamp());
            this.vnTimestamp = DateUtil.gregorian2String(timestamps.getVnTimestamp());
        }
    }

    /**
     * Instantiates a new receiver info.
     *
     * @param receiverInfoRequestType
     *            the receiver info request type
     */
    public ReceiverInfo(final ReceiverInfoRequestType receiverInfoRequestType) {

        final ReceiverInfoType receiverInfoType = receiverInfoRequestType.getReceiverInfo();
        if (receiverInfoType.getCaptureInfo() != null) {
            this.captureInfo = new CaptureInfo(receiverInfoType.getCaptureInfo());
        }
        this.setIdentCode(receiverInfoType.getIdentcode());
        this.setSenderId(receiverInfoType.getSenderId() == null ? null : String.valueOf(receiverInfoType.getSenderId().getValue()));
        this.setDpmTimeStamp(DateUtil.gregorian2String(receiverInfoType.getDPMTimestamp()));
        this.setCallerId(receiverInfoRequestType.getCallerId());
        this.setVersion(StringUtil.integer2String(receiverInfoRequestType.getVersion()));

        if (receiverInfoType.getAdresseErfassung() != null) {

            this.adressErfassung = new AdressErfassung(receiverInfoType.getAdresseErfassung());

            if (receiverInfoType.getAdresseErfassung().getHausKey() != null) {

                this.setHausKey(String.valueOf(receiverInfoType.getAdresseErfassung().getHausKey().getValue()));
            }
            if (receiverInfoType.getAdresseErfassung().getVolleAdresse() != null) {

                if (receiverInfoType.getAdresseErfassung().getVolleAdresse().getKdpId() != null) {
                    this.setKdpId(String.valueOf(receiverInfoType.getAdresseErfassung().getVolleAdresse().getKdpId().getValue()));
                }
                if (receiverInfoType.getAdresseErfassung().getVolleAdresse().getParcelHausKey() != null) {
                    this.setParcelHausKey(String.valueOf(receiverInfoType.getAdresseErfassung().getVolleAdresse().getParcelHausKey().getValue()));
                }
            }
        }
    }

    /**
     * Instantiates a new receiver info.
     *
     * @param callerId the caller id
     * @param version the version
     * @param captureResultRecord the capture result record
     */
    public ReceiverInfo(final String callerId, final int version, final vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultRecord captureResultRecord) {

        this.callerId = callerId;
        this.version = String.valueOf(version);

        this.setIdentCode(captureResultRecord.getIdentcode());
        this.setSenderId(String.valueOf(captureResultRecord.getSenderId()));

        this.captureInfo = new CaptureInfo(captureResultRecord.getCaptureInfo());

        final vn.sps.aba.dds.common.types.ws.dpmb.AdresseErfassung adresseErfassung = captureResultRecord.getAdresseErfassung();
        {
            this.adressErfassung = new AdressErfassung(adresseErfassung);
            this.setHausKey(adresseErfassung.getHausKey());
            final VolleAdresse volleAdresse = adresseErfassung.getVolleAdresse();
            {
                this.setKdpId(volleAdresse.getKdpId());
                this.setParcelHausKey(volleAdresse.getParcelHausKey());
            }
        }
        if (captureResultRecord.getParcelData() != null) {
            this.parcelData = new ParcelData(captureResultRecord.getParcelData());
        }
        final vn.sps.aba.dds.common.types.ws.dpmb.Timestamps timestamps = captureResultRecord.getTimestamps();
        if (timestamps != null) {
            this.disCoTimestamp = DateUtil.gregorian2String(timestamps.getDisCoTimestamp());
            this.pdsTimestamp = DateUtil.gregorian2String(timestamps.getPdsTimestamp());
            this.vgTimestamp = DateUtil.gregorian2String(timestamps.getVGTimestamp());
            this.vnTimestamp = DateUtil.gregorian2String(timestamps.getVnTimestamp());
        }
    }

    /**
     * Instantiates a new receiver info.
     *
     * @param key the key
     * @param callerId the caller id
     * @param version the version
     * @param receivedTime the received time
     */
    public ReceiverInfo(final String key, final String callerId, final int version, final long receivedTime) {
        this.key = key;
        this.callerId = callerId;
        this.version = String.valueOf(version);
        this.setReceived(receivedTime);
    }

    /**
     * Instantiates a new receiver info.
     *
     * @param callerId the caller id
     * @param version the version
     * @param captureResultRecord the capture result record
     */
    public ReceiverInfo(final String callerId, final String version, final vn.sps.aba.dds.common.types.ws.dpms.CaptureResultRecord captureResultRecord) {
        this.callerId = callerId;
        this.version = version;

        this.setIdentCode(JaxbUtil.element2String(captureResultRecord.getIdentcode()));
        this.setSenderId(JaxbUtil.element2String(captureResultRecord.getSenderId()));

        this.captureInfo = new CaptureInfo(captureResultRecord.getCaptureInfo().getValue());

        final vn.sps.aba.dds.common.types.ws.dpms.AdresseErfassung adresseErfassung = captureResultRecord.getAdresseErfassung().getValue();
        {
            this.adressErfassung = new AdressErfassung(adresseErfassung);
            this.setHausKey(adresseErfassung.getHausKey().getValue());
            final vn.sps.aba.dds.common.types.ws.dpms.VolleAdresse volleAdresse = adresseErfassung.getVolleAdresse().getValue();
            {
                this.setKdpId(JaxbUtil.element2String(volleAdresse.getKdpId()));
                this.setParcelHausKey(JaxbUtil.element2String(volleAdresse.getParcelHausKey()));
            }
        }
        if (captureResultRecord.getParcelData() != null) {
            this.parcelData = new ParcelData(captureResultRecord.getParcelData().getValue());
        }
        final Timestamps timestamps = captureResultRecord.getTimestamps().getValue();
        this.disCoTimestamp = JaxbUtil.element2String(timestamps.getDisCoTimestamp());
        this.pdsTimestamp = JaxbUtil.element2String(timestamps.getPdsTimestamp());
        this.vgTimestamp = JaxbUtil.element2String(timestamps.getVGTimestamp());
        this.vnTimestamp = JaxbUtil.element2String(timestamps.getVnTimestamp());
    }

    /**
     * Instantiates a new receiver info.
     *
     * @param callerId the caller id
     * @param version the version
     * @param captureResultRecord the capture result record
     * @param strickly the strickly
     */
    public ReceiverInfo(final String callerId, final String version, final vn.sps.aba.dds.common.types.ws.dpms.CaptureResultRecord captureResultRecord,
            final boolean strickly) {
        this.callerId = callerId;
        this.version = version;

        this.setSenderId(JaxbUtil.element2String(captureResultRecord.getSenderId()));

        if (captureResultRecord.getCaptureInfo() != null) {
            this.captureInfo = new CaptureInfo(captureResultRecord.getCaptureInfo().getValue());
        }
        if (captureResultRecord.getAdresseErfassung() != null) {
            final vn.sps.aba.dds.common.types.ws.dpms.AdresseErfassung adresseErfassung = captureResultRecord.getAdresseErfassung().getValue();

            this.adressErfassung = new AdressErfassung(adresseErfassung);
            this.setHausKey(JaxbUtil.element2String(adresseErfassung.getHausKey()));

            if (adresseErfassung.getVolleAdresse() != null) {
                final vn.sps.aba.dds.common.types.ws.dpms.VolleAdresse volleAdresse = adresseErfassung.getVolleAdresse().getValue();
                this.setKdpId(JaxbUtil.element2String(volleAdresse.getKdpId()));
                this.setParcelHausKey(JaxbUtil.element2String(volleAdresse.getParcelHausKey()));
            }
        }
        if (captureResultRecord.getParcelData() != null) {
            this.parcelData = new ParcelData(captureResultRecord.getParcelData().getValue());
        }
        if (captureResultRecord.getTimestamps() != null) {
            final Timestamps timestamps = captureResultRecord.getTimestamps().getValue();
            this.disCoTimestamp = JaxbUtil.element2String(timestamps.getDisCoTimestamp());
            this.pdsTimestamp = JaxbUtil.element2String(timestamps.getPdsTimestamp());
            this.vgTimestamp = JaxbUtil.element2String(timestamps.getVGTimestamp());
            this.vnTimestamp = JaxbUtil.element2String(timestamps.getVnTimestamp());
        }
    }

    /**
     * Count pad up.
     */
    public void countPadUp() {
        this.matchMakerCount++;
    }

    /**
     * Count vam up.
     */
    public void countVamUp() {
        this.captureResultCount++;
    }

    /**
     * {@inheritDoc}
     *
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() != obj.getClass()) {
            return false;
        }
        final ReceiverInfo other = (ReceiverInfo) obj;
        if (this.key == null) {
            if (other.key != null) {
                return false;
            }
        }
        else if (!this.key.equals(other.key)) {
            return false;
        }
        return true;
    }

    /**
     * Gets the adress erfassung.
     *
     * @return the adress erfassung
     */
    public AdressErfassung getAdressErfassung() {
        return this.adressErfassung;
    }

    /**
     * Gets the caller id.
     *
     * @return the caller id
     */
    public String getCallerId() {
        return this.callerId;
    }

    /**
     * Gets the capture info.
     *
     * @return the capture info
     */
    public CaptureInfo getCaptureInfo() {
        return this.captureInfo;
    }

    /**
     * Gets the capture result begin.
     *
     * @return the capture result begin
     */
    public long getCaptureResultBegin() {
        return this.captureResultBegin;
    }

    /**
     * Gets the capture result count.
     *
     * @return the capture result count
     */
    public int getCaptureResultCount() {
        return this.captureResultCount;
    }

    /**
     * Gets the capture result end.
     *
     * @return the capture result end
     */
    public long getCaptureResultEnd() {
        return this.captureResultEnd;
    }

    /**
     * Gets the dis co timestamp.
     *
     * @return the dis co timestamp
     */
    public String getDisCoTimestamp() {
        return this.disCoTimestamp;
    }

    /**
     * Gets the dpm time stamp.
     *
     * @return the dpm time stamp
     */
    public String getDpmTimeStamp() {
        return this.dpmTimeStamp;
    }

    /**
     * Gets the haus key.
     *
     * @return the haus key
     */
    public String getHausKey() {
        return this.hausKey;
    }

    /**
     * Gets the ident code.
     *
     * @return the ident code
     */
    @Override
    @Field(store = Store.YES, analyze = Analyze.NO, name = DDSConstant.ReceiverFields.FIELD_IDENT_CODE)
    public String getIdentCode() {
        return this.identCode;
    }

    /**
     * Gets the kdp id.
     *
     * @return the kdp id
     */
    public String getKdpId() {
        return this.kdpId;
    }

    /**
     * Gets the key.
     *
     * @return the key
     */
    @Override
    @Field(store = Store.YES, analyze = Analyze.NO, name = DDSConstant.ReceiverFields.FIELD_KEY)
    public String getKey() {
        return this.key;
    }

    /**
     * Gets the match maker begin.
     *
     * @return the match maker begin
     */
    public long getMatchMakerBegin() {
        return this.matchMakerBegin;
    }

    /**
     * Gets the match maker count.
     *
     * @return the match maker count
     */
    public int getMatchMakerCount() {
        return this.matchMakerCount;
    }

    /**
     * Gets the match maker end.
     *
     * @return the match maker end
     */
    public long getMatchMakerEnd() {
        return this.matchMakerEnd;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getMinorState()
     */
    @Override
    public String getMinorState() {
        return null;
    }

    /**
     * Gets the package id.
     *
     * @return the package id
     */
    public String getPackageId() {
        return this.packageId;
    }

    /**
     * Gets the parcel data.
     *
     * @return the parcel data
     */
    public ParcelData getParcelData() {
        return this.parcelData;
    }

    /**
     * Gets the parcel haus key.
     *
     * @return the parcel haus key
     */
    public String getParcelHausKey() {
        return this.parcelHausKey;
    }

    /**
     * Gets the pds timestamp.
     *
     * @return the pds timestamp
     */
    public String getPdsTimestamp() {
        return this.pdsTimestamp;
    }

    /**
     * Gets the person key.
     *
     * @return the person key
     */
    public Integer getPersonKey() {
        return this.personKey;
    }

    /**
     * Gets the process begin.
     *
     * @return the process begin
     */
    public long getProcessBegin() {
        return this.processBegin;
    }

    /**
     * Gets the process end.
     *
     * @return the process end
     */
    public long getProcessEnd() {
        return this.processEnd;
    }

    /**
     * Gets the received.
     *
     * @return the received
     */
    @Override
    @Field(store = Store.YES, analyze = Analyze.NO, name = DDSConstant.ReceiverFields.FIELD_RECEIVED_TIME)
    public long getReceived() {
        return this.received;
    }

    /**
     * Gets the receiver state.
     *
     * @return the receiver state
     */
    public ReceiverState getReceiverState() {
        return this.state;
    }

    /**
     * Gets the sender id.
     *
     * @return the sender id
     */
    public String getSenderId() {
        return this.senderId;
    }

    /**
     * Gets the state.
     *
     * @return the state
     */
    @Override
    @Field(store = Store.YES, analyze = Analyze.NO, name = DDSConstant.ReceiverFields.FIELD_STATE)
    public String getState() {
        return this.state.name();
    }

    /**
     * Gets the status code.
     *
     * @return the status code
     */
    public String getStatusCode() {
        return this.statusCode;
    }

    /**
     * Gets the vam station sent.
     *
     * @return the vam station sent
     */
    public String getVamStationSent() {
        return this.vamStationSent;
    }

    /**
     * Gets the verified by rule.
     *
     * @return the verified by rule
     */
    public String getVerifiedByRule() {
        return this.verifiedByRule;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public String getVersion() {
        return this.version;
    }

    /**
     * Gets the vg timestamp.
     *
     * @return the vg timestamp
     */
    public String getVgTimestamp() {
        return this.vgTimestamp;
    }

    /**
     * Gets the vn timestamp.
     *
     * @return the vn timestamp
     */
    public String getVnTimestamp() {
        return this.vnTimestamp;
    }

    /**
     * {@inheritDoc}
     *
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = (prime * result) + ((this.key == null) ? 0 : this.key.hashCode());
        return result;
    }

    /**
     * Checks if is enough info.
     *
     * @return true, if is enough info
     */
    public boolean isEnoughInfo() {
        return this.enoughInfo;
    }

    /**
     * Checks if is need empty amp key.
     *
     * @return true, if is need empty amp key
     */
    public boolean isNeedEmptyAmpKey() {
        return this.needEmptyAmpKey;
    }

    /**
     * Sets the adress erfassung.
     *
     * @param adressErfassung
     *            the new adress erfassung
     */
    public void setAdressErfassung(final AdressErfassung adressErfassung) {
        this.adressErfassung = adressErfassung;
    }

    /**
     * Sets the caller id.
     *
     * @param callerId
     *            the new caller id
     */
    public void setCallerId(final String callerId) {
        this.callerId = callerId;
    }

    /**
     * Sets the capture info.
     *
     * @param captureInfo
     *            the new capture info
     */
    public void setCaptureInfo(final CaptureInfo captureInfo) {
        this.captureInfo = captureInfo;
    }

    /**
     * Sets the capture result begin.
     *
     * @param captureResultBegin the new capture result begin
     */
    public void setCaptureResultBegin(final long captureResultBegin) {
        this.captureResultBegin = captureResultBegin;
    }

    /**
     * Sets the capture result count.
     *
     * @param captureResultCount the new capture result count
     */
    public void setCaptureResultCount(final int captureResultCount) {
        this.captureResultCount = captureResultCount;
    }

    /**
     * Sets the capture result end.
     *
     * @param captureResultEnd the new capture result end
     */
    public void setCaptureResultEnd(final long captureResultEnd) {
        this.captureResultEnd = captureResultEnd;
    }

    /**
     * Sets the dis co timestamp.
     *
     * @param disCoTimestamp the new dis co timestamp
     */
    public void setDisCoTimestamp(final String disCoTimestamp) {
        this.disCoTimestamp = disCoTimestamp;
    }

    /**
     * Sets the dpm time stamp.
     *
     * @param dpmTimeStamp
     *            the new dpm time stamp
     */
    public void setDpmTimeStamp(final String dpmTimeStamp) {
        this.dpmTimeStamp = dpmTimeStamp;
    }

    /**
     * Sets the enough info.
     *
     * @param enoughInfo the new enough info
     */
    public void setEnoughInfo(final boolean enoughInfo) {
        this.enoughInfo = enoughInfo;
    }

    /**
     * Sets the haus key.
     *
     * @param hausKey the new haus key
     */
    public void setHausKey(final String hausKey) {
        this.hausKey = hausKey;
    }

    /**
     * Sets the ident code.
     *
     * @param identCode
     *            the new ident code
     */
    public void setIdentCode(final String identCode) {
        this.identCode = identCode;
    }

    /**
     * Sets the kdp id.
     *
     * @param kdpId the new kdp id
     */
    public void setKdpId(final String kdpId) {
        this.kdpId = kdpId;
    }

    /**
     * Sets the key.
     *
     * @param key the new key
     */
    public void setKey(final String key) {
        this.key = key;
    }

    /**
     * Sets the match maker begin.
     *
     * @param matchMakerBegin the new match maker begin
     */
    public void setMatchMakerBegin(final long matchMakerBegin) {
        this.matchMakerBegin = matchMakerBegin;
    }

    /**
     * Sets the match maker count.
     *
     * @param matchMakerCount the new match maker count
     */
    public void setMatchMakerCount(final int matchMakerCount) {
        this.matchMakerCount = matchMakerCount;
    }

    /**
     * Sets the match maker end.
     *
     * @param matchMakerEnd the new match maker end
     */
    public void setMatchMakerEnd(final long matchMakerEnd) {
        this.matchMakerEnd = matchMakerEnd;
    }

    /**
     * Sets the need empty amp key.
     *
     * @param needEmptyAmpKey the new need empty amp key
     */
    public void setNeedEmptyAmpKey(final boolean needEmptyAmpKey) {
        this.needEmptyAmpKey = needEmptyAmpKey;
    }

    /**
     * Sets the package id.
     *
     * @param packageId the new package id
     */
    public void setPackageId(final String packageId) {
        this.packageId = packageId;
    }

    /**
     * Sets the parcel data.
     *
     * @param parcelData the new parcel data
     */
    public void setParcelData(final ParcelData parcelData) {
        this.parcelData = parcelData;
    }

    /**
     * Sets the parcel haus key.
     *
     * @param parcelHausKey the new parcel haus key
     */
    public void setParcelHausKey(final String parcelHausKey) {
        this.parcelHausKey = parcelHausKey;
    }

    /**
     * Sets the pds timestamp.
     *
     * @param pdsTimestamp the new pds timestamp
     */
    public void setPdsTimestamp(final String pdsTimestamp) {
        this.pdsTimestamp = pdsTimestamp;
    }

    /**
     * Sets the person key.
     *
     * @param personKey
     *            the new person key
     */
    public void setPersonKey(final Integer personKey) {
        this.personKey = personKey;
    }

    /**
     * Sets the process begin.
     *
     * @param processBegin the new process begin
     */
    public void setProcessBegin(final long processBegin) {
        this.processBegin = processBegin;
    }

    /**
     * Sets the process end.
     *
     * @param processEnd the new process end
     */
    public void setProcessEnd(final long processEnd) {
        this.processEnd = processEnd;
    }

    /**
     * Sets the received.
     *
     * @param received the new received
     */
    public void setReceived(final long received) {
        this.received = received;
    }

    /**
     * Sets the sender id.
     *
     * @param senderId
     *            the new sender id
     */
    public void setSenderId(final String senderId) {
        this.senderId = senderId;
    }

    /**
     * Sets the state.
     *
     * @param state
     *            the new state
     */
    public void setState(final ReceiverState state) {
        synchronized (state) {
            this.state = state;
        }
    }

    /**
     * Sets the status code.
     *
     * @param statusCode the new status code
     */
    public void setStatusCode(final String statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Sets the vam station sent.
     *
     * @param vamStationSent the new vam station sent
     */
    public void setVamStationSent(final String vamStationSent) {
        this.vamStationSent = vamStationSent;
    }

    /**
     * Sets the verified by rule.
     *
     * @param verifiedByRule
     *            the new verified by rule
     */
    public void setVerifiedByRule(final String verifiedByRule) {
        this.verifiedByRule = verifiedByRule;
    }

    /**
     * Sets the version.
     *
     * @param version
     *            the new version
     */
    public void setVersion(final String version) {
        this.version = version;
    }

    /**
     * Sets the vg timestamp.
     *
     * @param vgTimestamp the new vg timestamp
     */
    public void setVgTimestamp(final String vgTimestamp) {
        this.vgTimestamp = vgTimestamp;
    }

    /**
     * Sets the vn timestamp.
     *
     * @param vnTimestamp the new vn timestamp
     */
    public void setVnTimestamp(final String vnTimestamp) {
        this.vnTimestamp = vnTimestamp;
    }

    /**
     * To short string.
     *
     * @return the string
     */
    public String toShortString() {
        return "IdentCode:" + this.identCode + ";KdpId:" + this.kdpId + ";HausKey:" + this.hausKey + ";ParcelHausKey:" + this.parcelHausKey + ";State:"
                + this.state;
    }
}
