/*
 * Class: FullAddressEntity
 *
 * Created on Jul 5, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.entity.parcel;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import vn.sps.aba.dds.common.constant.TableNames;
import vn.sps.aba.dds.common.model.parcel.FullAddress;

/**
 * The Class FullAddressEntity.
 */
@Entity
@Table(name = TableNames.PAR_FULL_ADDRESS)
@Access(AccessType.PROPERTY)
public class FullAddressEntity implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 4486664860215259643L;

    /** The address type. */
    private String addressType;

    /** The angle. */
    private String angle;

    /** The id. */
    private Long id;

    /** The ort. */
    private String ort;

    /** The postleitzahl. */
    private String postleitzahl;

    /** The strasse. */
    private String strasse;

    /** The strassen nummer. */
    private String strassenNummer;

    /** The vertices. */
    private String vertices;

    /** The x1. */
    private String x1;

    /** The x2. */
    private String x2;

    /** The x3. */
    private String x3;

    /** The x4. */
    private String x4;

    /** The y1. */
    private String y1;

    /** The y2. */
    private String y2;

    /** The y3. */
    private String y3;

    /** The y4. */
    private String y4;

    /** The zip base. */
    private String zipBase;

    /**
     * Instantiates a new full address entity.
     */
    public FullAddressEntity() {
    }

    /**
     * Instantiates a new full address entity.
     *
     * @param fullAddress
     *            the full address
     */
    public FullAddressEntity(final FullAddress fullAddress) {

        this.setAddressType(fullAddress.getAddressType());
        this.setAngle(fullAddress.getAngle());
        this.setOrt(fullAddress.getOrt());
        this.setPostleitzahl(fullAddress.getPostleitzahl());
        this.setStrasse(fullAddress.getStrasse());
        this.setStrassenNummer(fullAddress.getStrassenNummer());
        this.setVertices(fullAddress.getVertices());
        this.setZipBase(fullAddress.getZipBase());

        if (fullAddress.getBoundary() != null) {
            this.setX1(fullAddress.getBoundary().getX1());
            this.setX2(fullAddress.getBoundary().getX2());
            this.setX3(fullAddress.getBoundary().getX3());
            this.setX4(fullAddress.getBoundary().getX4());
            this.setY1(fullAddress.getBoundary().getY1());
            this.setY2(fullAddress.getBoundary().getY2());
            this.setY3(fullAddress.getBoundary().getY3());
            this.setY4(fullAddress.getBoundary().getY4());
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.parcel.FullAddress#getAddressType()
     */

    @Column(name = "address_type", length = 20)
    public String getAddressType() {
        return this.addressType;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.parcel.FullAddress#getAngle()
     */

    @Column(name = "angle", length = 10)
    public String getAngle() {
        return this.angle;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    @Id
    @SequenceGenerator(name = "full_address_generator", sequenceName = "full_address_seq", initialValue = 1, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "full_address_generator")
    @JoinColumn(name = "id", columnDefinition = "bigserial")
    public Long getId() {
        return this.id;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.parcel.FullAddress#getOrt()
     */

    @Column(name = "ort", length = 50)
    public String getOrt() {
        return this.ort;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.parcel.FullAddress#getPostleitzahl()
     */

    @Column(name = "postleitzahl", length = 20)
    public String getPostleitzahl() {
        return this.postleitzahl;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.parcel.FullAddress#getStrasse()
     */

    @Column(name = "strasse", length = 100)
    public String getStrasse() {
        return this.strasse;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.parcel.FullAddress#getStrassenNummer()
     */

    @Column(name = "strassen_nummer", length = 20)
    public String getStrassenNummer() {
        return this.strassenNummer;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.parcel.FullAddress#getVertices()
     */

    @Column(name = "vertices", length = 50)
    public String getVertices() {
        return this.vertices;
    }

    /**
     * Gets the x1.
     *
     * @return the x1
     */
    @Column(name = "x1", length = 10)
    public String getX1() {
        return this.x1;
    }

    /**
     * Gets the x2.
     *
     * @return the x2
     */
    @Column(name = "x2", length = 10)
    public String getX2() {
        return this.x2;
    }

    /**
     * Gets the x3.
     *
     * @return the x3
     */
    @Column(name = "x3", length = 10)
    public String getX3() {
        return this.x3;
    }

    /**
     * Gets the x4.
     *
     * @return the x4
     */
    @Column(name = "x4", length = 10)
    public String getX4() {
        return this.x4;
    }

    /**
     * Gets the y1.
     *
     * @return the y1
     */
    @Column(name = "y1", length = 10)
    public String getY1() {
        return this.y1;
    }

    /**
     * Gets the y2.
     *
     * @return the y2
     */
    @Column(name = "y2", length = 10)
    public String getY2() {
        return this.y2;
    }

    /**
     * Gets the y3.
     *
     * @return the y3
     */
    @Column(name = "y3", length = 10)
    public String getY3() {
        return this.y3;
    }

    /**
     * Gets the y4.
     *
     * @return the y4
     */
    @Column(name = "y4", length = 10)
    public String getY4() {
        return this.y4;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.parcel.FullAddress#getZipBase()
     */

    @Column(name = "zip_base", length = 20)
    public String getZipBase() {
        return this.zipBase;
    }

    /**
     * Sets the address type.
     *
     * @param addressType
     *            the new address type
     */
    private void setAddressType(final String addressType) {
        this.addressType = addressType;
    }

    /**
     * Sets the angle.
     *
     * @param angle
     *            the new angle
     */
    private void setAngle(final String angle) {
        this.angle = angle;

    }

    /**
     * Sets the id.
     *
     * @param id
     *            the new id
     */
    public void setId(final Long id) {
        this.id = id;
    }

    /**
     * Sets the ort.
     *
     * @param ort
     *            the new ort
     */
    private void setOrt(final String ort) {
        this.ort = ort;
    }

    /**
     * Sets the postleitzahl.
     *
     * @param postleitzahl
     *            the new postleitzahl
     */
    private void setPostleitzahl(final String postleitzahl) {
        this.postleitzahl = postleitzahl;
    }

    /**
     * Sets the strasse.
     *
     * @param strasse
     *            the new strasse
     */
    private void setStrasse(final String strasse) {
        this.strasse = strasse;

    }

    /**
     * Sets the strassen nummer.
     *
     * @param strassenNummer
     *            the new strassen nummer
     */
    private void setStrassenNummer(final String strassenNummer) {
        this.strassenNummer = strassenNummer;

    }

    /**
     * Sets the vertices.
     *
     * @param vertices
     *            the new vertices
     */
    private void setVertices(final String vertices) {
        this.vertices = vertices;
    }

    /**
     * Sets the x1.
     *
     * @param x1
     *            the new x1
     */
    public void setX1(final String x1) {
        this.x1 = x1;
    }

    /**
     * Sets the x2.
     *
     * @param x2
     *            the new x2
     */
    public void setX2(final String x2) {
        this.x2 = x2;
    }

    /**
     * Sets the x3.
     *
     * @param x3
     *            the new x3
     */
    public void setX3(final String x3) {
        this.x3 = x3;
    }

    /**
     * Sets the x4.
     *
     * @param x4
     *            the new x4
     */
    public void setX4(final String x4) {
        this.x4 = x4;
    }

    /**
     * Sets the y1.
     *
     * @param y1
     *            the new y1
     */
    public void setY1(final String y1) {
        this.y1 = y1;
    }

    /**
     * Sets the y2.
     *
     * @param y2
     *            the new y2
     */
    public void setY2(final String y2) {
        this.y2 = y2;
    }

    /**
     * Sets the y3.
     *
     * @param y3
     *            the new y3
     */
    public void setY3(final String y3) {
        this.y3 = y3;
    }

    /**
     * Sets the y4.
     *
     * @param y4
     *            the new y4
     */
    public void setY4(final String y4) {
        this.y4 = y4;
    }

    /**
     * Sets the zip base.
     *
     * @param zipBase
     *            the new zip base
     */
    public void setZipBase(final String zipBase) {
        this.zipBase = zipBase;
    }
}
