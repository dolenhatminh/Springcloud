/*
 * Class: DefaultDpmValidator
 *
 * Created on Oct 7, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.dpms.impl;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBElement;
import javax.xml.transform.Result;
import javax.xml.transform.Source;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.xml.transform.StringResult;
import org.springframework.xml.transform.StringSource;
import org.springframework.xml.validation.XmlValidator;
import org.xml.sax.SAXParseException;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.ws.dpms.AddressFields;
import vn.sps.aba.dds.common.types.ws.dpms.AdresseErfassung;
import vn.sps.aba.dds.common.types.ws.dpms.CaptureResultRecord;
import vn.sps.aba.dds.common.types.ws.dpms.ObjectFactory;
import vn.sps.aba.dds.common.types.ws.dpms.VolleAdresse;
import vn.sps.aba.dds.common.util.JaxbUtil;
import vn.sps.aba.dds.config.service.DpmsServiceConfiguration;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.receiver.ReceiverProcessingManager;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;
import vn.sps.aba.dds.service.validation.dpms.IReceiverValidator;
import vn.sps.aba.dds.service.validation.dpms.PackageValidatingInfo;
import vn.sps.aba.dds.service.validation.dpms.ReceiverValidatingInfo;

/**
 * The Class DefaultDpmValidator.
 */
@Component
@Configuration
@ConfigurationProperties(prefix = "ws.dpms.validation")
@ConditionalOnProperty(name = "dpm.validator", havingValue = "vn.sps.aba.dds.service.validation.dpms.impl.ABA32Validator")
public class ABA32Validator implements IReceiverValidator {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ABA32Validator.class);

    /** The Constant RULE_AMPKEY_NAME. */
    private static final String RULE_AMPKEY_NAME = "AMPKeyName";

    /** The Constant RULE_AMPKEY_NO_NAME. */
    private static final String RULE_AMPKEY_NO_NAME = "AMPKeyNoName";

    /** The Constant RULE_NO_AMPKEY_NAME. */
    private static final String RULE_NO_AMPKEY_NAME = "NoAMPKeyName";

    /** The Constant RULE_NO_AMPKEY_NO_NAME. */
    private static final String RULE_NO_AMPKEY_NO_NAME = "NoAMPKeyNoName";

    /** The process manager. */
    @Autowired
    private ReceiverProcessingManager processManager;

    /** The receiver info DAO. */
    @Autowired
    private IReceiverInfoCacheDao receiverInfoDao;

    /** The service configuration. */
    @Autowired
    private DpmsServiceConfiguration serviceConfiguration;

    /** The verified rule names. */
    private final Map<String, String> verifiedRuleNames = new HashMap<>();

    /**
     * Apply manged info.
     *
     * @param receiverInfo the receiver info
     */
    @Override
    public void applyMangedInfo(final ReceiverInfo receiverInfo) {
    }

    /**
     * Check xsd compliance.
     *
     * @param key the key
     * @param receiverInfoRecord the receiver info record
     * @param errorHandler the error handler
     * @param receiverValidatingInfo the receiver validating info
     */
    private void checkXsdCompliance(
        final String key,
        final CaptureResultRecord receiverInfoRecord,
        final SimpleErrorHandler errorHandler,
        final ReceiverValidatingInfo receiverValidatingInfo) {
        try {
            // Validate the receiver info by XSD schema
            final ObjectFactory objectFactory = this.serviceConfiguration.getObjectFactory();
            final JAXBElement<CaptureResultRecord> element = objectFactory.createCaptureResultRecord(receiverInfoRecord);
            final Result result = new StringResult();
            this.serviceConfiguration.getMarshaller().marshal(element, result);
            final XmlValidator createValidator = this.serviceConfiguration.getXsdValidationSchemas().createValidator();
            final String content = result.toString();
            final Source source = new StringSource(content);

            createValidator.validate(source, errorHandler);
        }
        catch (final Exception e) {
            receiverValidatingInfo.getErrors().add("Unexpected error occured when validate receiver info");
            LOG.error(IndexMaker.indexes(receiverValidatingInfo), "There is error when validating receiver info", e);
        }
    }

    /**
     * Gets the verified rule names.
     *
     * @return the verified rule names
     */
    public Map<String, String> getVerifiedRuleNames() {
        return this.verifiedRuleNames;
    }

    /**
     * Checks if is verified address.
     *
     * @param key the key
     * @param validatingInfo the validating info
     * @return true, if is verified address
     */
    private boolean isVerifiedAddress(final String key, final ReceiverValidatingInfo validatingInfo) {

        try {
            // Note: The receiver info must go through XSD Validation before go to this verification
            // Then we have the following object not null
            //
            final CaptureResultRecord receiverInfoRecord = validatingInfo.getReceiverInfo();
            final AdresseErfassung adresseErfassung = receiverInfoRecord.getAdresseErfassung().getValue();
            final VolleAdresse volleAddress = adresseErfassung.getVolleAdresse().getValue();
            final AddressFields addressFields = volleAddress.getFields().getValue();

            if (JaxbUtil.nullOrEmpty(addressFields.getPostleitzahl())) {
                validatingInfo.getErrors().add("The address fields must contains Postleitzahl");
            }
            if (JaxbUtil.nullOrEmpty(addressFields.getOrt())) {
                validatingInfo.getErrors().add("The address fields must contains Ort");
            }
            if (JaxbUtil.nullOrEmpty(volleAddress.getParcelStreetNr())) {
                validatingInfo.getErrors().add("The address fields must contains ParcelStreetNr");
            }
            if (JaxbUtil.nullOrEmpty(addressFields.getStrasse()) && JaxbUtil.nullOrEmpty(addressFields.getPostfach())) {
                validatingInfo.getErrors().add("The address fields must contains at least Strasse or Postfach");
            }
            if (JaxbUtil.lessThanOne(volleAddress.getParcelHausKey()) && JaxbUtil.lessThanOne(adresseErfassung.getHausKey())) {
                validatingInfo.getErrors().add("The address fields must contains at least ParcelHausKey or HausKey");
            }
            if (validatingInfo.isValid()) {
                final boolean noName = JaxbUtil.nullOrEmpty(addressFields.getName()) && JaxbUtil.nullOrEmpty(addressFields.getFirmenname());
                final boolean noAmpKey = JaxbUtil.lessThanOne(volleAddress.getKdpId());
                ReceiverState state = ReceiverState.VAM_READY;
                String verifiedRuleKey = RULE_NO_AMPKEY_NO_NAME;
                // BUC-3: ABA-89: Transfer all to VAM and PADASA
                if (noName && noAmpKey) {
                    // state = ReceiverState.VAM_READY;
                	state = ReceiverState.VAM_PADASA_READY_NOT_MATCHING;
                    verifiedRuleKey = RULE_NO_AMPKEY_NO_NAME;
                }
                else if (noName) {
                    // state = ReceiverState.VAM_READY;
                	state = ReceiverState.VAM_PADASA_READY_NOT_MATCHING;
                    verifiedRuleKey = RULE_AMPKEY_NO_NAME;
                }
                else if (noAmpKey) {
                    // state = ReceiverState.VAM_READY;
                    state = ReceiverState.VAM_PADASA_READY_NOT_MATCHING;
                    verifiedRuleKey = RULE_NO_AMPKEY_NAME;
                }
                else {
                    // Has enough Name/Firmaname and KdpId
                    state = ReceiverState.VAM_PADASA_READY;
                    verifiedRuleKey = RULE_AMPKEY_NAME;
                }
                String verifiedRule = this.verifiedRuleNames.get(verifiedRuleKey);
                validatingInfo.setResultState(state);
                validatingInfo.setVerifiedRule(verifiedRule);
                LOG.info("Receiver info was verified by rule [{}]", verifiedRule);
            }
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.indexes(validatingInfo), "Error when checking receiver address fields.", e);
        }

        return validatingInfo.isValid();
    }

    /**
     * Process invalid receiver info.
     *
     * @param key the key
     * @param receiverValidatingInfo the receiver validating info
     * @param packageValidatingInfo the package validating info
     * @param beginProcess the begin process
     */
    private void processInvalidReceiverInfo(
        final String key,
        final ReceiverValidatingInfo receiverValidatingInfo,
        final PackageValidatingInfo packageValidatingInfo,
        final long beginProcess) {
        try {
            LOG.error(IndexMaker.indexes(receiverValidatingInfo), "Invalid receiver info");
            final CaptureResultRecord receiverInfoRecord = receiverValidatingInfo.getReceiverInfo();

            if (this.serviceConfiguration.isStoreInvalidReceiverInfo()) {

                final ReceiverInfo receiverInfo = new ReceiverInfo(packageValidatingInfo.getCallerId(), packageValidatingInfo.getVersion(), receiverInfoRecord,
                    true);
                {
                    receiverInfo.setProcessBegin(beginProcess);
                    receiverInfo.setIdentCode(receiverValidatingInfo.getIdentCode());
                    receiverInfo.setPackageId(packageValidatingInfo.getPackageId());
                    receiverInfo.setReceived(packageValidatingInfo.getReceivedTime());
                    receiverInfo.setKey(key);
                    receiverInfo.setStatusCode(this.serviceConfiguration.invalidCaptureResultRecordsError().getCode());
                    receiverInfo.setState(ReceiverState.INVALID);
                    receiverInfo.setProcessEnd(DiscoWallClock.milli());
                }
                this.receiverInfoDao.store(key, receiverInfo);
            }
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.indexes(receiverValidatingInfo), "Error when trying to store invalid receiver info", e);
        }
    }

    /**
     * Process valid receiver info.
     *
     * @param key the key
     * @param receiverValidatingInfo the receiver validating info
     * @param packageValidatingInfo the package validating info
     * @param beginProcess the begin process
     */
    private void processValidReceiverInfo(
        final String key,
        final ReceiverValidatingInfo receiverValidatingInfo,
        final PackageValidatingInfo packageValidatingInfo,
        final long beginProcess) {

       // LOG.info(IndexMaker.indexes(receiverValidatingInfo), "Valid receiver info");
        
       
        final CaptureResultRecord receiverInfoRecord = receiverValidatingInfo.getReceiverInfo();

        final ReceiverInfo receiverInfo = new ReceiverInfo(packageValidatingInfo.getCallerId(), packageValidatingInfo.getVersion(), receiverInfoRecord, true);
        {
            receiverInfo.setProcessBegin(beginProcess);
            receiverInfo.setIdentCode(receiverValidatingInfo.getIdentCode());
            receiverInfo.setPackageId(packageValidatingInfo.getPackageId());
            receiverInfo.setReceived(packageValidatingInfo.getReceivedTime());
            receiverInfo.setKey(key);
            receiverInfo.setState(receiverValidatingInfo.getResultState());
            receiverInfo.setStatusCode(this.serviceConfiguration.successful().getCode());
            receiverInfo.setVerifiedByRule(receiverValidatingInfo.getVerifiedRule());
            receiverInfo.setNeedEmptyAmpKey(receiverValidatingInfo.isNeedEmptyAmpKey());
            receiverInfo.setEnoughInfo(receiverValidatingInfo.isEnoughInfo());
            receiverInfo.setProcessEnd(DiscoWallClock.milli());
            this.applyMangedInfo(receiverInfo);
        }
        // LOG.info(IndexMaker.indexes(receiverInfo ,"receiverInfoReport"), "Insert logs receiver_info");
        this.receiverInfoDao.put(key, receiverInfo);
        this.processManager.submit(receiverInfo);
    }
    
    /**
     * Validate.
     *
     * @param receiverValidatingInfo the receiver validating info
     * @param packageValidatingInfo the package validating info
     * @return true, if successful
     */
    @Override
    public boolean validate(final ReceiverValidatingInfo receiverValidatingInfo, final PackageValidatingInfo packageValidatingInfo) {

        final String key = receiverValidatingInfo.getKey();

        try {
            final long beginProcess = DiscoWallClock.milli();

            final CaptureResultRecord receiverInfoRecord = receiverValidatingInfo.getReceiverInfo();
            final String identCode = JaxbUtil.element2String(receiverInfoRecord.getIdentcode());
            receiverValidatingInfo.setIdentCode(identCode);

            final SimpleErrorHandler errorHandler = new SimpleErrorHandler();

            this.checkXsdCompliance(key, receiverInfoRecord, errorHandler, receiverValidatingInfo);

            for (final SAXParseException error : errorHandler.getErrors()) {
                receiverValidatingInfo.getErrors().add(error.getMessage());
            }
            
           if (!receiverValidatingInfo.isValid()) {
                this.processInvalidReceiverInfo(key, receiverValidatingInfo, packageValidatingInfo, beginProcess);
            }
            else {
                // Validate the receiver info by the rules
                if (!this.isVerifiedAddress(key, receiverValidatingInfo)) {
                    this.processInvalidReceiverInfo(key, receiverValidatingInfo, packageValidatingInfo, beginProcess);
                }
                else {
                    this.processValidReceiverInfo(key, receiverValidatingInfo, packageValidatingInfo, beginProcess);
                }
            }
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.indexes(receiverValidatingInfo), "There is error when validating receiver info", e);
        }

        return receiverValidatingInfo.isValid();
    }
}
