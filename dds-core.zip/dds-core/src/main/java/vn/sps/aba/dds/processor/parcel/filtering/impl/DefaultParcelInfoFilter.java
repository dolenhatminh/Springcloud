/*
 * Class: DMCFilter
 *
 * Created on Jun 21, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.parcel.filtering.impl;

import vn.sps.aba.dds.common.types.filterrule.FilterRule;
import vn.sps.aba.dds.repository.cache.interfaces.IParcelInfoCacheDao;
import vn.sps.aba.dds.service.lookup.asdp.IAsdpLookupService;

/**
 * The Class DMCFilter.
 */
public class DefaultParcelInfoFilter extends AbstractParcelInfoFilterer {

    /**
     * Instantiates a new default parcel info filter.
     */
    public DefaultParcelInfoFilter() {
        super(null, null, null);
    }

    /**
     * Constructs a new <tt>DMCFilter</tt>.
     *
     * @param filterRule
     *            the filter rule
     * @param asdpLookupService
     *            the asdp lookup service
     * @param parcelInfoDao
     *            the parcel info dao
     */
    public DefaultParcelInfoFilter(final FilterRule filterRule, final IAsdpLookupService asdpLookupService, final IParcelInfoCacheDao parcelInfoDao) {
        super(filterRule, asdpLookupService, parcelInfoDao);
    }
}
