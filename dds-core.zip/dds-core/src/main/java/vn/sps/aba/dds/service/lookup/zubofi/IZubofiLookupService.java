package vn.sps.aba.dds.service.lookup.zubofi;

import vn.sps.aba.dds.common.model.lookup.AsdpPlz;

/**
 * The Interface IZubofiLookupService.
 */
public interface IZubofiLookupService {
	
	/**
	 * Gets the zubofi.
	 *
	 * @param plz the plz
	 * @return the zubofi
	 */
	AsdpPlz getZubofi(String plz);
    
}
