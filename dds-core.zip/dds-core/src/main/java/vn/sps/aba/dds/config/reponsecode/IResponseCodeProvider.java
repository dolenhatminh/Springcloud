/*
 * Class: IWsResponseCode
 *
 * Created on Jul 26, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.config.reponsecode;

import vn.sps.aba.dds.common.types.message.Response;

/**
 * The Interface IWsResponseCode.
 */
public interface IResponseCodeProvider {

    /**
     * Find.
     *
     * @param source the source
     * @param key the key
     * @return the response
     */
    Response find(String source, String key);
}
