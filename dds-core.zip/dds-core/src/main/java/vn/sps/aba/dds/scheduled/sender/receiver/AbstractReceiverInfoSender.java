/*
 * Class: AbstractParcelInfoSender
 *
 * Created on Oct 17, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.sender.receiver;

import org.springframework.beans.factory.annotation.Autowired;

import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;
import vn.sps.aba.dds.scheduled.sender.AbstractScheduledSender;

/**
 * The Class AbstractReceiverInfoSender.
 */
abstract class AbstractReceiverInfoSender extends AbstractScheduledSender<ReceiverInfo> {

    /** The receiver info dao. */
    @Autowired
    protected IReceiverInfoCacheDao receiverInfoDao;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.AbstractScheduledSender#checkBeforeStore(java.lang.String)
     */
    @Override
    protected boolean checkBeforeStore(final String key) {
        return true;
    }

}
