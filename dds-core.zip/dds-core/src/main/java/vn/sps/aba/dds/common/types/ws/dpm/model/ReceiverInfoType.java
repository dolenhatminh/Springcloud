
package vn.sps.aba.dds.common.types.ws.dpm.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ReceiverInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReceiverInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AdresseErfassung" type="{Ch.Post.PL.DisCo.ReceiverInfoService}AdresseErfassungType"/>
 *         &lt;element name="CaptureInfo" type="{Ch.Post.PL.DisCo.ReceiverInfoService}CaptureInfoType"/>
 *         &lt;element name="Identcode" type="{Ch.Post.PL.DisCo.ReceiverInfoService}IdentCodeType"/>
 *         &lt;element name="SenderId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="DPMTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReceiverInfoType", propOrder = {
    "adresseErfassung",
    "captureInfo",
    "identcode",
    "senderId",
    "dpmTimestamp"
})
public class ReceiverInfoType {

    @XmlElement(name = "AdresseErfassung", required = true, nillable = true)
    protected AdresseErfassungType adresseErfassung;
    @XmlElement(name = "CaptureInfo", required = true, nillable = true)
    protected CaptureInfoType captureInfo;
    @XmlElement(name = "Identcode", required = true, nillable = true)
    protected String identcode;
    @XmlElementRef(name = "SenderId", namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> senderId;
    @XmlElement(name = "DPMTimestamp")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dpmTimestamp;

    /**
     * Gets the value of the adresseErfassung property.
     * 
     * @return
     *     possible object is
     *     {@link AdresseErfassungType }
     *     
     */
    public AdresseErfassungType getAdresseErfassung() {
        return adresseErfassung;
    }

    /**
     * Sets the value of the adresseErfassung property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdresseErfassungType }
     *     
     */
    public void setAdresseErfassung(AdresseErfassungType value) {
        this.adresseErfassung = value;
    }

    /**
     * Gets the value of the captureInfo property.
     * 
     * @return
     *     possible object is
     *     {@link CaptureInfoType }
     *     
     */
    public CaptureInfoType getCaptureInfo() {
        return captureInfo;
    }

    /**
     * Sets the value of the captureInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CaptureInfoType }
     *     
     */
    public void setCaptureInfo(CaptureInfoType value) {
        this.captureInfo = value;
    }

    /**
     * Gets the value of the identcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentcode() {
        return identcode;
    }

    /**
     * Sets the value of the identcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentcode(String value) {
        this.identcode = value;
    }

    /**
     * Gets the value of the senderId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getSenderId() {
        return senderId;
    }

    /**
     * Sets the value of the senderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setSenderId(JAXBElement<Integer> value) {
        this.senderId = value;
    }

    /**
     * Gets the value of the dpmTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDPMTimestamp() {
        return dpmTimestamp;
    }

    /**
     * Sets the value of the dpmTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDPMTimestamp(XMLGregorianCalendar value) {
        this.dpmTimestamp = value;
    }

}
