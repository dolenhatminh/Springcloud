/*
 * Class: Parcel2VamSendingHandler
 *
 * Created on Oct 19, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.sender.parcel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.sender.Parcel2VamSendingExecutor;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.scheduled.sender.IScheduledSender;
import vn.sps.aba.dds.scheduled.sender.parcel.Parcel2VamScheduledSender;
import vn.sps.aba.dds.sender.parcel.interfaces.IParcel2VamSender;
import vn.sps.aba.dds.service.vam.ICaptureResultService;

/**
 * The Class Parcel2VamSendingHandler.
 */
@Component("Parcel2VamSendingHandler")
public class Parcel2VamSendingHandler extends AbstractParcelSender implements IParcel2VamSender {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(Parcel2VamSendingHandler.class);

    /** The executor. */
    @Autowired
    private Parcel2VamSendingExecutor executor;

    /** The schedule sender. */
    @Autowired
    private Parcel2VamScheduledSender scheduleSender;

    /** The capture result service. */
    @Autowired
    private ICaptureResultService service;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected TaskConfiguration getExecutor() {
        return this.executor;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.sender.parcel.AbstractParcelSender#getScheduledSender()
     */
    @Override
    protected IScheduledSender<ParcelInfo> getScheduledSender() {
        return this.scheduleSender;
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.sender.IExternalSender#getSenderName()
     */
    @Override
    public String getSenderName() {
        return "PCaptureResult sender";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.sender.IExternalSender#handleItem(java.lang.Object)
     */
    @Override
    public Runnable handleItem(final ParcelInfo parcelInfo, final boolean isRetry) {
        return () -> {
            try {
            	
                if (Parcel2VamSendingHandler.this.service.transferToVamStation(parcelInfo)) {

                    parcelInfo.setState(ParcelState.VAM_CAPTURE_RESULT_SENT);
                    LOG.info(IndexMaker.indexes(parcelInfo, "vamCaptureReport"), "Insert log vamCaptureReport");
                    LOG.info(IndexMaker.index(parcelInfo), "Transfer parcel VAM CaptureResult service successfully");
                }
                else {
                    LOG.info(IndexMaker.index(parcelInfo), "Failed to forward parcel info to VAM CaptureResult service!");
                    Parcel2VamSendingHandler.this.scheduleSender.queue(parcelInfo);
                    LOG.info(IndexMaker.index(parcelInfo), "Parcel info was queued up to re-send to VAM CaptureResult service");
                }
                if (!isRetry) {
                    Parcel2VamSendingHandler.this.parcelInfoDao.put(parcelInfo.getKey(), parcelInfo);
                }
                else {
                    Parcel2VamSendingHandler.this.parcelInfoDao.store(parcelInfo.getKey(), parcelInfo);
                }
            }
            catch (final Exception e) {
                LOG.debug(IndexMaker.index(parcelInfo), "There is error when re-send parcel to VAM CaptureResult service", e);
            }
            finally {
                Parcel2VamSendingHandler.this.watcher.unWatch(parcelInfo.getKey());
                LOG.info(IndexMaker.index(parcelInfo), "Transfer parcel to VAM CaptureResult service done");
            }
        };
    }

    /**
     * Merge and store.
     *
     * @param key the key
     * @param parcelInfo the parcel info
     */
    protected void mergeAndStore(final String key, final ParcelInfo parcelInfo) {
        try {
            ParcelInfo ret = this.parcelInfoDao.get(key);
            if (ret != null) {
                ret.setState(parcelInfo.getParcelState());
                ret.setCaptureResultBegin(parcelInfo.getCaptureResultBegin());
                ret.setCaptureResultEnd(parcelInfo.getCaptureResultEnd());
                ret.setCaptureResultCount(parcelInfo.getCaptureResultCount());
            }
            else {
                LOG.info(IndexMaker.index(key), "Cannot find any parcel match with key");
                ret = parcelInfo;
            }
            this.parcelInfoDao.store(key, ret);
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when merge and store parcel into database.", e);
        }
    }
}
