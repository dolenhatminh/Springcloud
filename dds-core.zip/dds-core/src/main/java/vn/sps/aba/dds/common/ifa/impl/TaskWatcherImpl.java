/*
 * Class: TaskWatcherImpl
 *
 * Created on Oct 11, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.ifa.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.ifa.ImmortalCollector;
import vn.sps.aba.dds.common.ifa.TaskWatcher;

/**
 * The Class TaskWatcherImpl.
 */
public class TaskWatcherImpl implements TaskWatcher, ImmortalCollector {

    /** The workers. */
    private final Map<String, Future<?>> workers = new HashMap<>();

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.TaskWatcher#cleanFinishedTasks()
     */
    @Override
    public int cleanFinishedTasks(final boolean force) {
        final int currentSize = this.workers.entrySet().size();
        if (currentSize > 0) {
            if (!force) {
                this.workers.entrySet().removeIf(t -> t.getValue().isDone());
            }
            else {
                this.workers.clear();
            }
            return currentSize - this.workers.entrySet().size();
        }
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.ImmortalCollector#emptyQueue(boolean, java.lang.String)
     */
    @Override
    public int emptyQueue(final String key) {

        if (DDSConstant.EMPTY_KEY.equals(key)) {
            final int currentSize = this.workers.entrySet().size();
            if (currentSize > 0) {

                this.workers.entrySet().removeIf(t -> t.getValue().cancel(false));

                return currentSize - this.workers.entrySet().size();
            }
            return 0;
        }
        else {
            return -1;
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.TaskWatcher#getNumberWatchingTask()
     */
    @Override
    public int getNumberWatchingTask() {
        return this.workers.size();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.TaskWatcher#isDone(java.lang.String)
     */
    @Override
    public boolean isDone(final String key) {
        final Future<?> worker = this.workers.get(key);
        return worker != null ? worker.isDone() : true;
    }

    /**
     * Size.
     *
     * @return the int
     */
    public int size() {
        return this.workers.size();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.TaskWatcher#unWatch(java.lang.String)
     */
    @Override
    public Future<?> unWatch(final String key) {
        return this.workers.remove(key);
    }

    /**
     * Watch.
     *
     * @param key the key
     * @param worker the worker
     */
    public void watch(final String key, final Future<?> worker) {
        this.workers.put(key, worker);
    }
}
