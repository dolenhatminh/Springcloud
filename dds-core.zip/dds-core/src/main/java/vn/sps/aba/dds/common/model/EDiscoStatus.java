package vn.sps.aba.dds.common.model;

/**
 * The Enum EDiscoStatus.
 */
public enum EDiscoStatus {

    /** The delivered. */
    // Step - 2
    DELIVERED(2, 1),
    /** The delivered fail. */
    DELIVERED_FAIL(2, -1),

    /** The image not found. */
    IMAGE_NOT_FOUND(2, -3),
    /** The persit collection. */
    // Step - 1
    PERSIT_COLLECTION(1, 1),

    /** The persit collection fail. */
    PERSIT_COLLECTION_FAIL(1, -1),

    /** The receive collection. */
    // Step - 3
    RECEIVE_COLLECTION(3, 1),

    /** The return collection. */
    // Step - 4
    RETURN_COLLECTION(4, 1),
    /** The return collection fail. */
    RETURN_COLLECTION_FAIL(4, -1);

    /** The status. */
    private final int status;

    /** The sub status. */
    private final int subStatus;

    /**
     * Instantiates a new e disco status.
     *
     * @param status the status
     * @param subStatus the sub status
     */
    EDiscoStatus(final int status, final int subStatus) {
        this.status = status;
        this.subStatus = subStatus;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public int getStatus() {
        return this.status;
    }

    /**
     * Gets the sub status.
     *
     * @return the sub status
     */
    public int getSubStatus() {
        return this.subStatus;
    }
}
