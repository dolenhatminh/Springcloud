/*
 * Class: ParcelInfoListener
 * 
 * Created on Sep 4, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.listener.impl09;

import org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.transaction.TransactionException;

import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.repository.cache.event.CacheEvent;
import vn.sps.aba.dds.repository.entity.receiver.ReceiverInfoEntity;
import vn.sps.aba.dds.repository.jpa.IReceiverInfoRepository;
import vn.sps.aba.dds.repository.listener.ICacheListener;
import vn.sps.aba.dds.repository.listener.impl.AbstractCacheListener;

/**
 * The listener interface for receiving receiverInfo events.
 * The class that is interested in processing a receiverInfo
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addReceiverInfoListener<code> method. When
 * the receiverInfo event occurs, that object's appropriate
 * method is invoked.
 *
 * @see ReceiverInfoEvent
 */
@Component("ReceiverInfoListener")
@Profile(value = { Profiles.RECEIVER, Profiles.DPM, Profiles.DPMB, Profiles.DPMS })
public class ReceiverInfoListener extends AbstractCacheListener<String, ReceiverInfo> implements ICacheListener<String, ReceiverInfo> {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ReceiverInfoListener.class);

    /** The receiver info repository. */
    @Autowired
    private IReceiverInfoRepository receiverInfoRepository;

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.repository.listener.ICacheListener#add(org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent)
     */
    @Override
    public void add(CacheEntryCreatedEvent<String, ReceiverInfo> event) {
        final ReceiverInfo receiverInfo = event.getValue();

        try {

            if (receiverInfo != null) {
                final ReceiverInfoEntity receiverInfoEntity = new ReceiverInfoEntity(receiverInfo);
                this.receiverInfoRepository.save(receiverInfoEntity);
            }
        }
        catch (final TransactionException e) {
            throw e;
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.index(receiverInfo), "Error while persisting data into database", e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.repository.listener.ICacheListener#modify(org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent)
     */
    @Override
    public void modify(CacheEntryModifiedEvent<String, ReceiverInfo> event) {

        final ReceiverInfo receiverInfo = event.getValue();
        String key = null;

        try {

            if (receiverInfo != null) {

                long created = 0;
                long lifespan = 0;

                if (event instanceof CacheEvent) {
                    created = ((CacheEvent<String, ReceiverInfo>) event).getCreated();
                    lifespan = ((CacheEvent<String, ReceiverInfo>) event).getLifespan();
                }

                key = receiverInfo.getKey();
                ReceiverInfoEntity receiverInfoEntity = this.receiverInfoRepository.findOne(key);

                if (receiverInfoEntity != null) {
                    receiverInfoEntity.updateInfo(receiverInfo);
                }
                else {
                    receiverInfoEntity = new ReceiverInfoEntity(receiverInfo);
                }
                receiverInfoEntity.setCreated(created);
                receiverInfoEntity.setLifespan(lifespan);
                this.receiverInfoRepository.save(receiverInfoEntity);
                LOG.info(IndexMaker.index(receiverInfo), "Store receiver info into database.");
            }
        }
        catch (final TransactionException e) {
            throw e;
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.index(receiverInfo), "Error while persisting data into database", e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.repository.listener.ICacheListener#remove(org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent)
     */
    @Override
    public void remove(CacheEntryRemovedEvent<String, ReceiverInfo> event) {

    }

}
