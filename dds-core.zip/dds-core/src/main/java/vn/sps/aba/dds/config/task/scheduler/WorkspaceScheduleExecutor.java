/*
 * Class: TaskEvictionConfiguration
 *
 * Created on Aug 19, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.task.scheduler;

import javax.annotation.PostConstruct;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.config.task.TaskConfiguration;

/**
 * The Class TaskEvictionConfiguration.
 */
@Configuration("WorkspaceScheduleExecutor")
@ConfigurationProperties(prefix = "task.scheduler.workspace")
public class WorkspaceScheduleExecutor extends TaskConfiguration implements DdsScheduler {

    /** The remove on cancel. */
    protected boolean removeOnCancel = false;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.task.TaskConfiguration#configThreadPool()
     */
    @Override
    @PostConstruct
    protected void configThreadPool() {
        if (this.executor == null) {
            this.executor = new ThreadPoolTaskScheduler();
            final ThreadPoolTaskScheduler scheduler = (ThreadPoolTaskScheduler) this.executor;
            scheduler.setBeanName(this.getName());
            scheduler.setThreadPriority(this.priority);
            scheduler.setThreadNamePrefix(TASK_PREFIX + this.getName());
            scheduler.setPoolSize(this.corePoolSize);
            scheduler.setRemoveOnCancelPolicy(this.removeOnCancel);
            scheduler.initialize();
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.task.TaskConfiguration#emptyQueue(int)
     */
    @Override
    public void emptyQueue(final String key) {
        if (DDSConstant.EMPTY_KEY.equals(key) && (this.executor != null)) {
            ((ThreadPoolTaskScheduler) this.executor).getScheduledThreadPoolExecutor().getQueue().clear();
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.task.TaskConfiguration#getActiveCount()
     */
    @Override
    public int getActiveCount() {
        if (this.executor != null) {
            return ((ThreadPoolTaskScheduler) this.executor).getScheduledThreadPoolExecutor().getActiveCount();
        }
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.task.TaskConfiguration#getCorePoolSize()
     */
    @Override
    public int getCorePoolSize() {
        if (this.executor != null) {
            return ((ThreadPoolTaskScheduler) this.executor).getScheduledThreadPoolExecutor().getCorePoolSize();
        }
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.task.TaskConfiguration#getMaxPoolSize()
     */
    @Override
    public int getMaxPoolSize() {
        if (this.executor != null) {
            return ((ThreadPoolTaskScheduler) this.executor).getScheduledThreadPoolExecutor().getMaximumPoolSize();
        }
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.task.TaskConfiguration#getQueingCount()
     */
    @Override
    public int getQueingCount() {
        if (this.executor != null) {
            return ((ThreadPoolTaskScheduler) this.executor).getScheduledThreadPoolExecutor().getQueue().size();
        }
        return 0;
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.config.task.scheduler.DdsScheduler#getScheduler()
     */
    @Override
    public ThreadPoolTaskScheduler getScheduler() {
        return (ThreadPoolTaskScheduler) this.executor;
    }

    /**
     * Checks if is removes the on cancel.
     *
     * @return true, if is removes the on cancel
     */
    public boolean isRemoveOnCancel() {
        return this.removeOnCancel;
    }

    /**
     * Sets the removes the on cancel.
     *
     * @param removeOnCancel the new removes the on cancel
     */
    public void setRemoveOnCancel(final boolean removeOnCancel) {
        this.removeOnCancel = removeOnCancel;
    }
}
