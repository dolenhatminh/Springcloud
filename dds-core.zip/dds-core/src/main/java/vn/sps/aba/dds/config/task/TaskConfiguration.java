/*
 * Class: ThreadPoolConfiguration
 *
 * Created on Jun 20, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.task;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.scheduling.annotation.AsyncConfigurerSupport;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.jmx.ThreadPoolInfo;

/**
 * The Class ThreadPoolConfiguration.<br>
 * Use @RefreshScope to prevent this configuration from refreshing after configuration updated.
 */
public abstract class TaskConfiguration extends AsyncConfigurerSupport implements ThreadPoolInfo {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(TaskConfiguration.class);

    /** The Constant TASK_PREFIX. */
    public static final String TASK_PREFIX = "dds-";

    /** The max number of thread. */
    protected int corePoolSize;

    /** The executor. */
    protected AsyncTaskExecutor executor;

    /** The max pool size. */
    protected int maxPoolSize;

    /** The name. */
    private String name;

    /** The priority. */
    protected int priority = Thread.NORM_PRIORITY;

    /** The queue capacity. */
    protected int queueCapacity;
    
    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ThreadPoolInfo#changePoolConfig(int, int)
     */
    @Override
    public void changePoolConfig(final int corePoolSize, final int maxPoolSize) {
        this.setCorePoolSize(corePoolSize);
        this.setMaxPoolSize(maxPoolSize);
        if (this.executor != null) {
            final ThreadPoolTaskExecutor threadPoolExcutor = (ThreadPoolTaskExecutor) this.executor;
            final int oldCorePoolSize = threadPoolExcutor.getCorePoolSize();
            if (oldCorePoolSize != this.corePoolSize) {
                threadPoolExcutor.setCorePoolSize(this.corePoolSize);
                LOG.info("Change core pool size from " + oldCorePoolSize + " to " + this.corePoolSize);
            }
            final int oldMaxPoolSize = threadPoolExcutor.getMaxPoolSize();
            if (oldMaxPoolSize != this.maxPoolSize) {
                threadPoolExcutor.setMaxPoolSize(this.maxPoolSize);
                LOG.info("Change max pool size from " + oldMaxPoolSize + " to " + this.maxPoolSize);
            }
        }
    }

    /**
     * Config thread pool.
     */
    @PostConstruct
    protected void configThreadPool() {
        if (this.corePoolSize > this.maxPoolSize) {
            throw new IllegalArgumentException("CorePoolSize: [" + this.getCorePoolSize() + "] cannot larger than MaxPoolSize:" + this.getMaxPoolSize());
        }
        if (this.executor == null) {
            this.executor = new ThreadPoolTaskExecutor();
            final ThreadPoolTaskExecutor threadPoolExcutor = (ThreadPoolTaskExecutor) this.executor;
            {
                threadPoolExcutor.setCorePoolSize(this.corePoolSize);
                threadPoolExcutor.setMaxPoolSize(this.maxPoolSize);
                threadPoolExcutor.setQueueCapacity(this.queueCapacity);
                threadPoolExcutor.setBeanName(this.getName());
                threadPoolExcutor.setThreadPriority(this.priority);
                threadPoolExcutor.setThreadNamePrefix(TASK_PREFIX + this.getName());
            }
            threadPoolExcutor.initialize();
        }
        else {
            this.changePoolConfig(this.corePoolSize, this.maxPoolSize);
        }
    }

    /**
     * Empty queue.
     *
     * @param key the key
     */
    @Override
    public void emptyQueue(final String key) {
        if (DDSConstant.EMPTY_KEY.equals(key)) {
            if (this.executor instanceof ThreadPoolTaskExecutor) {
                final ThreadPoolExecutor threadPoolExcutor = ((ThreadPoolTaskExecutor) this.executor).getThreadPoolExecutor();
                final BlockingQueue<Runnable> queue = threadPoolExcutor.getQueue();
                final int size = queue.size();
                queue.clear();
                LOG.info("Cleared {} items from the queue", size);
            }
        }
    }

    /**
     * Gets the active count.
     *
     * @return the active count
     */
    @Override
    public int getActiveCount() {
        if (this.getAsyncExecutor() != null) {
            return ((ThreadPoolTaskExecutor) this.getAsyncExecutor()).getThreadPoolExecutor().getActiveCount();
        }
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.scheduling.annotation.AsyncConfigurer#getAsyncExecutor()
     */
    @Override
    public AsyncTaskExecutor getAsyncExecutor() {
        return this.executor;
    }

    /**
     * Gets the core pool size.
     *
     * @return Returns the corePoolSize.
     */
    @Override
    public int getCorePoolSize() {
        return ((ThreadPoolTaskExecutor) this.getAsyncExecutor()).getThreadPoolExecutor().getCorePoolSize();
    }

    /**
     * Gets the DDS task prefix.
     *
     * @return the DDS task prefix
     */
    protected String getDDSTaskPrefix() {
        return "MyExecutor-";
    }

    /**
     * Gets the executor.
     *
     * @return the executor
     */
    public Executor getExecutor() {
        return this.executor;
    }

    /**
     * Gets the max pool size.
     *
     * @return Returns the maxPoolSize.
     */
    @Override
    public int getMaxPoolSize() {
        return ((ThreadPoolTaskExecutor) this.getAsyncExecutor()).getThreadPoolExecutor().getMaximumPoolSize();
    }

    /**
     * Gets the name.
     *
     * @return Returns the name.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Gets the priority.
     *
     * @return the priority
     */
    public int getPriority() {
        return this.priority;
    }

    /**
     * Gets the queing count.
     *
     * @return the queing count
     */
    @Override
    public int getQueingCount() {
        if (this.getAsyncExecutor() != null) {
            return ((ThreadPoolTaskExecutor) this.getAsyncExecutor()).getThreadPoolExecutor().getQueue().size();
        }
        return 0;
    }

    /**
     * Gets the queue capacity.
     *
     * @return Returns the queueCapacity.
     */
    @Override
    public int getQueueCapacity() {
        return this.queueCapacity;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ThreadPoolInfo#getThreadName()
     */
    @Override
    public String getThreadName() {
        return TASK_PREFIX + this.getName();
    }

    /**
     * Sets the core pool size.
     *
     * @param corePoolSize
     *            The corePoolSize to set.
     */
    public void setCorePoolSize(final int corePoolSize) {
        this.corePoolSize = corePoolSize;
    }

    /**
     * Sets the max pool size.
     *
     * @param maxPoolSize
     *            The maxPoolSize to set.
     */
    public void setMaxPoolSize(final int maxPoolSize) {
        this.maxPoolSize = maxPoolSize;
    }

    /**
     * Sets the name.
     *
     * @param name
     *            The name to set.
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * Sets the priority.
     *
     * @param priority the new priority
     */
    public void setPriority(final int priority) {
        this.priority = priority;
    }

    /**
     * Sets the queue capacity.
     *
     * @param queueCapacity
     *            The queueCapacity to set.
     */
    public void setQueueCapacity(final int queueCapacity) {
        this.queueCapacity = queueCapacity;
    }
}
