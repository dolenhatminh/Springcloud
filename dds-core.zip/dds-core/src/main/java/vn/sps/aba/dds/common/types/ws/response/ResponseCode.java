/*
 * Class: ResponseCode
 *
 * Created on Jul 26, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.ws.response;

/**
 * The Class ResponseCode.
 *
 * @param <T> the generic type
 */
public class ResponseCode<T> {

    /** The code. */
    private T code;

    /** The description. */
    private String description;

    /**
     * Gets the code.
     *
     * @return the code
     */
    public T getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(final T code) {
        this.code = code;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(final String description) {
        this.description = description;
    }

}
