/*
 * Class: VolleAdresse
 *
 * Created on Jul 8, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.receiver;

import java.io.Serializable;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.types.ws.dpm.model.VolleAdresseType;
import vn.sps.aba.dds.common.util.JaxbUtil;

/**
 * The Class VolleAdresse.
 */
public class VolleAdresse implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 5023059084079986127L;

    /** The address fields. */
    private AddressFields addressFields;

    /** The address source. */
    private String addressSource;

    /** The parcel adr amp status. */
    private String parcelAdrAmpStatus;

    /** The parcel adr types. */
    private String parcelAdrType;

    /** The parcel street number. */
    private String parcelStreetNumber;

    /** The pers status. */
    private String persStatus;

    /** The pers type. */
    private String persType;

    /**
     * Instantiates a new volle adresse.
     */
    public VolleAdresse() {
    }

    /**
     * Instantiates a new volle adresse.
     *
     * @param volleAdresse the volle adresse
     */
    public VolleAdresse(final vn.sps.aba.dds.common.types.ws.dpmb.VolleAdresse volleAdresse) {

        if (volleAdresse.getFields() != null) {
            this.addressFields = new AddressFields(volleAdresse.getFields());
        }

        this.setParcelAdrAmpStatus(volleAdresse.getParcelAdrAmpStatus() == null ? null : volleAdresse.getParcelAdrAmpStatus().value());
        this.setParcelStreetNumber(String.valueOf(volleAdresse.getParcelStreetNr()));

        this.parcelAdrType = String.join(Constant.CHAR_COMMA, volleAdresse.getParcelAdrType());

        this.setPersStatus(volleAdresse.getPersStatus() == null ? null : volleAdresse.getPersStatus().value());
        this.setPersType(volleAdresse.getPersType() == null ? null : volleAdresse.getPersType().value());
    }

    /**
     * Instantiates a new volle adresse.
     *
     * @param volleAdresse the volle adresse
     */
    public VolleAdresse(final vn.sps.aba.dds.common.types.ws.dpms.VolleAdresse volleAdresse) {

        if (volleAdresse.getFields() != null && volleAdresse.getFields().getValue() != null) {
            this.addressFields = new AddressFields(volleAdresse.getFields().getValue());
        }

        this.setParcelAdrAmpStatus(JaxbUtil.element2String(volleAdresse.getParcelAdrAmpStatus()));
        this.setParcelStreetNumber(JaxbUtil.element2String(volleAdresse.getParcelStreetNr()));
        this.setParcelAdrType(JaxbUtil.element2String(volleAdresse.getParcelAdrType()));
        this.setPersStatus(JaxbUtil.element2String(volleAdresse.getPersStatus()));
        this.setPersType(JaxbUtil.element2String(volleAdresse.getPersType()));
    }

    /**
     * Instantiates a new volle adresse.
     *
     * @param volleAdresse the volle adresse
     */
    public VolleAdresse(final vn.sps.aba.dds.common.types.ws.vam.capturing.model.VolleAdresse volleAdresse) {

        if (volleAdresse.getFields() != null) {
            this.addressFields = new AddressFields(volleAdresse.getFields());
        }
        this.setParcelAdrAmpStatus(volleAdresse.getParcelAdrAmpStatus().value());
        this.setParcelStreetNumber(String.valueOf(volleAdresse.getParcelStreetNr()));

        this.parcelAdrType = String.join(Constant.CHAR_COMMA, volleAdresse.getParcelAdrType());

        this.setPersStatus(volleAdresse.getPersStatus().getValue().value());
        this.setPersType(volleAdresse.getPersType().getValue().value());

    }

    /**
     * Instantiates a new volle adresse.
     *
     * @param volleAdresse the volle adresse
     */
    public VolleAdresse(final VolleAdresseType volleAdresse) {
        if (volleAdresse.getFields() != null) {
            this.addressFields = new AddressFields(volleAdresse.getFields());
        }
        this.setParcelAdrAmpStatus(volleAdresse.getParcelAdrAmpStatus().value());
        this.setParcelStreetNumber(String.valueOf(volleAdresse.getParcelStreetNr()));

        this.parcelAdrType = String.join(Constant.CHAR_COMMA, volleAdresse.getParcelAdrType());

        this.setPersStatus(volleAdresse.getPersStatus().getValue().value());
        this.setPersType(volleAdresse.getPersType().getValue().value());
        this.setAddressSource(volleAdresse.getAddressSource());
    }

    /**
     * Gets the address fields.
     *
     * @return the address fields
     */
    public AddressFields getAddressFields() {
        return this.addressFields;
    }

    /**
     * Gets the address source.
     *
     * @return the address source
     */
    public String getAddressSource() {
        return this.addressSource;
    }

    /**
     * Gets the parcel adr amp status.
     *
     * @return the parcel adr amp status
     */
    public String getParcelAdrAmpStatus() {
        return this.parcelAdrAmpStatus;
    }

    /**
     * Gets the parcel adr type.
     *
     * @return the parcel adr type
     */
    public String getParcelAdrType() {
        return this.parcelAdrType;
    }

    /**
     * Gets the parcel street number.
     *
     * @return the parcel street number
     */
    public String getParcelStreetNumber() {
        return this.parcelStreetNumber;
    }

    /**
     * Gets the pers status.
     *
     * @return the pers status
     */
    public String getPersStatus() {
        return this.persStatus;
    }

    /**
     * Gets the pers type.
     *
     * @return the pers type
     */
    public String getPersType() {
        return this.persType;
    }

    /**
     * Sets the address fields.
     *
     * @param addressFields the new address fields
     */
    public void setAddressFields(final AddressFields addressFields) {
        this.addressFields = addressFields;
    }

    /**
     * Sets the address source.
     *
     * @param addressSource the new address source
     */
    public void setAddressSource(final String addressSource) {
        this.addressSource = addressSource;
    }

    /**
     * Sets the parcel adr amp status.
     *
     * @param parcelAdrAmpStatus the new parcel adr amp status
     */
    public void setParcelAdrAmpStatus(final String parcelAdrAmpStatus) {
        this.parcelAdrAmpStatus = parcelAdrAmpStatus;
    }

    /**
     * Sets the parcel adr type.
     *
     * @param parcelAdrType the new parcel adr type
     */
    public void setParcelAdrType(final String parcelAdrType) {
        this.parcelAdrType = parcelAdrType;
    }

    /**
     * Sets the parcel street number.
     *
     * @param parcelStreetNumber the new parcel street number
     */
    public void setParcelStreetNumber(final String parcelStreetNumber) {
        this.parcelStreetNumber = parcelStreetNumber;
    }

    /**
     * Sets the pers status.
     *
     * @param persStatus the new pers status
     */
    public void setPersStatus(final String persStatus) {
        this.persStatus = persStatus;
    }

    /**
     * Sets the pers type.
     *
     * @param persType the new pers type
     */
    public void setPersType(final String persType) {
        this.persType = persType;
    }

}
