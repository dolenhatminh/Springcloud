
package vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for barCodeData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="barCodeData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="BarcodeArt" use="required" type="{http://www.w3.org/2001/XMLSchema}integer" />
 *       &lt;attribute name="BarcodeTyp" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="BarcodeInhalt" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "barCodeData")
public class BarCodeData {

    @XmlAttribute(name = "BarcodeArt", required = true)
    protected BigInteger barcodeArt;
    @XmlAttribute(name = "BarcodeTyp", required = true)
    protected String barcodeTyp;
    @XmlAttribute(name = "BarcodeInhalt", required = true)
    protected String barcodeInhalt;

    /**
     * Gets the value of the barcodeArt property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getBarcodeArt() {
        return barcodeArt;
    }

    /**
     * Sets the value of the barcodeArt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setBarcodeArt(BigInteger value) {
        this.barcodeArt = value;
    }

    /**
     * Gets the value of the barcodeTyp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBarcodeTyp() {
        return barcodeTyp;
    }

    /**
     * Sets the value of the barcodeTyp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBarcodeTyp(String value) {
        this.barcodeTyp = value;
    }

    /**
     * Gets the value of the barcodeInhalt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBarcodeInhalt() {
        return barcodeInhalt;
    }

    /**
     * Sets the value of the barcodeInhalt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBarcodeInhalt(String value) {
        this.barcodeInhalt = value;
    }

}
