
package vn.sps.aba.dds.common.types.ws.dpm.model;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlList;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for VolleAdresseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VolleAdresseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Fields" type="{Ch.Post.PL.DisCo.ReceiverInfoService}AddressFieldsType"/>
 *         &lt;element name="KdpId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="ParcelAdrAmpStatus" type="{Ch.Post.PL.DisCo.ReceiverInfoService}AmpStatusType" minOccurs="0"/>
 *         &lt;element name="ParcelAdrType" type="{Ch.Post.PL.DisCo.ReceiverInfoService}CaptureAddressType"/>
 *         &lt;element name="ParcelHausKey" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="ParcelStreetNr" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="PersStatus" type="{Ch.Post.PL.DisCo.ReceiverInfoService}PersStatusType" minOccurs="0"/>
 *         &lt;element name="PersType" type="{Ch.Post.PL.DisCo.ReceiverInfoService}PersTypeType" minOccurs="0"/>
 *         &lt;element name="AddressSource" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VolleAdresseType", propOrder = {
    "fields",
    "kdpId",
    "parcelAdrAmpStatus",
    "parcelAdrType",
    "parcelHausKey",
    "parcelStreetNr",
    "persStatus",
    "persType",
    "addressSource"
})
public class VolleAdresseType {

    @XmlElement(name = "Fields", required = true, nillable = true)
    protected AddressFieldsType fields;
    @XmlElementRef(name = "KdpId", namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> kdpId;
    @XmlElement(name = "ParcelAdrAmpStatus")
    @XmlSchemaType(name = "string")
    protected AmpStatusType parcelAdrAmpStatus;
    @XmlList
    @XmlElement(name = "ParcelAdrType", required = true)
    @XmlSchemaType(name = "anySimpleType")
    protected List<String> parcelAdrType;
    @XmlElementRef(name = "ParcelHausKey", namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> parcelHausKey;
    @XmlElement(name = "ParcelStreetNr")
    protected Integer parcelStreetNr;
    @XmlElementRef(name = "PersStatus", namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<PersStatusType> persStatus;
    @XmlElementRef(name = "PersType", namespace = "Ch.Post.PL.DisCo.ReceiverInfoService", type = JAXBElement.class, required = false)
    protected JAXBElement<PersTypeType> persType;
    @XmlElement(name = "AddressSource", required = true)
    protected String addressSource;

    /**
     * Gets the value of the fields property.
     * 
     * @return
     *     possible object is
     *     {@link AddressFieldsType }
     *     
     */
    public AddressFieldsType getFields() {
        return fields;
    }

    /**
     * Sets the value of the fields property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressFieldsType }
     *     
     */
    public void setFields(AddressFieldsType value) {
        this.fields = value;
    }

    /**
     * Gets the value of the kdpId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getKdpId() {
        return kdpId;
    }

    /**
     * Sets the value of the kdpId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setKdpId(JAXBElement<Integer> value) {
        this.kdpId = value;
    }

    /**
     * Gets the value of the parcelAdrAmpStatus property.
     * 
     * @return
     *     possible object is
     *     {@link AmpStatusType }
     *     
     */
    public AmpStatusType getParcelAdrAmpStatus() {
        return parcelAdrAmpStatus;
    }

    /**
     * Sets the value of the parcelAdrAmpStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link AmpStatusType }
     *     
     */
    public void setParcelAdrAmpStatus(AmpStatusType value) {
        this.parcelAdrAmpStatus = value;
    }

    /**
     * Gets the value of the parcelAdrType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the parcelAdrType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParcelAdrType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getParcelAdrType() {
        if (parcelAdrType == null) {
            parcelAdrType = new ArrayList<String>();
        }
        return this.parcelAdrType;
    }

    /**
     * Gets the value of the parcelHausKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getParcelHausKey() {
        return parcelHausKey;
    }

    /**
     * Sets the value of the parcelHausKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setParcelHausKey(JAXBElement<Integer> value) {
        this.parcelHausKey = value;
    }

    /**
     * Gets the value of the parcelStreetNr property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getParcelStreetNr() {
        return parcelStreetNr;
    }

    /**
     * Sets the value of the parcelStreetNr property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setParcelStreetNr(Integer value) {
        this.parcelStreetNr = value;
    }

    /**
     * Gets the value of the persStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PersStatusType }{@code >}
     *     
     */
    public JAXBElement<PersStatusType> getPersStatus() {
        return persStatus;
    }

    /**
     * Sets the value of the persStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PersStatusType }{@code >}
     *     
     */
    public void setPersStatus(JAXBElement<PersStatusType> value) {
        this.persStatus = value;
    }

    /**
     * Gets the value of the persType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PersTypeType }{@code >}
     *     
     */
    public JAXBElement<PersTypeType> getPersType() {
        return persType;
    }

    /**
     * Sets the value of the persType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PersTypeType }{@code >}
     *     
     */
    public void setPersType(JAXBElement<PersTypeType> value) {
        this.persType = value;
    }

    /**
     * Gets the value of the addressSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressSource() {
        return addressSource;
    }

    /**
     * Sets the value of the addressSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressSource(String value) {
        this.addressSource = value;
    }

}
