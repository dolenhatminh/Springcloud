
package vn.sps.aba.dds.common.types.ws.padasa.matchmakerdaten.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the vn.sps.aba.dds.service.padasa.matchmakerdaten.model package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _MatchMakerRequestRECName2_QNAME = new QName("http://xmlns.oracle.com/padasadatenrequest", "REC_Name2");
    private final static QName _MatchMakerRequestRECPOBox_QNAME = new QName("http://xmlns.oracle.com/padasadatenrequest", "REC_POBox");
    private final static QName _MatchMakerRequestRECName3_QNAME = new QName("http://xmlns.oracle.com/padasadatenrequest", "REC_Name3");
    private final static QName _MatchMakerRequestRECFreeText_QNAME = new QName("http://xmlns.oracle.com/padasadatenrequest", "REC_FreeText");
    private final static QName _MatchMakerRequestRECZIP_QNAME = new QName("http://xmlns.oracle.com/padasadatenrequest", "REC_ZIP");
    private final static QName _MatchMakerRequestRECSendeId_QNAME = new QName("http://xmlns.oracle.com/padasadatenrequest", "REC_SendeId");
    private final static QName _MatchMakerRequestRECStreet_QNAME = new QName("http://xmlns.oracle.com/padasadatenrequest", "REC_Street");
    private final static QName _MatchMakerRequestRECTitle_QNAME = new QName("http://xmlns.oracle.com/padasadatenrequest", "REC_Title");
    private final static QName _MatchMakerRequestRECCountry_QNAME = new QName("http://xmlns.oracle.com/padasadatenrequest", "REC_Country");
    private final static QName _MatchMakerRequestRECCity_QNAME = new QName("http://xmlns.oracle.com/padasadatenrequest", "REC_City");
    private final static QName _MatchMakerRequestEnvelopeVersion_QNAME = new QName("http://xmlns.oracle.com/padasadatenrequest", "Envelope_Version");
    private final static QName _MatchMakerRequestRECName1_QNAME = new QName("http://xmlns.oracle.com/padasadatenrequest", "REC_Name1");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: vn.sps.aba.dds.service.padasa.matchmakerdaten.model
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link MatchMakerRequest }
     * 
     */
    public MatchMakerRequest createMatchMakerRequest() {
        return new MatchMakerRequest();
    }

    /**
     * Create an instance of {@link MatchMakerResponse }
     * 
     */
    public MatchMakerResponse createMatchMakerResponse() {
        return new MatchMakerResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/padasadatenrequest", name = "REC_Name2", scope = MatchMakerRequest.class)
    public JAXBElement<String> createMatchMakerRequestRECName2(String value) {
        return new JAXBElement<String>(_MatchMakerRequestRECName2_QNAME, String.class, MatchMakerRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/padasadatenrequest", name = "REC_POBox", scope = MatchMakerRequest.class)
    public JAXBElement<String> createMatchMakerRequestRECPOBox(String value) {
        return new JAXBElement<String>(_MatchMakerRequestRECPOBox_QNAME, String.class, MatchMakerRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/padasadatenrequest", name = "REC_Name3", scope = MatchMakerRequest.class)
    public JAXBElement<String> createMatchMakerRequestRECName3(String value) {
        return new JAXBElement<String>(_MatchMakerRequestRECName3_QNAME, String.class, MatchMakerRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/padasadatenrequest", name = "REC_FreeText", scope = MatchMakerRequest.class)
    public JAXBElement<String> createMatchMakerRequestRECFreeText(String value) {
        return new JAXBElement<String>(_MatchMakerRequestRECFreeText_QNAME, String.class, MatchMakerRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/padasadatenrequest", name = "REC_ZIP", scope = MatchMakerRequest.class)
    public JAXBElement<String> createMatchMakerRequestRECZIP(String value) {
        return new JAXBElement<String>(_MatchMakerRequestRECZIP_QNAME, String.class, MatchMakerRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/padasadatenrequest", name = "REC_SendeId", scope = MatchMakerRequest.class)
    public JAXBElement<String> createMatchMakerRequestRECSendeId(String value) {
        return new JAXBElement<String>(_MatchMakerRequestRECSendeId_QNAME, String.class, MatchMakerRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/padasadatenrequest", name = "REC_Street", scope = MatchMakerRequest.class)
    public JAXBElement<String> createMatchMakerRequestRECStreet(String value) {
        return new JAXBElement<String>(_MatchMakerRequestRECStreet_QNAME, String.class, MatchMakerRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/padasadatenrequest", name = "REC_Title", scope = MatchMakerRequest.class)
    public JAXBElement<String> createMatchMakerRequestRECTitle(String value) {
        return new JAXBElement<String>(_MatchMakerRequestRECTitle_QNAME, String.class, MatchMakerRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/padasadatenrequest", name = "REC_Country", scope = MatchMakerRequest.class)
    public JAXBElement<String> createMatchMakerRequestRECCountry(String value) {
        return new JAXBElement<String>(_MatchMakerRequestRECCountry_QNAME, String.class, MatchMakerRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/padasadatenrequest", name = "REC_City", scope = MatchMakerRequest.class)
    public JAXBElement<String> createMatchMakerRequestRECCity(String value) {
        return new JAXBElement<String>(_MatchMakerRequestRECCity_QNAME, String.class, MatchMakerRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/padasadatenrequest", name = "Envelope_Version", scope = MatchMakerRequest.class)
    public JAXBElement<String> createMatchMakerRequestEnvelopeVersion(String value) {
        return new JAXBElement<String>(_MatchMakerRequestEnvelopeVersion_QNAME, String.class, MatchMakerRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/padasadatenrequest", name = "REC_Name1", scope = MatchMakerRequest.class)
    public JAXBElement<String> createMatchMakerRequestRECName1(String value) {
        return new JAXBElement<String>(_MatchMakerRequestRECName1_QNAME, String.class, MatchMakerRequest.class, value);
    }

}
