/*
 * Class: BeanNames
 * 
 * Created on Oct 17, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.constant;

import vn.sps.aba.dds.scheduled.sender.parcel.Parcel2VamScheduledSender;

public final class BeanNames {

    public static final String SCHEDULER_PARCEL_VAM_SCHEDULED_SENDER = Parcel2VamScheduledSender.class.getName();

    private BeanNames() {
    }
}
