/*
 * Class: CacheConfiguration
 *
 * Created on May 5, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.cache;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

/**
 * The Class CacheConfiguration.<br>
 * <p>
 * </p>
 */
@Configuration
@EnableCaching
public abstract class CacheConfiguration {

    /** The expired life span. */
    private long expiredLifeSpan;

    /** The expired max idle. */
    private long expiredMaxIdle;

    /** The listenable. */
    private boolean listenable;

    /** The name. */
    private String name;

    /**
     * Gets the expired life span.
     *
     * @return the expired life span
     */
    public long getExpiredLifeSpan() {
        return this.expiredLifeSpan;
    }

    /**
     * Gets the expired max idle.
     *
     * @return the expired max idle
     */
    public long getExpiredMaxIdle() {
        return this.expiredMaxIdle;
    }

    /**
     * Gets the name.
     *
     * @return Returns the name.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Gets the running states.
     *
     * @return the running states
     */
    public abstract String[] getRunningStates();

    /**
     * Checks if is listenable.
     *
     * @return true, if is listenable
     */
    public boolean isListenable() {
        return this.listenable;
    }

    /**
     * Sets the expired life span.
     *
     * @param expiredLifeSpan the new expired life span
     */
    public void setExpiredLifeSpan(final long expiredLifeSpan) {
        this.expiredLifeSpan = expiredLifeSpan;
    }

    /**
     * Sets the expired max idle.
     *
     * @param expiredMaxIdle the new expired max idle
     */
    public void setExpiredMaxIdle(final long expiredMaxIdle) {
        this.expiredMaxIdle = expiredMaxIdle;
    }

    /**
     * Sets the listenable.
     *
     * @param listenable the new listenable
     */
    public void setListenable(final boolean listenable) {
        this.listenable = listenable;
    }

    /**
     * Sets the name.
     *
     * @param name
     *            The name to set.
     */
    public void setName(final String name) {
        this.name = name;
    }

}
