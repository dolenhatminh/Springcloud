/*
 * Class: CacheCollectionsConfiguration
 *
 * Created on May 5, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.cache;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * The Class CacheCollectionsConfiguration.
 */
@Configuration
@ConfigurationProperties(prefix = "cache.asdpplz")
public class CacheAsdpPlzConfiguration extends CacheConfiguration {

    /** The import while boot. */
    private boolean importWhileBoot = true;

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.config.cache.CacheConfiguration#getRunningStates()
     */
    @Override
    public String[] getRunningStates() {
        return new String[0];
    }

    /**
     * Checks if is import while boot.
     *
     * @return true, if is import while boot
     */
    public boolean isImportWhileBoot() {
        return this.importWhileBoot;
    }

    /**
     * Sets the import while boot.
     *
     * @param importWhileBoot the new import while boot
     */
    public void setImportWhileBoot(final boolean importWhileBoot) {
        this.importWhileBoot = importWhileBoot;
    }
}
