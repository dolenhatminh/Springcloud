/*
 * Class: ServiceInfo
 *
 * Created on Oct 24, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.jmx;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

/**
 * The Interface ServiceInfo.
 */
@ManagedResource
public interface ServiceInfo {

    /**
     * Gets the connect timeout.
     *
     * @return the connect timeout
     */
    @ManagedAttribute
    int getConnectTimeout();

    /**
     * Gets the context path.
     *
     * @return the context path
     */
    @ManagedAttribute
    String getContextPath();

    /**
     * Gets the read timeout.
     *
     * @return the read timeout
     */
    @ManagedAttribute
    int getReadTimeout();

    /**
     * Gets the retry interval.
     *
     * @return the retry interval
     */
    @ManagedAttribute
    long getRetryInterval();

    /**
     * Gets the retry times.
     *
     * @return the retry times
     */
    @ManagedAttribute
    int getRetryTime();

    /**
     * Gets the service urls.
     *
     * @return the service urls
     */
    @ManagedAttribute
    String getServiceUrls();
}
