/*
 * Class: AbstractSoapWsTemplate
 *
 * Created on Jul 1, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.interfaces;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration;

/**
 * The Class AbstractSoapWsTemplate.
 *
 * @param <T>
 *            the generic type
 */
public abstract class AbstractSoapWsTemplate<T extends AbstractSoapWsConfiguration> extends WebServiceGatewaySupport {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(AbstractSoapWsTemplate.class);

    /** The configuration. */
    @Autowired
    private T configuration;

    /**
     * Check retry time.
     *
     * @param retryTime the retry time
     * @param maxRetryTimes the max retry times
     * @param retryIntervalTime the retry interval time
     */
    protected void checkRetryTime(final int retryTime, final int maxRetryTimes, final long retryIntervalTime) {
        try {

            if (maxRetryTimes > retryTime) {
                LOG.info("Retry after " + retryIntervalTime + " miliseconds");
                Thread.sleep(retryIntervalTime);
            }
        }
        catch (final Exception e) {
            LOG.debug(null, e);
        }

    }

    /**
     * Gets the configuration.
     *
     * @return Returns the configuration.
     */
    protected T getConfiguration() {
        return this.configuration;
    }

    /**
     * Gets the payload name.
     *
     * @return the payload name
     */
    protected String getPayloadName() {
        return "payload";
    }

    /**
     * Initialize gateway.
     *
     * @throws Exception
     *             the exception
     */
    @Override
    @PostConstruct
    public void initGateway() throws Exception {
        final Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath(this.configuration.getContextPath());
        this.setMarshaller(marshaller);
        this.setUnmarshaller(marshaller);

        LOG.info("Construct the [" + this.getPayloadName() + "] service");
        LOG.info("Service Url:" + this.getConfiguration().getServiceUrl());
    }

    /**
     * Checks if is response ok.
     *
     * @param response
     *            the response
     * @return true, if is response ok
     */
    protected abstract boolean isResponseOk(Object response);

    /**
     * Transfer.
     *
     * @param url the url
     * @param payload the payload
     * @return true, if successful
     */
    protected boolean transfer(final String url, final Object payload) {
        try {
            final Object response = this.getWebServiceTemplate().marshalSendAndReceive(url, payload);
            return this.isResponseOk(response);
        }
        catch (final Exception e) {
            LOG.warn("There is error when transfer [" + this.getPayloadName() + "].", e);
            return false;
        }
    }

    /**
     * Transfer cascade.
     *
     * @param payload the payload
     * @return true, if successful
     */
    protected boolean transferCascade(final Object payload) {
        return this.transferCascade(payload, this.configuration.getServiceUrl());
    }

    /**
     * Send canscade.
     *
     * @param payload            the payload
     * @param url the url
     * @return the object
     */
    protected boolean transferCascade(final Object payload, final String url) {

        boolean ret = false;
        final int maxRetryTimes = this.configuration.getRetryTime();
        int i = 0;

        while (i < this.configuration.getRetryTime()) {
            ret = this.transfer(url, payload);
            if (!ret) {
                i++;
                this.checkRetryTime(i, maxRetryTimes, this.configuration.getRetryIntervalTime());
            }
            else {
                break;
            }
        }

        return ret;
    }
}
