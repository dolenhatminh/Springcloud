/*
 * Class: Consignment
 *
 * Created on May 19, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.parcel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.Enumeration.DmcState;
import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.types.ws.pds.parcel.model.ArrayOfProduktZusatzleistung;
import vn.sps.aba.dds.common.types.ws.pds.parcel.model.TransferParcelInfoIn;

/**
 * The Class Parcel.
 */
@Indexed
public class ParcelInfo implements Serializable, IdentifiedEntry {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -3336349644040978892L;

    /** The barcode data time. */
    private volatile long barcodeBegin;

    /** The pad sent count. */
    private volatile int barcodeCount;

    /** The barcode data done time. */
    private volatile long barcodeEnd;

    /** The barcodes. */
    private List<Barcode> barcodes;

    /** The blackbox time. */
    private volatile long blackboxBegin;

    /** The blackbox count. */
    private volatile int blackboxCount;

    /** The blackbox done time. */
    private volatile long blackboxEnd;

    /** The caller id. */
    private String callerId;

    /** The capture result time. */
    private volatile long captureResultBegin;

    /** The vam sent count. */
    private volatile int captureResultCount;

    /** The capture result done time. */
    private volatile long captureResultEnd;

    /** The destination id. */
    private String destinationId;

    /** The destination station. */
    private String destinationStation;

    /** The dmc time. */
    private volatile long dmcBegin;

    /** The dmc code. */
    private DMCResponse dmcCode;

    /** The dmc sent count. */
    private volatile int dmcCount;

    /** The dmc done time. */
    private long dmcEnd;

    /** The dmc sent. */
    private volatile long dmcSent;

    /** The dmc state. */
    private volatile DmcState dmcState = DmcState.NOT_YET;

    /** The file. */
    private String fileName;

    /** The file path. */
    private String filePath;

    /** The filtered by rule. */
    private String filteredByRule;

    /** The full address. */
    private FullAddress fullAddress;

    /** The has image. */
    private boolean hasImage;

    /** The ident code. */
    private String identCode;

    /** The key. */
    private String key;

    /** The look up start time. */
    private long lookupBegin;

    /** The look up done time. */
    private long lookupEnd;

    /** The parcel address. */
    private ParcelAddress parcelAddress;

    /** The parcel coding info. */
    private ParcelCodingInfo parcelCodingInfo;

    /** The parcel info sent timestamp. */
    private XMLGregorianCalendar parcelInfoSentTimestamp;

    /** The parcel order. */
    private int parcelOrder;

    /** The par pic id. */
    private String parPicId;

    /** The process begin. */
    private long processBegin;

    /** The process end. */
    private long processEnd;

    /** The produkt zusatzleistungens. */
    private List<ProduktZusatzleistung> produktZusatzleistungens;

    /** The received. */
    private long received;

    /** The receiver info. */
    private ReceiverInfo receiverInfo;

    /** The source id. */
    private String sourceId;

    /** The source station. */
    private String sourceStation;

    /** The state. */
    private volatile ParcelState state = ParcelState.RECEIVED;

    /** The status code. */
    private String statusCode;

    /** The stored data time. */
    private long storedDataTime;

    /** The stored image time. */
    private long storedImageTime;

    /** The time stamp. */
    private XMLGregorianCalendar timeStamp;

    /** The transfered time. */
    private long transferedTime;

    /** The vcs case. */
    private int vcsCase;

    /** The version. */
    private int version;

    /**
     * Instantiates a new parcel info.
     */
    public ParcelInfo() {
    }

    /**
     * Instantiates a new parcel info.
     *
     * @param parcelInfoIn the parcel info in
     */
    public ParcelInfo(final TransferParcelInfoIn parcelInfoIn) {
        this(parcelInfoIn.getParcelInfo());
        this.callerId = parcelInfoIn.getCallerId();
        this.version = parcelInfoIn.getVersion();
        this.parcelInfoSentTimestamp = parcelInfoIn.getParcelInfoSentTimestamp();
    }

    /**
     * Constructs a new <tt>ParcelInfo</tt>.
     *
     * @param parcelInfo
     *            the <tt>ParcelInfo</tt> object sent/received via SOAP web
     *            service
     */
    public ParcelInfo(final vn.sps.aba.dds.common.types.ws.pds.parcel.model.ParcelInfo parcelInfo) {

        this.destinationStation = parcelInfo.getDestinationStation();
        this.identCode = parcelInfo.getIdentcode();
        this.parPicId = parcelInfo.getParPicId();
        this.sourceStation = parcelInfo.getSourceStation();
        this.timeStamp = parcelInfo.getTimestamp();
        this.vcsCase = parcelInfo.getVcsCase();

        if ((parcelInfo.getFullAddress() != null) && (parcelInfo.getFullAddress().getValue() != null)) {
            this.fullAddress = new FullAddress(parcelInfo.getFullAddress().getValue());
        }
        if ((parcelInfo.getParcelAddress() != null) && (parcelInfo.getParcelAddress().getValue() != null)) {
            this.parcelAddress = new ParcelAddress(parcelInfo.getParcelAddress().getValue());
        }
        if ((parcelInfo.getParcelCodingInfo() != null) && (parcelInfo.getParcelCodingInfo().getValue() != null)) {
            this.parcelCodingInfo = new ParcelCodingInfo(parcelInfo.getParcelCodingInfo().getValue());
        }

        if ((parcelInfo.getBarcodes() != null) && (parcelInfo.getBarcodes().getValue() != null)) {
            for (final vn.sps.aba.dds.common.types.ws.pds.parcel.model.Barcode wsBarcode : parcelInfo.getBarcodes().getValue().getBarcode()) {
                final Barcode barcode = new Barcode(wsBarcode);
                this.getBarcodes().add(barcode);
            }
        }
        if ((parcelInfo.getProduktZusatzleistungen() != null) && (parcelInfo.getProduktZusatzleistungen().getValue() != null)) {

            final ArrayOfProduktZusatzleistung producktZusatzleistungen = parcelInfo.getProduktZusatzleistungen().getValue();
            for (final vn.sps.aba.dds.common.types.ws.pds.parcel.model.ProduktZusatzleistung wsProdukt : producktZusatzleistungen.getProduktZusatzleistung()) {

                if (!wsProdukt.getCode().isEmpty()) {

                    final ProduktZusatzleistung produkt = new ProduktZusatzleistung(wsProdukt);
                    this.getProduktZusatzleistungens().add(produkt);
                }
            }
        }
    }

    /**
     * Count dmc up.
     */
    public void countDmcUp() {
        this.dmcCount++;
    }

    /**
     * Count pad up.
     */
    public void countPadUp() {
        this.barcodeCount++;
    }

    /**
     * Count vae up.
     */
    public void countVaeUp() {
        this.blackboxCount++;
    }

    /**
     * Count vam up.
     */
    public void countVamUp() {
        this.captureResultCount++;
    }

    /**
     * {@inheritDoc}
     *
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() != obj.getClass()) {
            return false;
        }
        final ParcelInfo other = (ParcelInfo) obj;
        if (this.key == null) {
            if (other.key != null) {
                return false;
            }
        }
        else if (!this.key.equals(other.key)) {
            return false;
        }
        return true;
    }

    /**
     * Gets the barcode data time.
     *
     * @return the barcode data time
     */
    public long getBarcodeBegin() {
        return this.barcodeBegin;
    }

    /**
     * Gets the pad sent count.
     *
     * @return the pad sent count
     */
    public int getBarcodeCount() {
        return this.barcodeCount;
    }

    /**
     * Gets the barcode data done time.
     *
     * @return the barcode data done time
     */
    public long getBarcodeEnd() {
        return this.barcodeEnd;
    }

    /**
     * Gets the barcodes.
     *
     * @return Returns the barcodes.
     */
    public List<Barcode> getBarcodes() {
        if (this.barcodes == null) {
            this.barcodes = new ArrayList<>();
        }
        return this.barcodes;
    }

    /**
     * Gets the blackbox begin.
     *
     * @return the blackbox begin
     */
    public long getBlackboxBegin() {
        return this.blackboxBegin;
    }

    /**
     * Gets the blackbox count.
     *
     * @return the blackbox count
     */
    public int getBlackboxCount() {
        return this.blackboxCount;
    }

    /**
     * Gets the blackbox end.
     *
     * @return the blackbox end
     */
    public long getBlackboxEnd() {
        return this.blackboxEnd;
    }

    /**
     * Gets the caller id.
     *
     * @return the caller id
     */
    public String getCallerId() {
        return this.callerId;
    }

    /**
     * Gets the capture result begin.
     *
     * @return the capture result begin
     */
    public long getCaptureResultBegin() {
        return this.captureResultBegin;
    }

    /**
     * Gets the capture result count.
     *
     * @return the capture result count
     */
    public int getCaptureResultCount() {
        return this.captureResultCount;
    }

    /**
     * Gets the capture result end.
     *
     * @return the capture result end
     */
    public long getCaptureResultEnd() {
        return this.captureResultEnd;
    }

    /**
     * Gets the destination id.
     *
     * @return the destination id
     */
    public String getDestinationId() {
        return this.destinationId;
    }

    /**
     * Gets the destination station.
     *
     * @return Returns the destinationStation.
     */
    public String getDestinationStation() {
        return this.destinationStation;
    }

    /**
     * Gets the dmc begin.
     *
     * @return the dmc begin
     */
    public long getDmcBegin() {
        return this.dmcBegin;
    }

    /**
     * Gets the dmc code.
     *
     * @return the dmc code
     */
    public DMCResponse getDmcCode() {
        return this.dmcCode;
    }

    /**
     * Gets the dmc sent count.
     *
     * @return the dmc sent count
     */
    public int getDmcCount() {
        return this.dmcCount;
    }

    /**
     * Gets the dmc end.
     *
     * @return the dmc end
     */
    public long getDmcEnd() {
        return this.dmcEnd;
    }

    /**
     * Gets the dmc sent.
     *
     * @return the dmc sent
     */
    public long getDmcSent() {
        return this.dmcSent;
    }

    /**
     * Gets the dmc state.
     *
     * @return the dmc state
     */
    public DmcState getDmcState() {
        return this.dmcState;
    }

    /**
     * Gets the file name.
     *
     * @return Returns the fileName.
     */
    public String getFileName() {
        return this.fileName;
    }

    /**
     * Gets the file path.
     *
     * @return Returns the filePath.
     */
    public String getFilePath() {
        return this.filePath;
    }

    /**
     * Gets the filtered by rule.
     *
     * @return the filtered by rule
     */
    public String getFilteredByRule() {
        return this.filteredByRule;
    }

    /**
     * Gets the full address.
     *
     * @return Returns the fullAddress.
     */
    public FullAddress getFullAddress() {
        return this.fullAddress;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getIdentCode()
     */
    @Override
    @Field(store = Store.YES, analyze = Analyze.NO, name = DDSConstant.ParcelFields.FIELD_IDENT_CODE)
    public String getIdentCode() {
        return this.identCode;
    }

    /**
     * Gets the image absolute path.
     *
     * @return the image absolute path
     */
    public String getImageAbsolutePath() {
        return this.filePath + Constant.FILE_SEPARATOR + this.fileName;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getKey()
     */
    @Override
    @Field(store = Store.YES, analyze = Analyze.NO, name = DDSConstant.ParcelFields.FIELD_KEY)
    public String getKey() {
        return this.key;
    }

    /**
     * Gets the lookup begin.
     *
     * @return the lookup begin
     */
    public long getLookupBegin() {
        return this.lookupBegin;
    }

    /**
     * Gets the lookup end.
     *
     * @return the lookup end
     */
    public long getLookupEnd() {
        return this.lookupEnd;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getMinorState()
     */
    @Override
    @Field(store = Store.YES, analyze = Analyze.NO, name = DDSConstant.ParcelFields.FIELD_DMC_STATE)
    public String getMinorState() {
        return this.dmcState.name();
    }

    /**
     * Gets the parcel address.
     *
     * @return Returns the parcelAddress.
     */
    public ParcelAddress getParcelAddress() {
        return this.parcelAddress;
    }

    /**
     * Gets the parcel coding info.
     *
     * @return Returns the parcelCodingInfo.
     */
    public ParcelCodingInfo getParcelCodingInfo() {
        return this.parcelCodingInfo;
    }

    /**
     * Gets the parcel info sent timestamp.
     *
     * @return the parcel info sent timestamp
     */
    public XMLGregorianCalendar getParcelInfoSentTimestamp() {
        return this.parcelInfoSentTimestamp;
    }

    /**
     * Gets the parcel order.
     *
     * @return the parcel order
     */
    public int getParcelOrder() {
        return this.parcelOrder;
    }

    /**
     * Gets the parcel state.
     *
     * @return the parcel state
     */
    public ParcelState getParcelState() {
        return this.state;
    }

    /**
     * Gets the par pic id.
     *
     * @return Returns the parPicId.
     */
    public String getParPicId() {
        return this.parPicId;
    }

    /**
     * Gets the process begin.
     *
     * @return the process begin
     */
    public long getProcessBegin() {
        return this.processBegin;
    }

    /**
     * Gets the process end.
     *
     * @return the process end
     */
    public long getProcessEnd() {
        return this.processEnd;
    }

    /**
     * Gets the produkt zusatzleistungens.
     *
     * @return Returns the produktZusatzleistungens.
     */
    public List<ProduktZusatzleistung> getProduktZusatzleistungens() {
        if (this.produktZusatzleistungens == null) {
            this.produktZusatzleistungens = new ArrayList<>();
        }
        return this.produktZusatzleistungens;
    }

    /**
     * Gets the produkt zusatzleistungens as array.
     *
     * @return the produkt zusatzleistungens as array
     */
    public String[] getProduktZusatzleistungensAsArray() {
        final String[] ret = new String[this.getProduktZusatzleistungens().size()];

        for (int i = 0; i < this.produktZusatzleistungens.size(); i++) {
            ret[i] = this.produktZusatzleistungens.get(i).getCode();
        }

        return ret;
    }

    /**
     * Gets the received.
     *
     * @return the received
     */
    @Override
    @Field(store = Store.YES, analyze = Analyze.NO, name = DDSConstant.ParcelFields.FIELD_RECEIVED_TIME)
    public long getReceived() {
        return this.received;
    }

    /**
     * Gets the receiver info.
     *
     * @return the receiver info
     */
    public ReceiverInfo getReceiverInfo() {
        return this.receiverInfo;
    }

    /**
     * Gets the source id.
     *
     * @return the source id
     */
    public String getSourceId() {
        return this.sourceId;
    }

    /**
     * Gets the source station.
     *
     * @return Returns the sourceStation.
     */
    public String getSourceStation() {
        return this.sourceStation;
    }

    /**
     * Gets the state.
     *
     * @return the state
     */
    @Override
    @Field(store = Store.YES, analyze = Analyze.NO, name = DDSConstant.ParcelFields.FIELD_STATE)
    public String getState() {
        return this.state.name();
    }

    /**
     * Gets the status code.
     *
     * @return the status code
     */
    public String getStatusCode() {
        return this.statusCode;
    }

    /**
     * Gets the stored data time.
     *
     * @return the stored data time
     */
    public long getStoredDataTime() {
        return this.storedDataTime;
    }

    /**
     * Gets the stored image time.
     *
     * @return the stored image time
     */
    public long getStoredImageTime() {
        return this.storedImageTime;
    }

    /**
     * Gets the time stamp.
     *
     * @return Returns the timeStamp.
     */
    public XMLGregorianCalendar getTimeStamp() {
        return this.timeStamp;
    }

    /**
     * Gets the transfered time.
     *
     * @return Returns the transferedTime.
     */
    public long getTransferedTime() {
        return this.transferedTime;
    }

    /**
     * Gets the vam sent count.
     *
     * @return the vam sent count
     */
    public int getVamSentCount() {
        return this.captureResultCount;
    }

    /**
     * Gets the vcs case.
     *
     * @return Returns the vcsCase.
     */
    public int getVcsCase() {
        return this.vcsCase;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public int getVersion() {
        return this.version;
    }

    /**
     * {@inheritDoc}
     *
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = (prime * result) + ((this.key == null) ? 0 : this.key.hashCode());
        return result;
    }

    /**
     * Checks if is checks for image.
     *
     * @return Returns the hasImage.
     */
    public boolean isHasImage() {
        return this.hasImage;
    }

    /**
     * Sets the barcode data time.
     *
     * @param barcodeBegin
     *            the new barcode data time
     */
    public void setBarcodeBegin(final long barcodeBegin) {
        this.barcodeBegin = barcodeBegin;
    }

    /**
     * Sets the pad sent count.
     *
     * @param barcodeCount the new pad sent count
     */
    public void setBarcodeCount(final int barcodeCount) {
        this.barcodeCount = barcodeCount;
    }

    /**
     * Sets the barcode data done time.
     *
     * @param barcodeEnd the new barcode data done time
     */
    public void setBarcodeEnd(final long barcodeEnd) {
        this.barcodeEnd = barcodeEnd;
    }

    /**
     * Sets the blackbox begin.
     *
     * @param blackboxBegin the new blackbox begin
     */
    public void setBlackboxBegin(final long blackboxBegin) {
        this.blackboxBegin = blackboxBegin;
    }

    /**
     * Sets the blackbox count.
     *
     * @param blackboxCount the new blackbox count
     */
    public void setBlackboxCount(final int blackboxCount) {
        this.blackboxCount = blackboxCount;
    }

    /**
     * Sets the blackbox end.
     *
     * @param blackboxEnd the new blackbox end
     */
    public void setBlackboxEnd(final long blackboxEnd) {
        this.blackboxEnd = blackboxEnd;
    }

    /**
     * Sets the caller id.
     *
     * @param callerId the new caller id
     */
    public void setCallerId(final String callerId) {
        this.callerId = callerId;
    }

    /**
     * Sets the capture result begin.
     *
     * @param captureResultBegin the new capture result begin
     */
    public void setCaptureResultBegin(final long captureResultBegin) {
        this.captureResultBegin = captureResultBegin;
    }

    /**
     * Sets the vam sent count.
     *
     * @param captureResultCount the new vam sent count
     */
    public void setCaptureResultCount(final int captureResultCount) {
        this.captureResultCount = captureResultCount;
    }

    /**
     * Sets the capture result end.
     *
     * @param captureResultEnd the new capture result end
     */
    public void setCaptureResultEnd(final long captureResultEnd) {
        this.captureResultEnd = captureResultEnd;
    }

    /**
     * Sets the destination id.
     *
     * @param destinationId the new destination id
     */
    public void setDestinationId(final String destinationId) {
        this.destinationId = destinationId;
    }

    /**
     * Sets the destination station.
     *
     * @param destinationStation
     *            The destinationStation to set.
     */
    public void setDestinationStation(final String destinationStation) {
        this.destinationStation = destinationStation;
    }

    /**
     * Sets the dmc begin.
     *
     * @param dmcBegin the new dmc begin
     */
    public void setDmcBegin(final long dmcBegin) {
        this.dmcBegin = dmcBegin;
    }

    /**
     * Sets the dmc code.
     *
     * @param dmcCode the new dmc code
     */
    public void setDmcCode(final DMCResponse dmcCode) {
        this.dmcCode = dmcCode;
    }

    /**
     * Sets the dmc sent count.
     *
     * @param dmcCount the new dmc sent count
     */
    public void setDmcCount(final int dmcCount) {
        this.dmcCount = dmcCount;
    }

    /**
     * Sets the dmc end.
     *
     * @param dmcEnd the new dmc end
     */
    public void setDmcEnd(final long dmcEnd) {
        this.dmcEnd = dmcEnd;
    }

    /**
     * Sets the dmc sent.
     *
     * @param dmcSent the new dmc sent
     */
    public void setDmcSent(final long dmcSent) {
        this.dmcSent = dmcSent;
    }

    /**
     * Sets the dmc state.
     *
     * @param dmcState the new dmc state
     */
    public void setDmcState(final DmcState dmcState) {
        this.dmcState = dmcState;
    }

    /**
     * Sets the file name.
     *
     * @param fileName
     *            The fileName to set.
     */
    public void setFileName(final String fileName) {
        this.fileName = fileName;
    }

    /**
     * Sets the file path.
     *
     * @param filePath
     *            The filePath to set.
     */
    public void setFilePath(final String filePath) {
        this.filePath = filePath;
    }

    /**
     * Sets the filtered by rule.
     *
     * @param filteredByRule the new filtered by rule
     */
    public void setFilteredByRule(final String filteredByRule) {
        this.filteredByRule = filteredByRule;
    }

    /**
     * Sets the full address.
     *
     * @param fullAddress
     *            The fullAddress to set.
     */
    public void setFullAddress(final FullAddress fullAddress) {
        this.fullAddress = fullAddress;
    }

    /**
     * Sets the checks for image.
     *
     * @param hasImage
     *            The hasImage to set.
     */
    public void setHasImage(final boolean hasImage) {
        this.hasImage = hasImage;
    }

    /**
     * Sets the ident code.
     *
     * @param identCode
     *            The identCode to set.
     */
    public void setIdentCode(final String identCode) {
        this.identCode = identCode;
    }

    /**
     * Sets the key.
     *
     * @param key
     *            The key to set.
     */
    public void setKey(final String key) {
        this.key = key;
    }

    /**
     * Sets the lookup begin.
     *
     * @param lookupBegin the new lookup begin
     */
    public void setLookupBegin(final long lookupBegin) {
        this.lookupBegin = lookupBegin;
    }

    /**
     * Sets the lookup end.
     *
     * @param lookupEnd the new lookup end
     */
    public void setLookupEnd(final long lookupEnd) {
        this.lookupEnd = lookupEnd;
    }

    /**
     * Sets the parcel address.
     *
     * @param parcelAddress
     *            The parcelAddress to set.
     */
    public void setParcelAddress(final ParcelAddress parcelAddress) {
        this.parcelAddress = parcelAddress;
    }

    /**
     * Sets the parcel coding info.
     *
     * @param parcelCodingInfo
     *            The parcelCodingInfo to set.
     */
    public void setParcelCodingInfo(final ParcelCodingInfo parcelCodingInfo) {
        this.parcelCodingInfo = parcelCodingInfo;
    }

    /**
     * Sets the parcel info sent timestamp.
     *
     * @param parcelInfoSentTimestamp the new parcel info sent timestamp
     */
    public void setParcelInfoSentTimestamp(final XMLGregorianCalendar parcelInfoSentTimestamp) {
        this.parcelInfoSentTimestamp = parcelInfoSentTimestamp;
    }

    /**
     * Sets the parcel order.
     *
     * @param parcelOrder the new parcel order
     */
    public void setParcelOrder(final int parcelOrder) {
        this.parcelOrder = parcelOrder;
    }

    /**
     * Sets the par pic id.
     *
     * @param parPicId
     *            The parPicId to set.
     */
    public void setParPicId(final String parPicId) {
        this.parPicId = parPicId;
    }

    /**
     * Sets the process begin.
     *
     * @param processBegin the new process begin
     */
    public void setProcessBegin(final long processBegin) {
        this.processBegin = processBegin;
    }

    /**
     * Sets the process end.
     *
     * @param processEnd the new process end
     */
    public void setProcessEnd(final long processEnd) {
        this.processEnd = processEnd;
    }

    /**
     * Sets the received.
     *
     * @param received the new received
     */
    public void setReceived(final long received) {
        this.received = received;
    }

    /**
     * Sets the receiver info.
     *
     * @param receiverInfo the new receiver info
     */
    public void setReceiverInfo(final ReceiverInfo receiverInfo) {
        this.receiverInfo = receiverInfo;
    }

    /**
     * Sets the source id.
     *
     * @param sourceId the new source id
     */
    public void setSourceId(final String sourceId) {
        this.sourceId = sourceId;
    }

    /**
     * Sets the source station.
     *
     * @param sourceStation
     *            The sourceStation to set.
     */
    public void setSourceStation(final String sourceStation) {
        this.sourceStation = sourceStation;
    }

    /**
     * Sets the state.
     *
     * @param state the new state
     */
    public void setState(final ParcelState state) {
        this.state = state;
    }

    /**
     * Sets the status code.
     *
     * @param statusCode the new status code
     */
    public void setStatusCode(final String statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Sets the stored data time.
     *
     * @param storedDataTime the new stored data time
     */
    public void setStoredDataTime(final long storedDataTime) {
        this.storedDataTime = storedDataTime;
    }

    /**
     * Sets the stored image time.
     *
     * @param storedImageTime the new stored image time
     */
    public void setStoredImageTime(final long storedImageTime) {
        this.storedImageTime = storedImageTime;
    }

    /**
     * Sets the time stamp.
     *
     * @param timeStamp
     *            The timeStamp to set.
     */
    public void setTimeStamp(final XMLGregorianCalendar timeStamp) {
        this.timeStamp = timeStamp;
    }

    /**
     * Sets the transfered time.
     *
     * @param transferedTime
     *            The transferedTime to set.
     */
    public void setTransferedTime(final long transferedTime) {
        this.transferedTime = transferedTime;
    }

    /**
     * Sets the vcs case.
     *
     * @param vcsCase
     *            The vcsCase to set.
     */
    public void setVcsCase(final int vcsCase) {
        this.vcsCase = vcsCase;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(final int version) {
        this.version = version;
    }

    /**
     * To short string.
     *
     * @return the string
     */
    public String toShortString() {
        return this.identCode;
    }
}
