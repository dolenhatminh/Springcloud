
package vn.sps.aba.dds.common.types.ws.dpmb;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ePersStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ePersStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Initial"/>
 *     &lt;enumeration value="Aktiv"/>
 *     &lt;enumeration value="GestorbenAbgelaufen"/>
 *     &lt;enumeration value="Wegzug"/>
 *     &lt;enumeration value="Provisorisch"/>
 *     &lt;enumeration value="Dublette"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ePersStatus")
@XmlEnum
public enum EPersStatus {

    @XmlEnumValue("Initial")
    INITIAL("Initial"),
    @XmlEnumValue("Aktiv")
    AKTIV("Aktiv"),
    @XmlEnumValue("GestorbenAbgelaufen")
    GESTORBEN_ABGELAUFEN("GestorbenAbgelaufen"),
    @XmlEnumValue("Wegzug")
    WEGZUG("Wegzug"),
    @XmlEnumValue("Provisorisch")
    PROVISORISCH("Provisorisch"),
    @XmlEnumValue("Dublette")
    DUBLETTE("Dublette");
    private final String value;

    EPersStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static EPersStatus fromValue(String v) {
        for (EPersStatus c: EPersStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
