/*
 * Class: UnsupportedAttributeException
 *
 * Created on Jun 22, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.exception;

/**
 * The Class UnsupportedAttributeException.
 */
public class UnsupportedAttributeException extends Exception {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 6341612937364844896L;

    /**
     * Constructs a new <tt>UnsupportedAttributeException</tt>.
     *
     * @param attribute the attribute
     */
    public UnsupportedAttributeException(final String attribute) {
        super("Unsupported attribute: " + attribute);
    }

    /**
     * Instantiates a new unsupported attribute exception.
     *
     * @param attribute the attribute
     * @param message the message
     */
    public UnsupportedAttributeException(final String attribute, final String message) {
        super(message);
    }

}
