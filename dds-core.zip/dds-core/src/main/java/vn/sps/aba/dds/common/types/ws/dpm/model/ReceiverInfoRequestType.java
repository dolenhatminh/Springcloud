
package vn.sps.aba.dds.common.types.ws.dpm.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ReceiverInfoRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReceiverInfoRequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CallerId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ReceiverInfo" type="{Ch.Post.PL.DisCo.ReceiverInfoService}ReceiverInfoType"/>
 *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReceiverInfoRequestType", propOrder = {
    "callerId",
    "receiverInfo",
    "version"
})
public class ReceiverInfoRequestType {

    @XmlElement(name = "CallerId", required = true, nillable = true)
    protected String callerId;
    @XmlElement(name = "ReceiverInfo", required = true, nillable = true)
    protected ReceiverInfoType receiverInfo;
    @XmlElement(name = "Version")
    protected int version;

    /**
     * Gets the value of the callerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallerId() {
        return callerId;
    }

    /**
     * Sets the value of the callerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallerId(String value) {
        this.callerId = value;
    }

    /**
     * Gets the value of the receiverInfo property.
     * 
     * @return
     *     possible object is
     *     {@link ReceiverInfoType }
     *     
     */
    public ReceiverInfoType getReceiverInfo() {
        return receiverInfo;
    }

    /**
     * Sets the value of the receiverInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReceiverInfoType }
     *     
     */
    public void setReceiverInfo(ReceiverInfoType value) {
        this.receiverInfo = value;
    }

    /**
     * Gets the value of the version property.
     * 
     */
    public int getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     */
    public void setVersion(int value) {
        this.version = value;
    }

}
