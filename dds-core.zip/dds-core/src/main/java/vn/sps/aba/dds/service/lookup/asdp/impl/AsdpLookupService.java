/*
 * Class: AsdpLookupService
 *
 * Created on Jun 22, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.lookup.asdp.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.lookup.AsdpPlz;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.service.AbstractRestWsConfiguration;
import vn.sps.aba.dds.config.service.AsdpServiceConfiguration;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate;
import vn.sps.aba.dds.service.lookup.asdp.IAsdpLookupService;

/**
 * The Class AsdpLookupService.
 */
@Service
@ConditionalOnProperty(name = "lookup.asdp.external", havingValue = "true")
public class AsdpLookupService extends AbstractRestWsTemplate<AsdpPlz> implements IAsdpLookupService {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(AsdpLookupService.class);

    /** The service configuration. */
    @Autowired
    private AsdpServiceConfiguration serviceConfiguration;

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.service.lookup.asdp.IAsdpLookupService#getAsdpPlz(vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public AsdpPlz getAsdpPlz(final ParcelInfo parcelInfo) {
        AsdpPlz response = null;
        String requestUrl = null;

        // Check null before call this function
        final String plz = parcelInfo.getParcelAddress().getZip();

        try {
            if (StringUtil.notNullOrEmpty(plz)) {
                requestUrl = String.join(DDSConstant.Common.CHAR_SLASH, this.getConfiguration().getServiceUrl(), plz);

                parcelInfo.setLookupBegin(DiscoWallClock.milli());
                response = this.sendCascade(parcelInfo, null, AsdpPlz.class, requestUrl);
                parcelInfo.setLookupEnd(DiscoWallClock.milli());
            }
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.indexes(parcelInfo), "There is error while lookup Asdp data {}", requestUrl, e);
        }

        return response;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.lookup.asdp.IAsdpLookupService#getAsdpPlz(java.lang.String)
     */
    @Override
    public AsdpPlz getAsdpPlz(final String plz) {

        AsdpPlz response = null;
        final String requestUrl = this.getConfiguration().getServiceUrl() + DDSConstant.Common.CHAR_SLASH + plz;
        try {
            response = this.restTemplate.getForObject(requestUrl, AsdpPlz.class);
        }
        catch (final Exception e) {
            LOG.error("There is error while lookup Asdp data " + requestUrl, e);
        }

        return response;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate#getConfiguration()
     */
    @Override
    protected AbstractRestWsConfiguration getConfiguration() {
        return this.serviceConfiguration;
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.service.dmc.AbstractRestWsTemplate#send(java.lang.String, java.lang.String, java.lang.Object, int, java.lang.Class)
     */
    @Override
    protected AsdpPlz send(final IdentifiedEntry entry, final String url, final Object message, final int readTimeOut, final Class<AsdpPlz> clazz) {
        try {
            return this.restTemplate.getForObject(url, clazz);
        }
        catch (final Exception e) {
            LOG.warn(IndexMaker.indexes(entry), "There is error when look up ASDP.", e);
        }
        return null;
    }

}
