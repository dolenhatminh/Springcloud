
package vn.sps.aba.dds.common.types.ws.pds.parcel.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the vn.sps.aba.dds.service.pds.parcel.model package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _UnsignedLong_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedLong");
    private final static QName _UnsignedByte_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedByte");
    private final static QName _UnsignedShort_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedShort");
    private final static QName _TransferParcelInfoOut_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "TransferParcelInfoOut");
    private final static QName _Duration_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "duration");
    private final static QName _FullAddress_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "FullAddress");
    private final static QName _ParcelCodingInfo_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "ParcelCodingInfo");
    private final static QName _ParcelAddress_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "ParcelAddress");
    private final static QName _Long_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "long");
    private final static QName _Float_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "float");
    private final static QName _DateTime_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "dateTime");
    private final static QName _ProduktZusatzleistung_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "ProduktZusatzleistung");
    private final static QName _AnyType_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "anyType");
    private final static QName _String_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "string");
    private final static QName _ParcelInfo_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "ParcelInfo");
    private final static QName _UnsignedInt_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedInt");
    private final static QName _Char_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "char");
    private final static QName _Short_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "short");
    private final static QName _Guid_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "guid");
    private final static QName _Decimal_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "decimal");
    private final static QName _TransferParcelInfoIn_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "TransferParcelInfoIn");
    private final static QName _Boolean_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "boolean");
    private final static QName _Base64Binary_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "base64Binary");
    private final static QName _Int_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "int");
    private final static QName _AnyURI_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "anyURI");
    private final static QName _ArrayOfBarcode_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "ArrayOfBarcode");
    private final static QName _Byte_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "byte");
    private final static QName _Double_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "double");
    private final static QName _QName_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "QName");
    private final static QName _Barcode_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "Barcode");
    private final static QName _ArrayOfProduktZusatzleistung_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "ArrayOfProduktZusatzleistung");
    private final static QName _TransferParcelInfoResponseTransferParcelInfoResult_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "TransferParcelInfoResult");
    private final static QName _TransferParcelInfoRequest_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "request");
    private final static QName _TransferParcelInfoOutDetailText_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "DetailText");
    private final static QName _ParcelInfoProduktZusatzleistungen_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "ProduktZusatzleistungen");
    private final static QName _ParcelInfoBarcodes_QNAME = new QName("Ch.Post.PL.Vae.VG.ParcelInfoService", "Barcodes");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: vn.sps.aba.dds.service.pds.parcel.model
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TransferParcelInfo }
     * 
     */
    public TransferParcelInfo createTransferParcelInfo() {
        return new TransferParcelInfo();
    }

    /**
     * Create an instance of {@link TransferParcelInfoIn }
     * 
     */
    public TransferParcelInfoIn createTransferParcelInfoIn() {
        return new TransferParcelInfoIn();
    }

    /**
     * Create an instance of {@link TransferParcelInfoOut }
     * 
     */
    public TransferParcelInfoOut createTransferParcelInfoOut() {
        return new TransferParcelInfoOut();
    }

    /**
     * Create an instance of {@link FullAddress }
     * 
     */
    public FullAddress createFullAddress() {
        return new FullAddress();
    }

    /**
     * Create an instance of {@link ProduktZusatzleistung }
     * 
     */
    public ProduktZusatzleistung createProduktZusatzleistung() {
        return new ProduktZusatzleistung();
    }

    /**
     * Create an instance of {@link ParcelCodingInfo }
     * 
     */
    public ParcelCodingInfo createParcelCodingInfo() {
        return new ParcelCodingInfo();
    }

    /**
     * Create an instance of {@link ParcelAddress }
     * 
     */
    public ParcelAddress createParcelAddress() {
        return new ParcelAddress();
    }

    /**
     * Create an instance of {@link Barcode }
     * 
     */
    public Barcode createBarcode() {
        return new Barcode();
    }

    /**
     * Create an instance of {@link ArrayOfProduktZusatzleistung }
     * 
     */
    public ArrayOfProduktZusatzleistung createArrayOfProduktZusatzleistung() {
        return new ArrayOfProduktZusatzleistung();
    }

    /**
     * Create an instance of {@link ParcelInfo }
     * 
     */
    public ParcelInfo createParcelInfo() {
        return new ParcelInfo();
    }

    /**
     * Create an instance of {@link TransferParcelInfoResponse }
     * 
     */
    public TransferParcelInfoResponse createTransferParcelInfoResponse() {
        return new TransferParcelInfoResponse();
    }

    /**
     * Create an instance of {@link ArrayOfBarcode }
     * 
     */
    public ArrayOfBarcode createArrayOfBarcode() {
        return new ArrayOfBarcode();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedLong")
    public JAXBElement<BigInteger> createUnsignedLong(BigInteger value) {
        return new JAXBElement<BigInteger>(_UnsignedLong_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Short }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedByte")
    public JAXBElement<Short> createUnsignedByte(Short value) {
        return new JAXBElement<Short>(_UnsignedByte_QNAME, Short.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedShort")
    public JAXBElement<Integer> createUnsignedShort(Integer value) {
        return new JAXBElement<Integer>(_UnsignedShort_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransferParcelInfoOut }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "TransferParcelInfoOut")
    public JAXBElement<TransferParcelInfoOut> createTransferParcelInfoOut(TransferParcelInfoOut value) {
        return new JAXBElement<TransferParcelInfoOut>(_TransferParcelInfoOut_QNAME, TransferParcelInfoOut.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Duration }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "duration")
    public JAXBElement<Duration> createDuration(Duration value) {
        return new JAXBElement<Duration>(_Duration_QNAME, Duration.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FullAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "FullAddress")
    public JAXBElement<FullAddress> createFullAddress(FullAddress value) {
        return new JAXBElement<FullAddress>(_FullAddress_QNAME, FullAddress.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParcelCodingInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "ParcelCodingInfo")
    public JAXBElement<ParcelCodingInfo> createParcelCodingInfo(ParcelCodingInfo value) {
        return new JAXBElement<ParcelCodingInfo>(_ParcelCodingInfo_QNAME, ParcelCodingInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParcelAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "ParcelAddress")
    public JAXBElement<ParcelAddress> createParcelAddress(ParcelAddress value) {
        return new JAXBElement<ParcelAddress>(_ParcelAddress_QNAME, ParcelAddress.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "long")
    public JAXBElement<Long> createLong(Long value) {
        return new JAXBElement<Long>(_Long_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Float }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "float")
    public JAXBElement<Float> createFloat(Float value) {
        return new JAXBElement<Float>(_Float_QNAME, Float.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "dateTime")
    public JAXBElement<XMLGregorianCalendar> createDateTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_DateTime_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProduktZusatzleistung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "ProduktZusatzleistung")
    public JAXBElement<ProduktZusatzleistung> createProduktZusatzleistung(ProduktZusatzleistung value) {
        return new JAXBElement<ProduktZusatzleistung>(_ProduktZusatzleistung_QNAME, ProduktZusatzleistung.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "anyType")
    public JAXBElement<Object> createAnyType(Object value) {
        return new JAXBElement<Object>(_AnyType_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "string")
    public JAXBElement<String> createString(String value) {
        return new JAXBElement<String>(_String_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParcelInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "ParcelInfo")
    public JAXBElement<ParcelInfo> createParcelInfo(ParcelInfo value) {
        return new JAXBElement<ParcelInfo>(_ParcelInfo_QNAME, ParcelInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedInt")
    public JAXBElement<Long> createUnsignedInt(Long value) {
        return new JAXBElement<Long>(_UnsignedInt_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "char")
    public JAXBElement<Integer> createChar(Integer value) {
        return new JAXBElement<Integer>(_Char_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Short }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "short")
    public JAXBElement<Short> createShort(Short value) {
        return new JAXBElement<Short>(_Short_QNAME, Short.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "guid")
    public JAXBElement<String> createGuid(String value) {
        return new JAXBElement<String>(_Guid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "decimal")
    public JAXBElement<BigDecimal> createDecimal(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_Decimal_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransferParcelInfoIn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "TransferParcelInfoIn")
    public JAXBElement<TransferParcelInfoIn> createTransferParcelInfoIn(TransferParcelInfoIn value) {
        return new JAXBElement<TransferParcelInfoIn>(_TransferParcelInfoIn_QNAME, TransferParcelInfoIn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "boolean")
    public JAXBElement<Boolean> createBoolean(Boolean value) {
        return new JAXBElement<Boolean>(_Boolean_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link byte[]}{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "base64Binary")
    public JAXBElement<byte[]> createBase64Binary(byte[] value) {
        return new JAXBElement<byte[]>(_Base64Binary_QNAME, byte[].class, null, ((byte[]) value));
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "int")
    public JAXBElement<Integer> createInt(Integer value) {
        return new JAXBElement<Integer>(_Int_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "anyURI")
    public JAXBElement<String> createAnyURI(String value) {
        return new JAXBElement<String>(_AnyURI_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBarcode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "ArrayOfBarcode")
    public JAXBElement<ArrayOfBarcode> createArrayOfBarcode(ArrayOfBarcode value) {
        return new JAXBElement<ArrayOfBarcode>(_ArrayOfBarcode_QNAME, ArrayOfBarcode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Byte }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "byte")
    public JAXBElement<Byte> createByte(Byte value) {
        return new JAXBElement<Byte>(_Byte_QNAME, Byte.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "double")
    public JAXBElement<Double> createDouble(Double value) {
        return new JAXBElement<Double>(_Double_QNAME, Double.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "QName")
    public JAXBElement<QName> createQName(QName value) {
        return new JAXBElement<QName>(_QName_QNAME, QName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Barcode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "Barcode")
    public JAXBElement<Barcode> createBarcode(Barcode value) {
        return new JAXBElement<Barcode>(_Barcode_QNAME, Barcode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfProduktZusatzleistung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "ArrayOfProduktZusatzleistung")
    public JAXBElement<ArrayOfProduktZusatzleistung> createArrayOfProduktZusatzleistung(ArrayOfProduktZusatzleistung value) {
        return new JAXBElement<ArrayOfProduktZusatzleistung>(_ArrayOfProduktZusatzleistung_QNAME, ArrayOfProduktZusatzleistung.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransferParcelInfoOut }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "TransferParcelInfoResult", scope = TransferParcelInfoResponse.class)
    public JAXBElement<TransferParcelInfoOut> createTransferParcelInfoResponseTransferParcelInfoResult(TransferParcelInfoOut value) {
        return new JAXBElement<TransferParcelInfoOut>(_TransferParcelInfoResponseTransferParcelInfoResult_QNAME, TransferParcelInfoOut.class, TransferParcelInfoResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransferParcelInfoIn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "request", scope = TransferParcelInfo.class)
    public JAXBElement<TransferParcelInfoIn> createTransferParcelInfoRequest(TransferParcelInfoIn value) {
        return new JAXBElement<TransferParcelInfoIn>(_TransferParcelInfoRequest_QNAME, TransferParcelInfoIn.class, TransferParcelInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "DetailText", scope = TransferParcelInfoOut.class)
    public JAXBElement<String> createTransferParcelInfoOutDetailText(String value) {
        return new JAXBElement<String>(_TransferParcelInfoOutDetailText_QNAME, String.class, TransferParcelInfoOut.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfProduktZusatzleistung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "ProduktZusatzleistungen", scope = ParcelInfo.class)
    public JAXBElement<ArrayOfProduktZusatzleistung> createParcelInfoProduktZusatzleistungen(ArrayOfProduktZusatzleistung value) {
        return new JAXBElement<ArrayOfProduktZusatzleistung>(_ParcelInfoProduktZusatzleistungen_QNAME, ArrayOfProduktZusatzleistung.class, ParcelInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBarcode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "Barcodes", scope = ParcelInfo.class)
    public JAXBElement<ArrayOfBarcode> createParcelInfoBarcodes(ArrayOfBarcode value) {
        return new JAXBElement<ArrayOfBarcode>(_ParcelInfoBarcodes_QNAME, ArrayOfBarcode.class, ParcelInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FullAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "FullAddress", scope = ParcelInfo.class)
    public JAXBElement<FullAddress> createParcelInfoFullAddress(FullAddress value) {
        return new JAXBElement<FullAddress>(_FullAddress_QNAME, FullAddress.class, ParcelInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParcelCodingInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "ParcelCodingInfo", scope = ParcelInfo.class)
    public JAXBElement<ParcelCodingInfo> createParcelInfoParcelCodingInfo(ParcelCodingInfo value) {
        return new JAXBElement<ParcelCodingInfo>(_ParcelCodingInfo_QNAME, ParcelCodingInfo.class, ParcelInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParcelAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.VG.ParcelInfoService", name = "ParcelAddress", scope = ParcelInfo.class)
    public JAXBElement<ParcelAddress> createParcelInfoParcelAddress(ParcelAddress value) {
        return new JAXBElement<ParcelAddress>(_ParcelAddress_QNAME, ParcelAddress.class, ParcelInfo.class, value);
    }

}
