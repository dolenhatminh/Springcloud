
package vn.sps.aba.dds.common.types.ws.padasa.matchmakerdaten.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentCode">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="18"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="LastUpdate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="REC_Title" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="REC_Name1" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="REC_Name2" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="REC_Name3" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="REC_Street" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="REC_POBox" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="35"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="REC_ZIP" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="6"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="REC_City" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="REC_Country" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="REC_FreeText" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="250"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="REC_SendeId" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="35"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Envelope_Version" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="3"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="VG_ProcessedTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="KDP_PersTyp" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="KDP_AMPStatus" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="KDP_Hauskey" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="KDP_Id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="KDP_Id_Confidence" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="ParcelHauskey" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="MatchmakerResponseCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Dienstleistung" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="12"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Kundennummer" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="15"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CountryCode" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Ort" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Streetnumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Anrede" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/>
 *         &lt;element name="Name" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Vorname" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Namezusatz" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="80"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Firmenname" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="100"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="PLZ" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="6"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Strasse" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="100"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Hausnummer" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Hausnummerzusatz" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Postfach" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="VaeAddressType" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="VAMTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="FailedVAMExports" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="120"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "identCode",
    "lastUpdate",
    "recTitle",
    "recName1",
    "recName2",
    "recName3",
    "recStreet",
    "recpoBox",
    "reczip",
    "recCity",
    "recCountry",
    "recFreeText",
    "recSendeId",
    "envelopeVersion",
    "vgProcessedTime",
    "kdpPersTyp",
    "kdpampStatus",
    "kdpHauskey",
    "kdpId",
    "kdpIdConfidence",
    "parcelHauskey",
    "matchmakerResponseCode",
    "dienstleistung",
    "kundennummer",
    "countryCode",
    "ort",
    "streetnumber",
    "anrede",
    "name",
    "vorname",
    "namezusatz",
    "firmenname",
    "plz",
    "strasse",
    "hausnummer",
    "hausnummerzusatz",
    "postfach",
    "vaeAddressType",
    "vamTimestamp",
    "failedVAMExports"
})
@XmlRootElement(name = "MatchMakerRequest", namespace = "http://xmlns.oracle.com/padasadatenrequest")
public class MatchMakerRequest {

    @XmlElement(name = "IdentCode", namespace = "http://xmlns.oracle.com/padasadatenrequest", required = true, nillable = true)
    protected String identCode;
    @XmlElement(name = "LastUpdate", namespace = "http://xmlns.oracle.com/padasadatenrequest", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastUpdate;
    @XmlElementRef(name = "REC_Title", namespace = "http://xmlns.oracle.com/padasadatenrequest", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recTitle;
    @XmlElementRef(name = "REC_Name1", namespace = "http://xmlns.oracle.com/padasadatenrequest", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recName1;
    @XmlElementRef(name = "REC_Name2", namespace = "http://xmlns.oracle.com/padasadatenrequest", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recName2;
    @XmlElementRef(name = "REC_Name3", namespace = "http://xmlns.oracle.com/padasadatenrequest", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recName3;
    @XmlElementRef(name = "REC_Street", namespace = "http://xmlns.oracle.com/padasadatenrequest", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recStreet;
    @XmlElementRef(name = "REC_POBox", namespace = "http://xmlns.oracle.com/padasadatenrequest", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recpoBox;
    @XmlElementRef(name = "REC_ZIP", namespace = "http://xmlns.oracle.com/padasadatenrequest", type = JAXBElement.class, required = false)
    protected JAXBElement<String> reczip;
    @XmlElementRef(name = "REC_City", namespace = "http://xmlns.oracle.com/padasadatenrequest", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recCity;
    @XmlElementRef(name = "REC_Country", namespace = "http://xmlns.oracle.com/padasadatenrequest", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recCountry;
    @XmlElementRef(name = "REC_FreeText", namespace = "http://xmlns.oracle.com/padasadatenrequest", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recFreeText;
    @XmlElementRef(name = "REC_SendeId", namespace = "http://xmlns.oracle.com/padasadatenrequest", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recSendeId;
    @XmlElementRef(name = "Envelope_Version", namespace = "http://xmlns.oracle.com/padasadatenrequest", type = JAXBElement.class, required = false)
    protected JAXBElement<String> envelopeVersion;
    @XmlElement(name = "VG_ProcessedTime", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar vgProcessedTime;
    @XmlElement(name = "KDP_PersTyp", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected Integer kdpPersTyp;
    @XmlElement(name = "KDP_AMPStatus", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected Integer kdpampStatus;
    @XmlElement(name = "KDP_Hauskey", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected Integer kdpHauskey;
    @XmlElement(name = "KDP_Id", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected Integer kdpId;
    @XmlElement(name = "KDP_Id_Confidence", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected Integer kdpIdConfidence;
    @XmlElement(name = "ParcelHauskey", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected Integer parcelHauskey;
    @XmlElement(name = "MatchmakerResponseCode", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected Integer matchmakerResponseCode;
    @XmlElement(name = "Dienstleistung", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String dienstleistung;
    @XmlElement(name = "Kundennummer", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String kundennummer;
    @XmlElement(name = "CountryCode", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String countryCode;
    @XmlElement(name = "Ort", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String ort;
    @XmlElement(name = "Streetnumber", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String streetnumber;
    @XmlElement(name = "Anrede", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected Object anrede;
    @XmlElement(name = "Name", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String name;
    @XmlElement(name = "Vorname", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String vorname;
    @XmlElement(name = "Namezusatz", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String namezusatz;
    @XmlElement(name = "Firmenname", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String firmenname;
    @XmlElement(name = "PLZ", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String plz;
    @XmlElement(name = "Strasse", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String strasse;
    @XmlElement(name = "Hausnummer", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected Integer hausnummer;
    @XmlElement(name = "Hausnummerzusatz", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String hausnummerzusatz;
    @XmlElement(name = "Postfach", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String postfach;
    @XmlElement(name = "VaeAddressType", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected Integer vaeAddressType;
    @XmlElement(name = "VAMTimestamp", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar vamTimestamp;
    @XmlElement(name = "FailedVAMExports", namespace = "http://xmlns.oracle.com/padasadatenrequest")
    protected String failedVAMExports;

    /**
     * Gets the value of the identCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentCode() {
        return identCode;
    }

    /**
     * Sets the value of the identCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentCode(String value) {
        this.identCode = value;
    }

    /**
     * Gets the value of the lastUpdate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUpdate() {
        return lastUpdate;
    }

    /**
     * Sets the value of the lastUpdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUpdate(XMLGregorianCalendar value) {
        this.lastUpdate = value;
    }

    /**
     * Gets the value of the recTitle property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRECTitle() {
        return recTitle;
    }

    /**
     * Sets the value of the recTitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRECTitle(JAXBElement<String> value) {
        this.recTitle = value;
    }

    /**
     * Gets the value of the recName1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRECName1() {
        return recName1;
    }

    /**
     * Sets the value of the recName1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRECName1(JAXBElement<String> value) {
        this.recName1 = value;
    }

    /**
     * Gets the value of the recName2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRECName2() {
        return recName2;
    }

    /**
     * Sets the value of the recName2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRECName2(JAXBElement<String> value) {
        this.recName2 = value;
    }

    /**
     * Gets the value of the recName3 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRECName3() {
        return recName3;
    }

    /**
     * Sets the value of the recName3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRECName3(JAXBElement<String> value) {
        this.recName3 = value;
    }

    /**
     * Gets the value of the recStreet property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRECStreet() {
        return recStreet;
    }

    /**
     * Sets the value of the recStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRECStreet(JAXBElement<String> value) {
        this.recStreet = value;
    }

    /**
     * Gets the value of the recpoBox property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRECPOBox() {
        return recpoBox;
    }

    /**
     * Sets the value of the recpoBox property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRECPOBox(JAXBElement<String> value) {
        this.recpoBox = value;
    }

    /**
     * Gets the value of the reczip property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRECZIP() {
        return reczip;
    }

    /**
     * Sets the value of the reczip property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRECZIP(JAXBElement<String> value) {
        this.reczip = value;
    }

    /**
     * Gets the value of the recCity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRECCity() {
        return recCity;
    }

    /**
     * Sets the value of the recCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRECCity(JAXBElement<String> value) {
        this.recCity = value;
    }

    /**
     * Gets the value of the recCountry property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRECCountry() {
        return recCountry;
    }

    /**
     * Sets the value of the recCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRECCountry(JAXBElement<String> value) {
        this.recCountry = value;
    }

    /**
     * Gets the value of the recFreeText property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRECFreeText() {
        return recFreeText;
    }

    /**
     * Sets the value of the recFreeText property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRECFreeText(JAXBElement<String> value) {
        this.recFreeText = value;
    }

    /**
     * Gets the value of the recSendeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRECSendeId() {
        return recSendeId;
    }

    /**
     * Sets the value of the recSendeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRECSendeId(JAXBElement<String> value) {
        this.recSendeId = value;
    }

    /**
     * Gets the value of the envelopeVersion property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEnvelopeVersion() {
        return envelopeVersion;
    }

    /**
     * Sets the value of the envelopeVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEnvelopeVersion(JAXBElement<String> value) {
        this.envelopeVersion = value;
    }

    /**
     * Gets the value of the vgProcessedTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getVGProcessedTime() {
        return vgProcessedTime;
    }

    /**
     * Sets the value of the vgProcessedTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setVGProcessedTime(XMLGregorianCalendar value) {
        this.vgProcessedTime = value;
    }

    /**
     * Gets the value of the kdpPersTyp property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getKDPPersTyp() {
        return kdpPersTyp;
    }

    /**
     * Sets the value of the kdpPersTyp property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setKDPPersTyp(Integer value) {
        this.kdpPersTyp = value;
    }

    /**
     * Gets the value of the kdpampStatus property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getKDPAMPStatus() {
        return kdpampStatus;
    }

    /**
     * Sets the value of the kdpampStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setKDPAMPStatus(Integer value) {
        this.kdpampStatus = value;
    }

    /**
     * Gets the value of the kdpHauskey property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getKDPHauskey() {
        return kdpHauskey;
    }

    /**
     * Sets the value of the kdpHauskey property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setKDPHauskey(Integer value) {
        this.kdpHauskey = value;
    }

    /**
     * Gets the value of the kdpId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getKDPId() {
        return kdpId;
    }

    /**
     * Sets the value of the kdpId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setKDPId(Integer value) {
        this.kdpId = value;
    }

    /**
     * Gets the value of the kdpIdConfidence property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getKDPIdConfidence() {
        return kdpIdConfidence;
    }

    /**
     * Sets the value of the kdpIdConfidence property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setKDPIdConfidence(Integer value) {
        this.kdpIdConfidence = value;
    }

    /**
     * Gets the value of the parcelHauskey property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getParcelHauskey() {
        return parcelHauskey;
    }

    /**
     * Sets the value of the parcelHauskey property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setParcelHauskey(Integer value) {
        this.parcelHauskey = value;
    }

    /**
     * Gets the value of the matchmakerResponseCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMatchmakerResponseCode() {
        return matchmakerResponseCode;
    }

    /**
     * Sets the value of the matchmakerResponseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMatchmakerResponseCode(Integer value) {
        this.matchmakerResponseCode = value;
    }

    /**
     * Gets the value of the dienstleistung property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDienstleistung() {
        return dienstleistung;
    }

    /**
     * Sets the value of the dienstleistung property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDienstleistung(String value) {
        this.dienstleistung = value;
    }

    /**
     * Gets the value of the kundennummer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKundennummer() {
        return kundennummer;
    }

    /**
     * Sets the value of the kundennummer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKundennummer(String value) {
        this.kundennummer = value;
    }

    /**
     * Gets the value of the countryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Sets the value of the countryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCode(String value) {
        this.countryCode = value;
    }

    /**
     * Gets the value of the ort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrt() {
        return ort;
    }

    /**
     * Sets the value of the ort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrt(String value) {
        this.ort = value;
    }

    /**
     * Gets the value of the streetnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreetnumber() {
        return streetnumber;
    }

    /**
     * Sets the value of the streetnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreetnumber(String value) {
        this.streetnumber = value;
    }

    /**
     * Gets the value of the anrede property.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getAnrede() {
        return anrede;
    }

    /**
     * Sets the value of the anrede property.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setAnrede(Object value) {
        this.anrede = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the vorname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVorname() {
        return vorname;
    }

    /**
     * Sets the value of the vorname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVorname(String value) {
        this.vorname = value;
    }

    /**
     * Gets the value of the namezusatz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNamezusatz() {
        return namezusatz;
    }

    /**
     * Sets the value of the namezusatz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNamezusatz(String value) {
        this.namezusatz = value;
    }

    /**
     * Gets the value of the firmenname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirmenname() {
        return firmenname;
    }

    /**
     * Sets the value of the firmenname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirmenname(String value) {
        this.firmenname = value;
    }

    /**
     * Gets the value of the plz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPLZ() {
        return plz;
    }

    /**
     * Sets the value of the plz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPLZ(String value) {
        this.plz = value;
    }

    /**
     * Gets the value of the strasse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrasse() {
        return strasse;
    }

    /**
     * Sets the value of the strasse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrasse(String value) {
        this.strasse = value;
    }

    /**
     * Gets the value of the hausnummer property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getHausnummer() {
        return hausnummer;
    }

    /**
     * Sets the value of the hausnummer property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setHausnummer(Integer value) {
        this.hausnummer = value;
    }

    /**
     * Gets the value of the hausnummerzusatz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHausnummerzusatz() {
        return hausnummerzusatz;
    }

    /**
     * Sets the value of the hausnummerzusatz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHausnummerzusatz(String value) {
        this.hausnummerzusatz = value;
    }

    /**
     * Gets the value of the postfach property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostfach() {
        return postfach;
    }

    /**
     * Sets the value of the postfach property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostfach(String value) {
        this.postfach = value;
    }

    /**
     * Gets the value of the vaeAddressType property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getVaeAddressType() {
        return vaeAddressType;
    }

    /**
     * Sets the value of the vaeAddressType property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setVaeAddressType(Integer value) {
        this.vaeAddressType = value;
    }

    /**
     * Gets the value of the vamTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getVAMTimestamp() {
        return vamTimestamp;
    }

    /**
     * Sets the value of the vamTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setVAMTimestamp(XMLGregorianCalendar value) {
        this.vamTimestamp = value;
    }

    /**
     * Gets the value of the failedVAMExports property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFailedVAMExports() {
        return failedVAMExports;
    }

    /**
     * Sets the value of the failedVAMExports property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFailedVAMExports(String value) {
        this.failedVAMExports = value;
    }

}
