
package vn.sps.aba.dds.common.types.ws.dpmb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlList;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for VolleAdresse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VolleAdresse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Fields" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}AddressFields"/>
 *         &lt;element name="KdpId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ParcelAdrAmpStatus" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}eAmpStatus" minOccurs="0"/>
 *         &lt;element name="ParcelAdrType" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}eCaptureAddressType"/>
 *         &lt;element name="ParcelHausKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ParcelStreetNr" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="PersStatus" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}ePersStatus" minOccurs="0"/>
 *         &lt;element name="PersType" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}ePersType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VolleAdresse", propOrder = {
    "fields",
    "kdpId",
    "parcelAdrAmpStatus",
    "parcelAdrType",
    "parcelHausKey",
    "parcelStreetNr",
    "persStatus",
    "persType"
})
public class VolleAdresse {

    @XmlElement(name = "Fields", required = true, nillable = true)
    protected AddressFields fields;
    @XmlElement(name = "KdpId")
    protected String kdpId;
    @XmlElement(name = "ParcelAdrAmpStatus")
    @XmlSchemaType(name = "string")
    protected EAmpStatus parcelAdrAmpStatus;
    @XmlList
    @XmlElement(name = "ParcelAdrType", required = true)
    @XmlSchemaType(name = "anySimpleType")
    protected List<String> parcelAdrType;
    @XmlElement(name = "ParcelHausKey")
    protected String parcelHausKey;
    @XmlElement(name = "ParcelStreetNr")
    protected Integer parcelStreetNr;
    @XmlElement(name = "PersStatus")
    @XmlSchemaType(name = "string")
    protected EPersStatus persStatus;
    @XmlElement(name = "PersType")
    @XmlSchemaType(name = "string")
    protected EPersType persType;

    /**
     * Gets the value of the fields property.
     * 
     * @return
     *     possible object is
     *     {@link AddressFields }
     *     
     */
    public AddressFields getFields() {
        return fields;
    }

    /**
     * Sets the value of the fields property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressFields }
     *     
     */
    public void setFields(AddressFields value) {
        this.fields = value;
    }

    /**
     * Gets the value of the kdpId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKdpId() {
        return kdpId;
    }

    /**
     * Sets the value of the kdpId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKdpId(String value) {
        this.kdpId = value;
    }

    /**
     * Gets the value of the parcelAdrAmpStatus property.
     * 
     * @return
     *     possible object is
     *     {@link EAmpStatus }
     *     
     */
    public EAmpStatus getParcelAdrAmpStatus() {
        return parcelAdrAmpStatus;
    }

    /**
     * Sets the value of the parcelAdrAmpStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link EAmpStatus }
     *     
     */
    public void setParcelAdrAmpStatus(EAmpStatus value) {
        this.parcelAdrAmpStatus = value;
    }

    /**
     * Gets the value of the parcelAdrType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the parcelAdrType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParcelAdrType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getParcelAdrType() {
        if (parcelAdrType == null) {
            parcelAdrType = new ArrayList<String>();
        }
        return this.parcelAdrType;
    }
    
    public List<String> getParcelAdrTypeRaw() {
        return this.parcelAdrType;
    }

    /**
     * Gets the value of the parcelHausKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParcelHausKey() {
        return parcelHausKey;
    }

    /**
     * Sets the value of the parcelHausKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParcelHausKey(String value) {
        this.parcelHausKey = value;
    }

    /**
     * Gets the value of the parcelStreetNr property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getParcelStreetNr() {
        return parcelStreetNr;
    }

    /**
     * Sets the value of the parcelStreetNr property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setParcelStreetNr(Integer value) {
        this.parcelStreetNr = value;
    }

    /**
     * Gets the value of the persStatus property.
     * 
     * @return
     *     possible object is
     *     {@link EPersStatus }
     *     
     */
    public EPersStatus getPersStatus() {
        return persStatus;
    }

    /**
     * Sets the value of the persStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link EPersStatus }
     *     
     */
    public void setPersStatus(EPersStatus value) {
        this.persStatus = value;
    }

    /**
     * Gets the value of the persType property.
     * 
     * @return
     *     possible object is
     *     {@link EPersType }
     *     
     */
    public EPersType getPersType() {
        return persType;
    }

    /**
     * Sets the value of the persType property.
     * 
     * @param value
     *     allowed object is
     *     {@link EPersType }
     *     
     */
    public void setPersType(EPersType value) {
        this.persType = value;
    }

}
