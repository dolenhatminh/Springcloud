/*
 * Class: IExternalTransfer
 *
 * Created on Oct 18, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.sender;

import java.util.concurrent.Future;

/**
 * The Interface IExternalSender.
 *
 * @param <T> the generic type
 */
public interface IExternalSender<T> {

    /**
     * Gets the sender name.
     *
     * @return the sender name
     */
    String getSenderName();

    /**
     * Gets the task.
     *
     * @param key the key
     * @return the task
     */
    @SuppressWarnings("rawtypes")
    Future getTask(String key);

    /**
     * Rubmit item.
     *
     * @param obj the obj
     */
    void rubmitItem(T obj);

    /**
     * Submit item.
     *
     * @param obj the obj
     */
    void submitItem(T obj);
}
