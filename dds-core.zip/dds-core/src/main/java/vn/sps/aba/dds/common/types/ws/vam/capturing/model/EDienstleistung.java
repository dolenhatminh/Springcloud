
package vn.sps.aba.dds.common.types.ws.vam.capturing.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for eDienstleistung.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="eDienstleistung">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Pickpost"/>
 *     &lt;enumeration value="MyPost24"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "eDienstleistung", namespace = "http://schemas.datacontract.org/2004/07/Ch.Post.PL.Vae.Vam.Domain.Enumerations")
@XmlEnum
public enum EDienstleistung {

    @XmlEnumValue("Pickpost")
    PICKPOST("Pickpost"),
    @XmlEnumValue("MyPost24")
    MY_POST_24("MyPost24");
    private final String value;

    EDienstleistung(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static EDienstleistung fromValue(String v) {
        for (EDienstleistung c: EDienstleistung.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
