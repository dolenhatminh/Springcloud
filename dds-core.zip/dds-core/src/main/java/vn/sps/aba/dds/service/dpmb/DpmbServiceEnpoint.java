/*
 * Class: DpmServiceEnpoint
 *
 * Created on Jul 22, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.service.dpmb;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import vn.sps.aba.dds.common.constant.DDSConstant.Namespace;
import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.message.Description;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureResult;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultIn;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultIn.CaptureResultRecords;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultRecord;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultResponse;
import vn.sps.aba.dds.common.types.ws.dpmb.ObjectFactory;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.service.DpmbServiceConfiguration;
import vn.sps.aba.dds.config.task.validator.TaskReceiverInfoRecepton;
import vn.sps.aba.dds.processor.receiver.ReceiverProcessingManager;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;

/**
 * The Class DpmServiceEnpoint.
 */
//@Profile(Profiles.DPMB)
//@Endpoint
public class DpmbServiceEnpoint {

    /**
     * The Class DelegateReceiverInfoValidator.
     */
    private class DelegateReceiverInfoValidator extends RecursiveTask<List<ReceiverInfoWrapper>> {

        /** The Constant serialVersionUID. */
        private static final long serialVersionUID = -3657239112021250391L;

        /** The capture result records. */
        private CaptureResultRecords captureResultRecords;

        /**
         * {@inheritDoc}
         *
         * @see java.util.concurrent.RecursiveTask#compute()
         */
        @Override
        protected List<ReceiverInfoWrapper> compute() {

            final List<ReceiverInfoWrapper> ret = new ArrayList<>();
            final List<ReceiverInfoValidator> validators = new ArrayList<>();

            for (final CaptureResultRecord record : this.captureResultRecords.getCaptureResultRecord()) {
                validators.add(new ReceiverInfoValidator(record, DpmbServiceEnpoint.this.serviceConfiguration));
            }
            ForkJoinTask.invokeAll(validators);

            for (final ReceiverInfoValidator receiverInfoValidator : validators) {
                ret.add(receiverInfoValidator.getRawResult());
            }

            return ret;
        }

        /**
         * Sets the capture result records.
         *
         * @param captureResultRecords the new capture result records
         */
        public void setCaptureResultRecords(final CaptureResultRecords captureResultRecords) {
            this.captureResultRecords = captureResultRecords;
        }

    }

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DpmbServiceEnpoint.class);

    /** The process manager. */
    @Autowired
    private ReceiverProcessingManager processManager;

    /** The receiver info DAO. */
    @Autowired
    private IReceiverInfoCacheDao receiverInfoDao;

    /** The reception task. */
    @Autowired
    private TaskReceiverInfoRecepton receptionTask;

    /** The service configuration. */
    @Autowired
    private DpmbServiceConfiguration serviceConfiguration;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.types.ws.vam.capturing.model.ICaptureResultService#captureResult(vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultIn)
     */
    @PayloadRoot(namespace = Namespace.E190_NAMESPACE, localPart = "CaptureResult")
    public @ResponsePayload CaptureResultResponse captureResult(@RequestPayload final CaptureResult captureResult) {

        Response response = this.serviceConfiguration.successful();

        final boolean isInvalidArgumentError = (captureResult == null) || (captureResult.getRequest() == null);

        final Description description = new Description();
        final ObjectFactory objectFactory = this.serviceConfiguration.getObjectFactory();
        final long received = DiscoWallClock.milli();
        try {
            if (!isInvalidArgumentError) {

                final CaptureResultIn request = captureResult.getRequest();
                if (this.valdiateRequestIn(request, description)) {

                    final CaptureResultRecords captureResultRecords = request.getCaptureResultRecords();
                    final DelegateReceiverInfoValidator delegateValidator = new DelegateReceiverInfoValidator();
                    delegateValidator.setCaptureResultRecords(captureResultRecords);
                    this.receptionTask.getValidatorPool().invoke(delegateValidator);

                    final List<ReceiverInfoWrapper> wrappers = delegateValidator.getRawResult();

                    this.processTheValidOnes(received, request, wrappers, description);

                }
                else {
                    final String key = StringUtil.newUuidString();
                    final ReceiverInfo receiverInfo = new ReceiverInfo(key, request.getCallerId(), request.getVersion(), received);
                    receiverInfo.setState(ReceiverState.REJECTED);
                    this.receiverInfoDao.put(key, receiverInfo);
                }
                if (description.getMessages().size() > 0) {
                    response = this.serviceConfiguration.invalidCaptureResultRecordsError();
                }
            }
            else {
                final String key = StringUtil.newUuidString();
                final ReceiverInfo receiverInfo = new ReceiverInfo(key, null, 0, received);
                receiverInfo.setState(ReceiverState.REJECTED);
                this.receiverInfoDao.put(key, receiverInfo);

                response = this.serviceConfiguration.invalidArgumentError();
                LOG.error(response.getCode() + ": Invalid argument error");
            }
        }
        catch (final Exception e) {

            response = this.serviceConfiguration.unexpectedError();
            LOG.error(response.getCode() + ": Error while processing the receiver info data", e);
        }

        return MessageBuilder.buildDPMBResponse(objectFactory, response, description);
    }

    /**
     * Process the valid ones.
     *
     * @param receivedTime the received time
     * @param request the request
     * @param wrappers the wrappers
     * @param description the description
     */
    private void processTheValidOnes(
        final long receivedTime,
        final CaptureResultIn request,
        final List<ReceiverInfoWrapper> wrappers,
        final Description description) {
        for (final ReceiverInfoWrapper wrapper : wrappers) {

            final CaptureResultRecord receiverInfoRecord = wrapper.getReceiverInfo();
            final String identCode = receiverInfoRecord.getIdentcode();

            final String key = StringUtil.newUuidString();
            if (!wrapper.isInValid()) {

                final ReceiverInfo receiverInfo = new ReceiverInfo(request.getCallerId(), request.getVersion(), receiverInfoRecord);

                receiverInfo.setReceived(receivedTime);
                receiverInfo.setKey(key);
                this.receiverInfoDao.put(identCode, receiverInfo);
                this.processManager.submit(receiverInfo);
            }
            else {
                final ReceiverInfo receiverInfo = new ReceiverInfo(key, request.getCallerId(), request.getVersion(), receivedTime);
                receiverInfo.setState(ReceiverState.REJECTED);
                this.receiverInfoDao.put(key, receiverInfo);

                description.getMessages().addAll(wrapper.getCauses());
            }
        }
    }

    /**
     * Valdiate request in.
     *
     * @param request the request
     * @param description the description
     * @return true, if successful
     */
    private boolean valdiateRequestIn(final CaptureResultIn request, final Description description) {

        boolean ret = true;

        if ((request.getCallerId() == null) || !request.getCallerId().matches(this.serviceConfiguration.getCallerIdFormat())) {
            description.addMessage("CallerId must match format " + this.serviceConfiguration.getCallerIdFormat());
        }
        if (request.getVersion() < 1) {
            description.addMessage("Version must be integer greater than 0");
        }
        if ((request.getCaptureResultRecords() == null) || (request.getCaptureResultRecords().getCaptureResultRecord().size() <= 0)) {
            description.addMessage("There is no ReceiverInfo found");
            ret = false;
        }

        return ret;
    }

}
