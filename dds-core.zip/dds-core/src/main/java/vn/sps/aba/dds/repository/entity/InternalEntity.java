/*
 * Class: InternalEntity
 * 
 * Created on Sep 23, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.entity;

/**
 * The Class InternalEntity.
 */
public class InternalEntity {
    
    /** The created. */
    private long created;

    /** The lifespan. */
    private long lifespan;

    /**
     * Gets the created.
     *
     * @return the created
     */
    public long getCreated() {
        return created;
    }

    /**
     * Sets the created.
     *
     * @param created the new created
     */
    public void setCreated(long created) {
        this.created = created;
    }

    /**
     * Gets the lifespan.
     *
     * @return the lifespan
     */
    public long getLifespan() {
        return lifespan;
    }

    /**
     * Sets the lifespan.
     *
     * @param lifespan the new lifespan
     */
    public void setLifespan(long lifespan) {
        this.lifespan = lifespan;
    }
}
