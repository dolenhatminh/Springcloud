/*
 * Class: DdsCacheInfo
 *
 * Created on Oct 24, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.jmx;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

/**
 * The Interface DdsCacheInfo.
 */
@ManagedResource
public interface DdsCacheInfo {

    /**
     * Change expired life span.
     *
     * @param lifespan the lifespan
     */
    @ManagedOperation
    void changeExpiredLifeSpan(long lifespan);

    /**
     * Count entries with minor state.
     *
     * @param minorState the minor state
     * @return the int
     */
    @ManagedOperation
    int countEntriesWithMinorState(final String minorState);

    /**
     * Count entries with state.
     *
     * @param state the state
     * @return the int
     */
    @ManagedOperation
    int countEntriesWithState(String state);

    /**
     * Gets the cache name.
     *
     * @return the cache name
     */
    @ManagedAttribute
    String getCacheName();

    /**
     * Gets the expired life span.
     *
     * @return the expired life span
     */
    @ManagedAttribute
    long getExpiredLifeSpan();
}
