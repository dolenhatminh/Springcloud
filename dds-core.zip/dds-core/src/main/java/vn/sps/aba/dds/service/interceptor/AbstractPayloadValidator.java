/*
 * Class: AbstractPayloadValidator
 *
 * Created on Jun 23, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.interceptor;

import java.io.IOException;

import javax.xml.namespace.QName;
import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.support.PayloadRootUtils;
import org.springframework.ws.soap.server.endpoint.interceptor.PayloadValidatingInterceptor;
import org.springframework.xml.transform.TransformerHelper;
import org.xml.sax.SAXException;

import vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration;

/**
 * The Class AbstractPayloadValidator.<br>
 * This will handle the request if the the request matches the namespace
 */
public abstract class AbstractPayloadValidator extends PayloadValidatingInterceptor {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(AbstractPayloadValidator.class);

    /** The configuration. */
    private final AbstractSoapWsConfiguration configuration;

    /**
     * Constructs a new <tt>AbstractPayloadValidator</tt>.
     *
     * @param configuration
     *            the configuration
     */
    public AbstractPayloadValidator(final AbstractSoapWsConfiguration configuration) {

        this.configuration = configuration;
        this.setValidateRequest(configuration.isValidateRequest());
        this.setValidateResponse(configuration.isValidateResponse());
        this.setAddValidationErrorDetail(configuration.isAddValidationErrorDetail());
        this.setXsdSchemaCollection(configuration.getXsdSchemas());
    }

    /**
     * Gets the configuration.
     *
     * @return Returns the configuration.
     */
    protected AbstractSoapWsConfiguration getConfiguration() {
        return this.configuration;
    }

    /**
     * Gets the configuration.
     *
     * @param <T> the generic type
     * @param clazz the clazz
     * @return the configuration
     */
    @SuppressWarnings("unchecked")
    protected <T> T getConfiguration(final Class<T> clazz) {
        return (T) this.configuration;
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.ws.server.endpoint.interceptor.AbstractValidatingInterceptor#handleRequest(org.springframework.ws.context.MessageContext,
     *      java.lang.Object)
     */
    @Override
    public boolean handleRequest(final MessageContext messageContext, final Object endpoint) throws IOException, SAXException, TransformerException {

        boolean ret = false;

        try {

            if (this.getConfiguration().isValidateRequest()) {

                final WebServiceMessage request = messageContext.getRequest();
                final QName payloadRootName = PayloadRootUtils.getPayloadRootQName(request.getPayloadSource(), new TransformerHelper());

                if ((payloadRootName == null) || !this.getConfiguration().getNamespaceURI().equals(payloadRootName.getNamespaceURI())) {
                    ret = true;
                }
                else {
                    ret = super.handleRequest(messageContext, endpoint);
                }
            }
            else {
                ret = true;
            }
        }
        catch (final TransformerException e) {
            LOG.error(e.getMessage(), e);
            ret = false;
        }

        return ret;
    }

}
