
package vn.sps.aba.dds.common.types.ws.dpmb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CaptureResultRecord complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CaptureResultRecord">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AdresseErfassung" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}AdresseErfassung"/>
 *         &lt;element name="CaptureInfo" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}CaptureInfo"/>
 *         &lt;element name="Identcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ParcelData" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}ParcelData" minOccurs="0"/>
 *         &lt;element name="SenderId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Timestamps" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}Timestamps"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CaptureResultRecord", propOrder = {
    "adresseErfassung",
    "captureInfo",
    "identcode",
    "parcelData",
    "senderId",
    "timestamps"
})
public class CaptureResultRecord {

    @XmlElement(name = "AdresseErfassung", required = true, nillable = true)
    protected AdresseErfassung adresseErfassung;
    @XmlElement(name = "CaptureInfo", required = true, nillable = true)
    protected CaptureInfo captureInfo;
    @XmlElement(name = "Identcode", required = true, nillable = true)
    protected String identcode;
    @XmlElement(name = "ParcelData")
    protected ParcelData parcelData;
    @XmlElement(name = "SenderId")
    protected Integer senderId;
    @XmlElement(name = "Timestamps", required = true, nillable = true)
    protected Timestamps timestamps;

    /**
     * Gets the value of the adresseErfassung property.
     * 
     * @return
     *     possible object is
     *     {@link AdresseErfassung }
     *     
     */
    public AdresseErfassung getAdresseErfassung() {
        return adresseErfassung;
    }

    /**
     * Sets the value of the adresseErfassung property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdresseErfassung }
     *     
     */
    public void setAdresseErfassung(AdresseErfassung value) {
        this.adresseErfassung = value;
    }

    /**
     * Gets the value of the captureInfo property.
     * 
     * @return
     *     possible object is
     *     {@link CaptureInfo }
     *     
     */
    public CaptureInfo getCaptureInfo() {
        return captureInfo;
    }

    /**
     * Sets the value of the captureInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CaptureInfo }
     *     
     */
    public void setCaptureInfo(CaptureInfo value) {
        this.captureInfo = value;
    }

    /**
     * Gets the value of the identcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentcode() {
        return identcode;
    }

    /**
     * Sets the value of the identcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentcode(String value) {
        this.identcode = value;
    }

    /**
     * Gets the value of the parcelData property.
     * 
     * @return
     *     possible object is
     *     {@link ParcelData }
     *     
     */
    public ParcelData getParcelData() {
        return parcelData;
    }

    /**
     * Sets the value of the parcelData property.
     * 
     * @param value
     *     allowed object is
     *     {@link ParcelData }
     *     
     */
    public void setParcelData(ParcelData value) {
        this.parcelData = value;
    }

    /**
     * Gets the value of the senderId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSenderId() {
        return senderId;
    }

    /**
     * Sets the value of the senderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSenderId(Integer value) {
        this.senderId = value;
    }

    /**
     * Gets the value of the timestamps property.
     * 
     * @return
     *     possible object is
     *     {@link Timestamps }
     *     
     */
    public Timestamps getTimestamps() {
        return timestamps;
    }

    /**
     * Sets the value of the timestamps property.
     * 
     * @param value
     *     allowed object is
     *     {@link Timestamps }
     *     
     */
    public void setTimestamps(Timestamps value) {
        this.timestamps = value;
    }

}
