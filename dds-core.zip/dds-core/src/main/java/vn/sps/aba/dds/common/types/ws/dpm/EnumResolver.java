/*
 * Class: EnumResolver
 *
 * Created on Jul 23, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.ws.dpm;

import java.util.HashMap;
import java.util.Map;

import vn.sps.aba.dds.common.types.ws.dpm.model.AmpStatusType;
import vn.sps.aba.dds.common.types.ws.dpm.model.CaptureResultCodeType;
import vn.sps.aba.dds.common.types.ws.dpm.model.DienstleistungType;
import vn.sps.aba.dds.common.types.ws.dpm.model.PersStatusType;
import vn.sps.aba.dds.common.types.ws.dpm.model.PersTypeType;

/**
 * The Class EnumResolver.
 */
public final class EnumResolver {

    /** The amp statuses. */
    private static Map<String, AmpStatusType> ampStatuses = new HashMap<>();

    /** The capture result codes. */
    private static Map<String, CaptureResultCodeType> captureResultCodes = new HashMap<>();

    /** The dienstleistungs. */
    private static Map<String, DienstleistungType> dienstleistungs = new HashMap<>();

    /** The pers statuses. */
    private static Map<String, PersStatusType> persStatuses = new HashMap<>();

    /** The pers types. */
    private static Map<String, PersTypeType> persTypes = new HashMap<>();

    static {

        for (final AmpStatusType ampStatus : AmpStatusType.values()) {

            ampStatuses.put(ampStatus.value(), ampStatus);
        }

        for (final CaptureResultCodeType captureResultCode : CaptureResultCodeType.values()) {

            captureResultCodes.put(captureResultCode.value(), captureResultCode);
        }

        for (final DienstleistungType dienstleistungType : DienstleistungType.values()) {

            dienstleistungs.put(dienstleistungType.value(), dienstleistungType);
        }

        for (final PersStatusType persStatusType : PersStatusType.values()) {

            persStatuses.put(persStatusType.value(), persStatusType);
        }

        for (final PersTypeType persTypeType : PersTypeType.values()) {

            persTypes.put(persTypeType.value(), persTypeType);
        }

    }

    /**
     * Resolve amp status.
     *
     * @param value the value
     * @return the amp status type
     */
    public static AmpStatusType resolveAmpStatus(final String value) {

        return ampStatuses.get(value);
    }

    /**
     * Resolve capture result code.
     *
     * @param value the value
     * @return the capture result code type
     */
    public static CaptureResultCodeType resolveCaptureResultCode(final String value) {

        return captureResultCodes.get(value);
    }

    /**
     * Resolve dienstleistung.
     *
     * @param value the value
     * @return the dienstleistung type
     */
    public static DienstleistungType resolveDienstleistung(final String value) {

        return dienstleistungs.get(value);
    }

    /**
     * Resolve pers status.
     *
     * @param value the value
     * @return the pers status type
     */
    public static PersStatusType resolvePersStatus(final String value) {

        return persStatuses.get(value);
    }

    /**
     * Resolve pers type.
     *
     * @param value the value
     * @return the pers type type
     */
    public static PersTypeType resolvePersType(final String value) {

        return persTypes.get(value);
    }

    /**
     * Instantiates a new enum resolver.
     */
    private EnumResolver() {
    }
}
