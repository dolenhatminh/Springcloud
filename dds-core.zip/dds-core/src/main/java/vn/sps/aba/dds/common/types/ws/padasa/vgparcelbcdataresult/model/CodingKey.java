
package vn.sps.aba.dds.common.types.ws.padasa.vgparcelbcdataresult.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.NormalizedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for codingKey complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="codingKey">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="CodingDate">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}normalizedString">
 *             &lt;minLength value="8"/>
 *             &lt;maxLength value="8"/>
 *             &lt;pattern value="[0-9]{8}"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="CodingSiteID">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}normalizedString">
 *             &lt;minLength value="6"/>
 *             &lt;maxLength value="6"/>
 *             &lt;pattern value="[0-9]{6}"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="ProducerID">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}normalizedString">
 *             &lt;minLength value="4"/>
 *             &lt;maxLength value="4"/>
 *             &lt;pattern value="[0-9]{4}"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="SequenceNumber">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}normalizedString">
 *             &lt;minLength value="7"/>
 *             &lt;maxLength value="7"/>
 *             &lt;pattern value="[0-9]{7}"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "codingKey")
public class CodingKey {

    @XmlAttribute(name = "CodingDate")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String codingDate;
    @XmlAttribute(name = "CodingSiteID")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String codingSiteID;
    @XmlAttribute(name = "ProducerID")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String producerID;
    @XmlAttribute(name = "SequenceNumber")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String sequenceNumber;

    /**
     * Gets the value of the codingDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodingDate() {
        return codingDate;
    }

    /**
     * Sets the value of the codingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodingDate(String value) {
        this.codingDate = value;
    }

    /**
     * Gets the value of the codingSiteID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodingSiteID() {
        return codingSiteID;
    }

    /**
     * Sets the value of the codingSiteID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodingSiteID(String value) {
        this.codingSiteID = value;
    }

    /**
     * Gets the value of the producerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProducerID() {
        return producerID;
    }

    /**
     * Sets the value of the producerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProducerID(String value) {
        this.producerID = value;
    }

    /**
     * Gets the value of the sequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSequenceNumber() {
        return sequenceNumber;
    }

    /**
     * Sets the value of the sequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSequenceNumber(String value) {
        this.sequenceNumber = value;
    }

}
