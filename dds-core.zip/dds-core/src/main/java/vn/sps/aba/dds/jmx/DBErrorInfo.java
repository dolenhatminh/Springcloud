/*
 * Class: DBErrorInfo
 *
 * Created on Nov 16, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.jmx;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

/**
 * The Interface DBErrorInfo.
 */
@ManagedResource
public interface DBErrorInfo {

    /**
     * Empty error.
     *
     * @return the int
     */
    @ManagedOperation
    int emptyError();

    /**
     * Gets the number of db error.
     *
     * @return the number of db error
     */
    @ManagedAttribute
    int getNumberOfDBError();

    /**
     * List error key.
     *
     * @return the string[]
     */
    @ManagedOperation
    String[] listErrorKey();
}
