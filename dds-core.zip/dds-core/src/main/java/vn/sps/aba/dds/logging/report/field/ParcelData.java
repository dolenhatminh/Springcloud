package vn.sps.aba.dds.logging.report.field;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * One of ReceiverInfoReport's Fields
 * Class ParcelData
 */
public class ParcelData implements Serializable{

	 /** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8368024209502864315L;

	/** The acs timestamp. */
	private String acsTimestamp;

	/** The destination station. */
	private String destinationStation;

	/** The par pic id. */
	private String parPicId;

	/** The source station. */
	private String sourceStation;

	/** The vcs case. */
	private String vcsCase;

	/** The zusatz leistungen. */
	private ZusatzLeistungen zusatzLeistungen;

	/**
	 * One of ReceiverInfoReport's Fields
	 * Parse from vn.sps.aba.dds.common.model.receiver.ParcelData
	 * @param ParcelData
	 */
	public ParcelData(vn.sps.aba.dds.common.model.receiver.ParcelData parcelData) {
		if (parcelData != null) {
			this.acsTimestamp = parcelData.getAcsTimestamp();
			this.destinationStation = parcelData.getDestinationStation();
			this.parPicId = parcelData.getParPicId();
			this.sourceStation = parcelData.getSourceStation();
			this.vcsCase = parcelData.getVcsCase();
			this.zusatzLeistungen = new ZusatzLeistungen(parcelData.getZusatzLeistungen());
		}
	}

	/**
	 * @return the acsTimestamp
	 */
	public String getAcsTimestamp() {
		return acsTimestamp;
	}

	/**
	 * @return the destinationStation
	 */
	public String getDestinationStation() {
		return destinationStation;
	}

	/**
	 * @return the parPicId
	 */
	public String getParPicId() {
		return parPicId;
	}

	/**
	 * @return the sourceStation
	 */
	public String getSourceStation() {
		return sourceStation;
	}

	/**
	 * @return the vcsCase
	 */
	public String getVcsCase() {
		return vcsCase;
	}

	/**
	 * @return the zusatzLeistungen
	 */
	public ZusatzLeistungen getZusatzLeistungen() {
		return zusatzLeistungen;
	}
	
	/**
	 * One of ParcelData's Fields.
	 * Inner Class ZusatzLeistungen
	 */
	private class ZusatzLeistungen {

		/**	List produktZusatzLeisten */
		private List<String> produktZusatzLeistung = new ArrayList<>();

		/**
		 * @param produktZusatzLeistung
		 */
		public ZusatzLeistungen(List<String> produktZusatzLeistung) {
			this.produktZusatzLeistung = produktZusatzLeistung;
		}

		/**
		 * @return the produktZusatzLeistung
		 */
		public List<String> getProduktZusatzLeistung() {
			return produktZusatzLeistung;
		}

	}
}
