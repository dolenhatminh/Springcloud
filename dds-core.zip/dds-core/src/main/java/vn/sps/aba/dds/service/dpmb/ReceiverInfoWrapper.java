/*
 * Class: ValidationResult
 *
 * Created on Aug 1, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.dpmb;

import java.util.ArrayList;
import java.util.List;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultRecord;

/**
 * The Class ValidationResult.
 */
public class ReceiverInfoWrapper {

    /** The causes. */
    private final List<String> causes = new ArrayList<>();

    /** The receiver info. */
    private final CaptureResultRecord receiverInfo;

    /**
     * Instantiates a new validation result.
     *
     * @param receiverInfo the receiver info
     */
    public ReceiverInfoWrapper(final CaptureResultRecord receiverInfo) {
        this.receiverInfo = receiverInfo;
    }

    /**
     * Adds the cause.
     *
     * @param cause the cause
     */
    void addCause(final String cause) {
        this.causes.add(cause);
    }

    /**
     * Gets the cause as string.
     *
     * @return the cause as string
     */
    public String getCauseAsString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("IdentCode: ").append(this.receiverInfo.getIdentcode()).append(Constant.LINE_SEPARATOR);
        for (final String cause : this.causes) {
            sb.append(cause).append(Constant.LINE_SEPARATOR);
        }
        return sb.toString();
    }

    /**
     * Gets the causes.
     *
     * @return the causes
     */
    public List<String> getCauses() {
        return this.causes;
    }

    /**
     * Gets the receiver info.
     *
     * @return the receiver info
     */
    public CaptureResultRecord getReceiverInfo() {
        return this.receiverInfo;
    }

    /**
     * Checks if is in valid.
     *
     * @return true, if is in valid
     */
    boolean isInValid() {
        return this.causes.size() > 0;
    }
}
