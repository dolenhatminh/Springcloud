/*
 * Class: CacheCollectionsConfiguration
 *
 * Created on May 5, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.cache;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import vn.sps.aba.dds.common.constant.Enumeration.DmcState;
import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;

/**
 * The Class CacheCollectionsConfiguration.
 */
@Configuration
@ConfigurationProperties(prefix = "cache.parcelinfo")
public class CacheParcelInfoConfiguration extends CacheConfiguration {

    /** The running states. */
    private String[] runningStates = new String[] { ParcelState.RECEIVED.name(), ParcelState.REJECTED.name(), ParcelState.FILTERING.name(),
        ParcelState.NO_FURTHER_PROCESSING.name(), ParcelState.MATCHING_READY.name(), ParcelState.DMC_PROCESSING.name(), ParcelState.BLACKBOX_READY.name(),
        ParcelState.BLACKBOX_SENT.name(), ParcelState.VAM_CAPTURE_RESULT_READY.name(), ParcelState.VAM_CAPTURE_RESULT_SENT.name(), DmcState.NOT_YET.name(),
        DmcState.DMC_SENT.name(), DmcState.PADASA_BARCODE_READY.name(), DmcState.PADASA_BARCODE_SENT.name(), DmcState.NO_BARCODE_AVAILABLE.name() };

    /**
     * Gets the running states.
     *
     * @return the running states
     */
    public String[] getRunningStates() {
        return this.runningStates;
    }

    /**
     * Sets the running states.
     *
     * @param runningStates the new running states
     */
    public void setRunningStates(final String[] runningStates) {
        this.runningStates = runningStates;
    }
}
