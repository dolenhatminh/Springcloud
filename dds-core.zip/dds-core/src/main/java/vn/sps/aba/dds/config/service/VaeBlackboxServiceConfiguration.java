/*
 * Class: VaeBlackboxServiceConfiguration
 *
 * Created on Jul 1, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.DDSConstant.Namespace;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.vae.blackbox.ObjectFactory;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.reponsecode.ICommonResponseCode;

/**
 * The Class VaeBlackboxServiceConfiguration.
 */
@Configuration("VaeBlackboxServiceConfiguration")
@ConfigurationProperties(prefix = "ws.vae.blackbox")
@Profile(value = { Profiles.PARCEL })
public class VaeBlackboxServiceConfiguration extends AbstractSoapWsConfiguration implements ICommonResponseCode {

    /**
     * The Enum ResponseCode.
     */
    private enum ResponseCode {

        /** The Failed to store data. */
        FailedToStoreData,
        /** The Invalid data. */
        InvalidData,
        /** The Service available. */
        ServiceAvailable,
        /** The Successful. */
        Successful,
        /** The Unexpected error. */
        UnexpectedError
    }

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(VaeBlackboxServiceConfiguration.class);

    /** The Constant SOUCE. */
    private static final String SOUCE = DDSConstant.Source.E119;

    /** The dienstleistungs. */
    private Map<String, Integer> dienstleistungs = new HashMap<>();

    /** The disco time stamp format. */
    private String discoTimeStampFormat;

    /** The pds time stamp format. */
    private String pdsTimeStampFormat;

    /** The valid code. */
    private String validCode = "[0-9]{18}";

    /** The valid type. */
    private String validType = "I";

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#failedToStoreData()
     */
    @Override
    public Response failedToStoreData() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.FailedToStoreData.name());
    }

    /**
     * Gets the dienstleistungs.
     *
     * @return the dienstleistungs
     */
    public Map<String, Integer> getDienstleistungs() {
        return this.dienstleistungs;
    }

    /**
     * Gets the disco time stamp format.
     *
     * @return the disco time stamp format
     */
    public String getDiscoTimeStampFormat() {
        return this.discoTimeStampFormat;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getNamespaceURI()
     */
    @Override
    public String getNamespaceURI() {
        return Namespace.E119_NAMESPACE;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getObjectFactory()
     */
    @Override
    public ObjectFactory getObjectFactory() {
        return (ObjectFactory) super.getObjectFactory();
    }

    /**
     * Gets the pds time stamp format.
     *
     * @return the pds time stamp format
     */
    public String getPdsTimeStampFormat() {
        return this.pdsTimeStampFormat;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getServiceName()
     */
    @Override
    public String getServiceName() {
        return "BlackBox";
    }

    /**
     * Gets the valid code.
     *
     * @return the valid code
     */
    public String getValidCode() {
        return this.validCode;
    }

    /**
     * Gets the valid type.
     *
     * @return the valid type
     */
    public String getValidType() {
        return this.validType;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#initialize()
     */
    @Override
    @PostConstruct
    public void initialize() throws Exception {
        super.initialize();
        LOG.info(StringUtil.printMap("Dienstleistungs", this.dienstleistungs));
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#invalidData()
     */
    @Override
    public Response invalidData() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.InvalidData.name());
    }

    /**
     * Resolve diensleistung.
     *
     * @param dienstleistung the dienstleistung
     * @return the integer
     */
    public Integer resolveDiensleistung(final String dienstleistung) {
        return this.dienstleistungs.get(dienstleistung);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#serviceAvailable()
     */
    @Override
    public Response serviceAvailable() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.ServiceAvailable.name());
    }

    /**
     * Sets the dienstleistungs.
     *
     * @param dienstleistungs the dienstleistungs
     */
    public void setDienstleistungs(final Map<String, Integer> dienstleistungs) {
        this.dienstleistungs = dienstleistungs;
    }

    /**
     * Sets the disco time stamp format.
     *
     * @param discoTimeStampFormat
     *            the new disco time stamp format
     */
    public void setDiscoTimeStampFormat(final String discoTimeStampFormat) {
        this.discoTimeStampFormat = discoTimeStampFormat;
    }

    /**
     * Sets the pds time stamp format.
     *
     * @param pdsTimeStampFormat
     *            the new pds time stamp format
     */
    public void setPdsTimeStampFormat(final String pdsTimeStampFormat) {
        this.pdsTimeStampFormat = pdsTimeStampFormat;
    }

    /**
     * Sets the valid code.
     *
     * @param validCode the new valid code
     */
    public void setValidCode(final String validCode) {
        this.validCode = validCode;
    }

    /**
     * Sets the valid type.
     *
     * @param validType the new valid type
     */
    public void setValidType(final String validType) {
        this.validType = validType;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#successful()
     */
    @Override
    public Response successful() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.Successful.name());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#unexpectedError()
     */
    @Override
    public Response unexpectedError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.UnexpectedError.name());
    }

}
