/*
 * Class: ResponseCodeInfo
 *
 * Created on Oct 27, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.jmx;

import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

/**
 * The Interface ResponseCodeInfo.
 */
@ManagedResource
public interface ResponseCodeInfo {
    
    /**
     * Gets the barcode response code.
     *
     * @return the barcode response code
     */
    @ManagedOperation
    String[] listBarcodeResponseCode();

    /**
     * Gets the blackbox response code.
     *
     * @return the blackbox response code
     */
    @ManagedOperation
    String[] listBlackboxResponseCode();

    /**
     * Gets the match maker response code.
     *
     * @return the match maker response code
     */
    @ManagedOperation
    String[] listMatchMakerResponseCode();

    /**
     * Gets the vam response code.
     *
     * @return the vam response code
     */
    @ManagedOperation
    String[] listVamResponseCode();

    /**
     * Put barcode response code.
     *
     * @param key the key
     * @param value the value
     */
    @ManagedOperation
    void putBarcodeResponseCode(String key, String value);

    /**
     * Put blackbox response code.
     *
     * @param key the key
     * @param value the value
     */
    @ManagedOperation
    void putBlackboxResponseCode(String key, String value);

    /**
     * Put match maker response code.
     *
     * @param key the key
     * @param value the value
     */
    @ManagedOperation
    void putMatchMakerResponseCode(String key, String value);

    /**
     * Put vam response code.
     *
     * @param key the key
     * @param value the value
     */
    @ManagedOperation
    void putVamResponseCode(String key, String value);
}