/*
 * Class: ErrorReceiverInfo
 *
 * Created on Sep 8, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.dpms;

import java.util.ArrayList;
import java.util.List;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.types.ws.dpms.CaptureResultRecord;

/**
 * The Class ErrorReceiverInfo.
 */
public class ReceiverValidatingInfo {

    /** The enough info. */
    private boolean enoughInfo;

    /** The error detail. */
    private final List<String> errors = new ArrayList<>();

    /** The ident code. */
    private String identCode;

    /** The key. */
    private String key;

    /** The need empty amp key. */
    private boolean needEmptyAmpKey;

    /** The package id. */
    private String packageId;

    /** The receiver info. */
    private CaptureResultRecord receiverInfo;

    /** The result state. */
    private ReceiverState resultState;

    /** The verified rule. */
    private String verifiedRule;

    /**
     * Gets the errors.
     *
     * @return the errors
     */
    public List<String> getErrors() {
        return this.errors;
    }

    /**
     * Gets the ident code.
     *
     * @return the ident code
     */
    public String getIdentCode() {
        return this.identCode;
    }

    /**
     * Gets the key.
     *
     * @return the key
     */
    public String getKey() {
        return this.key;
    }

    /**
     * Gets the package id.
     *
     * @return the package id
     */
    public String getPackageId() {
        return this.packageId;
    }

    /**
     * Gets the receiver info.
     *
     * @return the receiver info
     */
    public CaptureResultRecord getReceiverInfo() {
        return this.receiverInfo;
    }

    /**
     * Gets the result state.
     *
     * @return the result state
     */
    public ReceiverState getResultState() {
        return this.resultState;
    }

    /**
     * Gets the verified rule.
     *
     * @return the verified rule
     */
    public String getVerifiedRule() {
        return this.verifiedRule;
    }

    /**
     * Checks if is enough info.
     *
     * @return true, if is enough info
     */
    public boolean isEnoughInfo() {
        return this.enoughInfo;
    }

    /**
     * Checks if is need empty amp key.
     *
     * @return true, if is need empty amp key
     */
    public boolean isNeedEmptyAmpKey() {
        return this.needEmptyAmpKey;
    }

    /**
     * Checks if is valid.
     *
     * @return true, if is valid
     */
    public boolean isValid() {
        return this.errors.isEmpty();
    }

    /**
     * Sets the enough info.
     *
     * @param enoughInfo the new enough info
     */
    public void setEnoughInfo(final boolean enoughInfo) {
        this.enoughInfo = enoughInfo;
    }

    /**
     * Sets the ident code.
     *
     * @param identCode the new ident code
     */
    public void setIdentCode(final String identCode) {
        this.identCode = identCode;
    }

    /**
     * Sets the key.
     *
     * @param key the new key
     */
    public void setKey(final String key) {
        this.key = key;
    }

    /**
     * Sets the need empty amp key.
     *
     * @param needEmptyAmpKey the new need empty amp key
     */
    public void setNeedEmptyAmpKey(final boolean needEmptyAmpKey) {
        this.needEmptyAmpKey = needEmptyAmpKey;
    }

    /**
     * Sets the package id.
     *
     * @param packageId the new package id
     */
    public void setPackageId(final String packageId) {
        this.packageId = packageId;
    }

    /**
     * Sets the receiver info.
     *
     * @param receiverInfo the new receiver info
     */
    public void setReceiverInfo(final CaptureResultRecord receiverInfo) {
        this.receiverInfo = receiverInfo;
    }

    /**
     * Sets the result state.
     *
     * @param resultState the new result state
     */
    public void setResultState(final ReceiverState resultState) {
        this.resultState = resultState;
    }

    /**
     * Sets the verified rule.
     *
     * @param verifiedRule the new verified rule
     */
    public void setVerifiedRule(final String verifiedRule) {
        this.verifiedRule = verifiedRule;
    }
}
