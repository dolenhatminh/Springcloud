
package vn.sps.aba.dds.common.types.ws.vam.capturing.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CaptureResultIn complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CaptureResultIn">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CallerId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CaptureResultRecord" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}CaptureResultRecord"/>
 *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CaptureResultIn", propOrder = {
    "callerId",
    "captureResultRecord",
    "version"
})
public class CaptureResultIn {

    @XmlElement(name = "CallerId", required = true, nillable = true)
    protected String callerId;
    @XmlElement(name = "CaptureResultRecord", required = true, nillable = true)
    protected CaptureResultRecord captureResultRecord;
    @XmlElement(name = "Version")
    protected int version;

    /**
     * Gets the value of the callerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallerId() {
        return callerId;
    }

    /**
     * Sets the value of the callerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallerId(String value) {
        this.callerId = value;
    }

    /**
     * Gets the value of the captureResultRecord property.
     * 
     * @return
     *     possible object is
     *     {@link CaptureResultRecord }
     *     
     */
    public CaptureResultRecord getCaptureResultRecord() {
        return captureResultRecord;
    }

    /**
     * Sets the value of the captureResultRecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link CaptureResultRecord }
     *     
     */
    public void setCaptureResultRecord(CaptureResultRecord value) {
        this.captureResultRecord = value;
    }

    /**
     * Gets the value of the version property.
     * 
     */
    public int getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     */
    public void setVersion(int value) {
        this.version = value;
    }

}
