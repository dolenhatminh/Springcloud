/*
 * Class: DiscoWallClock
 *
 * Created on Sep 18, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.time;

import java.time.Clock;
import java.time.ZoneId;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.config.CommonConfiguration;

/**
 * The Class DiscoWallClock.
 */
@Component
@Configuration
public class DiscoWallClock {

    /** The clock. */
    private static Clock clock;

    /**
     * Milli.
     *
     * @return the long
     */
    public static long milli() {
        return clock.millis();
    }

    /**
     * Zone.
     *
     * @return the zone id
     */
    public static ZoneId zone() {
        return clock.getZone();
    }

    /** The common configuration. */
    @Autowired
    private CommonConfiguration commonConfiguration;

    /**
     * Initialzie.
     */
    @PostConstruct
    protected synchronized void initialzie() {
        clock = Clock.system(this.commonConfiguration.getZoneId());
        System.out.println("Disco Timezone: " + this.commonConfiguration.getZoneId());
    }
}
