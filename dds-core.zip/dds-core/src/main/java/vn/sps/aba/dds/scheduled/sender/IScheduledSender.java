/*
 * Class: IScheduledSender
 *
 * Created on Oct 11, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.sender;

import vn.sps.aba.dds.common.model.IdentifiedEntry;

/**
 * The Interface IScheduledSender.
 *
 * @param <T> the generic type
 */
public interface IScheduledSender<T extends IdentifiedEntry> {

    /**
     * Cancel scheduled item.
     *
     * @param key the key
     */
    void cancelScheduledItem(String key);

    /**
     * Queue.
     *
     * @param entity the entity
     */
    void queue(T entity);
}
