/*
 * Class: ICacheCommonDao
 *
 * Created on Jun 13, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.cache.interfaces;

import java.io.Serializable;
import java.util.List;

/**
 * The Interface ICacheCommonDao.
 *
 * @param <K>
 *            the key type
 * @param <V>
 *            the value type
 */
public interface ICacheCommonCacheDao<K, V extends Serializable> {

    /**
     * Clear.
     */
    void clear();

    /**
     * Contain key.
     *
     * @param key the key
     * @return true, if successful
     */
    boolean containKey(K key);

    /**
     * Count.
     *
     * @return the int
     */
    int count();

    /**
     * Delete.
     *
     * @param key
     *            the key
     */
    void delete(K key);

    /**
     * Gets the.
     *
     * @param key
     *            the key
     * @return the v
     */
    V get(K key);

    /**
     * List.
     *
     * @param max
     *            the max
     * @return the list
     */
    List<V> list(int max);

    /**
     * Persist.
     *
     * @param key the key
     * @param value the value
     * @param sync the sync
     * @return the v
     * @throws Exception the exception
     */
    boolean persist(K key, V value, boolean sync) throws Exception;

    /**
     * Put.
     *
     * @param key            the key
     * @param value            the value
     * @return the v
     */
    V put(K key, V value);

    /**
     * Put.
     *
     * @param key the key
     * @param value the value
     * @param lifespan the lifespan
     * @return the v
     */
    V put(K key, V value, long lifespan);

    /**
     * Removes the.
     *
     * @param key the key
     * @return the v
     */
    V remove(K key);

    /**
     * Removes the expired entries.
     */
    void removeExpiredEntries();

    /**
     * Put.
     *
     * @param key the key
     * @param value the value
     * @return the v
     */
    V store(K key, V value);
}
