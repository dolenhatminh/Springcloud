/*
 * Class: ReceiverInfoInterceptor
 *
 * Created on Jul 9, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.interceptor.receiver;

import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.support.MarshallingUtils;
import org.xml.sax.SAXParseException;

import vn.sps.aba.dds.common.types.message.Description;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.dpm.model.ObjectFactory;
import vn.sps.aba.dds.common.types.ws.dpm.model.TransferReceiverInfoResponse;
import vn.sps.aba.dds.config.service.ReceiverInfoServiceConfiguration;
import vn.sps.aba.dds.service.interceptor.AbstractPayloadValidator;

/**
 * The Class ReceiverInfoInterceptor.
 */
public class ReceiverInfoInterceptor extends AbstractPayloadValidator {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ReceiverInfoInterceptor.class);

    /**
     * Instantiates a new receiver info interceptor.
     *
     * @param serviceConfiguration the service configuration
     */
    public ReceiverInfoInterceptor(final ReceiverInfoServiceConfiguration serviceConfiguration) {
        super(serviceConfiguration);
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.ws.soap.server.endpoint.interceptor.AbstractFaultCreatingValidatingInterceptor#handleRequestValidationErrors(org.springframework.ws.context.MessageContext, org.xml.sax.SAXParseException[])
     */
    @Override
    protected boolean handleRequestValidationErrors(final MessageContext messageContext, final SAXParseException[] errors) throws TransformerException {

        try {
            if (messageContext.getResponse() instanceof SoapMessage) {

                LOG.info("The receiver info is invalid with following message:");

                final Description description = new Description();

                for (final SAXParseException error : errors) {
                    description.addMessage(error.getMessage());
                    LOG.info(error.getMessage());
                }
                if (this.getAddValidationErrorDetail()) {

                    final SaajSoapMessage response = (SaajSoapMessage) messageContext.getResponse();

                    final Response resp = this.getConfiguration(ReceiverInfoServiceConfiguration.class).invalidData();

                    if (resp != null) {

                        final ObjectFactory objectFactory = (ObjectFactory) this.getConfiguration().getObjectFactory();

                        final TransferReceiverInfoResponse putDeliveryInfoResponse = MessageBuilder
                            .buildTransferReceiverInfoResponse(objectFactory, resp, description);
                        MarshallingUtils.marshal(this.getConfiguration().getMarshaller(), putDeliveryInfoResponse, response);
                    }
                }
            }
        }
        catch (final Exception e) {

            LOG.error("There is error while handling validating errors of receiver info service ", e);
        }

        return false;
    }

}
