/*
 * Class: IParcelStateHandler
 *
 * Created on Jul 3, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.parcel.handers;

import java.util.concurrent.ExecutionException;

import vn.sps.aba.dds.common.model.parcel.ParcelInfo;

/**
 * The Interface IParcelStateHandler.
 */
public interface IParcelStepHandler {

    /** The parcel initial state handler. */
    static String PARCEL_INITIAL_STATE_HANDLER = "PARCEL_STATE_NEW";

    /**
     * Gets the state.
     *
     * @return the state
     */
    String getStateName();

    /**
     * Handle.
     *
     * @param context            the context
     * @param parcelInfo            the parcel info
     * @throws InterruptedException the interrupted exception
     * @throws ExecutionException the execution exception
     */
    void handle(IParcelStateHandlerContext context, ParcelInfo parcelInfo) throws InterruptedException, ExecutionException;
}
