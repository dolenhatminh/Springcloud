/*
 * Class: ParcelGeneralInterceptor
 *
 * Created on Jun 15, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.interceptor.parcel;

import java.util.regex.Pattern;

import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.support.MarshallingUtils;
import org.xml.sax.SAXParseException;

import net.logstash.logback.marker.Markers;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.pds.parcel.model.TransferParcelInfoResponse;
import vn.sps.aba.dds.config.service.ParcelInfoServiceConfiguration;
import vn.sps.aba.dds.service.interceptor.AbstractPayloadValidator;
import vn.sps.aba.dds.service.validation.parcel.ParcelValidatingInfo;

/**
 * The Class ParcelGeneralInterceptor.
 */
public class ParcelInfoInterceptor extends AbstractPayloadValidator {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ParcelInfoInterceptor.class);

    /**
     * Constructs a new <tt>ParcelInfoSchemaBasedValidatingInterceptor</tt>.
     *
     * @param configuration the configuration
     */
    public ParcelInfoInterceptor(final ParcelInfoServiceConfiguration configuration) {
        super(configuration);
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.ws.soap.server.endpoint.interceptor.AbstractFaultCreatingValidatingInterceptor#handleRequestValidationErrors(org.springframework.ws.context.MessageContext,
     *      org.xml.sax.SAXParseException[])
     */
    @Override
    protected boolean handleRequestValidationErrors(final MessageContext messageContext, final SAXParseException[] errors) throws TransformerException {

        boolean ret = true;
        final ParcelValidatingInfo validatingInfo = new ParcelValidatingInfo();
        ParcelInfoServiceConfiguration serviceConfiguration = getConfiguration(ParcelInfoServiceConfiguration.class);
        Response resp = serviceConfiguration.invalidData();
        validatingInfo.setResponse(resp);

        try {
            if (messageContext.getResponse() instanceof SoapMessage) {

                ret = false;

                Pattern pattern = Pattern.compile(serviceConfiguration.getIncorrectBase64Sign());
                for (final SAXParseException error : errors) {
                    String message = error.getMessage();
                    if (isImageElement(message, pattern)) {
                        message = serviceConfiguration.getIncorrectImageBase64Message();
                    }
                    validatingInfo.getErrors().add(message);
                }

                LOG.error(Markers.append(serviceConfiguration.getInvalidParcelInfoFieldName(), validatingInfo), "Invalid parcel info");
                if (!ret) {
                    buildResponseContent(messageContext, validatingInfo, serviceConfiguration);
                }
            }
        }
        catch (final Exception e) {
            resp = serviceConfiguration.unexpectedError();
            validatingInfo.setResponse(resp);
            buildResponseContent(messageContext, validatingInfo, serviceConfiguration);
            LOG.error(Markers.append(serviceConfiguration.getInvalidParcelInfoFieldName(), validatingInfo), "Error occurs while validating parcel", e);
        }

        return ret;
    }

    /**
     * Builds the response content.
     *
     * @param messageContext the message context
     * @param validatingInfo the validating info
     * @param serviceConfiguration the service configuration
     */
    private void buildResponseContent(
        final MessageContext messageContext,
        final ParcelValidatingInfo validatingInfo,
        ParcelInfoServiceConfiguration serviceConfiguration) {

        try {
            final SaajSoapMessage response = (SaajSoapMessage) messageContext.getResponse();
            final TransferParcelInfoResponse parcelInfoResponse = MessageBuilder.buildParcelResponse(serviceConfiguration, validatingInfo);
            MarshallingUtils.marshal(this.getConfiguration().getMarshaller(), parcelInfoResponse, response);
        }
        catch (Exception e) {
            LOG.error(Markers.append(serviceConfiguration.getInvalidParcelInfoFieldName(), validatingInfo), "Error when build response message for parcel", e);
        }
    }

    /**
     * Checks if is image element.
     *
     * @param message the message
     * @param pattern the pattern
     * @return true, if is image element
     */
    private boolean isImageElement(String message, Pattern pattern) {
        return pattern.matcher(message).find();
    }
}
