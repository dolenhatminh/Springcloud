/*
 * Class: ReceiverImportingReport
 *
 * Created on Nov 28, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.report;

/**
 * The Class ImportingResult.
 */
public class ImportingResult {

    /** The duplicated count. */
    private int duplicatedCount;

    /** The failed count. */
    private int failedCount;

    /** The from time. */
    private long fromTime;

    /** The loaded count. */
    private int loadedCount;

    /** The message. */
    private String message;

    /** The success count. */
    private int successCount;

    /** The to time. */
    private long toTime;

    /**
     * Gets the duplicated count.
     *
     * @return the duplicated count
     */
    public int getDuplicatedCount() {
        return this.duplicatedCount;
    }

    /**
     * Gets the failed count.
     *
     * @return the failed count
     */
    public int getFailedCount() {
        return this.failedCount;
    }

    /**
     * Gets the from time.
     *
     * @return the from time
     */
    public long getFromTime() {
        return this.fromTime;
    }

    /**
     * Gets the loaded count.
     *
     * @return the loaded count
     */
    public int getLoadedCount() {
        return this.loadedCount;
    }

    /**
     * Gets the message.
     *
     * @return the message
     */
    public String getMessage() {
        return this.message;
    }

    /**
     * Gets the success count.
     *
     * @return the success count
     */
    public int getSuccessCount() {
        return this.successCount;
    }

    /**
     * Gets the to time.
     *
     * @return the to time
     */
    public long getToTime() {
        return this.toTime;
    }

    /**
     * Sets the duplicated count.
     *
     * @param duplicatedCount the new duplicated count
     */
    public void setDuplicatedCount(final int duplicatedCount) {
        this.duplicatedCount = duplicatedCount;
    }

    /**
     * Sets the failed count.
     *
     * @param failedCount the new failed count
     */
    public void setFailedCount(final int failedCount) {
        this.failedCount = failedCount;
    }

    /**
     * Sets the from time.
     *
     * @param fromTime the new from time
     */
    public void setFromTime(final long fromTime) {
        this.fromTime = fromTime;
    }

    /**
     * Sets the loaded count.
     *
     * @param loadedCount the new loaded count
     */
    public void setLoadedCount(final int loadedCount) {
        this.loadedCount = loadedCount;
    }

    /**
     * Sets the message.
     *
     * @param message the new message
     */
    public void setMessage(final String message) {
        this.message = message;
    }

    /**
     * Sets the success count.
     *
     * @param successCount the new success count
     */
    public void setSuccessCount(final int successCount) {
        this.successCount = successCount;
    }

    /**
     * Sets the to time.
     *
     * @param toTime the new to time
     */
    public void setToTime(final long toTime) {
        this.toTime = toTime;
    }
}
