/*
 * Class: SchoberCachListener
 *
 * Created on May 4, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.listener;

import org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent;
import org.springframework.transaction.TransactionException;

/**
 * The listener interface for receiving ICache events.
 * The class that is interested in processing a ICache
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addICacheListener<code> method. When
 * the ICache event occurs, that object's appropriate
 * method is invoked.
 *
 * @param <K> the key type
 * @param <V> the value type
 * @see ICacheEvent
 */
public interface ICacheListener<K, V> {

    /**
     * Adds the.
     *
     * @param event the event
     * @throws TransactionException the transaction exception
     */
    void add(CacheEntryCreatedEvent<K, V> event) throws TransactionException;

    /**
     * Modify.
     *
     * @param event the event
     * @throws TransactionException the transaction exception
     */
    void modify(CacheEntryModifiedEvent<K, V> event) throws TransactionException;

    /**
     * Removes the.
     *
     * @param event the event
     * @throws TransactionException the transaction exception
     */
    void remove(CacheEntryRemovedEvent<K, V> event) throws TransactionException;
}
