/*
 * Class: VerifiedRule
 *
 * Created on Jul 5, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.types.verifying;

import java.util.HashSet;
import java.util.Set;

import vn.sps.aba.dds.common.constant.Enumeration.VerifiedField;
import vn.sps.aba.dds.common.util.StringUtil;

/**
 * The Class VerifiedRule.
 */
public class VerifiedRule {

    /** The fields. */
    private Set<VerifiedField> fields;

    /** The name. */
    private final String name;

    /**
     * Instantiates a new verified rule.
     *
     * @param name
     *            the name
     */
    public VerifiedRule(final String name) {
        this.name = name;
    }

    /**
     * Adds the field.
     *
     * @param field
     *            the field
     * @return true, if successful
     */
    public boolean addField(final VerifiedField field) {

        if (!this.getFields().add(field)) {

            throw new IllegalArgumentException(StringUtil.format("The field [%s] is existed in rule %s already", field, this.name));
        }

        return true;
    }

    /**
     * Gets the fields.
     *
     * @return the fields
     */
    private Set<VerifiedField> getFields() {

        if (this.fields == null) {

            this.fields = new HashSet<>();
        }

        return this.fields;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Gets the rules.
     *
     * @return the rules
     */
    public VerifiedField[] getRules() {
        return this.getFields().toArray(new VerifiedField[this.getFields().size()]);
    }

    /**
     * {@inheritDoc}
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return this.name;
    }
}
