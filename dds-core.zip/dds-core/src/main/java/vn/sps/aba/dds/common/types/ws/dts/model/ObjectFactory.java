
package vn.sps.aba.dds.common.types.ws.dts.model;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the vn.sps.aba.dds.service.dts.model package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: vn.sps.aba.dds.service.dts.model
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PutDeliveryInfo }
     * 
     */
    public PutDeliveryInfo createPutDeliveryInfo() {
        return new PutDeliveryInfo();
    }

    /**
     * Create an instance of {@link ArrayOfReceiverInfoRecord }
     * 
     */
    public ArrayOfReceiverInfoRecord createArrayOfReceiverInfoRecord() {
        return new ArrayOfReceiverInfoRecord();
    }

    /**
     * Create an instance of {@link PutDeliveryInfoResponse }
     * 
     */
    public PutDeliveryInfoResponse createPutDeliveryInfoResponse() {
        return new PutDeliveryInfoResponse();
    }

    /**
     * Create an instance of {@link ReceiverInfoRecord }
     * 
     */
    public ReceiverInfoRecord createReceiverInfoRecord() {
        return new ReceiverInfoRecord();
    }

}
