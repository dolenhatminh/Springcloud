/*
 * Class: BlackboxSendingExecutor
 *
 * Created on Oct 19, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.task.sender;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import vn.sps.aba.dds.config.task.TaskConfiguration;

/**
 * The Class VamSendingExecutor.
 */
@Configuration("Parcel2VamSendingExecutor")
@ConfigurationProperties(prefix = "task.sender.parcel2vam")
public class Parcel2VamSendingExecutor extends TaskConfiguration {

}
