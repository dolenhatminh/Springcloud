
package vn.sps.aba.dds.common.types.ws.dts.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RESP_CODE" type="{http://www.postlogistics.ch/PLDTVG/V10/}Max4Number" form="unqualified"/>
 *         &lt;element name="RESP_ERROR" type="{http://www.postlogistics.ch/PLDTVG/V10/}Max254Text" minOccurs="0" form="unqualified"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "respcode",
    "resperror"
})
@XmlRootElement(name = "putDeliveryInfoResponse")
public class PutDeliveryInfoResponse {

    @XmlElement(name = "RESP_CODE", required = true)
    protected String respcode;
    @XmlElement(name = "RESP_ERROR")
    protected String resperror;

    /**
     * Gets the value of the respcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESPCODE() {
        return respcode;
    }

    /**
     * Sets the value of the respcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESPCODE(String value) {
        this.respcode = value;
    }

    /**
     * Gets the value of the resperror property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESPERROR() {
        return resperror;
    }

    /**
     * Sets the value of the resperror property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESPERROR(String value) {
        this.resperror = value;
    }

}
