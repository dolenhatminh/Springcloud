/*
 * Class: DpmServiceEnpoint
 *
 * Created on Jul 22, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.service.dpm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import vn.sps.aba.dds.common.constant.DDSConstant.Namespace;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.message.Description;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResult;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultIn;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultResponse;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.ObjectFactory;
import vn.sps.aba.dds.config.service.DpmServiceConfiguration;
import vn.sps.aba.dds.processor.receiver.ReceiverProcessingManager;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;

/**
 * The Class DpmServiceEnpoint.
 */
@Profile(Profiles.DPM)
@Endpoint
public class DpmServiceEnpoint {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DpmServiceEnpoint.class);

    /** The process manager. */
    @Autowired
    private ReceiverProcessingManager processManager;

    /** The receiver info dao. */
    @Autowired
    private IReceiverInfoCacheDao receiverInfoDao;

    /** The service configuration. */
    @Autowired
    private DpmServiceConfiguration serviceConfiguration;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.types.ws.vam.capturing.model.ICaptureResultService#captureResult(vn.sps.aba.dds.common.types.ws.vam.capturing.model.CaptureResultIn)
     */
    @PayloadRoot(namespace = Namespace.E189_NAMESPACE, localPart = "CaptureResult")
    public @ResponsePayload CaptureResultResponse captureResult(@RequestPayload final CaptureResult captureResult) {

        final boolean isDianogRequest = (captureResult == null) || (captureResult.getRequest() == null)
                || (captureResult.getRequest().getValue().getCaptureResultRecord() == null);

        final ObjectFactory objectFactory = this.serviceConfiguration.getObjectFactory();

        Response response = this.serviceConfiguration.serviceAvailable();
        final Description description = new Description();

        try {
            if (!isDianogRequest) {

                response = this.serviceConfiguration.successful();
                final CaptureResultIn request = captureResult.getRequest().getValue();
                try {
                    if (this.isValidMessage(request, description)) {
                        final String key = request.getCaptureResultRecord().getIdentcode();

                        final vn.sps.aba.dds.common.model.receiver.ReceiverInfo receiverInfo = new vn.sps.aba.dds.common.model.receiver.ReceiverInfo(request);
                        receiverInfo.setReceived(DiscoWallClock.milli());
                        this.receiverInfoDao.put(key, receiverInfo);

                        this.processManager.submit(receiverInfo);
                    }
                    else {
                        response = this.serviceConfiguration.invalidData();
                    }
                }
                catch (final Exception e) {

                    response = this.serviceConfiguration.failedToStoreData();
                    LOG.error("Error while processing the receiver info data", e);
                }
            }
            else {

                LOG.info("Dianog request: Service available");
            }
        }
        catch (final Exception e) {

            response = this.serviceConfiguration.unexpectedError();
            LOG.error("Error while processing the receiver info data", e);
        }

        return MessageBuilder.buildDPMResponse(objectFactory, response, description);
    }

    /**
     * Checks if is valid message.
     *
     * @param request the request
     * @param description the reasons
     * @return true, if is valid message
     */
    private boolean isValidMessage(final CaptureResultIn request, final Description description) {
        if (!request.getCaptureResultRecord().getIdentcode().matches(this.serviceConfiguration.getIdentCodeFormat())) {
            description.addMessage("Invalid identcode, expected format " + this.serviceConfiguration.getIdentCodeFormat());
            return false;
        }
        return true;
    }
}
