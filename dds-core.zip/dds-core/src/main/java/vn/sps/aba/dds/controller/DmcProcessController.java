/*
 * Class: DmcProcessController
 *
 * Created on Nov 23, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.jms.IDmcMQConnector;

/**
 * The Class DmcProcessController.
 */
@RestController
@RequestMapping("/aba/dds/parcel")
@ConditionalOnProperty(name = "dmc.activemq", havingValue = "true")
public class DmcProcessController {

    /** The dmc mq connector. */
    @Autowired
    private IDmcMQConnector dmcMQConnector;

    /**
     * Process dmc response.
     *
     * @param dmcMsgQueueName the dmc msg queue name
     * @param size the size
     * @return the DMC response[]
     */
    @RequestMapping("/process-dmc-response")
    public DMCResponse[] processDMCResponse(@RequestParam(name = "queueName") final String dmcMsgQueueName, final int size) {
        final List<DMCResponse> ret = new ArrayList<>();

        if (StringUtil.notNullOrEmpty(dmcMsgQueueName)) {
            if (size < 0) {
                DMCResponse response;
                while ((response = this.dmcMQConnector.consume(dmcMsgQueueName)) != null) {
                    ret.add(response);
                }
            }
            else {
                int i = 0;
                DMCResponse response;
                while ((i < size) && ((response = this.dmcMQConnector.consume(dmcMsgQueueName)) != null)) {
                    ret.add(response);
                    i++;
                }
            }
        }

        return ret.toArray(new DMCResponse[ret.size()]);
    }
}
