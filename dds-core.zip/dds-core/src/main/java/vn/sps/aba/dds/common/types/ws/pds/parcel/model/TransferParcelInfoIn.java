
package vn.sps.aba.dds.common.types.ws.pds.parcel.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for TransferParcelInfoIn complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TransferParcelInfoIn">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CallerId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ParcelInfo" type="{Ch.Post.PL.Vae.VG.ParcelInfoService}ParcelInfo"/>
 *         &lt;element name="ParcelInfoSentTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransferParcelInfoIn", propOrder = {
    "callerId",
    "parcelInfo",
    "parcelInfoSentTimestamp",
    "version"
})
public class TransferParcelInfoIn {

    @XmlElement(name = "CallerId", required = true, nillable = true)
    protected String callerId;
    @XmlElement(name = "ParcelInfo", required = true, nillable = true)
    protected ParcelInfo parcelInfo;
    @XmlElement(name = "ParcelInfoSentTimestamp", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar parcelInfoSentTimestamp;
    @XmlElement(name = "Version")
    protected int version;

    /**
     * Gets the value of the callerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallerId() {
        return callerId;
    }

    /**
     * Sets the value of the callerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallerId(String value) {
        this.callerId = value;
    }

    /**
     * Gets the value of the parcelInfo property.
     * 
     * @return
     *     possible object is
     *     {@link ParcelInfo }
     *     
     */
    public ParcelInfo getParcelInfo() {
        return parcelInfo;
    }

    /**
     * Sets the value of the parcelInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ParcelInfo }
     *     
     */
    public void setParcelInfo(ParcelInfo value) {
        this.parcelInfo = value;
    }

    /**
     * Gets the value of the parcelInfoSentTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getParcelInfoSentTimestamp() {
        return parcelInfoSentTimestamp;
    }

    /**
     * Sets the value of the parcelInfoSentTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setParcelInfoSentTimestamp(XMLGregorianCalendar value) {
        this.parcelInfoSentTimestamp = value;
    }

    /**
     * Gets the value of the version property.
     * 
     */
    public int getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     */
    public void setVersion(int value) {
        this.version = value;
    }

}
