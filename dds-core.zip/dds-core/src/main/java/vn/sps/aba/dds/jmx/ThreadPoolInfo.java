/*
 * Class: ThreadPoolInfo
 *
 * Created on Oct 24, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.jmx;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

/**
 * The Interface ThreadPoolInfo.
 */
@ManagedResource
public interface ThreadPoolInfo {

    /**
     * Change pool config.
     *
     * @param corePoolSize the core pool size
     * @param maxPoolSize the max pool size
     */
    @ManagedOperation
    void changePoolConfig(int corePoolSize, int maxPoolSize);

    /**
     * Empty queue.
     *
     * @param key the key
     */
    void emptyQueue(final String key);

    /**
     * Gets the active count.
     *
     * @return the active count
     */
    @ManagedAttribute
    int getActiveCount();

    /**
     * Gets the core pool size.
     *
     * @return the core pool size
     */
    @ManagedAttribute
    int getCorePoolSize();

    /**
     * Gets the max pool size.
     *
     * @return the max pool size
     */
    @ManagedAttribute
    int getMaxPoolSize();

    /**
     * Gets the queuing count.
     *
     * @return the queuing count
     */
    @ManagedAttribute
    int getQueingCount();

    /**
     * Gets the queue capacity.
     *
     * @return the queue capacity
     */
    @ManagedAttribute
    int getQueueCapacity();

    /**
     * Gets the thread name.
     *
     * @return the thread name
     */
    @ManagedAttribute
    String getThreadName();
}
