/*
 * Class: DmcReceiver
 *
 * Created on Dec 7, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.receiver.dmc.impl;

import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.Enumeration.DmcState;
import vn.sps.aba.dds.common.ifa.TaskWatcher;
import vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.dmc.DMCCode;
import vn.sps.aba.dds.common.model.dmc.DMCFormat;
import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.service.DmcServiceConfiguration;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.sender.DmcReceivingExecutor;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.receiver.dmc.IDmcReceiver;
import vn.sps.aba.dds.repository.cache.interfaces.IParcelInfoCacheDao;
import vn.sps.aba.dds.sender.parcel.interfaces.IBarcodeSender;
import vn.sps.aba.dds.sender.parcel.interfaces.IDmcSender;

/**
 * The Class DmcReceiver.
 */
@Component(value = "DmcReceiver")
public class DmcReceiver extends AbstractAsyncWorker implements IDmcReceiver, TaskWatcher {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DmcReceiver.class);

    /** The barcode sender. */
    @Autowired
    private IBarcodeSender barcodeSender;

    /** The dmc receiving executor. */
    @Autowired
    private DmcReceivingExecutor dmcReceivingExecutor;

    /** The dmc sender. */
    @Autowired
    private IDmcSender dmcSender;

    /** The parcel info dao. */
    @Autowired
    private IParcelInfoCacheDao parcelInfoDao;

    /** The processor watcher. */
    @Autowired
    @Qualifier("ParcelProcessingManager")
    private TaskWatcher processorWatcher;

    /** The service configuration. */
    @Autowired
    private DmcServiceConfiguration serviceConfiguration;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected TaskConfiguration getExecutor() {
        return this.dmcReceivingExecutor;
    }

    /**
     * Checks if is ready for sending to padasa.
     *
     * @param entry the entry
     * @param response the response
     * @return true, if is ready for sending to padasa
     */
    private boolean isReadyForSendingToPadasa(final IdentifiedEntry entry, final DMCResponse response) {
        boolean ret = false;

        for (final DMCCode code : response.getDmcCodes()) {

            LOG.info(IndexMaker.index(entry), "Checking DMC code {}", code.getContent());
            for (final DMCFormat format : this.serviceConfiguration.getDmcFormats()) {

                if (code.getContent().matches(format.getFormat())) {
                    code.setFormat(format);
                    ret = true;
                    break;
                }
            }
        }
        return ret;
    }

    /**
     * Merge and store.
     *
     * @param key the key
     * @param parcelInfo the parcel info
     * @param state the state
     * @param response the response
     * @param dmcEnd the dmc end
     */
    protected void mergeAndStore(final String key, final ParcelInfo parcelInfo, final DmcState state, final DMCResponse response, final long dmcEnd) {
        try {
            // Wait for pre-processor finished before merge and store data
            // Just because the parcel is read from cache, and its fields is not updated by other threads
            // Wait thread: + Main business processor + Blackbox or Vam thread sender (if any) + DMC sender
            // Add watcher for each message sender thread
            Future<?> task = this.processorWatcher.unWatch(key);
            if (task != null) {
                LOG.info(IndexMaker.index(parcelInfo), "Wait for prio-dmc processing finished");
                task.get();
            }
            task = this.dmcSender.getTask(key);
            if (task != null) {
                LOG.info(IndexMaker.index(parcelInfo), "Wait for DMC sender finished");
                task.get();
            }

            ParcelInfo ret = this.parcelInfoDao.get(key);
            if (ret == null) {
                LOG.info(IndexMaker.index(parcelInfo), "Cannot find any parcel match with key");
                ret = parcelInfo;
            }
            ret.setDmcState(state);
            ret.setDmcCode(response);
            ret.setDmcEnd(dmcEnd);
            if (DmcState.NO_BARCODE_AVAILABLE == state) {
                this.parcelInfoDao.store(key, ret);
            }
            else {
                this.parcelInfoDao.put(key, ret);
            }
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when merge and store DMC data into database.", e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.receiver.dmc.IDmcReceiver#receive(vn.sps.aba.dds.common.model.dmc.DMCResponse)
     */
    @Override
    public void receive(final DMCResponse response) {
        if (response != null) {
            final String key = response.getKey();

            if (StringUtil.notNullOrEmpty(key)) {
                final Future<?> task = this.dmcReceivingExecutor.getAsyncExecutor().submit(() -> {
                    try {

                        LOG.info(IndexMaker.indexes(response), "Receive DMC processing result");

                        final ParcelInfo parcelInfo = this.parcelInfoDao.get(key);
                        if (parcelInfo != null) {
                            DmcState dmcState = parcelInfo.getDmcState();
                            LOG.info(IndexMaker.index(parcelInfo), "Retrieve a parcel info");

                            final long dmcEnd = DiscoWallClock.milli();
                            if (this.isReadyForSendingToPadasa(parcelInfo, response)) {

                                dmcState = DmcState.PADASA_BARCODE_READY;
                                LOG.info(IndexMaker.index(parcelInfo), "Submit parcel to PADASA sender");
                                this.barcodeSender.submitItem(parcelInfo, response);
                            }
                            else {
                                dmcState = DmcState.NO_BARCODE_AVAILABLE;
                                LOG.info(IndexMaker.index(parcelInfo), "The parcel info is not ready for sending to PADASA BarcodeDataService");
                            }
                            this.mergeAndStore(key, parcelInfo, dmcState, response, dmcEnd);
                        }
                        else {
                            LOG.warn(IndexMaker.index(key), "No parcel indexed with key");
                        }
                    }
                    catch (final Exception e) {
                        LOG.error(IndexMaker.indexes(response), "Error when store data matrix code", e);
                    }
                    finally {
                        this.watcher.unWatch(key);
                    }
                });
                this.watcher.watch(key, task);
            }
            else {
                LOG.error(IndexMaker.index(key), "Invalid key in the response.");
            }
        }
        else {
            LOG.warn(IndexMaker.indexes(response), "Invalid DMC reponse");
        }
    }

    /**
     * Sets the dmc receiving executor.
     *
     * @param dmcReceivingExecutor the new dmc receiving executor
     */
    public void setDmcReceivingExecutor(final DmcReceivingExecutor dmcReceivingExecutor) {
        this.dmcReceivingExecutor = dmcReceivingExecutor;
    }
}
