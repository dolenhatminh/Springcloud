/*
 * Class: FilteringThreadPoolConfiguration
 *
 * Created on Jun 20, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.task.processor;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.config.task.TaskConfiguration;

/**
 * The Class FilteringThreadPoolConfiguration.<br>
 * This will be changed later if it is used for main workflow also.
 */
@Profile(value = { Profiles.RECEIVER, Profiles.DPM, Profiles.DPMB, Profiles.DPMS })
@Configuration("ReceiverProcessingExecutor")
@ConfigurationProperties(prefix = "task.receiverprocess")
public class ReceiverProcessingExecutor extends TaskConfiguration {

}
