/*
 * Class: MatchMakerServiceConfiguration
 *
 * Created on Jun 30, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.DDSConstant.Namespace;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.padasa.matchmakerdaten.model.ObjectFactory;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.config.reponsecode.ICommonResponseCode;

/**
 * The Class MatchMakerServiceConfiguration.
 */
@Configuration("MatchMakerServiceConfiguration")
@ConfigurationProperties(prefix = "ws.padasa.matchmaker")
@Profile(value = { Profiles.RECEIVER, Profiles.DPM, Profiles.DPMB, Profiles.DPMS })
public class MatchMakerServiceConfiguration extends AbstractSoapWsConfiguration implements ICommonResponseCode {

    /**
     * The Enum ResponseCode.
     */
    private enum ResponseCode {

        /** The Failed to store data. */
        FailedToStoreData,
        /** The Invalid data. */
        InvalidData,
        /** The Service available. */
        ServiceAvailable,
        /** The Successful. */
        Successful,
        /** The Unexpected error. */
        UnexpectedError
    }

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(MatchMakerServiceConfiguration.class);

    /** The Constant SOUCE. */
    private static final String SOUCE = DDSConstant.Source.E138;

    /** The amp statuses. */
    private final Map<String, Integer> ampStatuses = new HashMap<>();

    /** The last update format. */
    private String lastUpdateFormat;

    /** The match maker response codes. */
    private Map<String, Integer> matchMakerResponseCodes = new HashMap<>();

    /** The parcel adr types. */
    private Map<String, Integer> parcelAdrTypes = new HashMap<>();

    /** The pers statuses. */
    private Map<String, Integer> persStatuses = new HashMap<>();

    /** The pers types. */
    private Map<String, Integer> persTypes = new HashMap<>();

    /** The vam time stamp format. */
    private String vamTimeStampFormat;

    /** The vg process time format. */
    private String vgProcessTimeFormat;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#failedToStoreData()
     */
    @Override
    public Response failedToStoreData() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.FailedToStoreData.name());
    }

    /**
     * Gets the amp statuses.
     *
     * @return the amp statuses
     */
    public Map<String, Integer> getAmpStatuses() {
        return this.ampStatuses;
    }

    /**
     * Gets the last update format.
     *
     * @return the last update format
     */
    public String getLastUpdateFormat() {
        return this.lastUpdateFormat;
    }

    /**
     * Gets the match maker response codes.
     *
     * @return the match maker response codes
     */
    public Map<String, Integer> getMatchMakerResponseCodes() {
        return this.matchMakerResponseCodes;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getNamespaceURI()
     */
    @Override
    public String getNamespaceURI() {
        return Namespace.E138_NAMESPACE;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#getObjectFactory()
     */
    @Override
    public ObjectFactory getObjectFactory() {
        return (ObjectFactory) super.getObjectFactory();
    }

    /**
     * Gets the parcel adr types.
     *
     * @return the parcel adr types
     */
    public Map<String, Integer> getParcelAdrTypes() {
        return this.parcelAdrTypes;
    }

    /**
     * Gets the pers statuses.
     *
     * @return the pers statuses
     */
    public Map<String, Integer> getPersStatuses() {
        return this.persStatuses;
    }

    /**
     * Gets the pers types.
     *
     * @return the pers types
     */
    public Map<String, Integer> getPersTypes() {
        return this.persTypes;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getServiceName()
     */
    @Override
    public String getServiceName() {
        return "MatchMaker";
    }

    /**
     * Gets the vam time stamp format.
     *
     * @return the vam time stamp format
     */
    public String getVamTimeStampFormat() {
        return this.vamTimeStampFormat;
    }

    /**
     * Gets the vg process time format.
     *
     * @return the vg process time format
     */
    public String getVgProcessTimeFormat() {
        return this.vgProcessTimeFormat;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.AbstractSoapWsConfiguration#initialize()
     */
    @Override
    @PostConstruct
    public void initialize() throws Exception {
        super.initialize();
        LOG.info(StringUtil.printMap("AmpStatuses", this.ampStatuses));
        LOG.info(StringUtil.printMap("MatchMakerResponseCodes", this.matchMakerResponseCodes));
        LOG.info(StringUtil.printMap("ParcelAdrTypes", this.parcelAdrTypes));
        LOG.info(StringUtil.printMap("PersStatuses", this.persStatuses));
        LOG.info(StringUtil.printMap("PersTypes", this.persTypes));
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#invalidData()
     */
    @Override
    public Response invalidData() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.InvalidData.name());
    }

    /**
     * Resolve amp status.
     *
     * @param key the key
     * @return the integer
     */
    public Integer resolveAmpStatus(final String key) {

        return this.ampStatuses.get(key);
    }

    /**
     * Resolve match maker response code.
     *
     * @param key the key
     * @return the match maker response code wrapper
     */
    public Integer resolveMatchMakerResponseCode(final String key) {

        return this.matchMakerResponseCodes.get(key);
    }

    /**
     * Resolve pers status.
     *
     * @param key the key
     * @return the integer
     */
    public Integer resolvePersStatus(final String key) {
        return this.persStatuses.get(key);
    }

    /**
     * Resolve pers type.
     *
     * @param key the key
     * @return the integer
     */
    public Integer resolvePersType(final String key) {
        return this.persTypes.get(key);
    }

    /**
     * Resolve vae address type.
     *
     * @param key the key
     * @return the integer
     */
    public Integer resolveVaeAddressType(final String key) {
        return this.parcelAdrTypes.get(key);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#serviceAvailable()
     */
    @Override
    public Response serviceAvailable() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.ServiceAvailable.name());
    }

    /**
     * Sets the last update format.
     *
     * @param lastUpdateFormat
     *            the new last update format
     */
    public void setLastUpdateFormat(final String lastUpdateFormat) {
        this.lastUpdateFormat = lastUpdateFormat;
    }

    /**
     * Sets the match maker response codes.
     *
     * @param matchMakerResponseCodes the match maker response codes
     */
    public void setMatchMakerResponseCodes(final Map<String, Integer> matchMakerResponseCodes) {
        this.matchMakerResponseCodes = matchMakerResponseCodes;
    }

    /**
     * Sets the parcel adr types.
     *
     * @param parcelAdrTypes the parcel adr types
     */
    public void setParcelAdrTypes(final Map<String, Integer> parcelAdrTypes) {
        this.parcelAdrTypes = parcelAdrTypes;
    }

    /**
     * Sets the pers statuses.
     *
     * @param persStatuses the pers statuses
     */
    public void setPersStatuses(final Map<String, Integer> persStatuses) {
        this.persStatuses = persStatuses;
    }

    /**
     * Sets the pers types.
     *
     * @param persTypes the pers types
     */
    public void setPersTypes(final Map<String, Integer> persTypes) {
        this.persTypes = persTypes;
    }

    /**
     * Sets the vam time stamp format.
     *
     * @param vamTimeStampFormat
     *            the new vam time stamp format
     */
    public void setVamTimeStampFormat(final String vamTimeStampFormat) {
        this.vamTimeStampFormat = vamTimeStampFormat;
    }

    /**
     * Sets the vg process time format.
     *
     * @param vgProcessTimeFormat
     *            the new vg process time format
     */
    public void setVgProcessTimeFormat(final String vgProcessTimeFormat) {
        this.vgProcessTimeFormat = vgProcessTimeFormat;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#successful()
     */
    @Override
    public Response successful() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.Successful.name());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.ICommonResponseCode#unexpectedError()
     */
    @Override
    public Response unexpectedError() {
        return this.responseCodeProvider.find(SOUCE, ResponseCode.UnexpectedError.name());
    }
}
