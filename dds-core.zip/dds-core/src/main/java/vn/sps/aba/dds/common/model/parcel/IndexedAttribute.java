/*
 * Class: Attribute
 *
 * Created on Jun 22, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.parcel;

/**
 * Contains the paths to classes and their variables that need to be indexed for
 * caching. The paths can also be used when querying caching data.
 */
public class IndexedAttribute {

    /** The ident code. */
    public static String IDENT_CODE = "identCode";

    /** The received time. */
    public static String RECEIVED_TIME = "receivedTime";

    /**
     * Instantiates a new indexed attribute.
     */
    private IndexedAttribute() {
    }
}
