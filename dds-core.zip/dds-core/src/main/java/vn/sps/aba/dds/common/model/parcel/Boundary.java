/*
 * Class: Coordination
 *
 * Created on May 19, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.parcel;

import java.io.Serializable;

/**
 * The Class Boundary.
 */
public class Boundary implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 7160225551424753882L;

    /** The x1. */
    private String x1;

    /** The x2. */
    private String x2;

    /** The x3. */
    private String x3;

    /** The x4. */
    private String x4;

    /** The y1. */
    private String y1;

    /** The y2. */
    private String y2;

    /** The y3. */
    private String y3;

    /** The y4. */
    private String y4;

    /**
     * Instantiates a new boundary.
     */
    public Boundary() {
    }

    /**
     * Instantiates a new Boundary.
     *
     * @param barcode the <tt>Barcode</tt> object sent/received via SOAP web
     * service
     */
    public Boundary(final vn.sps.aba.dds.common.types.ws.pds.parcel.model.Barcode barcode) {
        this.x1 = barcode.getX1();
        this.y1 = barcode.getY1();
        this.x2 = barcode.getX2();
        this.y2 = barcode.getY2();
        this.x3 = barcode.getX3();
        this.y3 = barcode.getY3();
        this.x4 = barcode.getX4();
        this.y4 = barcode.getY4();
    }

    /**
     * Instantiates a new Boundary.
     *
     * @param address the <tt>FullAddress</tt> object sent/received via SOAP web
     * service
     */
    public Boundary(final vn.sps.aba.dds.common.types.ws.pds.parcel.model.FullAddress address) {
        this.x1 = address.getX1();
        this.y1 = address.getY1();
        this.x2 = address.getX2();
        this.y2 = address.getY2();
        this.x3 = address.getX3();
        this.y3 = address.getY3();
        this.x4 = address.getX4();
        this.y4 = address.getY4();
    }

    /**
     * Gets the x1.
     *
     * @return Returns the x1.
     */
    public String getX1() {
        return this.x1;
    }

    /**
     * Gets the x2.
     *
     * @return Returns the x2.
     */
    public String getX2() {
        return this.x2;
    }

    /**
     * Gets the x3.
     *
     * @return Returns the x3.
     */
    public String getX3() {
        return this.x3;
    }

    /**
     * Gets the x4.
     *
     * @return Returns the x4.
     */
    public String getX4() {
        return this.x4;
    }

    /**
     * Gets the y1.
     *
     * @return Returns the y1.
     */
    public String getY1() {
        return this.y1;
    }

    /**
     * Gets the y2.
     *
     * @return Returns the y2.
     */
    public String getY2() {
        return this.y2;
    }

    /**
     * Gets the y3.
     *
     * @return Returns the y3.
     */
    public String getY3() {
        return this.y3;
    }

    /**
     * Gets the y4.
     *
     * @return Returns the y4.
     */
    public String getY4() {
        return this.y4;
    }

    /**
     * Sets the x1.
     *
     * @param x1 The x1 to set.
     */
    public void setX1(final String x1) {
        this.x1 = x1;
    }

    /**
     * Sets the x2.
     *
     * @param x2 The x2 to set.
     */
    public void setX2(final String x2) {
        this.x2 = x2;
    }

    /**
     * Sets the x3.
     *
     * @param x3 The x3 to set.
     */
    public void setX3(final String x3) {
        this.x3 = x3;
    }

    /**
     * Sets the x4.
     *
     * @param x4 The x4 to set.
     */
    public void setX4(final String x4) {
        this.x4 = x4;
    }

    /**
     * Sets the y1.
     *
     * @param y1 The y1 to set.
     */
    public void setY1(final String y1) {
        this.y1 = y1;
    }

    /**
     * Sets the y2.
     *
     * @param y2 The y2 to set.
     */
    public void setY2(final String y2) {
        this.y2 = y2;
    }

    /**
     * Sets the y3.
     *
     * @param y3 The y3 to set.
     */
    public void setY3(final String y3) {
        this.y3 = y3;
    }

    /**
     * Sets the y4.
     *
     * @param y4 The y4 to set.
     */
    public void setY4(final String y4) {
        this.y4 = y4;
    }

}
