/*
 * Class: ParcelAddress
 *
 * Created on May 19, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.parcel;

import java.io.Serializable;

/**
 * The Class ParcelAddress.
 */
public class ParcelAddress implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -6190449253785172583L;

    /** The address type. */
    private String addressType;

    /** The house number. */
    private String houseNumber;

    /** The log type. */
    private Integer logType;

    /** The plz type. */
    private Integer plzType;

    /** The street number. */
    private String streetNumber;

    /** The zip. */
    private String zip;

    /**
     * Instantiates a new parcel address.
     */
    public ParcelAddress() {
    }

    /**
     * Instantiates a new parcel address.
     *
     * @param parcelAddress the parcel address
     */
    public ParcelAddress(final vn.sps.aba.dds.common.types.ws.pds.parcel.model.ParcelAddress parcelAddress) {
        this.addressType = parcelAddress.getAddressType();
        this.houseNumber = parcelAddress.getHousenumber();
        this.streetNumber = parcelAddress.getStreetnumber();
        this.zip = parcelAddress.getZip();
    }

    /**
     * Gets the address type.
     *
     * @return Returns the addressType.
     */
    public String getAddressType() {
        return this.addressType;
    }

    /**
     * Gets the house number.
     *
     * @return Returns the houseNumber.
     */
    public String getHouseNumber() {
        return this.houseNumber;
    }

    /**
     * Gets the log type.
     *
     * @return the log type
     */
    public Integer getLogType() {
        return this.logType;
    }

    /**
     * Gets the plz type.
     *
     * @return the plz type
     */
    public Integer getPlzType() {
        return this.plzType;
    }

    /**
     * Gets the street number.
     *
     * @return Returns the streetNumber.
     */
    public String getStreetNumber() {
        return this.streetNumber;
    }

    /**
     * Gets the zip.
     *
     * @return Returns the zip.
     */
    public String getZip() {
        return this.zip;
    }

    /**
     * Sets the address type.
     *
     * @param addressType
     *            The addressType to set.
     */
    public void setAddressType(final String addressType) {
        this.addressType = addressType;
    }

    /**
     * Sets the house number.
     *
     * @param houseNumber
     *            The houseNumber to set.
     */
    public void setHouseNumber(final String houseNumber) {
        this.houseNumber = houseNumber;
    }

    /**
     * Sets the log type.
     *
     * @param logType the new log type
     */
    public void setLogType(Integer logType) {
        this.logType = logType;
    }

    /**
     * Sets the plz type.
     *
     * @param plzType the new plz type
     */
    public void setPlzType(Integer plzType) {
        this.plzType = plzType;
    }

    /**
     * Sets the street number.
     *
     * @param streetNumber
     *            The streetNumber to set.
     */
    public void setStreetNumber(final String streetNumber) {
        this.streetNumber = streetNumber;
    }

    /**
     * Sets the zip.
     *
     * @param zip
     *            The zip to set.
     */
    public void setZip(final String zip) {
        this.zip = zip;
    }

    /**
     * {@inheritDoc}
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();

        sb.append("AddressType:").append(this.addressType).append(";Zip:").append(this.zip).append(";StreetNumber:").append(this.streetNumber)
            .append(";HouseNumber:").append(this.houseNumber);

        return sb.toString();
    }

}
