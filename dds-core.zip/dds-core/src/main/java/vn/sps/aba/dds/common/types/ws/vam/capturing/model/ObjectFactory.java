
package vn.sps.aba.dds.common.types.ws.vam.capturing.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the vn.sps.aba.dds.service.vam.capturing.model package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _UnsignedLong_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedLong");
    private final static QName _UnsignedByte_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedByte");
    private final static QName _UnsignedShort_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedShort");
    private final static QName _Duration_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "duration");
    private final static QName _EPersStatus_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "ePersStatus");
    private final static QName _AddressFields_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "AddressFields");
    private final static QName _CaptureResultOut_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "CaptureResultOut");
    private final static QName _Long_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "long");
    private final static QName _Float_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "float");
    private final static QName _ECaptureResultCode_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "eCaptureResultCode");
    private final static QName _EAmpStatus_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "eAmpStatus");
    private final static QName _DateTime_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "dateTime");
    private final static QName _Timestamps_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Timestamps");
    private final static QName _AnyType_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "anyType");
    private final static QName _String_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "string");
    private final static QName _CaptureInfo_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "CaptureInfo");
    private final static QName _ParcelData_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "ParcelData");
    private final static QName _AdresseErfassung_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "AdresseErfassung");
    private final static QName _ArrayOfProduktZusatzLeistung_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "ArrayOfProduktZusatzLeistung");
    private final static QName _UnsignedInt_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedInt");
    private final static QName _Char_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "char");
    private final static QName _EPersType_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "ePersType");
    private final static QName _Short_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "short");
    private final static QName _Guid_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "guid");
    private final static QName _ProduktZusatzLeistung_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "ProduktZusatzLeistung");
    private final static QName _Decimal_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "decimal");
    private final static QName _Boolean_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "boolean");
    private final static QName _Base64Binary_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "base64Binary");
    private final static QName _CaptureResultRecord_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "CaptureResultRecord");
    private final static QName _Int_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "int");
    private final static QName _VolleAdresse_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "VolleAdresse");
    private final static QName _AnyURI_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "anyURI");
    private final static QName _ECaptureAddressType_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "eCaptureAddressType");
    private final static QName _Byte_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "byte");
    private final static QName _Double_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "double");
    private final static QName _QName_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "QName");
    private final static QName _CaptureResultIn_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "CaptureResultIn");
    private final static QName _EDienstleistung_QNAME = new QName("http://schemas.datacontract.org/2004/07/Ch.Post.PL.Vae.Vam.Domain.Enumerations", "eDienstleistung");
    private final static QName _CaptureResultResponseCaptureResultResult_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "CaptureResultResult");
    private final static QName _CaptureResultRequest_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "request");
    private final static QName _AddressFieldsAnrede_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Anrede");
    private final static QName _AddressFieldsLand_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Land");
    private final static QName _AddressFieldsName_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Name");
    private final static QName _AddressFieldsStockwerk_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Stockwerk");
    private final static QName _AddressFieldsLaenderCode_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "LaenderCode");
    private final static QName _AddressFieldsHausnummerZusatz_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "HausnummerZusatz");
    private final static QName _AddressFieldsNameZusatz_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "NameZusatz");
    private final static QName _AddressFieldsKundennummer_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Kundennummer");
    private final static QName _AddressFieldsPostleitzahl_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Postleitzahl");
    private final static QName _AddressFieldsDienstleistung_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Dienstleistung");
    private final static QName _AddressFieldsPostfach_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Postfach");
    private final static QName _AddressFieldsStrasse_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Strasse");
    private final static QName _AddressFieldsVorname_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Vorname");
    private final static QName _AddressFieldsFirmenname_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Firmenname");
    private final static QName _AddressFieldsCoAdresse_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "CoAdresse");
    private final static QName _AddressFieldsAdressZusatz_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "AdressZusatz");
    private final static QName _AddressFieldsOrt_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "Ort");
    private final static QName _AdresseErfassungTypedFields_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "TypedFields");
    private final static QName _CaptureResultRecordSenderId_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "SenderId");
    private final static QName _VolleAdressePersType_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "PersType");
    private final static QName _VolleAdresseParcelHausKey_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "ParcelHausKey");
    private final static QName _VolleAdresseKdpId_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "KdpId");
    private final static QName _VolleAdressePersStatus_QNAME = new QName("Ch.Post.PL.Vae.Vam.CaptureResultService", "PersStatus");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: vn.sps.aba.dds.service.vam.capturing.model
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CaptureResultResponse }
     * 
     */
    public CaptureResultResponse createCaptureResultResponse() {
        return new CaptureResultResponse();
    }

    /**
     * Create an instance of {@link CaptureResultOut }
     * 
     */
    public CaptureResultOut createCaptureResultOut() {
        return new CaptureResultOut();
    }

    /**
     * Create an instance of {@link CaptureResult }
     * 
     */
    public CaptureResult createCaptureResult() {
        return new CaptureResult();
    }

    /**
     * Create an instance of {@link CaptureResultIn }
     * 
     */
    public CaptureResultIn createCaptureResultIn() {
        return new CaptureResultIn();
    }

    /**
     * Create an instance of {@link ProduktZusatzLeistung }
     * 
     */
    public ProduktZusatzLeistung createProduktZusatzLeistung() {
        return new ProduktZusatzLeistung();
    }

    /**
     * Create an instance of {@link AdresseErfassung }
     * 
     */
    public AdresseErfassung createAdresseErfassung() {
        return new AdresseErfassung();
    }

    /**
     * Create an instance of {@link ArrayOfProduktZusatzLeistung }
     * 
     */
    public ArrayOfProduktZusatzLeistung createArrayOfProduktZusatzLeistung() {
        return new ArrayOfProduktZusatzLeistung();
    }

    /**
     * Create an instance of {@link CaptureInfo }
     * 
     */
    public CaptureInfo createCaptureInfo() {
        return new CaptureInfo();
    }

    /**
     * Create an instance of {@link ParcelData }
     * 
     */
    public ParcelData createParcelData() {
        return new ParcelData();
    }

    /**
     * Create an instance of {@link Timestamps }
     * 
     */
    public Timestamps createTimestamps() {
        return new Timestamps();
    }

    /**
     * Create an instance of {@link VolleAdresse }
     * 
     */
    public VolleAdresse createVolleAdresse() {
        return new VolleAdresse();
    }

    /**
     * Create an instance of {@link CaptureResultRecord }
     * 
     */
    public CaptureResultRecord createCaptureResultRecord() {
        return new CaptureResultRecord();
    }

    /**
     * Create an instance of {@link AddressFields }
     * 
     */
    public AddressFields createAddressFields() {
        return new AddressFields();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedLong")
    public JAXBElement<BigInteger> createUnsignedLong(BigInteger value) {
        return new JAXBElement<BigInteger>(_UnsignedLong_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Short }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedByte")
    public JAXBElement<Short> createUnsignedByte(Short value) {
        return new JAXBElement<Short>(_UnsignedByte_QNAME, Short.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedShort")
    public JAXBElement<Integer> createUnsignedShort(Integer value) {
        return new JAXBElement<Integer>(_UnsignedShort_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Duration }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "duration")
    public JAXBElement<Duration> createDuration(Duration value) {
        return new JAXBElement<Duration>(_Duration_QNAME, Duration.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EPersStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "ePersStatus")
    public JAXBElement<EPersStatus> createEPersStatus(EPersStatus value) {
        return new JAXBElement<EPersStatus>(_EPersStatus_QNAME, EPersStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressFields }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "AddressFields")
    public JAXBElement<AddressFields> createAddressFields(AddressFields value) {
        return new JAXBElement<AddressFields>(_AddressFields_QNAME, AddressFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureResultOut }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "CaptureResultOut")
    public JAXBElement<CaptureResultOut> createCaptureResultOut(CaptureResultOut value) {
        return new JAXBElement<CaptureResultOut>(_CaptureResultOut_QNAME, CaptureResultOut.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "long")
    public JAXBElement<Long> createLong(Long value) {
        return new JAXBElement<Long>(_Long_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Float }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "float")
    public JAXBElement<Float> createFloat(Float value) {
        return new JAXBElement<Float>(_Float_QNAME, Float.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ECaptureResultCode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "eCaptureResultCode")
    public JAXBElement<ECaptureResultCode> createECaptureResultCode(ECaptureResultCode value) {
        return new JAXBElement<ECaptureResultCode>(_ECaptureResultCode_QNAME, ECaptureResultCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EAmpStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "eAmpStatus")
    public JAXBElement<EAmpStatus> createEAmpStatus(EAmpStatus value) {
        return new JAXBElement<EAmpStatus>(_EAmpStatus_QNAME, EAmpStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "dateTime")
    public JAXBElement<XMLGregorianCalendar> createDateTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_DateTime_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Timestamps }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Timestamps")
    public JAXBElement<Timestamps> createTimestamps(Timestamps value) {
        return new JAXBElement<Timestamps>(_Timestamps_QNAME, Timestamps.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "anyType")
    public JAXBElement<Object> createAnyType(Object value) {
        return new JAXBElement<Object>(_AnyType_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "string")
    public JAXBElement<String> createString(String value) {
        return new JAXBElement<String>(_String_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "CaptureInfo")
    public JAXBElement<CaptureInfo> createCaptureInfo(CaptureInfo value) {
        return new JAXBElement<CaptureInfo>(_CaptureInfo_QNAME, CaptureInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParcelData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "ParcelData")
    public JAXBElement<ParcelData> createParcelData(ParcelData value) {
        return new JAXBElement<ParcelData>(_ParcelData_QNAME, ParcelData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdresseErfassung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "AdresseErfassung")
    public JAXBElement<AdresseErfassung> createAdresseErfassung(AdresseErfassung value) {
        return new JAXBElement<AdresseErfassung>(_AdresseErfassung_QNAME, AdresseErfassung.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfProduktZusatzLeistung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "ArrayOfProduktZusatzLeistung")
    public JAXBElement<ArrayOfProduktZusatzLeistung> createArrayOfProduktZusatzLeistung(ArrayOfProduktZusatzLeistung value) {
        return new JAXBElement<ArrayOfProduktZusatzLeistung>(_ArrayOfProduktZusatzLeistung_QNAME, ArrayOfProduktZusatzLeistung.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedInt")
    public JAXBElement<Long> createUnsignedInt(Long value) {
        return new JAXBElement<Long>(_UnsignedInt_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "char")
    public JAXBElement<Integer> createChar(Integer value) {
        return new JAXBElement<Integer>(_Char_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EPersType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "ePersType")
    public JAXBElement<EPersType> createEPersType(EPersType value) {
        return new JAXBElement<EPersType>(_EPersType_QNAME, EPersType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Short }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "short")
    public JAXBElement<Short> createShort(Short value) {
        return new JAXBElement<Short>(_Short_QNAME, Short.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "guid")
    public JAXBElement<String> createGuid(String value) {
        return new JAXBElement<String>(_Guid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProduktZusatzLeistung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "ProduktZusatzLeistung")
    public JAXBElement<ProduktZusatzLeistung> createProduktZusatzLeistung(ProduktZusatzLeistung value) {
        return new JAXBElement<ProduktZusatzLeistung>(_ProduktZusatzLeistung_QNAME, ProduktZusatzLeistung.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "decimal")
    public JAXBElement<BigDecimal> createDecimal(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_Decimal_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "boolean")
    public JAXBElement<Boolean> createBoolean(Boolean value) {
        return new JAXBElement<Boolean>(_Boolean_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link byte[]}{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "base64Binary")
    public JAXBElement<byte[]> createBase64Binary(byte[] value) {
        return new JAXBElement<byte[]>(_Base64Binary_QNAME, byte[].class, null, ((byte[]) value));
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureResultRecord }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "CaptureResultRecord")
    public JAXBElement<CaptureResultRecord> createCaptureResultRecord(CaptureResultRecord value) {
        return new JAXBElement<CaptureResultRecord>(_CaptureResultRecord_QNAME, CaptureResultRecord.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "int")
    public JAXBElement<Integer> createInt(Integer value) {
        return new JAXBElement<Integer>(_Int_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VolleAdresse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "VolleAdresse")
    public JAXBElement<VolleAdresse> createVolleAdresse(VolleAdresse value) {
        return new JAXBElement<VolleAdresse>(_VolleAdresse_QNAME, VolleAdresse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "anyURI")
    public JAXBElement<String> createAnyURI(String value) {
        return new JAXBElement<String>(_AnyURI_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link List }{@code <}{@link String }{@code >}{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "eCaptureAddressType")
    public JAXBElement<List<String>> createECaptureAddressType(List<String> value) {
        return new JAXBElement<List<String>>(_ECaptureAddressType_QNAME, ((Class) List.class), null, ((List<String> ) value));
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Byte }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "byte")
    public JAXBElement<Byte> createByte(Byte value) {
        return new JAXBElement<Byte>(_Byte_QNAME, Byte.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "double")
    public JAXBElement<Double> createDouble(Double value) {
        return new JAXBElement<Double>(_Double_QNAME, Double.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "QName")
    public JAXBElement<QName> createQName(QName value) {
        return new JAXBElement<QName>(_QName_QNAME, QName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureResultIn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "CaptureResultIn")
    public JAXBElement<CaptureResultIn> createCaptureResultIn(CaptureResultIn value) {
        return new JAXBElement<CaptureResultIn>(_CaptureResultIn_QNAME, CaptureResultIn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EDienstleistung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/Ch.Post.PL.Vae.Vam.Domain.Enumerations", name = "eDienstleistung")
    public JAXBElement<EDienstleistung> createEDienstleistung(EDienstleistung value) {
        return new JAXBElement<EDienstleistung>(_EDienstleistung_QNAME, EDienstleistung.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureResultOut }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "CaptureResultResult", scope = CaptureResultResponse.class)
    public JAXBElement<CaptureResultOut> createCaptureResultResponseCaptureResultResult(CaptureResultOut value) {
        return new JAXBElement<CaptureResultOut>(_CaptureResultResponseCaptureResultResult_QNAME, CaptureResultOut.class, CaptureResultResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureResultIn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "request", scope = CaptureResult.class)
    public JAXBElement<CaptureResultIn> createCaptureResultRequest(CaptureResultIn value) {
        return new JAXBElement<CaptureResultIn>(_CaptureResultRequest_QNAME, CaptureResultIn.class, CaptureResult.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Anrede", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsAnrede(String value) {
        return new JAXBElement<String>(_AddressFieldsAnrede_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Land", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsLand(String value) {
        return new JAXBElement<String>(_AddressFieldsLand_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Name", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsName(String value) {
        return new JAXBElement<String>(_AddressFieldsName_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Stockwerk", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsStockwerk(String value) {
        return new JAXBElement<String>(_AddressFieldsStockwerk_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "LaenderCode", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsLaenderCode(String value) {
        return new JAXBElement<String>(_AddressFieldsLaenderCode_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "HausnummerZusatz", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsHausnummerZusatz(String value) {
        return new JAXBElement<String>(_AddressFieldsHausnummerZusatz_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "NameZusatz", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsNameZusatz(String value) {
        return new JAXBElement<String>(_AddressFieldsNameZusatz_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Kundennummer", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsKundennummer(String value) {
        return new JAXBElement<String>(_AddressFieldsKundennummer_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Postleitzahl", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsPostleitzahl(String value) {
        return new JAXBElement<String>(_AddressFieldsPostleitzahl_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EDienstleistung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Dienstleistung", scope = AddressFields.class)
    public JAXBElement<EDienstleistung> createAddressFieldsDienstleistung(EDienstleistung value) {
        return new JAXBElement<EDienstleistung>(_AddressFieldsDienstleistung_QNAME, EDienstleistung.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Postfach", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsPostfach(String value) {
        return new JAXBElement<String>(_AddressFieldsPostfach_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Strasse", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsStrasse(String value) {
        return new JAXBElement<String>(_AddressFieldsStrasse_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Vorname", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsVorname(String value) {
        return new JAXBElement<String>(_AddressFieldsVorname_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Firmenname", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsFirmenname(String value) {
        return new JAXBElement<String>(_AddressFieldsFirmenname_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "CoAdresse", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsCoAdresse(String value) {
        return new JAXBElement<String>(_AddressFieldsCoAdresse_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "AdressZusatz", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsAdressZusatz(String value) {
        return new JAXBElement<String>(_AddressFieldsAdressZusatz_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "Ort", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsOrt(String value) {
        return new JAXBElement<String>(_AddressFieldsOrt_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressFields }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "TypedFields", scope = AdresseErfassung.class)
    public JAXBElement<AddressFields> createAdresseErfassungTypedFields(AddressFields value) {
        return new JAXBElement<AddressFields>(_AdresseErfassungTypedFields_QNAME, AddressFields.class, AdresseErfassung.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParcelData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "ParcelData", scope = CaptureResultRecord.class)
    public JAXBElement<ParcelData> createCaptureResultRecordParcelData(ParcelData value) {
        return new JAXBElement<ParcelData>(_ParcelData_QNAME, ParcelData.class, CaptureResultRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "SenderId", scope = CaptureResultRecord.class)
    public JAXBElement<Integer> createCaptureResultRecordSenderId(Integer value) {
        return new JAXBElement<Integer>(_CaptureResultRecordSenderId_QNAME, Integer.class, CaptureResultRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EPersType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "PersType", scope = VolleAdresse.class)
    public JAXBElement<EPersType> createVolleAdressePersType(EPersType value) {
        return new JAXBElement<EPersType>(_VolleAdressePersType_QNAME, EPersType.class, VolleAdresse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "ParcelHausKey", scope = VolleAdresse.class)
    public JAXBElement<String> createVolleAdresseParcelHausKey(String value) {
        return new JAXBElement<String>(_VolleAdresseParcelHausKey_QNAME, String.class, VolleAdresse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "KdpId", scope = VolleAdresse.class)
    public JAXBElement<String> createVolleAdresseKdpId(String value) {
        return new JAXBElement<String>(_VolleAdresseKdpId_QNAME, String.class, VolleAdresse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EPersStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "Ch.Post.PL.Vae.Vam.CaptureResultService", name = "PersStatus", scope = VolleAdresse.class)
    public JAXBElement<EPersStatus> createVolleAdressePersStatus(EPersStatus value) {
        return new JAXBElement<EPersStatus>(_VolleAdressePersStatus_QNAME, EPersStatus.class, VolleAdresse.class, value);
    }

}
