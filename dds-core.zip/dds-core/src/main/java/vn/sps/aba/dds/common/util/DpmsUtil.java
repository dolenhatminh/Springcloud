/*
 * Class: DpmsUtil
 *
 * Created on Aug 19, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.util;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class DpmsUtil.
 */
public final class DpmsUtil {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DpmsUtil.class);

    /**
     * Check version.
     *
     * @param version the version
     * @param versionRange the version range
     * @return true, if successful
     */
    public static boolean checkVersion(final String version, final int[] versionRange) {

        final Integer versionInt = string2Integer(version, "Version");
        if (versionInt != null) {
            return (versionInt >= versionRange[0]) && (versionInt <= versionRange[1]);
        }
        return false;
    }

    /**
     * Invalid format.
     *
     * @param fieldName the field name
     * @param value the value
     * @param clazz the clazz
     */
    private static void invalidFormat(final String fieldName, final String value, final Class<?> clazz) {
        LOG.error(fieldName + " has invalid " + clazz.getSimpleName() + " format: " + value);
    }

    /**
     * String2 gregorian calendar.
     *
     * @param value the value
     * @param fieldName the field name
     * @return the XML gregorian calendar
     */
    public static XMLGregorianCalendar string2GregorianCalendar(final String value, final String fieldName) {
        try {
            return value == null ? null : DatatypeFactory.newInstance().newXMLGregorianCalendar(value);
        }
        catch (final DatatypeConfigurationException e) {
            DpmsUtil.invalidFormat(fieldName, value, XMLGregorianCalendar.class);
            LOG.debug(e.getMessage(), e);
        }
        return null;
    }

    /**
     * String2 integer.
     *
     * @param value the value
     * @param fieldName the field name
     * @return the integer
     */
    public static Integer string2Integer(final String value, final String fieldName) {
        try {
            return value == null ? null : Integer.valueOf(value);
        }
        catch (final NumberFormatException e) {
            DpmsUtil.invalidFormat(fieldName, value, Integer.class);
            LOG.debug(e.getMessage(), e);
        }
        return null;
    }

    /**
     * Instantiates a new dpms util.
     */
    private DpmsUtil() {
    }
}
