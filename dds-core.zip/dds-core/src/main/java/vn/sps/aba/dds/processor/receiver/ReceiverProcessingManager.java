/*
 * Class: ReceiverInfoProcessManager
 *
 * Created on Jul 9, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.receiver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.config.filtering.IVerifiedRuleConfiguration;
import vn.sps.aba.dds.config.service.CaptureResultServiceConfiguration;
import vn.sps.aba.dds.config.task.sender.ReceiverSendingExecutor;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;
import vn.sps.aba.dds.scheduled.sender.IScheduledSender;
import vn.sps.aba.dds.sender.receiver.interfaces.IMatchMakerSender;
import vn.sps.aba.dds.sender.receiver.interfaces.IReceiver2VamSender;
import vn.sps.aba.dds.service.padasa.matchmakerdaten.IMatchMakerDatenService;
import vn.sps.aba.dds.service.vam.ICaptureResultService;

/**
 * The Class ReceiverInfoProcessManager.
 */
@Component
@Profile(value = { Profiles.RECEIVER, Profiles.DPM, Profiles.DPMB, Profiles.DPMS })
public class ReceiverProcessingManager {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ReceiverProcessingManager.class);

    /** The capture result service. */
    @Autowired
    private ICaptureResultService captureResultService;

    /** The capture result service configuration. */
    @Autowired
    private CaptureResultServiceConfiguration captureResultServiceConfiguration;

    /** The match maker daten service. */
    @Autowired
    private IMatchMakerDatenService matchMakerDatenService;

    /** The matchmaker scheduled sender. */
    @Autowired
    @Qualifier("MatchmakerScheduledSender")
    private IScheduledSender<ReceiverInfo> matchmakerScheduledSender;

    /** The match maker sender. */
    @Autowired
    private IMatchMakerSender matchMakerSender;

    /** The rceiver2 vam sender. */
    @Autowired
    private IReceiver2VamSender receiver2VamSender;

    /** The receiver info dpm dao. */
    @Autowired
    private IReceiverInfoCacheDao receiverInfoDpmDao;

    /** The common task executor. */
    @Autowired
    private ReceiverSendingExecutor receiverSendingExecutor;

    /** The vam scheduled sender. */
    @Autowired
    @Qualifier("Receiver2VamScheduledSender")
    private IScheduledSender<ReceiverInfo> vamScheduledSender;

    /** The verified rule configuration. */
    @Autowired
    private IVerifiedRuleConfiguration verifiedRuleConfiguration;

    /**
     * Gets the capture result service.
     *
     * @return the capture result service
     */
    ICaptureResultService getCaptureResultService() {
        return this.captureResultService;
    }

    /**
     * Gets the capture result service configuration.
     *
     * @return the capture result service configuration
     */
    CaptureResultServiceConfiguration getCaptureResultServiceConfiguration() {
        return this.captureResultServiceConfiguration;
    }

    /**
     * Gets the match maker daten service.
     *
     * @return the match maker daten service
     */
    IMatchMakerDatenService getMatchMakerDatenService() {
        return this.matchMakerDatenService;
    }

    /**
     * Gets the matchmaker scheduled sender.
     *
     * @return the matchmaker scheduled sender
     */
    IScheduledSender<ReceiverInfo> getMatchmakerScheduledSender() {
        return this.matchmakerScheduledSender;
    }

    /**
     * Gets the match maker sender.
     *
     * @return the match maker sender
     */
    IMatchMakerSender getMatchMakerSender() {
        return this.matchMakerSender;
    }

    /**
     * Gets the rceiver2 vam sender.
     *
     * @return the rceiver2 vam sender
     */
    IReceiver2VamSender getReceiver2VamSender() {
        return this.receiver2VamSender;
    }

    /**
     * Gets the receiver info dpm dao.
     *
     * @return the receiver info dpm dao
     */
    IReceiverInfoCacheDao getReceiverInfoDpmDao() {
        return this.receiverInfoDpmDao;
    }

    /**
     * Gets the receiver sending executor.
     *
     * @return the receiver sending executor
     */
    ReceiverSendingExecutor getReceiverSendingExecutor() {
        return this.receiverSendingExecutor;
    }

    /**
     * Gets the vam scheduled sender.
     *
     * @return the vam scheduled sender
     */
    IScheduledSender<ReceiverInfo> getVamScheduledSender() {
        return this.vamScheduledSender;
    }

    /**
     * Gets the verified rule configuration.
     *
     * @return the verified rule configuration
     */
    IVerifiedRuleConfiguration getVerifiedRuleConfiguration() {
        return this.verifiedRuleConfiguration;
    }

    /**
     * Submit.
     *
     * @param receiverInfo the receiver info
     */
    public void submit(final ReceiverInfo receiverInfo) {
        switch (receiverInfo.getReceiverState()) {
        /** BUC-3: ABA-89: this state will be not match PDS*/
		case VAM_PADASA_READY_NOT_MATCHING:
			LOG.info(IndexMaker.index(receiverInfo), "Submit receiver info to VAM sender");
			this.receiver2VamSender.submitItem(receiverInfo);
			LOG.info(IndexMaker.index(receiverInfo), "Submit receiver info to MatchMaker sender");
			this.matchMakerSender.submitItem(receiverInfo);
			break;
        case VAM_PADASA_READY:
            LOG.info(IndexMaker.index(receiverInfo), "Submit receiver info to VAM sender");
            this.receiver2VamSender.submitItem(receiverInfo);
            LOG.info(IndexMaker.index(receiverInfo), "Submit receiver info to MatchMaker sender");
            this.matchMakerSender.submitItem(receiverInfo);
            break;
        case VAM_READY:
            LOG.info(IndexMaker.index(receiverInfo), "Submit receiver info to VAM sender");
            this.receiver2VamSender.submitItem(receiverInfo);
            break;
        case VERIFIED:
            LOG.info(IndexMaker.index(receiverInfo), "Submit receiver info to VAM sender");
            this.receiver2VamSender.submitItem(receiverInfo);
            LOG.info(IndexMaker.index(receiverInfo), "Submit receiver info to MatchMaker sender");
            this.matchMakerSender.submitItem(receiverInfo);
            break;
        default:
            break;
        }
    }
}
