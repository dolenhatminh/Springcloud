/*
 * Class: StateNewHandler
 *
 * Created on Jul 3, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.parcel.handers.impl;

import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.util.BusinessUtil;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.parcel.handers.IParcelStepHandler;
import vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext;

/**
 * The Class StateNewHandler.
 */
public class InitializingHandler extends AbstractParcelStepHandler implements IParcelStepHandler {

    /**
     * The LOG.
     */
    private static final Logger LOG = LoggerFactory.getLogger(InitializingHandler.class);

    /**
     * Instantiates a new state new handler.
     */
    public InitializingHandler() {
        super(PARCEL_STATE_NEW);
    }

    /**
     * Handle.
     *
     * @param context the context
     * @param parcelInfo the parcel info
     * @throws InterruptedException the interrupted exception
     * @throws ExecutionException the execution exception
     */
    @Override
    public void handle(final IParcelStateHandlerContext context, final ParcelInfo parcelInfo) throws InterruptedException, ExecutionException {

        LOG.info(IndexMaker.index(parcelInfo), "Start processing parcel info");

        try {
            parcelInfo.setDestinationId(BusinessUtil.extractGroup(parcelInfo.getDestinationStation(), context.getDestinationPattern()));
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.index(parcelInfo), "Failed to find the destination id for parcel", e);
        }
        try {
            parcelInfo.setSourceId(BusinessUtil.extractGroup(parcelInfo.getSourceStation(), context.getSourcePattern()));
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.index(parcelInfo), "Failed to find the source id for parcel", e);
        }
        context.transmitState(parcelInfo, ParcelState.FILTERING);

        context.handle(PARCEL_STATE_FILTERING, parcelInfo);
    }

}
