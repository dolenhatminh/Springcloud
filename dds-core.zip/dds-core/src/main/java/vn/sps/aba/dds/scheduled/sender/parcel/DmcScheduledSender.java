/*
 * Class: BarcodeScheduledSender
 *
 * Created on Oct 12, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.sender.parcel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.Enumeration.DmcState;
import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.scheduler.DdsScheduler;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.service.dmc.IDataMatrixCodingService;

/**
 * The Class MatchmakerScheduledSender.
 */
@Configuration
@Component("DmcScheduledSender")
@ConfigurationProperties("schedule.resend.dmc")
public class DmcScheduledSender extends AbstractParcelInfoSender {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DmcScheduledSender.class);

    /** The match maker daten service. */
    @Autowired
    private IDataMatrixCodingService dataMatrixCodingService;

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.scheduled.sender.AbstractScheduledSender#buildSenderExecutor()
     */
    @Override
    protected void buildSenderExecutor() {
        this.scheduledExecutor = new DdsScheduler() {

            @Override
            public String getName() {
                return "resend-dmc-scheduler-";
            }

            @Override
            public ThreadPoolTaskScheduler getScheduler() {
                final ThreadPoolTaskScheduler executor = new ThreadPoolTaskScheduler();
                {
                    final ThreadPoolTaskScheduler scheduler = executor;
                    scheduler.setBeanName(this.getName());
                    scheduler.setThreadNamePrefix(TaskConfiguration.TASK_PREFIX + this.getName());
                    scheduler.setPoolSize(getParallel());
                    scheduler.setRemoveOnCancelPolicy(isRemoveOnCancel());
                    scheduler.initialize();
                    LOG.info(
                        "Create sender thread pool task executor {}. Core pool: {}. Max pool: {}",
                        getName(),
                        scheduler.getPoolSize(),
                        scheduler.getScheduledThreadPoolExecutor().getMaximumPoolSize());
                }
                return executor;
            }
        };
    }
    
    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#getDestinationServiceName()
     */
    @Override
    protected String getDestinationServiceName() {
        return "DMC";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#mergeAndStore(java.lang.String, java.util.Iterator, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    protected void mergeAndStore(final String key, final ParcelInfo parcelInfo) {
        try {
            ParcelInfo ret = this.parcelInfoDao.get(key);
            if (ret != null) {
                ret.setState(parcelInfo.getParcelState());
                ret.setDmcBegin(parcelInfo.getDmcBegin());
                ret.setDmcSent(parcelInfo.getDmcSent());
                ret.setDmcCount(parcelInfo.getDmcCount());
            }
            else {
                ret = parcelInfo;
                LOG.info(IndexMaker.index(key), "Cannot find any parcel match with key");
            }
            this.parcelInfoDao.store(key, ret);
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when merge and store parcel into database.", e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#needToSent(java.lang.String, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    protected boolean needToSent(final String key, final ParcelInfo parcelInfo) {
        return DmcState.NOT_YET == parcelInfo.getDmcState();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#resendParcel(java.lang.String, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    protected boolean resend(final String key, final ParcelInfo parcelInfo) {
        try {
            LOG.info(IndexMaker.index(parcelInfo), "Request for DMC processing");
            final DMCResponse response = this.dataMatrixCodingService.forwardToDmc(parcelInfo);
            if (response != null) {
                parcelInfo.setDmcState(DmcState.DMC_SENT);
                LOG.info(IndexMaker.index(parcelInfo), "Request for DMC processing successfully.");
                return true;
            }
            else {
                LOG.info(IndexMaker.index(parcelInfo), "Failed to request for DMC processing !");
            }
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when re-send DMC.", e);
        }
        return false;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#taskName()
     */
    @Override
    public String taskName() {
        return "dmc-scheduled-sender";
    }

}
