/*
 * Class: ResponseCodeProvider
 *
 * Created on Jul 26, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.reponsecode;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.http.util.Asserts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.types.message.DDSResponseList;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.util.FileUtil;
import vn.sps.aba.dds.common.util.StringUtil;
import vn.sps.aba.dds.common.util.XMLUtils;
import vn.sps.aba.dds.jmx.ResponseCodeInfo;

/**
 * The Class ResponseCodeProvider.
 */
@Configuration
@Component("ResponseCodeProvider")
public class ResponseCodeProvider implements ResourceLoaderAware, IResponseCodeProvider, ResponseCodeInfo {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ResponseCodeProvider.class);

    /** The resource loader. */
    private ResourceLoader resourceLoader;

    /** The responses. */
    private final Map<String, Map<String, Response>> responses = new HashMap<>();

    /**
     * Builds the response string.
     *
     * @param source the source
     * @return the string
     */
    private String[] buildResponseString(final String source) {
        final Map<String, Response> sourceMap = this.responses.get(source);
        if (sourceMap != null) {
            final Collection<Response> collection = sourceMap.values();
            final Response[] responseList = collection.toArray(new Response[collection.size()]);
            final String[] ret = new String[responseList.length];
            for (int i = 0; i < responseList.length; i++) {
                ret[i] = responseList[i].toString();
            }
            return ret;
        }

        return null;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.reponsecode.IResponseCodeProvider#find(java.lang.String, java.lang.String)
     */
    @Override
    public Response find(final String source, final String key) {
        return this.responses.get(source).get(key);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ResponseCodeInfo#getBarcodeResponseCode()
     */
    @Override
    public String[] listBarcodeResponseCode() {
        return this.buildResponseString(DDSConstant.Source.E134);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ResponseCodeInfo#getBlackboxResponseCode()
     */
    @Override
    public String[] listBlackboxResponseCode() {
        return this.buildResponseString(DDSConstant.Source.E119);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ResponseCodeInfo#getMatchMakerResponseCode()
     */
    @Override
    public String[] listMatchMakerResponseCode() {
        return this.buildResponseString(DDSConstant.Source.E138);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ResponseCodeInfo#getVamResponseCode()
     */
    @Override
    public String[] listVamResponseCode() {
        return this.buildResponseString(DDSConstant.Source.E128);
    }

    /**
     * Load response config.
     *
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @PostConstruct
    public void loadResponseConfig() throws IOException {

        String responseCodeConfigurationFile = "classpath:./schema/responsecode.xml";

        LOG.info("Found responsecode configuration inside jar");
        if (FileUtil.exist(FileUtil.currentLocation() + "/config/responsecode.xml")) {
        	if (FileUtil.currentLocation().contains("\\")) {
				responseCodeConfigurationFile = "file:" + FileUtil.currentLocation() + "\\config\\responsecode.xml";
			} else {
				responseCodeConfigurationFile = "file://" + FileUtil.currentLocation() + "/config/responsecode.xml";
			}
            LOG.info("Found responsecode configuration from " + responseCodeConfigurationFile);
        }
        final DDSResponseList responseList = XMLUtils
            .deserialize(this.resourceLoader.getResource(responseCodeConfigurationFile).getInputStream(), DDSResponseList.class);
        if (responseList != null) {

            for (final Response resp : responseList.getResponses()) {

                final String sourceKey = resp.getSource();
                Assert.notNull(sourceKey, "Source must not be null");
                Asserts.notEmpty(sourceKey, "Source must not be empty");

                Map<String, Response> source = this.responses.get(sourceKey);
                if (source == null) {
                    source = new HashMap<>();
                }
                final String key = resp.getKey();

                Assert.notNull(key, "Key must not be null");
                Asserts.notEmpty(key, "Key must not be empty");

                source.put(key, resp);
                this.responses.put(sourceKey, source);
            }
            LOG.warn("The reasons listed in the responsecode.xml will be ignored");
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ResponseCodeInfo#putBarcodeResponseCode(java.lang.String, java.lang.String)
     */
    @Override
    public void putBarcodeResponseCode(final String key, final String value) {
        this.updateCode(DDSConstant.Source.E134, key, value);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ResponseCodeInfo#putBlackboxResponseCode(java.lang.String, java.lang.String)
     */
    @Override
    public void putBlackboxResponseCode(final String key, final String value) {
        this.updateCode(DDSConstant.Source.E119, key, value);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ResponseCodeInfo#putMatchMakerResponseCode(java.lang.String, java.lang.String)
     */
    @Override
    public void putMatchMakerResponseCode(final String key, final String value) {
        this.updateCode(DDSConstant.Source.E138, key, value);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ResponseCodeInfo#putVamResponseCode(java.lang.String, java.lang.String)
     */
    @Override
    public void putVamResponseCode(final String key, final String value) {
        this.updateCode(DDSConstant.Source.E128, key, value);
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.context.ResourceLoaderAware#setResourceLoader(org.springframework.core.io.ResourceLoader)
     */
    @Override
    public void setResourceLoader(final ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    /**
     * Update code.
     *
     * @param codeList the code list
     * @param key the key
     * @param value the value
     */
    private void updateCode(final String codeList, final String key, final String value) {
        if (StringUtil.notNullOrEmpty(codeList) && StringUtil.notNullOrEmpty(key)) {
            final Map<String, Response> map = this.responses.get(codeList);
            if (map != null) {
                final Response response = map.get(key);
                if (response != null) {
                    response.setCode(value);
                }
            }
        }
    }

}
