package vn.sps.aba.dds.service.lookup.ampplus;

import vn.sps.aba.dds.common.model.lookup.AsdpPlz;

/**
 * The Interface IAMPPlusLookupService.
 */
public interface IAMPPlusLookupService {
	
	/**
	 * Gets the amp plus.
	 *
	 * @param plz the plz
	 * @return the amp plus
	 */
	AsdpPlz getAmpPlus(String plz);
    
}