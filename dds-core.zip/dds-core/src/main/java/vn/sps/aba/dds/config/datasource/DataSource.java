package vn.sps.aba.dds.config.datasource;

/**
 * The Class DataSourceConfiguration.
 */
public class DataSource extends org.springframework.jdbc.datasource.DriverManagerDataSource {

}
