/*
 * Class: SimpleErrorHandler
 *
 * Created on Oct 8, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.dpms.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.xml.validation.ValidationErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * The Class SimpleErrorHandler.
 */
public class SimpleErrorHandler implements ValidationErrorHandler {
    /** The errors. */
    private final List<SAXParseException> errors = new ArrayList<>();

    /**
     * {@inheritDoc}
     *
     * @see org.xml.sax.ErrorHandler#error(org.xml.sax.SAXParseException)
     */
    @Override
    public void error(final SAXParseException exception) throws SAXException {
        this.errors.add(exception);
    }

    /**
     * {@inheritDoc}
     *
     * @see org.xml.sax.ErrorHandler#fatalError(org.xml.sax.SAXParseException)
     */
    @Override
    public void fatalError(final SAXParseException exception) throws SAXException {
        this.errors.add(exception);
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.xml.validation.ValidationErrorHandler#getErrors()
     */
    @Override
    public SAXParseException[] getErrors() {
        return this.errors.toArray(new SAXParseException[this.errors.size()]);
    }

    /**
     * {@inheritDoc}
     *
     * @see org.xml.sax.ErrorHandler#warning(org.xml.sax.SAXParseException)
     */
    @Override
    public void warning(final SAXParseException exception) throws SAXException {

    }
}
