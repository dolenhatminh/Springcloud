/*
 * Class: CaptureResultTask
 *
 * Created on Oct 11, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.sender.parcel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.scheduler.DdsScheduler;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.service.vam.ICaptureResultService;

/**
 * The Class CaptureResultScheduledSender.
 */
@Configuration
@Component("Parcel2VamScheduledSender")
@ConfigurationProperties("schedule.resend.vam.parcel")
public class Parcel2VamScheduledSender extends AbstractParcelInfoSender {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(Parcel2VamScheduledSender.class);

    /** The capture result service. */
    @Autowired
    private ICaptureResultService captureResultService;

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.scheduled.sender.AbstractScheduledSender#buildSenderExecutor()
     */
    @Override
    protected void buildSenderExecutor() {
        this.scheduledExecutor = new DdsScheduler() {

            @Override
            public String getName() {
                return "resend-parcel2vam-scheduler-";
            }

            @Override
            public ThreadPoolTaskScheduler getScheduler() {
                final ThreadPoolTaskScheduler executor = new ThreadPoolTaskScheduler();
                {
                    final ThreadPoolTaskScheduler scheduler = executor;
                    scheduler.setBeanName(this.getName());
                    scheduler.setThreadNamePrefix(TaskConfiguration.TASK_PREFIX + this.getName());
                    scheduler.setPoolSize(getParallel());
                    scheduler.setRemoveOnCancelPolicy(isRemoveOnCancel());
                    scheduler.initialize();
                    LOG.info(
                        "Create sender thread pool task executor {}. Core pool: {}. Max pool: {}",
                        getName(),
                        scheduler.getPoolSize(),
                        scheduler.getScheduledThreadPoolExecutor().getMaximumPoolSize());
                }
                return executor;
            }
        };
    }
    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#getDestinationServiceName()
     */
    @Override
    protected String getDestinationServiceName() {
        return "VAM CaptureResult";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#mergeAndStore(java.lang.String, java.util.Iterator, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    protected void mergeAndStore(final String key, final ParcelInfo parcelInfo) {
        try {
            ParcelInfo ret = this.parcelInfoDao.get(key);
            if (ret != null) {
                ret.setState(parcelInfo.getParcelState());
                ret.setCaptureResultBegin(parcelInfo.getCaptureResultBegin());
                ret.setCaptureResultEnd(parcelInfo.getCaptureResultEnd());
                ret.setCaptureResultCount(parcelInfo.getCaptureResultCount());
            }
            else {
                ret = parcelInfo;
                LOG.info(IndexMaker.index(key), "Cannot find any parcel match with key");
            }
            this.parcelInfoDao.store(key, ret);
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when merge and store parcel into database.", e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#needToSent(java.lang.String, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    protected boolean needToSent(final String key, final ParcelInfo parcelInfo) {
        return ParcelState.VAM_CAPTURE_RESULT_READY == parcelInfo.getParcelState();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.parcel.AbstractParcelInfoSender#resendParcel(java.lang.String, vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    protected boolean resend(final String key, final ParcelInfo parcelInfo) {
        try {
            LOG.info(IndexMaker.index(parcelInfo), "Transfering to VAM station");
            if (Parcel2VamScheduledSender.this.captureResultService.transferToVamStation(parcelInfo)) {

                parcelInfo.setState(ParcelState.VAM_CAPTURE_RESULT_SENT);
                LOG.info(IndexMaker.indexes(parcelInfo, "vamCaptureReport"), "Insert log vamCaptureReport");
                LOG.info(IndexMaker.index(parcelInfo), "Forwarded parcel info VAM CaptureResult service successfully");
                return true;
            }
            else {
                LOG.info(IndexMaker.index(parcelInfo), "Failed to forward parcel info to VAM CaptureResult service !");
            }
        }
        catch (final Exception e) {
            LOG.debug(IndexMaker.index(parcelInfo), "There is error when re-send parcel info to VAM CaptureResult.", e);
        }
        return false;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#taskName()
     */
    @Override
    public String taskName() {
        return "vam-scheduled-sender";
    }
}
