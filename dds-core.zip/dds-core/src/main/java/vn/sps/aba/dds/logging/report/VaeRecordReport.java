package vn.sps.aba.dds.logging.report;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.model.parcel.Barcode;
import vn.sps.aba.dds.common.model.parcel.ParcelAddress;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.model.parcel.ProduktZusatzleistung;
import vn.sps.aba.dds.common.model.receiver.AdressErfassung;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.util.DateUtil;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.logging.report.field.IdentCodeOrientation;

/**
 * Log VaeRecord for ABA_Report
 * Class VaeRecordReport
 */
public class VaeRecordReport implements Serializable{
	
	 /** The Constant serialVersionUID. */
	private static final long serialVersionUID = 843103102131438898L;

	/** The LOG */
    private static final Logger LOG = LoggerFactory.getLogger(VaeRecordReport.class);
	
	private AddressFields addressFields = null;
	
	/**
	 * AdresseErfassung Attribute
	 */
	private Integer adrid = null;
	
	private Integer hauskey = null;
	/**
	 * AdresseErfassung Attribute
	 */
	
	private String identCode;
	
	
	/**
	 * Parcel Data Attribute
	 */
	private String destinationStation = null;
	
	private String parPicId = null;
	
	private String parcelDataTimeStamp = null;
	
	private String sourceStation = null;
	
	private List<ProduktZusatzleistung> produktZusatzleistungen;
	
	private Integer vcsCase = null;
	/**
	 * Parcel Data Attribute
	 */
	
	/**
	 * Parcel Address Attribute
	 */
	private Integer streetNumber = null;
	
	private String addressType = null;
	/**
	 * Parcel Address Attribute
	 */
	
	private String pdsTimestamp;
	
	private String discoTimestamp;
	
	private Integer priority;
	
	private String kundennummer;
	
	private Integer dienstleistung;
	
	private IdentCodeOrientation identCodeOrientation;
	
	/*public VaeRecordReport(CaptureRequestRecord captureRequestRecord) {
		if (captureRequestRecord.getAddressFields() != null) {
			this.addressFields = new AddressFields(captureRequestRecord);
		}
		this.setAdresseErfassung(captureRequestRecord);
		this.identCode = captureRequestRecord.getIdentCode() != null ? captureRequestRecord.getIdentCode().getValue() : null;
		this.setParcelData(captureRequestRecord);
		this.setParcelAddress(captureRequestRecord);
		this.pdsTimestamp = DateUtil.gregorian2String(captureRequestRecord.getPDSTimestamp());
		this.discoTimestamp = DateUtil.gregorian2String(captureRequestRecord.getDiscoTimestamp());
		this.priority = captureRequestRecord.getPriority();
		this.kundennummer = captureRequestRecord.getKundennummer() != null ? captureRequestRecord.getKundennummer().getValue() : null;
		this.dienstleistung = captureRequestRecord.getDienstleistung() != null ? captureRequestRecord.getDienstleistung().getValue() : null;
		this.identCodeOrientation = captureRequestRecord.getIdentCodeOrientation();
	}*/
	
	/**
	 * Parse from vn.sps.aba.dds.common.model.parcel.ParcelInfo
	 * @param ParcelInfo
	 */
	public VaeRecordReport(final ParcelInfo parcelInfo) {
		try {
			final ReceiverInfo receiverInfo = parcelInfo.getReceiverInfo();
			final ParcelAddress parcelAddress = parcelInfo.getParcelAddress();
			final List<Barcode> barcodes = parcelInfo.getBarcodes();
			if (receiverInfo != null && receiverInfo.getAdressErfassung() != null) {
				final AdressErfassung adressErfassung = receiverInfo.getAdressErfassung();
				if (adressErfassung.getVolleAdresse() != null ) {
					this.addressFields = new AddressFields(adressErfassung.getVolleAdresse().getAddressFields());
				}
				setAdresseErfassung(receiverInfo);
			} else if (parcelInfo.getFullAddress() != null ){
				this.addressFields = new AddressFields();
				this.addressFields.setOrt(parcelInfo.getFullAddress().getOrt());
				this.addressFields.setPostleitzahl(parcelInfo.getFullAddress().getPostleitzahl());
				this.addressFields.setStrasse(parcelInfo.getFullAddress().getStrasse());
			}
			
			this.identCode = parcelInfo.getIdentCode();
			setParcelData(parcelInfo);
			
			if (parcelAddress != null ) {
				setParcelAddress(parcelAddress);
			}
			this.pdsTimestamp = DateUtil.gregorian2String(parcelInfo.getParcelInfoSentTimestamp());
			this.discoTimestamp = DateUtil.gregorian2String(DateUtil.milli2GregorianCalendar(parcelInfo.getBlackboxBegin()));
			this.priority = null;
			this.kundennummer = null;
			this.dienstleistung = null;
			setIdentCodeOrientation(barcodes);
		} catch (Exception e) {
			LOG.error(IndexMaker.index(parcelInfo), "Could not parse to VaeRecordReport", e);
		}
	}
	
	private void setAdresseErfassung(ReceiverInfo receiverInfo) { 
		if (receiverInfo.getAdressErfassung() != null) {
			this.adrid = null;
			this.hauskey = string2Integer(receiverInfo.getHausKey(), "hauskey");
		}
	}
	
	private void setParcelData(ParcelInfo parcelInfo) {
		this.destinationStation = parcelInfo.getDestinationStation();
		this.parPicId = parcelInfo.getParPicId();
		this.parcelDataTimeStamp = DateUtil.gregorian2String(parcelInfo.getTimeStamp());
		this.sourceStation = parcelInfo.getSourceStation();
		this.produktZusatzleistungen = parcelInfo.getProduktZusatzleistungens();
		this.vcsCase = parcelInfo.getVcsCase();
	}
	
	private void setParcelAddress(ParcelAddress parcelAddress) {
		if (parcelAddress != null) {
			this.streetNumber = string2Integer(parcelAddress.getStreetNumber(), "streetNumber");
			this.addressType = parcelAddress.getAddressType();
		}
	}
	
	/**
	 * @param identCodeOrientation the identCodeOrientation to set
	 */
	private void setIdentCodeOrientation(final List<Barcode> barcodes) {
		boolean hasBarcode = false;
		if (barcodes != null && !barcodes.isEmpty()) {
			for (final Barcode barcode : barcodes) {
				this.identCodeOrientation = new IdentCodeOrientation(barcode);
				hasBarcode = true;
				break;
			}
		}
		if (!hasBarcode) {
			this.identCodeOrientation = new IdentCodeOrientation();
		}
	}

	/**
	 * @return the addressFields
	 */
	public AddressFields getAddressFields() {
		return addressFields;
	}

	/**
	 * @return the adrid
	 */
	public Integer getAdrid() {
		return adrid;
	}

	/**
	 * @return the hauskey
	 */
	public Integer getHauskey() {
		return hauskey;
	}

	/**
	 * @return the identCode
	 */
	public String getIdentCode() {
		return identCode;
	}

	/**
	 * @return the destinationStation
	 */
	public String getDestinationStation() {
		return destinationStation;
	}

	/**
	 * @return the parPicId
	 */
	public String getParPicId() {
		return parPicId;
	}

	/**
	 * @return the parcelDataTimeStamp
	 */
	public String getParcelDataTimeStamp() {
		return parcelDataTimeStamp;
	}

	/**
	 * @return the sourceStation
	 */
	public String getSourceStation() {
		return sourceStation;
	}
	
	public List<ProduktZusatzleistung> getProduktZusatzleistungen() {
		return this.produktZusatzleistungen;
	}

	/**
	 * @return the vcsCase
	 */
	public Integer getVcsCase() {
		return vcsCase;
	}

	/**
	 * @return the streetNumber
	 */
	public Integer getStreetNumber() {
		return streetNumber;
	}

	/**
	 * @return the addressType
	 */
	public String getAddressType() {
		return addressType;
	}

	/**
	 * @return the pdsTimestamp
	 */
	public String getPdsTimestamp() {
		return pdsTimestamp;
	}

	/**
	 * @return the discoTimestamp
	 */
	public String getDiscoTimestamp() {
		return discoTimestamp;
	}

	/**
	 * @return the priority
	 */
	public Integer getPriority() {
		return priority;
	}

	/**
	 * @return the kundennummer
	 */
	public String getKundennummer() {
		return kundennummer;
	}

	/**
	 * @return the dienstleistung
	 */
	public Integer getDienstleistung() {
		return dienstleistung;
	}

	/**
	 * @return the identCodeOrientation
	 */
	public IdentCodeOrientation getIdentCodeOrientation() {
		return identCodeOrientation;
	}

	/**
	 * Inner Class AddressFields
	 * One of VaeRecordReport's Fields
	 */
	private class AddressFields implements Serializable{
		
		 /** The Constant serialVersionUID. */
		private static final long serialVersionUID = -7472070461875373171L;

		/** The anrede.*/
		private String anrede;
		
		/** The coAdresse.*/
		private String coAdresse;
		
		/** The firmenname.*/
		private String firmenname;
		
		/** The hausnummer.*/
		private Integer hausnummer;
		
		/** The hausnummerZusatz.*/
		private String hausnummerZusatz;
		
		/** The land.*/
		private String land;
		
		/** The name.*/
		private String name;
		
		/** The nameZusatz.*/
		private String nameZusatz;
		
		/** The ort.*/
		private String ort;
		
		/** The postfach.*/
		private Integer postfach;
		
		/** The postleitzahl.*/
		private String postleitzahl;
		
		/** The stockwerk.*/
		private String stockwerk;
		
		/** The strasse.*/
		private String strasse;
		
		/** The vorname.*/
		private String vorname;
		
		/**
		 * Parse from vn.sps.aba.dds.common.model.receiver.AddressFields
		 * Without adress zusatz.
		 * @param AddressFields
		 */
		public AddressFields(vn.sps.aba.dds.common.model.receiver.AddressFields addressFields) {
			if (addressFields != null ) {
				this.anrede = addressFields.getAnrede();
				this.coAdresse = addressFields.getCoAdress();
				this.firmenname = addressFields.getFirmeName();
				this.hausnummer = string2Integer(addressFields.getHausNummer(), "hausnummer");
				this.hausnummerZusatz = addressFields.getHausNummerZusatz();
				this.land = addressFields.getLand();
				this.name = addressFields.getName();
				this.nameZusatz = addressFields.getNameZusatz();
				this.ort = addressFields.getOrt();
				this.postfach = string2Integer(addressFields.getPostfach(), "postfach");
				this.postleitzahl = addressFields.getPostleizahl();
				this.stockwerk = addressFields.getStockwerk();
				this.strasse = addressFields.getStrasse();
				this.vorname = addressFields.getVorname();
			}
		}
		
		public AddressFields() {
		}
		
		/**
		 * @param ort the ort to set
		 */
		public void setOrt(String ort) {
			this.ort = ort;
		}

		/**
		 * @param postleitzahl the postleitzahl to set
		 */
		public void setPostleitzahl(String postleitzahl) {
			this.postleitzahl = postleitzahl;
		}

		/**
		 * @param strasse the strasse to set
		 */
		public void setStrasse(String strasse) {
			this.strasse = strasse;
		}

		/**
		 * @return the anrede
		 */
		public String getAnrede() {
			return anrede;
		}
		/**
		 * @return the coAdresse
		 */
		public String getCoAdresse() {
			return coAdresse;
		}
		/**
		 * @return the firmenname
		 */
		public String getFirmenname() {
			return firmenname;
		}
		/**
		 * @return the hausnummer
		 */
		public Integer getHausnummer() {
			return hausnummer;
		}
		/**
		 * @return the hausnummerZusatz
		 */
		public String getHausnummerZusatz() {
			return hausnummerZusatz;
		}
		/**
		 * @return the land
		 */
		public String getLand() {
			return land;
		}
		/**
		 * @return the name
		 */
		public String getName() {
			return name;
		}
		/**
		 * @return the nameZusatz
		 */
		public String getNameZusatz() {
			return nameZusatz;
		}
		/**
		 * @return the ort
		 */
		public String getOrt() {
			return ort;
		}
		/**
		 * @return the postfach
		 */
		public Integer getPostfach() {
			return postfach;
		}
		/**
		 * @return the postleitzahl
		 */
		public String getPostleitzahl() {
			return postleitzahl;
		}
		/**
		 * @return the stockwerk
		 */
		public String getStockwerk() {
			return stockwerk;
		}
		/**
		 * @return the strasse
		 */
		public String getStrasse() {
			return strasse;
		}
		/**
		 * @return the vorname
		 */
		public String getVorname() {
			return vorname;
		}
	}
	
	private static Integer string2Integer(final String value, final String fieldName) {
		try {
			return Integer.valueOf(value);
		} catch (final NumberFormatException e) {
			LOG.error("Cannot parse {} field with value {} to integer", fieldName, value);
			return null;
		}
	}
}
