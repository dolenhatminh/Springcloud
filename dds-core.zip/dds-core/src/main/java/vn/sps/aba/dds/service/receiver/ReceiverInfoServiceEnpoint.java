/*
 * Class: IDPMAddressValidationService
 *
 * Created on Jun 28, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.receiver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import vn.sps.aba.dds.common.constant.DDSConstant.Namespace;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.message.Description;
import vn.sps.aba.dds.common.types.message.MessageBuilder;
import vn.sps.aba.dds.common.types.message.Response;
import vn.sps.aba.dds.common.types.ws.dpm.model.IReceiverInfoService;
import vn.sps.aba.dds.common.types.ws.dpm.model.ObjectFactory;
import vn.sps.aba.dds.common.types.ws.dpm.model.ReceiverInfoRequestType;
import vn.sps.aba.dds.common.types.ws.dpm.model.TransferReceiverInfoRequest;
import vn.sps.aba.dds.common.types.ws.dpm.model.TransferReceiverInfoResponse;
import vn.sps.aba.dds.config.service.ReceiverInfoServiceConfiguration;
import vn.sps.aba.dds.processor.receiver.ReceiverProcessingManager;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;

/**
 * The Class ReceiverInfoServiceEnpoint.
 */
@Profile(Profiles.RECEIVER)
@Endpoint
public final class ReceiverInfoServiceEnpoint implements IReceiverInfoService {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ReceiverInfoServiceEnpoint.class);

    /** The process manager. */
    @Autowired
    private ReceiverProcessingManager processManager;

    /** The receiver info dao. */
    @Autowired
    private IReceiverInfoCacheDao receiverInfoDao;

    /** The service configuration. */
    @Autowired
    private ReceiverInfoServiceConfiguration serviceConfiguration;

    /**
     * Submit processing payload.
     *
     * @param receiverInfoRequestType the receiver info request type
     * @return the response
     */
    private Response submitProcessingPayload(final ReceiverInfoRequestType receiverInfoRequestType) {
        try {

            final String key = receiverInfoRequestType.getReceiverInfo().getIdentcode();
            final vn.sps.aba.dds.common.model.receiver.ReceiverInfo receiverInfo = new vn.sps.aba.dds.common.model.receiver.ReceiverInfo(
                receiverInfoRequestType);
            receiverInfo.setReceived(DiscoWallClock.milli());
            this.receiverInfoDao.put(key, receiverInfo);

            this.processManager.submit(receiverInfo);
            return this.serviceConfiguration.successful();
        }
        catch (final Exception e) {

            LOG.error("Error while processing the receiver info data", e);
            return this.serviceConfiguration.failedToStoreData();
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.types.ws.dpm.model.IReceiverInfoService#transferReceiverInfo(vn.sps.aba.dds.common.types.ws.dpm.model.TransferReceiverInfoRequest)
     */
    @Override
    @PayloadRoot(namespace = Namespace.E120_NAMESPACE, localPart = "TransferReceiverInfoRequest")
    public @ResponsePayload TransferReceiverInfoResponse transferReceiverInfo(@RequestPayload final TransferReceiverInfoRequest receiverInfoRequest) {

        final boolean isDianogRequest = (receiverInfoRequest.getReceiverInfoRequest() == null)
                || (receiverInfoRequest.getReceiverInfoRequest().getValue() == null)
                || (receiverInfoRequest.getReceiverInfoRequest().getValue().getReceiverInfo() == null);
        final ObjectFactory objectFactory = this.serviceConfiguration.getObjectFactory();

        Response response = this.serviceConfiguration.serviceAvailable();

        try {
            if (!isDianogRequest) {

                final ReceiverInfoRequestType receiverInfoRequestType = receiverInfoRequest.getReceiverInfoRequest().getValue();

                response = this.submitProcessingPayload(receiverInfoRequestType);
            }
            else {

                LOG.info("Dianog request: Service available");
            }
        }
        catch (final Exception e) {

            response = this.serviceConfiguration.unexpectedError();
            LOG.error("Error while processing the receiver info data", e);
        }

        return MessageBuilder.buildTransferReceiverInfoResponse(objectFactory, response, new Description());
    }

}
