/*
 * Class: AbstractCacheDao
 *
 * Created on Jun 13, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.cache;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.infinispan.Cache;
import org.infinispan.cache.impl.CacheImpl;
import org.infinispan.container.DataContainer;
import org.infinispan.container.entries.InternalCacheEntry;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.query.Search;
import org.infinispan.query.dsl.FilterConditionContext;
import org.infinispan.query.dsl.QueryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.transaction.TransactionException;

import vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.cache.DDSCacheEntryInfo;
import vn.sps.aba.dds.common.model.cache.IDDSCacheEntry;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.statistic.Status;
import vn.sps.aba.dds.config.cache.CacheConfiguration;
import vn.sps.aba.dds.jmx.DBErrorInfo;
import vn.sps.aba.dds.jmx.DdsCacheInfo;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.repository.cache.event.CacheEvent;
import vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao;
import vn.sps.aba.dds.repository.listener.ICacheListener;
import vn.sps.aba.dds.repository.listener.IMightBeErrorCollector;

/**
 * The Class AbstractCacheDao.
 *
 * @param <K> the key type
 * @param <V> the value type
 */
@SuppressWarnings("rawtypes")
@Configuration
public abstract class AbstractCacheDao<K, V extends Serializable> extends AbstractAsyncWorker
        implements ICacheCommonCacheDao<K, V>, DdsCacheInfo, IMightBeErrorCollector, DBErrorInfo {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(AbstractCacheDao.class);

    /** The cache. */
    private Cache<K, V> cache;

    /** The cache manager. */
    @Autowired
    private DefaultCacheManager cacheManager;

    /** The data source of tomcat jdbc pool. */
    @Autowired
    private DataSource dataSource;

    /** The might error list. */
    private final Set<String> mightErrorList = new HashSet<>();

    /** The query builder. */
    private QueryBuilder queryBuilder;

    /**
     * Adds the default status list.
     *
     * @param statuses the statuses
     */
    protected void appendDefaultStatusList(final List<Status> statuses) {
        final List<String> availableStatuses = new ArrayList<>();
        statuses.stream().forEach((s) -> {
            availableStatuses.add(s.getStatus());
        });

        final String[] runningStates = this.getCacheConfiguration().getRunningStates();
        if (!availableStatuses.isEmpty()) {
            for (final String state : runningStates) {
                if (!availableStatuses.contains(state)) {
                    statuses.add(new Status(state, Long.valueOf(0)));
                }
            }
        }
        else {
            for (final String state : runningStates) {
                statuses.add(new Status(state, Long.valueOf(0)));
            }
        }
    }

    /**
     * Append entry.
     *
     * @param managedInfos the managed infos
     * @param now the now
     * @param e the e
     * @param key the key
     * @param ie the ie
     */
    protected void appendEntry(
        final List<IDDSCacheEntry> managedInfos,
        final long now,
        final InternalCacheEntry<K, V> e,
        final String key,
        final IdentifiedEntry ie) {
        final DDSCacheEntryInfo cacheEntry = new DDSCacheEntryInfo();
        {
            cacheEntry.setCanExpire(e.canExpire());
            cacheEntry.setCreated(e.isCreated());
            cacheEntry.setCreated(e.getCreated());
            cacheEntry.setEvicted(e.isEvicted());
            cacheEntry.setExpired(e.isExpired(now));
            cacheEntry.setExpiryTime(e.getExpiryTime());
            cacheEntry.setLastUsed(e.getLastUsed());
            cacheEntry.setLifespan(e.getLifespan());
            cacheEntry.setMaxIdle(e.getMaxIdle());
            cacheEntry.setRemoved(e.isRemoved());
            cacheEntry.setValid(e.isValid());
            cacheEntry.setKey(key);
            cacheEntry.setIdentCode(ie.getIdentCode());
            cacheEntry.setState(ie.getState());
            cacheEntry.setMinorState(ie.getMinorState());
            cacheEntry.setReceived(ie.getReceived());
        }
        managedInfos.add(cacheEntry);
    }

    /**
     * List by attribute.
     *
     * @param attribute the attribute
     * @param value the value
     * @return the filter condition context
     */
    protected FilterConditionContext appendEqualContext(final String attribute, final String value) {
        return Search.getQueryFactory(this.getCache()).from(this.getClassType()).having(attribute).eq(value);
    }

    /**
     * Append status data.
     *
     * @param statuses the statuses
     * @param list the list
     */
    protected void appendStatusData(final List<Status> statuses, final List<Object> list) {
        try {
            list.stream().forEach((s) -> {
                final Object[] items = (Object[]) s;
                if (items.length > 1) {
                    statuses.add(new Status(String.valueOf(items[0]), Long.valueOf(items[1].toString())));
                }
            });
        }
        catch (final Exception e) {
            LOG.warn("Error when append status data", e);
        }
    }
    
    /**
     * Append status data.
     *
     * @param statuses the statuses
     * @param hashMap<String, Integer> the status data
     */
    @Deprecated
    protected void appendStatusData(final List<Status> statuses, final HashMap<String, Integer> statusData) {
        try {
        	for (Entry<String, Integer> status : statusData.entrySet()) {
        		statuses.add(new Status(status.getKey(), Long.valueOf(status.getValue())));
        	}
        }
        catch (final Exception e) {
            LOG.warn("Error when append status data", e);
        }
    }
    
    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.DdsCacheInfo#changeExpiredLifeSpan(long)
     */
    @Override
    public void changeExpiredLifeSpan(final long lifespan) {
        this.getCacheConfiguration().setExpiredLifeSpan(lifespan);
    }

    /**
     * Check and remove.
     *
     * @param key the key
     * @return the string
     */
    protected String checkAndRemove(final String key) {
        return this.mightErrorList.remove(key) ? key : null;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#clear()
     */
    @Override
    public void clear() {
        this.cache.clear();
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#containKey(java.lang.Object)
     */
    @Override
    public boolean containKey(final K key) {
        return this.cache.containsKey(key);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#count()
     */
    @Override
    public int count() {
        return this.cache.size();
    }

    /**
     * Creates the db worker.
     *
     * @param key the key
     * @param newValue the new value
     * @return the callable
     */
    @SuppressWarnings("unchecked")
    private Callable<Boolean> createDbWorker(final K key, final V newValue) {
        return () -> {
            boolean ret = false;
            final String id = (String) key;
            try {
                LOG.info(IndexMaker.index(id), "Begin persisting data into database");
                long created = 0;
                long lifespan = 0;
                final InternalCacheEntry<K, V> internalCacheEntry = this.getDataContainer().get(key);
                if (internalCacheEntry != null) {
                    created = internalCacheEntry.getCreated();
                    lifespan = internalCacheEntry.getLifespan();
                }
                final CacheEvent<K, V> event = CacheEvent.createEvent(this.cache, key, null, newValue, created, lifespan);

                this.getListener().modify(event);
                this.checkAndRemove(id);
                ret = true;
            }
            catch (final TransactionException e) {
                this.mightErrorList.add(id);
                this.dataSource.purge();
                LOG.warn(
                    "Purges all connections in the pool. For connections currently in use, these connections will be purged when returned on the pool. This call also purges connections that are idle and in the pool.",
                    e);
            }
            catch (final Exception e) {
                LOG.error(IndexMaker.indexes(newValue), "There is error while persisting data", e);
            }

            return ret;
        };
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#delete(java.lang.Object)
     */
    @Override
    public void delete(final K key) {
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.DBErrorInfo#emptyError()
     */
    @Override
    public int emptyError() {
        final int ret = this.mightErrorList.size();
        this.mightErrorList.clear();
        return ret;
    }

    /**
     * Fire modified notification.
     *
     * @param key the key
     * @param oldValue the old value
     * @param newValue the new value
     */
    protected void fireModifiedNotification(final K key, final V oldValue, final V newValue) {
        // This thread pool must be single thread only
        this.getExecutor().getAsyncExecutor().submit(this.createDbWorker(key, newValue));
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#get(java.lang.Object)
     */
    @Override
    public V get(final K key) {
        return this.cache.get(key);
    }

    /**
     * Gets the cache.
     *
     * @return Returns the cache.
     */
    protected Cache<K, V> getCache() {
        return this.cache;
    }

    /**
     * Gets the cache configuration.
     *
     * @return the cache configuration
     */
    protected abstract CacheConfiguration getCacheConfiguration();

    /**
     * Gets the cache name.
     *
     * @return the cache name
     */
    @Override
    public abstract String getCacheName();

    /**
     * Gets the class type.
     *
     * @return the class type
     */
    protected abstract Class<V> getClassType();

    /**
     * Gets the data container.
     *
     * @return the data container
     */
    @SuppressWarnings("unchecked")
    protected DataContainer<K, V> getDataContainer() {
        return ((CacheImpl<K, V>) this.cache).getDataContainer();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.DdsCacheInfo#getExpiredLifeSpan()
     */
    @Override
    public long getExpiredLifeSpan() {
        return this.getCacheConfiguration().getExpiredLifeSpan();
    }

    /**
     * Gets the listener.
     *
     * @return the listener
     */
    protected abstract ICacheListener getListener();

    /**
     * Gets the managed info.
     *
     * @param managedInfos the managed infos
     * @param fromTime the from time
     * @param toTime the to time
     * @param size the size
     * @return the managed info
     */
    public void getManagedInfo(final List<IDDSCacheEntry> managedInfos, final long fromTime, final long toTime, final int size) {
        final long now = DiscoWallClock.milli();
        final Iterator<InternalCacheEntry<K, V>> purgeCandidates = this.getDataContainer().iteratorIncludingExpired();

        // TODO -- Performance issue when the records around 1 million, it takes 60 seconds
        if ((fromTime > 0) && (toTime > 0)) {
            if (size > 0) {
                int c = 0;
                while ((c < size) && purgeCandidates.hasNext()) {
                    final InternalCacheEntry<K, V> e = purgeCandidates.next();
                    final String key = (String) e.getKey();
                    final V v = e.getValue();
                    if (v != null) {
                        final IdentifiedEntry ie = (IdentifiedEntry) v;
                        if ((ie.getReceived() >= fromTime) && (ie.getReceived() <= toTime)) {
                            this.appendEntry(managedInfos, now, e, key, ie);
                            c++;
                        }
                    }
                }
            }
            else if (size < 0) {
                while (purgeCandidates.hasNext()) {
                    final InternalCacheEntry<K, V> e = purgeCandidates.next();
                    final String key = (String) e.getKey();
                    final V v = e.getValue();
                    if (v != null) {
                        final IdentifiedEntry ie = (IdentifiedEntry) v;
                        if ((ie.getReceived() >= fromTime) && (ie.getReceived() <= toTime)) {
                            this.appendEntry(managedInfos, now, e, key, ie);
                        }
                    }
                }
            }
        }
        else if (toTime <= 0) {
            if (size > 0) {
                int c = 0;
                while ((c < size) && purgeCandidates.hasNext()) {
                    final InternalCacheEntry<K, V> e = purgeCandidates.next();
                    final String key = (String) e.getKey();
                    final V v = e.getValue();
                    if (v != null) {
                        final IdentifiedEntry ie = (IdentifiedEntry) v;
                        if (ie.getReceived() >= fromTime) {
                            this.appendEntry(managedInfos, now, e, key, ie);
                            c++;
                        }
                    }
                }
            }
            else if (size < 0) {
                while (purgeCandidates.hasNext()) {
                    final InternalCacheEntry<K, V> e = purgeCandidates.next();
                    final String key = (String) e.getKey();
                    final V v = e.getValue();
                    if (v != null) {
                        final IdentifiedEntry ie = (IdentifiedEntry) v;
                        if (ie.getReceived() >= fromTime) {
                            this.appendEntry(managedInfos, now, e, key, ie);
                        }
                    }
                }
            }
        }
        else if (fromTime <= 0) {
            if (size > 0) {
                int c = 0;
                while ((c < size) && purgeCandidates.hasNext()) {
                    final InternalCacheEntry<K, V> e = purgeCandidates.next();
                    final String key = (String) e.getKey();
                    final V v = e.getValue();
                    if (v != null) {
                        final IdentifiedEntry ie = (IdentifiedEntry) v;
                        if (ie.getReceived() <= toTime) {
                            this.appendEntry(managedInfos, now, e, key, ie);
                            c++;
                        }
                    }
                }
            }
            else if (size < 0) {
                while (purgeCandidates.hasNext()) {
                    final InternalCacheEntry<K, V> e = purgeCandidates.next();
                    final String key = (String) e.getKey();
                    final V v = e.getValue();
                    if (v != null) {
                        final IdentifiedEntry ie = (IdentifiedEntry) v;
                        if (ie.getReceived() <= toTime) {
                            this.appendEntry(managedInfos, now, e, key, ie);
                        }
                    }
                }
            }
        }
        else {
            if (size > 0) {
                int c = 0;
                while ((c < size) && purgeCandidates.hasNext()) {
                    final InternalCacheEntry<K, V> e = purgeCandidates.next();
                    final String key = (String) e.getKey();
                    final V v = e.getValue();
                    if (v != null) {
                        final IdentifiedEntry ie = (IdentifiedEntry) v;
                        this.appendEntry(managedInfos, now, e, key, ie);
                        c++;
                    }
                }
            }
            else if (size < 0) {
                while (purgeCandidates.hasNext()) {
                    final InternalCacheEntry<K, V> e = purgeCandidates.next();
                    final String key = (String) e.getKey();
                    final V v = e.getValue();
                    if (v != null) {
                        final IdentifiedEntry ie = (IdentifiedEntry) v;
                        this.appendEntry(managedInfos, now, e, key, ie);
                    }
                }
            }
        }
    }

    /**
     * Gets the managed info by ident code.
     *
     * @param managedInfos the managed infos
     * @param key the key
     * @param identCode the ident code
     * @return the managed info by ident code
     */
    public void getManagedInfo(final List<IDDSCacheEntry> managedInfos, final String key, final String identCode, final int size) {
        final long now = DiscoWallClock.milli();
        final Iterator<InternalCacheEntry<K, V>> purgeCandidates = this.getDataContainer().iteratorIncludingExpired();

        if ((key != null) && (identCode != null)) {
            if (size > 0) {
                int c = 0;
                while ((c < size) && purgeCandidates.hasNext()) {
                    final InternalCacheEntry<K, V> e = purgeCandidates.next();
                    final V v = e.getValue();
                    if (v != null) {
                        final IdentifiedEntry ie = (IdentifiedEntry) v;
                        if (key.equals(ie.getKey()) && identCode.equals(ie.getIdentCode())) {
                            this.appendEntry(managedInfos, now, e, key, ie);
                        }
                    }
                    c++;
                }
            }
            else {
                while (purgeCandidates.hasNext()) {
                    final InternalCacheEntry<K, V> e = purgeCandidates.next();
                    final V v = e.getValue();
                    if (v != null) {
                        final IdentifiedEntry ie = (IdentifiedEntry) v;
                        if (key.equals(ie.getKey()) && identCode.equals(ie.getIdentCode())) {
                            this.appendEntry(managedInfos, now, e, key, ie);
                        }
                    }
                }
            }
            // This can simplify the code like below:
            // But because it can impact the performance because foreach item the loop must check the statement: size > 0 ? c < size : true
            //            int c = 0;
            //            while ((size > 0 ? c < size : true) && purgeCandidates.hasNext()) {
            //                final InternalCacheEntry<K, V> e = purgeCandidates.next();
            //                final V v = e.getValue();
            //                if (v != null) {
            //                    final IdentifiedEntry ie = (IdentifiedEntry) v;
            //                    if (key.equals(ie.getKey()) && identCode.equals(ie.getIdentCode())) {
            //                        this.appendEntry(managedInfos, now, e, key, ie);
            //                    }
            //                }
            //                c++;
            //            }
            //
        }
        else if (key != null) {
            // Dont care the size because there only one entry with specified key
            while (purgeCandidates.hasNext()) {
                final InternalCacheEntry<K, V> e = purgeCandidates.next();
                final V v = e.getValue();
                if (v != null) {
                    final IdentifiedEntry ie = (IdentifiedEntry) v;
                    if (key.equals(ie.getKey())) {
                        this.appendEntry(managedInfos, now, e, key, ie);
                        break;
                    }
                }
            }
        }
        else if (identCode != null) {
            if (size > 0) {
                int c = 0;
                while ((c < size) && purgeCandidates.hasNext()) {
                    final InternalCacheEntry<K, V> e = purgeCandidates.next();
                    final V v = e.getValue();
                    if (v != null) {
                        final IdentifiedEntry ie = (IdentifiedEntry) v;
                        if (identCode.equals(ie.getIdentCode())) {
                            this.appendEntry(managedInfos, now, e, key, ie);
                            // There can be more than one entry with the same ident code
                            // So, don't break the while
                        }
                    }
                    c++;
                }
            }
            else {
                while (purgeCandidates.hasNext()) {
                    final InternalCacheEntry<K, V> e = purgeCandidates.next();
                    final V v = e.getValue();
                    if (v != null) {
                        final IdentifiedEntry ie = (IdentifiedEntry) v;
                        if (identCode.equals(ie.getIdentCode())) {
                            this.appendEntry(managedInfos, now, e, key, ie);
                            // There can be more than one entry with the same ident code
                            // So, don't break the while
                        }
                    }
                }
            }
        }
    }

    /**
     * Gets the managed info by state.
     *
     * @param managedInfos the managed infos
     * @param states the states
     * @return the managed info by state
     */
    public void getManagedInfoByState(final List<IDDSCacheEntry> managedInfos, final String... states) {
        final long now = DiscoWallClock.milli();
        final List<String> statez = Arrays.asList(states);
        for (final Iterator<InternalCacheEntry<K, V>> purgeCandidates = this.getDataContainer().iteratorIncludingExpired(); purgeCandidates.hasNext();) {
            final InternalCacheEntry<K, V> e = purgeCandidates.next();
            final String key = (String) e.getKey();
            final V v = e.getValue();
            if (v != null) {
                final IdentifiedEntry ie = (IdentifiedEntry) v;
                if (statez.contains(ie.getState())) {
                    this.appendEntry(managedInfos, now, e, key, ie);
                }
            }
        }
    }

    /**
     * Gets the managed infos.
     *
     * @param managedInfos the managed infos
     * @param size the size
     * @return the managed infos
     */
    public void getManagedInfos(final List<IDDSCacheEntry> managedInfos, final int size) {
        final long now = DiscoWallClock.milli();
        int i = 0;
        final Iterator<InternalCacheEntry<K, V>> purgeCandidates = this.getDataContainer().iteratorIncludingExpired();

        while ((i < size) && purgeCandidates.hasNext()) {
            final InternalCacheEntry<K, V> e = purgeCandidates.next();
            final String key = (String) e.getKey();
            final V v = e.getValue();
            if (v != null) {
                final IdentifiedEntry ie = (IdentifiedEntry) v;
                this.appendEntry(managedInfos, now, e, key, ie);
            }
            i++;
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.DBErrorInfo#getNumberOfDBError()
     */
    @Override
    public int getNumberOfDBError() {
        return this.mightErrorList.size();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.ImmortalCollector#getNumberWatchingTask()
     */
    @Override
    public int getNumberWatchingTask() {
        return this.watcher.getNumberWatchingTask();
    }

    /**
     * Gets the query builder.
     *
     * @return Returns the queryBuilder.
     */
    protected QueryBuilder getQueryBuilder() {
        return this.queryBuilder;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.listener.IMightBeErrorCollector#hasKey(java.lang.String)
     */
    @Override
    public boolean hasKey(final String key) {
        return this.mightErrorList.contains(key);
    }

    /**
     * Initialize.
     */
    @PostConstruct
    protected void initialize() {
        if (this.cache == null) {
            LOG.info("Replicating data from existing members...");
            this.cache = this.cacheManager.getCache(this.getCacheName());
        }
        if (this.queryBuilder == null) {
            this.queryBuilder = Search.getQueryFactory(this.getCache()).from(this.getClassType());
        }
        if (this.isListenable()) {
            this.getCache().addListener(this.getListener());
            LOG.info("Register listener {} to cache {}", this.getListener().getClass().getName(), this.getCacheName());
        }
    }

    /**
     * Checks if is listenable.
     *
     * @return true, if is listenable
     */
    protected boolean isListenable() {
        return true;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#list(int)
     */
    @Override
    public List<V> list(final int max) {
        return this.getQueryBuilder().maxResults(max).build().list();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.listener.IMightBeErrorCollector#listErrorItem()
     */
    @Override
    public List<String> listErrorItem() {
        final List<String> ret = new ArrayList<>();

        if (this.mightErrorList.size() > 0) {
            ret.addAll(this.mightErrorList);
        }

        return ret;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.DBErrorInfo#listErrorKey()
     */
    @Override
    public String[] listErrorKey() {
        return this.mightErrorList.toArray(new String[this.mightErrorList.size()]);
    }

    /**
     * {@inheritDoc}
     * @throws Exception
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#persist(java.lang.Object, java.io.Serializable)
     */
    @Override
    public boolean persist(final K key, final V value, final boolean sync) throws Exception {
        if (sync) {
            return this.createDbWorker(key, value).call().booleanValue();
        }
        else {
            this.fireModifiedNotification(key, null, value);
            return true;
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#put(java.lang.Object,
     * java.io.Serializable, long)
     */
    @Override
    public V put(final K key, final V value, final long lifespan) {
        V ret = null;

        try {
            ret = this.cache.put(key, value, lifespan, TimeUnit.MILLISECONDS);
        }
        catch (final Exception e) {
            LOG.error("Error when caching data", e);
        }

        return ret;
    }

    /**
     * {@inheritDoc}
     *
     * @see
     * vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#remove(java.lang.Object)
     */
    @Override
    public V remove(final K key) {
        return this.cache.remove(key);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#removeExpiredEntries()
     */
    @Override
    @ManagedOperation
    public void removeExpiredEntries() {
        if (this.cache instanceof CacheImpl) {
            ((CacheImpl<K, V>) this.cache).getExpirationManager().processExpiration();
        }
    }

    /**
     * Put and store.
     *
     * @param key the key
     * @param value the value
     * @param lifespan the lifespan
     * @return the v
     */
    public V store(final K key, final V value, final long lifespan) {
        final V oldValue = this.put(key, value, lifespan);
        this.fireModifiedNotification(key, oldValue, value);
        return oldValue;
    }
}
