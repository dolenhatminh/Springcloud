/*
 * Class: IReceiverInfoProcessContext
 *
 * Created on Jul 9, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.receiver;

import java.util.List;

import org.springframework.core.task.AsyncTaskExecutor;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.types.verifying.VerifiedRule;
import vn.sps.aba.dds.config.filtering.IVerifiedRuleConfiguration;
import vn.sps.aba.dds.service.padasa.matchmakerdaten.IMatchMakerDatenService;
import vn.sps.aba.dds.service.vam.ICaptureResultService;

/**
 * The Interface IReceiverInfoProcessContext.
 */
public interface IReceiverProcessingContext extends IMatchMakerDatenService, ICaptureResultService, IVerifiedRuleConfiguration {

    /**
     * Gets the common task executor.
     *
     * @return the common task executor
     */
    AsyncTaskExecutor getReceiverSendingExecutor();

    /**
     * Gets the rules.
     *
     * @return the rules
     */
    @Override
    List<VerifiedRule> getRules();

    /**
     * Handle.
     *
     * @param state
     *            the state
     * @param receiverInfo
     *            the receiver info
     */
    void handle(String state, ReceiverInfo receiverInfo);

    /**
     * Queue for resend capture result.
     *
     * @param receiverInfo the receiver info
     */
    void queueForResendCaptureResult(ReceiverInfo receiverInfo);

    /**
     * Queue for resend match maker.
     *
     * @param receiverInfo the receiver info
     */
    void queueForResendMatchMaker(ReceiverInfo receiverInfo);

    /**
     * Submit capture result.
     *
     * @param receiverInfo the receiver info
     */
    void submitCaptureResult(ReceiverInfo receiverInfo);

    /**
     * Submit match maker.
     *
     * @param receiverInfo the receiver info
     */
    void submitMatchMaker(ReceiverInfo receiverInfo);

    /**
     * Transmit state to.
     *
     * @param receiverInfo the receiver info
     * @param state the state
     */
    void transmitStateTo(ReceiverInfo receiverInfo, ReceiverState state);

    /**
     * Update receiver info.
     *
     * @param receiverInfo the receiver info
     */
    void updateReceiverInfo(ReceiverInfo receiverInfo);
}
