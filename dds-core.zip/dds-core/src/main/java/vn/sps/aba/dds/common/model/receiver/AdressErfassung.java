/*
 * Class: AdressErfassung
 *
 * Created on Jul 8, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model.receiver;

import java.io.Serializable;

import javax.xml.bind.JAXBElement;

import vn.sps.aba.dds.common.types.ws.dpm.model.AdresseErfassungType;
import vn.sps.aba.dds.common.types.ws.vam.capturing.model.AdresseErfassung;

/**
 * The Class AdressErfassung.
 */
public class AdressErfassung implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 7952891861521909105L;

    /** The address fields. */
    private AddressFields addressFields;

    /** The volle adresse. */
    private VolleAdresse volleAdresse;

    /**
     * Instantiates a new adress erfassung.
     */
    public AdressErfassung() {
    }

    /**
     * Instantiates a new adress erfassung.
     *
     * @param adresseErfassung the adresse erfassung
     */
    public AdressErfassung(final AdresseErfassung adresseErfassung) {

        if (adresseErfassung.getTypedFields() != null) {
            this.addressFields = new AddressFields(adresseErfassung.getTypedFields().getValue());
        }
        if (adresseErfassung.getVolleAdresse() != null) {
            this.volleAdresse = new VolleAdresse(adresseErfassung.getVolleAdresse());
        }
    }

    /**
     * Instantiates a new adress erfassung.
     *
     * @param adresseErfassungType the adresse erfassung type
     */
    public AdressErfassung(final AdresseErfassungType adresseErfassungType) {
        if ((adresseErfassungType.getTypedFields() != null) && (adresseErfassungType.getTypedFields().getValue() != null)) {
            this.addressFields = new AddressFields(adresseErfassungType.getTypedFields().getValue());
        }
        if (adresseErfassungType.getVolleAdresse() != null) {
            this.volleAdresse = new VolleAdresse(adresseErfassungType.getVolleAdresse());
        }
    }

    /**
     * Instantiates a new adress erfassung.
     *
     * @param adresseErfassung the adresse erfassung
     */
    public AdressErfassung(final vn.sps.aba.dds.common.types.ws.dpmb.AdresseErfassung adresseErfassung) {

        if (adresseErfassung.getTypedFields() != null) {
            this.addressFields = new AddressFields(adresseErfassung.getTypedFields());
        }
        if (adresseErfassung.getVolleAdresse() != null) {
            this.volleAdresse = new VolleAdresse(adresseErfassung.getVolleAdresse());
        }
    }

    /**
     * Instantiates a new adress erfassung.
     *
     * @param adresseErfassung the adresse erfassung
     */
    public AdressErfassung(final vn.sps.aba.dds.common.types.ws.dpms.AdresseErfassung adresseErfassung) {

        final JAXBElement<vn.sps.aba.dds.common.types.ws.dpms.AddressFields> typedFields = adresseErfassung.getTypedFields();
        if ((typedFields != null) && (typedFields.getValue() != null)) {
            this.addressFields = new AddressFields(typedFields.getValue());
        }
        final JAXBElement<vn.sps.aba.dds.common.types.ws.dpms.VolleAdresse> volleAdress = adresseErfassung.getVolleAdresse();
        if ((volleAdress != null) && (volleAdress.getValue() != null)) {
            this.volleAdresse = new VolleAdresse(volleAdress.getValue());
        }
    }

    /**
     * Gets the address fields.
     *
     * @return the address fields
     */
    public AddressFields getAddressFields() {
        return this.addressFields;
    }

    /**
     * Gets the volle adresse.
     *
     * @return the volle adresse
     */
    public VolleAdresse getVolleAdresse() {
        return this.volleAdresse;
    }

    /**
     * Sets the address fields.
     *
     * @param addressFields the new address fields
     */
    public void setAddressFields(final AddressFields addressFields) {
        this.addressFields = addressFields;
    }

    /**
     * Sets the volle adresse.
     *
     * @param volleAdresse the new volle adresse
     */
    public void setVolleAdresse(final VolleAdresse volleAdresse) {
        this.volleAdresse = volleAdresse;
    }

}
