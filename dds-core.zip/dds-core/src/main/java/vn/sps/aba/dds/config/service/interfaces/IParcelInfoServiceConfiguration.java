/*
 * Class: IParcelInfoService
 *
 * Created on Jul 28, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service.interfaces;

/**
 * The Interface IParcelInfoService.
 */
public interface IParcelInfoServiceConfiguration {

    /**
     * Gets the destination pattern.
     *
     * @return the destination pattern
     */
    String getDestinationPattern();

    /**
     * Gets the source pattern.
     *
     * @return the source pattern
     */
    String getSourcePattern();

}