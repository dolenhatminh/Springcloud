/*
 * Class: WsTemplaceConfiguration
 *
 * Created on Jun 28, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.service;

import org.springframework.ws.config.annotation.WsConfigurerAdapter;

import vn.sps.aba.dds.config.service.interfaces.IWsConfiguration;
import vn.sps.aba.dds.jmx.ServiceInfo;

/**
 * The Class WsTemplaceConfiguration.
 */
public abstract class WsTemplaceConfiguration extends WsConfigurerAdapter implements IWsConfiguration, ServiceInfo {

    /** The additional delay. */
    private int additionalReadTimeout;

    /** The connect timeout. */
    private int connectTimeout;

    /** The read timeout. */
    private int readTimeout;

    /** The retry interval time. */
    private long retryIntervalTime;

    /** The retry time. */
    private int retryTime;

    /** The service url. */
    private String serviceUrl;

    /**
     * Gets the additional read timeout.
     *
     * @return the additional read timeout
     */
    public int getAdditionalReadTimeout() {
        return this.additionalReadTimeout;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getConnectTimeout()
     */
    @Override
    public int getConnectTimeout() {
        return this.connectTimeout;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getReadTimeout()
     */
    @Override
    public int getReadTimeout() {
        return this.readTimeout;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ServiceInfo#getRetryInterval()
     */
    @Override
    public long getRetryInterval() {
        return this.retryIntervalTime;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getRetryIntervalTime()
     */
    @Override
    public long getRetryIntervalTime() {
        return this.retryIntervalTime;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getRetryTime()
     */
    @Override
    public int getRetryTime() {
        return this.retryTime;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.config.service.interfaces.IWsConfiguration#getServiceUrl()
     */
    @Override
    public String getServiceUrl() {
        return this.serviceUrl;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ServiceInfo#getServiceUrls()
     */
    @Override
    public String getServiceUrls() {
        return this.getServiceUrl();
    }

    /**
     * Sets the additional read timeout.
     *
     * @param additionalReadTimeout the new additional read timeout
     */
    public void setAdditionalReadTimeout(final int additionalReadTimeout) {
        this.additionalReadTimeout = additionalReadTimeout;
    }

    /**
     * Sets the connect timeout.
     *
     * @param connectTimeout the new connect timeout
     */
    public void setConnectTimeout(final int connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    /**
     * Sets the read timeout.
     *
     * @param readTimeout the new read timeout
     */
    public void setReadTimeout(final int readTimeout) {
        this.readTimeout = readTimeout;
    }

    /**
     * Sets the retry interval time.
     *
     * @param retryIntervalTime
     *            The retryIntervalTime to set.
     */
    public void setRetryIntervalTime(final long retryIntervalTime) {
        this.retryIntervalTime = retryIntervalTime;
    }

    /**
     * Sets the retry time.
     *
     * @param retryTime
     *            The retryTime to set.
     */
    public void setRetryTime(final int retryTime) {
        this.retryTime = retryTime;
    }

    /**
     * Sets the service url.
     *
     * @param serviceUrl
     *            The serviceUrl to set.
     */
    public void setServiceUrl(final String serviceUrl) {
        this.serviceUrl = serviceUrl;
    }
}
