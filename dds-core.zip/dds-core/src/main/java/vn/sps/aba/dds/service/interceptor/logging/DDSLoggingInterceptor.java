/*
 * Class: ParcelSoapEnvelopeLoggingInterceptor
 *
 * Created on July 18, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.interceptor.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.stereotype.Component;
import org.springframework.ws.soap.server.endpoint.interceptor.SoapEnvelopeLoggingInterceptor;

/**
 * Extends the {@linkplain SoapEnvelopeLoggingInterceptor} to use slf4j logger.
 */
@Component
@ConfigurationProperties(prefix = "ws.parcel")
public class DDSLoggingInterceptor extends SoapEnvelopeLoggingInterceptor {

    /** The Constant LOGGER. */
    private static final Logger LOG = LoggerFactory.getLogger(DDSLoggingInterceptor.class);

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.ws.server.endpoint.AbstractLoggingInterceptor#isLogEnabled()
     */
    @Override
    protected boolean isLogEnabled() {
        return true;
    }
    
    /**
     * {@inheritDoc}
     *
     * @see org.springframework.ws.server.endpoint.AbstractLoggingInterceptor#logMessage(java.lang.String)
     */
    @Override
    public void logMessage(final String message) {
        LOG.info(message);
    }

    /**
     * Update log request.
     *
     * @param logRequest the log request
     */
    @ManagedOperation
    public void updateLogRequest(final boolean logRequest) {
        this.setLogRequest(logRequest);
    }

    /**
     * Update log response.
     *
     * @param logResponse the log response
     */
    @ManagedOperation
    public void updateLogResponse(final boolean logResponse) {
        this.setLogResponse(logResponse);
    }
}
