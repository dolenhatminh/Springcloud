package vn.sps.aba.dds.logging.report.field;

import java.io.Serializable;

import vn.sps.aba.dds.common.model.receiver.AddressFields;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;

/**
 * One of ReceiverInfoReport's Fields
 * Class AdresseErfassung
 */
public class AdresseErfassung implements Serializable {
	
	 /** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5144479732228256087L;

	private String hausKey;
	
	 /** The address fields. */
    private AddressFields typedFields;
	
	 /** The volle adresse. */
    private VolleAdresse volleAdresse;
    
    /**
     * One of ReceiverInfoReport's Fields
     * @param vn.sps.aba.dds.common.model.receiver.AdressErfassung
     * @param ReceiverInfo
     */
    public AdresseErfassung (final vn.sps.aba.dds.common.model.receiver.AdressErfassung adresseErfassung, ReceiverInfo receiverInfo) {
    	
    	this.hausKey = receiverInfo.getHausKey();
        if (adresseErfassung.getAddressFields() != null) {
            this.typedFields = adresseErfassung.getAddressFields();
        }
        if (adresseErfassung.getVolleAdresse() != null) {
            this.volleAdresse = new VolleAdresse(adresseErfassung.getVolleAdresse(), receiverInfo);
        }
    }

	/**
	 * @return the hausKey
	 */
	public String getHausKey() {
		return hausKey;
	}

	/**
	 * @param hausKey the hausKey to set
	 */
	public void setHausKey(String hausKey) {
		this.hausKey = hausKey;
	}

	/**
	 * @return the typedFields
	 */
	public AddressFields getTypedFields() {
		return typedFields;
	}

	/**
	 * @param typedFields the typedFields to set
	 */
	public void setTypedFields(AddressFields typedFields) {
		this.typedFields = typedFields;
	}

	/**
	 * @return the volleAdresse
	 */
	public VolleAdresse getVolleAdresse() {
		return volleAdresse;
	}

	/**
	 * @param volleAdresse the volleAdresse to set
	 */
	public void setVolleAdresse(VolleAdresse volleAdresse) {
		this.volleAdresse = volleAdresse;
	}
    
    
}
