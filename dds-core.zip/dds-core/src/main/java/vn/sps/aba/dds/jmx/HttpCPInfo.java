/*
 * Class: HttpCPInfo
 *
 * Created on Dec 23, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.jmx;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

/**
 * The Interface HttpCPInfo.
 */
@ManagedResource
public interface HttpCPInfo {

    /**
     * Gets the conn time to live.
     *
     * @return the conn time to live
     */
    @ManagedAttribute
    long getConnTimeToLive();

    /**
     * Gets the default connect time out.
     *
     * @return the default connect time out
     */
    @ManagedAttribute
    long getDefaultConnectTimeOut();

    /**
     * Gets the default read time out.
     *
     * @return the default read time out
     */
    @ManagedAttribute
    long getDefaultReadTimeOut();

    /**
     * Gets the connection pool info.
     * <p>
     * Retrieve the CP info just as string will save the requests to the CP Manager which lock the threads
     * </p>
     *
     * @return the connection pool info
     */
    @ManagedAttribute
    String getConnectionPoolInfo();

    /**
     * Sets the max per route.
     *
     * @param max the new max per route
     */
    @ManagedOperation
    void setMaxPerRoute(int max);

    /**
     * Sets the max total.
     *
     * @param max the new max total
     */
    @ManagedOperation
    void setMaxTotal(int max);
}
