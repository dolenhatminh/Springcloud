package vn.sps.aba.dds.logging.report;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.model.receiver.CaptureInfo;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.logging.report.field.AdresseErfassung;
import vn.sps.aba.dds.logging.report.field.ParcelData;
import vn.sps.aba.dds.logging.report.field.Timestamps;

/**
 * Log DPM for ABA_Report
 * Class ReceiverInfoReport
 */
public class ReceiverInfoReport implements Serializable, IdentifiedEntry {
	
	 /** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1755975496153320635L;
	
	 /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ReceiverInfoReport.class);

	/* Default Fields*/
	/** The adress erfassung. */
	private AdresseErfassung adresseErfassung;

	/** The capture info. */
	private CaptureInfo captureInfo;

	/** The ident code. */
	private String identCode;

	/** The parcel data. */
	private ParcelData parcelData;

	/** The sender id. */
	private String senderId;

	/** The Timestamps. */
	private Timestamps timestamps;
	/* Default Fields*/

	/* Additional Fields */
	/** The caller id. */
	private String callerId;

	/** The enough info. */
	@Deprecated
	private boolean enoughInfo;

	/** The need empty amp key. */
	@Deprecated
	private boolean needEmptyAmpKey;

	/** The package id. */
	private String packageId;

	/** The key. */
	private String key;

	/** The person key. */
	private Integer personKey;

	/** The process begin. */
	private long processBegin;

	/** The process end. */
	private long processEnd;

	/** The received. */
	private long received;

	/** The capture result time. */
	private volatile long captureResultBegin;

	/** The capture result count. */
	private int captureResultCount;

	/** The capture result done time. */
	private volatile long captureResultEnd;

	/** The dpm time stamp. */
	private String dpmTimeStamp;

	/** The match maker time. */
	private volatile long matchMakerBegin;

	/** The match maker count. */
	private int matchMakerCount;

	/** The match maker done time. */
	private volatile long matchMakerEnd;

	/** The state. */
	private volatile ReceiverState state = ReceiverState.RECEIVED;

	/** The status code. */
	private String statusCode;

	/** The vam station sent. */
	private String vamStationSent;

	/** The verified by rule. */
	private String verifiedByRule;

	/** The version. */
	private String version;
	/* Additional Fields */

	/**
	 * Parse from vn.sps.aba.dds.common.model.receiver.ReceiverInfo
	 * @param ReceiverInfo
	 */
	public ReceiverInfoReport(ReceiverInfo receiverInfo) {
		try {
			this.adresseErfassung = new AdresseErfassung(receiverInfo.getAdressErfassung(), receiverInfo);
			this.parcelData = new ParcelData(receiverInfo.getParcelData());
			this.timestamps = new Timestamps(receiverInfo);
			this.captureInfo = receiverInfo.getCaptureInfo();
			this.identCode = receiverInfo.getIdentCode();
			this.senderId = receiverInfo.getSenderId();
			this.callerId = receiverInfo.getCallerId();
			this.enoughInfo = receiverInfo.isEnoughInfo();
			this.needEmptyAmpKey = receiverInfo.isNeedEmptyAmpKey();
			this.packageId = receiverInfo.getPackageId();
			this.key = receiverInfo.getKey();
			this.personKey = receiverInfo.getPersonKey();
			this.processBegin = receiverInfo.getProcessBegin();
			this.processEnd = receiverInfo.getProcessEnd();
			this.received = receiverInfo.getReceived();
			this.captureResultBegin = receiverInfo.getCaptureResultBegin();
			this.captureResultCount = receiverInfo.getCaptureResultCount();
			this.captureResultEnd = receiverInfo.getCaptureResultEnd();
			this.dpmTimeStamp = receiverInfo.getDpmTimeStamp();
			this.matchMakerBegin = receiverInfo.getMatchMakerBegin();
			this.matchMakerCount = receiverInfo.getMatchMakerCount();
			this.matchMakerEnd = receiverInfo.getMatchMakerEnd();
			this.state = receiverInfo.getReceiverState();
			this.statusCode = receiverInfo.getStatusCode();
			this.vamStationSent = receiverInfo.getVamStationSent();
			this.verifiedByRule = receiverInfo.getVerifiedByRule();
			this.version = receiverInfo.getVersion();
		} catch (Exception e) {
			LOG.error(IndexMaker.index(receiverInfo), "Could not parse to ReceiverInfoReport", e);
		}
	}
	
	/**
	 * @return the adresseErfassung
	 */
	public AdresseErfassung getAdresseErfassung() {
		return adresseErfassung;
	}

	/**
	 * @return the captureInfo
	 */
	public CaptureInfo getCaptureInfo() {
		return captureInfo;
	}

	/**
	 * @return the identCode
	 */
	public String getIdentCode() {
		return identCode;
	}

	/**
	 * @return the parcelData
	 */
	public ParcelData getParcelData() {
		return parcelData;
	}

	/**
	 * @return the senderId
	 */
	public String getSenderId() {
		return senderId;
	}

	/**
	 * @return the timestamps
	 */
	public Timestamps getTimestamps() {
		return timestamps;
	}

	/**
	 * @return the callerId
	 */
	public String getCallerId() {
		return callerId;
	}

	/**
	 * @return the enoughInfo
	 */
	public boolean isEnoughInfo() {
		return enoughInfo;
	}

	/**
	 * @return the needEmptyAmpKey
	 */
	public boolean isNeedEmptyAmpKey() {
		return needEmptyAmpKey;
	}

	/**
	 * @return the packageId
	 */
	public String getPackageId() {
		return packageId;
	}

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @return the personKey
	 */
	public Integer getPersonKey() {
		return personKey;
	}

	/**
	 * @return the processBegin
	 */
	public long getProcessBegin() {
		return processBegin;
	}

	/**
	 * @return the processEnd
	 */
	public long getProcessEnd() {
		return processEnd;
	}

	/**
	 * @return the received
	 */
	public long getReceived() {
		return received;
	}

	/**
	 * @return the captureResultBegin
	 */
	public long getCaptureResultBegin() {
		return captureResultBegin;
	}

	/**
	 * @return the captureResultCount
	 */
	public int getCaptureResultCount() {
		return captureResultCount;
	}

	/**
	 * @return the captureResultEnd
	 */
	public long getCaptureResultEnd() {
		return captureResultEnd;
	}

	/**
	 * @return the dpmTimeStamp
	 */
	public String getDpmTimeStamp() {
		return dpmTimeStamp;
	}

	/**
	 * @return the matchMakerBegin
	 */
	public long getMatchMakerBegin() {
		return matchMakerBegin;
	}

	/**
	 * @return the matchMakerCount
	 */
	public int getMatchMakerCount() {
		return matchMakerCount;
	}

	/**
	 * @return the matchMakerEnd
	 */
	public long getMatchMakerEnd() {
		return matchMakerEnd;
	}

	/**
	 * @return the state
	 */
	public ReceiverState getReceiverState() {
		return state;
	}
	

	/**
	 * @return the state name
	 */
	public String getState() {
		return state.name();
	}

	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @return the vamStationSent
	 */
	public String getVamStationSent() {
		return vamStationSent;
	}

	/**
	 * @return the verifiedByRule
	 */
	public String getVerifiedByRule() {
		return verifiedByRule;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/* (non-Javadoc)
	 * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getMinorState()
	 */
	@Override
	public String getMinorState() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
