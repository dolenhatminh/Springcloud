
package vn.sps.aba.dds.common.types.ws.dpmb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AdresseErfassung complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdresseErfassung">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="HausKey" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TypedFields" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}AddressFields" minOccurs="0"/>
 *         &lt;element name="VolleAdresse" type="{Ch.Post.PL.Vae.Vam.CaptureResultService}VolleAdresse"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdresseErfassung", propOrder = {
    "hausKey",
    "typedFields",
    "volleAdresse"
})
public class AdresseErfassung {

    @XmlElement(name = "HausKey", required = true, nillable = true)
    protected String hausKey;
    @XmlElement(name = "TypedFields")
    protected AddressFields typedFields;
    @XmlElement(name = "VolleAdresse", required = true, nillable = true)
    protected VolleAdresse volleAdresse;

    /**
     * Gets the value of the hausKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHausKey() {
        return hausKey;
    }

    /**
     * Sets the value of the hausKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHausKey(String value) {
        this.hausKey = value;
    }

    /**
     * Gets the value of the typedFields property.
     * 
     * @return
     *     possible object is
     *     {@link AddressFields }
     *     
     */
    public AddressFields getTypedFields() {
        return typedFields;
    }

    /**
     * Sets the value of the typedFields property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressFields }
     *     
     */
    public void setTypedFields(AddressFields value) {
        this.typedFields = value;
    }

    /**
     * Gets the value of the volleAdresse property.
     * 
     * @return
     *     possible object is
     *     {@link VolleAdresse }
     *     
     */
    public VolleAdresse getVolleAdresse() {
        return volleAdresse;
    }

    /**
     * Sets the value of the volleAdresse property.
     * 
     * @param value
     *     allowed object is
     *     {@link VolleAdresse }
     *     
     */
    public void setVolleAdresse(VolleAdresse value) {
        this.volleAdresse = value;
    }

}
