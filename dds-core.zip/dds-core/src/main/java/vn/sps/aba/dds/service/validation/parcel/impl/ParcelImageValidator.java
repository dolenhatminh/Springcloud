/*
 * Class: ParcelImageValidator
 *
 * Created on Jun 14, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.parcel.impl;

import vn.sps.aba.dds.common.types.ws.pds.parcel.model.ParcelInfo;

/**
 * The Class ParcelImageValidator.
 */
public class ParcelImageValidator extends AbstractParcelInfoValidator {

	/**
	 * {@inheritDoc}
	 *
	 * @see vn.sps.aba.dds.service.validation.AbstractGenericValidator#getMessage()
	 */
	@Override
	protected String getMessage() {
		return null;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see vn.sps.aba.dds.service.validation.AbstractGenericValidator#getResponseCode()
	 */
	@Override
	protected int getResponseCode() {
		return 0;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see vn.sps.aba.dds.service.validation.AbstractGenericValidator#isPassed(java.lang.Object)
	 */
	@Override
	protected boolean isPassed(final ParcelInfo entry) {
		return false;
	}

}
