
package vn.sps.aba.dds.common.types.ws.pds.parcel.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Barcode complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Barcode">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Code" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Edges" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Type" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="X1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="X2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="X3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="X4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Y1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Y2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Y3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Y4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Barcode", propOrder = {
    "code",
    "edges",
    "type",
    "x1",
    "x2",
    "x3",
    "x4",
    "y1",
    "y2",
    "y3",
    "y4"
})
public class Barcode {

    @XmlElement(name = "Code", required = true, nillable = true)
    protected String code;
    @XmlElement(name = "Edges", required = true, nillable = true)
    protected String edges;
    @XmlElement(name = "Type", required = true, nillable = true)
    protected String type;
    @XmlElement(name = "X1", required = true, nillable = true)
    protected String x1;
    @XmlElement(name = "X2", required = true, nillable = true)
    protected String x2;
    @XmlElement(name = "X3", required = true, nillable = true)
    protected String x3;
    @XmlElement(name = "X4", required = true, nillable = true)
    protected String x4;
    @XmlElement(name = "Y1", required = true, nillable = true)
    protected String y1;
    @XmlElement(name = "Y2", required = true, nillable = true)
    protected String y2;
    @XmlElement(name = "Y3", required = true, nillable = true)
    protected String y3;
    @XmlElement(name = "Y4", required = true, nillable = true)
    protected String y4;

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    /**
     * Gets the value of the edges property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEdges() {
        return edges;
    }

    /**
     * Sets the value of the edges property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEdges(String value) {
        this.edges = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the x1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX1() {
        return x1;
    }

    /**
     * Sets the value of the x1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX1(String value) {
        this.x1 = value;
    }

    /**
     * Gets the value of the x2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX2() {
        return x2;
    }

    /**
     * Sets the value of the x2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX2(String value) {
        this.x2 = value;
    }

    /**
     * Gets the value of the x3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX3() {
        return x3;
    }

    /**
     * Sets the value of the x3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX3(String value) {
        this.x3 = value;
    }

    /**
     * Gets the value of the x4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX4() {
        return x4;
    }

    /**
     * Sets the value of the x4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX4(String value) {
        this.x4 = value;
    }

    /**
     * Gets the value of the y1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getY1() {
        return y1;
    }

    /**
     * Sets the value of the y1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setY1(String value) {
        this.y1 = value;
    }

    /**
     * Gets the value of the y2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getY2() {
        return y2;
    }

    /**
     * Sets the value of the y2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setY2(String value) {
        this.y2 = value;
    }

    /**
     * Gets the value of the y3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getY3() {
        return y3;
    }

    /**
     * Sets the value of the y3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setY3(String value) {
        this.y3 = value;
    }

    /**
     * Gets the value of the y4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getY4() {
        return y4;
    }

    /**
     * Sets the value of the y4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setY4(String value) {
        this.y4 = value;
    }

}
