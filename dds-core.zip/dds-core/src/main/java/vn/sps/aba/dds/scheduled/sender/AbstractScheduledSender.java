/*
 * Class: AbstractScheduledSender
 *
 * Created on Oct 23, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.sender;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.config.task.scheduler.DdsScheduler;
import vn.sps.aba.dds.jmx.ScheduledSenderInfo;
import vn.sps.aba.dds.scheduled.AbstractCronScheduler;
import vn.sps.aba.dds.scheduled.DdsScheduledTask;

/**
 * The Class AbstractScheduledSender.
 *
 * @param <T> the generic type
 */
public abstract class AbstractScheduledSender<T extends IdentifiedEntry> extends AbstractCronScheduler
        implements DdsScheduledTask, IScheduledSender<T>, ScheduledSenderInfo {

    /**
     * The Class ScheduledItem.
     */
    private class ScheduledItem {

        /** The item. */
        T item;

        /** The max touch count. */
        int maxTouchCount;

        /** The touch count. */
        int touchCount;

        /**
         * Checks if is under max.
         *
         * @return true, if is under max
         */
        boolean isUnderMax() {
            return this.maxTouchCount < 0 ? true : this.touchCount < this.maxTouchCount;
        }
    }

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(AbstractScheduledSender.class);

    /** The max count. */
    private int maxCount = -1;

    /** The max item each execution. */
    private int maxForOnce = -1;

    /** The parallel. */
    private int parallel = 1;

    /** The remove on cancel. */
    private boolean removeOnCancel = false;

    /** The scheduled executor. */
    protected DdsScheduler scheduledExecutor;

    /** The store. */
    private final List<ScheduledItem> store = Collections.synchronizedList(new ArrayList<>());

    /**
     * Builds the sender executor.
     */
    protected abstract void buildSenderExecutor();

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ScheduledSenderInfo#cancelScheduledItem(java.lang.String)
     */
    @Override
    public void cancelScheduledItem(final String key) {
        if (key == null) {
            return;
        }
        this.store.removeIf(t -> key.equals(t.item.getKey()));
    }

    /**
     * Check before store.
     *
     * @param key the key
     * @return true, if successful
     */
    protected abstract boolean checkBeforeStore(String key);

    /**
     * Config.
     */
    @PostConstruct
    protected void config() {
        this.buildSenderExecutor();
        this.scheduleConfigurar.registerScheduledTask(this, this.getDDSScheduler());
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.beans.factory.DisposableBean#destroy()
     */
    @Override
    public void destroy() throws Exception {
        this.getDDSScheduler().getScheduler().destroy();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.AbstractCronScheduler#emptyQueue(java.lang.String)
     */
    @Override
    public int emptyQueue(final String key) {
        int size = 0;

        if (DDSConstant.EMPTY_KEY.equals(key)) {
            size = this.store.size();
            this.store.clear();
        }

        return size;
    }

    /**
     * Gets the DDS scheduler.
     *
     * @return the DDS scheduler
     */
    private DdsScheduler getDDSScheduler() {
        if (this.scheduledExecutor != null) {
            this.buildSenderExecutor();
        }
        return this.scheduledExecutor;
    }

    /**
     * Gets the destination service name.
     *
     * @return the destination service name
     */
    protected abstract String getDestinationServiceName();

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.scheduled.sending.IScheduledSender#getMaxCount()
     */
    @Override
    public int getMaxCount() {
        return this.maxCount;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.scheduled.sending.IScheduledSender#getMaxForOnce()
     */
    @Override
    public int getMaxForOnce() {
        return this.maxForOnce;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ScheduledTaskInfo#getNumberOfRemainItems()
     */
    @Override
    public int getNumberOfRemainItems() {
        return this.store.size();
    }

    /**
     * Gets the parallel.
     *
     * @return the parallel
     */
    protected int getParallel() {
        return this.parallel;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.ScheduledTaskInfo#getTaskName()
     */
    @Override
    public String getTaskName() {
        return this.taskName();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#handleTask()
     */
    @Override
    public Runnable handleTask() {
        return () -> {
            if (this.isEnable() && getNumberOfRemainItems() > 0) {
                LOG.info("Re-send data to {} service...", this.getDestinationServiceName());
                if (this.maxForOnce != 0) {
                    final AtomicInteger counter = new AtomicInteger(0);
                    this.store.removeIf(it -> {
                        boolean ret = false;
                        if ((it != null) && ((this.maxForOnce < 0) || (counter.get() < this.maxForOnce))) {
                            final String key = it.item.getKey();
                            if (AbstractScheduledSender.this.needToSent(key, it.item) && it.isUnderMax()) {
                                ret = AbstractScheduledSender.this.resend(key, it.item);
                                if (AbstractScheduledSender.this.checkBeforeStore(key)) {
                                    AbstractScheduledSender.this.mergeAndStore(key, it.item);
                                }
                                it.touchCount++;
                            }
                            else {
                                ret = true;
                            }
                            counter.incrementAndGet();
                        }
                        return ret;
                    });
                }
            }
        };
    }

    /**
     * Checks if is removes the on cancel.
     *
     * @return true, if is removes the on cancel
     */
    protected boolean isRemoveOnCancel() {
        return this.removeOnCancel;
    }

    /**
     * Merge and store.
     *
     * @param key the key
     * @param item the item
     */
    protected abstract void mergeAndStore(String key, T item);

    /**
     * Need to sent.
     *
     * @param key the key
     * @param item the item
     * @return true, if successful
     */
    protected abstract boolean needToSent(String key, T item);

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.IScheduledSender#queue(java.lang.Object)
     */
    @Override
    public void queue(final T value) {
        if (this.isEnable() && !this.store.contains(value)) {
            final ScheduledItem item = new ScheduledItem();
            {
                item.item = value;
                item.maxTouchCount = this.maxCount;
                item.touchCount = 0;
            }
            this.store.add(item);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.sender.IScheduledSender#removeItemMoreThanCount(int)
     */
    @Override
    public void removeItemMoreThanCount(final int count) {
        this.store.removeIf(t -> t.touchCount > count);
    }

    /**
     * Resend.
     *
     * @param key the key
     * @param item the item
     * @return true, if successful
     */
    protected abstract boolean resend(String key, T item);

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.scheduled.sending.IScheduledSender#setMaxCount(int)
     */
    @Override
    public void setMaxCount(final int maxCount) {
        this.maxCount = maxCount;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.controller.scheduled.sending.IScheduledSender#setMaxForOnce(int)
     */
    @Override
    public void setMaxForOnce(final int maxForOnce) {
        this.maxForOnce = maxForOnce;
    }

    /**
     * Sets the parallel.
     *
     * @param parallel the new parallel
     */
    public void setParallel(final int parallel) {
        this.parallel = parallel;
    }

    /**
     * Sets the removes the on cancel.
     *
     * @param removeOnCancel the new removes the on cancel
     */
    public void setRemoveOnCancel(final boolean removeOnCancel) {
        this.removeOnCancel = removeOnCancel;
    }
}
