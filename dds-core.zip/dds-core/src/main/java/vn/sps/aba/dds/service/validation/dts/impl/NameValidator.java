/*
 * Class: NameValidator
 *
 * Created on Jun 13, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.dts.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.types.ws.dts.model.ReceiverInfoRecord;

/**
 * The Class NameValidator.
 */
public class NameValidator extends AbstractReceiverInfoValidator {

    /** The Constant LOG. */
    private final static Logger LOG = LoggerFactory.getLogger(NameValidator.class);

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.validation.dts.impl.AbstractReceiverInfoValidator#getMessage()
     */
    @Override
    protected String getMessage() {
        return "Name1, Name2, and Name3 must be not null";
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.validation.AbstractGenericValidator#getResponseCode()
     */
    @Override
    protected int getResponseCode() {
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.validation.dts.impl.AbstractReceiverInfoValidator#isPassed(vn.sps.aba.dds.common.types.ws.dts.model.ReceiverInfoRecord)
     */
    @Override
    protected boolean isPassed(final ReceiverInfoRecord entry) {
        LOG.debug("Validating name...");
        return (entry.getRECName1() != null) && (entry.getRECName2() != null) && (entry.getRECName3() != null);
    }

}
