/*
 * Class: IVgParcelBcDataResultService
 *
 * Created on Jun 30, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.padasa.vgparcelbcdataresult;

import vn.sps.aba.dds.common.model.dmc.DMCResponse;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;

/**
 * The Interface IVgParcelBcDataResultService.
 */
public interface IVgParcelBcDataResultService {

    /**
     * Transfer.
     *
     * @param parcelInfo            the parcel info
     * @param response the response
     * @return true, if successful
     */
    boolean transferToBarcodeDataService(ParcelInfo parcelInfo, DMCResponse response);

    /**
     * Transfer to barcode data service.<br>
     * Note: This is used after the <code>DMCResponse</code> was set into parcel
     *
     * @param parcelInfo the parcel info
     * @return true, if successful
     */
    boolean transferToBarcodeDataService(ParcelInfo parcelInfo);
    
}
