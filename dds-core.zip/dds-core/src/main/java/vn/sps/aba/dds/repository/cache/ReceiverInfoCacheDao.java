/*
 * Class: ReceiverInfoDao
 *
 * Created on Jul 9, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.infinispan.container.entries.InternalCacheEntry;
import org.infinispan.query.Search;
import org.infinispan.query.dsl.Expression;
import org.infinispan.query.dsl.FilterConditionContext;
import org.infinispan.query.dsl.Query;
import org.infinispan.query.dsl.QueryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.common.constant.DDSConstant.Profiles;
import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.cache.IDDSCacheEntry;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.types.statistic.Status;
import vn.sps.aba.dds.config.cache.CacheConfiguration;
import vn.sps.aba.dds.config.cache.CacheReceiverInfoConfiguration;
import vn.sps.aba.dds.config.task.TaskConfiguration;
import vn.sps.aba.dds.config.task.notifier.CacheReceiverNotificationExecutor;
import vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao;
import vn.sps.aba.dds.repository.listener.ICacheListener;
import vn.sps.aba.dds.repository.query.ICCounter;

/**
 * The Class ReceiverInfoCacheDao.
 */
@Profile(value = { Profiles.RECEIVER, Profiles.DPM, Profiles.DPMB, Profiles.DPMS })
@Repository("ReceiverInfoCacheDao")
@Configuration
public class ReceiverInfoCacheDao extends AbstractCacheDao<String, ReceiverInfo> implements IReceiverInfoCacheDao {

    /** The Constant FIELD_IDENT_CODE. */
    private static final String FIELD_IDENT_CODE = DDSConstant.ReceiverFields.FIELD_IDENT_CODE;

    /** The Constant FIELD_KEY. */
    private static final String FIELD_KEY = DDSConstant.ReceiverFields.FIELD_KEY;

    /** The Constant FIELD_PROCESS_END. */
    private static final String FIELD_PROCESS_END = DDSConstant.ReceiverFields.FIELD_PROCESS_END;

    /** The Constant FIELD_RECEIVED_TIME. */
    private static final String FIELD_RECEIVED_TIME = DDSConstant.ReceiverFields.FIELD_RECEIVED_TIME;

    /** The Constant FIELD_STATE. */
    private static final String FIELD_STATE = DDSConstant.ReceiverFields.FIELD_STATE;

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ReceiverInfoCacheDao.class);

    /** The cache configuration. */
    @Autowired
    private CacheReceiverInfoConfiguration cacheConfiguration;

    /** The listener. */
    @Autowired
    @Qualifier("ReceiverInfoListener")
    private ICacheListener<String, ReceiverInfo> listener;

    /** The notification executor. */
    @Autowired
    private CacheReceiverNotificationExecutor notificationExecutor;

    /**
     * Count by field.
     *
     * @param states the states
     * @param fromTime the from time
     * @param toTime the to time
     * @param groupByField the group by field
     */
    private void countByField(final List<Status> states, final long fromTime, final long toTime, final String groupByField) {
        final FilterConditionContext context = Search.getQueryFactory(this.getCache()).from(this.getClassType()).having(FIELD_RECEIVED_TIME).gte(fromTime);

        if (toTime > 0) {
            context.and().having(FIELD_RECEIVED_TIME).lte(toTime);
        }
        final Query query = context.toBuilder().select(Expression.property(groupByField), Expression.count(FIELD_KEY)).groupBy(groupByField).build();
        final List<Object> list = query.list();

        if (list != null) {
            this.appendStatusData(states, list);
        }
    }
    
    /**
     * Count by field.
     * Select item in cache and group by STATE yourself
     * @param states the states
     * @param fromTime the from time
     * @param toTime the to time
     */
    @SuppressWarnings("unused")
    @Deprecated
	private void countByField(final List<Status> states, final long fromTime, final long toTime) {
    	final FilterConditionContext context = Search.getQueryFactory(this.getCache()).from(this.getClassType()).having(FIELD_RECEIVED_TIME).gte(fromTime);

        if (toTime > 0) {
            context.and().having(FIELD_RECEIVED_TIME).lte(toTime);
        }
        
        final Query query = context.toBuilder().build();
        final List<ReceiverInfo> listReceiverInfo = query.list();
        HashMap<String, Integer> statusData = new HashMap<>();
        listReceiverInfo.stream().forEach((receiver) -> {
        	if (statusData.containsKey(receiver.getState())) {
				statusData.put(receiver.getState(), statusData.get(receiver.getState()) + 1);
			} else {
				statusData.put(receiver.getState(), 1);
			}
        });
        this.appendStatusData(states, statusData);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.DdsCacheInfo#countEntriesWithMinorState(java.lang.String)
     */
    @Override
    public int countEntriesWithMinorState(final String minorState) {
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.jmx.DdsCacheInfo#countEntriesWithState(java.lang.String)
     */
    @Override
    public int countEntriesWithState(final String state) {
        if ((state != null) && !state.isEmpty() && (ParcelState.valueOf(state) != null)) {
            final Iterator<InternalCacheEntry<String, ReceiverInfo>> iterator = this.getDataContainer().iterator();

            int count = 0;
            while (iterator.hasNext()) {
                count += state.equals(iterator.next().getValue().getState()) ? 1 : 0;
            }
            return count;
        }
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.query.ICacheQuery#countState(java.util.List, long, long)
     */
    @Override
    public void countState(final List<Status> states, final long fromTime, final long toTime) {
        this.countByField(states, fromTime, toTime, FIELD_STATE);
        this.appendDefaultStatusList(states);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#countStatus()
     */
    @Override
    public List<Status> countStatus(final long fromTime, final long toTime) {

        final List<Status> statuses = new ArrayList<>();

        try {
            this.countByField(statuses, fromTime, toTime, FIELD_STATE);
            this.appendDefaultStatusList(statuses);
        }
        catch (final Exception e) {
            LOG.error("Error when counting the status", e);
        }

        return statuses;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.AbstractCacheDao#getCacheConfiguration()
     */
    @Override
    protected CacheConfiguration getCacheConfiguration() {
        return this.cacheConfiguration;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.AbstractCacheDao#getCacheName()
     */
    @Override
    public String getCacheName() {
        return DDSConstant.CacheName.CACHE_RECEIVER_INFO;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.AbstractCacheDao#getClassType()
     */
    @Override
    protected Class<ReceiverInfo> getClassType() {
        return ReceiverInfo.class;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected TaskConfiguration getExecutor() {
        return this.notificationExecutor;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.AbstractCacheDao#getListener()
     */
    @Override
    protected ICacheListener<String, ReceiverInfo> getListener() {
        return this.listener;
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.repository.query.IDataContainerEntries#getManagedInfo(java.util.List, long, long, java.lang.String, java.lang.String, int)
     */
    @Override
    public void getManagedInfo(
        final List<IDDSCacheEntry> managedInfos,
        final long fromTime,
        final long toTime,
        final String state,
        final String minorState,
        final int size) {

        this.getManagedInfo(managedInfos, fromTime, toTime, size);

        // Ignore the minorState
        if ((managedInfos.size() > 0) && (state != null)) {
            managedInfos.removeIf(t -> (t.getState() == null) || !t.getState().equals(state));
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.AbstractCacheDao#isListenable()
     */
    @Override
    protected boolean isListenable() {
        return this.cacheConfiguration.isListenable();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao#list(java.time.LocalDateTime, java.time.LocalDateTime, vn.sps.aba.dds.common.constant.Enumeration.ReceiverState, int)
     */
    @Override
    public List<ReceiverInfo> list(final long fromTime, final long toTime, final String state, final String minorState, final int maxResult) {
        return this.list(fromTime, toTime, state, minorState, maxResult, true);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao#list(java.time.LocalDateTime, java.time.LocalDateTime, java.lang.String, int, boolean)
     */
    @Override
    public List<ReceiverInfo> list(
        final long fromTime,
        final long toTime,
        final String state,
        final String minorState,
        final int maxResult,
        final boolean processed) {

        final FilterConditionContext context = Search.getQueryFactory(this.getCache()).from(this.getClassType()).having(FIELD_RECEIVED_TIME).gte(fromTime);

        if (processed) {
            context.and().having(FIELD_PROCESS_END).gt(0);
        }
        if (fromTime > 0) {
            context.and().having(FIELD_RECEIVED_TIME).gte(fromTime);
        }
        if (toTime > 0) {
            context.and().having(FIELD_RECEIVED_TIME).lte(toTime);
        }
        if (state != null) {
            context.and().having(FIELD_STATE).eq(state);
        }

        final QueryBuilder<Query> builder = context.toBuilder();

        if (maxResult > 0) {
            builder.maxResults(maxResult);
        }

        return builder.build().list();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao#listByIdentCode(java.lang.String)
     */
    @Override
    public List<ReceiverInfo> listByIdentCode(final String identCode) {
        final Query query = Search.getQueryFactory(this.getCache()).from(this.getClassType()).having(FIELD_IDENT_CODE).eq(identCode).toBuilder().build();
        return query.list();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.IReceiverInfoCacheDao#listDuplicatedEnitries()
     */
    @Override
    public List<ICCounter> listDuplicatedIdentCode() {

        final List<ICCounter> counter = new ArrayList<>();

        try {

            final List<Object> list = Search.getQueryFactory(this.getCache()).from(this.getClassType())
                .select(Expression.property(FIELD_IDENT_CODE), Expression.count(FIELD_KEY)).having(FIELD_PROCESS_END).gt(0).toBuilder()
                .groupBy(FIELD_IDENT_CODE).build().list();

            list.stream().forEach((s) -> {
                final Object[] items = (Object[]) s;
                if (items.length > 1) {
                    counter.add(new ICCounter(String.valueOf(items[0]), Integer.valueOf(items[1].toString())));
                }
            });
        }
        catch (final Exception e) {
            LOG.warn("Error when count duplicated indent code", e);
        }

        return counter;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.AbstractCacheDao#put(java.lang.Object,
     * java.io.Serializable)
     */
    @Override
    public ReceiverInfo put(final String key, final ReceiverInfo value) {
        return super.put(key, value, this.cacheConfiguration.getExpiredLifeSpan());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.repository.cache.interfaces.ICacheCommonCacheDao#putAndStore(java.lang.Object, java.io.Serializable)
     */
    @Override
    public ReceiverInfo store(final String key, final ReceiverInfo value) {
        return super.store(key, value, this.cacheConfiguration.getExpiredLifeSpan());
    }
}
