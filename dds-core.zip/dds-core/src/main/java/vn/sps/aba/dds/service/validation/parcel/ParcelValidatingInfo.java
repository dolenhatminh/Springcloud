/*
 * Class: ParcelValidatingInfo
 *
 * Created on Sep 9, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.validation.parcel;

import java.util.ArrayList;
import java.util.List;

import vn.sps.aba.dds.common.model.IdentifiedEntry;
import vn.sps.aba.dds.common.types.message.Response;

/**
 * The Class ParcelValidatingInfo.
 */
public class ParcelValidatingInfo implements IdentifiedEntry {

    /** The errors. */
    private final List<String> errors = new ArrayList<>();

    /** The ident code. */
    private String identCode;

    /** The key. */
    private String key;

    /** The received time. */
    private long receivedTime;

    /** The request item. */
    private Object requestItem;

    /** The response. */
    private Response response;

    /** The stored data time. */
    private long storedDataTime;

    /** The stored image time. */
    private long storedImageTime;

    /**
     * Gets the errors.
     *
     * @return the errors
     */
    public List<String> getErrors() {
        return this.errors;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getIdentCode()
     */
    @Override
    public String getIdentCode() {
        return this.identCode;
    }

    /**
     * Gets the key.
     *
     * @return the key
     */
    @Override
    public String getKey() {
        return this.key;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getMinorState()
     */
    @Override
    public String getMinorState() {
        return null;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getReceived()
     */
    @Override
    public long getReceived() {
        return this.receivedTime;
    }

    /**
     * Gets the request item.
     *
     * @return the request item
     */
    public Object getRequestItem() {
        return this.requestItem;
    }

    /**
     * Gets the response.
     *
     * @return the response
     */
    public Response getResponse() {
        return this.response;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.IdentifiedEntry#getState()
     */
    @Override
    public String getState() {
        return null;
    }

    /**
     * Gets the stored data time.
     *
     * @return the stored data time
     */
    public long getStoredDataTime() {
        return this.storedDataTime;
    }

    /**
     * Gets the stored image time.
     *
     * @return the stored image time
     */
    public long getStoredImageTime() {
        return this.storedImageTime;
    }

    /**
     * Sets the ident code.
     *
     * @param identCode the new ident code
     */
    public void setIdentCode(final String identCode) {
        this.identCode = identCode;
    }

    /**
     * Sets the key.
     *
     * @param key the new key
     */
    public void setKey(final String key) {
        this.key = key;
    }

    /**
     * Sets the received time.
     *
     * @param receivedTime the new received time
     */
    public void setReceivedTime(final long receivedTime) {
        this.receivedTime = receivedTime;
    }

    /**
     * Sets the request item.
     *
     * @param requestItem the new request item
     */
    public void setRequestItem(final Object requestItem) {
        this.requestItem = requestItem;
    }

    /**
     * Sets the response.
     *
     * @param response the new response
     */
    public void setResponse(final Response response) {
        this.response = response;
    }

    /**
     * Sets the stored data time.
     *
     * @param storedDataTime the new stored data time
     */
    public void setStoredDataTime(final long storedDataTime) {
        this.storedDataTime = storedDataTime;
    }

    /**
     * Sets the stored image time.
     *
     * @param storedImageTime the new stored image time
     */
    public void setStoredImageTime(final long storedImageTime) {
        this.storedImageTime = storedImageTime;
    }
}
