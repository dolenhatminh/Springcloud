/*
 * Class: StateMatchingHandler
 *
 * Created on Jul 4, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.parcel.handers.impl;

import java.util.List;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.aba.dds.common.constant.Enumeration.ParcelState;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.parcel.handers.IParcelStateHandlerContext;
import vn.sps.aba.dds.processor.parcel.handers.IParcelStepHandler;

/**
 * The Class StateMatchingHandler.
 */
public class MatchingHandler extends AbstractParcelStepHandler implements IParcelStepHandler {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(MatchingHandler.class);

    /**
     * Instantiates a new state matching handler.
     */
    public MatchingHandler() {
        super(PARCEL_STATE_MATCHING_DPM);
    }

    /**
     * Handle.
     *
     * @param context            the context
     * @param parcelInfo            the parcel info
     * @throws InterruptedException the interrupted exception
     * @throws ExecutionException the execution exception
     */
    @Override
    public void handle(final IParcelStateHandlerContext context, final ParcelInfo parcelInfo) throws InterruptedException, ExecutionException {

        LOG.info(IndexMaker.index(parcelInfo), "Find a matching receiver info");

        ReceiverInfo receiverInfo = null;
        boolean isCaptureRequest = true;

        // In case one ReceiverInfo has the same IdentCode with ParcelInfo but its state does not belong to context.getMatchedStates()
        //  That ReceiverInfo will be enclosed to VAE BlackBox as well.
        final List<ReceiverInfo> receiverInfos = context.findByIdentCode(parcelInfo.getIdentCode());
        if ((receiverInfos != null) && !receiverInfos.isEmpty()) {
            if (receiverInfos.size() > 1) {
                receiverInfos.sort((r1, r2) -> Long.valueOf(r2.getReceived()).compareTo(Long.valueOf(r1.getReceived())));
            }
            receiverInfo = receiverInfos.get(0);
        }
        parcelInfo.setReceiverInfo(receiverInfo);
        if (receiverInfo != null) {

            String state = receiverInfo.getState();
            if (context.getMatchedStates().contains(state)) {
                isCaptureRequest = false;
                LOG.info(
                    IndexMaker.index(parcelInfo),
                    "Found one matching receiver info with same ident code {} and state {}. Ready to VAM",
                    parcelInfo.getIdentCode(),
                    state);

                context.transmitState(parcelInfo, ParcelState.VAM_CAPTURE_RESULT_READY);

                context.handle(PARCEL_STATE_VAM_CAPTURE_RESULT_HANDLER, parcelInfo);
            }
            else {
                LOG.info(
                    IndexMaker.index(parcelInfo),
                    "Found one matching receiver info with same ident code {} and state {}. Ready to BlackBox",
                    parcelInfo.getIdentCode(),
                    state);
            }
        }
        else {
            LOG.info(IndexMaker.index(parcelInfo), "There is no verified receiver info match with this parcel");
        }
        if (isCaptureRequest) {

            LOG.info(IndexMaker.index(parcelInfo), "Parcel will be transfered to VAE Blackbox for capturing");
            context.transmitState(parcelInfo, ParcelState.BLACKBOX_READY);

            context.handle(PARCEL_STATE_BLACKBOX_HANDLER, parcelInfo);
        }
    }

}
