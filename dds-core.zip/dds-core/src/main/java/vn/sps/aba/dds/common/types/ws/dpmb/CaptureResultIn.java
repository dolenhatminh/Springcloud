
package vn.sps.aba.dds.common.types.ws.dpmb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CaptureResultIn complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CaptureResultIn">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CallerId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CaptureResultRecords">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence maxOccurs="unbounded">
 *                   &lt;element ref="{Ch.Post.PL.Vae.Vam.CaptureResultService}CaptureResultRecord"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CaptureResultIn", propOrder = {
    "callerId",
    "captureResultRecords",
    "version"
})
public class CaptureResultIn {

    @XmlElement(name = "CallerId", required = true, nillable = true)
    protected String callerId;
    @XmlElement(name = "CaptureResultRecords", required = true)
    protected CaptureResultIn.CaptureResultRecords captureResultRecords;
    @XmlElement(name = "Version")
    protected int version;

    /**
     * Gets the value of the callerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallerId() {
        return callerId;
    }

    /**
     * Sets the value of the callerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallerId(String value) {
        this.callerId = value;
    }

    /**
     * Gets the value of the captureResultRecords property.
     * 
     * @return
     *     possible object is
     *     {@link CaptureResultIn.CaptureResultRecords }
     *     
     */
    public CaptureResultIn.CaptureResultRecords getCaptureResultRecords() {
        return captureResultRecords;
    }

    /**
     * Sets the value of the captureResultRecords property.
     * 
     * @param value
     *     allowed object is
     *     {@link CaptureResultIn.CaptureResultRecords }
     *     
     */
    public void setCaptureResultRecords(CaptureResultIn.CaptureResultRecords value) {
        this.captureResultRecords = value;
    }

    /**
     * Gets the value of the version property.
     * 
     */
    public int getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     */
    public void setVersion(int value) {
        this.version = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence maxOccurs="unbounded">
     *         &lt;element ref="{Ch.Post.PL.Vae.Vam.CaptureResultService}CaptureResultRecord"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "captureResultRecord"
    })
    public static class CaptureResultRecords {

        @XmlElement(name = "CaptureResultRecord", required = true)
        protected List<CaptureResultRecord> captureResultRecord;

        /**
         * Gets the value of the captureResultRecord property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the captureResultRecord property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getCaptureResultRecord().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link CaptureResultRecord }
         * 
         * 
         */
        public List<CaptureResultRecord> getCaptureResultRecord() {
            if (captureResultRecord == null) {
                captureResultRecord = new ArrayList<CaptureResultRecord>();
            }
            return this.captureResultRecord;
        }

    }

}
