/*
 * Class: IDiscoLogger
 * 
 * Created on Sep 29, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.logging;

import vn.sps.aba.dds.common.model.IdentifiedEntry;

public interface Logger {

    void info(String message);
    void info(String message, Object... objects);
    void info(IdentifiedEntry entry, String pattern, Object... objects);
    void info(int p, Object entry, String pattern, Object... objects);
    void info(String key, String pattern, Object... objects);
    
    void error(String message);
    void error(String message, Throwable t);
    void error(int p,IdentifiedEntry entry, String message, Throwable t);
    void error(Object entry,String message, Throwable t);
    void error(String key, String identCode, String message, Throwable t);
    void error(String key, String message, Throwable t);

    void warn(String message);
    void warn(String message, Throwable t);
    void warn(int p,Object entry, String message);
    void warn(IdentifiedEntry entry, String message);
    void warn(String key, String identCode, String message);
    void warn(IdentifiedEntry entry, String message, Throwable t);
    
    void debug(String message);
    void debug(Object entry, String pattern, Object... objects);
    void debug(String key, String pattern, Object... objects);
    void debug(String key, String message, Throwable t);
}
