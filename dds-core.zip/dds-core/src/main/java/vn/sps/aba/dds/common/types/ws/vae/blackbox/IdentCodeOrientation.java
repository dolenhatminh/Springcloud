
package vn.sps.aba.dds.common.types.ws.vae.blackbox;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for IdentCodeOrientation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="IdentCodeOrientation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="UpperLeftX" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="UpperLeftY" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="LowerLeftX" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="LowerLeftY" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="LowerRightX" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="LowerRightY" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="UpperRightX" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="UpperRightY" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentCodeOrientation", propOrder = {
    "upperLeftX",
    "upperLeftY",
    "lowerLeftX",
    "lowerLeftY",
    "lowerRightX",
    "lowerRightY",
    "upperRightX",
    "upperRightY"
})
public class IdentCodeOrientation {

    @XmlElement(name = "UpperLeftX")
    protected double upperLeftX;
    @XmlElement(name = "UpperLeftY")
    protected double upperLeftY;
    @XmlElement(name = "LowerLeftX")
    protected double lowerLeftX;
    @XmlElement(name = "LowerLeftY")
    protected double lowerLeftY;
    @XmlElement(name = "LowerRightX")
    protected double lowerRightX;
    @XmlElement(name = "LowerRightY")
    protected double lowerRightY;
    @XmlElement(name = "UpperRightX")
    protected double upperRightX;
    @XmlElement(name = "UpperRightY")
    protected double upperRightY;

    /**
     * Gets the value of the upperLeftX property.
     * 
     */
    public double getUpperLeftX() {
        return upperLeftX;
    }

    /**
     * Sets the value of the upperLeftX property.
     * 
     */
    public void setUpperLeftX(double value) {
        this.upperLeftX = value;
    }

    /**
     * Gets the value of the upperLeftY property.
     * 
     */
    public double getUpperLeftY() {
        return upperLeftY;
    }

    /**
     * Sets the value of the upperLeftY property.
     * 
     */
    public void setUpperLeftY(double value) {
        this.upperLeftY = value;
    }

    /**
     * Gets the value of the lowerLeftX property.
     * 
     */
    public double getLowerLeftX() {
        return lowerLeftX;
    }

    /**
     * Sets the value of the lowerLeftX property.
     * 
     */
    public void setLowerLeftX(double value) {
        this.lowerLeftX = value;
    }

    /**
     * Gets the value of the lowerLeftY property.
     * 
     */
    public double getLowerLeftY() {
        return lowerLeftY;
    }

    /**
     * Sets the value of the lowerLeftY property.
     * 
     */
    public void setLowerLeftY(double value) {
        this.lowerLeftY = value;
    }

    /**
     * Gets the value of the lowerRightX property.
     * 
     */
    public double getLowerRightX() {
        return lowerRightX;
    }

    /**
     * Sets the value of the lowerRightX property.
     * 
     */
    public void setLowerRightX(double value) {
        this.lowerRightX = value;
    }

    /**
     * Gets the value of the lowerRightY property.
     * 
     */
    public double getLowerRightY() {
        return lowerRightY;
    }

    /**
     * Sets the value of the lowerRightY property.
     * 
     */
    public void setLowerRightY(double value) {
        this.lowerRightY = value;
    }

    /**
     * Gets the value of the upperRightX property.
     * 
     */
    public double getUpperRightX() {
        return upperRightX;
    }

    /**
     * Sets the value of the upperRightX property.
     * 
     */
    public void setUpperRightX(double value) {
        this.upperRightX = value;
    }

    /**
     * Gets the value of the upperRightY property.
     * 
     */
    public double getUpperRightY() {
        return upperRightY;
    }

    /**
     * Sets the value of the upperRightY property.
     * 
     */
    public void setUpperRightY(double value) {
        this.upperRightY = value;
    }

}
