/*
 * Class: Enumeration
 *
 * Created on Jun 28, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.constant;

import java.util.HashMap;
import java.util.Map;

import vn.sps.aba.dds.common.types.exception.UnsupportedAttributeException;

/**
 * The Class Enumeration.
 */
public class Enumeration {

    /**
     * The Enum DmcState.
     */
    public enum DmcState {

        /** The dmc sent. */
        DMC_SENT,
        /** The no barcode available. */
        NO_BARCODE_AVAILABLE,
        /** The dmc sent. */
        NOT_YET,
        /** The padasa barcode ready. */
        PADASA_BARCODE_READY,
        /** The padasa barcode sent. */
        PADASA_BARCODE_SENT
    }

    /**
     * The Enum ParcelState.
     */
    public enum ParcelState {

        /** The blackbox ready. */
        BLACKBOX_READY,
        /** The blackbox sent. */
        BLACKBOX_SENT,
        /** The dmc processing. */
        DMC_PROCESSING,
        /** The filtering. */
        FILTERING,
        /** The matching ready. */
        MATCHING_READY,
        /** The no further processing. */
        NO_FURTHER_PROCESSING,
        /** The received. */
        RECEIVED,
        /** The rejected. */
        REJECTED,
        /** The vam capture result ready. */
        VAM_CAPTURE_RESULT_READY,
        /** The vam capture result sent. */
        VAM_CAPTURE_RESULT_SENT;
    }

    /**
     * The Enum ReceiverInfoStatus.
     */
    public enum ReceiverState {

        /** The invalid. */
        INVALID,
        /** The padasa sent. */
        PADASA_SENT,
        /** BUC-3: ABA-89: The padasa sent but not matching PDS. */
        PADASA_SENT_NOT_MATCHING,
        /** The new. */
        RECEIVED,
        /** The rejected. */
        REJECTED,
        /** The vam and padasa sent. */
        VAM_AND_PADASA_SENT,
        /** The vam done. */
        VAM_DONE,
        /** The vam and padasa ready. */
        VAM_PADASA_READY,
        /** BUC-3: ABA-89: The vam and padasa ready but not matching PDS. */
        VAM_PADASA_READY_NOT_MATCHING,
        /** BUC-3: ABA-89: The vam and padasa sent but not matching PDS. */
        VAM_PADASA_SENT_NOT_MATCHING,
        /** The vam and paddasa sent. */
        VAM_PADASA_SENT,
        /** The vam ready. */
        VAM_READY,
        /** BUC-3: ABA-89: The vam sent but not matching PDS. */
        VAM_SENT_NOT_MATCHING,
        /** The vam sent. */
        VAM_SENT,
        /** The verified. */
        VERIFIED,
        /** The verifying. */
        VERIFYING
    }

    /**
     * The Enum VerifiedField.
     */
    public enum VerifiedField {

        /** The Amp key. */
        AmpKey("Amp-Key"),
        /** The Domizil haus key. */
        DomizilHausKey("Domizil-HAUSKEY"),
        /** The Parcel haus key. */
        ParcelHausKey("Parcel-HAUSKEY"),
        /** The Pers key. */
        PersKey("Pers-Key");

        /** The verified fields. */
        private static Map<String, VerifiedField> verifiedFields = null;

        static {
            verifiedFields = new HashMap<>(4);
            for (final VerifiedField element : VerifiedField.values()) {
                final String name = element.getName();
                if (name != null) {
                    verifiedFields.put(name, element);
                }
            }
        }

        /**
         * For name.
         *
         * @param name
         *            the name
         * @return the verified field
         * @throws UnsupportedAttributeException
         *             the unsupported attribute exception
         */
        public static VerifiedField forName(final String name) throws UnsupportedAttributeException {

            final VerifiedField verifiedField = verifiedFields.get(name);

            if (verifiedField == null) {
                throw new UnsupportedAttributeException("Unsupport field [" + name + "] for checking verified receiver info");
            }

            return verifiedField;
        }

        /** The name. */
        private String name;

        /**
         * Instantiates a new verified field.
         *
         * @param name
         *            the name
         */
        private VerifiedField(final String name) {
            this.name = name;
        }

        /**
         * Gets the name.
         *
         * @return the name
         */
        public String getName() {
            return this.name;
        }

        /**
         * {@inheritDoc}
         *
         * @see java.lang.Enum#toString()
         */
        @Override
        public String toString() {
            return this.name;
        }
    }

    /**
     * Constructs a new <tt>Enumeration</tt>.
     */
    private Enumeration() {
    }
}
