/*
 * Class: CacheParcelScheduledCleaner
 *
 * Created on Oct 17, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.scheduled.preparer;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import vn.sps.aba.dds.config.task.scheduler.WorkspaceScheduleExecutor;
import vn.sps.aba.dds.controller.interfaces.IEntriesController;
import vn.sps.aba.dds.scheduled.AbstractCronScheduler;
import vn.sps.aba.dds.scheduled.DdsScheduledTask;

/**
 * The Class CacheParcelScheduledCleaner.
 */
@Component("DBErrorChecker")
@Configuration
@ConfigurationProperties("schedule.db.error.checker")
public class DBErrorChecker extends AbstractCronScheduler implements DdsScheduledTask {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DBErrorChecker.class);

    /** The parcel info controller. */
    @Autowired
    @Qualifier("ParcelInfoController")
    private IEntriesController parcelInfoController;

    /** The receiver info controller. */
    @Autowired
    @Qualifier("ReceiverInfoController")
    private IEntriesController receiverInfoController;

    /** The scheduled executor. */
    @Autowired
    private WorkspaceScheduleExecutor scheduledExecutor;

    /**
     * Config.
     */
    @PostConstruct
    protected void config() {
        this.scheduleConfigurar.registerScheduledTask(this, this.scheduledExecutor);
    }

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.beans.factory.DisposableBean#destroy()
     */
    @Override
    public void destroy() throws Exception {
        this.scheduledExecutor.getScheduler().destroy();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#getCronExpression()
     */
    @Override
    public String getCronExpression() {
        return this.getCron();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#handleTask()
     */
    @Override
    public Runnable handleTask() {
        return () -> {
            if (this.isEnable()) {
                LOG.info("Process parcel DB error: {}", this.parcelInfoController.processDBError(true));
                LOG.info("Process receiver DB error: {}", this.receiverInfoController.processDBError(true));
            }
        };
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.scheduled.DdsScheduledTask#taskName()
     */
    @Override
    public String taskName() {
        return "check-db-error";
    }

}
