package vn.sps.aba.dds.logging.report.field;

import java.io.Serializable;

import vn.sps.aba.dds.common.model.receiver.AddressFields;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
/**
 * One of AdresseErfassung's Fields.
 * Class VolleAdresse
 */
public class VolleAdresse implements Serializable {

	 /** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3636054847700138661L;

	/** The address fields. */
	private AddressFields fields;

	/** The address source. */
	private String kdpId;

	/** The parcel adr amp status. */
	private String parcelAdrAmpStatus;

	/** The parcel adr types. */
	private String parcelAdrType;

	/** The parcel haus key. */
	private String parcelHausKey;

	/** The parcel street number. */
	private String parcelStreetNumber;

	/** The pers status. */
	private String persStatus;

	/** The pers type. */
	private String persType;

	/**
	 * One of AdresseErfassung's Fields.
	 * @param vn.sps.aba.dds.common.model.receiver.VolleAdresse
	 * @param ReceiverInfo
	 */
	public VolleAdresse(vn.sps.aba.dds.common.model.receiver.VolleAdresse volleAdresse, ReceiverInfo receiverInfo) {
		this.fields = volleAdresse.getAddressFields();
		this.kdpId = receiverInfo.getKdpId();
		this.parcelAdrAmpStatus = volleAdresse.getParcelAdrAmpStatus();
		this.parcelAdrType = volleAdresse.getParcelAdrType();
		this.parcelHausKey = receiverInfo.getParcelHausKey();
		this.parcelStreetNumber = volleAdresse.getParcelStreetNumber();
		this.persStatus = volleAdresse.getPersStatus();
		this.persType = volleAdresse.getPersType();
	}

	/**
	 * @return the fields
	 */
	public AddressFields getFields() {
		return fields;
	}

	/**
	 * @return the kdpId
	 */
	public String getKdpId() {
		return kdpId;
	}

	/**
	 * @return the parcelAdrAmpStatus
	 */
	public String getParcelAdrAmpStatus() {
		return parcelAdrAmpStatus;
	}

	/**
	 * @return the parcelAdrType
	 */
	public String getParcelAdrType() {
		return parcelAdrType;
	}

	/**
	 * @return the parcelHausKey
	 */
	public String getParcelHausKey() {
		return parcelHausKey;
	}

	/**
	 * @return the parcelStreetNumber
	 */
	public String getParcelStreetNumber() {
		return parcelStreetNumber;
	}

	/**
	 * @return the persStatus
	 */
	public String getPersStatus() {
		return persStatus;
	}

	/**
	 * @return the persType
	 */
	public String getPersType() {
		return persType;
	}

}
