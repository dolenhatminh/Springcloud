/*
 * Class: ReceiverInfoProcessContext
 *
 * Created on Jul 9, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.processor.receiver;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.AsyncTaskExecutor;

import vn.sps.aba.dds.common.constant.Enumeration.ReceiverState;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.common.model.receiver.ReceiverInfo;
import vn.sps.aba.dds.common.time.DiscoWallClock;
import vn.sps.aba.dds.common.types.verifying.VerifiedRule;
import vn.sps.aba.dds.logging.IndexMaker;
import vn.sps.aba.dds.processor.receiver.handers.IReceiverStepHandler;
import vn.sps.aba.dds.processor.receiver.handers.StepForwardingHandler;

/**
 * The Class ReceiverInfoProcessContext.
 */
class ReceiverProcessingContext implements IReceiverProcessingContext {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ReceiverProcessingContext.class);

    /** The handlers. */
    private final Map<String, IReceiverStepHandler> handlers = new HashMap<>();

    /** The manager. */
    private final ReceiverProcessingManager manager;

    /**
     * Instantiates a new receiver info process context.
     *
     * @param manager            the manager
     * @param clock the clock
     */
    public ReceiverProcessingContext(final ReceiverProcessingManager manager) {
        this.manager = manager;
    }

    /**
     * Adds the handler.
     *
     * @param handler
     *            the handler
     */
    private void addHandler(final IReceiverStepHandler handler) {
        this.handlers.put(handler.getHandlerName(), handler);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext#getCommonTaskExecutor()
     */
    @Override
    public AsyncTaskExecutor getReceiverSendingExecutor() {
        return this.manager.getReceiverSendingExecutor().getAsyncExecutor();
    }

    /**
     * {@inheritDoc} c
     *
     * @see vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext#getRules()
     */
    @Override
    public List<VerifiedRule> getRules() {
        return this.manager.getVerifiedRuleConfiguration().getRules();
    }

    /**
     * Handle.
     *
     * @param receiverInfo
     *            the receiver info
     */
    void handle(final ReceiverInfo receiverInfo) {

        try {
            receiverInfo.setProcessBegin(DiscoWallClock.milli());
            this.addHandler(new StepForwardingHandler());

            this.handle("STEP_FORWARDING_HANDLER", receiverInfo);

            receiverInfo.setProcessEnd(DiscoWallClock.milli());
            this.manager.getReceiverInfoDpmDao().put(receiverInfo.getIdentCode(), receiverInfo);
            LOG.info(IndexMaker.index(receiverInfo), "Finish processing receiver info");
        }
        catch (final Exception e) {
            LOG.error(IndexMaker.indexes(receiverInfo), "There is error while processing receiver info", e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext#handle(java.lang.String,
     *      vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    public void handle(final String state, final ReceiverInfo receiverInfo) {
        final IReceiverStepHandler handler = this.handlers.get(state);

        if (handler != null) {
            handler.handle(this, receiverInfo);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext#queueForResendCaptureResult(vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    public void queueForResendCaptureResult(final ReceiverInfo receiverInfo) {
        this.manager.getVamScheduledSender().queue(receiverInfo);
        LOG.info(IndexMaker.index(receiverInfo), "Receiver info was queued up to re-send to Vam CaptureResult service");
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext#queueForResendMatchMaker(vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    public void queueForResendMatchMaker(final ReceiverInfo receiverInfo) {
        this.manager.getMatchmakerScheduledSender().queue(receiverInfo);
        LOG.info(IndexMaker.index(receiverInfo), "Receiver info was queued up to re-send to Padasa MatchMaker service");
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.padasa.matchmakerdaten.IMatchMakerDatenService#transferToMatchMaker(vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    public boolean transferToMatchMaker(final ReceiverInfo receiverInfo) {
        return this.manager.getMatchMakerDatenService().transferToMatchMaker(receiverInfo);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.vam.ICaptureResultService#transferToVamStation(vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public boolean transferToVamStation(final ParcelInfo parcelInfo) {
        return this.manager.getCaptureResultService().transferToVamStation(parcelInfo);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.service.vam.ICaptureResultService#transferToVamStation(vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    public boolean transferToVamStation(final ReceiverInfo receiverInfo) {
        return this.manager.getCaptureResultService().transferToVamStation(receiverInfo);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext#transmitStateTo(vn.sps.aba.dds.common.model.receiver.ReceiverInfo, vn.sps.aba.dds.common.constant.Enumeration.ReceiverState)
     */
    @Override
    public void transmitStateTo(final ReceiverInfo receiverInfo, final ReceiverState state) {

        receiverInfo.setState(state);
        LOG.debug(IndexMaker.index(receiverInfo), "Receiver info was changed status to {}", receiverInfo.getState());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.processor.receiver.IReceiverProcessingContext#updateReceiverInfo(vn.sps.aba.dds.common.model.receiver.ReceiverInfo)
     */
    @Override
    public void updateReceiverInfo(final ReceiverInfo receiverInfo) {
        manager.getReceiverInfoDpmDao().store(receiverInfo.getKey(), receiverInfo);
    }

    @Override
    public void submitCaptureResult(ReceiverInfo receiverInfo) {
        manager.getReceiver2VamSender().submitItem(receiverInfo);
    }

    @Override
    public void submitMatchMaker(ReceiverInfo receiverInfo) {
        manager.getMatchMakerSender().submitItem(receiverInfo);
    }

}
