
package vn.sps.aba.dds.common.types.ws.dpm.model;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusCodeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="StatusCodeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Successful"/>
 *     &lt;enumeration value="ServiceAvailable"/>
 *     &lt;enumeration value="InvalidData"/>
 *     &lt;enumeration value="FailedToStoreData"/>
 *     &lt;enumeration value="UnexpectedError"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "StatusCodeType")
@XmlEnum
public enum StatusCodeType {

    @XmlEnumValue("Successful")
    SUCCESSFUL("Successful"),
    @XmlEnumValue("ServiceAvailable")
    SERVICE_AVAILABLE("ServiceAvailable"),
    @XmlEnumValue("InvalidData")
    INVALID_DATA("InvalidData"),
    @XmlEnumValue("FailedToStoreData")
    FAILED_TO_STORE_DATA("FailedToStoreData"),
    @XmlEnumValue("UnexpectedError")
    UNEXPECTED_ERROR("UnexpectedError");
    private final String value;

    StatusCodeType(String v) {
        value = v;
    }
    
    private static Map<String,StatusCodeType> statusCodes;
    
    static{
    	
    	statusCodes = new HashMap<String, StatusCodeType>();
    	
    	for (StatusCodeType status : values()) {
			statusCodes.put(status.value(), status);
		}
    }
    
    public static StatusCodeType forName(String value){
    	StatusCodeType statusCodeType = statusCodes.get(value);
    	
    	if(statusCodeType==null){
    		
    		throw new IllegalArgumentException("Invalid status code value ["+value+"]");
    	}
    	
    	return statusCodeType;
    }

    public String value() {
        return value;
    }

    public static StatusCodeType fromValue(String v) {
        for (StatusCodeType c: StatusCodeType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
