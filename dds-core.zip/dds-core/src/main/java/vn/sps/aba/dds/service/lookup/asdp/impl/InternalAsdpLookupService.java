/*
 * Class: InternalAsdpLookupService
 * 
 * Created on Oct 13, 2016
 * 
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.lookup.asdp.impl;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import vn.sps.aba.dds.common.model.lookup.IAsdpPlz;
import vn.sps.aba.dds.common.model.parcel.ParcelInfo;
import vn.sps.aba.dds.repository.cache.interfaces.IAsdpPlzCacheDao;
import vn.sps.aba.dds.service.lookup.asdp.IAsdpLookupService;

/**
 * The Class InternalAsdpLookupService.
 */
@Service
@ConditionalOnProperty(name = "lookup.asdp.external", havingValue = "false")
public class InternalAsdpLookupService implements IAsdpLookupService {
    
    /** The Constant LOG. */
    private static final Logger LOG =LoggerFactory.getLogger(InternalAsdpLookupService.class);

    /** The asdp plz cache dao. */
    @Autowired
    private IAsdpPlzCacheDao asdpPlzCacheDao;

    /**
     * Initialize.
     */
    @PostConstruct
    protected void initialize(){
        LOG.info("Initialize the internal lookup Asdp Plz");
    }
    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.service.lookup.asdp.IAsdpLookupService#getAsdpPlz(java.lang.String)
     */
    @Override
    public IAsdpPlz getAsdpPlz(String plz) {
        return asdpPlzCacheDao.get(plz);
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.service.lookup.asdp.IAsdpLookupService#getAsdpPlz(vn.sps.aba.dds.common.model.parcel.ParcelInfo)
     */
    @Override
    public IAsdpPlz getAsdpPlz(ParcelInfo parcelInfo) {
        return getAsdpPlz(parcelInfo.getParcelAddress().getZip());
    }

}
