/*
 * Class: VolleAddressEntity
 *
 * Created on Jul 13, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.entity.receiver;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import vn.sps.aba.dds.common.constant.TableNames;
import vn.sps.aba.dds.common.model.receiver.VolleAdresse;

/**
 * The Class VolleAddressEntity.
 */
@Entity
@Table(name = TableNames.REC_VOLLE_ADDRESS)
@Access(AccessType.PROPERTY)
public class VolleAddressEntity implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -1483513875587723774L;

    /** The address fields. */
    private AddressFieldsEntity addressFields;

    /** The address source. */
    private String addressSource;

    /** The id. */
    private Long id;

    /** The parcel adr amp status. */
    private String parcelAdrAmpStatus;

    /** The parcel adr types. */
    private String parcelAdrTypes;

    /** The parcel street number. */
    private String parcelStreetNumber;

    /** The pers status. */
    private String persStatus;

    /** The pers type. */
    private String persType;

    /**
     * Instantiates a new volle address entity.
     */
    public VolleAddressEntity() {
    }

    /**
     * Instantiates a new volle address entity.
     *
     * @param volleAdresse
     *            the volle adresse
     */
    public VolleAddressEntity(final VolleAdresse volleAdresse) {

        this.setParcelAdrAmpStatus(volleAdresse.getParcelAdrAmpStatus());
        this.setParcelAdrTypes(volleAdresse.getParcelAdrType());
        this.setParcelStreetNumber(volleAdresse.getParcelStreetNumber());
        this.setPersStatus(volleAdresse.getPersStatus());
        this.setPersType(volleAdresse.getPersType());
        this.setAddressSource(volleAdresse.getAddressSource());

        if (volleAdresse.getAddressFields() != null) {
            this.addressFields = new AddressFieldsEntity(volleAdresse.getAddressFields());
        }
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.VolleAdresse#getAddressFields()
     */

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "address_fields_id")
    public AddressFieldsEntity getAddressFields() {
        return this.addressFields;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.VolleAdresse#getAddressSource()
     */

    @Column(name = "address_source", length = 50)
    public String getAddressSource() {
        return this.addressSource;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    @Id
    @SequenceGenerator(name = "volle_address_generator", sequenceName = "rec_volle_address_seq", initialValue = 1, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "volle_address_generator")
    @JoinColumn(name = "id", columnDefinition = "bigserial")
    public Long getId() {
        return this.id;
    }

    /**
     * Gets the parcel adr amp status string.
     *
     * @return the parcel adr amp status string
     */
    @Column(name = "parcel_adr_amp_status", length = 100)
    public String getParcelAdrAmpStatus() {
        return this.parcelAdrAmpStatus;
    }

    /**
     * Gets the parcel adr types string.
     *
     * @return the parcel adr types string
     */
    @Column(name = "parcel_adr_types", length = 255)
    public String getParcelAdrTypes() {
        return this.parcelAdrTypes;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.model.receiver.VolleAdresse#getParcelStreetNumber()
     */

    @Column(name = "parcel_street_number", length = 50)
    public String getParcelStreetNumber() {
        return this.parcelStreetNumber;
    }

    /**
     * Gets the pers status string.
     *
     * @return the pers status string
     */
    @Column(name = "pers_status", length = 100)
    public String getPersStatus() {
        return this.persStatus;
    }

    /**
     * Gets the pers type string.
     *
     * @return the pers type string
     */
    @Column(name = "pers_type", length = 100)
    public String getPersType() {
        return this.persType;
    }

    /**
     * Sets the address fields.
     *
     * @param addressFields
     *            the new address fields
     */
    public void setAddressFields(final AddressFieldsEntity addressFields) {
        this.addressFields = addressFields;
    }

    /**
     * Sets the address source.
     *
     * @param addressSource
     *            the new address source
     */
    private void setAddressSource(final String addressSource) {
        this.addressSource = addressSource;
    }

    /**
     * Sets the id.
     *
     * @param id
     *            the new id
     */
    public void setId(final Long id) {
        this.id = id;
    }

    /**
     * Sets the parcel adr amp status string.
     *
     * @param parcelAdrAmpStatus
     *            the new parcel adr amp status
     */
    public void setParcelAdrAmpStatus(final String parcelAdrAmpStatus) {
        this.parcelAdrAmpStatus = parcelAdrAmpStatus;
    }

    /**
     * Sets the parcel adr types string.
     *
     * @param parcelAdrTypes
     *            the new parcel adr types
     */
    public void setParcelAdrTypes(final String parcelAdrTypes) {
        this.parcelAdrTypes = parcelAdrTypes;
    }

    /**
     * Sets the parcel street number.
     *
     * @param parcelStreetNumber
     *            the new parcel street number
     */
    private void setParcelStreetNumber(final String parcelStreetNumber) {
        this.parcelStreetNumber = parcelStreetNumber;
    }

    /**
     * Sets the pers status string.
     *
     * @param persStatus
     *            the new pers status
     */
    public void setPersStatus(final String persStatus) {
        this.persStatus = persStatus;
    }

    /**
     * Sets the pers type string.
     *
     * @param persType
     *            the new pers type
     */
    public void setPersType(final String persType) {
        this.persType = persType;
    }
}
