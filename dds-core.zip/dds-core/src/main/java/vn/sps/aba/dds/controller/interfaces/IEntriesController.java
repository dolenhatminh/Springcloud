/*
 * Class: IEntryInteractionController
 *
 * Created on Aug 6, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.controller.interfaces;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import vn.sps.aba.dds.common.types.statistic.Status;

/**
 * The Interface IEntryInteractionController.
 */
public interface IEntriesController {

    /**
     * Check and persist.
     *
     * @param key the key
     * @return 0: do nothing, -1: store failed, 1: store successful
     */
    @RequestMapping(value = "/check-and-persist", method = RequestMethod.POST)
    int checkAndPersist(String key);

    /**
     * Clear cache.
     */
    @RequestMapping(path = "/clear", method = RequestMethod.DELETE)
    void clearCache();

    /**
     * Count.
     *
     * @return the list
     */
    @RequestMapping(value = "/count-status/unlimit", method = RequestMethod.GET)
    List<Status> count();

    /**
     * Count.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @return the list
     */
    @RequestMapping(value = "/count-status", method = RequestMethod.GET)
    List<Status> count(String fromTime, String toTime);

    /**
     * Persist in-memory entries to database.
     *
     * @param fromTime the from time
     * @param toTime the to time
     * @param size the size
     * @return the string[]
     */
    @RequestMapping(value = "/persist", method = RequestMethod.POST)
    String[] persist(final LocalDateTime fromTime, final LocalDateTime toTime, int size);

    /**
     * Process db error.
     *
     * @param wait the wait
     * @return the string
     */
    @RequestMapping(value = "/process-db-error", method = RequestMethod.POST)
    String processDBError(boolean wait);

    /**
     * Process duplicated entries.
     */
    @RequestMapping(value = "/process-duplicated", method = RequestMethod.POST)
    void processDuplicatedEntries();

    /**
     * Removes the expired entries.
     */
    @RequestMapping(value = "/process-expired", method = RequestMethod.POST)
    void processExpiredEntries();
}
