
package vn.sps.aba.dds.common.types.ws.vae.blackbox;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.Duration;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the vn.sps.aba.dds.service.vae.blackbox package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _UnsignedLong_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedLong");
    private final static QName _UnsignedByte_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedByte");
    private final static QName _UnsignedShort_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedShort");
    private final static QName _Duration_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "duration");
    private final static QName _CaptureRequestRecord_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "CaptureRequestRecord");
    private final static QName _ArrayOfProduktZusatzleistung_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "ArrayOfProduktZusatzleistung");
    private final static QName _ParcelData_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "ParcelData");
    private final static QName _Long_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "long");
    private final static QName _Float_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "float");
    private final static QName _DateTime_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "dateTime");
    private final static QName _AnyType_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "anyType");
    private final static QName _String_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "string");
    private final static QName _AddressFields_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "AddressFields");
    private final static QName _Char_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "char");
    private final static QName _UnsignedInt_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedInt");
    private final static QName _Guid_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "guid");
    private final static QName _Short_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "short");
    private final static QName _Decimal_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "decimal");
    private final static QName _Boolean_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "boolean");
    private final static QName _Base64Binary_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "base64Binary");
    private final static QName _ProduktZusatzleistung_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "ProduktZusatzleistung");
    private final static QName _Int_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "int");
    private final static QName _AnyURI_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "anyURI");
    private final static QName _CaptureRequestResponse_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "CaptureRequestResponse");
    private final static QName _QName_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "QName");
    private final static QName _Byte_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "byte");
    private final static QName _Double_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "double");
    private final static QName _CaptureRequestRecordIdentCode_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "IdentCode");
    private final static QName _CaptureRequestRecordKundennummer_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "Kundennummer");
    private final static QName _CaptureRequestRecordDienstleistung_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "Dienstleistung");
    private final static QName _SubmitCaptureRequestResponseSubmitCaptureRequestResult_QNAME = new QName("http://tempuri.org/", "SubmitCaptureRequestResult");
    private final static QName _AddressFieldsFirmenname_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "Firmenname");
    private final static QName _AddressFieldsAnrede_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "Anrede");
    private final static QName _AddressFieldsLand_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "Land");
    private final static QName _AddressFieldsName_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "Name");
    private final static QName _AddressFieldsVorname_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "Vorname");
    private final static QName _AddressFieldsStrasse_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "Strasse");
    private final static QName _AddressFieldsCoAdresse_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "CoAdresse");
    private final static QName _AddressFieldsStockwerk_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "Stockwerk");
    private final static QName _AddressFieldsPostleitzahl_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "Postleitzahl");
    private final static QName _AddressFieldsNameZusatz_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "NameZusatz");
    private final static QName _AddressFieldsHausnummerZusatz_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "HausnummerZusatz");
    private final static QName _AddressFieldsOrt_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "Ort");
    private final static QName _SubmitCaptureRequestCaptureRequest_QNAME = new QName("http://tempuri.org/", "captureRequest");
    private final static QName _AdresseErfassungADRID_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "ADRID");
    private final static QName _AdresseErfassungHAUSKEY_QNAME = new QName("http://schemas.datacontract.org/2004/07/DisCoService", "HAUSKEY");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: vn.sps.aba.dds.service.vae.blackbox
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SubmitCaptureRequestResponse }
     * 
     */
    public SubmitCaptureRequestResponse createSubmitCaptureRequestResponse() {
        return new SubmitCaptureRequestResponse();
    }

    /**
     * Create an instance of {@link CaptureRequestResponse }
     * 
     */
    public CaptureRequestResponse createCaptureRequestResponse() {
        return new CaptureRequestResponse();
    }

    /**
     * Create an instance of {@link SubmitCaptureRequest }
     * 
     */
    public SubmitCaptureRequest createSubmitCaptureRequest() {
        return new SubmitCaptureRequest();
    }

    /**
     * Create an instance of {@link CaptureRequestRecord }
     * 
     */
    public CaptureRequestRecord createCaptureRequestRecord() {
        return new CaptureRequestRecord();
    }

    /**
     * Create an instance of {@link ProduktZusatzleistung }
     * 
     */
    public ProduktZusatzleistung createProduktZusatzleistung() {
        return new ProduktZusatzleistung();
    }

    /**
     * Create an instance of {@link ArrayOfProduktZusatzleistung }
     * 
     */
    public ArrayOfProduktZusatzleistung createArrayOfProduktZusatzleistung() {
        return new ArrayOfProduktZusatzleistung();
    }

    /**
     * Create an instance of {@link AddressFields }
     * 
     */
    public AddressFields createAddressFields() {
        return new AddressFields();
    }

    /**
     * Create an instance of {@link ParcelData }
     * 
     */
    public ParcelData createParcelData() {
        return new ParcelData();
    }

    /**
     * Create an instance of {@link IdentCodeOrientation }
     * 
     */
    public IdentCodeOrientation createIdentCodeOrientation() {
        return new IdentCodeOrientation();
    }

    /**
     * Create an instance of {@link ParcelAddress }
     * 
     */
    public ParcelAddress createParcelAddress() {
        return new ParcelAddress();
    }

    /**
     * Create an instance of {@link AdresseErfassung }
     * 
     */
    public AdresseErfassung createAdresseErfassung() {
        return new AdresseErfassung();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedLong")
    public JAXBElement<BigInteger> createUnsignedLong(BigInteger value) {
        return new JAXBElement<BigInteger>(_UnsignedLong_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Short }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedByte")
    public JAXBElement<Short> createUnsignedByte(Short value) {
        return new JAXBElement<Short>(_UnsignedByte_QNAME, Short.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedShort")
    public JAXBElement<Integer> createUnsignedShort(Integer value) {
        return new JAXBElement<Integer>(_UnsignedShort_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Duration }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "duration")
    public JAXBElement<Duration> createDuration(Duration value) {
        return new JAXBElement<Duration>(_Duration_QNAME, Duration.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureRequestRecord }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "CaptureRequestRecord")
    public JAXBElement<CaptureRequestRecord> createCaptureRequestRecord(CaptureRequestRecord value) {
        return new JAXBElement<CaptureRequestRecord>(_CaptureRequestRecord_QNAME, CaptureRequestRecord.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfProduktZusatzleistung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "ArrayOfProduktZusatzleistung")
    public JAXBElement<ArrayOfProduktZusatzleistung> createArrayOfProduktZusatzleistung(ArrayOfProduktZusatzleistung value) {
        return new JAXBElement<ArrayOfProduktZusatzleistung>(_ArrayOfProduktZusatzleistung_QNAME, ArrayOfProduktZusatzleistung.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParcelData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "ParcelData")
    public JAXBElement<ParcelData> createParcelData(ParcelData value) {
        return new JAXBElement<ParcelData>(_ParcelData_QNAME, ParcelData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "long")
    public JAXBElement<Long> createLong(Long value) {
        return new JAXBElement<Long>(_Long_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Float }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "float")
    public JAXBElement<Float> createFloat(Float value) {
        return new JAXBElement<Float>(_Float_QNAME, Float.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "dateTime")
    public JAXBElement<Object> createDateTime(Object value) {
        return new JAXBElement<Object>(_DateTime_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "anyType")
    public JAXBElement<Object> createAnyType(Object value) {
        return new JAXBElement<Object>(_AnyType_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "string")
    public JAXBElement<String> createString(String value) {
        return new JAXBElement<String>(_String_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressFields }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "AddressFields")
    public JAXBElement<AddressFields> createAddressFields(AddressFields value) {
        return new JAXBElement<AddressFields>(_AddressFields_QNAME, AddressFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "char")
    public JAXBElement<Integer> createChar(Integer value) {
        return new JAXBElement<Integer>(_Char_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedInt")
    public JAXBElement<Long> createUnsignedInt(Long value) {
        return new JAXBElement<Long>(_UnsignedInt_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "guid")
    public JAXBElement<String> createGuid(String value) {
        return new JAXBElement<String>(_Guid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Short }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "short")
    public JAXBElement<Short> createShort(Short value) {
        return new JAXBElement<Short>(_Short_QNAME, Short.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "decimal")
    public JAXBElement<BigDecimal> createDecimal(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_Decimal_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "boolean")
    public JAXBElement<Boolean> createBoolean(Boolean value) {
        return new JAXBElement<Boolean>(_Boolean_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link byte[]}{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "base64Binary")
    public JAXBElement<byte[]> createBase64Binary(byte[] value) {
        return new JAXBElement<byte[]>(_Base64Binary_QNAME, byte[].class, null, ((byte[]) value));
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProduktZusatzleistung }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "ProduktZusatzleistung")
    public JAXBElement<ProduktZusatzleistung> createProduktZusatzleistung(ProduktZusatzleistung value) {
        return new JAXBElement<ProduktZusatzleistung>(_ProduktZusatzleistung_QNAME, ProduktZusatzleistung.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "int")
    public JAXBElement<Integer> createInt(Integer value) {
        return new JAXBElement<Integer>(_Int_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "anyURI")
    public JAXBElement<String> createAnyURI(String value) {
        return new JAXBElement<String>(_AnyURI_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureRequestResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "CaptureRequestResponse")
    public JAXBElement<CaptureRequestResponse> createCaptureRequestResponse(CaptureRequestResponse value) {
        return new JAXBElement<CaptureRequestResponse>(_CaptureRequestResponse_QNAME, CaptureRequestResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "QName")
    public JAXBElement<QName> createQName(QName value) {
        return new JAXBElement<QName>(_QName_QNAME, QName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Byte }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "byte")
    public JAXBElement<Byte> createByte(Byte value) {
        return new JAXBElement<Byte>(_Byte_QNAME, Byte.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "double")
    public JAXBElement<Double> createDouble(Double value) {
        return new JAXBElement<Double>(_Double_QNAME, Double.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "IdentCode", scope = CaptureRequestRecord.class)
    public JAXBElement<String> createCaptureRequestRecordIdentCode(String value) {
        return new JAXBElement<String>(_CaptureRequestRecordIdentCode_QNAME, String.class, CaptureRequestRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "Kundennummer", scope = CaptureRequestRecord.class)
    public JAXBElement<String> createCaptureRequestRecordKundennummer(String value) {
        return new JAXBElement<String>(_CaptureRequestRecordKundennummer_QNAME, String.class, CaptureRequestRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "Dienstleistung", scope = CaptureRequestRecord.class)
    public JAXBElement<Integer> createCaptureRequestRecordDienstleistung(Integer value) {
        return new JAXBElement<Integer>(_CaptureRequestRecordDienstleistung_QNAME, Integer.class, CaptureRequestRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureRequestResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "SubmitCaptureRequestResult", scope = SubmitCaptureRequestResponse.class)
    public JAXBElement<CaptureRequestResponse> createSubmitCaptureRequestResponseSubmitCaptureRequestResult(CaptureRequestResponse value) {
        return new JAXBElement<CaptureRequestResponse>(_SubmitCaptureRequestResponseSubmitCaptureRequestResult_QNAME, CaptureRequestResponse.class, SubmitCaptureRequestResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "Firmenname", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsFirmenname(String value) {
        return new JAXBElement<String>(_AddressFieldsFirmenname_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "Anrede", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsAnrede(String value) {
        return new JAXBElement<String>(_AddressFieldsAnrede_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "Land", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsLand(String value) {
        return new JAXBElement<String>(_AddressFieldsLand_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "Name", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsName(String value) {
        return new JAXBElement<String>(_AddressFieldsName_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "Vorname", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsVorname(String value) {
        return new JAXBElement<String>(_AddressFieldsVorname_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "Strasse", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsStrasse(String value) {
        return new JAXBElement<String>(_AddressFieldsStrasse_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "CoAdresse", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsCoAdresse(String value) {
        return new JAXBElement<String>(_AddressFieldsCoAdresse_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "Stockwerk", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsStockwerk(String value) {
        return new JAXBElement<String>(_AddressFieldsStockwerk_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "Postleitzahl", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsPostleitzahl(String value) {
        return new JAXBElement<String>(_AddressFieldsPostleitzahl_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "NameZusatz", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsNameZusatz(String value) {
        return new JAXBElement<String>(_AddressFieldsNameZusatz_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "HausnummerZusatz", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsHausnummerZusatz(String value) {
        return new JAXBElement<String>(_AddressFieldsHausnummerZusatz_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "Ort", scope = AddressFields.class)
    public JAXBElement<String> createAddressFieldsOrt(String value) {
        return new JAXBElement<String>(_AddressFieldsOrt_QNAME, String.class, AddressFields.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CaptureRequestRecord }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "captureRequest", scope = SubmitCaptureRequest.class)
    public JAXBElement<CaptureRequestRecord> createSubmitCaptureRequestCaptureRequest(CaptureRequestRecord value) {
        return new JAXBElement<CaptureRequestRecord>(_SubmitCaptureRequestCaptureRequest_QNAME, CaptureRequestRecord.class, SubmitCaptureRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "ADRID", scope = AdresseErfassung.class)
    public JAXBElement<Integer> createAdresseErfassungADRID(Integer value) {
        return new JAXBElement<Integer>(_AdresseErfassungADRID_QNAME, Integer.class, AdresseErfassung.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/DisCoService", name = "HAUSKEY", scope = AdresseErfassung.class)
    public JAXBElement<Integer> createAdresseErfassungHAUSKEY(Integer value) {
        return new JAXBElement<Integer>(_AdresseErfassungHAUSKEY_QNAME, Integer.class, AdresseErfassung.class, value);
    }

}
