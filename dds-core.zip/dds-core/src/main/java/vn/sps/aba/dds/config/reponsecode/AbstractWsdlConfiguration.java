/*
 * Class: AbstractWsdlConfiguration
 *
 * Created on Jul 26, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config.reponsecode;

import java.util.HashMap;
import java.util.Map;

import vn.sps.aba.dds.common.types.ws.response.ResponseCode;

/**
 * The Class AbstractWsdlConfiguration.
 *
 * @param <T> the generic type
 */
public class AbstractWsdlConfiguration<T> {

    /** The response codes. */
    private Map<String, ResponseCode<T>> responseCodes = new HashMap<>();

    /**
     * Gets the response codes.
     *
     * @return the response codes
     */
    public Map<String, ResponseCode<T>> getResponseCodes() {
        return this.responseCodes;
    }

    /**
     * Sets the response codes.
     *
     * @param responseCodes the response codes
     */
    public void setResponseCodes(final Map<String, ResponseCode<T>> responseCodes) {
        this.responseCodes = responseCodes;
    }
}
