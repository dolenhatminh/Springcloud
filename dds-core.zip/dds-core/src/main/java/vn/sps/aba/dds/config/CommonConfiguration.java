/*
 * Class: CommonConfiguration
 *
 * Created on Jun 16, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.config;

import java.time.ZoneId;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.transport.http.MessageDispatcherServlet;

import vn.sps.aba.dds.common.constant.DDSConstant;
import vn.sps.aba.dds.jmx.CommonInfo;

/**
 * The Class CommonConfiguration.
 */
@EnableWs
@Configuration("CommonConfiguration")
@ConfigurationProperties(prefix = "common")
public class CommonConfiguration implements CommonInfo {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(CommonConfiguration.class);

    /** The application url. */
    private String applicationUrl;

    /** The image dir format. */
    private String imageDirFormat;

    /** The image per folder. */
    private int imagePerFolder;

    /**
     * The mapping URL.
     */
    private String[] mappingUrls;

    /** The ip of server. */
    private String serverHost;

    /**
     * The shared storage.
     */
    private String sharedStorage;

    /**
     * The store image.
     */
    private boolean storeImage;

    /** The zone id. */
    private ZoneId zoneId;

    /**
     * Gets the application url.
     *
     * @return the application url
     */
    @Override
    public String getApplicationUrl() {
        return this.applicationUrl;
    }

    /**
     * Gets the image dir format.
     *
     * @return the image dir format
     */
    @Override
    public String getImageDirFormat() {
        return this.imageDirFormat;
    }

    /**
     * Gets the image per folder.
     *
     * @return the image per folder
     */
    @Override
    public int getImagePerFolder() {
        return this.imagePerFolder;
    }

    /**
     * Gets the mapping urls.
     *
     * @return the mapping urls
     */
    public String[] getMappingUrls() {
        return this.mappingUrls;
    }

    /**
     * Get server host.
     *
     * @return server host
     */
    public String getServerHost() {
        return this.serverHost;
    }

    /**
     * Gets the shared storage.
     *
     * @return Returns the sharedStorage.
     */
    @Override
    @ManagedAttribute(description = "SharedStorage")
    public String getSharedStorage() {
        return this.sharedStorage;
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.aba.dds.jmx.CommonInfo#getTimeZone()
     */
    @Override
    public String getTimeZone() {
        return this.getZoneId().getId();
    }

    /**
     * Gets the zone id.
     *
     * @return the zone id
     */
    public ZoneId getZoneId() {
        return this.zoneId;
    }

    /**
     * Initialize.
     */
    @PostConstruct
    protected void initialize() {
        final String port = System.getProperties().getProperty(DDSConstant.Common.SERVER_PORT_KEY);
        this.applicationUrl = this.serverHost + DDSConstant.Common.COLON + port;
        LOG.info("Application url: " + this.applicationUrl);
    }

    /**
     * Checks if is store image.
     *
     * @return Returns the storeImage.
     */
    public boolean isStoreImage() {
        return this.storeImage;
    }

    /**
     * Message dispatcher servlet.
     *
     * @param applicationContext the application context
     * @return the servlet registration bean
     */
    @Bean
    public ServletRegistrationBean messageDispatcherServlet(final ApplicationContext applicationContext) {
        final MessageDispatcherServlet servlet = new MessageDispatcherServlet();
        {
            servlet.setApplicationContext(applicationContext);
            servlet.setTransformWsdlLocations(true);
        }
        return new ServletRegistrationBean(servlet, this.mappingUrls);
    }

    /**
     * Sets the image dir format.
     *
     * @param imageDirFormat the new image dir format
     */
    public void setImageDirFormat(final String imageDirFormat) {
        this.imageDirFormat = imageDirFormat;
    }

    /**
     * Sets the image per folder.
     *
     * @param imagePerFolder the new image per folder
     */
    public void setImagePerFolder(final int imagePerFolder) {
        this.imagePerFolder = imagePerFolder;
    }

    /**
     * Sets the mapping urls.
     *
     * @param mappingUrls the new mapping urls
     */
    public void setMappingUrls(final String[] mappingUrls) {
        this.mappingUrls = mappingUrls;
    }

    /**
     * Set server host.
     *
     * @param serverHost the new server host
     */
    public void setServerHost(final String serverHost) {
        this.serverHost = serverHost;
    }

    /**
     * Sets the shared storage.
     *
     * @param sharedStorage The sharedStorage to set.
     */
    public void setSharedStorage(final String sharedStorage) {
        this.sharedStorage = sharedStorage;
    }

    /**
     * Sets the store image.
     *
     * @param storeImage The storeImage to set.
     */
    public void setStoreImage(final boolean storeImage) {
        this.storeImage = storeImage;
    }

    /**
     * Sets the zone id.
     *
     * @param zoneId the new zone id
     */
    public void setZoneId(final String zoneId) {
        try {
            this.zoneId = ZoneId.of(zoneId);
        }
        catch (final Exception e) {
            this.zoneId = ZoneId.systemDefault();
            LOG.warn("Error when initialize the timezone. Use the default system timezone istead", e);
        }
    }
}
