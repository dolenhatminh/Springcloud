/*
 * Class: ParcelDataEntity
 *
 * Created on Jul 25, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package vn.sps.aba.dds.repository.entity.receiver;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import vn.sps.aba.dds.common.constant.Constant;
import vn.sps.aba.dds.common.constant.TableNames;
import vn.sps.aba.dds.common.model.receiver.ParcelData;

/**
 * The Class ParcelDataEntity.
 */
@Entity
@Table(name = TableNames.REC_PARCEL_DATA)
@Access(AccessType.PROPERTY)
public class ParcelDataEntity implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 3742393991008109190L;

    /** The acs timestamp. */
    private String acsTimestamp;

    /** The destination station. */
    private String destinationStation;

    /** The id. */
    private Long id;

    /** The par pic id. */
    private String parPicId;

    /** The source station. */
    private String sourceStation;

    /** The vcs case. */
    private String vcsCase;

    /** The zusatz leistungen. */
    private String zusatzLeistungen;

    /**
     * Instantiates a new parcel data entity.
     */
    public ParcelDataEntity() {
    }

    /**
     * Instantiates a new parcel data entity.
     *
     * @param parcelData the parcel data
     */
    public ParcelDataEntity(final ParcelData parcelData) {
        this.setAcsTimestamp(parcelData.getAcsTimestamp());
        this.destinationStation = parcelData.getDestinationStation();
        this.sourceStation = parcelData.getSourceStation();
        this.parPicId = parcelData.getParPicId();
        this.vcsCase = parcelData.getVcsCase();
        this.zusatzLeistungen = String.join(Constant.CHAR_COMMA, parcelData.getZusatzLeistungenAsString());
    }

    /**
     * Gets the acs timestamp.
     *
     * @return the acs timestamp
     */
    @Column(name = "acs_timestamp")
    public String getAcsTimestamp() {
        return this.acsTimestamp;
    }

    /**
     * Gets the destination station.
     *
     * @return the destination station
     */
    @Column(name = "destination_station", length = 100)
    public String getDestinationStation() {
        return this.destinationStation;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    @Id
    @SequenceGenerator(name = "parcel_data_generator", sequenceName = "rec_parcel_data_id_seq", initialValue = 1, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "parcel_data_generator")
    @JoinColumn(name = "id", columnDefinition = "bigserial")
    public Long getId() {
        return this.id;
    }

    /**
     * Gets the par pic id.
     *
     * @return the par pic id
     */
    @Column(name = "parpic_id", length = 100)
    public String getParPicId() {
        return this.parPicId;
    }

    /**
     * Gets the source station.
     *
     * @return the source station
     */
    @Column(name = "source_station", length = 100)
    public String getSourceStation() {
        return this.sourceStation;
    }

    /**
     * Gets the vcs case.
     *
     * @return the vcs case
     */
    @Column(name = "vcs_case", length = 100)
    public String getVcsCase() {
        return this.vcsCase;
    }

    /**
     * Gets the zusatz leistungen.
     *
     * @return the zusatz leistungen
     */
    @Column(name = "zusatz_leistungen", length = 100)
    public String getZusatzLeistungen() {
        return this.zusatzLeistungen;
    }

    /**
     * Sets the acs timestamp.
     *
     * @param acsTimestamp the new acs timestamp
     */
    public void setAcsTimestamp(final String acsTimestamp) {
        this.acsTimestamp = acsTimestamp;
    }

    /**
     * Sets the destination station.
     *
     * @param destinationStation the new destination station
     */
    public void setDestinationStation(final String destinationStation) {
        this.destinationStation = destinationStation;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(final Long id) {
        this.id = id;
    }

    /**
     * Sets the par pic id.
     *
     * @param parPicId the new par pic id
     */
    public void setParPicId(final String parPicId) {
        this.parPicId = parPicId;
    }

    /**
     * Sets the source station.
     *
     * @param sourceStation the new source station
     */
    public void setSourceStation(final String sourceStation) {
        this.sourceStation = sourceStation;
    }

    /**
     * Sets the vcs case.
     *
     * @param vcsCase the new vcs case
     */
    public void setVcsCase(final String vcsCase) {
        this.vcsCase = vcsCase;
    }

    /**
     * Sets the zusatz leistungen.
     *
     * @param zusatzLeistungen the new zusatz leistungen
     */
    public void setZusatzLeistungen(final String zusatzLeistungen) {
        this.zusatzLeistungen = zusatzLeistungen;
    }

}
