/*
 * Class: InternalEntry
 *
 * Created on Sep 12, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.common.model;

/**
 * The Class InternalEntry.
 */
public abstract class InternalEntry {
    
    /** The process begin. */
    private long processBegin;

    /** The process end. */
    private long processEnd;

    /** The received. */
    private long received;

    /**
     * Gets the process begin.
     *
     * @return the process begin
     */
    public long getProcessBegin() {
        return this.processBegin;
    }

    /**
     * Gets the process end.
     *
     * @return the process end
     */
    public long getProcessEnd() {
        return this.processEnd;
    }

    /**
     * Gets the received.
     *
     * @return the received
     */
    public long getReceived() {
        return this.received;
    }

    /**
     * Sets the process begin.
     *
     * @param processBegin the new process begin
     */
    public void setProcessBegin(final long processBegin) {
        this.processBegin = processBegin;
    }

    /**
     * Sets the process end.
     *
     * @param processEnd the new process end
     */
    public void setProcessEnd(final long processEnd) {
        this.processEnd = processEnd;
    }

    /**
     * Sets the received.
     *
     * @param received the new received
     */
    public void setReceived(final long received) {
        this.received = received;
    }
}
