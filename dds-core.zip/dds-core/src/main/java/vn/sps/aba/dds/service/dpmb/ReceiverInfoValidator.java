/*
 * Class: ReceiverInfoValidator
 *
 * Created on Jul 31, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.aba.dds.service.dpmb;

import java.io.IOException;
import java.util.concurrent.RecursiveTask;

import javax.xml.bind.JAXBElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.support.MarshallingSource;
import org.springframework.xml.transform.StringResult;
import org.xml.sax.SAXParseException;

import vn.sps.aba.dds.common.types.ws.dpmb.AdresseErfassung;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureInfo;
import vn.sps.aba.dds.common.types.ws.dpmb.CaptureResultRecord;
import vn.sps.aba.dds.common.types.ws.dpmb.ParcelData;
import vn.sps.aba.dds.common.types.ws.dpmb.Timestamps;
import vn.sps.aba.dds.common.types.ws.dpmb.VolleAdresse;
import vn.sps.aba.dds.common.types.ws.response.EnumResolver;
import vn.sps.aba.dds.config.service.DpmbServiceConfiguration;

/**
 * The Class ReceiverInfoValidator.
 */
public class ReceiverInfoValidator extends RecursiveTask<ReceiverInfoWrapper> {

    /** The LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ReceiverInfoValidator.class);

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -330944096792888875L;

    /** The capture result record. */
    private final CaptureResultRecord captureResultRecord;

    /** The service configuration. */
    private final DpmbServiceConfiguration serviceConfiguration;

    /**
     * Instantiates a new receiver info validator.
     *
     * @param captureResultRecord the capture result record
     * @param serviceConfiguration the service configuration
     */
    public ReceiverInfoValidator(final CaptureResultRecord captureResultRecord, final DpmbServiceConfiguration serviceConfiguration) {
        this.captureResultRecord = captureResultRecord;
        this.serviceConfiguration = serviceConfiguration;
    }

    /**
     * Adds the cause.
     *
     * @param wrapper the wrapper
     * @param causeString the cause string
     */
    private void addCause(final ReceiverInfoWrapper wrapper, final String causeString) {
        wrapper.addCause(causeString);
        LOG.error(causeString);
    }

    /**
     * {@inheritDoc}
     *
     * @see java.util.concurrent.RecursiveTask#compute()
     */
    @Override
    protected ReceiverInfoWrapper compute() {
        final ReceiverInfoWrapper wrapper = new ReceiverInfoWrapper(this.captureResultRecord);
        this.validate(wrapper);
        return wrapper;
    }

    /**
     * Enhanced validate.
     *
     * @param wrapper the wrapper
     */
    void enhancedValidate(final ReceiverInfoWrapper wrapper) {
        try {
            final SAXParseException[] exceptions = this.validate(wrapper.getReceiverInfo());
            for (final SAXParseException saxParseException : exceptions) {
                wrapper.addCause(saxParseException.getMessage());
            }
        }
        catch (final IOException e) {
            LOG.error(null, e);
        }
    }

    /**
     * Expected element.
     *
     * @param wrapper the wrapper
     * @param element the element
     * @param fieldName the field name
     * @return true, if successful
     */
    private boolean expectedElement(final ReceiverInfoWrapper wrapper, final Object element, final String fieldName) {
        if (element == null) {
            this.addCause(wrapper, "Expected element " + fieldName);
            return false;
        }
        return true;
    }

    /**
     * Match enum.
     *
     * @param wrapper the wrapper
     * @param value the value
     * @param fieldName the field name
     * @param enumItems the enum items
     */
    private void matchEnum(final ReceiverInfoWrapper wrapper, final Object value, final String fieldName, final String enumItems) {
        if (value == null) {
            this.addCause(wrapper, fieldName + " must be one of {" + enumItems + "}");
        }
    }

    /**
     * Match pattern.
     *
     * @param wrapper the wrapper
     * @param value the value
     * @param fieldName the field name
     * @param pattern the pattern
     * @return true, if successful
     */
    private boolean matchPattern(final ReceiverInfoWrapper wrapper, final String value, final String fieldName, final String pattern) {
        if ((value == null) || !value.matches(this.serviceConfiguration.getIdentCodeFormat())) {
            this.addCause(wrapper, fieldName + " must match pattern " + pattern + "");
            return false;
        }
        return true;
    }

    /**
     * Not null or empty.
     *
     * @param wrapper the wrapper
     * @param value the value
     * @param fieldName the field name
     */
    void notNullOrEmpty(final ReceiverInfoWrapper wrapper, final String value, final String fieldName) {
        if ((value == null) || value.isEmpty()) {
            this.addCause(wrapper, fieldName + " must not null or empty");
        }
    }

    /**
     * Validate.
     *
     * @return the receiver info wrapper
     */
    public ReceiverInfoWrapper validate() {
        final ReceiverInfoWrapper wrapper = new ReceiverInfoWrapper(this.captureResultRecord);
        this.validate(wrapper);
        return wrapper;
    }

    /**
     * Validate.
     *
     * @param receiverInfo the receiver info
     * @return the SAX parse exception[]
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private SAXParseException[] validate(final CaptureResultRecord receiverInfo) throws IOException {
        final JAXBElement<CaptureResultRecord> captureResultRecordElement = this.serviceConfiguration.getObjectFactory()
            .createCaptureResultRecord(receiverInfo);

        final StringResult stringResult = new StringResult();

        final Marshaller marshaller = this.serviceConfiguration.getMarshaller();

        marshaller.marshal(captureResultRecordElement, stringResult);
        final MarshallingSource source = new MarshallingSource(marshaller, captureResultRecordElement);
        return this.serviceConfiguration.getXsdSchemas().createValidator().validate(source);
    }

    /**
     * Validate.
     *
     * @param wrapper the wrapper
     * @return true, if successful
     */
    void validate(final ReceiverInfoWrapper wrapper) {

        final CaptureResultRecord receiverInfo = wrapper.getReceiverInfo();
        final String identCode = receiverInfo.getIdentcode();

        if (this.matchPattern(wrapper, identCode, "IdentCode", this.serviceConfiguration.getIdentCodeFormat())) {
            if ((identCode == null) || !identCode.matches(this.serviceConfiguration.getIdentCodeFormat())) {
                final String cause = "IdentCode " + identCode + " is null or does not match pattern " + this.serviceConfiguration.getIdentCodeFormat();
                this.addCause(wrapper, cause);
                return;
            }
            final AdresseErfassung adresseErfassung = receiverInfo.getAdresseErfassung();

            if (this.expectedElement(wrapper, adresseErfassung, "AdresseErfassung")) {
                this.expectedElement(wrapper, adresseErfassung.getHausKey(), "AdresseErfassung.HausKey");
                final VolleAdresse volleAdresse = adresseErfassung.getVolleAdresse();
                if (this.expectedElement(wrapper, volleAdresse, "AdresseErfassung.VolleAdresse")) {
                    this.expectedElement(wrapper, volleAdresse.getFields(), "VolleAdresse.Fields");
                    this.matchEnum(wrapper, volleAdresse.getParcelAdrType(), "VolleAdresse.ParcelAdrType", EnumResolver.getParcelAdrTypesString());
                }
            }
            final CaptureInfo captureInfo = receiverInfo.getCaptureInfo();
            if (this.expectedElement(wrapper, captureInfo, "CaptureInfo")) {
                this.matchEnum(wrapper, captureInfo.getCaptureResultCode(), "CaptureInfo.CaptureResultCode", EnumResolver.getCaptureResultCodesString());
                this.expectedElement(wrapper, captureInfo.getCoderId(), "CaptureInfo.CoderId");
                this.expectedElement(wrapper, captureInfo.getCodingStation(), "CaptureInfo.CodingStation");
                this.expectedElement(wrapper, captureInfo.getCodingTimestamp(), "CaptureInfo.CodingTimestamp");
            }
            final ParcelData parcelData = receiverInfo.getParcelData();
            if (parcelData != null) {
                this.expectedElement(wrapper, parcelData.getAcsTimestamp(), "ParcelData.AcsTimestamp");
                this.expectedElement(wrapper, parcelData.getDestinationStation(), "ParcelData.DestinationStation");
                this.expectedElement(wrapper, parcelData.getParPicId(), "ParcelData.ParPicId");
                this.expectedElement(wrapper, parcelData.getSourceStation(), "ParcelData.SourceStation");
                this.expectedElement(wrapper, parcelData.getZusatzLeistungen(), "ParcelData.ZusatzLeistungen");
            }

            final Timestamps timestamps = receiverInfo.getTimestamps();
            if (this.expectedElement(wrapper, timestamps, "Timestamps")) {
                this.expectedElement(wrapper, timestamps.getDisCoTimestamp(), "Timestamps.DisCoTimestamp");
                this.expectedElement(wrapper, timestamps.getPdsTimestamp(), "Timestamps.PdsTimestamp");
                this.expectedElement(wrapper, timestamps.getVGTimestamp(), "Timestamps.VGTimestamp");
                this.expectedElement(wrapper, timestamps.getVnTimestamp(), "Timestamps.VnTimestamp");
            }
        }
    }
}
