package com.minhdo.Repository;


import java.util.List;

import com.minhdo.Entity.Department;
import com.minhdo.Entity.Employee;

public interface DepartmentImpl {
	//departments
  public List<Department> findAllInfoDepartment();
  public List<Employee>  findAllEmployeesByIdDepartment(int departmentId);
  public List<String> findInfoManagerOfDeparment();
  
  public Employee findInfoEmployee(int employeeId);
  public List<String> findDepartmentOfEmployee(int employeeId);
  public Employee delete(int employeeId);
  public Employee update(int firstname , Employee employee);
  
  public Employee move(int employeeId ,int idDepartmentFrom ,int idDepartmentTo);
  
}
