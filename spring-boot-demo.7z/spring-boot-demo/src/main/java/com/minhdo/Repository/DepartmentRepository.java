package com.minhdo.Repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.minhdo.Entity.Department;
import com.minhdo.Entity.Employee;

@Repository
public class DepartmentRepository implements DepartmentImpl  {
	// departments
	public static List<Department> departmentList = new ArrayList<Department>();
	
	public static List<Employee> employees = new ArrayList<>() ;

	static {

		Employee Employee_one = new Employee(1, "Minh", "Do", 1990);
		Employee Employee_two = new Employee(2, "Minh", "Tran", 1989);
		Employee Employee_three = new Employee(3, "Huy", "Tran", 1992);
		Employee Employee_four = new Employee(4, "Toan", "Tran", 1987);
		Employee Employee_five = new Employee(5, "Peter", "David", 2000);
		Employee Employee_six = new Employee(6, "John", "rock", 1826);
		Employee Employee_seven = new Employee(7, "Quang", "Do", 1991);

		Department department_one = new Department(11, "Tech", "ABC",
				new ArrayList<>(Arrays.asList(Employee_one, Employee_two, Employee_three)));
		Department department_two = new Department(12, "IT", "DEF",
				new ArrayList<>(Arrays.asList(Employee_four, Employee_five, Employee_six, Employee_seven)));

		departmentList.add(department_one);
		departmentList.add(department_two);
	}


	@Override
	public List<Department> findAllInfoDepartment() {
		return departmentList;
	}

	@Override
	public List<Employee> findAllEmployeesByIdDepartment(int departmentId) {
		for (Department department : departmentList) {
			if (department.getId() == departmentId) {
				return department.getEmployees();
			}
		}
		return null;
	}

	@Override
	public List<String> findInfoManagerOfDeparment() {
		List<String> listManager = new ArrayList<>();
		for (Department department : departmentList) {
			if (department != null) {
				listManager.add(department.getManager());
			}
		}
		return listManager;
	}

	@Override
	public Employee findInfoEmployee(int employeeId) {
		List<Employee> listEmployee = null;
		for (Department department : departmentList) {
			if (department != null) {
				listEmployee = department.getEmployees();
				for (Employee employee : listEmployee) {
					if (employee.getId() == employeeId) {
						return employee;
					}
				}
			}
		}
		return null;
	}

	@Override
	public List<String> findDepartmentOfEmployee(int employeeId) {
		Employee employee = findInfoEmployee(employeeId);
		List<Department> listDepartment = findAllInfoDepartment();
		List<String> InfoDepartment = new ArrayList<>();
		for (Department department : listDepartment) {
			List<Employee> listEmployee = department.getEmployees();
			for (Employee empl : listEmployee) {
				if (empl.equals(employee)) {
					InfoDepartment.add(String.valueOf(department.getId()));
					InfoDepartment.add(department.getManager());
					InfoDepartment.add(department.getName());
					return InfoDepartment;
				}
			}
		}
		return null;
	}

	@Override
	public Employee delete(int employeeId) {
		for (Department department : departmentList) {
			List<Employee> listEmployee = department.getEmployees();
			for (Employee empl : department.getEmployees()) {
				if (empl.getId() == employeeId) {
					listEmployee.remove(empl);
					department.setEmployees(listEmployee);
					return empl;
				}
			}
		}
		return null;
	}

	@Override
	public Employee update(int employeeId, Employee employee) {
		Employee empl = findInfoEmployee(employeeId);
		employee.setId(employeeId);
		for (Department department : departmentList) {
			if (empl != null) {
				department.getEmployees().remove(empl);
				department.getEmployees().add(employee);
				return employee;
			}
		}

		return null;
	}

	@Override
	public Employee move(int employeeId, int idDepartment_From, int idDepartment_To) {
		Employee employee = findInfoEmployee(employeeId);
		List<Employee> listEmployee = findAllEmployeesByIdDepartment(idDepartment_From);
		if (employee.getId() == employeeId) {
			listEmployee.remove(employee);

			for (Department department : departmentList) {
				if (department.getId() == idDepartment_From) {
					department.setEmployees(listEmployee);
				} else if (department.getId() == idDepartment_To) {
					department.getEmployees().add(employee);
				}
			}

		}
		return employee;
	}
}
