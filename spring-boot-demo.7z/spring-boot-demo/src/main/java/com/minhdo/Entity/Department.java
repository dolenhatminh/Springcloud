package com.minhdo.Entity;

import java.util.List;

public class Department {
	// id, name, manager
	private int id;
	private String name;
	private String manager;
	private List<Employee> employees;

	public Department() {
		super();
	}
	
	public Department(int i, String name, String manager, List<Employee> employees) {
		super();
		this.id = i;
		this.name = name;
		this.manager = manager;
		this.employees = employees;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getManager() {
		return manager;			
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employee) {
		this.employees = employees;
	}
	

}
