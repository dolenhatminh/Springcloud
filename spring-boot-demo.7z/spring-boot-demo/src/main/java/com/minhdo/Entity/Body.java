package com.minhdo.Entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement( name = "s:Body" )
@XmlAccessorType(XmlAccessType.FIELD)
public class Body {
	
    @XmlElement( name = "TransferParcelInfo" )
	private TransferParcelInfo TransferParcelInfo;

	public TransferParcelInfo getTransferParcelInfo() {
		return TransferParcelInfo;
	}

	public void setTransferParcelInfo(TransferParcelInfo transferParcelInfo) {
		TransferParcelInfo = transferParcelInfo;
	}

	
	
}
