package com.minhdo.Entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement( name = "s:Envelope" )
@XmlAccessorType(XmlAccessType.FIELD)
public class Envelope {
	
    @XmlElement( name = "s:Body" )
	private Body Body;
    @XmlAttribute( name = "xmlns:s" )
    private String xmlns;
	
	
	
	public String getXmlns() {
		return xmlns;
	}
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}
	public Body getBody() {
		return Body;
	}
	public void setBody(Body body) {
		Body = body;
	}
	
}
