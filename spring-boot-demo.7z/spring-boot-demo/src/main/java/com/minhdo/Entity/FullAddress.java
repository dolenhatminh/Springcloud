package com.minhdo.Entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "AddressType", "Angle", "Ort", "Postleitzahl", "Strasse", "Strassennummer", "Vertices", "X1", "X2", "X3", "X4", "Y1", "Y2", "Y3", "Y4", "ZipBase" })
@XmlRootElement(name = "FullAddress")
@XmlAccessorType(XmlAccessType.FIELD)
public class FullAddress {
    @XmlElement( name = "AddressType" )
	private String AddressType;
    @XmlElement( name = "Angle" )
	private String Angle;
    @XmlElement( name = "Ort" )
	private String Ort;
    @XmlElement( name = "Postleitzahl" )
	private String Postleitzahl;
    @XmlElement( name = "Strasse" )
	private String Strasse;
    @XmlElement( name = "Strassennummer" )
	private String Strassennummer;
    @XmlElement( name = "Vertices" )
	private String Vertices;
	@XmlElement(name = "X1")
	private String X1;
	@XmlElement(name = "X2")
	private String X2;
	@XmlElement(name = "X3")
	private String X3;
	@XmlElement(name = "X4")
	private String X4;
	@XmlElement(name = "Y1")

	private String Y1;
	@XmlElement(name = "Y2")

	private String Y2;
	@XmlElement(name = "Y3")

	private String Y3;
	@XmlElement(name = "Y4")

	private String Y4;

    @XmlElement( name = "ZipBase" )
	private String ZipBase;

	public String getAddressType() {
		return AddressType;
	}

	public void setAddressType(String addressType) {
		AddressType = addressType;
	}

	public String getAngle() {
		return Angle;
	}

	public void setAngle(String angle) {
		Angle = angle;
	}

	public String getOrt() {
		return Ort;
	}

	public void setOrt(String ort) {
		Ort = ort;
	}

    
	public String getPostleitzahl() {
		return Postleitzahl;
	}

	public void setPostleitzahl(String postleitzahl) {
		Postleitzahl = postleitzahl;
	}

	public String getStrasse() {
		return Strasse;
	}

	public void setStrasse(String strasse) {
		Strasse = strasse;
	}

	public String getStrassennummer() {
		return Strassennummer;
	}

	public void setStrassennummer(String strassennummer) {
		Strassennummer = strassennummer;
	}

	public String getVertices() {
		return Vertices;
	}

	public void setVertices(String vertices) {
		Vertices = vertices;
	}

    public String getX1() {
		return X1;
	}

	public void setX1(String x1) {
		X1 = x1;
	}

	public String getX2() {
		return X2;
	}

	public void setX2(String x2) {
		X2 = x2;
	}

	public String getX3() {
		return X3;
	}

	public void setX3(String x3) {
		X3 = x3;
	}

	public String getX4() {
		return X4;
	}

	public void setX4(String x4) {
		X4 = x4;
	}

	public String getY1() {
		return Y1;
	}

	public void setY1(String y1) {
		Y1 = y1;
	}

	public String getY2() {
		return Y2;
	}

	public void setY2(String y2) {
		Y2 = y2;
	}

	public String getY3() {
		return Y3;
	}

	public void setY3(String y3) {
		Y3 = y3;
	}

	public String getY4() {
		return Y4;
	}

	public void setY4(String y4) {
		Y4 = y4;
	}

	public String getZipBase() {
		return ZipBase;
	}

	public void setZipBase(String zipBase) {
		ZipBase = zipBase;
	}

}
