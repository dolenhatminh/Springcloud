package com.minhdo.Entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement( name = "TransferParcelInfo" )
@XmlAccessorType(XmlAccessType.FIELD)
public class TransferParcelInfo {
	
    @XmlElement( name = "request" )
	private Request request;
	@XmlAttribute(name = "xmlns")
	private String xmlns;

	public Request getRequest() {
		return request;
	}

	public void setRequest(Request request) {
		this.request = request;
	}

	public String getXmlns() {
		return xmlns;
	}

	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}
	
}
