package com.minhdo.Entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "CodingArt", "CodingQuality" })
@XmlRootElement(name = "ParcelCodingInfo")
@XmlAccessorType(XmlAccessType.FIELD)
public class ParcelCodingInfo {
    @XmlElement( name = "CodingArt" )
	private String CodingArt;
    @XmlElement( name = "CodingQuality" )
	private String CodingQuality;
	
	
	public String getCodingArt() {
		return CodingArt;
	}
	
	public void setCodingArt(String codingArt) {
		CodingArt = codingArt;
	}
	public String getCodingQuality() {
		return CodingQuality;
	}
	
	public void setCodingQuality(String codingQuality) {
		CodingQuality = codingQuality;
	}
	

}
