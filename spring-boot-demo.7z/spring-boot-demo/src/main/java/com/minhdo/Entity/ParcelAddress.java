package com.minhdo.Entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "AddressType", "Housenumber", "Streetnumber", "Zip" })
@XmlRootElement(name = "ParcelAddress")
@XmlAccessorType(XmlAccessType.FIELD)
public class ParcelAddress {

    @XmlElement( name = "AddressType" )
	private String AddressType;
    @XmlElement( name = "Housenumber" )
	private String Housenumber;
    @XmlElement( name = "Streetnumber" )
	private String Streetnumber;
    @XmlElement( name = "Zip" )
	private String Zip;

	public String getAddressType() {
		return AddressType;
	}

	public void setAddressType(String addressType) {
		AddressType = addressType;
	}

	public String getHousenumber() {
		return Housenumber;
	}

	public void setHousenumber(String housenumber) {
		Housenumber = housenumber;
	}

	public String getStreetnumber() {
		return Streetnumber;
	}

	public void setStreetnumber(String streetnumber) {
		Streetnumber = streetnumber;
	}

	public String getZip() {
		return Zip;
	}

	public void setZip(String zip) {
		Zip = zip;
	}

}
