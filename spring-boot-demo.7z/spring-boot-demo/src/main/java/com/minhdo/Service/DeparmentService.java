package com.minhdo.Service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.minhdo.Entity.Department;
import com.minhdo.Entity.Employee;

public interface DeparmentService {
	
	 /*public List<Department> findAllInforDeparment();
	  public List<Employees>  findAllEmployeesbyIdDeparment(int IdDeparment);
	  public String getinforManagerofDeparment();
	  Employees getinforEmployees(int idEmployees);
	  Department getinforofEmployees(int idEmployees);
	  void UpdateInForofEmployees(int id , String lastname , String firstname , String yearofbirth);
	  void DeleteEployees(int idEmployess);
	  */
	
	public List<Department>	getAllDepartment();
	public List<Employee> getAllEmloyeesByIdDepartment(int Id);
	public List<String> getAllManagerOfDepartment();
	
	public Employee getEmployee(int employeeId);
	public List<String> getDepartmentOfEmployee(int employeeId);
	public ResponseEntity updateEmployee(int employeeId , Employee employee);
	public ResponseEntity deleteEmployee(int employeeId);
	
	public ResponseEntity moveEmployee(int employeeId, int idDepartment_From, int idDepartment_To);
	public List<Employee> storeEmployeeByCondition();
	//public List<Employee> getAllEmployeeByCondition();
	
} 
