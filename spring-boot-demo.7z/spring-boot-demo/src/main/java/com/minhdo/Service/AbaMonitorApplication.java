package com.minhdo.Service;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.auth.AuthScope;
import org.apache.http.client.CredentialsProvider;



@SpringBootApplication
@EnableScheduling
public class AbaMonitorApplication {

	@Bean
	public RestTemplate logsearch() {
		HttpClientBuilder htBuilder = HttpClientBuilder.create();
		CredentialsProvider crProvider = new BasicCredentialsProvider();
		return null;
		
		//crProvider.setCredentials(AuthScope.ANY, new );
	}
}
