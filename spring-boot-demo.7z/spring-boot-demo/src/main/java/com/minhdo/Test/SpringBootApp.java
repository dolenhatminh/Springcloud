package com.minhdo.Test;

import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;


@Configuration
@ComponentScan("com.minhdo")
@SpringBootApplication
public class SpringBootApp {
	
	@Bean
    @Primary
    public RestTemplate getRestTemplate() {
		HttpClientBuilder clientBuilder = HttpClientBuilder.create();

        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(AuthScope.ANY,
                                           new UsernamePasswordCredentials("pnmai",
                                                                           "abc123"));

        clientBuilder.setDefaultCredentialsProvider(credentialsProvider);
        ClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(clientBuilder.build());

        return new RestTemplate(requestFactory);
    }
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootApp.class, args);
	}
	
}
