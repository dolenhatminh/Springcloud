package com.minhdo.Controller;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.minhdo.Entity.Body;
import com.minhdo.Entity.Department;
import com.minhdo.Entity.Employee;
import com.minhdo.Repository.DepartmentRepository;
import com.minhdo.Service.DeparmentService;

@RestController
public class EmployeeImpl implements DeparmentService{
	
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Autowired
	private ProcessKibanaService ProcessKibanaService;
	
	@GetMapping("/kipana")
	public void getAll(){
		 ProcessKibanaService.readFile();;
	}

	@GetMapping("/department/{departmentId}")
	public List<Employee> getAllEmloyeesByIdDepartment(@PathVariable("departmentId") int departmentId) {
		return departmentRepository.findAllEmployeesByIdDepartment(departmentId);
	}

	@GetMapping("/department/manager")
	public List<String> getAllManagerOfDepartment() {
		return departmentRepository.findInfoManagerOfDeparment();
	}

	@GetMapping("/employee/{employeeId}")
	public Employee getEmployee(@PathVariable("employeeId") int employeeId) {
		return departmentRepository.findInfoEmployee(employeeId);
	}

	@GetMapping("/department/employee/{employeeId}")
	public List<String> getDepartmentOfEmployee(@PathVariable("employeeId") int employeeId) {
		return departmentRepository.findDepartmentOfEmployee(employeeId);
	}

	@PutMapping("/employee/{employeeId}")
	public ResponseEntity updateEmployee(@PathVariable int employeeId, @RequestBody Employee employee) {
		Employee empl = departmentRepository.update(employeeId, employee);
		if (empl == null) {
			return new ResponseEntity("No Employee found for ID " + employeeId, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(employeeId, HttpStatus.OK);
	}

	@DeleteMapping("/employee/{employeeId}")
	public ResponseEntity deleteEmployee(@PathVariable int employeeId) {
		Employee employee = departmentRepository.delete(employeeId);
		if (employee == null) {
			return new ResponseEntity("No Employee found for ID " + employeeId, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(employeeId, HttpStatus.OK);
	}

	@GetMapping("/employee/{employeeId}/Department_From/{departmentId_From}/Department_To/{departmentId_To}")
	public ResponseEntity moveEmployee(@PathVariable int employeeId, @PathVariable int departmentId_From,
			@PathVariable int departmentId_To) {
		Employee employees = departmentRepository.move(employeeId, departmentId_From, departmentId_To);

		if (employees == null) {
			return new ResponseEntity("No Employee found for ID " + employeeId, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(employeeId, HttpStatus.OK);
	}
	
	@GetMapping("employee/condition")
	public List<Employee> storeEmployeeByCondition() {

		ExecutorService executor = Executors.newFixedThreadPool(2);
		for (Department department : departmentRepository.departmentList) {
			Runnable listEmployees = new ThreadProcess(department);
			
			executor.execute(listEmployees);
		}
		return departmentRepository.employees;
	}


	@Override
	public List<Department> getAllDepartment() {
		// TODO Auto-generated method stub
		return null;
	}
}
