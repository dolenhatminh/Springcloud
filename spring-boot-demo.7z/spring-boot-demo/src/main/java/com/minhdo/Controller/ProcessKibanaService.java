package com.minhdo.Controller;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParser;
import com.minhdo.Entity.Barcode;
import com.minhdo.Entity.Barcodes;
import com.minhdo.Entity.Body;
import com.minhdo.Entity.ConnectKiban;
import com.minhdo.Entity.Envelope;
import com.minhdo.Entity.FullAddress;
import com.minhdo.Entity.ParcelAddress;
import com.minhdo.Entity.ParcelCodingInfo;
import com.minhdo.Entity.ParcelInfo;
import com.minhdo.Entity.ProduktZusatzleistungen;
import com.minhdo.Entity.Request;
import com.minhdo.Entity.TransferParcelInfo;



@Service
public class ProcessKibanaService {
	
	private final static String filexml = "C:\\Users\\dlnminh\\Desktop\\dds-core-test.xml";	

	
	@Autowired
	private ConnectKiban connect;
	
	@Autowired
	 private RestTemplate getRestTemplate;
	
    public ResponseEntity<Object> searchIdentcode() {
	
	
	StringBuilder builder = new StringBuilder();
	
	builder.append(connect.getAddress()).append("/").append(connect.getContextPath()).append("/").append("_search");
	Map<String, Object> searchQuery = new HashMap<>();
    Map<String, Object> searchMatchQuery = new HashMap<>();
    Map<String, String> identCodeValue = new HashMap<>();
    identCodeValue.put("message", "Detail of the parcel. The image byte array was removed");
    
    searchMatchQuery.put("match", identCodeValue);
    searchQuery.put("query", searchMatchQuery);
    searchQuery.put("size", "1");
   
    return getRestTemplate.postForEntity(builder.toString(), searchQuery, Object.class);
	
    }
    
    
    public void readFile() {
    	
    	
    	Object Array = searchIdentcode().getBody();
		
    	JSONObject jsonObject =  (JSONObject) Array;
    	
    	
    	
		Request request = new Request();
		Body body = new Body();
		Envelope envelope = new Envelope();
		TransferParcelInfo transferParcelInfo = new TransferParcelInfo();
		envelope.setXmlns("http://schemas.xmlsoap.org/soap/envelope/");
		transferParcelInfo.setXmlns("Ch.Post.PL.Vae.VG.ParcelInfoService");
		request.setXmlns("http://www.w3.org/2001/XMLSchema-instance");
		Barcodes barcodes = new Barcodes();
		Barcode barcode = new Barcode(); 
		ParcelInfo parcelInfo = new ParcelInfo();
		FullAddress fullAddress = new FullAddress();
		ParcelAddress parcelAddress = new ParcelAddress();
		ParcelCodingInfo parcelCodingInfo = new ParcelCodingInfo();
		ProduktZusatzleistungen prZusatzleistungen = new ProduktZusatzleistungen();
		
		
		
			JSONArray JsArray = jsonObject.getJSONObject("hits").getJSONArray("hits");

			for (Object object : JsArray) {
				JSONObject jsonOb = (JSONObject) object;
				
				if ((jsonOb.getJSONObject("_source").get("message").toString()).equals("Detail of the parcel. The image byte array was removed")) {
					
					JSONObject jsonParcelInfo = jsonOb.getJSONObject("_source").getJSONObject("parcelContent").getJSONObject("parcelInfo");
					
					request.setCallerId(jsonOb.getJSONObject("_source").getJSONObject("parcelContent").get("callerId").toString());	
					JSONArray jsobject = jsonParcelInfo.getJSONArray("barcodes");
						for(Object json : jsobject) {
							JSONObject jsonCode = (JSONObject) json;
							barcode.setCode(jsonCode.get("code").toString());
							barcode.setEdges(jsonCode.get("edges").toString());
							barcode.setType(jsonCode.get("type").toString());
							barcode.setY1(jsonCode.getJSONObject("boundary").get("y1").toString());
							barcode.setX1(jsonCode.getJSONObject("boundary").get("x1").toString());
							barcode.setY2(jsonCode.getJSONObject("boundary").get("y2").toString());
							barcode.setX2(jsonCode.getJSONObject("boundary").get("x2").toString());
							barcode.setY3(jsonCode.getJSONObject("boundary").get("y3").toString());
							barcode.setX3(jsonCode.getJSONObject("boundary").get("x3").toString());
							barcode.setY4(jsonCode.getJSONObject("boundary").get("y4").toString());
							barcode.setX4(jsonCode.getJSONObject("boundary").get("x4").toString());
						}
						
						parcelInfo.setDestinationStation(jsonParcelInfo.get("destinationStation").toString());
						fullAddress.setAddressType(jsonParcelInfo.getJSONObject("fullAddress").get("addressType").toString());
						fullAddress.setAngle(jsonParcelInfo.getJSONObject("fullAddress").get("angle").toString());
						fullAddress.setOrt(jsonParcelInfo.getJSONObject("fullAddress").get("ort").toString());
						fullAddress.setPostleitzahl(jsonParcelInfo.getJSONObject("fullAddress").get("postleitzahl").toString());
						fullAddress.setStrasse(jsonParcelInfo.getJSONObject("fullAddress").get("strasse").toString());
						fullAddress.setStrassennummer(jsonParcelInfo.getJSONObject("fullAddress").get("strassenNummer").toString());
						fullAddress.setVertices(jsonParcelInfo.getJSONObject("fullAddress").get("vertices").toString());
						
						JSONObject jsonBoundary = jsonParcelInfo.getJSONObject("fullAddress").getJSONObject("boundary");
						
						
						fullAddress.setY1(jsonBoundary.get("y1").toString());
						fullAddress.setX1(jsonBoundary.get("x1").toString());
						fullAddress.setY2(jsonBoundary.get("y2").toString());
						fullAddress.setX2(jsonBoundary.get("x2").toString());
						fullAddress.setY3(jsonBoundary.get("y3").toString());
						fullAddress.setX3(jsonBoundary.get("x3").toString());
						fullAddress.setY4(jsonBoundary.get("y4").toString());
						fullAddress.setX4(jsonBoundary.get("x4").toString());
						fullAddress.setZipBase(jsonParcelInfo.getJSONObject("fullAddress").get("zipBase").toString());
						
						
						parcelInfo.setIdentcode(jsonParcelInfo.get("identCode").toString());
						//parcelInfo.setImage(imageDt);
						parcelInfo.setParPicId(jsonParcelInfo.get("parPicId").toString());
						parcelInfo.setTimestamp(jsonOb.getJSONObject("_source").get("@timestamp").toString());
						parcelInfo.setVcsCase(jsonParcelInfo.get("vcsCase").toString());
						
						parcelAddress.setAddressType(jsonParcelInfo.getJSONObject("parcelAddress").get("addressType").toString());
						parcelAddress.setHousenumber(jsonParcelInfo.getJSONObject("parcelAddress").get("houseNumber").toString());
						parcelAddress.setStreetnumber(jsonParcelInfo.getJSONObject("parcelAddress").get("streetNumber").toString());
						parcelAddress.setZip(jsonParcelInfo.getJSONObject("parcelAddress").get("zip").toString());
						
						parcelCodingInfo.setCodingQuality(jsonParcelInfo.getJSONObject("parcelCodingInfo").get("codingQuality").toString());
						parcelCodingInfo.setCodingArt(jsonParcelInfo.getJSONObject("parcelCodingInfo").get("codingArt").toString());
						prZusatzleistungen.setNil(true);
						parcelInfo.setProduktZusatzleistungen(prZusatzleistungen);
						parcelInfo.setSourceStation(jsonParcelInfo.get("sourceStation").toString());
						
						
						request.setParcelInfoSentTimestamp(jsonOb.getJSONObject("_source").getJSONObject("parcelContent").get("parcelInfoSentTimestamp").toString());
						request.setVersion(jsonOb.getJSONObject("_source").getJSONObject("parcelContent").get("version").toString());
					
				}
				
			}
			
		
		
		
		barcodes.setBarcode(barcode);
		parcelInfo.setBarcodes(barcodes);
		parcelInfo.setFullAddress(fullAddress);
		parcelInfo.setParcelAddress(parcelAddress);
		parcelInfo.setParcelCodingInfo(parcelCodingInfo);
		request.setParcelInfo(parcelInfo);
		transferParcelInfo.setRequest(request);
		body.setTransferParcelInfo(transferParcelInfo);
		
		envelope.setBody(body);
		
		
		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance( Envelope.class );
			 Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		        
		        jaxbMarshaller.setProperty( Marshaller.JAXB_FORMATTED_OUTPUT, true );

		        // marshaling of java objects in xml (output to file and standard output) 
		        jaxbMarshaller.marshal( envelope, new File(filexml) );
		        jaxbMarshaller.marshal( envelope, System.out );
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
    }
}
