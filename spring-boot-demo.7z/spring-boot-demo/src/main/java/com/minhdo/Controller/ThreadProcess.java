package com.minhdo.Controller;

import java.util.List;

import com.minhdo.Entity.Department;
import com.minhdo.Entity.Employee;
import com.minhdo.Repository.DepartmentRepository;

public class ThreadProcess implements Runnable{

	
	private Department department;

	public ThreadProcess(Department department) {
		this.department = department;
	}
	
	public List<Employee> getListEmployeeByCondition(Department department) {

		List<Employee> employees = department.getEmployees();
		for (Employee employee : employees) {
			if (employee.getYearofbirth() < 1990) {
				if(!DepartmentRepository.employees.contains(employee)) {
					DepartmentRepository.employees.add(employee);
				}
			}
		}
		return DepartmentRepository.employees;
	}
	
	@Override
	public void run() {
		getListEmployeeByCondition(department);
	}

}
