package demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Sum {

	public static class MyIntComparable implements Comparator<Integer> {

		@Override
		public int compare(Integer o1, Integer o2) {
			return (o1 > o2 ? -1 : (o1 == o2 ? 0 : 1));
		}
	}

	public static List<Integer> findHighestSums(int grid[][], int n) {
		int row = grid.length - 1;
		int cell = grid[grid.length - 1].length - 1;

		List<Integer> list = new ArrayList<Integer>();

		for (int i = 0; i <= cell; i++) {
			list.addAll(findHighestSums(grid, row, i));
		}

		Collections.sort(list, new MyIntComparable());

		if (n >= list.size()) {
			return list;
		} else {
			List<Integer> result = new ArrayList<Integer>();
			for (int j = 0; j < n; j++) {
				result.add(list.get(j));
			}
			return result;
		}
	}

	public static List<Integer> findHighestSums(int grid[][], int row, int cell) {
		List<Integer> list = new ArrayList<Integer>();

		if (row > 0) {
			for (int k = 0; k < grid[row - 1].length; k++) {
				List<Integer> result = findHighestSums(grid, --row, k);
				row++;

				for (int x = 0; x < result.size(); x++) {
					result.set(x, result.get(x) + grid[row][cell]);
				}

				list.addAll(result);
			}

		} else {
			list.add(grid[row][cell]);
		}

		return list;
	}

	public static void main(String[] args) {

		int[][] m = { { 5, 4, 3, 2, 1 }, { 4, 1 }, { 5, 0, 0 }, { 6, 4, 2 },
				{ 1 } };

	/*	int[][] c = { { 1, -1 }, { 1, 0, -1 } };

		int[][] z = { { 2, 5, 17, 12, 3 }, { 15, 8, 4, 11, 10 },
				{ 9, 18, 6, 20, 16 }, { 14, 13, 12, 1, 7 } };*/

		System.out.println(findHighestSums(m, 5));
	}
}
