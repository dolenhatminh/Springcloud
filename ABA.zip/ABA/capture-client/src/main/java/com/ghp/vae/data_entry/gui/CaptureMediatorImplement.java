package com.ghp.vae.data_entry.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.Timer;

import javax.jms.JMSException;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.bll.BLLAddressField;
import com.ghp.vae.data_entry.bll.BLLCard;
import com.ghp.vae.data_entry.bll.BLLDataStructure;
import com.ghp.vae.data_entry.bll.BLLField;
import com.ghp.vae.data_entry.bll.BLLViewData;
import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.common.autocomplete.VaeFocusTraversalPolicy;
import com.ghp.vae.data_entry.entity.Card;
import com.ghp.vae.data_entry.entity.UserName;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.ObjectInformation;
import com.ghp.vae.data_entry.face.StateCapture;
import com.ghp.vae.data_entry.ptl.OCRInformation;
import com.ghp.vae.data_entry.ptl.ProgressBar;
import com.ghp.vae.data_entry.ptl.ProgressBarLoadCard;
import com.ghp.vae.data_entry.ptl.UISearch;
import com.ghp.vae.data_entry.ptl.autocomplete.LearningInterface;
import com.ghp.vae.data_entry.ptl.state.CaptureMessage;
import com.ghp.vae.data_entry.ptl.state.NormalState;
import com.ghp.vae.search.service.impl.LookupServiceImpl;
import com.sps.vn.config.AboutConfig;
import com.sps.vn.config.ApplicationConfig;
import com.sps.vn.utilities.StringUtil;

public class CaptureMediatorImplement implements CaptureMediator, MainFieldInterface {

	private static Logger log = LoggerFactory.getLogger("GUI");
	private ButtonBar buttonBar;
	private CapturePanel capturePanel;
	private DisplayPanel displayPanel;
	private ImagePanel imagePanel;
	private InfoPanel infoPanel;
	private MenuBar menubar;
	private UIMainFrame mainFrame;
	private StateCapture stateCapture;
	private Communication commu;
	private Timer timerCountTime;
	private Card card;
	private BLLViewData viewData;
	private UserName user;
	VaeFocusTraversalPolicy traversalPolicy;

	private static Boolean isInLookup = false;

	private static  int countLookup;
	
	public static void releaseLookup() {
		log.info("RELEASE LOOKUP LOCK");
		synchronized (isInLookup) {
			isInLookup = false;
		}
	}

	public static synchronized boolean lockLookup() {
		log.info("TRY TO GET LOOKUP LOCK");
		if (isInLookup) {
			log.info("FAIL TO GET LOOKUP LOCK");
			return false;
		}
		isInLookup = true;
		return true;
	}

	public CaptureMediatorImplement() {
		this.initData();
		CaptureMediatorImplement.countLookup = 0;
	}

	private void initFocusManagement() {
		this.traversalPolicy = new VaeFocusTraversalPolicy();
		this.mainFrame.setFocusTraversalPolicy(this.traversalPolicy);
		this.capturePanel.addFocusManagement(this.traversalPolicy);
	}

	private void initData() {
		this.viewData = new BLLViewData();
		// land data
		final String landList[][] = this.viewData.getLand();
		if (landList != null) {
			this.land = new Properties();
			for (final String[] data : landList) {
				this.land.put(data[1], data[0]);
			}
		}
		// reason data
		final String arr[][] = this.viewData.getReason();
		this.reason = new Properties();
		for (final String data[] : arr) {
			this.reason.put(data[0], data[1]);
		}
		this.changeCase = this.viewData.getChangeCase();

		final Dimension screen_size = Toolkit.getDefaultToolkit().getScreenSize();
		this.progressBar = new ProgressBar(this, true);

		this.progressBar.setBounds((screen_size.width / 2) - 50, (screen_size.height / 2) - 20, 300, 45);
		this.proccessLoadCard = new ProgressBarLoadCard(this, true);
		this.proccessLoadCard.setLocationRelativeTo(null);
		// Hoang enable when finish
		// proccessLoadCard.setNotEscape(true);
		this.proccessLoadCard.setStr("IS GETTING CARD.");
		this.timerCountTime = new Timer();
	}

	private void initOCR(UIMainFrame mainFrame) {
		// ocr = new OCRProcessing();
		this.ocrInfo = new OCRInformation(this, mainFrame);
		this.ocrInfo.setPosition();
	}

	@Override
	public void saveButton() {
		this.requestState(StateCapture.SAVE_CARD_BUTTON);
	}

	@Override
	public void saveMenuItem() {
		this.requestState(StateCapture.SAVE_CARD_CTRL);
	}

	@Override
	public void search() {
		CaptureMediatorImplement.countLookup++;
		log.info("###### Count LOOK UP Field: " + CaptureMediatorImplement.countLookup);
		if (!lockLookup()) {
			return;
		}
		
		final UISearch search = UISearch.intance();
		UISearch.destroy();

		this.firstSearch = false;
		this.requestState(StateCapture.LOOKUP);
	}

	private void requestState(byte action) {
		final CaptureMessage message = CaptureMessage.intance();
		message.clearData();
		message.setAction(action);

		this.request(message, this);
	}

	@Override
	public void rotataRight() {
		this.imagePanel.rotato(90);
	}

	@Override
	public void rotataLeft() {
		this.imagePanel.rotato(-90);
	}

	@Override
	public void clearData() {
		this.capturePanel.clearCaptureDataButton();

		// Request: https://helpdesk.spsvietnam.vn/WorkOrder.do?woMode=viewWO&woID=10025&&fromListView=true
		// infoPanel.setKdpid("");
		this.capturePanel.setKdpid("");

		this.capturePanel.getJtfLookup().requestFocus();
		this.capturePanel.setDefaultColorBackGroundButton();

		// Request #10890: Disable 'strasse' and 'hausnumber' when kdp is postfach, enable them when user press 'Clear
		// kdp'.
		this.capturePanel.enableStrasseHausnrField(true);

		this.resetCardData();
	}

	private void resetCardData() {
		if (this.card == null) {
			return;
		}
		this.card.clearValue();
	}

	@Override
	public void exit() {
		this.requestState(StateCapture.EXIT);
	}

	@Override
	public void help() {
	}

	@Override
	public void about() {
		final AboutConfig about = new AboutConfig();

		final Map<String, String> members = about.getMembers();
		final StringBuilder builder = new StringBuilder();
		for (final Map.Entry<String, String> member : members.entrySet()) {
			builder.append(member.getKey()).append(" - ").append(member.getValue()).append("\n");
		}

		JOptionPane.showMessageDialog(this.mainFrame,
				about.getAppname() + "\n" + "Version: " + about.getVersion() + "\n" + "Copyright: "
						+ about.getCopyright() + "\n" + "VAE Team: " + "\n" + builder.toString(),
				"Thong tin", JOptionPane.INFORMATION_MESSAGE);
	}

	@Override
	public void setButtonBar(ButtonBar buttonBar) {
		this.buttonBar = buttonBar;
	}

	@Override
	public void setCapturePanel(CapturePanel capturePanel) {
		this.capturePanel = capturePanel;
	}

	@Override
	public void setDisplayPanel(DisplayPanel displayPanel) {
		this.displayPanel = displayPanel;
	}

	@Override
	public void setImagePanel(ImagePanel imagePanel) {
		this.imagePanel = imagePanel;
	}

	@Override
	public void setInfoPanel(InfoPanel infoPanel) {
		this.infoPanel = infoPanel;
	}

	@Override
	public void setMenubar(MenuBar menubar) {
		this.menubar = menubar;
	}

	@Override
	public void request(ObjectInformation information, MainFieldInterface main) {

		log.debug("[CaptureMediatorImplement] CURRENT STATE: " + this.stateCapture.getClass().getName());

		this.stateCapture.handleEvent(information, main);
	}

	// Hoang chua co land , defaultState, disableLookup, title
	// Hoang chua co function tren jtf , f1, f2, f3
	private Properties land;
	private StateCapture defaultState;
	private final String title = "";
	private String strStrasse;
	private String strAnrede;
	private String strOrt;
	private String[] changeCase;
	private Properties reason;
	private ProgressBar progressBar;
	private ProgressBarLoadCard proccessLoadCard;
	private OCRInformation ocrInfo;
	private boolean firstSearch = true;

	@Override
	public void validate(String field, String value) {

	}

	@Override
	@Deprecated
	public void addStatus(int cardAmount, float speed) {
		this.infoPanel.setCardAmount(cardAmount);
		this.infoPanel.setSpeed(speed, speed > ApplicationConfig.getInstance().getBusinessConfig().getServiceLevel());
	}

	int amountCard;
	int cardGood;
	float minutes;

	@Override
	public void addStatus(long startTime, long endTime) {
		this.amountCard++;
		final long milisecond = endTime - startTime;
		this.minutes += milisecond / 1000.0;

		if (milisecond < 19000) {
			this.cardGood++;
		}
		float speed;

		speed = this.minutes / this.amountCard;
		final int percent = (int) (((this.cardGood * 1.0) / this.amountCard) * 100);

		this.infoPanel.setCardAmount(this.amountCard);
		this.infoPanel.setPercentCardGood(percent);
		this.infoPanel.setSpeed(speed, speed > ApplicationConfig.getInstance().getBusinessConfig().getServiceLevel());

	}

	@Override
	public void changeState(StateCapture state) {
		this.stateCapture = state;
	}

	@Override
	public void defaultState(StateCapture state) {
		this.defaultState = state;

	}

	@Override
	public void resetState() {
		this.stateCapture = this.defaultState;
		// this.mainFrame.setEnabled(true);
		//
		// boolean isWindows = Utilities.isWindowOS();
		// if(isWindows){
		// this.mainFrame.toFront();
		// }
	}

	@Override
	public String getFieldValue(byte field) {
		final Component component = this.getComponent(field);
		if (component instanceof JTextField) {
			return ((JTextField) component).getText();
		}
		if (component instanceof JCheckBox) {
			return Boolean.toString(((JCheckBox) component).isSelected());
		}
		if (component == this.capturePanel.getJcboReason()) {
			return this.capturePanel.getJcboReason().getSelectedItem().toString();
		}
		if (component == this.capturePanel.getJcboLand()) {
			return ((JTextField) this.capturePanel.getJcboLand().getEditor().getEditorComponent()).getText();
		}
		return null;
	}

	@Override
	public Component getComponent(byte field) {
		switch (field) {
		case BADREASON:
			return this.capturePanel.getJcboReason();
		case LOOKUP:
			return this.capturePanel.getJtfLookup();
		case FIRMA:
			return this.capturePanel.getJtfFirmename();
		case ZUSAT:
			return this.capturePanel.getJtfNameZusat();
		case ANREDE:
			return this.capturePanel.getJcboAnrede();
		case VORNAME:
			return this.capturePanel.getJtfVorname();
		case NAME:
			return this.capturePanel.getJtfName();
		case PLZ:
			return this.capturePanel.getJtfPlz();
		case ORT:
			return this.capturePanel.getJtfOrt();
		case STRASSE:
			return this.capturePanel.getJtfStrasse();
		case HAUSE:
			return this.capturePanel.getJtfHausNummer();
		case LAND:
			return this.capturePanel.getJcboLand();
		case POSTFACH:
			return this.capturePanel.getJtfPostFach();
		case STOCKWERK:
			return this.capturePanel.getJtfStockwerk();
		case ADRESSZUSAT:
			return this.capturePanel.getJtfAddressuzat();
		case COADDRESS:
			return this.capturePanel.getJtfCOAddress();
		case PICKPOST:
			return this.capturePanel.getJtfPickPost();
		case MYPOST24:
			return this.capturePanel.getJtfMyPost24();
		case POSTLAGEND:
			return this.capturePanel.getJtfPostLagend();
		case OCRINFORMATION:
			return this.ocrInfo;
		case SAVE_BUTTON:
			return this.buttonBar.getJbtnSave();
		case SAVE_MENU:
			return this.menubar.getJmiSave();
		case SEARCH_BUTTON:
			return this.buttonBar.getJbtnSearch();
		case KDPID_FIELD:
			return this.infoPanel.getJlKdpid();
		case IMAGE_VIEW:
			return this.imagePanel;
		case FRAME_VIEW:
			return this.mainFrame;
		case 27:
			return this.proccessLoadCard;
		}
		return null;

	}

	@Override
	public void hiddenToolTip() {
		this.capturePanel.hiddenToolTip();
	}

	@Override
	public void displayToolTip() {
		log.debug("tool tip");
		this.capturePanel.displayToolTip();
	}

	@Override
	public void clearTooltip() {
		this.capturePanel.clearTooltip();
	}

	@Override
	public void loadImageAvailable() {
		log.debug("load Image Available");
		this.imagePanel.loadImageAvailable();
	}

	@Override
	public void allEnable(boolean enable) {
		this.capturePanel.allEnable(enable);
		this.menubar.setEnableSearch(enable);
	}

	@Override
	public void resetGui() {
		this.capturePanel.clearCaptureData();
		// Request: https://helpdesk.spsvietnam.vn/WorkOrder.do?woMode=viewWO&woID=10025&&fromListView=true
		// infoPanel.setKdpid("");
		this.capturePanel.setKdpid("");
		this.resetOcrdata();
		if (this.card != null) {
			this.card.setVectorKDP(null);
		}
		this.capturePanel.setDefaultColorBackGroundButton();
		this.mainFrame.setTitle("VAE2 Data Entry");
	}

	private void resetOcrdata() {
		if (this.ocrInfo == null) {
			return;
		}

		if (this.ocrInfo.isVisible()) {
			// Fix issue https://pms.spsvietnam.vn/issues/12007
			// Reset OCRInformation's data.
			this.ocrInfo.resetData();
			this.ocrInfo.setVisible(false);
			this.ocrInfo.dispose();
		}
	}

	@Override
	public void setProcessStatus(boolean visible) {
		if (this.progressBar.isVisible() != visible) {
			if (!visible) {
				try {
					// Thread.sleep(100);

					log.info("CLOSE PROGRESS BAR: " + EventQueue.isDispatchThread());
					if (!EventQueue.isDispatchThread()) {
						EventQueue.invokeLater(new Runnable() {
							@Override
							public void run() {
								// TODO Auto-generated method stub
								CaptureMediatorImplement.this.progressBar.dispose();
							}
						});
					} else {
						this.progressBar.dispose();
					}
				} catch (final Exception e) {
					log.error("", e);
				}

				return;
			}
			this.progressBar.setVisible(visible);
		}
	}

	/**
	 * when process load card is true open count time.
	 */
	@Override
	public void setProcessLoadCard(boolean visible) {
		if (this.proccessLoadCard.isVisible() != visible) {
			if (!visible) {
				try {
					Thread.sleep(100);
				} catch (final Exception e) {
					log.error("", e);
				}
				this.proccessLoadCard.setVisible(visible);
				this.proccessLoadCard.dispose();
				this.stopCountTimeBar();
			} else {
				this.startCountTimeBar();
				this.proccessLoadCard.setVisible(visible);
			}
		}
	}

	Thread timeBarThread;

	/**
	 * function start count time bar. create scheduler update time in seconds
	 */
	private void startCountTimeBar() {
		if ((this.timeBarThread != null) && this.timeBarThread.isAlive()) {
			this.timeBarThread.stop();
		}
		this.timeBarThread = new Thread(new CountTimeBar());
		this.timeBarThread.start();
	}

	/**
	 * function stop count time bar. stop scheduler
	 */
	private void stopCountTimeBar() {
		if ((this.timeBarThread != null) && this.timeBarThread.isAlive()) {
			this.timeBarThread.interrupt();
		}
	}

	@Override
	public void setStatus(String status) {

		this.progressBar.setStr(status);
		this.progressBar.repaint();
	}

	@Override
	public void doExit(boolean b) {
		this.requestState(StateCapture.EXIT);
	}

	@Override
	public void showStatus(String msg) {
		this.infoPanel.showStatus("Status: " + msg);
	}

	@Override
	public Card getEntity() {
		return this.card;
	}

	@Override
	public void setEntity(Card card) {
		this.card = card;
	}

	@Override
	public String getLand(String value, String defaulValue) {
		return this.land.getProperty(value, defaulValue);
	}

	@Override
	public String getBadRepondcode(String badCard) {
		return this.reason.getProperty(badCard);
	}

	private final String version = new AboutConfig().getVersion();

	@Override
	public void loadDataCard() {
		this.loadDefaultValue();
		this.firstSearch = true;
		final float angle = (float) this.card.getCard()
				.getAngle(ApplicationConfig.getInstance().getOcrConfig().getDefaultAngle());
		this.imagePanel.fillImage(this.card.getImageByte(), angle);
		// menubar.setEnableSave(true);
		// buttonBar.setEnableSave(true);
		this.capturePanel.getJtfLookup().requestFocus();
		this.infoPanel.showStatus("is typing...");
		this.mainFrame.setTitle(
				"VAE2 Data Entry (" + this.title + ") - " + this.card.getDecription() + " - version : " + this.version);
		this.refreshGui();

		//Load data field Hause in UI
		if (this.card.getValueHausnummer() != null && this.card.getValueHausnummerzusatz() == null) {
			this.capturePanel.getJtfHausNummer().setText(this.card.getValueHausnummer());
		} else if (this.card.getValueHausnummer() == null && this.card.getValueHausnummerzusatz() != null) {
			this.capturePanel.getJtfHausNummer().setText(this.card.getValueHausnummerzusatz());
		} else if (this.card.getValueHausnummer() != null && this.card.getValueHausnummerzusatz() != null) {
			this.capturePanel.getJtfHausNummer().setText(this.card.getValueHausnummer()+this.card.getValueHausnummerzusatz());
		} else {
			this.capturePanel.getJtfHausNummer().setText("");
		}
	}

	private void refreshGui() {
		this.capturePanel.updateUI();
		this.infoPanel.updateUI();
		this.displayPanel.updateUI();

	}

	private void loadDefaultValue() {
		final Map<String, BLLField> fields = this.card.getCard().getFieldList();
		for (int i = 0; i < this.capturePanel.getComponentCount(); i++) {
			if (this.capturePanel.getComponent(i) instanceof JTextField) {
				final JTextField tmp = (JTextField) this.capturePanel.getComponent(i);

				final String fieldName = tmp.getName();

				try {
					if ((fieldName != null) && !fieldName.equals("")) {
						log.debug(" > fieldName :" + fieldName + " : type : " + fields.get(fieldName).getClass());

						if (fieldName.equalsIgnoreCase(BLLDataStructure.HAUSNUMMER_FIELD)) {
							final String hause = Utilities.ignoreNull(
									((BLLAddressField) fields.get(BLLDataStructure.HAUSNUMMER_FIELD)).getTyped())
									+ Utilities.ignoreNull(
											((BLLAddressField) fields.get(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD))
													.getTyped());
							this.capturePanel.getJtfHausNummer().setText(hause);
						} else if (fieldName.equalsIgnoreCase(BLLDataStructure.STRASSE_FIELD)) {
							this.strStrasse = this.capturePanel.handleErrorFontTextField(((BLLAddressField) fields.get(fieldName)).getTyped());
							this.capturePanel.getJtfStrasse().setText(this.strStrasse);
						} else if (fieldName.equalsIgnoreCase(BLLDataStructure.ANREDE_FIELD)) {
							this.strAnrede = this.capturePanel.handleErrorFontTextField(((BLLAddressField) fields.get(fieldName)).getTyped());
							this.capturePanel.getJcboAnrede().setText(this.strAnrede);
						} else if (fieldName.equalsIgnoreCase(BLLDataStructure.ORT_FIELD)) {
							this.strOrt = this.capturePanel.handleErrorFontTextField(((BLLAddressField) fields.get(fieldName)).getTyped());
							this.capturePanel.getJtfOrt().setText(this.strOrt);
						} else {
							try {
								final String type = ((BLLAddressField) fields.get(fieldName)).getTyped();
								// log.warn("ignore case is null");
								if (type != null) {
									tmp.setText(type);
								}
							} catch (final java.lang.ClassCastException ccex) {
								// log.warn("ignore case postlagend (com.ghp.vae.data_entry.bll.BLLField cannot be cast
								// to
								// com.ghp.vae.data_entry.bll.BLLAddressField)");
							}
						}
						this.setTyped(tmp);
					}
				} catch (final Exception ex) {
					log.error("", ex);
				}
			} else if (this.capturePanel.getComponent(i) instanceof JComboBox) {
				final JComboBox tmp = ((JComboBox) this.capturePanel.getComponent(i));
				if (tmp.getName().equalsIgnoreCase("land")) {
					continue;
				}
				if (tmp.isEditable()) {
					final JTextField editor = (JTextField) tmp.getEditor().getEditorComponent();
					final String fieldName = tmp.getName();
					try {
						log.debug("field name: " + fieldName);
						if ((fieldName != null) && !fieldName.equals("") && !fieldName.equalsIgnoreCase("reason")) {
							final String text = ((BLLAddressField) fields.get(fieldName)).getTyped();
							editor.setText(text);
							this.setTyped(tmp);
						}
					} catch (final Exception ex) {
						log.warn("", ex);
					}
				}
			}
		}
	}

	@Override
	public void updateKDPID(String kdpid) {
		// Request: https://helpdesk.spsvietnam.vn/WorkOrder.do?woMode=viewWO&woID=10025&&fromListView=true
		// infoPanel.setKdpid(kdpid);
		this.capturePanel.setKdpid(kdpid);

		if (kdpid.isEmpty()) {
			this.capturePanel.setDefaultColorBackGroundButton();
		} else {
			this.capturePanel.setColorBackGroundButton(Color.pink);
		}
	}

	@Override
	public void setMainFrame(UIMainFrame mainFrame) {

		this.mainFrame = mainFrame;
		this.initOCR(mainFrame);
	}

	@Override
	public void getLookup(Component lookup) {
		final CaptureMessage message = CaptureMessage.intance();
		message.clearData();
		message.setAction(StateCapture.OPEN_SUGGEST);
		message.setSource(lookup);

		this.request(message, this);
	}

	private void setTyped(JComponent comp) {// when lost focus text field
		final BLLCard bllCard = this.card.getCard();
		if (comp instanceof JTextField) {
			final String fieldName = comp.getName();
			final BLLField field = bllCard.getField(fieldName);
			if ((field != null) && (field instanceof BLLAddressField)) {
				String value = Utilities.ignoreNull(((JTextField) comp).getText());
				final String inputConstraint = ((BLLAddressField) field).getConstraint();
				int changeCaseType = 0;
				try {
					changeCaseType = Integer.parseInt(Utilities.getdata_seperator(inputConstraint, false, ";"));
				} catch (final NumberFormatException ex) {
					log.error("At field name:" + fieldName, ex);
				} catch (final Exception ex) {
					log.error("At field name:" + fieldName, ex);
				}
				value = this.changeCase(value, changeCaseType);
				((JTextField) comp).setText(value);
				if (fieldName.equalsIgnoreCase(BLLDataStructure.HAUSNUMMER_FIELD)) {
					final String[] tmp = this.spilitHauseNum(value);
					final BLLAddressField hauzusatField = (BLLAddressField) bllCard
							.getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD);
					((BLLAddressField) field).setTyped(tmp[0]);
					hauzusatField.setTyped(tmp[1]);
				} else {
					if (fieldName.equalsIgnoreCase(BLLDataStructure.PICKPOSTNUMMER_FIELD)) {
						if (!value.equals("")) {
							((BLLAddressField) field).setTyped(value);
						} else {
							if (!Utilities.ignoreNull(this.capturePanel.getJtfPostLagend().getText()).equals("")) {
								((BLLAddressField) field)
										.setTyped("#" + this.capturePanel.getJtfPostLagend().getText());
							} else {
								((BLLAddressField) field).setTyped("");
							}
						}
					} else {
						((BLLAddressField) field).setTyped(value);
					}
				}
			}
		} else if (comp instanceof JComboBox) {
			final String fieldName = comp.getName();
			if (BLLDataStructure.ANREDE_FIELD.equalsIgnoreCase(fieldName)) {
				((BLLAddressField) bllCard.getField(fieldName))
						.setTyped(((JTextField) ((JComboBox) comp).getEditor().getEditorComponent()).getText());
			} else if (BLLDataStructure.LAND_FIELD.equalsIgnoreCase(fieldName)) {
				((BLLAddressField) bllCard.getField(fieldName))
						.setTyped(((JTextField) ((JComboBox) comp).getEditor().getEditorComponent()).getText());
			}
		}
	}

	private String changeCase(String value, int type) {
		try {
			if (value.length() > 0) {
				return Utilities.changeCase(this.changeCase, value, type);
			}
		} catch (final Exception ex) {
			log.error(Utilities.getStackTrace(ex));
			return value;
		}
		return value;
	}

	private String[] spilitHauseNum(String str) {
		final String result[] = new String[2];
		String hausuzat = "";
		String hausNum = str;
		for (int j = 0; j < str.length(); j++) {
			if ((str.charAt(j) < '0') || (str.charAt(j) > '9')) {
				hausuzat = str.substring(j);
				hausNum = str.substring(0, j);
				break;
			}
		}
		result[0] = hausNum.trim();
		result[1] = hausuzat.trim();
		return result;
	}

	@Override
	public void processThread() {
		final CaptureMessage message = CaptureMessage.intance();
		message.clearData();
		message.setAction(StateCapture.CANCEL_PROCESS);
		this.request(message, this);
	}

	@Override
	public void defaultFocus() {
		this.capturePanel.getJtfFirmename().requestFocus();
	}

	public void start(UserName user) throws JMSException {
		log.info("[Capture]-START CAPTURE");
		UIManager.put("TextField.select", Color.YELLOW);
		UIManager.put("TextField.font", new Font("Tahoma", Font.PLAIN, 17));
		UIManager.put("Label.font", new Font("SansSerif", Font.PLAIN, 14));
		UIManager.put("Label.selectfont", new Font("SansSerif", Font.BOLD, 14));
		UIManager.put("Label.selectforeground", Color.RED);
		UIManager.put("List.font", new Font("SansSerif", Font.PLAIN, 16));
		try {
			TimeZone.setDefault(
					TimeZone.getTimeZone(ApplicationConfig.getInstance().getBusinessConfig().getTimeZone()));
		} catch (final Exception ex) {
			log.warn("cann't change time zone:" + ex);
		}

		this.user = user;
		this.setComm(new Communication(this));
		final UIMainFrame frame = new UIMainFrame(this);
		try {
			this.defaultState = new NormalState(user, this, this.viewData);
			this.stateCapture = this.defaultState;
		} catch (final SQLException e) {
			log.error(Utilities.getStackTrace(e));
		}
		this.infoPanel.setUsername(user.getFullName());
		frame.pack();
		frame.setVisible(true);
		this.initFocusManagement();
		final SwingWorker worker = new SwingWorker() {

			@Override
			protected void done() {
				final CaptureMessage message = CaptureMessage.intance();
				message.clearData();
				message.setAction(StateCapture.LOAD);

				CaptureMediatorImplement.this.request(message, CaptureMediatorImplement.this);
			}

			@Override
			protected Object doInBackground() throws Exception {
				final CaptureMessage message = CaptureMessage.intance();
				message.clearData();
				message.setAction(StateCapture.INIT_GUI);

				CaptureMediatorImplement.this.request(message, CaptureMediatorImplement.this);

				// Change request id:
				// CaptureMediatorImplement.this.getComponent(LAND).setEnabled(false);
				CaptureMediatorImplement.this.getComponent(LAND).setVisible(false);

				return null;
			}
		};

		worker.execute();
	}

	@Override
	public void viewInfo(String name) {
		this.displayPanel.setVisibleLegend(name);
	}

	@Override
	public void enableFieldWhenFocusPickpost() {
		this.capturePanel.enableWhenFocusPickpost();
		// enableSaveButton(true);
	}

	@Override
	public void getOcrInformation(Component component, byte index) {
		final CaptureMessage message = CaptureMessage.intance();
		message.clearData();
		message.setAction(StateCapture.OCR_INFORMATION);
		final HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("component", component);
		data.put("index", index);
		message.setSource(data);
		
		this.request(message, this);
	}

	@Override
	public void ocrCropImage(byte[] cropImage) {	
		this.enableFieldWhenFocusPickpost();
		final CaptureMessage information = CaptureMessage.intance();
		information.clearData();
		information.setAction(StateCapture.OCR);
		information.setSource(cropImage);
		this.request(information, this);
	}

	@Override
	public void enableSaveButton(boolean b) {
		this.buttonBar.enableSaveButton(b);
		this.menubar.enableSaveButton(b);
	}

	@Override
	public void getReLoadData(JTextField field) {
		this.capturePanel.getJtfStrasse().setText(this.capturePanel.handleErrorFontTextField(this.strStrasse));
		this.capturePanel.getJtfOrt().setText(this.strOrt);
	}

	@Override
	public void firstEnterLookup() {
		if (this.firstSearch) {
			this.search();
		}
	}

	@Override
	public void swapVornameNachname(String vorname, String nachname, int validPercent) {
		if (this.viewData.checkSwapCondtion(vorname, nachname, validPercent)) {
			if (JOptionPane.showConfirmDialog(this.mainFrame, "Ban co muon hoan doi Vorname va Nachname?", "Xac nhan",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
				((JTextField) this.getComponent(VORNAME)).setText(StringUtils.capitalize(nachname));
				((JTextField) this.getComponent(NAME)).setText(StringUtils.capitalize(vorname));
			}
		}
	}
	
	// CI123: PRESS F9 TO MOVE NAME TO FIRMA
	@Override
	public void moveVornameName(String firmaName, String zusatzName, String indexType, String value, Component component) {
		String res = this.viewData.checkMoveCondition(indexType, value);
		if (res.equalsIgnoreCase("[]")) {
			List<String> ocrData = this.ocrInfo.getAllData();
			String ret = StringUtil.containValue(value, ocrData, this.viewData);
//			if (indexType == LookupServiceImpl.INDEX_TYPE_NAME) {
//				((JTextField) this.getComponent(NAME)).setText(StringUtils.capitalize(""));
//			} if (indexType == LookupServiceImpl.INDEX_VORNAME_TYPE) {
//				((JTextField) this.getComponent(VORNAME)).setText(StringUtils.capitalize(""));
//			} 
			
			if (indexType == LookupServiceImpl.INDEX_NACHNAMEMORE_TYPE) {
				((JTextField) this.getComponent(NAME)).setText(StringUtils.capitalize(""));
			} if (indexType == LookupServiceImpl.INDEX_VORNAMEMORE_TYPE) {
				((JTextField) this.getComponent(VORNAME)).setText(StringUtils.capitalize(""));
			} 
			
			if (!ret.isEmpty()) {
				if (firmaName.isEmpty()) {
					((JTextField) this.getComponent(FIRMA)).setText(StringUtils.capitalize(ret));
					((JTextField) this.getComponent(FIRMA)).requestFocus();
				} if (!firmaName.isEmpty()) {
					zusatzName += " " + ret;
					((JTextField) this.getComponent(ZUSAT)).setText(StringUtils.capitalize(zusatzName.trim()));
					((JTextField) this.getComponent(ZUSAT)).requestFocus();
				}
			} if (ret.isEmpty()) {
				if (firmaName.isEmpty()) {
					((JTextField) this.getComponent(FIRMA)).setText(StringUtils.capitalize(value));
					((JTextField) this.getComponent(FIRMA)).requestFocus();
				} if (!firmaName.isEmpty()) {
					zusatzName += " " + value;
					((JTextField) this.getComponent(ZUSAT)).setText(StringUtils.capitalize(zusatzName.trim()));
					((JTextField) this.getComponent(ZUSAT)).requestFocus();
				}
			}
		} else {
			// this.openSuggestionForm(indexType, value, arrValues, component);
			this.getLookup(component);
		}
	}
	
	/**
	 *  Dev by htvy, 16/11/2017
	 *  ABA-68 - CI-116: Rollback KDP, hot key: F8
	 */
	@Override
	public void rollBackKDP() {
		log.info("Rollback KDP || Press F8");
		
		final CaptureMessage message = CaptureMessage.intance();
		message.clearData();
		message.setAction(StateCapture.ROLLBACK_KDP);
		this.request(message, this);	
	}

	@Override
	public synchronized void setStatusCard(final String status) {
		log.debug("in set Status Card :" + status);
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				CaptureMediatorImplement.this.proccessLoadCard.setStr(status + ". Dung tat chuong trinh!!!");
			}
		});
	}

	/**
	 * @throws JMSException
	 *
	 */
	@Override
	public void loadCardEvent(boolean gettingCard) throws JMSException {
		this.commu.loadCardEvent(gettingCard);
	}

	@Override
	public void activeWindows() {
		this.mainFrame.activeWindow();
	}

	private void setComm(Communication commu) {
		this.commu = commu;
	}

	private class CountTimeBar implements Runnable {

		int count;

		@Override
		public void run() {
			while (true) {
				try {
					Thread.sleep(1000); // sleep one second
				} catch (final InterruptedException e) {
					log.warn("", Utilities.getStackTrace(e));
					break;
				}
				this.count++;
				CaptureMediatorImplement.this.proccessLoadCard.setDuration(this.count);
			}
		}
	}

	@Override
	public Component getProcessLoadCard() {
		return this.proccessLoadCard;
	}

	@Override
	public void clearKDP() {
		final CaptureMessage message = CaptureMessage.intance();
		message.clearData();
		message.setAction(StateCapture.CLEAR_KDPID);
		// message.setSource(lookup);

		this.request(message, this);
	}

	@Override
	public void learn() {
		final Thread thread = new Thread() {
			@Override
			public void run() {
				for (final Component compo : CaptureMediatorImplement.this.capturePanel.getComponents()) {
					if (compo instanceof LearningInterface) {
						try {
							((LearningInterface) compo).learn();
						} catch (final Exception e) {
							log.debug("", e);
						}
					}
				}
			}
		};

		thread.start();
	}

	@Override
	public void setUseSuggestion(boolean useSuggestion) {
		this.capturePanel.setUseSuggestion(useSuggestion);

	}
	
	public static void resetCountLookup() {
		CaptureMediatorImplement.countLookup = 0;
	}
	
// CI123 open suggestion dialog.	
//	private void openSuggestionForm(String indexType, String value, List<Map<String, String>> arrValues, Component component) {
//		String fieldName = "";
//		if (indexType == LookupServiceImpl.INDEX_VORNAMEMORE_TYPE) {
//			fieldName  = LookupServiceImpl.SEARCHMORE_KEYS.get("vorname");
//		} else {
//			fieldName = LookupServiceImpl.SEARCHMORE_KEYS.get("name");
//		}
//		final UISearchNomal search = UISearchNomal
//				.intance((JFrame) this.getComponent(MainFieldInterface.FRAME_VIEW));
//		search.clearData();
//		search.setParentMainFace(this);
//		search.setSearchType(UISearch.searchOther);
//		search.setDataResult(arrValues);
//		search.setTitle(new LookupKey[] { LookupKey.fromKey(fieldName) });
//		search.setCurrentJtf((JTextField) component);
//		if (component == this.getComponent(MainFieldInterface.VORNAME)) {
//			search.setNextFocus((JComponent) this.getComponent(MainFieldInterface.NAME));
//		}
//		if (component == this.getComponent(MainFieldInterface.NAME)) {
//			search.setNextFocus((JComponent) this.getComponent(MainFieldInterface.PLZ));
//		}
//		
//		try {
//			search.viewResult();
//		} catch (final Exception ex) {
//			log.error("", ex);
//		}
//	}
}
