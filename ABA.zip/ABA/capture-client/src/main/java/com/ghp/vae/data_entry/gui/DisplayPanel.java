package com.ghp.vae.data_entry.gui;

import javax.swing.*;

import com.sps.vn.config.ApplicationConfig;

import java.awt.*;

public class DisplayPanel extends JPanel{

	public DisplayPanel() {
		initComponent();
	}
	
	private JLabel label_1;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label_7;
	private JLabel label_8;
	private JLabel label_9;
	
	private void initComponent() {
		initGui();
		
		label_1 = new JLabel();
		label_2 = new JLabel();
		label_3 = new JLabel();
		label_4 = new JLabel();
		label_5 = new JLabel();
		label_6 = new JLabel();
		label_7 = new JLabel();
		label_8 = new JLabel();
		label_9 = new JLabel();
		
		label_1.setBounds(28, 27, 178, 14);
		label_2.setBounds(28, 49, 178, 14);
		label_3.setBounds(28, 74, 178, 14);
		label_4.setBounds(28, 100, 178, 14);
		label_5.setBounds(28, 125, 179, 14);
		label_6.setBounds(246, 27, 182, 14);
		label_7.setBounds(246, 49, 182, 14);
		label_8.setBounds(246, 74, 182, 14);
		label_9.setBounds(246, 100, 182, 14);
		
		initLable(label_1);
		initLable(label_2);
		initLable(label_3);
		initLable(label_4);
		initLable(label_5);
		initLable(label_6);
		initLable(label_7);
		initLable(label_8);
		initLable(label_9);
		
		
	}

	private void initLable(JLabel label) {
		label.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label.setForeground(Color.blue);
		this.add(label);
	}

	private void initGui() {
		this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Post Legend", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11))); // NOI18N
		this.setAlignmentX(0.0F);
		this.setAlignmentY(0.0F);
		this.setFont(new java.awt.Font("Tahoma", 0, 10));
		this.setLayout(null);
	}

	public void setVisibleLegend(String name) {
		this.setVisible(true);
		this.repaint();
		
		if (name.equalsIgnoreCase("postfachnummer")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getPostfachTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getPostfachInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}
			
		} else if (name.equalsIgnoreCase("postlagend")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getPostlagerndTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getPostlagerndInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("pickpostnummer")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getPickpostTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			// Update
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getPickpostInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("stockwerk")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getStockwerkTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getStockwerkInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("adresszusatz")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getAdresszusatzTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getAdresszusatzInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("co_addresse")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getCo_addresseTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getCo_addresseInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("lookup")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getLookupTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getLookupInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("firmenname")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getFirmaTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getFirmaInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("namenszusatz")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getZusatTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getZusatInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("anrede")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getAnredeTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getAnredeInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("vorname")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getVornameTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getVornameInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("name")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getNameTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getNameInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("plz")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getPlzTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getPlzInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("ort")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getOrtTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getOrtInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("strasse")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getStrasseTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getStrasseInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("hausnummer")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getHouseTitle(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getHouseInfo();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else if (name.equalsIgnoreCase("mypost24")) {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, ApplicationConfig.getInstance().getDisplayConfig().getMypost24Title(), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			
			String[] info = ApplicationConfig.getInstance().getDisplayConfig().getMypost24Info();
			try {
				setLegend(info[0].replaceAll("\"", ""), info[1].replaceAll("\"", ""), info[2].replaceAll("\"", ""), info[3].replaceAll("\"", ""), info[4].replaceAll("\"", ""), info[5].replaceAll("\"", ""), info[6].replaceAll("\"", ""), info[7].replaceAll("\"", ""), info[8].replaceAll("\"", ""));
			} catch (Exception ex) {
				setLegend( "", "", "", "", "", "", "", "", "");
			}

		} else {
			this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, name, javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
					javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11)));
			setLegend( "", "", "", "", "", "", "", "", "");
			
			System.out.println(name); 
		}
	}
	private void setLegend(String label1, String label2, String label3, String label4, String label5, String label6, String label7, String label8, String label9) {
		label_1.setText(label1);
		label_2.setText(label2);
		label_3.setText(label3);
		label_4.setText(label4);
		label_5.setText(label5);
		label_6.setText(label6);
		label_7.setText(label7);
		label_8.setText(label8);
		label_9.setText(label9);
	}
}
