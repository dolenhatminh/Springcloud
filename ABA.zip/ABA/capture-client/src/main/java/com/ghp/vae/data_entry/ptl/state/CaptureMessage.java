package com.ghp.vae.data_entry.ptl.state;

import com.ghp.vae.data_entry.face.ObjectInformation;

public class CaptureMessage implements ObjectInformation{
	
	private static CaptureMessage information = new CaptureMessage(); 
	private CaptureMessage() {
	}
	
	private byte action;
	private Object source;
	public byte getAction() {
		return action;
	}

	@Override
	public void setAction(byte action) {
		this.action = action;
		
	}

	@Override
	public Object getSource() {
		return source;
	}

	@Override
	public void setSource(Object souce) {
		this.source = souce; 
		
	}

	@Override
	public void clearData() {
		action = 0;
		source = null;
	}
	
	public static CaptureMessage intance(){
		return information;
//		return new CaptureMessage();
	}
}
