package com.ghp.vae.data_entry.ptl;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Event;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.KeyStroke;
import javax.swing.SwingWorker;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.CheckInput;
import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.ObjectInformation;
import com.ghp.vae.data_entry.face.StateCapture;
import com.ghp.vae.data_entry.gui.CaptureMediatorImplement;
import com.ghp.vae.data_entry.ptl.state.AroundDialog;
import com.ghp.vae.data_entry.ptl.state.CaptureMessage;
import com.ghp.vae.search.service.impl.LookupServiceImpl;

import net.java.balloontip.BalloonTip;
import net.java.balloontip.styles.BalloonTipStyle;
import net.java.balloontip.styles.EdgedBalloonStyle;
import vae.client.transfer.LookupKey;

public class UISearch extends JDialog implements ActionListener {
    // public class UISearch extends JFrame implements ActionListener {

    private static Logger log = LoggerFactory.getLogger(UISearch.class);
    private static org.slf4j.Logger sloger = LoggerFactory.getLogger(UISearch.class);
    /**
     *
     */
    private static final long serialVersionUID = 215877504251966534L;
    // public static final UISearch singleton = new UISearch();
    private JTable jtData = null;
    private final int screen_lenx;
    private final int screen_leny;
    private JPanel jpMain;
    private int searchType;
    private JTextField curJtf;
    private JButton jbtnPrevious = null;
    private JButton jbtnNext = null;
    private JLabel jlblAmountRecord = null;
    private JLabel jlblResult = null;
    private JLabel jlblRecordsDisplayed = null;
    private JScrollPane jsbData = null;
    MainFieldInterface parentFrame;
    private JButton jbtnSelect = null;
    private JButton jbtnCancel = null;
    private final int MAXROW = 9;
    private int curPage = 0;
    private int maxPage = 0;
    ModeForTable dTableModel = null;
    private JLabel jlblRecordPerPage = null;
    private JLabel jlblCurrPage = null;
    private JLabel jlblCurrentPage = null;
    private JPanel jpnlLabel = null;
    private JPanel jpnlButton = null;
    private JTextField jtfSelectedRow;
    public static final int searchKDP = 1;
    public static final int searchOther = 2;
    public static final int searchPlz = 5;
    public static final int searchStrasse = 3;
    public static final int searchOrt = 4;
    public JComponent nextFocusComp;
    private XTableColumnModel xTableColumnModel = null;
    JPopupMenu popup;
    private List<Map<String, String>> dataArr;
    private LookupKey[] title;

    // Hoang add new
    ColorColumnRenderer normalRenderBlack;
    ColorColumnRenderer normalRenderBlue;
    ColorColumnRenderer normalRenderSpecial;
    ColorColumnRenderer normalRenderAlias;
    private final Color nameAliasColor = new Color(165, 42, 42);

    private UISearch(JFrame parent) {
        super(parent);
        this.setModal(true);
        final Rectangle rec = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice()
                .getDefaultConfiguration().getBounds();
        this.screen_leny = rec.height;
        this.screen_lenx = rec.width;
        this.initComponent();
        this.initForNew();
        this.addWindowListener(this.adapter);
        this.keyBind();
    }

    /**
     * @create Uisearch don't have data.
     * @param parentFrame
     */
    private UISearch() {
        this(null);
    }

    public static void destroy() {
        if (rowTip != null) {
            rowTip.setVisible(false);
            rowTip = null;
        }

        if (search != null) {
            search.dispose();
        }

        search = null;
    }

    private void initForNew() {
        this.dTableModel = new ModeForTable();
        this.normalRenderBlack = new ColorColumnRenderer(Color.BLACK, new Font("Tahoma", Font.BOLD, 16), Color.WHITE);
        this.normalRenderBlue = new ColorColumnRenderer(Color.BLUE, new Font("Tahoma", Font.PLAIN, 17), Color.WHITE);
        this.normalRenderSpecial = new ColorColumnRenderer(new Color(139, 0, 139), new Font("Tahoma", Font.PLAIN, 17),
                Color.WHITE);

        this.xTableColumnModel = new XTableColumnModel();

    }

    /**
     * view data when finish update data
     *
     * @throws InterruptedException update ui : scroll panel, table.
     */
    public void viewResult(final boolean isSpecial) throws InterruptedException {
        final SwingWorker worker = new SwingWorker() {

            boolean isContinue = false;

            @Override
            protected Object doInBackground() throws Exception {

                final List<Map<String, String>> results = new ArrayList<Map<String, String>>(0);

                // // Separate kdp special and kdp normal
                // for (final Map<String, String> mapData : UISearch.this.dataArr) {
                // if (mapData.get(LookupKey.IS_SPECIAL.getKey()).equalsIgnoreCase(isSpecial + "")) {
                // results.add(mapData);
                // }
                // }
                // 18/07/2016 -UPDATE-Display all kdp
                results.addAll(UISearch.this.dataArr);

                this.isContinue = UISearch.this.initPageEx(results, UISearch.this.title, isSpecial);
                if (this.isContinue) {
                    UISearch.this.init2();
                    UISearch.this.initialize();
                    // addOlderEvent();
                    UISearch.this.parentFrame.setProcessStatus(false);
                    UISearch.this.jtData.revalidate();
                    // jsbData.setViewportView(jtData);
                    UISearch.this.jsbData.getHorizontalScrollBar().setValue(0);
                    UISearch.this.jsbData.setColumnHeaderView(UISearch.this.jtData.getTableHeader());
                    UISearch.this.jsbData.getColumnHeader().setViewPosition(new Point(0, 0));

                } else {
                    destroy();
                }
                return null;
            }

            @Override
            protected void done() {
                CaptureMediatorImplement.releaseLookup();

                if (this.isContinue) {
                    UISearch.this.setVisible(true);
                }
            }
        ;

        };
		worker.execute();

    }

    private void updateRecordInformation() {
        try {
            this.jlblResult.setText(String.valueOf(this.totalSize));
            this.jlblCurrentPage.setText(String.valueOf((this.curPage + 1)));
            if (this.bufferDataEx != null) {
                final String tmp = String.valueOf(this.bufferDataEx.size()) + "/" + this.totalSize;
                this.jlblRecordsDisplayed.setText(tmp);
            }
        } catch (final Exception e) {
            log.error(Utilities.getStackTrace(e));
        }

    }

    public void clearData() {

        this.dataArr = null;
        this.title = null;
        this.searchType = 0;
        this.nextFocusComp = null;
        this.curJtf = null;
        this.isSelectKDPID = false;
        this.curPage = 0;
        this.maxPage = 0;
        this.totalSize = 0;
        this.splitPage.clear();
        this.bufferDataEx = null;

    }

    private void removeEvent() {
        for (final WindowListener lister : this.getWindowListeners()) {
            this.removeWindowListener(lister);
        }
        if (this.jtData != null) {
            this.jtData.getActionMap().clear();
        }
    }

    private boolean searchKDP() {
        return this.searchType == searchKDP;
    }

    /**
     * This method initializes this
     *
     */
    private void initialize() {
        try {
            this.setContentPane(this.jpMain);
        } catch (final Exception e) {
            log.error("", e);
        }
    }

    private final HashMap<Integer, Vector<Vector<String>>> splitPage = new HashMap<Integer, Vector<Vector<String>>>();
    private int totalSize;
    private Vector<String> tableTitleEx;
    // private boolean findNextKDP= false;
    private final WindowListener adapter = new WindowExcute();

    /**
     * add data into map for get page keyIndex from 1 to end
     */
    private boolean initPageEx(List<Map<String, String>> data, LookupKey[] title, boolean isSpecial) {
        try {

            if (data == null) {
                return false;
            }
            int index = 0;
            int currentPage = 0;
            this.totalSize = data.size();

            /**
             * check row is empty
             */
            if (this.totalSize == 0) {
                System.out.println(" *** arrValuesLookup isEmptyList *** ");

                this.setUpdateMessage(this.parentFrame, false);
                this.parentFrame.displayToolTip();
                this.clearWhenNotChooseKdp(this.parentFrame);
                this.parentFrame.resetState();
                this.parentFrame.getComponent(MainFieldInterface.FIRMA).requestFocus();
                return false;
            }

            Vector<Vector<String>> rows = new Vector<Vector<String>>();
            for (final Map<String, String> mapData : data) {

                final Vector<String> row = new Vector<String>();

                for (final LookupKey element : title) {
                    row.add(mapData.get(element.getKey()));
                }

                rows.add(row);
                index++;
                if (index == this.MAXROW) {
                    this.splitPage.put(new Integer(currentPage), rows);
                    rows = new Vector<Vector<String>>();
                    currentPage++;
                    index = 0;
                }
            }

            if (index > 0) {
                this.splitPage.put(new Integer(currentPage), rows);
            }
            if (data.isEmpty()) {
                this.splitPage.put(new Integer(0), rows);
            }
            this.maxPage = this.splitPage.keySet().size();

            this.tableTitleEx = new Vector<String>();
            for (final LookupKey header : title) {
                this.tableTitleEx.add(header.getHeader());
            }

            return true;

        } catch (final Exception e) {
            log.error("", e);
            return false;
        }
    }

    private void setUpdateMessage(final MainFieldInterface main, final boolean visible) {
        if (!visible) {
            try {
                Thread.sleep(100);
            } catch (final InterruptedException e) {
                log.warn("", e);
            }
        }
        main.setProcessStatus(visible);
    }

    private void clearWhenNotChooseKdp(MainFieldInterface main) {
        // Card card = main.getEntity();
        main.displayToolTip();
        this.setUpdateMessage(main, false);
        AroundDialog.showMessageDialog(null, "Khong co ket qua nao duoc tim thay", "Thong tin",
                JOptionPane.INFORMATION_MESSAGE);
        main.resetState();
        // card.clearValue();
        // resetAddressFieldValue(main);
    }

    private Vector<Vector<String>> getRecords(Integer page) {
        return this.splitPage.get(page);
    }

    private void setEnableButton() {
        try {

            if ((this.curPage == 0) && (this.maxPage <= 1)) {
                this.jbtnPrevious.setEnabled(false);
                this.jbtnNext.setEnabled(false);
            } else if ((this.curPage == 0) && (this.curPage < this.maxPage)) {
                this.jbtnPrevious.setEnabled(false);
                this.jbtnNext.setEnabled(true);
            } else if ((this.curPage > 0) && (this.curPage >= (this.maxPage - 1))) {
                this.jbtnPrevious.setEnabled(true);
                this.jbtnNext.setEnabled(false);
            } else if ((this.curPage > 0) && (this.curPage < this.maxPage)) {
                this.jbtnPrevious.setEnabled(true);
                this.jbtnNext.setEnabled(true);
            }

        } catch (final Exception e) {
            log.error("", e);
        }
    }

    void init2() {
        try {

            this.setTableModel();
            this.checkInterrupted("end set table model");
            this.showMouseOnTable();
            this.setEnableButton();
            this.updateRecordInformation();
            // Hoang check need addEvent and keyBind
            // addEvent();
            // keyBind();

        } catch (final Exception e) {
            log.error("", e);
        }
    }

    /**
     * function update kdp id when chosen kdp record.
     *
     * @note remove function pms id 4981
	 *
     */
    void updateKDPID() {
        if (this.searchKDP()) {
            UISearch.this.parentFrame.displayToolTip();
            final ObjectInformation message = CaptureMessage.intance();
            message.clearData();
            message.setAction(StateCapture.UPDATE_KDP);

            UISearch.this.parentFrame.request(message, UISearch.this.parentFrame);
        }
    }

    Color fgndColor = Color.BLACK;
    Font font = new Font("Tahoma", Font.PLAIN, 16);
    static Color bgColor;// = new Color(0xBAEDBA);

    @SuppressWarnings("unchecked")
    void setTableModel() {
        try {
            if (this.getRecords(this.curPage) != null) {
                this.bufferDataEx = (Vector<Vector<String>>) this.getRecords(this.curPage).clone();
            } else {
                this.bufferDataEx = new Vector<Vector<String>>(0);
            }

            // Group Firma and Person
            this.bufferDataEx = this.groupKDPbyFirmaandPerson(this.bufferDataEx);

            // Hoang remove new ModeForTable.
            this.xTableColumnModel.clearAllColumn();

            this.dTableModel.setDataVector(this.bufferDataEx, this.tableTitleEx);

            this.dTableModel.addColumn(LookupKey.NO.getHeader());
            this.jtData.setModel(this.dTableModel);
            this.positionColumn(this.jtData, 0);

            if (this.jtData.getModel().getRowCount() != 0) {
                this.jtData.getSelectionModel().setSelectionInterval(0, 0);
            }

            this.jtData.setRowHeight(29);
            this.addValueForFirstColunm();

            this.changeLocationAndSize();
            final int columNum = this.jtData.getColumnCount();
            if ((columNum > 1) && (columNum < 14)) {
                this.jtData.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
                final long w = Math.round(this.getBounds().getWidth() - 40) / (columNum - 1);
                final String sw = String.valueOf(w);
                for (int k = 0; k < columNum; k++) {
                    final TableColumn column = this.jtData.getColumnModel().getColumn(k);
                    if (k == 0) {
                        column.setPreferredWidth(40);
                    } else if ((this.searchType == searchKDP) && ((k == 1) || (k == 6))) {
                        column.setPreferredWidth(Integer.valueOf((int) w * 3));
                    } else if ((this.searchType == searchKDP) && ((k == 2) || (k == 3) || (k == 5))) {
                        column.setPreferredWidth(Integer.valueOf((int) w * 2));
                    } else {
                        column.setPreferredWidth(Integer.valueOf(sw));
                    }
                }
            }
            if (columNum >= 10) {
                this.jtData.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
                this.jtData.setColumnModel(this.xTableColumnModel);
                this.jtData.createDefaultColumnsFromModel();
                this.positionColumn(this.jtData, 0);
                this.addValueForFirstColunm();
                this.jtData.getTableHeader().setBackground(bgColor);

                /**
                 * Request ID : 4743 [VAE]KDP_Result_Table
                 */
                // fix width
                // pvgiang_1 -13/07/2016- UPDATE: Remove fields which are removed. View Lookupkey.java for detail!
                for (int i = 0; i < this.jtData.getColumnCount(); i++) {
                    this.jtData.getColumnModel().getColumn(i).setPreferredWidth(LookupKey.fromHeader(this.jtData.getColumnName(i)).getWidth());
                    this.jtData.getColumnModel().getColumn(i).setCellRenderer(this.normalRenderBlack);
                    if (this.jtData.getColumnName(i).equals(LookupKey.STRASSE_SET.getHeader())) {
                        this.jtData.getColumnModel().getColumn(i).setCellRenderer(this.normalRenderBlue);
                    } else if (this.jtData.getColumnName(i).equals(LookupKey.ORT_SET.getHeader())) {
                        this.jtData.getColumnModel().getColumn(i).setCellRenderer(this.normalRenderSpecial);
                    }
                }

            } else {
                this.jtData.setColumnModel(new DefaultTableColumnModel());
            }
            this.jtData.repaint();

            // jtData.doLayout();
        } catch (final Exception ex) {
            // ex.printStackTrace();
            log.error("", ex);
        } finally {

        }
    }

    private void addValueForFirstColunm() {
        try {

            for (int i = 0; i < this.jtData.getModel().getRowCount(); i++) {
                this.jtData.getModel().setValueAt(i + 1, i, this.jtData.getColumnCount() - 1);
            }

        } catch (final Exception e) {
            log.error("", e);
        }
    }

    /**
     * Show mouse on the table.
     *
     * @param
     * @return
     */
    void showMouseOnTable() throws InterruptedException {
        try {

            final Robot robot = new Robot();
            robot.mouseMove((this.screen_lenx / 2) + (this.screen_lenx / 4) + (this.screen_lenx / 20),
                    (this.screen_leny / 4) + (this.screen_leny / 50));
        } catch (final Exception e) {
            log.error("", e);
            log.error("", e);
        }
    }

    /**
     * Initialize component.
     *
     * @param
     * @return
	 *
     */
    private void initComponent() {
        try {
            this.setTitle("Search KDP");
            this.jpMain = new javax.swing.JPanel();
            this.jpMain.setLayout(new BorderLayout());
            this.setContentPane(this.jpMain);
            this.jpMain.add(this.getJPanel(), java.awt.BorderLayout.SOUTH);
            this.jpMain.add(this.getJsbData(), java.awt.BorderLayout.CENTER);
            this.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
            this.setLocation(200, 50);
            this.pack();
        } catch (final Exception ex) {
            log.error("", ex);
        }
    }

    int kdpType = 0;

    private boolean isSelectKDPID = false;

    private void setData2AddressInfo(int rowSelected) {
        // Store ocr value for logging
        final Map<Byte, String> ocrValues = new HashMap<Byte, String>();
        for (final Byte field : LogUtil.logFields) {
            final JTextField control = (JTextField) this.parentFrame.getComponent(field);
            ocrValues.put(field, control.getText());
        }

        int row;
        if (rowSelected < 0) {
            row = this.jtData.getSelectedRow();
        } else {
            row = rowSelected;
        }

        log.debug("row selected: " + row);
        String plz;
        if (this.jtData.getModel().getRowCount() > 0) {
            switch (this.searchType) {
                case searchKDP:// seach reference
                    // <editor-fold defaultstate="collapsed"
                    // desc="set value for address fields">
                    // begin set typed
                    final Vector vectorData = (Vector) ((DefaultTableModel) this.jtData.getModel()).getDataVector()
                            .get(row);

                    final Map<String, String> map = new HashMap<String, String>(vectorData.size());

                    for (int i = 0; i < this.title.length; i++) {
                        map.put(this.title[i].getKey(), vectorData.get(i) == null ? null : vectorData.get(i).toString());
                    }
                    this.parentFrame.getEntity().setVectorKDP(map);
                    this.parentFrame.getEntity().getCard()
                            .setKdpSpecical(Boolean.valueOf(map.get(LookupKey.IS_SPECIAL.getKey())));
                    this.parentFrame.getEntity().setHaveValueFromSearchKdp(true);
                    this.isSelectKDPID = true;
                    this.updateKDPID();
                    break;

                // </editor-fold>
                case searchOther:// search lookup 1 field
                    if ("plz".equalsIgnoreCase(this.curJtf.getName())) {
                        plz = Utilities.toString(this.jtData.getModel().getValueAt(row, 0));
                        if (plz.length() > 4) {
                            plz = plz.substring(0, 4);
                        }
                        this.curJtf.setText(plz);
                    } else {
                        this.curJtf.setText(this.jtData.getModel().getValueAt(row, 0).toString());
                    }
                    break;
                case searchStrasse:// strasse
                    this.curJtf.setText(this.jtData.getModel().getValueAt(row, 0).toString());// strasse
                    ((JTextField) this.parentFrame.getComponent(MainFieldInterface.ORT))
                            .setText(this.jtData.getModel().getValueAt(row, 1).toString());
                    plz = Utilities.toString(this.jtData.getModel().getValueAt(row, 2));
                    if (plz.length() > 4) {
                        plz = plz.substring(0, 4);
                    }
                    ((JTextField) this.parentFrame.getComponent(MainFieldInterface.PLZ)).setText(plz);
                    break;
                case searchOrt:// ort
                    this.curJtf.setText(this.jtData.getModel().getValueAt(row, 0).toString());// ort
                    plz = Utilities.toString(this.jtData.getModel().getValueAt(row, 1));
                    if (plz.length() > 4) {
                        plz = plz.substring(0, 4);
                    }
                    ((JTextField) this.parentFrame.getComponent(MainFieldInterface.PLZ)).setText(plz);
                    break;
                case searchPlz:// plz
                    plz = Utilities.toString(this.jtData.getModel().getValueAt(row, 0));
                    if (plz.length() > 4) {
                        plz = plz.substring(0, 4);
                    }
                    this.curJtf.setText(plz);// plz
                    ((JTextField) this.parentFrame.getComponent(MainFieldInterface.ORT))
                            .setText(this.jtData.getModel().getValueAt(row, 1).toString());
                    // curJtf.requestFocus();
                    break;
            }
        }

        // send to gray log
        LogUtil.logLookupResult(sloger, row, this.parentFrame, ocrValues);
        // End log
    }

    /**
     * Key(Enter, ESC) event.
     *
     * @param java .awt.event.KeyEvent evt
     * @return
	 *
     */
    boolean enter = false;

    private void tblDataKeyPressed(java.awt.event.KeyEvent evt) {
        if (this.popup != null) {
            this.popup.setVisible(false);
        }

        if (evt.getKeyCode() == KeyEvent.VK_ESCAPE) {
            if (this.curJtf != null) {
                this.curJtf.requestFocus();
            }
            this.parentFrame.displayToolTip();
            this.sleepWhenClose(150);
            destroy();
        } else if (evt.getKeyCode() == 10) {
            this.setData2AddressInfo(-1);
            this.resetRequestfocus();
            this.sleepWhenClose();
            destroy();
        } else if (evt.getKeyCode() == 117) {
            /**
             * #10672: Change request - F6 function
             */
            this.setData2AddressInfo(-1);
            this.resetRequestfocus();
            this.sleepWhenClose();
            destroy();
            this.parentFrame.clearKDP();
        } else if ((((evt.getKeyCode()) >= 97) && (evt.getKeyCode() <= 105))
                || (((evt.getKeyCode()) >= 49) && (evt.getKeyCode() <= 57))) {
            final String selectedRow = this.jtfSelectedRow.getText();
            final int currentRow = this.jtData.getSelectedRow();
            if ((selectedRow != null) && !selectedRow.equals("") && selectedRow.equals("" + (currentRow + 1))) {
                this.setData2AddressInfo(-1);
                this.resetRequestfocus();
                this.sleepWhenClose();
                destroy();
            }
        } else if ((evt.getKeyCode() == 37) && this.jbtnPrevious.isEnabled()) // left
        {
            this.goPrevious();
            this.displayRowTip(0);
            evt.consume();
        } else if ((evt.getKeyCode() == 39) && this.jbtnNext.isEnabled()) // right
        {
            this.goNext();
            this.displayRowTip(0);
            evt.consume();
        } else if (evt.getKeyCode() == KeyEvent.VK_DOWN) {
            final int currentRow = this.jtData.getSelectedRow() + 1;
            if ((currentRow >= 0) & (currentRow < this.jtData.getRowCount())) {
                final String vorname = this.jtData.getModel().getValueAt(currentRow, 1).toString();
                try {
                    // searchVornameSynonym(vorname);
                    this.displayRowTip(currentRow);
                } catch (final Exception ex) {
                    log.error("", ex);
                }
            } else if (this.jtData.getRowCount() == 1) {
                final String vorname = this.jtData.getModel().getValueAt(0, 1).toString();
                // searchVornameSynonym(vorname);
                this.displayRowTip(0);
            }
        } else if (evt.getKeyCode() == KeyEvent.VK_UP) {
            final int currentRow = this.jtData.getSelectedRow() - 1;
            if ((currentRow >= 0) & (currentRow < this.jtData.getRowCount())) {
                final String vorname = this.jtData.getModel().getValueAt(currentRow, 1).toString();
                // searchVornameSynonym(vorname);
                this.displayRowTip(currentRow);
            } else if (this.jtData.getRowCount() == 1) {
                final String vorname = this.jtData.getModel().getValueAt(0, 1).toString();
                // searchVornameSynonym(vorname);
                this.displayRowTip(0);
            }
        }

    }

    /**
     * Select event.
     *
     * @param java .awt.event.ActionEvent evt.
     * @return
	 *
     */
    private void btnSelectActionPerformed(java.awt.event.ActionEvent evt) {
        this.setData2AddressInfo(-1);
        // curJtf.requestFocus();
        this.resetRequestfocus();
        this.sleepWhenClose();

        destroy();
    }

    /**
     * Cancel event.
     *
     * @param java .awt.event.ActionEvent evt
     * @return
	 *
     */
    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {
        if ((this.parentFrame.getEntity().getKdpType() != 1) && (this.parentFrame.getEntity().getKdpType() != 2)) {
            this.parentFrame.getEntity().setHaveValueFromSearchKdp(false);
        }

        this.resetRequestfocus();
        this.sleepWhenClose();
        destroy();
    }

    private void resetRequestfocus() {
        if (this.nextFocusComp != null) {
            this.nextFocusComp.requestFocus();
        } else if (this.curJtf != null) {
            this.curJtf.requestFocus();
        }
    }

    /**
     * This method initializes jbtnPrevious
     *
     * @return javax.swing.JButton
     */
    private JButton getJbtnPrevious() {
        if (this.jbtnPrevious == null) {
            this.jbtnPrevious = new JButton();
            this.jbtnPrevious.setText("<");
            this.jbtnPrevious.setMnemonic(',');
            this.jbtnPrevious.setBounds(new java.awt.Rectangle(7, 30, 45, 24));
            this.jbtnPrevious.setActionCommand(PREVIOUS);
            this.jbtnPrevious.addActionListener(this);
        }
        return this.jbtnPrevious;
    }

    /**
     * This method initializes jbtnNext
     *
     * @return javax.swing.JButton
     */
    private JButton getJbtnNext() {
        if (this.jbtnNext == null) {
            this.jbtnNext = new JButton();
            this.jbtnNext.setText(">");
            this.jbtnNext.setMnemonic('.');
            this.jbtnNext.setBounds(new java.awt.Rectangle(55, 30, 45, 24));
            this.jbtnNext.setActionCommand(NEXT);
            this.jbtnNext.addActionListener(this);

        }
        return this.jbtnNext;
    }

    /**
     * This method initializes jsbData
     *
     * @return javax.swing.JScrollPane
     */
    private JScrollPane getJsbData() {
        if (this.jsbData == null) {
            this.jsbData = new JScrollPane();
            this.jsbData.setViewportView(this.getJtData());
        }
        return this.jsbData;
    }

    /**
     * This method initializes jtfSelectedRow
     *
     * @return javax.swing.JTextField
     */
    String preSelectedRow = "";
    private Vector<Vector<String>> bufferDataEx;

    private JTextField getJtfSelectedRow() {
        if (this.jtfSelectedRow == null) {
            this.jtfSelectedRow = new JTextField();
            this.jtfSelectedRow.setBounds(new Rectangle(104, 32, 43, 21));
            this.jtfSelectedRow.setDocument(new CheckInput(3, 11));
            this.jtfSelectedRow.setBackground(Color.YELLOW);
            this.jtfSelectedRow.addKeyListener(new java.awt.event.KeyAdapter() {

                @Override
                public void keyReleased(java.awt.event.KeyEvent e) {
                    if (!UISearch.this.preSelectedRow.equals(UISearch.this.jtfSelectedRow.getText())) {
                        final int selectedRow = Integer
                                .valueOf(Utilities.checkInt(UISearch.this.jtfSelectedRow.getText()));
                        if ((selectedRow > 0) && (selectedRow <= UISearch.this.jtData.getRowCount())) {
                            UISearch.this.jtData.setRowSelectionInterval(selectedRow - 1, selectedRow - 1);
                        } else {
                            UISearch.this.jtData.setRowSelectionInterval(0, 0);
                        }
                    }
                    UISearch.this.preSelectedRow = UISearch.this.jtfSelectedRow.getText();
                    UISearch.this.tblDataKeyPressed(e);
                }
            });
        }
        return this.jtfSelectedRow;
    }

    /**
     * This method initializes jtData
     *
     * @return javax.swing.JTable
     */
    @SuppressWarnings("serial")
    protected JTable getJtData() {
        if (this.jtData == null) {
            this.jtData = new JTable() {
                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                    final Component c = super.prepareRenderer(renderer, row, column);
                    if (!this.isRowSelected(row)) {
                        c.setBackground((row % 2) == 0 ? this.getBackground() : new Color(230, 230, 250));

                    } else {
                        c.setBackground(new Color(255, 222, 173));
                        c.setFont(new Font("Tahoma", Font.BOLD, 18));
                    }

                    final JTableHeader header = super.getTableHeader();
                    header.setFont(new Font("Tahoma", Font.BOLD, 16));

                    return c;
                }
            };
            this.jtData.setSize(new java.awt.Dimension(390, 120));
            this.jtData.addKeyListener(new java.awt.event.KeyAdapter() {

                @Override
                public void keyPressed(java.awt.event.KeyEvent e) {
                    UISearch.this.tblDataKeyPressed(e);
                    UISearch.this.getDataFromKeyboard(e);

                }
            });

            this.jtData.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
                @Override
                public void valueChanged(ListSelectionEvent arg0) {

                    if (UISearch.this.jtData.getSelectedRow() > -1) {
                        UISearch.this.displayRowTip(UISearch.this.jtData.getSelectedRow());

                    } else /**
                     * Bug #8835 Should show at least 1 KDPID in suggestion
                     */
                    if (rowTip != null) {
                        rowTip.setVisible(false);
                        rowTip = null;
                    }
                }
            });

        }
        return this.jtData;
    }

    /**
     * This method initializes jbtnSelect
     *
     * @return javax.swing.JButton
     */
    private JButton getJbtnSelect() {
        if (this.jbtnSelect == null) {
            this.jbtnSelect = new JButton();
            this.jbtnSelect.setText("Select");
            this.jbtnSelect.setMnemonic('S');
            this.jbtnSelect.setBounds(new java.awt.Rectangle(169, 30, 78, 24));
            this.jbtnSelect.setActionCommand(SELECT);
            this.jbtnSelect.addActionListener(this);
        }
        return this.jbtnSelect;
    }

    /**
     * This method initializes jbtncancel
     *
     * @return javax.swing.JButton
     */
    private JButton getJbtnCancel() {
        if (this.jbtnCancel == null) {
            this.jbtnCancel = new JButton();
            this.jbtnCancel.setText("Cancel");
            this.jbtnCancel.setMnemonic('C');
            this.jbtnCancel.setBounds(new java.awt.Rectangle(256, 30, 73, 24));
            this.jbtnCancel.setActionCommand(CANCEL);
            this.jbtnCancel.addActionListener(this);
        }
        return this.jbtnCancel;
    }

    private synchronized void goPrevious() {
        // String tmp = "0";
        this.curPage--;
        this.jlblCurrentPage.setText(String.valueOf((this.curPage + 1)));
        this.updateTable(this.curPage);
    }

    private void updateTable(int curPage) {
        this.bufferDataEx = (Vector<Vector<String>>) this.getRecords(curPage).clone();

        // Group Firma and Person
        this.bufferDataEx = this.groupKDPbyFirmaandPerson(this.bufferDataEx);

        this.dTableModel.getDataVector().clear();
        this.jtData.clearSelection();
        for (final Vector<String> tmp : this.bufferDataEx) {
            this.dTableModel.addRow(tmp);
        }
        if (this.jtData.getModel().getRowCount() != 0) {
            this.jtData.getSelectionModel().setSelectionInterval(0, 0);
        }
        for (int i = 0; i < this.jtData.getRowCount(); i++) {
            this.jtData.setValueAt(i + 1, i, 0);
        }
        this.setEnableButton();
        if (this.bufferDataEx != null) {
            final String tmp = String.valueOf(this.bufferDataEx.size()) + "/" + this.totalSize;
            this.jlblRecordsDisplayed.setText(tmp);
        }
    }

    // Added-13/06/2016: Group Firmas and Persons
    private Vector<Vector<String>> groupKDPbyFirmaandPerson(Vector<Vector<String>> bufferDataEx) {
        final Vector<Vector<String>> bufferGroupedEx = new Vector<Vector<String>>();
        final Vector<Vector<String>> bufferPersonDataEx = new Vector<Vector<String>>();

        for (final Vector<String> tmpRow : bufferDataEx) {
            final int indexOfFirmaColumn = this.tableTitleEx.indexOf(LookupKey.FIRMENNAME.getKey());
            if (indexOfFirmaColumn > -1) {
                if (!StringUtils.isBlank(tmpRow.get(indexOfFirmaColumn))) { // Check if Firma column is not blank or
                    // null, this KDP is Firma
                    bufferGroupedEx.add(tmpRow);
                } else {
                    bufferPersonDataEx.add(tmpRow);
                }
            }
        }

        bufferGroupedEx.addAll(bufferPersonDataEx);
        return bufferGroupedEx;
    }

    private synchronized void goNext() {
        this.jtData.requestFocus();
        this.curPage += 1;
        this.jlblCurrentPage.setText(String.valueOf((this.curPage + 1)));
        this.updateTable(this.curPage);
    }

    /**
     * This method initializes jpnlLabel
     *
     * @return javax.swing.JPanel
     */
    private JPanel getJpnlLabel() {
        if (this.jpnlLabel == null) {
            this.jpnlLabel = new JPanel();
            this.jpnlLabel.setLayout(null);
            this.jpnlLabel.setBounds(new java.awt.Rectangle(-2, 4, 354, 23));
            this.jlblCurrentPage = new JLabel();
            this.jlblCurrentPage.setBounds(new java.awt.Rectangle(156, 1, 17, 23));
            this.jlblCurrentPage.setText("1");
            this.jlblCurrPage = new JLabel();
            this.jlblCurrPage.setBounds(new java.awt.Rectangle(85, 1, 69, 23));
            this.jlblCurrPage.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 10));
            this.jlblCurrPage.setText("Current page");
            this.jlblRecordPerPage = new JLabel();
            this.jlblRecordPerPage.setBounds(new java.awt.Rectangle(174, 1, 108, 23));
            this.jlblRecordPerPage.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 10));
            this.jlblRecordPerPage.setText("Current records/Total");
            this.jlblRecordsDisplayed = new JLabel();
            this.jlblRecordsDisplayed.setBounds(new java.awt.Rectangle(283, 1, 48, 23));
            this.jlblRecordsDisplayed.setText("");
            this.jlblResult = new JLabel();
            this.jlblResult.setBounds(new java.awt.Rectangle(49, 1, 34, 23));
            this.jlblResult.setText("0");
            this.jlblResult.setText(String.valueOf(this.totalSize));
            this.jlblAmountRecord = new JLabel();
            this.jlblAmountRecord.setBounds(new java.awt.Rectangle(5, 1, 40, 23));
            this.jlblAmountRecord.setText("Result");
            this.jpnlLabel.add(this.jlblAmountRecord, null);
            this.jpnlLabel.add(this.jlblResult, null);
            this.jpnlLabel.add(this.jlblRecordsDisplayed, null);
            this.jpnlLabel.add(this.jlblRecordPerPage, null);
            this.jpnlLabel.add(this.jlblCurrPage, null);
            this.jpnlLabel.add(this.jlblCurrentPage, null);
        }
        return this.jpnlLabel;
    }

    /**
     * This method initializes jPanel
     *
     * @return javax.swing.JPanel
     */
    private JPanel getJPanel() {
        if (this.jpnlButton == null) {
            this.jpnlButton = new JPanel();
            this.jpnlButton.setLayout(null);
            this.jpnlButton.setPreferredSize(new java.awt.Dimension(1, 60));
            this.jpnlButton.add(this.getJbtnPrevious(), null);
            this.jpnlButton.add(this.getJbtnNext(), null);
            this.jpnlButton.add(this.getJbtnSelect(), null);
            this.jpnlButton.add(this.getJbtnCancel(), null);
            this.jpnlButton.add(this.getJpnlLabel(), null);
            this.jpnlButton.add(this.getJtfSelectedRow(), null);
        }
        return this.jpnlButton;
    }

    private void positionColumn(JTable table, int col_Index) {
        try {
            table.moveColumn(table.getColumnCount() - 1, col_Index);
        } catch (final Exception e) {
            log.error("", e);
        }

    }

    private class ModeForTable extends javax.swing.table.DefaultTableModel {

        private static final long serialVersionUID = 1L;

        public ModeForTable(Vector<Vector<String>> rows, Vector<String> headerColumns) {
            super(rows, headerColumns);
        }

        public ModeForTable() {
            super();
        }

        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    }

    public void getDataFromKeyboard(java.awt.event.KeyEvent evt) {
        switch (evt.getKeyCode()) {
            case KeyEvent.VK_1:
            case KeyEvent.VK_NUMPAD1:
                this.selectDataAddress(0);
                break;
            case KeyEvent.VK_2:
            case KeyEvent.VK_NUMPAD2:
                this.selectDataAddress(1);
                break;
            case KeyEvent.VK_3:
            case KeyEvent.VK_NUMPAD3:
                this.selectDataAddress(2);
                break;
            case KeyEvent.VK_4:
            case KeyEvent.VK_NUMPAD4:
                this.selectDataAddress(3);
                break;
            case KeyEvent.VK_5:
            case KeyEvent.VK_NUMPAD5:
                this.selectDataAddress(4);
                break;
            case KeyEvent.VK_6:
            case KeyEvent.VK_NUMPAD6:
                this.selectDataAddress(5);
                break;
            case KeyEvent.VK_7:
            case KeyEvent.VK_NUMPAD7:
                this.selectDataAddress(6);
                break;
            case KeyEvent.VK_8:
            case KeyEvent.VK_NUMPAD8:
                this.selectDataAddress(7);
                break;
            case KeyEvent.VK_9:
            case KeyEvent.VK_NUMPAD9:
                this.selectDataAddress(8);
                break;
            case KeyEvent.VK_HOME:
                this.goHome();
                break;
            case KeyEvent.VK_END:
                this.goEnd();
                break;

            case KeyEvent.VK_ESCAPE:

                // if (parentFrame.getEntity().getKdpType() != 1 &&
                // parentFrame.getEntity().getKdpType() != 2) {
                // this.parentFrame.getEntity().clearValue();
                // }
                break;
        }
    }

    private synchronized void goHome() {
        this.jtData.requestFocus();
        this.curPage = 0;
        this.jlblCurrentPage.setText(String.valueOf((this.curPage + 1)));
        this.updateTable(this.curPage);
    }

    private synchronized void goEnd() {
        this.jtData.requestFocus();
        this.curPage = this.maxPage - 1;
        this.jlblCurrentPage.setText(String.valueOf((this.curPage + 1)));
        this.updateTable(this.curPage);
    }

    // public void searchVornameSynonym(String vorname)
    // throws IllegalComponentStateException {
    // try {
    // // Open the file that is the first
    // // command line parameter
    // FileInputStream fstream = new FileInputStream(
    // ConfigInfo.VORNAME_SYNONYM_FILEPATH);
    //
    // // Get the object of DataInputStream
    // DataInputStream in = new DataInputStream(fstream);
    // BufferedReader br = new BufferedReader(new InputStreamReader(in));
    // String strLine;
    // DefaultListModel model = new DefaultListModel();
    //
    // // Read File Line By Line
    // while ((strLine = br.readLine()) != null) {
    // String[] tmp = strLine.split("\\;");
    //
    // for (int i = 0; i < tmp.length; i++) {
    // // If vorname equals any letter in synonym list
    // if (vorname.equals(tmp[i])) {
    // for (int j = 0; j < tmp.length; j++) {
    // model.addElement(tmp[j]);
    // }
    // break;
    // }
    // }
    //
    // }
    //
    // // Close the input stream
    // in.close();
    //
    // popup = new JPopupMenu();
    // JList jList = new JList();
    // jList.setModel(model);
    // popup.add(jList);
    // popup.setFocusable(false);
    //
    // if (model.size() > 0) {
    // // System.out.println("Show Popup");
    // popup.show(jtData, 190, -185);
    // } else {
    // // System.out.println("Disable Popup");
    // popup.show(jtData, 0, 100);
    // }
    //
    // } catch (Exception e) {
    // log.warn("", e);
    // }
    //
    // }
    private class ColorColumnRenderer extends DefaultTableCellRenderer {

        private static final long serialVersionUID = 3808450006624702167L;
        Color fgndColor;
        Font font;
        Color bgColor;

        public ColorColumnRenderer(Color foregnd, Font f, Color bg) {
            super();
            this.fgndColor = foregnd;
            this.font = f;
            this.bgColor = bg;
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
                int row, int column) {
            final Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            cell.setForeground(this.fgndColor);
            cell.setFont(this.font);
            final TableModel model = table.getModel();
            int vnameAliasColumn = 0;
            int kdpAliasColumn = 0;
            final int columnCount = model.getColumnCount();
            for (int i = 0; i < columnCount; i++) {
                if (model.getColumnName(i).equals(LookupKey.VNAME_ALIAS.getHeader())) {
                    vnameAliasColumn = i;
                }
                if (model.getColumnName(i).equals(LookupKey.IS_KDP_ALIAS.getHeader())) {
                    kdpAliasColumn = i;
                }
            }
            final String isAlias = (String) table.getModel().getValueAt(row, vnameAliasColumn);
            final String kdpAlias = (String) table.getModel().getValueAt(row, kdpAliasColumn);
            if (isAlias.equalsIgnoreCase("true")) {
                cell.setForeground(UISearch.this.nameAliasColor);
            }
            if (kdpAlias.equalsIgnoreCase("true")) {
                cell.setForeground(Color.BLUE);
            }
            return cell;
        }
    }

    public void keyBind() {

        // Create Action Search_key
        // Ctrl + F 2nd
        final ActionMap am = this.jtData.getActionMap();
        am.put("Search_KDP_Ctrl_F", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log.debug("action find next kdp");

                final CaptureMessage message = CaptureMessage.intance();
                message.clearData();
                message.setAction(StateCapture.FIND_NEXT_KDP);

                UISearch.this.parentFrame.request(message, UISearch.this.parentFrame);
                UISearch.this.sleepWhenClose();
                destroy();
            }
        });
        final KeyStroke key = KeyStroke.getKeyStroke(KeyEvent.VK_F, Event.CTRL_MASK);
        final InputMap im = this.jtData.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        im.put(key, "Search_KDP_Ctrl_F");
    }

    private static BalloonTip rowTip = null;

    protected void displayRowTip(int rowIndex) {

        if ((this.jtData.getColumnCount() > 10) && (this.jtData.getRowCount() > 0)) {

            // pvgiang_1 -28/07/2016- Using html to display balloon tooltip. Remove Postfach on tooltip
            int FIRMEN_NAME = 1;
            int VORNAME = 2;
            int NAME = 3;
            int ANREDE = 4;
            int NAMENSZUSATZ = 5;
            int PLZ = 6;
            int ORT = 7;
            int STRASSE = 8;
            int HAUS = 9;
            int IS_POSTFACH = 10;
            int MYPOST24 = 11;
            int PICKPOST = 12;
            // int NAME_SET = 31;
            int VNAME_SET = 31;
            int VNAME_ALIAS = 32;
            int KDP_ALIAS = 34;
            int IS_KDP_ALIAS = 35;
            final int columnCount = this.jtData.getColumnCount();
            // get index of column
            for (int i = 0; i < columnCount; i++) {
                if (this.jtData.getColumnName(i).equals(LookupKey.FIRMENNAME.getHeader())) {
                    FIRMEN_NAME = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.VORNAME.getHeader())) {
                    VORNAME = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.NAME.getHeader())) {
                    NAME = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.NAMENSZUSATZ.getHeader())) {
                    NAMENSZUSATZ = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.PLZ.getHeader())) {
                    PLZ = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.ORT.getHeader())) {
                    ORT = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.STRASSE.getHeader())) {
                    STRASSE = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.FULLHAUSNUMMER.getHeader())) {
                    HAUS = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.IS_POSTFACH.getHeader())) {
                    IS_POSTFACH = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.ANREDE.getHeader())) {
                    ANREDE = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.MY_POST_24.getHeader())) {
                    MYPOST24 = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.PICKPOST.getHeader())) {
                    PICKPOST = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.VNAME_SET.getHeader())) {
                    VNAME_SET = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.VNAME_ALIAS.getHeader())) {
                    VNAME_ALIAS = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.KDP_ALIAS.getHeader())) {
                    KDP_ALIAS = i;
                }
                if (this.jtData.getColumnName(i).equals(LookupKey.IS_KDP_ALIAS.getHeader())) {
                    IS_KDP_ALIAS = i;
                }
            }

            if (rowTip != null) {
                rowTip.setVisible(false);
            }

            final JPanel pnlTip = new JPanel();
            pnlTip.setBackground(Color.WHITE);

            final BorderLayout layout = new BorderLayout();
            pnlTip.setLayout(layout);

            final JTextPane pane = new JTextPane();

            final StringBuilder tooltipStringBuilder = new StringBuilder();
            tooltipStringBuilder.append("<html>");

            // Firmenname
            final Object firmenname = this.jtData.getValueAt(rowIndex, FIRMEN_NAME);
            if ((firmenname != null) && (firmenname.toString().length() > 0)) {
                // this.appendToPane(pane, firmenname.toString() + "\n", Color.BLACK);
                tooltipStringBuilder.append(firmenname.toString()).append("<br/>");
            }

            // is_alias
            final Object alias = this.jtData.getValueAt(rowIndex, VNAME_ALIAS);
            boolean isAlias = false;
            if ((alias != null) && (alias.toString().length() > 0)) {
                isAlias = Boolean.parseBoolean(alias.toString().trim());
            }

            /**
             * * IS-ALIAS **
             */
            if (isAlias) {
                // vname_set
                final Object vname_set = this.jtData.getValueAt(rowIndex, VNAME_SET);
                if ((vname_set != null) && (vname_set.toString().length() > 0)) {
                    // final List<String> arrAlias = Arrays.asList(vname_set.toString().split(Pattern.quote("|")));
                    //
                    // final StringBuilder builder = new StringBuilder();
                    // StringBuilder limitChar = new StringBuilder();
                    //
                    // final String separator = System.getProperty("line.separator");
                    //
                    // for (final String item : arrAlias) {
                    // // Verify length too long
                    // limitChar.append(item).append("|");
                    //
                    // if (limitChar.toString().length() < 50) {
                    // builder.append(item).append("|");
                    // } else {
                    // // reset limit
                    // limitChar = new StringBuilder();
                    // limitChar.append(item).append("|");
                    //
                    // builder.append(separator).append(item).append("|");
                    // }
                    // }
                    //
                    // String strVNameSet = builder.replace(builder.length() - 1, builder.length(),
                    // "").toString().replace("|" + separator, separator);
                    //
                    // // Remove '|' appear in the first
                    // if (strVNameSet.indexOf("|") == 0) {
                    // strVNameSet = strVNameSet.substring(1, strVNameSet.length());
                    // }
                    //
                    // this.appendToPane(pane, strVNameSet + "\n", this.nameAliasColor);
                    tooltipStringBuilder.append("<span style='color:#8B0000'>");
                    tooltipStringBuilder.append(vname_set.toString());
                    tooltipStringBuilder.append("</span>").append("<br/>");
                }
            }

            final String lookup = this.parentFrame.getFieldValue(MainFieldInterface.LOOKUP);
            final String is_kdp_alias = (String) this.jtData.getValueAt(rowIndex, IS_KDP_ALIAS);

            if ("true".equalsIgnoreCase(is_kdp_alias)) {
                // kdp_alias
                final String kdp_alias = (String) this.jtData.getValueAt(rowIndex, KDP_ALIAS);
                final String tmpKdp_alias = kdp_alias.replace(lookup.toLowerCase(),
                        "<span style='color:#8B0000'>" + lookup.toLowerCase() + "</span>");
                // final List<String> arrAlias = Arrays.asList(kdp_alias.toString().split(Pattern.quote("|")));
                //
                // final StringBuilder builder = new StringBuilder();
                // StringBuilder limitChar = new StringBuilder();
                //
                // final String separator = System.getProperty("line.separator");
                //
                // for (final String item : arrAlias) {
                // // Verify length too long
                // limitChar.append(item).append("|");
                //
                // if (limitChar.toString().length() < 50) {
                // builder.append(item).append("|");
                // } else {
                // // reset limit
                // limitChar = new StringBuilder();
                // limitChar.append(item).append("|");
                //
                // builder.append(separator).append(item).append("|");
                // }
                // }
                //
                // String strKDPAlias = builder.replace(builder.length() - 1, builder.length(),
                // "").toString().replace("|" + separator, separator);
                //
                // // Remove '|' appear in the first
                // if (strKDPAlias.indexOf("|") == 0) {
                // strKDPAlias = strKDPAlias.substring(1, strKDPAlias.length());
                // }
                // this.appendKdpAliasToTooltip(pane, lookup, strKDPAlias);
                // this.appendToPane(pane, "\n", Color.BLUE);

                tooltipStringBuilder.append("<span style='color:#0000CD'>");
                tooltipStringBuilder.append(tmpKdp_alias.toString());
                tooltipStringBuilder.append("</span>").append("<br/>");
            }
            /**
             * * <<END>> IS-ALIAS **
             */

            // namenszusatz
            final Object namenszusatz = this.jtData.getValueAt(rowIndex, NAMENSZUSATZ);
            if ((namenszusatz != null) && (namenszusatz.toString().length() > 0)) {
                // this.appendToPane(pane, namenszusatz.toString() + "\n", Color.BLACK);
                tooltipStringBuilder.append(namenszusatz.toString()).append("<br/>");
            }

            // anrede
            final Object anredeObj = this.jtData.getValueAt(rowIndex, ANREDE);

            // vorname
            final Object vorname = this.jtData.getValueAt(rowIndex, VORNAME);
            if ((vorname != null) && (vorname.toString().length() > 0)) {
                // if (!anredeObj.toString().isEmpty()) {
                // this.appendToPane(pane, anredeObj.toString(), Color.BLACK);
                // this.appendToPane(pane, "\n", Color.BLACK);
                // }
                // this.appendToPane(pane, vorname.toString() + " ", Color.BLACK);

                tooltipStringBuilder.append(anredeObj.toString()).append("<br/>");
                tooltipStringBuilder.append(vorname.toString()).append(" ");
            }

            // name
            final Object name = this.jtData.getValueAt(rowIndex, NAME);
            if ((name != null) && (name.toString().length() > 0)) {
                // if (!anredeObj.toString().isEmpty() && ((vorname == null) || vorname.toString().isEmpty())) {
                // this.appendToPane(pane, anredeObj.toString(), Color.BLACK);
                // this.appendToPane(pane, "\n", Color.BLACK);
                // }
                // this.appendToPane(pane, name.toString(), Color.BLACK);
                tooltipStringBuilder.append(name.toString()).append("<br/>");
            }

            /**
             * * Break line
             */
            // if (((vorname != null) && (vorname.toString().length() > 0)) || ((name != null) &&
            // (name.toString().length() > 0))) {
            // this.appendToPane(pane, "\n", Color.BLACK);
            // }
            // MyPost24
            final Object mypost24 = this.jtData.getValueAt(rowIndex, MYPOST24);
            if ((mypost24 != null) && (mypost24.toString().length() > 0)) {
                final String strMyPost24 = this.jtData.getColumnName(MYPOST24) + " - " + mypost24.toString();
                // this.appendToPane(pane, strMyPost24, Color.BLACK);
                // this.appendToPane(pane, "\n", Color.BLACK);
                tooltipStringBuilder.append(strMyPost24.toString()).append("<br/>");
            }

            // Postfach
            final Object postfach = this.jtData.getValueAt(rowIndex, IS_POSTFACH);
            if ((postfach != null) && (postfach.toString().toLowerCase().equalsIgnoreCase("x"))) {
                // this.appendToPane(pane, "Postfach " + postfach.toString() + "\n", Color.BLACK);
                tooltipStringBuilder.append("<i style='color:#0000CD'>Postfach</i>").append("<br/>");
            } else {
                // Strasse
                final Object strasse = this.jtData.getValueAt(rowIndex, STRASSE);
                if ((strasse != null) && (strasse.toString().length() > 0)) {
                    // this.appendToPane(pane, strasse.toString() + " ", Color.BLACK);
                    tooltipStringBuilder.append(strasse.toString()).append(" ");
                }

                // Haus
                final Object haus = this.jtData.getValueAt(rowIndex, HAUS);
                if ((haus != null) && (haus.toString().length() > 0)) {
                    // this.appendToPane(pane, haus.toString(), Color.BLACK);
                    tooltipStringBuilder.append(haus.toString()).append("<br/>");
                } else {
                    tooltipStringBuilder.append("<br/>");
                }
            }

            /**
             * * Break line
             */
            // (postfach != null) && (postfach.toString().trim().length() > 0))
            // if (((strasse != null) && (strasse.toString().length() > 0)) || ((haus != null) &&
            // (haus.toString().length() > 0))) {
            // this.appendToPane(pane, "\n", Color.BLACK);
            // }
            // PLZ
            final Object plz = this.jtData.getValueAt(rowIndex, PLZ);
            if ((plz != null) && (plz.toString().length() < 3)) {
                // this.appendToPane(pane, plz.toString() + " ", Color.BLACK);
                tooltipStringBuilder.append(plz.toString()).append(" ");
            } else if ((plz != null) && (plz.toString().length() >= 4)) {
                // this.appendToPane(pane, plz.toString().substring(0, 4) + " ", Color.BLACK);
                tooltipStringBuilder.append(plz.toString().substring(0, 4)).append(" ");
            }

            // Ort
            final Object ort = this.jtData.getValueAt(rowIndex, ORT);
            if ((ort != null) && (ort.toString().length() > 0)) {
                // this.appendToPane(pane, ort.toString(), Color.BLACK);
                tooltipStringBuilder.append(ort.toString()).append("<br/>");
            }

            /**
             * * Break line
             */
            // if (((plz != null) && (plz.toString().length() > 4)) || ((ort != null) && (ort.toString().length() > 0)))
            // {
            // this.appendToPane(pane, "\n", Color.BLACK);
            // }
            // Pickpost
            final Object pickpost = this.jtData.getValueAt(rowIndex, PICKPOST);

            if ((pickpost != null) && (pickpost.toString().length() > 0)) {
                final String strPickpost = this.jtData.getColumnName(PICKPOST) + " - " + pickpost.toString();
                // this.appendToPane(pane, strPickpost, Color.BLACK);
                tooltipStringBuilder.append(strPickpost.toString());
            }

            // pnlTip.add(pane);
            tooltipStringBuilder.append("</html>");

            final JLabel label = new JLabel(this.wrapTextIgnoreHtml(tooltipStringBuilder.toString(), 48));
            label.setFont(new Font(label.getFont().getName(), label.getFont().getStyle(), 20));

            rowTip = new BalloonTip((JComponent) this.parentFrame.getComponent(MainFieldInterface.IMAGE_VIEW), label,
                    this.createBalloonTipStyle(), BalloonTip.Orientation.RIGHT_BELOW,
                    BalloonTip.AttachLocation.NORTHWEST, 0, 0, false);

            if (rowTip.getX() < 0) {
                rowTip.setLocation(0, rowTip.getY());
            }

            if (rowTip.getY() < 0) {
                rowTip.setLocation(rowTip.getX(), rowTip.getParent().getY());
            }
        }
    }

    private String wrapTextIgnoreHtml(String str, int limit) {
        final StringBuilder stringBuilder = new StringBuilder();
        final String brRegex = "<br/>";
        final String htmlRegex = "<[^>]*[/]?>";
        final Pattern pattern = Pattern.compile(htmlRegex);

        final String[] arrText = str.split(brRegex);

        if (arrText.length > 0) {
            int i = 0;
            while (i < arrText.length) {
                final String tmp = arrText[i];

                final String tmpClearedHtml = tmp.replaceAll(htmlRegex, "");
                if (tmpClearedHtml.length() > limit) {
                    /*
					 * 1.Put all html tag into array. 2.Replace each html tag with its index. 3.Do wrap a text.
					 * 4.Convert index to a html.
                     */
                    final Map<Integer, String> mapHtmlTag = new HashMap<Integer, String>();
                    String replacedTmp = tmp;

                    final Matcher matcher = pattern.matcher(tmp);

                    int index = 0;
                    // STEP-1
                    while (matcher.find()) {
                        final int start = matcher.start();
                        final int end = matcher.end();
                        final String htmlTag = tmp.substring(start, end);

                        mapHtmlTag.put(index, htmlTag);

                        index++;
                    }
                    // STEP-2
                    int m_i = mapHtmlTag.size() - 1;
                    while (m_i > -1) {
                        final String htmlTag = mapHtmlTag.get(m_i);
                        replacedTmp = replacedTmp.replaceFirst(htmlTag, ":" + m_i + ":");

                        m_i--;
                    }
                    // STEP-3
                    if (replacedTmp.length() > limit) {
                        int tmpIndex = 0;
                        while (tmpIndex < (replacedTmp.length() - limit)) {
                            final String temp = replacedTmp.substring(tmpIndex, tmpIndex + limit);

                            final int lastSpaceIndex = temp.lastIndexOf(" ");
                            final int lastCommaIndex = temp.lastIndexOf("|");

                            if (lastSpaceIndex >= lastCommaIndex) {
                                if (lastSpaceIndex > 0) {
                                    replacedTmp = replacedTmp.substring(0, tmpIndex + lastSpaceIndex) + "\n"
                                            + replacedTmp.substring(tmpIndex + lastSpaceIndex + 1);
                                    tmpIndex += lastSpaceIndex;
                                } else {
                                    tmpIndex += limit;
                                }
                            } else if (lastCommaIndex > 0) {
                                replacedTmp = replacedTmp.substring(0, tmpIndex + lastCommaIndex) + "|\n"
                                        + replacedTmp.substring(tmpIndex + lastCommaIndex + 1);
                                tmpIndex += lastCommaIndex;
                            } else {
                                tmpIndex += limit;
                            }
                        }
                    }
                    // STEP-4
                    m_i = mapHtmlTag.size() - 1;
                    while (m_i > -1) {
                        final String htmlTag = mapHtmlTag.get(m_i);
                        replacedTmp = replacedTmp.replace(":" + m_i + ":", htmlTag);

                        m_i--;
                    }
                    stringBuilder.append(replacedTmp).append("<br/>");
                } else {
                    stringBuilder.append(tmp).append("<br/>");
                }
                // System.out.println("----");
                i++;
            }
            return stringBuilder.toString().replaceAll("\n", "<br/>");
            // System.out.println(str);
        } else {
            return str;
        }
    }

    private void appendKdpAliasToTooltip(JTextPane tp, String lookup, String kdpAlias) {

        final boolean isContain = lookup.trim().startsWith("%");
        final String patternRegrex = isContain ? "%s" : "\\b%s";
        final String lookup_translate = LookupServiceImpl.translateForDisplay(lookup).replace(" ", "|");
        final String[] lookups = lookup_translate.split(" ");
        final Map<Integer, Integer> indexes = new HashMap<Integer, Integer>();
        for (final String lk : lookups) {
            final Pattern pattern = Pattern.compile(String.format(patternRegrex, lk), Pattern.CASE_INSENSITIVE);
            final Matcher matcher = pattern.matcher(kdpAlias);
            while (matcher.find()) {
                final int from = matcher.start();
                final int to = matcher.end();
                if (!indexes.containsKey(from) || (indexes.containsKey(from) && (indexes.get(from) < to))) {
                    indexes.put(from, to);
                }
            }
        }

        final List<Integer> froms = new ArrayList<Integer>(indexes.keySet());
        Collections.sort(froms);
        final Iterator<Integer> it = froms.iterator();
        final int sizeStr = kdpAlias.length();

        for (int i = 0; i < sizeStr;) {
            if (it.hasNext()) {
                final int from = it.next();
                final int to = indexes.get(from);

                this.appendToPane(tp, kdpAlias.substring(i, from), Color.BLUE);
                this.appendToPane(tp, "\n", Color.BLUE);
                this.appendToPane(tp, kdpAlias.substring(from, to), this.nameAliasColor);
                i = to;
            } else {
                this.appendToPane(tp, kdpAlias.substring(i, sizeStr), Color.BLUE);
                break;
            }
        }
    }

    protected BalloonTipStyle createBalloonTipStyle() {
        return new EdgedBalloonStyle(Color.white, Color.blue);
    }

    private void appendToPane(JTextPane tp, String msg, Color c) {
        final StyleContext sc = StyleContext.getDefaultStyleContext();

        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);
        aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Tahoma");
        aset = sc.addAttribute(aset, StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED);
        aset = sc.addAttribute(aset, StyleConstants.FontSize, 18);
        aset = sc.addAttribute(aset, StyleConstants.Bold, false);

        final int len = tp.getDocument().getLength();
        tp.setCaretPosition(len);
        tp.setCharacterAttributes(aset, false);

        if (msg.length() > 35) {
            msg = this.wrapText(msg, 35);
        }

        tp.replaceSelection(msg);
    }

    // Added-09/06/2016: Use to wrap text when size of text over limit
    private String wrapText(String text, int limit) {

        int i = 0;

        while (i < (text.length() - limit)) {
            final String temp = text.substring(i, i + limit);
            final int lastSpaceIndex = temp.lastIndexOf(" ");
            final int lastCommaIndex = temp.lastIndexOf(",");

            if (lastSpaceIndex >= lastCommaIndex) {
                if (lastSpaceIndex > 0) {
                    text = text.substring(0, i + lastSpaceIndex) + "\n" + text.substring(i + lastSpaceIndex + 1);
                }
            } else if (lastCommaIndex > 0) {
                text = text.substring(0, i + lastCommaIndex) + ",\n" + text.substring(i + lastCommaIndex + 1);
            }

            i += limit;
        }

        return text;
    }

    private void checkInterrupted(String message) throws InterruptedException {
        if (Thread.interrupted()) {
            throw new InterruptedException(message);
        }
    }

    private static String PREVIOUS = "previous";
    private static String NEXT = "next";
    private static String SELECT = "select";
    private static String CANCEL = "cancel";

    @Override
    public void actionPerformed(ActionEvent e) {
        final String command = e.getActionCommand();
        if (command.equals(PREVIOUS)) {
            this.goPrevious();
        } else if (command.equals(NEXT)) {
            this.goNext();
        } else if (command.equals(SELECT)) {
            this.btnSelectActionPerformed(e);
        } else if (command.equals(CANCEL)) {
            this.btnCancelActionPerformed(e);
        }
    }

    private void changeLocationAndSize() {
        final Frame frame = JOptionPane.getRootFrame();
        if (this.searchType == searchKDP) {
            final int pointX = frame.getLocation().x;
            this.setBounds(pointX, ((this.screen_leny * 2) / 3) - 80, this.screen_lenx,
                    ((((this.screen_leny + 200) / 3) - (this.screen_leny / 20)) + 15));
        } else if (this.searchType == searchStrasse) {
            this.setSize(this.screen_lenx / 2, ((this.screen_leny / 3) - (this.screen_leny / 20)) + 15);
            this.setLocationRelativeTo(frame);
        } else {
            this.setSize(this.screen_lenx / 3, ((this.screen_leny / 3) - (this.screen_leny / 20)) + 15);
            this.setLocationRelativeTo(frame);
        }
    }

    private class WindowExcute extends WindowAdapter {

        @Override
        public void windowOpened(WindowEvent e) {
            if (UISearch.this.searchType == searchKDP) {
                UISearch.this.displayRowTip(0);
            }
        }

        @Override
        public void windowClosed(WindowEvent e) {
            UISearch.this.removeEvent();

            if (rowTip != null) {
                rowTip.setVisible(false);
            }

            if (UISearch.this.searchKDP()) {
                log.info("Event close search ui");
                final CaptureMessage information = CaptureMessage.intance();
                information.clearData();
                information.setAction(StateCapture.SEARCH_GUI_CLOSE);

                UISearch.this.parentFrame.request(information, UISearch.this.parentFrame);
            }
        }
    }

    private void selectDataAddress(int index) {
        this.setData2AddressInfo(index);
        this.sleepWhenClose();
        destroy();
    }

    private void sleepWhenClose() {
        this.sleepWhenClose(100);

    }

    private void sleepWhenClose(int timeSleep) {
        try {
            Thread.sleep(timeSleep);
        } catch (final InterruptedException ie) {
            log.warn("", ie);
        }
    }

    public static UISearch intance() {
        if (search == null) {
            System.out.println("----- new -----");
            search = new UISearch();
        }
        return search;
    }

    public static boolean isExisted() {
        System.out.println("search >>> " + search);
        return search != null;
    }

    static UISearch search;

    public static UISearch intance(JFrame parent, boolean displayOnlySpecial) {
        if (search == null) {
            System.out.println(" *** UISearch intance *** ");
            search = new UISearch(parent);

            if (displayOnlySpecial) {
                bgColor = new Color(0xBAEDBA);
            } else {
                bgColor = Color.WHITE;
            }
        }
        return search;
    }

    public void setCurrentJtf(JTextField currentField) {
        this.curJtf = currentField;
    }

    public void setNextFocus(JTextField nextFocus) {
        this.nextFocusComp = nextFocus;
    }

    public void setDataResult(List<Map<String, String>> data) {
        this.dataArr = data;
    }

    public void setParentMainFace(MainFieldInterface parent) {
        this.parentFrame = parent;
    }

    public void setTitle(LookupKey[] title) {
        this.title = title;
    }

    public void setSearchType(int searchType) {
        this.searchType = searchType;
    }

}
