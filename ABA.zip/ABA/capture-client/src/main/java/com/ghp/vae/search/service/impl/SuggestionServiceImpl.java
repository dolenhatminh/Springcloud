/*
 * Class: SuggestionServiceImpl
 *
 * Created on Mar 30, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package com.ghp.vae.search.service.impl;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import org.apache.commons.lang3.text.WordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.ptl.state.AroundDialog;
import com.ghp.vae.search.service.ISuggestionService;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sps.vn.config.ApplicationConfig;


/**
 * @author tvbinh
 *
 */
public class SuggestionServiceImpl extends AbstractLookupProxyService implements ISuggestionService {
    /** The log. */
    private static Logger log = LoggerFactory.getLogger(SuggestionServiceImpl.class);
    
    /** The Constant PARAM_TYPE. */
    private static final String PARAM_TYPE = "type";

    /** The Constant PARAM_FIELD_NAME. */
    private static final String PARAM_FIELD_NAME = "fieldName";
    
    /** The Constant PARAM_TERM. */
    private static final String PARAM_TERM = "term";
    
    /** The Constant PARAM_STR_VN. */
    private static final String PARAM_STR_VN = "strVN";
    
    /** The Constant PARAM_STR_NN. */
    private static final String PARAM_STR_NN = "strNN";
    
    /** The Constant PARAM_STR_IPERCENT. */
    private static final String PARAM_IPERCENT = "iPercent";
    
    /** The Constant PARAM_VALUE. */
    // private static final String PARAM_VALUE = "value";
    
    public List<Map<String, String>> getSuggestion(String indexType, String fieldName, String term) {
	List<Map<String, String>> rows = new ArrayList<Map<String, String>>();
	term = processdata(term);
	log.info("getSuggestion###" + indexType + "####" + fieldName + "####" + term);

	try {
		String remoteUrl = ApplicationConfig.getInstance().getLookupConfig()
				.getKdpSuggestionRestService();
		Map<String, String> params = new HashMap<String, String>();
		params.put(PARAM_TYPE, indexType);
		params.put(PARAM_FIELD_NAME, fieldName);
		params.put(PARAM_TERM, term);
		String res = this.callRemote(params, remoteUrl);
		JsonParser parser = new JsonParser();
		JsonArray hits = parser.parse(res).getAsJsonArray();
		
		for(JsonElement jsonElement : hits) {
			Map<String, String> row = new HashMap<String, String>();
			JsonObject jsonObj = (JsonObject) jsonElement;
			row.put(fieldName,
					getValidValue(jsonObj.get(fieldName)));
			rows.add(row);
		}
	} catch (final Exception e) {
		log.error("", e);
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				AroundDialog.showMessageDialog(null,
						WordUtils.wrap(Utilities.getStackTrace(e), 100),
						"Canh bao", JOptionPane.WARNING_MESSAGE);
			}
		});
	}
	return rows;
}
    

public boolean checkSwapCondition(String strVN, String strNN, int iPercent) {
	boolean result = false;
	List<Map<String, String>> rows = new ArrayList<Map<String, String>>();
	log.info("checkSwapCondition strVN:###" + strVN + "####strNN:" + strNN + "####iPercent:" + iPercent);

	try {
		String remoteUrl = ApplicationConfig.getInstance()
				.getLookupConfig().getKdpCheckSwapConditionRestService();
		Map<String, String> params = new HashMap<String, String>();
		params.put(PARAM_STR_VN, strVN);
		params.put(PARAM_STR_NN, strNN);
		params.put(PARAM_IPERCENT, String.valueOf(iPercent));
		String res = this.callRemote(params, remoteUrl);
		
		result = Boolean.valueOf(res);
	} catch (final Exception e) {
		log.error("", e);
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				AroundDialog.showMessageDialog(null,
						WordUtils.wrap(Utilities.getStackTrace(e), 100),
						"Canh bao", JOptionPane.WARNING_MESSAGE);
			}
		});
	}
	return result;
}
// CI123: PRESS F9
public String checkMoveCondition(String indexType, String value) {
	// List<Map<String, String>> rows = new ArrayList<Map<String, String>>();
	String res = "";
	String fieldName = "";
	if (indexType == LookupServiceImpl.INDEX_VORNAMEMORE_TYPE) {
		fieldName  = LookupServiceImpl.SEARCHMORE_KEYS.get(LookupServiceImpl.INDEX_VORNAME_TYPE);
	} else {
		fieldName = LookupServiceImpl.SEARCHMORE_KEYS.get(LookupServiceImpl.INDEX_TYPE_NAME);
	}
	
	log.info("checkMoveCondition index:#### " + indexType + "#### fieldName: " + fieldName + "#### value: " + value);
	try {
		String remoteUrl = ApplicationConfig.getInstance().getLookupConfig()
				.getKdpSuggestionRestService();
		Map<String, String> params = new HashMap<String, String>();
		params.put(PARAM_TYPE, indexType);
		params.put(PARAM_FIELD_NAME, fieldName);
		params.put(PARAM_TERM, value);
		res = this.callRemote(params, remoteUrl);
//		JsonParser parser = new JsonParser();
//		JsonArray hits = parser.parse(res).getAsJsonArray();
//		
//		for(JsonElement jsonElement : hits) {
//			Map<String, String> row = new HashMap<String, String>();
//			JsonObject jsonObj = (JsonObject) jsonElement;
//			row.put(fieldName,
//					getValidValue(jsonObj.get(fieldName)));
//			rows.add(row);
//		}
//	try {
//		String remoteUrl = ApplicationConfig.getInstance().getLookupConfig().getCheckMoveConditionRestService();
//		Map<String, String> params = new HashMap<String, String>();
//		params.put(PARAM_TYPE, indexType);
//		params.put(PARAM_VALUE, value);
//		String res = this.callRemote(params, remoteUrl);
//		if (!res.isEmpty()) {
//			JsonParser parser = new JsonParser();
//			JsonArray hits = parser.parse(res).getAsJsonArray();
//			for(JsonElement jsonElement : hits) {
//				Map<String, String> row = new HashMap<String, String>();
//				JsonObject jsonObj = (JsonObject) jsonElement;
//				row.put(indexType, getValidValue(jsonObj.get("name")));
//				rows.add(row);
//			}
//		}
	} catch (final Exception e) {
		log.error("", e);
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				AroundDialog.showMessageDialog(null,
						WordUtils.wrap(Utilities.getStackTrace(e), 100),
						"Canh bao", JOptionPane.WARNING_MESSAGE);
			}
		});
	}
	return res;
}
}
