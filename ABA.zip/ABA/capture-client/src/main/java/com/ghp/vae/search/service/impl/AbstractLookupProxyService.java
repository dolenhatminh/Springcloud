/*
 * Class: AbstractLookupProxyService Created on Mar 8, 2016 (c) Swiss Post Solutions Vietnam, unpublished work All use,
 * disclosure, and/or reproduction of this material is prohibited unless authorized in writing. All Rights Reserved.
 * Rights in this program belong to: Swiss Post Solutions Vietnam. Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package com.ghp.vae.search.service.impl;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.search.service.ILookupProxyService;
import com.google.gson.JsonElement;
import com.sps.vn.config.ApplicationConfig;

import vae.client.transfer.HttpClientFailover;
import vae.client.transfer.JsonUtils;

/**
 * The Class AbstractLookupProxyService.
 */
public abstract class AbstractLookupProxyService implements ILookupProxyService {

	/**
	 * The log.
	 */
	private static Logger log = LoggerFactory.getLogger(AbstractLookupProxyService.class);

	/**
	 * {@inheritDoc}
	 *
	 * @see com.ghp.vae.search.service.ILookupProxyService#normalize(java.lang.String)
	 */
	@Override
	public String normalize(final String string) {
		String ret = string;

		if ((string != null) && !string.isEmpty()) {
			final String vaeUtilNormalizeServiceUrl = ApplicationConfig.getInstance().getLookupConfig()
					.getVaeUtilNormalize();

			try {
				final URI uri = new URIBuilder(vaeUtilNormalizeServiceUrl)
						.addParameter("string", JsonUtils.object2Json(string)).build();
				final HttpUriRequest request = new HttpGet(uri);
				log.debug("Translating string [" + string + "] for ASCII characters...");
				// final String response = HTTPUtils.doGET(request, 1000, 1);
				final String response = HttpClientFailover.intance().doGET(request,
						ApplicationConfig.getInstance().getLookupConfig().getHosts(),
						ApplicationConfig.getInstance().getLookupConfig().getDelay(),
						ApplicationConfig.getInstance().getLookupConfig().getRetryTimes());
				if ((response != null) && !response.isEmpty()) {
					ret = response;
					log.debug("Translated to: " + ret);
				}
			} catch (final URISyntaxException e) {
				log.error("Invalid service URI: " + vaeUtilNormalizeServiceUrl, e);
			} catch (final Exception e) {
				log.error("Failed to translate the string [" + string + "]", e);
			}
		}

		return ret;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String processdata(String value) {
		if (value == null || value.equals("")) {
			return "";
		} else {
			String newValue = value.toLowerCase();
			String tmp = "";
			for (final char c : newValue.toCharArray()) {
				if (c == '+') {
					tmp += "\\+";
				} else {
					tmp += c;
				}
				newValue = tmp;
			}
			// newValue = newValue.replace("'", "\\'");
			if (newValue.indexOf(';') != newValue.length() - 1) {
				newValue = newValue + "%";
			} else {
				newValue = newValue.substring(0, newValue.length() - 1);
			}
			log.debug("\nvalue:" + value + "\nnew value:" + newValue);
			return newValue;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String callRemote(Map<String, String> params, String remoteUrl) throws Exception {
		final URIBuilder uriBuilder = new URIBuilder(remoteUrl);
		for (final Map.Entry<String, String> param : params.entrySet()) {
			uriBuilder.addParameter(param.getKey(), param.getValue());
		}
		final HttpUriRequest request = new HttpGet(uriBuilder.build());
		// String response = HTTPUtils.doGET(request, 1000, 1);
		final String response = HttpClientFailover.intance().doGET(request,
				ApplicationConfig.getInstance().getLookupConfig().getHosts(),
				ApplicationConfig.getInstance().getLookupConfig().getDelay(),
				ApplicationConfig.getInstance().getLookupConfig().getRetryTimes());
		return response;
	}

	@Override
	public String callPostRemote(Map<String, String> params, String remoteUrl) throws Exception {
		final URIBuilder uriBuilder = new URIBuilder(remoteUrl);
		for (final Map.Entry<String, String> param : params.entrySet()) {
			uriBuilder.addParameter(param.getKey(), param.getValue());
		}
		final HttpUriRequest request = new HttpPost(uriBuilder.build());
		final String response = HttpClientFailover.intance().doGET(request,
				ApplicationConfig.getInstance().getLookupConfig().getHosts(),
				ApplicationConfig.getInstance().getLookupConfig().getDelay(),
				ApplicationConfig.getInstance().getLookupConfig().getRetryTimes());
		return response;
	}

	protected String getValidValue(JsonElement el) {
		String value = "";
		if (el != null && !el.isJsonNull()) {
			if (el.isJsonArray()) {
				final List<String> values = new ArrayList<String>();
				for (final JsonElement a : el.getAsJsonArray()) {
					values.add(a.getAsString().replace(",", "|"));
				}
				value = StringUtils.join(values, "|");
			} else {
				value = el.getAsString();
			}
		}
		return value;
	}
}
