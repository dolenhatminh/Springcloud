package com.ghp.vae.data_entry.ptl.state;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class AroundDialog {
	private static Logger log = LoggerFactory.getLogger(AroundDialog.class);
	
	
	 public static void showMessageDialog(Component parent,String message, String title,int type ){
		 final JOptionPane pane = new JOptionPane(message, type);
		 final JDialog dialog = pane.createDialog(title);
	        PropertyChangeListener[] listeners = pane.getPropertyChangeListeners();        
	        for(PropertyChangeListener property :listeners ){
	            if(property.getClass().getName().contains("javax.swing.JOptionPane")){
	                pane.removePropertyChangeListener(property);
	            }
	        }
	        
	        final long time =System.currentTimeMillis();
	        pane.addPropertyChangeListener(new PropertyChangeListener() {
	            public void propertyChange(PropertyChangeEvent event) {
	                if (dialog.isVisible() && event.getSource() == pane &&(event.getPropertyName().equals(JOptionPane.VALUE_PROPERTY)) &&
	                  event.getNewValue() != null &&
	                  event.getNewValue() != JOptionPane.UNINITIALIZED_VALUE) {
	                    try {
	                    	long timeVisible = System.currentTimeMillis() -time;
	                    	if( timeVisible < 200){
	                    		log.trace("TIME VISIBLE DIALOG:"+ timeVisible);
	                    		Thread.sleep(200);
	                    	}
	                    } catch (InterruptedException ex) {
	                    	log.error("", ex);
	                    }
	                    dialog.setVisible(false);
	                }
	            }
	        });
	        dialog.setVisible(true);
	        dialog.dispose();
	 }
	 
	 static int showConfirmDialog(Component parentComponent,
		        Object message, String title, int optionType, int messageType){
	 
	 	final JOptionPane pane = new JOptionPane(message, messageType, optionType);
	 	final JDialog dialog = pane.createDialog(title);
	 	PropertyChangeListener[] listeners = pane.getPropertyChangeListeners();        
        for(PropertyChangeListener property :listeners ){
            if(property.getClass().getName().contains("javax.swing.JOptionPane")){
                pane.removePropertyChangeListener(property);
            }
        }
        
        final long time =System.currentTimeMillis();
        pane.addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent event) {
                if (dialog.isVisible() && event.getSource() == pane &&(event.getPropertyName().equals(JOptionPane.VALUE_PROPERTY)) &&
                  event.getNewValue() != null &&
                  event.getNewValue() != JOptionPane.UNINITIALIZED_VALUE) {
                    try {
                    	long timeVisible = System.currentTimeMillis() -time;
                    	if( timeVisible < 200){
                    		log.trace("TIME VISIBLE DIALOG:"+ timeVisible);
                    		Thread.sleep(200);
                    	}
                    } catch (InterruptedException ex) {
                    	log.error("", ex);
                    }
                    dialog.setVisible(false);
                }
            }
        });
        dialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        dialog.setVisible(true);
        dialog.dispose();
        Object        selectedValue = pane.getValue();

        if(selectedValue == null)
            return JOptionPane.CLOSED_OPTION;
        if(selectedValue instanceof Integer){
                return ((Integer)selectedValue).intValue();
        }
            return JOptionPane.CLOSED_OPTION;
	 }
}
