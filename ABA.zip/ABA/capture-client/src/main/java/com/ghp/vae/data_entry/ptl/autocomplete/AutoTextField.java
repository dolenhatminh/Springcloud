package com.ghp.vae.data_entry.ptl.autocomplete;

import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPopupMenu;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

import org.apache.commons.collections.KeyValue;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.search.service.impl.LookupServiceImpl;
import com.sps.vn.config.ApplicationConfig;

public class AutoTextField extends CustomTextField implements AutoTextFieldInterface {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static Logger log = LoggerFactory.getLogger("GUI");
	// private List<String> dataList;
	private List<KeyValue> dataList;
	private boolean isCaseSensitive;
	private boolean isStrict;
	private final JList jList;
	private final JPopupMenu jPopupMenu;

	private DefaultListModel lookupModel;
	private AutoTextFieldDataSourceInf dataSource;
	Rectangle oldBound;
	Font oldFont;
	boolean mustGetNewList = true;
	boolean isAutoComplete = true;
	java.awt.event.KeyEvent keyPressed;
	LookupServiceImpl lookupService;

	public AutoTextField() {

		this.jList = new JList();
		this.jPopupMenu = new JPopupMenu() {
			@Override
			public void setVisible(boolean b) {
				try {
					AutoTextField.this.setFocusTraversalKeysEnabled(!b);
					super.setVisible(b);
				} catch (final Exception ex) {
					log.error("", ex);
				} finally {
					if (!b) {
						AutoTextField.this.requestFocus();

					}
				}
			}
		};
		this.jPopupMenu.setFocusable(false);
		this.jList.setFocusTraversalKeysEnabled(false);
		this.jList.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_TAB) {
					AutoTextField.this.jPopupMenu.setVisible(false);
					AutoTextField.this.transferFocusDownCycle();
					e.consume();
				}
			}
		});
		this.isCaseSensitive = false;
		this.isStrict = true;
		this.dataSource = null;
		// dataList = new LinkedList<String>();
		this.dataList = new ArrayList<KeyValue>();
		this.lookupService = new LookupServiceImpl();
		this.init();
	}

	@Override
	public void setDataSource(AutoTextFieldDataSourceInf ds) {
		this.dataSource = ds;
	}

	private void init() {
		try {
			this.delayTime = ApplicationConfig.getInstance().getBusinessConfig().getDelaySuggestion();
		} catch (final Exception e) {
			this.delayTime = 300;
		}
		this.setDocument(new AutoDocument());
		if (this.isStrict && this.dataList.size() > 0) {
			this.setText(this.dataList.get(0).getKey().toString());
		}
		this.addKeyListener(new java.awt.event.KeyAdapter() {

			@Override
			public void keyTyped(KeyEvent evt) {
				if (!AutoTextField.this.jPopupMenu.isVisible()) {
					return;
				}
				if (evt.getKeyCode() == KeyEvent.VK_DOWN) {
					// jList.requestFocus();
					evt.consume();
				}
			}

			@Override
			public void keyPressed(java.awt.event.KeyEvent evt) {
				if (AutoTextField.this.getText().indexOf("%") != -1 || AutoTextField.this.getText().indexOf("*") != -1
						|| AutoTextField.this.getText().indexOf("_") != -1 || evt.getKeyChar() == '%'
						|| evt.getKeyChar() == '*' || evt.getKeyChar() == '_') {
					AutoTextField.this.isAutoComplete = false;
				} else {
					AutoTextField.this.isAutoComplete = true;
				}
				if (evt.getKeyCode() == KeyEvent.VK_DOWN) {
					AutoTextField.this.jList.requestFocus();
					/**
					 * Bug #8892 Can not choose suggest for "strasse" field when Press "Down arrow" and enter
					 */
					AutoTextField.this.jList.setSelectedIndex(0);

					evt.consume();
				} else if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
					if (AutoTextField.this.jPopupMenu.isVisible()) {
						AutoTextField.this.jPopupMenu.setVisible(false);
						AutoTextField.this.transferFocus();
					}
				} else if (evt.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
					AutoTextField.this.mustGetNewList = true;
				} else if (evt.getKeyCode() == KeyEvent.VK_TAB) {
					AutoTextField.this.jPopupMenu.setVisible(false);
					AutoTextField.this.transferFocusDownCycle();
				} else if (evt.getKeyCode() == KeyEvent.VK_ESCAPE || evt.getKeyCode() == KeyEvent.VK_F9) {
					AutoTextField.this.jPopupMenu.setVisible(false);
				}
				AutoTextField.this.keyPressed = evt;
			}
		});
		this.jPopupMenu.setBackground(new java.awt.Color(204, 255, 204));
		this.jList.setBackground(new java.awt.Color(204, 255, 204));
		this.jList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		this.jList.addKeyListener(new java.awt.event.KeyAdapter() {

			@Override
			public void keyPressed(java.awt.event.KeyEvent evt) {
				if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
					final KeyValue tmp = (KeyValue) AutoTextField.this.jList.getSelectedValue();
					;
					if (tmp != null) {
						AutoTextField.this.setText(tmp.getKey().toString());
					}
					AutoTextField.this.jPopupMenu.setVisible(false);
				} else if (evt.getKeyCode() == KeyEvent.VK_ESCAPE) {
					AutoTextField.this.jPopupMenu.setVisible(false);
				}
			}
		});

		this.jList.setCellRenderer(new SuggestionCellRenderer());
		this.jPopupMenu.add(this.jList);
		this.jList.setAutoscrolls(true);
		this.jPopupMenu.setAutoscrolls(true);
	}

	private String toAscii(String value) {
		return StringUtils.replaceChars(value, "Ã¡Ã Ã¢Ã¤Ã¦Ã§Ä�Ã©Ã¨ÃªÃ«Ã¬Ã­Ã®Ã¯Ã²Ã´Ã¶Å“Ã¹Ã»Ã¼Ã½Ã¿Å¾ÅºÅ¼",
				"aaaaacÄ�eeeeiiiioooÅ“uuuyyzzz");
	}

	String outDate;

	private String getMatch(final String s) {
		if (s.startsWith("%") || s.startsWith("_") || s.startsWith("*")) {
			return null;
		}
		boolean havalue = false;
		String s1 = null;
		String s1Origin = null;
		final String ins = this.lookupService.translate(s);
		int index = 0;
		if (s != null && !s.equals("")) {
			if (this.dataSource != null) {
				this.dataList = this.dataSource.getDataSource(s);
				if (this.dataList != null && this.dataList.size() > 0) {
					this.lookupModel = new DefaultListModel();
					index = 0;
					for (int i = 0; i < this.dataList.size(); i++) {
						final KeyValue kv = this.dataList.get(i);
						s1 = kv.getKey().toString();
						s1Origin = kv.getKey().toString();
						if (s1 != null) {
							if (!this.isCaseSensitive && s1.toLowerCase().startsWith(ins.toLowerCase())) {
								havalue = true;
								break;// return s1;
							}
							if (this.isCaseSensitive && s1.startsWith(s)) {
								havalue = true;
								break;// return s1;
							}
						}
						index++;
						log.debug("Remove Data List: " + s1);
					}
					//
					if (!havalue) {
						index = 0;
						for (int i = 0; i < this.dataList.size(); i++) {
							final KeyValue kv = this.dataList.get(i);
							s1 = this.lookupService.translate(kv.getKey().toString().toLowerCase());
							s1Origin = kv.getKey().toString();
							if (s1 != null) {
								if (!this.isCaseSensitive
										&& s1.startsWith(this.lookupService.translate(s.toLowerCase()))) {
									havalue = true;
									break;// return s1;
								}
								if (this.isCaseSensitive && s1.startsWith(this.lookupService.translate(s))) {
									havalue = true;
									break;// return s1;
								}
							}
							index++;
							log.debug("Remove Data List: " + s1);
						}
					}

					//

					for (int i = index; this.dataList != null && i < this.dataList.size(); i++) {
						if (!this.lookupModel.contains(this.dataList.get(i))) {
							this.lookupModel.addElement(this.dataList.get(i));
						}

					}
					this.jList.setModel(this.lookupModel);
					this.jPopupMenu.add(this.jList);
					if (s1 != null) {
						this.jList.setSelectedValue(s1Origin, false);
						try {
							if (this.lookupModel.size() == 0) {
								this.jPopupMenu.setVisible(false);
								return s;
							}
							if (this.isFocusOwner()) {
								if (this.jPopupMenu.isVisible()) {
									this.jPopupMenu.pack();
								}
								this.jPopupMenu.show(this, 0, this.getBounds().height);
								this.jPopupMenu.updateUI();
								this.jList.setVisibleRowCount(5);
							}

						} catch (final Exception ex) {
							log.error(Utilities.getStackTrace(ex));
						}
						return s1;
					}
				} else {
					this.outDate = s;
				}
			}
		}
		this.jPopupMenu.setVisible(false);
		return s;
	}

	private boolean isSet;

	@Override
	public void setText(String value) {
		this.isSet = true;
		super.setText(value);

		// jPopupMenu.setVisible(false);jtfStrasse
	}

	@Override
	public void replaceSelection(String s) {
		final AutoDocument _lb = (AutoDocument) this.getDocument();
		if (_lb != null) {
			try {
				final int i = Math.min(this.getCaret().getDot(), this.getCaret().getMark());
				final int j = Math.max(this.getCaret().getDot(), this.getCaret().getMark());
				_lb.replace(i, j - i, s, null);
			} catch (final Exception exception) {
				log.error(Utilities.getStackTrace(exception));
			}
		}
	}

	public boolean isCaseSensitive() {
		return this.isCaseSensitive;
	}

	public void setCaseSensitive(boolean flag) {
		this.isCaseSensitive = flag;
	}

	public boolean isStrict() {
		return this.isStrict;
	}

	public void setStrict(boolean flag) {
		this.isStrict = flag;
	}

	@SuppressWarnings("rawtypes")
	public List getDataList() {
		return this.dataList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void setDataList(List list) {
		if (list == null) {
			throw new IllegalArgumentException("values can not be null");
		} else {
			this.dataList = list;
			return;
		}
	}

	@Override
	public void setConstraint(int maxLength, String invalidCharacter) {
		try {
			this.setDocument(new AutoDocument(maxLength, invalidCharacter));
		} catch (final Exception ex) {
			log.error("", ex);
		}
	}

	class AutoDocument extends PlainDocument {

		private static final long serialVersionUID = 1L;
		private int maxLength = 0;
		private String invalidCharacter = "";

		public AutoDocument() {
			this.maxLength = 0;
			this.invalidCharacter = "";
		}

		;

		public AutoDocument(int maxlength, String sOption) {
			this.maxLength = maxlength;
			this.invalidCharacter = sOption;
		}

		@Override
		public void replace(int i, int j, String s, AttributeSet attributeset) throws BadLocationException {
			super.remove(i, j);
			this.insertString(i, s, attributeset);
			AutoTextField.this.isSet = false;
		}

		@Override
		public void insertString(int offset, String s, AttributeSet attributeset) throws BadLocationException {
			AutoTextField.this.changeBackGround(false);
			if (s == null || "".equals(s)) {
				return;
			}
			if (!AutoTextField.this.isAutoComplete) {
				if (AutoTextField.this.jPopupMenu.isShowing()) {
					AutoTextField.this.jPopupMenu.setVisible(false);
				}

				if (this.maxLength > 0 && !this.invalidCharacter.equals("")) {
					final int textlength = this.getEndPosition().getOffset();
					if (textlength <= this.maxLength) {
						final int remain = this.maxLength - textlength;
						int count = 0;
						String tmp = "";
						final char[] addedFigures = s.toCharArray();
						char c;
						for (int z = 0; tmp.length() < this.maxLength && z < addedFigures.length; z++) {
							c = addedFigures[z];
							if (!Utilities.inString(this.invalidCharacter, c)) {
								tmp = tmp + c;
								count++;
								if (count > remain) {
									break;
								}
							}
						}
						super.insertString(offset, tmp, attributeset);
					}
				} else {
					super.insertString(offset, s, attributeset);
				}
			} else {
				if (this.maxLength > 0 && !this.invalidCharacter.equals("")) {
					final int textlength = this.getEndPosition().getOffset();

					if (textlength <= this.maxLength) {
						final int remain = this.maxLength - textlength;
						int count = 0;
						String tmp = "";
						final char[] addedFigures = s.toCharArray();
						char c;
						for (int z = 0; tmp.length() < this.maxLength && z < addedFigures.length; z++) {
							c = addedFigures[z];
							if (!Utilities.inString(this.invalidCharacter, c)) {
								tmp = tmp + c;
								count++;
								if (count > remain) {
									break;
								}
							}
						}
						final String s1 = this.getText(0, offset);
						String s2 = "";
						String s3 = "";
						if (AutoTextField.this.isSet) {
							AutoTextField.this.isSet = false;
							s2 = tmp;
						} else if (offset == 0 && tmp != null && tmp.length() > 0) {
							AutoTextField.this.suggestion(tmp);
						} else {
							s3 = this.getText(offset, this.getEndPosition().getOffset() - offset - 1);
							final String check = s1 + tmp + s3;
							AutoTextField.this.suggestion(check);
						}
						super.insertString(offset, tmp, attributeset);
					} else {
						return;
					}
				} else {
					final String s1 = this.getText(0, offset);
					@SuppressWarnings("unused")
					String s2 = "";
					String s3 = "";
					if (offset == 0) {
						s2 = s;
					} else {
						s3 = this.getText(offset, this.getEndPosition().getOffset() - offset - 1);
						final String check = s1 + s + s3;
						AutoTextField.this.suggestion(check);
					}
					super.insertString(offset, s, attributeset);
				}
			}
		}

		@Override
		public void remove(int i, int j) {
			try {
				String s = this.getText(0, this.getEndPosition().getOffset() - 1);
				super.remove(i, j);

				if (!AutoTextField.this.isSet) {
					s = this.getText(0, this.getEndPosition().getOffset() - 1);
					AutoTextField.this.suggestion(s);
				}
			} catch (final BadLocationException exception) {
				log.error("", exception);
			} catch (final Exception exception) {
				log.error("", exception);
			}
			AutoTextField.this.isSet = false;
			AutoTextField.this.changeBackGround(false);
		}
	}

	private void suggestion(String source) {
		this.callSuggest();
	}

	private void suggestPopup(String source) {
		if (this.outDate != null && source.toLowerCase().startsWith(this.outDate.toLowerCase())) {
			this.jPopupMenu.setVisible(false);
		} else {
			this.getMatch(source);
		}
	}

	volatile long time;
	int delayTime;
	Thread suggestThread;

	private long checkTime() {
		return this.delayTime + this.time - System.currentTimeMillis();
	}

	private void callSuggest() {
		if (this.suggestThread == null || !this.suggestThread.isAlive()) {
			this.createSuggestThread();
		}
		this.time = System.currentTimeMillis();
	}

	private void createSuggestThread() {
		this.suggestThread = new Thread() {
			@Override
			public void run() {
				while (true) {
					final long distanceTime = AutoTextField.this.checkTime();
					if (distanceTime < 0) {
						AutoTextField.this.suggestion();
						return;
					} else {
						try {
							sleep(distanceTime + 1);
						} catch (final Exception e) {
							log.error("", e);
						}
					}
				}
			}
		};
		this.suggestThread.start();
	}

	public void suggestion() {
		if (this.isFocusOwner() && this.delayTime > 0) {
			this.suggestPopup(this.getText());
		}
	}

	@Override
	public void setUseSuggestion(boolean useSuggestion) {
		// class not support function.
	}

}
