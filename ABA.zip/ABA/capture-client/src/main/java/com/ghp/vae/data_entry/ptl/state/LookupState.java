package com.ghp.vae.data_entry.ptl.state;

import java.awt.Component;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.bll.BLLAddressField;
import com.ghp.vae.data_entry.bll.BLLCard;
import com.ghp.vae.data_entry.bll.BLLDataStructure;
import com.ghp.vae.data_entry.bll.BLLField;
import com.ghp.vae.data_entry.bll.BLLViewData;
import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.entity.Card;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.ObjectInformation;
import com.ghp.vae.data_entry.face.StateCapture;
import com.ghp.vae.data_entry.gui.CaptureMediatorImplement;
import com.ghp.vae.data_entry.ptl.UISearch;
import com.ghp.vae.data_entry.ptl.autocomplete.CustomTextField;
import com.ghp.vae.search.model.ObjectSearch;
import com.ghp.vae.search.service.impl.LookupServiceImpl;
import com.sps.vn.config.ApplicationConfig;
import com.sps.vn.writing.datasource.WritingDBase;

import vae.client.transfer.LookupKey;

/**
 * this is class control behavior of lookup db of capture client :
 * <ul>
 * <ol>
 * Searching kdpid special.
 * </ol>
 * <ol>
 * Searching kdpid normal.
 * </ol>
 * <ol>
 * Searching auto searching kdpid.
 * </ol>
 * <ol>
 * Cancel when searching kdp id.
 * </ol>
 * <ol>
 * Fill data when chose kdpId
 * </ol>
 * </ul>
 *
 * @author vmhoang
 *
 */
class LookupState implements ReloadState {

    private static Logger log = LoggerFactory.getLogger("Lookup");
    private final BLLViewData viewData;

    private Thread aliveThread;
    HashMap<String, String> searchKDPMap = new HashMap<String, String>();
    private int startStep;
    private String changeCase[];
    private boolean findNextKdp;
    private final String notWordData;

    /**
     * lookup state need list Search OCR, changeCase . get config properties
     * NOT_WORDS;
     *
     * @param listSearchOcr
     * @param changeCase
     * @see NormalState
     */
    public LookupState(List<String> listSearchOcr, String[] changeCase, BLLViewData viewData) {
        // this.listOrtChecks =listSearchOcr;
        this.viewData = viewData;
        this.lookupService = new LookupServiceImpl();
        this.notWordData = ApplicationConfig.getInstance().getBusinessConfig().getNotWord();
    }

    @Override
    public void reloadStatus() {
        this.searchKDPMap.clear();
        this.aliveThread = null;
        this.startStep = 0;
        this.findNextKdp = false;
    }

    // public void searchlookup(MainFieldInterface main, final List<Map<String,
    // String>> arrValuesLookup) {
    // try {
    // findNextKdp(main, arrValuesLookup);
    // } catch (Exception e) {
    // main.setProcessStatus(false);
    // main.resetState();
    // }
    //
    // }
    /**
     * handleEvent :
     * <ul>
     * <ol>
     * LOOKUP_NORMAL: Lookup table kdp_combination
     * </ol>
     * <ol>
     * LOOKUP_SPECIAL: Lookup table kdp_combination_special
     * </ol>
     * <ol>
     * LOOKUP_UISPEC: When change lookup from special to normal
     * </ol>
     * <ol>
     * CANCEL_PROCESS: Escape into lookup data.
     * </ol>
     * <ol>
     * UPDATE_KDP: Update gui when chose kdp
     * </ol>
     * <ol>
     * EXIT
     * </ol>
     * </ul>
     *
     * @note: request from customer for auto searching change use lookupSpecial
     * for firstSearch , and LoopNormal for nextSearch.
     * @see StateCapture
     */
    @Override
    public void handleEvent(final ObjectInformation information, final MainFieldInterface main) {
        final byte action = information.getAction();
        switch (action) {
            case LOOKUP:
                try {
                    this.findNextKdp(information, main);
                } catch (final Exception e) {
                    if (e instanceof InterruptedException) {
                        log.info("CANCEL LOOKUP THREAD");
                    } else {
                        log.error("", e);
                    }

                    CaptureMediatorImplement.releaseLookup();
                    main.setProcessStatus(false);
                    main.resetState();
                }
                break;
            case ROLLBACK_KDP:
				try {
					this.RollBackKdp(information, main);
				} catch (Exception e) {
					e.printStackTrace();
				}
            	break;
            // case LOOKUP_SPECIAL:
            // openLookupSpecial(information, main);
            // try {
            // findNextKdp(main);
            // } catch (Exception e) {
            // main.setProcessStatus(false);
            // main.resetState();
            // }
            // break;
            case LOOKUP_UISPEC:
                // System.out.println("LOOKUP_UISPEC");
                break;
            case CANCEL_PROCESS:
                System.out.println("CANCEL_LOOKUP_PROCESS");
                this.cancelProcess(information, main);
                break;
            case UPDATE_KDP:
                // System.out.println("UPDATE_KDP");
                this.makeValueKDP(main);
                break;
            case FIND_NEXT_KDP:
                // System.out.println("FIND_NEXT_KDP");
                this.findNextKdp = true;
                break;
            case SEARCH_GUI_CLOSE:
                System.out.println("SEARCH_GUI_CLOSE - " + this.findNextKdp);
                if (!this.findNextKdp) {
                    isFirstSearch = true;
                    isSecondSearch = false;
                }

                if (this.findNextKdp) {
                    information.clearData();
                    information.setAction(LOOKUP);

                    CaptureMediatorImplement.lockLookup();

                    main.request(information, main);
                } else {
                    CaptureMediatorImplement.releaseLookup();
                    main.resetState();
                }
                break;
            case CLEAR_KDPID:
                System.out.println("CLEAR_KDPID");
                this.clearKDPID(main);
                break;
            case EXIT:
                this.openPopupCannotNotExit("Dang Lookup khong the exit chuong trinh");
                break;

            default:
                log.info("This type of action is not support in LookupState: " + action);
                break;
        }

    }

    private void clearKDPID(MainFieldInterface main) {
        final Card card = main.getEntity();
        if (card.getVectorKDP() == null) {
            main.resetState();
            return;
        }
        card.clearValue();
        this.enablePickpostField(main);
        this.resetAddressFieldValue(main);
    }

    private void resetAddressFieldValue(MainFieldInterface main) {
        final BLLCard bllCard = main.getEntity().getCard();
        final Iterator<BLLField> fields = bllCard.getFieldList().values().iterator();
        while (fields.hasNext()) {
            final BLLField field = fields.next();
            if (field instanceof BLLAddressField) {
                field.setValue("");
            }
        }
        bllCard.getField(BLLDataStructure.KDPID_FIELD).setValue("");
        main.updateKDPID("");
        bllCard.getField(BLLDataStructure.ADDRESSTYPE_FIELD).setValue("");
        bllCard.getField(BLLDataStructure.PERSIBS_FIELD).setValue("");
        bllCard.getField(BLLDataStructure.ORTZIBS_FIELD).setValue("");
        bllCard.getField(BLLDataStructure.ORTZTYP_FIELD).setValue("");
        bllCard.getField(BLLDataStructure.ANREDEID_FIELD).setValue("");
    }

    private void enablePickpostField(MainFieldInterface main) {
        main.getComponent(MainFieldInterface.PICKPOST).setEnabled(true);
        main.getComponent(MainFieldInterface.POSTLAGEND).setEnabled(true);
        main.getComponent(MainFieldInterface.MYPOST24).setEnabled(true);

    }

    /**
     * open message box when exit program.
     *
     * @param message
     */
    private void openPopupCannotNotExit(String message) {
        AroundDialog.showMessageDialog(null, message, "Canh bao", JOptionPane.WARNING_MESSAGE);
    }

    /**
     * 1. check thread lookup live.<br/>
     * 2. cancel query lookup if query in db.<br/>
     * 3. interrupt thread.<br/>
     * 4. clear gui and reset data.
     *
     * @param information
     * @param main
     * @note disable function clear when interruptLookup (2014/12/23)
     */
    private void cancelProcess(ObjectInformation information, MainFieldInterface main) {
        if ((this.aliveThread != null) && (this.aliveThread.isAlive())) {
            log.info("LOOKUP STATE: INTERUPT LOOKUP STATE");
            this.aliveThread.interrupt();
            WritingDBase.cancelStatementAll();
            // clearWhenInterruptLookup(main);
        }
        CaptureMediatorImplement.releaseLookup();

        main.setProcessStatus(false);
        main.resetState();

        log.info("Thread >> " + Thread.currentThread().getName());
    }

    /**
     * clear gui , card data when interrupt lookup.
     *
     * @param main
     * @note disable
     */
    @SuppressWarnings("unused")
    private void clearWhenInterruptLookup(MainFieldInterface main) {
        final Card card = main.getEntity();
        // card.setHaveValueFromSearchKdp(false);
        // card.clearValue();
        // enablePickpostField(main);
        card.getCard().getField(BLLDataStructure.ZUBO_ADRID_FIELD).setValue("");
        // resetAddressFieldValue(main);
        // card.getCard().setKdpSpecical(false);
        main.getComponent(MainFieldInterface.FIRMA).requestFocus();
        // card.setAdr_id(0);
    }

    /**
     * check lookup postfach or not postfach, change process bar status . create
     * thread lookup special.
     *
     * @param information
     * @param main
     * @see #openLookupSpecialThread(MainFieldInterface, int).
     */
    @SuppressWarnings("unused")
    private void openLookupSpecial(ObjectInformation information, MainFieldInterface main) {
        final boolean hasPostfach = this.checkHasPostfach(main);
        int type;
        if (hasPostfach) {
            main.setStatus("Searching KDP with Postfach ...");
            type = 1;
        } else {
            main.setStatus("Searching KDP ...");
            type = 0;
        }
        this.openLookupSpecialThread(main, type);
    }

    /**
     * create thread lookup special.</br and search Normal when searchNormal is
     * true. <br/> enable process bar.
     *
     * @param main
     * @param type
     */
    private void openLookupSpecialThread(final MainFieldInterface main, final int type) {

        this.searchKDP(main, type);

        main.setProcessStatus(true);
    }

    /**
     * function check contraint after searching use by searchKDP_Nomal,
     * searckKDP. <br/>
     *
     * @param main
     * @return boolean
     */
    private boolean checkContraintForSearch(MainFieldInterface main) {

        if (!main.getFieldValue(MainFieldInterface.PICKPOST).equals("")
                || !main.getFieldValue(MainFieldInterface.MYPOST24).equals("")) {
            return true;
        }
        final String plz = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.PLZ));
        final boolean checkPlz = plz.matches("\\d{3}|\\d{4}") || plz.equals("");
        if (!checkPlz) {
            AroundDialog.showMessageDialog(null, "Khong dung dieu kien de search PLZ Co it nhat 3 ky tu", "Canh bao",
                    JOptionPane.WARNING_MESSAGE);
            main.resetState();
            this.setUpdateMessage(main, false);

            return false;
        }
        final String ort = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.ORT));
        final boolean checkORT = ort.matches("\\D+|\\D+\\d+.*|%") || ort.equals("");
        if (!checkORT) {
            AroundDialog.showMessageDialog(null, "Khong dung dieu kien de search ORT", "Canh bao",
                    JOptionPane.WARNING_MESSAGE);

            CaptureMediatorImplement.releaseLookup();

            main.resetState();
            this.setUpdateMessage(main, false);

            return false;
        }

        // Warning search
        if (this.countParamForSearch(main) < 1) {
            AroundDialog.showMessageDialog(null, "Phai co it nhat 1 dieu kien de search kdp id", "Canh bao",
                    JOptionPane.WARNING_MESSAGE);

            CaptureMediatorImplement.releaseLookup();

            main.resetState();
            this.setUpdateMessage(main, false);

            return false;
        }
        return true;
    }

    /**
     * function check param for searching. <br/>
     *
     * @param main
     * @see #countParamForSearch(String, String, String, String)
     */
    private int countParamForSearch(MainFieldInterface main) {
        return this.countParamForSearch(main.getFieldValue(MainFieldInterface.PLZ),
                main.getFieldValue(MainFieldInterface.ORT), main.getFieldValue(MainFieldInterface.STRASSE),
                main.getFieldValue(MainFieldInterface.HAUSE));
    }

    /**
     * function check param for searching. <br/>
     *
     * @param main
     * @see #countParamForSearch(String, String, String, String)
     */
    private int countParamForSearch(ObjectSearch objectSearch) {
        return this.countParamForSearch(objectSearch.getPlz(), objectSearch.getOrt(), objectSearch.getStrasse(),
                objectSearch.getHausNummer());
    }

    /**
     * @param plz
     * @param ort
     * @param strasse
     * @param hausNummer
     * @return
     */
    private int countParamForSearch(String plz, String ort, String strasse, String hausNummer) {
        int param = 4;
        if (Utilities.ignoreNull(plz).equals("")) {
            param--;
        }
        if (Utilities.ignoreNull(ort).equals("")) {
            param--;
        }
        if (Utilities.ignoreNull(strasse).equals("")) {
            param--;
        }
        if (Utilities.ignoreNull(hausNummer).equals("")) {
            param--;
        }
        return param;
    }

    /**
     * proccess lookup kdp special.
     *
     * @param main
     * @param type
     * @note Thread.sleep (50) workaround for lost data when settext field
     * search.
     */
    private void searchKDP(MainFieldInterface main, int type) {
        try {
            Thread.sleep(50);
            if (!this.checkContraintForSearch(main)) {
                this.setUpdateMessage(main, false);
                main.resetState();
                return;
            }
            if (this.getKDPReference(type, main)) {
                this.setEnableSomeField(true, main);
            }

        } catch (final Exception ex) {
            log.error("", ex);
            main.setProcessStatus(false);
            main.resetState();
        }
    }

    /**
     * this is function control lookup special.
     *
     * @param type
     * @param main
     * @return
     * @throws InterruptedException
     * @note: remove enablePickpostField : request pms id : 4981
     */
    private boolean getKDPReference(int type, MainFieldInterface main) throws Exception {
        main.hiddenToolTip();
        final String lookup = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.LOOKUP));
        if (lookup.equals("")) {
            AroundDialog.showMessageDialog(null, "Ban phai nhap gia tri tim kiem.\nKhong co gia tri KDP duoc chon.",
                    "Canh bao", JOptionPane.WARNING_MESSAGE);
            main.resetState();
            main.getComponent(MainFieldInterface.FIRMA).requestFocus();
            this.setUpdateMessage(main, false);
            return false;
        }

        String plz = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.PLZ));
        if (!plz.equals("") && (plz.length() >= 3)) {
            plz = plz.substring(0, 3);
        } else if (!plz.equals("") && (plz.length() == 1) && plz.equalsIgnoreCase("%")) {
            plz = "%_";

        }
        String ort = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.ORT));
        if (ort.contains("-")) {
            ort = ort.replaceAll("-", " ");
        }

        String strasse = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.STRASSE));
        strasse = this.removeNotWordsData(strasse);
        strasse = strasse.replace("'", "''");
        // if (strasse.indexOf("'") != -1) {
        // strasse = strasse.substring(0, strasse.indexOf("'"));
        // }

        if (ort.indexOf("'") != -1) {
            ort = ort.substring(0, ort.indexOf("'"));
        }

        String hausNummer = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.HAUSE));

        final String[] strassKeys = strasse.split(" ");
        if (strassKeys.length > 1) {
            strasse = strassKeys[0];
        }

        final String haus[] = this.spilitHauseNum(hausNummer);
        String hausuzat = "";
        if ((haus != null) && (haus.length > 0)) {
            hausNummer = haus[0];
            hausuzat = haus[1];
        }

        // split key word to name and vorce name
        String name = "";
        String v_name = "";
        final String[] keyWords = lookup.split(" ");
        if (keyWords.length > 1) {
            name = keyWords[0];
            v_name = keyWords[1];
        } else {
            name = lookup;
            v_name = "";
        }
        final int timeSearch = 0;

        name = this.lookupService.translate(name);
        v_name = this.lookupService.translate(v_name);
        ort = this.lookupService.translate(ort);
        strasse = this.lookupService.translate(strasse);

        final String ort_origin = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.ORT));
        final String strasse_origin = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.STRASSE));
        final String hasValue = main.getFieldValue(MainFieldInterface.PICKPOST)
                + main.getFieldValue(MainFieldInterface.POSTLAGEND);
        int type_special = type;
        if (!hasValue.equals("")) {
            type_special = type + 2;
        }

        this.searchKDPMap.clear();
        this.updateMapSearch(name, v_name, plz, ort, strasse, hausNummer, hausuzat, type_special + "", timeSearch + "",
                ort_origin, strasse_origin);
        this.checkInterrupted("check interrupted before search");
        this.lookupKDPID(main);

        return false;
        /**
         * checkInterrupted("check interrupted before search"); if
         * (!main.getFieldValue(MainFieldInterface.MYPOST24).equals("")) {
         * type_special = 4; arrValuesLookup = searchPickpost(name, v_name, "",
         * "", "", "", "", type_special, timeSearch, "", "", true); } else if
         * (!main.getFieldValue(MainFieldInterface.PICKPOST).equals("")) {
         * arrValuesLookup = searchPickpost(name, v_name, "", "", "", "", "",
         * type_special, timeSearch, "", "", true); } else { arrValuesLookup =
         * autoSearchingProcess(name, v_name, plz, ort, strasse, hausNummer,
         * hausuzat, type_special, timeSearch, ort_origin, strasse_origin, true,
         * main); } System.out.println("end search database:" + new
         * Date().getTime()); checkInterrupted("check interrupted after
         * search"); if (arrValuesLookup != null) {
         * card.getCard().setKdpSpecical(true);
         * card.setHaveValueFromSearchKdp(true); String titles[] = new String[]
         * { "Firmenname", "Vorname", "Name", "Namenszusatz", "Plz", "Ort",
         * "Strasse", "Haus", "Postfach", "Pickpost", "Anrede", "Addresszusatz",
         * "C/o adresse", "Stockwerk", "Kdp_id", "Landcode", "Pers_08_typ",
         * "pers_06_ibs", "ortz_04_ibs", "ortz_06_typ", "Namesuzat_1", "Adr_id",
         * "Ort Set", "Strasse Set", "Expire Date", "Start Date", "My Post 24"
         * }; checkInterrupted("check interrupted when init uisearch"); new
         * UISearch(main, UISearch.searchKDP, arrValuesLookup, titles, null,
         * null); } else { searchNormal = true; return false; } return true;
         *
         */
    }

    /**
     * this is function using for notwords Data <br>
     * ex: -strasse, Z.I Request ID : 1309 [VAE]Request-Strasse
     *
     * @return
     */
    private String removeNotWordsData(String strasse) {
        strasse = strasse.toLowerCase();
        final String[] notWords = this.notWordData.toLowerCase().split(";");

        if (notWords.length < 1) {
            return strasse;
        }
        for (final String notWord : notWords) {
            if (notWord.contains("-")) {
                continue;
            }

            strasse = (" " + strasse + " ").replaceAll(" " + notWord + " ", " ");

        }

        strasse = strasse.trim().split(" ")[0];
        for (final String notWord : notWords) {
            if (notWord.contains("-")) {
                if (notWord.startsWith("-")) {
                    if (strasse.endsWith(notWord.substring(1))) {
                        strasse = strasse.substring(0, (strasse.length() - notWord.length()) + 1);
                    }
                }
                if (notWord.endsWith("-")) {
                    if (strasse.startsWith(notWord.substring(0, notWord.length() - 1))) {
                        strasse = strasse.replaceFirst(notWord.substring(0, notWord.length() - 1), "");
                    }
                }
            }
        }
        return strasse.trim();
    }

    private void lookupKDPID(MainFieldInterface main) throws Exception {
        this.setEnableSomeField(true, main);
        System.out.println("lookup...................");
        // findNextKdp(main);

        // if (!main.getFieldValue(MainFieldInterface.MYPOST24).equals("")
        // || !main.getFieldValue(MainFieldInterface.PICKPOST).equals("")) {
        // findKdpPickpostMyPost24(main);
        //
        // } else {
        // startStep = 1;
        // kdpSpecial = true;
        // findNextKdp(main);
        // }
    }

    /**
     * It is used for holding a flag that check there is the first action search
     * If typist doesn't change 'object search' this value will be reverse. ex
     * true->false, false -> true
     */
    static boolean isFirstSearch = true;
    static boolean isSecondSearch = false;

    /**
     * It is used for holding a previous data It will be used to compare to
     * current data If data is changed -> reset flag 'isFirstSearch'
     */
    static ObjectSearch objCurrSearch = new ObjectSearch();

    private boolean isDataChange(ObjectSearch obj1, ObjectSearch obj2) {
        if (obj1.toString().equalsIgnoreCase(obj2.toString())) {
            return false;
        }
        return true;
    }

    private ObjectSearch buildObjectSearch(MainFieldInterface main) {
        try {

            final String lookup = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.LOOKUP));

            final String plz = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.PLZ));

            final String ort = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.ORT));

            final String strasse = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.STRASSE));

            final String hausNummer = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.HAUSE));

            final String pf = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.POSTFACH));

            final String pickpost = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.PICKPOST));

            final String mypost24 = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.MYPOST24));

            final ObjectSearch objectSearch = new ObjectSearch(lookup, plz, ort, strasse, hausNummer, pf, pickpost,
                    mypost24);

            final Card card = main.getEntity();

            log.info(String.format("[STATISTIC] Ctrl+F :: ID [%s] - %s",
                    (card != null ? card.getCard().getCollectionID() : ""), objectSearch.toString()));

            return objectSearch;

        } catch (final Exception e) {
            log.error("", e);
            return new ObjectSearch();
        }
    }

    private boolean checkContraintForSearch(ObjectSearch objectSearch, MainFieldInterface main) {

        if (!objectSearch.getPickpost().equals("") || !objectSearch.getMypost24().equals("")) {
            return true;
        }
        final String plz = Utilities.ignoreNull(objectSearch.getPlz());
        final boolean checkPlz = plz.matches("\\d{3}|\\d{4}") || plz.equals("");
        if (!checkPlz) {
            AroundDialog.showMessageDialog(null, "Khong dung dieu kien de search PLZ Co it nhat 3 ky tu", "Canh bao",
                    JOptionPane.WARNING_MESSAGE);

            CaptureMediatorImplement.releaseLookup();

            main.resetState();
            this.setUpdateMessage(main, false);

            return false;
        }
        final String ort = Utilities.ignoreNull(objectSearch.getOrt());
        final boolean checkORT = ort.matches("\\D+|\\D+\\d+.*|%") || ort.equals("");
        if (!checkORT) {
            AroundDialog.showMessageDialog(null, "Khong dung dieu kien de search ORT", "Canh bao",
                    JOptionPane.WARNING_MESSAGE);

            CaptureMediatorImplement.releaseLookup();

            /**
             * Bug #8885 Capture Client is frozen after user click ok at message
             */
            main.resetState();
            this.setUpdateMessage(main, false);

            return false;
        }

        // Warning search
        if (this.countParamForSearch(objectSearch) < 1) {
            AroundDialog.showMessageDialog(null, "Phai co it nhat 1 dieu kien de search kdp id", "Canh bao",
                    JOptionPane.WARNING_MESSAGE);

            CaptureMediatorImplement.releaseLookup();

            /**
             * Bug #8885 Capture Client is frozen after user click ok at message
             */
            main.resetState();
            this.setUpdateMessage(main, false);

            return false;
        }
        return true;
    }

    LookupServiceImpl lookupService = new LookupServiceImpl();
    ObjectSearch objectSearch = new ObjectSearch();
    List<Map<String, String>> arrValuesLookup = new ArrayList<Map<String, String>>(0);
    boolean getSearchBySpecial = false;
    
    //Dev by htvy, ABA-68, check has Lookup KDP
    boolean checkHasSearchES = false;

    private void enableMainForm(final MainFieldInterface main) {
    	 // Enable main form - button SAVE_BUTTON + SAVE_MENU, ZUSAT, ANREDE,
        // STOCKWERK, ADRESSZUSAT, COADDRESS
        if (!EventQueue.isDispatchThread()) {
            EventQueue.invokeLater(new Runnable() {
                @Override
                public void run() {
                    LookupState.this.setEnableSomeField(true, main);
                }
            });
        } else {
            this.setEnableSomeField(true, main);
        }
    }
    
    private boolean resultsContain(boolean compare) {
        boolean result = false;
        for (final Map<String, String> map : this.arrValuesLookup) {
            if (map.get(LookupKey.IS_SPECIAL.getKey()).equalsIgnoreCase(compare + "")) {
                result = true;
                break;
            }
        }

        return result;
    }
    
    private LookupKey[] getTitles() {
    	final LookupKey titles[] = new LookupKey[]{
    			LookupKey.FIRMENNAME, // 1
                LookupKey.VORNAME, // 2
                LookupKey.NAME, // 3
                LookupKey.ANREDE, // 4
                LookupKey.PLZ, // 5
                LookupKey.ORT, // 6
                LookupKey.STRASSE, // 7
                LookupKey.FULLHAUSNUMMER, // 8
                LookupKey.IS_POSTFACH, // 9
                LookupKey.MY_POST_24, // 10
                LookupKey.PICKPOST, // 11
                //LookupKey.NIXIE_CODE, // 12
                LookupKey.STRASSE_SET, // 13
                LookupKey.ORT_SET, // 14
                LookupKey.NIXIE_CODE, // 12
                LookupKey.KDP_ID, // 15
                LookupKey.PERS_08_TYP, // 16
                LookupKey.HAUSKEY, // 17 hidden
                LookupKey.ADR_ID, // 18 hidden
                LookupKey.STREETNUMBER, // 19 hidden
                LookupKey.VNAME_SET, // 20 hidden
                LookupKey.VNAME_ALIAS, // 21 hidden
                LookupKey.IS_SPECIAL, // 22 hidden
                LookupKey.KDP_ALIAS, // 23 hidden
                LookupKey.IS_KDP_ALIAS, // 24 hidden
                LookupKey.AADR_ID, // 25 hidden
                LookupKey.NAMENSZUSATZ, // 26 hidden
                LookupKey.IS_IGNORE_KUNDENNUMBER, // 26 hidden
        };
    			
    	return titles;
    }

    private void findNextKdp(final ObjectInformation information, final MainFieldInterface main) throws Exception {
    	LookupState.this.enableMainForm(main);

        this.findNextKdp = false;

        this.aliveThread = new Thread() {
            @Override
            public void run() {
                try {
                    // System.out.println("UISearch.isExisted() :: " +
                    // UISearch.isExisted());
                    // if(UISearch.isExisted()){
                    // return;
                    // }

                    log.info("[Capture]-[COLLECTION:" + main.getEntity().getCard().getManagementID() + "][LOOK]-start");

                    /**
                     * ------- Search KDP ID -------
                     */
                    LookupState.this.objectSearch = LookupState.this.buildObjectSearch(main);

                    // check constraint before search kdp
                    /**
                     * Bug #8885 Capture Client is frozen after user click ok at
                     * message
                     */
                    if (!LookupState.this.checkContraintForSearch(LookupState.this.objectSearch, main)) {
                        return;
                    }
                    if (LookupState.this.objectSearch.getLookup().equals("")) {
                    	LookupState.this.checkHasSearchES = false;
                    	
                        AroundDialog.showMessageDialog(null,
                                "Ban phai nhap gia tri tim kiem.\nKhong co gia tri KDP duoc chon.", "Canh bao",
                                JOptionPane.WARNING_MESSAGE);

                        CaptureMediatorImplement.releaseLookup();

                        main.getComponent(MainFieldInterface.FIRMA).requestFocus();
                        main.resetState();
                        LookupState.this.setUpdateMessage(main, false);

                        return;
                    }

                    // 05/11/2016 - Update: do lookup when user press CTRL + F, even though the key words is not
                    // changed.
                    // final boolean isChangedData = LookupState.this.isDataChange(objCurrSearch,
                    // LookupState.this.objectSearch);
                    final boolean isChangedData = true;

                    // Update objCurrSearch
                    objCurrSearch = LookupState.this.objectSearch;

                    if (isChangedData) {
                        /**
                         * Reset isFirstSearch if the data is changed
                         */
                        isFirstSearch = true;

                        /**
                         * 1. Set status is "Searching KDP ..." and start dialog
                         */
                        main.setStatus("Searching KDP ...");

                        final ExecutorService pool = Executors.newSingleThreadExecutor();
                        final Future<Object> future = pool.submit(new Callable<Object>() {
                            @Override
                            public Object call() throws Exception {
                            	LookupState.this.arrValuesLookup = LookupState.this.lookupService.lookupKDP(LookupState.this.objectSearch, true);
                        		if (LookupState.this.arrValuesLookup.size() == 0) {
                        			log.info("###THE 1ST STEP NOT FOUND OUT RESULT. KEEP SEARCHING KDP IN NORMAL WORKFLOW###");
                        			LookupState.this.arrValuesLookup = LookupState.this.lookupService.lookupKDP(LookupState.this.objectSearch, false);
                        		}
                        		
                        		LookupState.this.checkHasSearchES = true;
                        		
                                return LookupState.this.arrValuesLookup;
                            }
                        });
                        new Thread(new Runnable() {

                            @Override
                            public void run() {
                                LookupState.this.setUpdateMessage(main, true);
                            }
                        }).start();

                        /**
                         * Hide status "Searching KDP ..." in another thread
                         */
                        future.get();
                    }

                    if ((LookupState.this.arrValuesLookup == null) || ((LookupState.this.arrValuesLookup.size() == 0)
                            && !((information != null) && (information.getSource() != null)
                            && information.getSource().toString().equalsIgnoreCase("LOOKUP")))) {
                        System.out.println(" *** arrValuesLookup ==null || arrValuesLookup.size() == 0 *** ");

                        CaptureMediatorImplement.releaseLookup();

                        main.resetState();
                        LookupState.this.setUpdateMessage(main, false);
                        main.displayToolTip();
                        LookupState.this.clearWhenNotChooseKdp(main);
                        main.getComponent(MainFieldInterface.FIRMA).requestFocus();

                        return;
                    } else {
                        // 13/06/2016-Update by pvgiang_1

                        final LookupKey titles[] = LookupState.this.getTitles();
                        /**
                         * ----------------------------
                         */
                        final boolean hasSpecial = LookupState.this.resultsContain(true);
                        final boolean hasNormal = LookupState.this.resultsContain(false);

                        boolean searchBySpecial = false;

                        /**
                         * For special case 3rd Ctrl + F
                         */
                        if (isSecondSearch && hasSpecial && hasNormal) {
                            System.out.println(" *** For special case 3rd Ctrl + F *** ");
                            isSecondSearch = false;

                            CaptureMediatorImplement.releaseLookup();

                            LookupState.this.setUpdateMessage(main, false);
                            main.displayToolTip();
                            LookupState.this.clearWhenNotChooseKdp(main);
                            main.resetState();
                            main.getComponent(MainFieldInterface.FIRMA).requestFocus();

                            return;
                        }
                        
                        if (isFirstSearch && hasSpecial && hasNormal) { // Case:1.1-search.by.special
                            // ignore check is special
                            isFirstSearch = false;
                            searchBySpecial = true;
                        } else if (!isFirstSearch && hasSpecial && hasNormal) { // Case:1.2-search.by.normal
                            // ignore check is special
                            searchBySpecial = false;
                            isFirstSearch = true;
                            isSecondSearch = true;
                        } else if (isFirstSearch && hasSpecial && !hasNormal) {// Case:2.1-search.by.special
                            isFirstSearch = false;
                            searchBySpecial = true;
                        } else if (!isFirstSearch && hasSpecial && !hasNormal) {// Case:2.2-search.by.normal
                            isFirstSearch = true;
                            searchBySpecial = false;
                        } else if (isFirstSearch && !hasSpecial && hasNormal) {// Case:3.1-search.by.normal
                            isFirstSearch = false;
                            searchBySpecial = false;
                        } else if (!isFirstSearch && !hasSpecial && hasNormal) {// Case:3.2-search.by.special
                            isFirstSearch = true;
                            searchBySpecial = true;
                        }
                        //Get searchBySpecial
                        LookupState.this.getSearchBySpecial = searchBySpecial;
                        
                        /**
                         * Request ID : 7440 [VAE]Showing KDP result
                         */
                        /**
                         * Added on 06/06/2016 by pvgiang_1 Request ID : 10025
                         * [VAE] KDP Result sort by score
                         *
                         */
                        // List<Map<String, String>> groupResults = groupResults(arrValuesLookup);
                        final UISearch search = UISearch
                                .intance((JFrame) main.getComponent(MainFieldInterface.FRAME_VIEW), searchBySpecial);
                        search.clearData();
                        search.setParentMainFace(main);
                        search.setSearchType(UISearch.searchKDP);
                        // search.setDataResult(groupResults);
                        search.setDataResult(LookupState.this.arrValuesLookup);
                        search.setTitle(titles);
                        search.viewResult(searchBySpecial);
                    }

                    main.getComponent(MainFieldInterface.FIRMA).requestFocus();
                    return;
                } catch (final Exception e) {
                    System.out.println(" ERROR >>> findNextKdp ");
                    log.error("", e);

                    CaptureMediatorImplement.releaseLookup();

                    main.resetState();
                    LookupState.this.setUpdateMessage(main, false);

                } finally {

                }
            }

        };
        this.aliveThread.start();
        // setUpdateMessage(main, true);
        
    }
    
    /**
     * ABA-175: Erfassung Firmen-PLZ
     * 		Function Rollback KDP as soon as has look up
     * @param information
     * @param main
     * @throws Exception
     */
    private void RollBackKdp(final ObjectInformation information, final MainFieldInterface main) throws Exception {
    	if(LookupState.this.checkHasSearchES) {
    		if(!LookupState.this.arrValuesLookup.isEmpty()) {
		    	LookupState.this.enableMainForm(main);
		    
		    	this.aliveThread = new Thread() {
					@Override
		            public void run() {
						try {			
				    		final LookupKey titles[] = LookupState.this.getTitles();
				    			
				            //param 2: True is color Blue or false is color white
				            final UISearch rollBackKDP = UISearch.intance((JFrame) main.getComponent(MainFieldInterface.FRAME_VIEW), LookupState.this.getSearchBySpecial);
				            rollBackKDP.clearData();
				            rollBackKDP.setParentMainFace(main);
				            rollBackKDP.setSearchType(UISearch.searchKDP);
				            rollBackKDP.setDataResult(LookupState.this.arrValuesLookup);
				            rollBackKDP.setTitle(titles);
				            rollBackKDP.viewResult(LookupState.this.getSearchBySpecial);
				
				            main.getComponent(MainFieldInterface.FIRMA).requestFocus();
				            return;
					    } catch (final Exception e) {
					        System.out.println(" ERROR >>> RollBack KDP ");
					        log.error("", e);
					        CaptureMediatorImplement.releaseLookup();
					        main.resetState();
					        LookupState.this.setUpdateMessage(main, false);
					    }
		            }
		    	};
		    	this.aliveThread.start();
			}else {
				CaptureMediatorImplement.releaseLookup();
				main.resetState();
			}
    	}else {
    		CaptureMediatorImplement.releaseLookup();
			main.resetState();
    	}
    }
    
    /**
     * ABA-175: Erfassung Firmen-PLZ
     * 		Function clear List as soon as save card
     */
    public void resetData() {
    	LookupState.this.checkHasSearchES = false;
    }
    
    /**
     * Request ID : 7440 [VAE]Showing KDP result
     */
    public List<Map<String, String>> groupResults(List<Map<String, String>> arrValuesLookup) {
        final List<Map<String, String>> finalResult = new ArrayList<Map<String, String>>(0);
        final List<Map<String, String>> company = new ArrayList<Map<String, String>>(0);

        for (final Map<String, String> map : arrValuesLookup) {
            if (StringUtils.isBlank(map.get(LookupKey.FIRMENNAME.getKey()))) {
                finalResult.add(map);
            } else {
                company.add(map);
            }
        }

        finalResult.addAll(company);

        return finalResult;

    }

    /**
     * Cong dung so sanh nhung kdpid gan ke nhau giong nhau thi dua record co'
     * expireddate (25), kdpid (15) lon len tren
     *
     * @param arrValuesLookup
     * @return
     */
    private List<Map<String, String>> softWithKdpAndExpiredDate(List<Map<String, String>> arrValuesLookup) {
        String currentKdp = "";

        int min = 0;
        int current = 0;
        final List<Map<String, String>> temp = new ArrayList<Map<String, String>>();

        for (final Map<String, String> data : arrValuesLookup) {

            final String compare = data.get(LookupKey.KDP_ID.getKey());

            if (currentKdp.equals("") || !currentKdp.equals(compare)) {
                if (temp.size() > 1) {
                    this.softWithExpiredDate(temp, arrValuesLookup, min);
                }

                temp.clear();
                currentKdp = compare;
                min = current;
            }
            // temp.add(data);
            temp.add(new HashMap<String, String>(data));
            current++;
        }
        if (temp.size() > 1) {
            this.softWithExpiredDate(temp, arrValuesLookup, min);
        }
        return arrValuesLookup;
    }

    private void softWithExpiredDate(List<Map<String, String>> temp, List<Map<String, String>> arrValuesLookup,
            int min) {

        // final Comparator<Map<String, String>> com = new Comparator<Map<String, String>>() {
        // @Override
        // public int compare(Map<String, String> o1, Map<String, String> o2) {
        // return o2.get(LookupKey.EXPIRE_DATE.getKey()).compareTo(o1.get(LookupKey.EXPIRE_DATE.getKey()));
        // }
        // };
        // Collections.sort(temp, com);
        for (final Map<String, String> data : temp) {
            arrValuesLookup.get(min).putAll(data);
            min++;
        }
    }

    private boolean checkHasPostfach(MainFieldInterface main) {
        final String checkValue = ((JTextField) main.getComponent(MainFieldInterface.POSTFACH)).getText();
        final String checkStrasse = ((JTextField) main.getComponent(MainFieldInterface.STRASSE)).getText();
        if (checkValue.equals("") || !checkStrasse.equals("")) {
            return false;
        }
        return true;

    }

    /**
     * @note: remove Card card = main.getEntity(); card.clearValue ,
     * resetAddressFieldValue(main) 2014/12/23 pmsid :4981.
     *
     */
    private void clearWhenNotChooseKdp(MainFieldInterface main) {
        // Card card = main.getEntity();
        main.resetState();
        main.displayToolTip();
        this.setUpdateMessage(main, false);
        AroundDialog.showMessageDialog(null, "Khong co ket qua nao duoc tim thay", "Thong tin",
                JOptionPane.INFORMATION_MESSAGE);
        // card.clearValue();
        // resetAddressFieldValue(main);
    }

    private void updateMapSearch(String name, String v_name, String plz, String ort, String strasse, String hausNummer,
            String hausuzat, String type, String timeSearch, String ort_origin, String strasse_origin) {
        this.searchKDPMap.clear();
        this.searchKDPMap.put("NAME", name);
        this.searchKDPMap.put("VONAME", v_name);
        this.searchKDPMap.put("PLZ", plz);
        this.searchKDPMap.put("ORT", ort);
        this.searchKDPMap.put("STRASSE", strasse);
        this.searchKDPMap.put("HAUSNUMMER", hausNummer);
        this.searchKDPMap.put("HAUSUZAT", hausuzat);
        this.searchKDPMap.put("TYPE", type);
        this.searchKDPMap.put("TIMESEARCH", timeSearch);
        this.searchKDPMap.put("ORTORIGIN", ort_origin);
        this.searchKDPMap.put("STRASSEORIGIN", strasse_origin);

    }

    /**
     * this is function utility for get hausnummer and hausnummerzusat.
     *
     * @param str
     * @return
     */
    private String[] spilitHauseNum(String str) {
        final String result[] = new String[2];
        String hausuzat = "";
        String hausNum = str;
        for (int j = 0; j < str.length(); j++) {
            if ((str.charAt(j) < '0') || (str.charAt(j) > '9')) {
                hausuzat = str.substring(j);
                hausNum = str.substring(0, j);
                break;
            }
        }
        result[0] = hausNum.trim();
        result[1] = hausuzat.trim();
        return result;
    }

    /**
     * this is function searchingProcess for lookup kdp specail and kdp normal.
     *
     * @return
     */
    private void setUpdateMessage(final MainFieldInterface main, final boolean visible) {
        if (!visible) {
            try {
                Thread.sleep(100);
            } catch (final InterruptedException e) {
                log.warn("", e);
            }
        }
        main.setProcessStatus(visible);
    }

    private void setEnableSomeField(boolean visible, MainFieldInterface main) {
        main.getComponent(MainFieldInterface.ZUSAT).setEnabled(visible);
        main.getComponent(MainFieldInterface.ANREDE).setEnabled(visible);
        main.getComponent(MainFieldInterface.STOCKWERK).setEnabled(visible);
        main.getComponent(MainFieldInterface.ADRESSZUSAT).setEnabled(visible);
        main.getComponent(MainFieldInterface.COADDRESS).setEnabled(visible);
        // main.getComponent(MainFieldInterface.LAND).setEnabled(visible);
        main.getComponent(MainFieldInterface.SAVE_BUTTON).setEnabled(visible);
        main.getComponent(MainFieldInterface.SAVE_MENU).setEnabled(visible);
    }

    private void disablePickPostField(MainFieldInterface main) {
        ((JTextField) main.getComponent(MainFieldInterface.PICKPOST)).setText("");
        ((JTextField) main.getComponent(MainFieldInterface.POSTLAGEND)).setText("");
        ((JTextField) main.getComponent(MainFieldInterface.MYPOST24)).setText("");
        main.getComponent(MainFieldInterface.PICKPOST).setEnabled(false);
        main.getComponent(MainFieldInterface.POSTLAGEND).setEnabled(false);
        main.getComponent(MainFieldInterface.MYPOST24).setEnabled(false);
    }

    private void disableStrasseHausnrField(MainFieldInterface main, boolean enabled) {
        if (!enabled) {
            ((JTextField) main.getComponent(MainFieldInterface.STRASSE)).setText("");
            ((JTextField) main.getComponent(MainFieldInterface.HAUSE)).setText("");
        }
        main.getComponent(MainFieldInterface.STRASSE).setEnabled(enabled);
        main.getComponent(MainFieldInterface.HAUSE).setEnabled(enabled);
    }

    private void checkInterrupted(String message) throws InterruptedException {
        if (Thread.interrupted()) {
            throw new InterruptedException(message);
        }
    }

    // this is new control make value kdp
    /**
     * function use when choose kdpid in searching kdpid.
     *
     * @param main
     */
    private void makeValueKDP(MainFieldInterface main) {
        final Card card = main.getEntity();
        final Map<String, String> vectorKDP = card.getVectorKDP();
        main.getComponent(MainFieldInterface.FIRMA).requestFocus();
        this.makeValueKDP(card, vectorKDP, main);

    }

    /**
     * function use when choose kdpid in searching kdpid has param.
     *
     */
    private void makeValueKDP(Card card, Map<String, String> vectorKDP, MainFieldInterface main) {

        if (vectorKDP == null) {
            card.clearValue();
        } else {
            if (!card.getCard().isKdpSpecial()) {
                this.disablePickPostField(main);
            } else {
                this.enablePickpostField(main); // nhung field duoc enable .
            }

            // Request #10890: Disable 'strasse' and 'hausnumber' when kdp is postfach, enable them when user press
            // 'Clear kdp'.
            if (this.getDataInKDP("is_postfach", false, vectorKDP).equalsIgnoreCase("x")) {
                this.disableStrasseHausnrField(main, false);
            } else {
                this.disableStrasseHausnrField(main, true);
            }

            this.getDataFromKdp(card.getCard().isKdpSpecial(), vectorKDP, main);
        }
    }

    /**
     * function fill data into main when data. check different when kdp and mask
     * capture on field haus, strasse, plz, ort.
     *
     * @param isKdpSpecial
     * @param vectorKdp
     * @param main
     */
    private void getDataFromKdp(boolean isKdpSpecial, Map<String, String> vectorKdp, MainFieldInterface main) {
        // pvgiang_1 -13/07/2016- UPDATE: Remove fields which are removed. View Lookupkey.java for detail!
        this.addDataIntoTextField(vectorKdp, main, isKdpSpecial, main.getComponent(MainFieldInterface.FIRMA));
        this.addDataIntoTextField(vectorKdp, main, isKdpSpecial, main.getComponent(MainFieldInterface.ZUSAT));
        this.addDataIntoTextField(vectorKdp, main, isKdpSpecial, main.getComponent(MainFieldInterface.ANREDE));
        this.addDataIntoTextField(vectorKdp, main, isKdpSpecial, main.getComponent(MainFieldInterface.VORNAME));
        this.addDataIntoTextField(vectorKdp, main, isKdpSpecial, main.getComponent(MainFieldInterface.NAME));
        this.addDataIntoTextField(vectorKdp, main, isKdpSpecial, main.getComponent(MainFieldInterface.PICKPOST));
        this.addDataIntoTextField(vectorKdp, main, isKdpSpecial, main.getComponent(MainFieldInterface.MYPOST24));

        this.addDataIntoTextFieldValue(vectorKdp, main, isKdpSpecial, main.getComponent(MainFieldInterface.PLZ), null);
        this.addDataIntoTextFieldValue(vectorKdp, main, isKdpSpecial, main.getComponent(MainFieldInterface.ORT), null);

        this.addDataIntoTextFieldValue(vectorKdp, main, isKdpSpecial, main.getComponent(MainFieldInterface.STRASSE),
                null);
        this.addDataIntoTextFieldValue(vectorKdp, main, isKdpSpecial, main.getComponent(MainFieldInterface.HAUSE),
                null);

        main.updateKDPID(this.getDataInKDP("kdpid", isKdpSpecial, vectorKdp));
        final String types = this.getDataInKDP("kdp_type", isKdpSpecial, vectorKdp);
        // pvgiang_1 -13/07/2016- TYPE 'P' is Person, 'O' is Company
        int type = 0;
        if (types.toUpperCase().equalsIgnoreCase("P")) {
            type = 1;
        } else {
            type = 2;
        }
        main.getEntity().setKdpType(type);

    }

    /**
     * until add Data into text Field.
     *
     * @param vectorKdp
     * @param main
     * @param isKdpSpecial
     * @param component
     */
    private String addDataIntoTextField(Map<String, String> vectorKdp, MainFieldInterface main, boolean isKdpSpecial,
            Component component) {
        final String name = component.getName();
        final String value = this.checkContraint(name, this.getDataInKDP(name, isKdpSpecial, vectorKdp),
                main.getEntity());
        ((JTextField) component).setText(value);
        return value;
    }

    /**
     * until add Data into text Field when value is not empty. when old Value
     *
     * @param vectorKdp
     * @param main
     * @param isKdpSpecial
     * @param component
     */
    private void addDataIntoTextFieldValue(Map<String, String> vectorKdp, MainFieldInterface main, boolean isKdpSpecial,
            Component component, String textData) {
        final String name = component.getName();
        final String value = this.checkContraint(name, this.getDataInKDP(name, isKdpSpecial, vectorKdp),
                main.getEntity());
        final String oldValue = ((JTextField) component).getText();
        /**
         * Disable CI_090
         */
//        /**
//         * CI_090: Do not fill Address Data when Operator select KDP if the
//         * Address (zip/city/street/hausnummer) has data
//         */
//
//        if (StringUtils.isNotBlank(oldValue) && (name.equalsIgnoreCase("plz") || name.equalsIgnoreCase("ort")
//                || name.equalsIgnoreCase("strasse") || name.equalsIgnoreCase("hausnummer"))) {
//            return;
//        }
        if (value.equals("") && isKdpSpecial) {
            return;
        }
        if (textData == null) {
            ((JTextField) component).setText(value);
        } else {
            ((JTextField) component).setText(textData);
        }

        if (component instanceof CustomTextField) {
            if (((textData == null) && !oldValue.equalsIgnoreCase(value))
                    || ((textData != null) && !oldValue.isEmpty())) {
                if (name.equalsIgnoreCase("plz")) { // plz only 4 digit
                    if (!value.substring(0, 4).equalsIgnoreCase(oldValue)) {
                        ((CustomTextField) component).setDifferent(true);
                        ((CustomTextField) component).changeBackGround();
                    } else {
                        ((CustomTextField) component).setDifferent(false);
                        ((CustomTextField) component).changeBackGround();
                    }
                } else {
                    ((CustomTextField) component).setDifferent(true);
                    ((CustomTextField) component).changeBackGround();
                }
            } else {
                ((CustomTextField) component).setDifferent(false);
                ((CustomTextField) component).changeBackGround();
            }
        }

    }

    /**
     * function get data from vector KDP.
     *
     * @param fieldName
     * @param kdp_special
     * @param vectorKDP
     * @return
     */
    private String getDataInKDP(String fieldName, boolean kdp_special, Map<String, String> vectorKDP) {
        return StateUtil.getDataInKDP(fieldName, kdp_special, vectorKDP);
    }

    private String checkContraint(String fieldName, String valueCheck, Card card) {
        final BLLCard bllCard = card.getCard();
        final BLLField field = bllCard.getField(fieldName);
        if ((field != null) && (field instanceof BLLAddressField)) {
            final String contraint = ((BLLAddressField) field).getConstraint();
            int changeCaseType = 0;
            try {
                changeCaseType = Integer.parseInt(Utilities.getdata_seperator(contraint, false, ";"));
            } catch (final NumberFormatException ex) {
                log.warn("", ex);
            } catch (final Exception ex) {
                log.warn("", ex);
            }
            valueCheck = this.changeCase(valueCheck, changeCaseType);
        }
        return valueCheck;
    }

    private String changeCase(String value, int type) {
        try {
            if (value.length() > 0) {
                return Utilities.changeCase(this.changeCase, value, type);
            }
        } catch (final Exception ex) {
            log.error(Utilities.getStackTrace(ex));
            return value;
        }
        return value;
    }

    public static void main(String arg[]) {
        String strasse = "abcstrasse strasse Belflori";
        final String notWordData = "-strasse;strasse;-str.;-str;-weg;" + "Boulevard;Blvd.;Bd.;Im;Am;Chemin;Ch-;Ch.;"
                + "Route;Rte.;Rte;Rue;Chalet;Impasse;Imp;Imp.;"
                + "Via;Zoneindustrie;Zoneindustriel;Zoneindustrielle;ZI;Z.I.;-gasse;";
        strasse = strasse.toLowerCase();
        final String[] notWords = notWordData.toLowerCase().split(";");

        if (notWords.length < 1) {
            return;
        }
        for (final String notWord : notWords) {
            if (notWord.contains("-")) {
                continue;
            }
            strasse = (" " + strasse + " ").replaceAll(" " + notWord + " ", "");
        }

        strasse = strasse.trim().split(" ")[0];
        for (final String notWord : notWords) {
            if (notWord.contains("-")) {
                if (notWord.startsWith("-")) {
                    if (strasse.endsWith(notWord.substring(1))) {
                        // strasse = strasse.replace(notWord.substring(1), "");

                        strasse = strasse.substring(0, (strasse.length() - notWord.length()) + 1);
                    }
                }
                if (notWord.endsWith("-")) {
                    if (strasse.startsWith(notWord.substring(0, notWord.length() - 1))) {
                        strasse = strasse.replaceFirst(notWord.substring(0, notWord.length() - 1), "");
                    }
                }
            }

            // strasse = (" "+ strasse+ " ").replaceAll(" "+notWord+" " , "");
        }
        System.out.println(strasse.trim());

        final String s = "a|b";

        final String[] ss = s.split("\\|");
        for (final String string : ss) {
            log.info(string);
        }
    }

}
