package com.ghp.vae.data_entry.ptl.state;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.bll.BLLDataStructure;
import com.ghp.vae.data_entry.common.Utilities;

import vae.client.transfer.LookupKey;

public class StateUtil {
	private static Logger log = LoggerFactory.getLogger(StateUtil.class);

	/**
	 * is util get data from kdp_special and kdp normal
	 *
	 * @param fieldName
	 * @param kdp_special
	 * @param vectorKDP
	 * @return
	 */
	public static String getDataInKDP(String fieldName, boolean kdp_special, Map<String, String> vectorKDP) {
		// int expan = kdp_special ? 1 : 0;
		if (fieldName.equals("firmenname")) {
			return Utilities.toString(vectorKDP.get(LookupKey.FIRMENNAME.getKey()));
		}
		if (fieldName.equals("vorname")) {
			return Utilities.toString(vectorKDP.get(LookupKey.VORNAME.getKey()));
		}
		if (fieldName.equals("name")) {
			return Utilities.toString(vectorKDP.get(LookupKey.NAME.getKey()));
		}

		if (fieldName.equals("namenszusatz")) {

			/**
			 * Remove '|' between NAMESUZAT_1("pers_11_name3") and NAMENSZUSATZ
			 */
			final String value = vectorKDP.get(LookupKey.NAMENSZUSATZ.getKey());

			if (value.indexOf(" | ") > 0) {
				return Utilities.toString(value.replace(" | ", " "));
			}

			return Utilities.toString(value);
		}

		if (fieldName.equals("plz")) {
			return Utilities.toString(vectorKDP.get(LookupKey.PLZ.getKey()));
		}

		if (fieldName.equals("ort")) {
			return Utilities.toString(vectorKDP.get(LookupKey.ORT.getKey()));
		}
		if (fieldName.equals("strasse")) {
			return Utilities.toString(vectorKDP.get(LookupKey.STRASSE.getKey()));
		}
		if (fieldName.equals("hausnummer")) {
			return Utilities.toString(vectorKDP.get(LookupKey.FULLHAUSNUMMER.getKey()));
		}
		if (fieldName.equals("postfachnummer")) {
			return Utilities.toString(vectorKDP.get(LookupKey.POSTFACHNUMMER.getKey()));
		}

		if (fieldName.equals("is_postfach")) {
			return Utilities.toString(vectorKDP.get(LookupKey.IS_POSTFACH.getKey()));
		}

		if (fieldName.equals("pickpostnummer")) {

			if (kdp_special) {
				// Update add data my post 24 into field pickpostnummer
				return Utilities.toString(vectorKDP.get(LookupKey.PICKPOST.getKey()));
			} else {
				return "";
			}
		}
		// need usser add size
		if (fieldName.equals("anrede")) {
			return Utilities.toString(vectorKDP.get(LookupKey.ANREDE.getKey()));
		}
		// if (fieldName.equals("namenszusatz")) {
		// return Utilities.toString(vectorKDP.get(9));
		// }
		// if (fieldName.equals("adresszusatz")) {
		// return Utilities.toString(vectorKDP.get(LookupKey.ADDRESSZUSATZ.getKey()));
		// }
		// if (fieldName.equals("co_addresse")) {
		// return Utilities.toString(vectorKDP.get(LookupKey.CO_ADRESSE.getKey()));
		// }
		// if (fieldName.equals("stockwerk")) {
		// return Utilities.toString(vectorKDP.get(LookupKey.STOCKWERK.getKey()));
		// }
		if (fieldName.equals("kdpid")) {
			return Utilities.toString(vectorKDP.get(LookupKey.KDP_ID.getKey()));
		}
		// if (fieldName.equals("land")) {
		// return Utilities.toString(vectorKDP.get(LookupKey.LANDCODE.getKey()));
		// }
		if (fieldName.equals("kdp_type")) { // *** Binh update kdp_type = PERS_08_TYP
			return Utilities.toString(vectorKDP.get(LookupKey.PERS_08_TYP.getKey()));
		}
		// if (fieldName.equals(BLLDataStructure.PERSIBS_FIELD)) {
		// return Utilities.toString(vectorKDP.get(LookupKey.PERSIBS_FIELD.getKey() ));
		// }
		// if (fieldName.equals(BLLDataStructure.ORTZIBS_FIELD)) {
		// return Utilities.toString(vectorKDP.get(LookupKey.ORTZIBS_FIELD.getKey() ));
		// }
		// if (fieldName.equals(BLLDataStructure.ORTZTYP_FIELD)) {
		// return Utilities.toString(vectorKDP.get(LookupKey.ORTZTYP_FIELD.getKey() ));
		// }
		// if (fieldName.equals("namezusat_1")) {
		// return Utilities.toString(vectorKDP.get(LookupKey.NAMESUZAT_1.getKey() ));
		// }
		if (fieldName.equals("adr_id")) {
			return Utilities.toString(vectorKDP.get(LookupKey.ADR_ID.getKey()));
		}
		if (fieldName.equals("postlagend")) {
			return "";
		}
		// if (fieldName.equals(BLLDataStructure.AMP_STATUS) && !kdp_special) {
		// log.debug("amp_status : " + Utilities.toString(vectorKDP.get(vae.client.transfer.LookupKey.AMP_STATUS.getKey() )));
		// return Utilities.toString(vectorKDP.get(LookupKey.AMP_STATUS.getKey() ));
		// }
		if (fieldName.equals(BLLDataStructure.HAUSKEY) && !kdp_special) {
			log.debug("hauskey : " + Utilities.toString(vectorKDP.get(LookupKey.HAUSKEY.getKey())));
			return Utilities.toString(vectorKDP.get(LookupKey.HAUSKEY.getKey()));
		}
		// s
		if (fieldName.equals(BLLDataStructure.MYPOST24)) {
			if (kdp_special) {
				String value = "";
				try {
					value = Utilities.toString(vectorKDP.get(LookupKey.MY_POST_24.getKey()));
				} catch (final Exception ex) {
				}
				return value;
			} else {
				return "";
			}
		}
		return null;
	}

}
