package com.ghp.vae.data_entry.face;

import com.ghp.vae.data_entry.entity.Card;

import javax.jms.JMSException;
import java.awt.*;

public interface MainFieldInterface {

	byte LOOKUP = 1;
	byte FIRMA = 2;
	byte ZUSAT = 3;
	byte ANREDE = 4;
	byte VORNAME = 5;
	byte NAME = 6;
	byte PLZ = 7;
	byte ORT = 8;
	byte STRASSE = 9;
	byte HAUSE = 10;
	byte LAND = 11;
	byte POSTFACH = 12;
	byte STOCKWERK = 13;
	byte ADRESSZUSAT = 14;
	byte COADDRESS = 15;
	byte PICKPOST = 16;
	byte MYPOST24 = 17;
	byte POSTLAGEND = 18;
	byte BADREASON = 19;
	byte OCRINFORMATION =20;
	byte SAVE_BUTTON= 21;
	byte SAVE_MENU= 22;
	byte SEARCH_BUTTON= 23;
	byte KDPID_FIELD= 24;
	byte IMAGE_VIEW= 25;
	byte FRAME_VIEW= 26;
	void validate(String field, String value);

	void addStatus(int cardAmount, float speed);
	void addStatus(long startTime, long endTime);

	// new implement.
	void changeState(StateCapture state);

	void request(ObjectInformation information, MainFieldInterface main);
	void defaultState(StateCapture state);

	void resetState();

	String getFieldValue(byte field);
	
//	void enablePickPostField();
	Component getComponent(byte field);
	void hiddenToolTip();
	void displayToolTip();
	void clearTooltip();
	void loadImageAvailable();
	void allEnable(boolean enable);
	void resetGui();
	void setProcessStatus(boolean visible);
	void setProcessLoadCard(boolean visible);
	void setStatusCard(String status);
	void setStatus(String status);
	void doExit(boolean b);
	void showStatus(String msg) ;
	void processThread();
	
	// can chinh sua them
	
	Card getEntity();
	void setEntity(Card card);
	String getLand (String value,String defaulValue);
	String getBadRepondcode(String badCard);
	
// co gang bo load default value.
	void loadDataCard();
	void updateKDPID(String kdpid) ;
	void defaultFocus();
	void loadCardEvent(boolean startGettingCard) throws JMSException;

	void learn();
	void clearKDP();
}
