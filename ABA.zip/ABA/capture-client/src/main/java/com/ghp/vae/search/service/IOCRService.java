/*
 * Class: IOCRService
 *
 * Created on Mar 8, 2016
 *
 * (c) Swiss Post Solutions Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solutions Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package com.ghp.vae.search.service;

import java.util.List;

import com.ghp.vae.search.model.ocr.FirmaSign;

/**
 * The Interface IOCRCheckingService.
 */
public interface IOCRService extends ILookupProxyService {

    /**
     * Count existing kdp.
     *
     * @param kdp the kdp
     * @return the int
     */
    int countExistingKDP(final String kdp);

    /**
     * Count existing ort.
     *
     * @param ort the ort
     * @return the int
     */
    int countExistingOrt(final String ort);

    /**
     * Count existing plz.
     *
     * @param plz should be in integer format.
     * @return the int
     */
    int countExistingPlz(final String plz);

    /**
     * Count existing strasse.
     *
     * @param strasse the strasse
     * @return the int
     */
    int countExistingStrasse(final String strasse);

    /**
     * Gets the all firma sign.
     *
     * @return the all list firma signs even when the list is empty
     */
    List<FirmaSign> getAllFirmaSign();
}
