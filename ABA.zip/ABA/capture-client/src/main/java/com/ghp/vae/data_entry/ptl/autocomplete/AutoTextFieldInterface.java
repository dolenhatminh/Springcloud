package com.ghp.vae.data_entry.ptl.autocomplete;

public interface AutoTextFieldInterface {
	 void setDataSource(AutoTextFieldDataSourceInf ds);
	 void setConstraint(int maxLength, String invalidCharacter); 
	 void setUseSuggestion(boolean useSuggestion);
}
