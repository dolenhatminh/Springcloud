package com.ghp.vae.data_entry.common.autocomplete;

import java.awt.*;
import java.util.Vector;

public class VaeFocusTraversalPolicy extends FocusTraversalPolicy {
	private Vector<Component> order;
	private Vector<Container> orders;
	public VaeFocusTraversalPolicy() {
		order = new Vector<Component>();
		orders = new Vector<Container>();
	}
	
	public VaeFocusTraversalPolicy(Vector<Component> order, Vector<Container> orders){
		this();
		this.order.addAll(order);
		this.orders.addAll(orders);
	}
	public Component getComponentAfter(Container aContainer, Component aComponent) {
		int idx = order.indexOf(aComponent);
		if(idx < 0){
			return null;
		}
		if(idx +1 >  order.size()){
			return null;
			
		}
		idx = idx + 1 ;
        Component check = order.get(idx);
        if(check.isEnabled()){
            return check ;
        }else{
            for (int i = 0 ;i < order.size();i++ ){
            	idx ++ ;
//            	idx = idx % order.size();
            	try{
	            	if(order.get(idx).isEnabled()){
	            		return  order.get(idx);
	            	}
            	}catch(Exception ex){
            		return aComponent;
            	}
            }
        }
        return null;
	}

	
	public Component getComponentBefore(Container aContainer, Component aComponent) {
		int idx = (order.indexOf(aComponent) - 1 ) ;
        if(idx <0){
            idx = order.size()-1;
        }
        Component check = order.get(idx);
        if(check.isEnabled()){

            return check ;
        }else{
            for (int i = 0 ;i < order.size();i++ ){
            	idx -- ;
            	if(idx <0){
            		idx = order.size()-1;
            	}
            	if(order.get(idx).isEnabled())
            		return order.get(idx);
            }
        }
        return null;
	}

	
	public Component getDefaultComponent(Container aContainer) {
		int index =orders.indexOf(aContainer);
        if (index == orders.size()-1){
        	return null;
        }
        return  orders.get(index+1);
	}

	
	public Component getFirstComponent(Container aContainer) {
		return order.firstElement();
	}
	
	public void addComponent (Component component){
		order.add(component);
	}

	public void addComponentIndex (int index ,Component component){
		order.add(index,component);
	}
	
	public void addContainer (Container component){
		orders.add(component);
	}

	public void addContainerIndex (int index ,Container component){
		orders.add(index,component);
	}
	public Component getLastComponent(Container aContainer) {
		return order.lastElement();
	}

}
