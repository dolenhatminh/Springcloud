package com.ghp.vae.data_entry.face;

import com.ghp.vae.data_entry.entity.Card;

public interface SaveCardInterface {
	boolean checkValidServer();
	boolean saveCard(Card card) throws Exception; // return true false ,exeception .
	void doExit();
	void setChangeCase(String[] changeCase);
	void setMainField(MainFieldInterface mainField);

}
