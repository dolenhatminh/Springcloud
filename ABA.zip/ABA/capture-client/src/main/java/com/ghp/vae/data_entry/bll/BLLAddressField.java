/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ghp.vae.data_entry.bll;
/**
 *
 * @author vtbinh
 */
public class BLLAddressField extends BLLField implements Cloneable{
    private String typed;
    private String constraint;
    private String lookupTable;
    private String lookupField;

    public BLLAddressField(String name, String value, String typeid, String typed, String constraint, String lookupTable, String lookupField) {
        super(name, value, typeid);
        this.typed = typed;
        this.constraint = constraint;
        this.lookupTable = lookupTable;
        this.lookupField = lookupField;
    }
    
    @Override
    public BLLAddressField clone() throws CloneNotSupportedException
    {
        return (BLLAddressField) super.clone();
    }
    //<editor-fold defaultstate="collapsed" desc="get/set functions">
    public String getConstraint() {
        return constraint;
    }

    public void setConstraint(String constraint) {
        this.constraint = constraint;
    }

    public String getLookupField() {
        return lookupField;
    }

    public void setLookupField(String lookupField) {
        this.lookupField = lookupField;
    }

    public String getLookupTable() {
        return lookupTable;
    }

    public void setLookupTable(String lookupTable) {
        this.lookupTable = lookupTable;
    }


    public String getTyped() {
        return typed;
    }

    public void setTyped(String typed) {
        this.typed = typed;
    }
    //</editor-fold>
   
    @Override
    public String toString(){
        return this.typed;
    }
}
