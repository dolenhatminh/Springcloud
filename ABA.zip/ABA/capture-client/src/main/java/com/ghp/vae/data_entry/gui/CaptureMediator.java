package com.ghp.vae.data_entry.gui;

import javax.swing.*;

import java.awt.*;

interface CaptureMediator {

	void saveButton();
	void search();	
	void rotataRight();
	void rotataLeft();
	void clearData();
	
	void saveMenuItem();
	void exit();
	void help();
	void about();
	void setUseSuggestion(boolean useSuggestion);
	
	void setButtonBar(ButtonBar buttonBar);
	void setCapturePanel(CapturePanel capturePanel);
	void setDisplayPanel(DisplayPanel displayPanel);
	void setImagePanel(ImagePanel imagePanel);
	void setInfoPanel(InfoPanel infoPanel);
	void setMenubar(MenuBar menubar);
	void setMainFrame(UIMainFrame mainFrame);
	void getLookup(Component lookup);
	void viewInfo(String name);
	void enableFieldWhenFocusPickpost();
	void getOcrInformation(Component component, byte index);
	void getReLoadData(JTextField textField);
	void ocrCropImage(byte[] cropImage);
	void enableSaveButton(boolean b);
	void firstEnterLookup();
	void swapVornameNachname(String vorname, String nachname, int validPercent);
	void activeWindows();
	Component getProcessLoadCard();
	void clearKDP();
	
	// CI123: PRESS F9 TO COPY VORNAME TO NAME
	void moveVornameName(String firmaName, String zusatzName, String indexType, String value, Component component);
	
	// ABA-68 - CI-116: Rollback KDP, hot key: F8
	void rollBackKDP();
}
