/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ghp.vae.data_entry.bll;

import com.ghp.vae.data_entry.entity.UserName;

import java.sql.Timestamp;

/**
 *
 * @author vtbinh
 */
public class BLLSession {
    private UserName user;
    private Timestamp startTime;
    private Timestamp endTime;

    public BLLSession() {
    }
    public BLLSession(UserName username) {
        this.user = username;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }


    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public UserName getUser() {
        return user;
    }

    public void setUser(UserName user) {
        this.user = user;
    }
    
    String getUsername(){
    	return user.getUserName();
    }
    
    
    //</editor-fold>
}
