/*
 * Class: ILookupProxyService
 *
 * Created on Mar 8, 2016
 *
 * (c) Swiss Post Solutions Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solutions Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package com.ghp.vae.search.service;

import java.util.Map;

/**
 * The Interface ILookupProxyService.
 */
public interface ILookupProxyService {

    /**
     * Normalize.
     *
     * @param string the string
     * @return the string
     */
    String normalize(final String string);

    /**
     * Pre-process the search term before sending to elastic Add slash (\)
     * before + and ' Add % at the end of search term if ';' is not the last
     * character
     *
     * @param value {@link String} the search term
     * @return {@link String} the processed data
     */
    String processdata(String value);

    /**
     * Call the remote API for data
     *
     * @param params {@link Map} the request parameter in pair: key-value
     * @param remoteUrl {@link String} the end point
     * @throws {@link Exception} throw exception when cannot connect to remote
     * or timed-out reach
     * @return {@link String} the response in text
     */
    String callRemote(Map<String, String> params, String remoteUrl) throws Exception;

    /**
     * Call the remote API for data
     *
     * @param params {@link Map} the request parameter in pair: key-value
     * @param remoteUrl {@link String} the end point
     * @return {@link String} the response in text
     */
    String callPostRemote(Map<String, String> params, String remoteUrl) throws Exception;
}
