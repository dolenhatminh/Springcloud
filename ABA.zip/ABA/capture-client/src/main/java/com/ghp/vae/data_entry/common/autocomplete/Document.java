package com.ghp.vae.data_entry.common.autocomplete;

import com.ghp.vae.data_entry.common.Utilities;

import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public class Document extends PlainDocument {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4308582067971462896L;

	boolean selecting = false;

	boolean strictMatching;
	private String checkString;
	private boolean check = false;
	private int maxLength;
	AbstractComponentAdaptor adaptor;

	public Document(AbstractComponentAdaptor adaptor, boolean strictMatching) {
		this.adaptor = adaptor;
		this.strictMatching = strictMatching;
		Object selected = adaptor.getSelectedItem();
		if (selected != null)
			setText(selected.toString());
		adaptor.markEntireText();
	}

	public Document(AbstractComponentAdaptor adaptor, boolean strictMatching, String checkString, int maxLength) {
		this(adaptor, strictMatching);
		this.checkString = checkString;
		this.maxLength = maxLength;
		check = !checkString.equals("");
	}

	public boolean isStrictMatching() {
		return strictMatching;
	}

	public void remove(int offs, int len) throws BadLocationException {
		if (selecting)
			return;
		super.remove(offs, len);
		if (!strictMatching) {
			setSelectedItem(getText(0, getLength()));
			adaptor.getTextComponent().setCaretPosition(offs);
		}
	}

	public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
		if (selecting)
			return;
		if (check) {
			if (this.getEndPosition().getOffset() <= this.maxLength) {
				if (str == null)
					return;
				char[] addedFigures = str.toCharArray();
				char c;
				for (int i = addedFigures.length; i > 0; i--) {
					c = addedFigures[i - 1];
					if (!Utilities.inString(checkString, c)) {
						try {
							super.insertString(offs, new String(new Character(c).toString()), a);
						} catch (Exception ex) {
						}
					}
				}
			}
		}else{
			super.insertString(offs, str, a);
		}
		Object item = lookupItem(getText(0, getLength()));
		if (item != null) {
			setSelectedItem(item);
		} else {
			if (strictMatching) {
				item = adaptor.getSelectedItem();
				offs = offs - str.length();
				UIManager.getLookAndFeel().provideErrorFeedback(adaptor.getTextComponent());
			} else {
				item = getText(0, getLength());
				setSelectedItem(item);
			}
		}
		setText(item == null ? "" : item.toString());
		adaptor.markText(offs + str.length());
	}

	private void setText(String text) {
		try {
			// remove all text and insert the completed string
			super.remove(0, getLength());
			super.insertString(0, text, null);
		} catch (BadLocationException e) {
			throw new RuntimeException(e.toString());
		}
	}

	private void setSelectedItem(Object item) {
		selecting = true;
		adaptor.setSelectedItem(item);
		selecting = false;
	}

	private Object lookupItem(String pattern) {
		Object selectedItem = adaptor.getSelectedItem();
		if (selectedItem != null && startsWithIgnoreCase(selectedItem.toString(), pattern)) {
			return selectedItem;
		} else {
			for (int i = 0, n = adaptor.getItemCount(); i < n; i++) {
				Object currentItem = adaptor.getItem(i);
				if (currentItem != null && startsWithIgnoreCase(currentItem.toString(), pattern)) {
					return currentItem;
				}
			}
		}
		return null;
	}

	private boolean startsWithIgnoreCase(String string1, String string2) {
		return string1.toUpperCase().startsWith(string2.toUpperCase());
	}
}