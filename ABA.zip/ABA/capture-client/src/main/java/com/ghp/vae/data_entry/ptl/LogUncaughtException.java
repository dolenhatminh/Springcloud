package com.ghp.vae.data_entry.ptl;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogUncaughtException implements Thread.UncaughtExceptionHandler {
	Logger log = LoggerFactory.getLogger(LogUncaughtException.class);
	@Override
	public void uncaughtException(Thread t, Throwable e) {
		log.debug(t.getName(), e);
	}

}
