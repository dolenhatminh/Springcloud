package com.ghp.vae.data_entry.ptl;

import com.ghp.vae.data_entry.common.EncryptionHelper;

public class Test_Config {
	public static void main(String arg[]){
		System.out.println(EncryptionHelper.encrypt("1qa@WS3ed"));
	}
}
