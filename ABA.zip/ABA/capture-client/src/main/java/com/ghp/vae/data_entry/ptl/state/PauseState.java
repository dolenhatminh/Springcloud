package com.ghp.vae.data_entry.ptl.state;

import com.ghp.vae.data_entry.bll.BLLoadCard;
import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.ObjectInformation;
import com.ghp.vae.data_entry.gui.ActiveMQClient;
import com.sps.vn.config.ApplicationConfig;
import com.sps.vn.writing.datasource.WritingBaseDAL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.JMSException;
import javax.swing.*;

import java.util.HashMap;

/**
 * this is class handle capture client when use save button.
 * @author vmhoang
 *
 */
class PauseState implements ReloadState{
	
	private BLLoadCard loadCard;
	private LoadCardState loadCardState;
	private static Logger  log = LoggerFactory.getLogger("Pause");
	
	private final String userDir = System.getProperty("user.dir");

	@Override
	public void reloadStatus() {
	}
	
	public PauseState(BLLoadCard loadCard) {
		this.loadCard = loadCard;
	}
	
	void setLoadCardState(LoadCardState loadCardState){
		this.loadCardState = loadCardState;
	}
	
	/**
	 * function handle Event : PAUSE, SAVE_CARD_BUTTON, EXIT
	 * @throws JMSException 
	 */
	public void handleEvent(ObjectInformation	 information, MainFieldInterface main) {
		byte action = information.getAction();
		switch (action){
			case PAUSE:
				openPauseCapture(information , main);
				break;
			case SAVE_CARD_BUTTON:
				
				openSaveCardLoad(information , main);
				break;
			case EXIT:
				exitCapture();
				break;
		}
	}
	
	/**
	 * function is action when exit Capture.
	 */

	private void exitCapture() {
		try{
			loadCard.checkOut();
		}catch(Exception ex){
			
		}
		WritingBaseDAL baseDAL = new WritingBaseDAL();
		baseDAL.releaseALLConnection();
		System.exit(0);
	}

	private void openPauseCapture(ObjectInformation information, MainFieldInterface main) {
		pauseCapture(main);
	}

	/**
	 * action start capturing. Create stateCapture is LoadCard.
	 * @param main
	 */
	private void openSaveCardLoad(ObjectInformation information, MainFieldInterface main) {
		log.info("[Capture][PAUSE] end pause");
		startCapture(main);
		loadCardState.reloadStatus();
		main.changeState(loadCardState );
		information.setAction(LOAD_PAUSE);
		
		main.request(information, main);
	}
	
	
	ActiveMQClient client;
	/**
	 * update icon, disable some field
	 * @throws JMSException 
	 */
	private void pauseCapture(MainFieldInterface main ) {
		log.info("[Capture][PAUSE] begin pause");
		main.resetGui();
		log.debug("after resetGui");
		main.showStatus("Stoped");
		JButton save = (JButton) main.getComponent(MainFieldInterface.SAVE_BUTTON);
		        
		save.setIcon(new javax.swing.ImageIcon(userDir + "/resources/img/start.png"));
		save.setEnabled(true);
		JButton search = (JButton) main.getComponent(MainFieldInterface.SEARCH_BUTTON);
		search.setEnabled(false);
		loadCard.pause(true);
		main.loadImageAvailable();
		main.allEnable(false);
		main.getComponent(MainFieldInterface.LOOKUP).requestFocus();
		log.info("VAE Capture pause capture");
		
		// *** Killing Softly
		new Thread(){				
			@Override
			public void run() {
				if(ApplicationConfig.getInstance().getWorking2ProjectConfig().isConnectToBrokerActiveMQ()){
					try {				
					
						if(client == null){
							client = new ActiveMQClient();
						}
						
						HashMap<String, String> message = ApplicationConfig.getInstance().getWorking2ProjectConfig().getResumeCmd();
						client.sendCommand(message, ApplicationConfig.getInstance().getWorking2ProjectConfig().getActiveMQJmsTimeout());
					
					} catch(javax.jms.IllegalStateException ise){
						AroundDialog.showMessageDialog(null, Utilities.getStackTrace(ise), "Canh bao", JOptionPane.WARNING_MESSAGE);
						log.error("", ise);
					} catch (Exception e) {
						log.error("", e);
					}
				}
			}
		}.start();
		
	}
	
	/**
	 * 
	 * @param main
	 * @see #pauseCapture(MainFieldInterface).
	 */
	private void startCapture(MainFieldInterface main){
		main.allEnable(true);
		loadCard.pause(false);
		JButton save = (JButton) main.getComponent(MainFieldInterface.SAVE_BUTTON);
		save.setIcon(new javax.swing.ImageIcon(userDir + "/resources/img/disk_blue.png"));
		save.setEnabled(false);
		JButton search = (JButton) main.getComponent(MainFieldInterface.SEARCH_BUTTON);
		search.setEnabled(true);
		main.getComponent(MainFieldInterface.VORNAME).requestFocus();
		log.info("VAE Capture starting capture");
	}
}
