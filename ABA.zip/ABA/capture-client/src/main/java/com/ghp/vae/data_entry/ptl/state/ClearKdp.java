package com.ghp.vae.data_entry.ptl.state;

import com.ghp.vae.data_entry.bll.BLLAddressField;
import com.ghp.vae.data_entry.bll.BLLCard;
import com.ghp.vae.data_entry.bll.BLLDataStructure;
import com.ghp.vae.data_entry.bll.BLLField;
import com.ghp.vae.data_entry.entity.Card;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.ObjectInformation;

import java.util.Iterator;

public class ClearKdp implements ReloadState {

	@Override
	public void handleEvent(ObjectInformation information, MainFieldInterface main) {
		switch (information.getAction()) {
		case CLEAR_KDPID:
			clearKDPID(main);
			break;
		default:
			break;
		}
	}

	private void clearKDPID(MainFieldInterface main) {
		Card card = main.getEntity();
		if(card.getVectorKDP() == null){
			main.resetState();
			return;
		}
		card.clearValue();
		enablePickpostField(main);
		resetAddressFieldValue(main);
		main.resetState();
	}

	@Override
	public void reloadStatus() {

	}

	private void resetAddressFieldValue(MainFieldInterface main) {
		BLLCard bllCard = main.getEntity().getCard();
		Iterator<BLLField> fields = bllCard.getFieldList().values().iterator();
		while (fields.hasNext()) {
			BLLField field = (BLLField) fields.next();
			if (field instanceof BLLAddressField) {
				field.setValue("");
			}
		}
		bllCard.getField(BLLDataStructure.KDPID_FIELD).setValue("");
		main.updateKDPID("");
		bllCard.getField(BLLDataStructure.ADDRESSTYPE_FIELD).setValue("");
		bllCard.getField(BLLDataStructure.PERSIBS_FIELD).setValue("");
		bllCard.getField(BLLDataStructure.ORTZIBS_FIELD).setValue("");
		bllCard.getField(BLLDataStructure.ORTZTYP_FIELD).setValue("");
		bllCard.getField(BLLDataStructure.ANREDEID_FIELD).setValue("");
	}
	
	private void enablePickpostField(MainFieldInterface main){
		main.getComponent(MainFieldInterface.PICKPOST).setEnabled(true);
		main.getComponent(MainFieldInterface.POSTLAGEND).setEnabled(true);
		main.getComponent(MainFieldInterface.MYPOST24).setEnabled(true);
		
	}
	
}
