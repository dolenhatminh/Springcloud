package com.ghp.vae.data_entry.gui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


class ButtonBar extends JPanel implements ActionListener{

	private String SAVE   = "SAVE";
	private String SEARCH = "SEARCH";
	private String LEFT   = "LEFT";
	private String RIGHT  = "RIGHT";
	private String CLEAR  = "CLEAR";
	
	private javax.swing.JButton jbtnZoomOut;
	private javax.swing.JButton jbtnZoomIn;
	private javax.swing.JButton jbtnRotateRight;
	private javax.swing.JButton jbtnRotateLeft;
	private javax.swing.JButton jbtnSearch;
	private javax.swing.JButton jbtnSave;
	private javax.swing.JCheckBox jckbClear;
	
	private CaptureMediator meditor;
	
	void setMediator(CaptureMediator meditor) {
		this.meditor = meditor;
	}
	ButtonBar() {
		initComponent();
	}
	/*
	 * init gui
	 */
	private void initComponent(){
		
		jbtnZoomOut = new javax.swing.JButton();
		jbtnZoomIn = new javax.swing.JButton();
		
		jbtnRotateRight = new javax.swing.JButton();
		jbtnRotateLeft = new javax.swing.JButton();
		
		jbtnSearch = new javax.swing.JButton();
		jbtnSave = new javax.swing.JButton();
		jckbClear = new javax.swing.JCheckBox();
		
                String userDir = System.getProperty("user.dir");
//                String filePath = userDir + "/" + xmlFile;
		
		jbtnZoomIn.setIcon(new javax.swing.ImageIcon(userDir + "/resources/img/zoom_in.png")); // NOI18N
		jbtnZoomOut.setIcon(new javax.swing.ImageIcon(userDir +"/resources/img/zoom_out.png")); // NOI18N
		jbtnRotateLeft.setIcon(new javax.swing.ImageIcon(userDir +"/resources/img/undo.png")); // NOI18N
		jbtnRotateRight.setIcon(new javax.swing.ImageIcon(userDir +"/resources/img/redo.png")); // NOI18N
		jbtnSave.setIcon(new javax.swing.ImageIcon(userDir +"/resources/img/disk_blue.png"));
		jbtnSearch.setIcon(new javax.swing.ImageIcon(userDir +"/resources/img/find.png")); // NOI18N
		jckbClear.setFont(new java.awt.Font("SansSerif", 0, 11));
		jckbClear.setMnemonic('r');
		jckbClear.setText("Clear");
		
		//set command action.
		jbtnRotateLeft.setActionCommand(LEFT);
		jbtnRotateRight.setActionCommand(RIGHT);
		jbtnSave.setActionCommand(SAVE);
		jbtnSearch.setActionCommand(SEARCH);
		jckbClear.setActionCommand(CLEAR);

		//add action listerning
		jbtnRotateLeft.addActionListener(this);
		jbtnRotateRight.addActionListener(this);
		jbtnSave.addActionListener(this);
		jbtnSearch.addActionListener(this);
		jckbClear.addActionListener(this);
		

		org.jdesktop.layout.GroupLayout gl_jPanel2 = new org.jdesktop.layout.GroupLayout(this);
		this.setLayout(gl_jPanel2);
		gl_jPanel2.setHorizontalGroup(gl_jPanel2.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING).add(
				gl_jPanel2.createSequentialGroup().add(jbtnZoomOut, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
						.add(jbtnZoomIn, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
						.add(jbtnRotateRight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
						.add(jbtnRotateLeft, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
						.add(jbtnSearch, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
						.add(jbtnSave, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 34, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE).add(18, 18, 18).add(jckbClear)
						.addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		
		gl_jPanel2.setVerticalGroup(gl_jPanel2.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING).add(
				gl_jPanel2
						.createSequentialGroup()
						.add(gl_jPanel2
								.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
								.add(jckbClear)
								.add(org.jdesktop.layout.GroupLayout.TRAILING,
										gl_jPanel2.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
												.add(org.jdesktop.layout.GroupLayout.LEADING, jbtnSave, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, Short.MAX_VALUE)
												.add(org.jdesktop.layout.GroupLayout.LEADING, jbtnSearch, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, Short.MAX_VALUE)
												.add(org.jdesktop.layout.GroupLayout.LEADING, jbtnZoomOut, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, Short.MAX_VALUE)
												.add(org.jdesktop.layout.GroupLayout.LEADING, jbtnZoomIn, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, Short.MAX_VALUE)
												.add(org.jdesktop.layout.GroupLayout.LEADING, jbtnRotateRight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, Short.MAX_VALUE)
												.add(jbtnRotateLeft, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, Short.MAX_VALUE))).addContainerGap()));
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String actionCommand = e.getActionCommand();
		if(actionCommand.equals(SAVE)){
			meditor.saveButton();
			return;
		}
		if(actionCommand.equals(SEARCH)){
			meditor.search();
			return;
		}
		if(actionCommand.equals(LEFT)){
			meditor.rotataLeft();
			return;
		}
		if(actionCommand.equals(RIGHT)){
			meditor.rotataRight();
			return;
		}
		if(actionCommand.equals(CLEAR)){
			jckbClear.setSelected(false);
			meditor.clearData();
			return;
		}
		
	}
	void setEnableSave(boolean disableLookup) {
		jbtnSave.setEnabled(disableLookup);
	}
	
	JButton getJbtnSearch() {
		return jbtnSearch;
	}
	JButton getJbtnSave() {
		return jbtnSave;
	}
	public void enableSaveButton(boolean b) {
		jbtnSave.setEnabled(b);
	}
	
	
}
