package com.ghp.vae.search.service;

import com.ghp.vae.data_entry.ptl.autocomplete.service.dto.ItemSearchResult;
import java.util.List;

public interface IWordSuggestionService {

    /**
     * call to the searching service to suggest
     *
     * @param word
     * @return list of the items search result
     * @throws Exception
     */
    public List<ItemSearchResult> suggest(String word) throws Exception;

    /**
     * Accept with this word
     *
     * @param indexWord
     * @throws Exception
     */
    public void accept(int indexWord) throws Exception; //update accept indexWord in list suggestion

    public void learn(String word) throws Exception;

    void clearSelection();
}
