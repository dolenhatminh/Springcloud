package com.ghp.vae.data_entry.face;

import com.ghp.vae.data_entry.entity.Card;

public interface ValidateCardInterface {
	boolean checkValidate(Card card);
	void setMainField(MainFieldInterface mainField);
}
