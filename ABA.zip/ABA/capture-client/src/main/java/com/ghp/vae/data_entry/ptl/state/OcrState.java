package com.ghp.vae.data_entry.ptl.state;

import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.ObjectInformation;
import com.ghp.vae.data_entry.face.StateCapture;
import com.ghp.vae.data_entry.ptl.OCRInformation;
import com.ghp.vae.data_entry.ptl.autocomplete.CustomTextField;
import com.ghp.vae.search.model.ObjectSearch;
import com.sps.vn.config.ApplicationConfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vae_ocr.OCR.OCRProcessing;

import javax.swing.*;

import java.awt.*;

class OcrState implements ReloadState {

    private OCRProcessing ocr;

    private Thread aliveThread;
    private static Logger log = LoggerFactory.getLogger("OCRProccessing");
    
    private static int countLookup;

    public OcrState(OCRProcessing ocr) {
        this.ocr = ocr;
//		logOcr = ConfigInfo.getOCRLog();
        OcrState.countLookup = 0;
    }

    @Override
    public void reloadStatus() {
    }

    /**
     * handle event ocr of capture client <br/>
     * capture : OCR_IMAGE, CANCEL_PROCESS, EXIT.
     *
     */
    public void handleEvent(ObjectInformation information, MainFieldInterface main) {
        int action = information.getAction();
        switch (action) {
            case OCR_IMAGE:
                openOCRImage(information, main);
                break;
            case CANCEL_PROCESS:
                System.out.println(" --- CANCEL OCR PROCESS ---");
                cancelProcess(information, main);
                break;
            case EXIT:
                openPopupCannotNotExit("Dang OCR");
                break;
            default:
                log.info("This type of action is not support in OcrState: " + action);
                break;
        }
    }

    /**
     * open form when exit.
     *
     * @param message
     */
    private void openPopupCannotNotExit(String message) {
        AroundDialog.showMessageDialog(null, message, "Canh bao", JOptionPane.WARNING_MESSAGE);
    }

    private void cancelProcess(ObjectInformation information, MainFieldInterface main) {
        if (aliveThread != null && aliveThread.isAlive()) {
//			aliveThread.stop();
            // need check
            aliveThread.interrupt();
        }
        main.setProcessStatus(false);
        main.getComponent(MainFieldInterface.FIRMA).requestFocus();
        main.resetState();
    }

    private void openOCRImage(ObjectInformation information, MainFieldInterface main) {
        if (ocr == null) {
            main.getComponent(MainFieldInterface.FIRMA).requestFocus();
            main.resetState();
            return;
        }
        try {
            Object source = information.getSource();
            byte[] cropImage = (byte[]) source;
            int mbImage = cropImage.length / 1024;
            if (mbImage > ApplicationConfig.getInstance().getOcrConfig().getSize()) {
                main.getComponent(MainFieldInterface.FIRMA).requestFocus();
                main.resetState();
                return;
            }
            main.hiddenToolTip();
            orcProcess(cropImage, main);
        } catch (Exception ex) {
            log.error("", ex);
        } finally {
            main.getComponent(MainFieldInterface.FIRMA).requestFocus();
        }

    }

    /**
     * connect to server ocr.
     *
     * @param data
     * @param main
     */
    private void orcProcess(final byte[] data, final MainFieldInterface main) {
        main.setStatus("OCR Processing ...");
        aliveThread = new Thread() {
            public void run() {
                try {
                    // print logback's internal status
//					statusOcr =1;
                    log.info("[Capture]-[COLLECTION:" + main.getEntity().getCard().getManagementID() + "][OCR]-send data ocr");
                    try {
                        ocr.doOCRArray(data, "", "", "");
                    } catch (java.net.SocketTimeoutException ste) {
                        // ignore this exception
                        JOptionPane.showMessageDialog(null, "OCR Khong tim thay ket qua");
                        log.error("", ste);
                    } catch (org.apache.http.impl.execchain.RequestAbortedException rae) {
                        // ignore this exception
                        log.error("", rae);
                    } catch (java.lang.InterruptedException ie) {
                        log.error("", ie);
                        log.warn("OCR Library throws interrupt exception" + ie.getMessage());
                    } catch (java.lang.ArrayIndexOutOfBoundsException aioobe) {
                        log.error("", aioobe);
                        JOptionPane.showMessageDialog(null, "Lookup Khong tim thay ket qua");
                    } catch (Exception e) {
                        log.error("", e);
                        JOptionPane.showMessageDialog(null, e);
                    }

                    logOcrResult(ocr, main);
                    log.info("[Capture]-[COLLECTION:" + main.getEntity().getCard().getManagementID() + "][OCR]-processing data from ocr server");
                    checkThreadInteruppted("interrupt after ocr image");
//					statusOcr =2;
                    Component infor = main.getComponent(MainFieldInterface.OCRINFORMATION);
                    ((OCRInformation) infor).setInformation(ocr.getFullOCR(), ocr);
                    ((OCRInformation) infor).setVisible(true);
                    ((JTextField) main.getComponent(MainFieldInterface.STRASSE)).setText(ocr.getStrasse(((JTextField) main.getComponent(MainFieldInterface.STRASSE)).getText()));
                    if (ocr.isMatchKeyword()) {
                        ((JTextField) main.getComponent(MainFieldInterface.LOOKUP)).setText(ocr.getKeyword());
                        JTextField plzField = (JTextField) main.getComponent(MainFieldInterface.PLZ);
                        JTextField ortField = (JTextField) main.getComponent(MainFieldInterface.ORT);
                        JTextField hauseField = (JTextField) main.getComponent(MainFieldInterface.HAUSE);
                        plzField.setText(ocr.getPlz(plzField.getText()));
                        ortField.setText(ocr.getOrt(ortField.getText()));
                        hauseField.setText(ocr.getHausnummer(hauseField.getText()));

                        if (ocr.getSpecialCaseAll() == 0 ) {
                            checkThreadInteruppted("interrupt before request lookup");
                            requestLookup(main);
                            return;
                        } else if (ocr.getSpecialCaseAll() == 1) {
                            String value = ocr.getPostfach();
                            if (value == null | value.equals("")) {
                                value = "x";
                            }
                            if (ocr.getStrasse().equals("")) {
                                ((JTextField) main.getComponent(MainFieldInterface.POSTFACH)).setText(value);
                            }
                            checkThreadInteruppted("interrupt before request lookup");
                            requestLookup(main);
                            return;
                        } else if (ocr.getSpecialCaseAll() == 3) {
                            String value = ocr.getPickpost();
                            if (value == null || value.equals("")) {
                                value = "x";
                            }
                            log.debug("############Check PICKPOST :{}", value);
                            
                            ((JTextField) main.getComponent(MainFieldInterface.PICKPOST)).setText(value);
                            checkThreadInteruppted("interrupt before request lookup");
                            requestLookup(main);
                            return;
                        } else if (ocr.getSpecialCaseAll() == 7) {
                            String value = ocr.getMypost24();
                            if (value == null || value.equals("")) {
                                value = "x";
                            }
                            log.debug("############Check MYPOST24 :{}", value);
                            ((JTextField) main.getComponent(MainFieldInterface.MYPOST24)).setText(value);
                            checkThreadInteruppted("interrupt before request lookup");
                            requestLookup(main);
                            return;
                        } else {
                            log.info(" *** ELSE *** ");
                            finishOcr(main);
                            return;
                        }
                    }

                    log.info(" *** ocr Not Match Keyword *** ");
                    finishOcr(main);
                    return;
                } catch (InterruptedException ex) {
                    log.debug(ex.getMessage());
                } catch (Exception ex) {
                    log.error(" OCR-State Exception :: ", ex);
                    log.info(" *** Exception *** ");
                    finishOcr(main);
                } finally {
                    addTooltipMain(main);
                }
            }

        };
        aliveThread.start();
        main.setProcessStatus(true);

    }

    private void finishOcr(MainFieldInterface main) {
        try {
            main.setProcessStatus(false);
            log.info("[Capture]-[COLLECTION:" + main.getEntity().getCard().getManagementID() + "][OCR]-finish ocr proccess");
            main.getComponent(MainFieldInterface.FIRMA).requestFocus();
            log.info("[finishOcr] - requestFocus");
            main.resetState();
            log.info("[finishOcr] - resetState");
        } catch (Exception e) {
            log.error("EXCEPTION WHEN FINISH OCR", e);
        }
    }

    private void addTooltipMain(MainFieldInterface main) {
        addTooltipForField(main.getComponent(MainFieldInterface.FIRMA));
        addTooltipForField(main.getComponent(MainFieldInterface.ZUSAT));
        addTooltipForField(main.getComponent(MainFieldInterface.ANREDE));
        addTooltipForField(main.getComponent(MainFieldInterface.VORNAME));
        addTooltipForField(main.getComponent(MainFieldInterface.NAME));
        addTooltipForField(main.getComponent(MainFieldInterface.PLZ));
        addTooltipForField(main.getComponent(MainFieldInterface.ORT));
        addTooltipForField(main.getComponent(MainFieldInterface.STRASSE));
        addTooltipForField(main.getComponent(MainFieldInterface.HAUSE));
        addTooltipForField(main.getComponent(MainFieldInterface.POSTFACH));
        addTooltipForField(main.getComponent(MainFieldInterface.COADDRESS));
        addTooltipForField(main.getComponent(MainFieldInterface.ADRESSZUSAT));
        addTooltipForField(main.getComponent(MainFieldInterface.PICKPOST));
    }

    private void addTooltipForField(Component component) {
        if (!(component instanceof CustomTextField)) {
            return;
        }
        CustomTextField field = (CustomTextField) component;
        String toolTip = ocr.getToolTip(field.getText(), OCRProcessing.OCR_TOOLTIP.value(field.getName()));
//		log.debug("tool tip :" +toolTip);
        field.setToolTip(toolTip.trim());
    }

    private void requestLookup(MainFieldInterface main) {
    	OcrState.countLookup++;
    	log.info("###### Count LOOK UP OCR: " + OcrState.countLookup);
        log.info("[Capture]-[COLLECTION:" + main.getEntity().getCard().getManagementID() + "][OCR]-finish ocr proccess");
        main.getComponent(MainFieldInterface.FIRMA).requestFocus();
        main.resetState();
        CaptureMessage message = CaptureMessage.intance();
        message.clearData();
        message.setAction(StateCapture.LOOKUP);
        main.request(message, main);
    }

    @SuppressWarnings("unused")
    private ObjectSearch buildObjectSearch(MainFieldInterface main) {
        String lookup = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.LOOKUP));

        String plz = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.PLZ));

        String ort = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.ORT));

        String strasse = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.STRASSE));

        String hausNummer = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.HAUSE));

        String pf = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.POSTFACH));

        String pickpost = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.PICKPOST));

        String mypost24 = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.MYPOST24));

        ObjectSearch objectSearch = new ObjectSearch(lookup, plz, ort, strasse, hausNummer, pf, pickpost, mypost24);

        System.out.println("ObjectSearch:" + objectSearch.toString());
        return objectSearch;
    }

    private void checkThreadInteruppted(String message) throws InterruptedException {
        if (Thread.interrupted()) {
            throw new InterruptedException(message);
        }
    }

    /**
     * Write correct percent of OCR service to console and gray log
     */
    private void logOcrResult(OCRProcessing ocr, MainFieldInterface main) {
        // LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
        // // print logback's internal status
        // StatusPrinter.print(lc);
        String cardOrt = ((JTextField) main
                .getComponent(MainFieldInterface.ORT)).getText();
        String cardPlz = ((JTextField) main
                .getComponent(MainFieldInterface.PLZ)).getText();
        String cardStra = ((JTextField) main
                .getComponent(MainFieldInterface.STRASSE)).getText();
        LogDataObject data = new LogDataObject(ocr.getOrt(), ocr.getPlz(),
                ocr.getStrasse(), cardOrt, cardPlz, cardStra, ocr.getKeyword());
        log.info("OCR_RESULT_MEASURE###" + data);
    }
    
    public static void resetCountLookup() {
    	OcrState.countLookup = 0;
    }
    
    class LogDataObject {

        private String ocrOrt;
        private String ocrPlz;
        private String ocrStra;
        private String cardOrt;
        private String cardPlz;
        private String cardStra;
        private String lookup;

        public String getLookup() {
            return lookup;
        }

        public void setLookup(String lookup) {
            this.lookup = lookup;
        }

        private int isOrtMatch;
        private int isPlzMatch;
        private int isStraMatch;

        public LogDataObject(String ocrOrt, String ocrPlz, String ocrStra,
                String cardOrt, String cardPlz, String cardStra, String lookup) {
            this.ocrOrt = (ocrOrt != null) ? ocrOrt : "";
            this.ocrPlz = (ocrPlz != null) ? ocrPlz : "";
            this.ocrStra = (ocrStra != null) ? ocrStra : "";
            this.cardOrt = (cardOrt != null) ? cardOrt : "";
            this.cardPlz = (cardPlz != null) ? cardPlz : "";
            this.cardStra = (cardStra != null) ? cardStra : "";
            this.lookup = (lookup != null) ? lookup : "";

            this.isOrtMatch = this.ocrOrt.equalsIgnoreCase(this.cardOrt) ? 1
                    : 0;
            this.isPlzMatch = this.ocrPlz.equalsIgnoreCase(this.cardPlz) ? 1
                    : 0;
            this.isStraMatch = this.ocrStra.equalsIgnoreCase(this.cardStra) ? 1
                    : 0;
        }

        @Override
        public String toString() {
            return "[rocrOrt:" + ocrOrt + "|rcardOrt:" + cardOrt + "|rmatch:"
                    + isOrtMatch + "][rocrPlz:" + ocrPlz + "|rcardPlz:"
                    + cardPlz + "|rmatch:" + isPlzMatch + "][rocrStra:"
                    + ocrStra + "|rcardStra:" + cardStra + "|rmatch:"
                    + isStraMatch + "| lookup:" + lookup + "]";
        }

        public int isOrtMatch() {
            return isOrtMatch;
        }

        public void setOrtMatch(int isOrtMatch) {
            this.isOrtMatch = isOrtMatch;
        }

        public int isPlzMatch() {
            return isPlzMatch;
        }

        public void setPlzMatch(int isPlzMatch) {
            this.isPlzMatch = isPlzMatch;
        }

        public int isStraMatch() {
            return isStraMatch;
        }

        public void setStraMatch(int isStraMatch) {
            this.isStraMatch = isStraMatch;
        }
    }

}
