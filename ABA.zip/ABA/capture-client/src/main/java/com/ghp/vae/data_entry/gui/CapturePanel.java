package com.ghp.vae.data_entry.gui;

import java.awt.AWTKeyStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.KeyboardFocusManager;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.plaf.TextUI;
import javax.swing.text.BadLocationException;
import javax.swing.text.Caret;
import javax.swing.text.Highlighter;
import javax.swing.text.Highlighter.HighlightPainter;
import javax.swing.text.JTextComponent;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vae.client.transfer.LookupKey;

import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.common.autocomplete.VaeFocusTraversalPolicy;
import com.ghp.vae.data_entry.ptl.autocomplete.AutoTextField;
import com.ghp.vae.data_entry.ptl.autocomplete.AutoTextFieldInterface;
import com.ghp.vae.data_entry.ptl.autocomplete.AutoTextFieldSuggestionService;
import com.ghp.vae.data_entry.ptl.autocomplete.CustomTextField;
import com.ghp.vae.search.service.impl.LookupServiceImpl;
import com.sps.vn.config.ApplicationConfig;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

class CapturePanel extends JPanel implements ActionListener, FocusListener {

    private static Logger log = LoggerFactory.getLogger("GUI");
    private JLabel jlbAddressuzat;
    private JLabel jlbAnrede;
    private JLabel jlbCOAddress;
    private JLabel jlbFirmaname;
    private JLabel jlbHauseNummer;
    private JLabel jlbLookup;
    private JLabel jlbNachname;
    private JLabel jlbNamezusat;
    private JLabel jlbOrt;
    private JLabel jlbPickpost;
    private JLabel jlbPlz;
    private JLabel jlbPostfach;
    private JLabel jlbPostlagend;
    private JLabel jlbReason;
    private JLabel jlbVorname;
    private JLabel jlbStrasse;
    private JLabel jlbStockwerk;
    private JLabel jlbLand;
    private JLabel jlbKDPId;
    private JLabel jlbMyPost24;

    private CustomTextField jtfAddressuzat;
    private CustomTextField jtfCOAddress;
    private CustomTextField jcboAnrede;
    private CustomTextField jtfFirmename;
    private CustomTextField jtfHausNummer;
    private CustomTextField jtfLookup;
    private CustomTextField jtfName;
    private CustomTextField jtfNameZusat;
    private CustomTextField jtfOrt;
    private CustomTextField jtfPickPost;
    private CustomTextField jtfPlz;
    private CustomTextField jtfPostFach;
    private CustomTextField jtfPostLagend;
    private CustomTextField jtfStockwerk;
    private CustomTextField jtfStrasse;
    private CustomTextField jtfVorname;
    private CustomTextField jtfMyPost24;

    private javax.swing.JComboBox jcboLand;
    private javax.swing.JComboBox jcboReason;

    private JButton jbtnFirmename;
    private JButton jbtnLookup;
    private JButton jbtnName;
    private JButton jbtnOrt;
    private JButton jbtnPlz;
    private JButton jbtnStrasse;
    private JButton jbtnVorname;

    private JSeparator jSeparator1;
    private CaptureMediator meditor;
    private boolean clickButton;
    private Map<String, DefaultListModel> lookupList;

    private JList jListGermanyCharactor;
    private JPopupMenu jPopupMenuGermanyCharactor;

    private Color defaultColor;

    public CapturePanel() {
        this.initComponent();
        this.lightPaint = new CustomerHighlightPainter(Color.red);

	};

	private void initComponent() {
        this.jPopupMenuGermanyCharactor = new javax.swing.JPopupMenu();
        this.jPopupMenuGermanyCharactor.setFocusable(false);

        this.jListGermanyCharactor = new javax.swing.JList();
        this.jSeparator1 = new JSeparator();

        this.jcboAnrede = new AutoTextField();
        // jtfNameZusat = new AutoTextField();
        // jtfFirmename = new AutoTextField();

        this.jtfNameZusat = new AutoTextFieldSuggestionService();
        this.jtfFirmename = new AutoTextFieldSuggestionService();
        // jtfLookup = new LookupTextFieldSuggestionService();
        this.jtfVorname = new AutoTextField();
        this.jtfName = new AutoTextField();
        this.jtfPlz = new AutoTextField();
        this.jtfOrt = new AutoTextField();
        this.jtfStrasse = new AutoTextField();
        this.jtfHausNummer = new AutoTextField();
        this.jtfPostFach = new AutoTextField();
        this.jtfStockwerk = new AutoTextField();
        this.jtfAddressuzat = new AutoTextField();
        this.jtfPostLagend = new AutoTextField();
        this.jtfCOAddress = new AutoTextField();
        this.jtfPickPost = new AutoTextField();
        this.jtfLookup = new CustomTextField();
        this.jtfMyPost24 = new CustomTextField();

        this.jlbReason = new JLabel();
        this.jlbLookup = new JLabel();
        this.jlbFirmaname = new JLabel();
        this.jlbNamezusat = new JLabel();
        this.jlbAnrede = new JLabel();
        this.jlbVorname = new JLabel();
        this.jlbNachname = new JLabel();
        this.jlbStrasse = new JLabel();
        this.jlbPlz = new JLabel();
        this.jlbOrt = new JLabel();
        this.jlbPostfach = new JLabel();
        this.jlbStockwerk = new JLabel();
        this.jlbAddressuzat = new JLabel();
        this.jlbCOAddress = new JLabel();
        this.jlbHauseNummer = new JLabel();
        this.jlbPickpost = new JLabel();
        this.jlbPostlagend = new JLabel();
        this.jlbLand = new JLabel();
        this.jlbKDPId = new JLabel();
        this.jlbMyPost24 = new JLabel();

        this.jbtnPlz = new JButton();
        this.jbtnOrt = new JButton();
        this.jbtnStrasse = new JButton();
        this.jbtnName = new JButton();
        this.jbtnVorname = new JButton();
        this.jbtnFirmename = new JButton();
        this.jbtnLookup = new JButton();

        this.defaultColor = this.jbtnPlz.getBackground();
        this.jcboReason = new JComboBox();
        this.jcboLand = new JComboBox();

        this.initGui();
        this.setAutoCompleteLookupModal();
    }

    private void initGui() {
        this.setAlignmentX(0.0F);
        this.setLayout(null);

        this.setBoundLabel();
        this.setBoundTextField();
        this.setBoundCombobox();
        this.setBoundOtherComponent();
        this.initAction();
        this.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, Color.LIGHT_GRAY));
    }

    /**
     * remove FocusAdapter blockWork for jtfNameZuzat, jtfVorname, jtfName
     */
    private void initAction() {
        final FocusListener listerner = new SelectionEventListener();
        final DisplayInformation listernerInformation = new DisplayInformation();
        final ProccessKeyEvent keyEvent = new ProccessKeyEvent();
        final OcrProcessKey ocrKey = new OcrProcessKey();
        final WarningBlockWork blockWork = new WarningBlockWork();

        // jbtnLookup.addActionListener(this);
        this.jbtnFirmename.addActionListener(this);
        this.jbtnName.addActionListener(this);
        this.jbtnVorname.addActionListener(this);
        this.jbtnPlz.addActionListener(this);
        this.jbtnOrt.addActionListener(this);
        this.jbtnStrasse.addActionListener(this);
        this.jbtnLookup.addFocusListener(this);
        this.jbtnFirmename.addFocusListener(this);
        this.jbtnName.addFocusListener(this);
        this.jbtnVorname.addFocusListener(this);
        this.jbtnPlz.addFocusListener(this);
        this.jbtnOrt.addFocusListener(this);
        this.jbtnStrasse.addFocusListener(this);

        this.addActionOnField(this.jtfNameZusat, listerner, keyEvent, ocrKey, blockWork, listernerInformation);
        this.addActionOnField(this.jcboAnrede, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfFirmename, listerner, keyEvent, ocrKey, blockWork, listernerInformation);
        this.addActionOnField(this.jtfVorname, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfName, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfPlz, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfOrt, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfStrasse, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfHausNummer, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfPostFach, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfStockwerk, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfAddressuzat, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfMyPost24, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfPostLagend, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfCOAddress, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfPickPost, listerner, keyEvent, ocrKey, null, listernerInformation);
        this.addActionOnField(this.jtfLookup, listerner, keyEvent, ocrKey, blockWork, listernerInformation);
        this.addActionForField(this.jcboReason.getEditor().getEditorComponent(), listerner, null, null);
        this.addActionForField(this.jcboLand.getEditor().getEditorComponent(), listerner, null, null);

        this.addActionCustomerizer();
        this.verifyRollbackKDP();
    }
    
    private void addActionCustomerizer() {
        try {

            this.jtfPickPost.addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    CapturePanel.this.meditor.enableFieldWhenFocusPickpost();
                }
            });
            
            this.jcboReason.addItemListener(new ItemListener() {
                @Override
                public void itemStateChanged(ItemEvent e) {
                    if (e.getStateChange() == ItemEvent.DESELECTED) {
                        return;
                    }
                    if (CapturePanel.this.jcboReason.getSelectedIndex() != 0) {
                        CapturePanel.this.meditor.enableSaveButton(true);

                        // Request #10890: Disable capturing fields when selected '5. Dia chi nuoc ngoai, quan doi'
                        if (CapturePanel.this.jcboReason.getSelectedItem().toString().equalsIgnoreCase("5. Dia chi nuoc ngoai, quan doi")) {
                            clearAllCapturingData();
                            CapturePanel.this.enableCapturingField(false);
                            
                        } else {
                            CapturePanel.this.enableCapturingField(true);
                        }
                    } else {
                        // Request #10890: Enable capturing fields when user don't select any reason
                        CapturePanel.this.enableCapturingField(true);
                        if (CapturePanel.this.jtfVorname.getText().equals("") && CapturePanel.this.jtfName.getText().equals("")
                                && CapturePanel.this.jtfPlz.getText().equals("") && CapturePanel.this.jtfOrt.getText().equals("")
                                && CapturePanel.this.jtfStrasse.getText().equals("")) {
                            CapturePanel.this.meditor.enableSaveButton(false);
                        }
                    }
                }
            });
            final KeyAdapter selectItem = new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                        if (e.getComponent().equals(CapturePanel.this.jcboReason.getEditor().getEditorComponent())) {
                            CapturePanel.this.jtfLookup.requestFocus();
                        } else {
                            e.getComponent().transferFocus();
                        }
                    } else if (((e.getKeyCode() >= KeyEvent.VK_1) && (e.getKeyCode() <= KeyEvent.VK_6))
                            || ((e.getKeyCode() >= KeyEvent.VK_NUMPAD1) && (e.getKeyCode() <= KeyEvent.VK_NUMPAD6))) {
                        if (e.getComponent().equals(CapturePanel.this.jcboReason.getEditor().getEditorComponent())) {
                            CapturePanel.this.jtfLookup.requestFocus();
                        } else {
                            CapturePanel.this.jtfStockwerk.requestFocus();
                        }
                    }
                }
            };
            this.jcboReason.getEditor().getEditorComponent().addKeyListener(selectItem);
            this.jcboLand.getEditor().getEditorComponent().addKeyListener(selectItem);
            this.jcboLand.getEditor().getEditorComponent().addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    if (e.getKeyCode() == KeyEvent.VK_UP) {
                        if (CapturePanel.this.jcboLand.getSelectedIndex() < 1) {
                            e.getComponent().transferFocusBackward();
                        } else {
                            CapturePanel.this.jcboLand.setPopupVisible(true);
                        }
                    }
                }
            });

            this.jListGermanyCharactor.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    CapturePanel.this.selectCharacterFromSuggest(e);
                }
            ;
            });

			this.jtfMyPost24.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    if ((e.getKeyCode() == KeyEvent.VK_DOWN) || (e.getKeyCode() == KeyEvent.VK_ENTER)) {
                        CapturePanel.this.jtfFirmename.transferFocus();
                        return;
                    }
                    if (e.getKeyCode() == KeyEvent.VK_UP) {
                        ((Component) e.getSource()).transferFocusBackward();
                    }
                }
            });

            final KeyStroke settext = KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0, false);
            // KeyStroke tabl = KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0,
            // false);
            this.jcboReason.registerKeyboardAction(this, "settext", settext, JComponent.WHEN_IN_FOCUSED_WINDOW);

            /**
             * #10672: Change request - F6 function
             */
            // KeyStroke clearKdpid = KeyStroke.getKeyStroke(KeyEvent.VK_F6, 0, false);
            // jcboReason.registerKeyboardAction(this, "clearKdpid", clearKdpid, JComponent.WHEN_IN_FOCUSED_WINDOW);
            this.jcboReason.getEditor().getEditorComponent().addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    CapturePanel.this.jcboReason.showPopup();
                }
            });

            this.jtfName.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    if (e.getKeyCode() == KeyEvent.VK_ENTER) {

                        final String vorname = Utilities.ignoreNull(CapturePanel.this.jtfVorname.getText());
                        final String nachname = Utilities.ignoreNull(CapturePanel.this.jtfName.getText());
                        if (StringUtils.isNotEmpty(vorname) || StringUtils.isNotEmpty(nachname)) {
                            CapturePanel.this.swapVornameNachname(vorname, nachname, ApplicationConfig.getInstance().getBusinessConfig().getValidPercent());
                        }
                        CapturePanel.this.jtfName.transferFocus();
                    } 
                    
                    // CI123: PRESS F9 TO COPY VORNAME TO NAME
                    if (e.getKeyCode() == KeyEvent.VK_F9) {
                    	Component component = e.getComponent();
                    	String firma = Utilities.ignoreNull(CapturePanel.this.jtfFirmename.getText());
                    	String zusatz = Utilities.ignoreNull(CapturePanel.this.jtfNameZusat.getText());
                    	final String name = Utilities.ignoreNull(CapturePanel.this.jtfName.getText());
                    	// final String key = LookupKey.SUG_NAME.getKey();
                    	if (StringUtils.isNotEmpty(name)) {
                    		// CapturePanel.this.moveVornameName(firma, zusatz, LookupServiceImpl.INDEX_TYPE_NAME, name, component);
                    		CapturePanel.this.moveVornameName(firma, zusatz, LookupServiceImpl.INDEX_NACHNAMEMORE_TYPE, name, component);
						}
					}
                }
            });
            
            // CI123: PRESS F9 TO COPY VORNAME TO NAME
            this.jtfVorname.addKeyListener(new KeyAdapter() {

				@Override
				public void keyPressed(KeyEvent e) {
					 if (e.getKeyCode() == KeyEvent.VK_F9) {
	                    	Component component = e.getComponent();
	                    	String firma = Utilities.ignoreNull(CapturePanel.this.jtfFirmename.getText());
	                    	String zusatz = Utilities.ignoreNull(CapturePanel.this.jtfNameZusat.getText());
	                    	final String vorname = Utilities.ignoreNull(CapturePanel.this.jtfVorname.getText());
	                    	final String key = LookupKey.SUG_NAME.getKey();
	                    	if (StringUtils.isNotEmpty(vorname)) {
	                    		// CapturePanel.this.moveVornameName(firma, zusatz, LookupServiceImpl.INDEX_VORNAME_TYPE, vorname, component);
	                    		CapturePanel.this.moveVornameName(firma, zusatz, LookupServiceImpl.INDEX_VORNAMEMORE_TYPE, vorname, component);
							}
						}
				}
            	
			});
            

            // jtfLookup.addKeyListener(new KeyAdapter() {
            // @Override
            // public void keyReleased(KeyEvent evt) {
            //
            // /**
            // * this method only run in the first load UI
            // */
            // if(evt.getKeyCode() == KeyEvent.VK_ENTER || evt.getKeyCode() == KeyEvent.VK_DOWN){
            // System.out.println("this method only run in the first load UI ");
            // jtfFirmename.requestFocus();
            // }
            // }});
            this.jtfLookup.addKeyListener(new KeyAdapter() {
                @Override
                public void keyReleased(KeyEvent evt) {
                    final JTextField lookup = (JTextField) evt.getComponent();
                    // if(evt.isControlDown() && evt.getKeyCode() ==
                    // KeyEvent.VK_2){
                    // if(lookup.getText().contains(" ")){
                    // lookup.setText(lookup.getText().replace(" ","%"));
                    // }else if(lookup.getText().contains("%")){
                    // lookup.setText(lookup.getText().replace("%"," "));
                    // }
                    // return;
                    // }
                    if (evt.getKeyCode() == KeyEvent.VK_F3) {
                        lookup.setText(Utilities.getCharShort(lookup.getText()));
                    }
                }

                @Override
                public void keyPressed(KeyEvent evt) {
                    if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                        if (CapturePanel.this.meditor != null) {
                            if (!CapturePanel.this.jtfLookup.getText().trim().equals("")) {
                                CapturePanel.this.meditor.search();
                            }
                        }
                        CapturePanel.this.jtfLookup.transferFocus();
                    }
                    if (evt.getKeyCode() == KeyEvent.VK_DOWN) {
                        CapturePanel.this.jtfLookup.transferFocus();
                    }
                    if (evt.getKeyCode() == KeyEvent.VK_UP) {
                        CapturePanel.this.jtfLookup.transferFocusBackward();
                    }
                    if (evt.getKeyCode() == KeyEvent.VK_TAB) {
                        CapturePanel.this.jtfLookup.transferFocusDownCycle();
                    }
                }
            });
            this.jtfHausNummer.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    /**
                     * Request ID : 1166 Haus-number/Postfach_capturing_Support
                     */
                    if (e.getKeyCode() == KeyEvent.VK_TAB) {
                        CapturePanel.this.updateTextForAddresssuzat("Haus-Nr");
                    }
                    super.keyPressed(e);
                }
            });

            this.jtfPostFach.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    if (e.getKeyCode() == KeyEvent.VK_TAB) {
                        CapturePanel.this.updateTextForAddresssuzat("Postfach");

                    }
                    super.keyPressed(e);
                }
            });
        } catch (final Exception e2) {
            log.error("", e2);
        }
    }
    
    //ABA-68 - CI-116: Rollback KDP - Hot key: F8 
    private void verifyRollbackKDP() {     	
        this.jcboReason.getEditor().getEditorComponent().addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
    	
        this.jtfLookup.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        
        this.jtfFirmename.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        this.jtfNameZusat.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        this.jcboAnrede.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        this.jtfVorname.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        this.jtfName.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        this.jtfPlz.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        this.jtfOrt.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        this.jtfStrasse.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        this.jtfHausNummer.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        this.jtfPostFach.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        this.jtfStockwerk.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        this.jtfAddressuzat.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
        this.jtfCOAddress.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
    	this.jtfPickPost.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
    	this.jtfPostLagend.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
    	this.jtfMyPost24.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
            	if(e.getKeyCode() == KeyEvent.VK_F8)
            		meditor.rollBackKDP();
            }
        });
    }

    protected void updateTextForAddresssuzat(String text) {
        final String currentText = this.jtfAddressuzat.getText();
        if (currentText.isEmpty()) {
        	this.jtfAddressuzat.setText(this.handleErrorFontTextField(text));
        } else {
        	this.jtfAddressuzat.setText(this.handleErrorFontTextField(currentText) + " " + this.handleErrorFontTextField(text));
        }
        if (!this.jtfAddressuzat.isEnabled()) {
            this.jtfAddressuzat.setEnabled(true);
        }
        this.jtfAddressuzat.requestFocus();

    }

    protected void swapVornameNachname(String vorname, String nachname, int validPercent) {
        this.meditor.swapVornameNachname(vorname, nachname, validPercent);
    }
    
    // CI123: PRESS F7 TO COPY VORNAME TO NAME
    protected void moveVornameName (String firmaName, String zusatzName, String indexType, String value, Component component) {
    	this.meditor.moveVornameName(firmaName, zusatzName, indexType, value, component);
    }

    private void addActionOnField(Component component, FocusListener listerner, ProccessKeyEvent keyEvent, OcrProcessKey ocrKey, WarningBlockWork blockWork,
            DisplayInformation listernerInformation) {
        if (listerner != null) {
            component.addFocusListener(listerner);
        }
        if (keyEvent != null) {
            component.addKeyListener(keyEvent);
        }
        if (ocrKey != null) {
            component.addKeyListener(ocrKey);
        }
        if (blockWork != null) {
            component.addFocusListener(blockWork);
        }
        if (listernerInformation != null) {
            component.addFocusListener(listernerInformation);
        }
    }

    private void addActionForField(Component component, FocusListener listerner, ProccessKeyEvent keyEvent, OcrProcessKey ocrKey) {
        this.addActionOnField(component, listerner, keyEvent, ocrKey, null, null);
    }

    private void setBoundCombobox() {
        this.jcboReason.setFont(new Font("Tahoma", Font.PLAIN, 17));
        this.jcboReason.setName("Reason");// set name for reason-pml
        this.jcboReason.setBounds(97, 10, 388, 30);
        ((JTextField) this.jcboReason.getEditor().getEditorComponent()).setFocusAccelerator('B');
        this.add(this.jcboReason);
        this.jcboLand.setBounds(315, this.pointY(9), 130, 30);
        this.jcboLand.setEditable(true);
        this.jcboLand.setFont(new Font("Tahoma", Font.PLAIN, 17));
        this.jcboLand.setModel(new javax.swing.DefaultComboBoxModel(new String[]{"Item 1", "Item 2", "Item 3", "Item 4"}));
        this.jcboLand.setName("land");
        ((JTextField) this.jcboLand.getEditor().getEditorComponent()).setFocusAccelerator('L');
        this.add(this.jcboLand);

    }

    private void setBoundOtherComponent() {

        this.jbtnPlz.setBounds(257, this.pointY(6), 30, 30);
        this.jbtnOrt.setBounds(455, this.pointY(7), 30, 30);
        this.jbtnStrasse.setBounds(455, this.pointY(8), 30, 30);
        this.jbtnName.setBounds(455, this.pointY(5), 30, 30);
        this.jbtnVorname.setBounds(455, this.pointY(4), 30, 30);
        this.jbtnFirmename.setBounds(455, this.pointY(1), 30, 30);
        this.jbtnLookup.setBounds(455, this.pointY(0), 30, 30);

        this.initButton(this.jbtnPlz);
        this.initButton(this.jbtnOrt);
        this.initButton(this.jbtnStrasse);
        this.initButton(this.jbtnName);
        this.initButton(this.jbtnVorname);
        this.initButton(this.jbtnFirmename);
        this.initButton(this.jbtnLookup);

        this.jSeparator1.setBounds(0, 0, 320, 2);
        this.add(this.jSeparator1);
    }

    public void initButton(JButton button) {
        button.setText("...");
        this.add(button);
    }

    private void setBoundLabel() {
        this.jlbReason.setBounds(10, 19, 90, 21);
        this.jlbLookup.setBounds(10, this.pointLabelY(0), 77, 15);
        this.jlbFirmaname.setBounds(10, this.pointLabelY(1), 52, 15);
        this.jlbNamezusat.setBounds(10, this.pointLabelY(2), 52, 15);
        this.jlbAnrede.setBounds(10, this.pointLabelY(3), 60, 15);
        this.jlbVorname.setBounds(10, this.pointLabelY(4), 77, 15);
        this.jlbNachname.setBounds(10, this.pointLabelY(5), 77, 15);
        this.jlbPlz.setBounds(10, this.pointLabelY(6), 38, 15);
        this.jlbOrt.setBounds(10, this.pointLabelY(7), 38, 15);
        this.jlbStrasse.setBounds(10, this.pointLabelY(8), 60, 15);
        this.jlbHauseNummer.setBounds(10, this.pointLabelY(9), 60, 15);

        this.jlbLand.setBounds(255, this.pointLabelY(9), 53, 15);
        this.jlbKDPId.setBounds(255, this.pointLabelY(9), 200, 15);

        this.jlbPostfach.setBounds(10, this.pointLabelY(10), 77, 15);
        this.jlbStockwerk.setBounds(10, this.pointLabelY(11), 77, 15);
        this.jlbAddressuzat.setBounds(10, this.pointLabelY(12), 90, 15);
        this.jlbCOAddress.setBounds(10, this.pointLabelY(13), 90, 15);
        this.jlbPickpost.setBounds(10, this.pointLabelY(14), 77, 15);
        this.jlbPostlagend.setBounds(10, this.pointLabelY(15), 90, 15);
        this.jlbMyPost24.setBounds(10, this.pointLabelY(16), 90, 15);

        this.initLabel(this.jlbReason, 'B', "Bad Reason");
        this.initLabel(this.jlbLookup, 'k', "Lookup");
        this.initLabel(this.jlbFirmaname, 'F', "Firma");
        this.initLabel(this.jlbNamezusat, 'u', "Zusatz");
        this.initLabel(this.jlbAnrede, 'e', "Anrede");
        this.initLabel(this.jlbVorname, 'V', "Vorname");
        this.initLabel(this.jlbNachname, 'N', "Name");
        this.initLabel(this.jlbPlz, 'P', "Plz");
        this.initLabel(this.jlbOrt, 'O', "Ort");
        this.initLabel(this.jlbStrasse, 'a', "Strasse");
        this.initLabel(this.jlbHauseNummer, 'H', "Hause");

        // Request: https://helpdesk.spsvietnam.vn/WorkOrder.do?woMode=viewWO&woID=10025&&fromListView=true
        // initLabel(jlbLand, 'L', "Land");
        this.initLabel(this.jlbKDPId, 'I', "KDPID");

        this.initLabel(this.jlbPostfach, 't', "PostFach");
        this.initLabel(this.jlbStockwerk, 'w', "Stockwerk");
        this.initLabel(this.jlbAddressuzat, 'd', "Adresszusatz");
        this.initLabel(this.jlbCOAddress, 'C', "C/O Adress");
        this.initLabel(this.jlbPickpost, 'i', "PickPost");
        this.initLabel(this.jlbPostlagend, 'g', "Postlagernd");
        this.initLabel(this.jlbMyPost24, 'M', "MyPost 24");
    }

    private void setBoundTextField() {
        this.jtfLookup.setBounds(97, this.pointY(0), 348, 29);
        this.jtfFirmename.setBounds(97, this.pointY(1), 348, 29);
        this.jtfNameZusat.setBounds(97, this.pointY(2), 348, 29);
        this.jcboAnrede.setBounds(97, this.pointY(3), 121, 29);
        this.jtfVorname.setBounds(97, this.pointY(4), 348, 29);
        this.jtfName.setBounds(97, this.pointY(5), 348, 29);
        this.jtfPlz.setBounds(97, this.pointY(6), 150, 29);
        this.jtfOrt.setBounds(97, this.pointY(7), 348, 29);
        this.jtfStrasse.setBounds(97, this.pointY(8), 348, 29);
        this.jtfHausNummer.setBounds(97, this.pointY(9), 130, 29);
        this.jtfPostFach.setBounds(97, this.pointY(10), 348, 29);
        this.jtfStockwerk.setBounds(97, this.pointY(11), 348, 29);
        this.jtfAddressuzat.setBounds(97, this.pointY(12), 348, 29);
        this.jtfCOAddress.setBounds(97, this.pointY(13), 348, 29);
        this.jtfPickPost.setBounds(97, this.pointY(14), 348, 29);
        this.jtfPostLagend.setBounds(97, this.pointY(15), 348, 29);
        this.jtfMyPost24.setBounds(97, this.pointY(16), 348, 29);

        final Color backGroup = new Color(204, 255, 204);
        this.initTextField(this.jcboAnrede, 'E', "anrede", backGroup);
        this.initTextField(this.jtfNameZusat, 'u', "namenszusatz");
        this.initTextField(this.jtfFirmename, 'F', "firmenname", backGroup);
        this.initTextField(this.jtfVorname, 'V', "vorname", backGroup);
        this.initTextField(this.jtfName, 'N', "name", backGroup);
        this.initTextField(this.jtfPlz, 'P', "plz", backGroup);
        this.initTextField(this.jtfOrt, 'o', "ort", backGroup);
        this.initTextField(this.jtfStrasse, 'a', "strasse", backGroup);
        this.initTextField(this.jtfHausNummer, 'h', "hausnummer");
        this.initTextField(this.jtfPostFach, 't', "postfachnummer");
        this.initTextField(this.jtfStockwerk, 'w', "stockwerk");
        this.initTextField(this.jtfAddressuzat, 'd', "adresszusatz");
        this.initTextField(this.jtfCOAddress, 'C', "co_addresse");
        this.initTextField(this.jtfPickPost, 'i', "pickpostnummer");
        this.initTextField(this.jtfPostLagend, 'g', "postlagend");
        this.initTextField((JTextField) this.jcboReason.getEditor().getEditorComponent(), 'B', "Reason");
        this.initTextField((JTextField) this.jcboLand.getEditor().getEditorComponent(), 'L', "land");
        this.initTextField(this.jtfLookup, 'K', "lookup", backGroup);
        this.initTextField(this.jtfMyPost24, 'M', "mypost24");
    }

    private void initLabel(JLabel label, char mnemonic, String text) {
        label.setText(text);
        label.setDisplayedMnemonic(mnemonic);
        this.add(label);
    }

    private void initTextField(JTextField text, char mnemonic, String name) {
        text.setFocusAccelerator(mnemonic);
        text.setName(name);
        if (text instanceof CustomTextField) {
            ((CustomTextField) text).setDifferentColor(Color.pink);
        }
        this.add(text);
    }

    private void initTextField(CustomTextField text, char mnemonic, String name, Color backGroup) {
        text.setBackground(backGroup);
        text.setNormalColor(backGroup);

        final Color selectColor = UIManager.getColor("TextField.select");
        text.setSelectColor(selectColor);
        text.setDifferentColor(Color.pink);

        text.setFont(new Font("Tahoma", Font.PLAIN, 17));
        text.setFocusAccelerator(mnemonic);
        text.setName(name);
        this.add(text);
    }

    void clearCaptureData() {
        for (final Component component : this.getComponents()) {
            if (component instanceof JTextField) {
                log.debug(component.getName() + ":" + component.getClass().getName());
                ((JTextField) component).setText("");
            } else if (component instanceof JComboBox) {
                if (component == this.jcboLand) {
                    // Do not action for land
                    continue;
                }
                log.debug(component.getName() + ":" + component.getClass().getName());
                ((JComboBox) component).setSelectedIndex(0);
                if (((JComboBox) component).isEditable()) {
                    ((JTextField) ((JComboBox) component).getEditor().getEditorComponent()).setText("");
                }
            }
        }

        this.enableFieldNotLookup();

    }

    void clearCaptureDataButton() {
        for (final Component component : this.getComponents()) {
            if (component instanceof JTextField) {
                if (component instanceof CustomTextField) {
                    ((CustomTextField) component).setDifferent(false);
                    ((CustomTextField) component).changeBackGround();
                }
                if ((component == this.jtfPlz) || (component == this.jtfOrt)) {
                    continue;
                }
                ((JTextField) component).setText("");
            } else if (component instanceof JComboBox) {
                ((JComboBox) component).setSelectedIndex(0);
                if (((JComboBox) component).isEditable()) {
                    ((JTextField) ((JComboBox) component).getEditor().getEditorComponent()).setText("");
                }
            }
        }

        this.enableFieldNotLookup();
        this.enableStrasseHausnrField(true);
    }

    void enableFieldNotLookup() {
        this.jtfPickPost.setEnabled(true);
        this.jtfPostLagend.setEnabled(true);
        this.jtfMyPost24.setEnabled(true);
    }
    
    /**
     * @note not action for land beacause request from production
     */
    void allEnable(boolean enabled) {
        this.jcboReason.setEnabled(enabled);
        this.jtfLookup.setEnabled(enabled);
        this.jtfFirmename.setEnabled(enabled);
        this.jtfNameZusat.setEnabled(enabled);
        this.jtfNameZusat.setEnabled(enabled);
        this.jcboAnrede.setEnabled(enabled);
        this.jtfVorname.setEnabled(enabled);
        this.jtfName.setEnabled(enabled);
        this.jtfPlz.setEnabled(enabled);
        this.jtfOrt.setEnabled(enabled);
        this.jtfStrasse.setEnabled(enabled);
        this.jtfHausNummer.setEnabled(enabled);
        // jcboLand.setEnabled(enabled);
        this.jtfPostFach.setEnabled(enabled);
        this.jtfStockwerk.setEnabled(enabled);
        this.jtfAddressuzat.setEnabled(enabled);
        this.jtfCOAddress.setEnabled(enabled);
        this.jtfPickPost.setEnabled(enabled);
        this.jtfPostLagend.setEnabled(enabled);
        this.jtfMyPost24.setEnabled(enabled);
        // button field
        this.jbtnLookup.setEnabled(enabled);
        this.jbtnFirmename.setEnabled(enabled);
        this.jbtnStrasse.setEnabled(enabled);
        this.jbtnVorname.setEnabled(enabled);
        this.jbtnName.setEnabled(enabled);
        this.jbtnPlz.setEnabled(enabled);
        this.jbtnOrt.setEnabled(enabled);
    }

    void enableCapturingField(boolean enabled) {
        this.jtfLookup.setEnabled(enabled);
        this.jtfFirmename.setEnabled(enabled);
        this.jtfNameZusat.setEnabled(enabled);
        this.jtfNameZusat.setEnabled(enabled);
        this.jcboAnrede.setEnabled(enabled);
        this.jtfVorname.setEnabled(enabled);
        this.jtfName.setEnabled(enabled);
        this.jtfPlz.setEnabled(enabled);
        this.jtfOrt.setEnabled(enabled);
        this.jtfStrasse.setEnabled(enabled);
        this.jtfHausNummer.setEnabled(enabled);
        // jcboLand.setEnabled(enabled);
        this.jtfPostFach.setEnabled(enabled);
        this.jtfStockwerk.setEnabled(enabled);
        this.jtfAddressuzat.setEnabled(enabled);
        this.jtfCOAddress.setEnabled(enabled);
        this.jtfPickPost.setEnabled(enabled);
        this.jtfPostLagend.setEnabled(enabled);
        this.jtfMyPost24.setEnabled(enabled);
        // button field
        this.jbtnLookup.setEnabled(enabled);
        this.jbtnFirmename.setEnabled(enabled);
        this.jbtnStrasse.setEnabled(enabled);
        this.jbtnVorname.setEnabled(enabled);
        this.jbtnName.setEnabled(enabled);
        this.jbtnPlz.setEnabled(enabled);
        this.jbtnOrt.setEnabled(enabled);
    }
    
    void clearAllCapturingData() {
        this.jtfLookup.setText(StringUtils.EMPTY);
        this.jtfFirmename.setText(StringUtils.EMPTY);
        this.jtfNameZusat.setText(StringUtils.EMPTY);
        this.jcboAnrede.setText(StringUtils.EMPTY);
        this.jtfVorname.setText(StringUtils.EMPTY);
        this.jtfName.setText(StringUtils.EMPTY);
        this.jtfPlz.setText(StringUtils.EMPTY);
        this.jtfOrt.setText(StringUtils.EMPTY);
        this.jtfStrasse.setText(StringUtils.EMPTY);
        this.jtfHausNummer.setText(StringUtils.EMPTY);
        this.jtfPostFach.setText(StringUtils.EMPTY);
        this.jtfStockwerk.setText(StringUtils.EMPTY);
        this.jtfAddressuzat.setText(StringUtils.EMPTY);
        this.jtfCOAddress.setText(StringUtils.EMPTY);
        this.jtfPickPost.setText(StringUtils.EMPTY);
        this.jtfPostLagend.setText(StringUtils.EMPTY);
        this.jtfMyPost24.setText(StringUtils.EMPTY);
        this.meditor.clearKDP();
    }

    void enableStrasseHausnrField(boolean enabled) {
        this.jtfStrasse.setEnabled(enabled);
        this.jtfHausNummer.setEnabled(enabled);
    }

    JComboBox getJcboReason() {
        return this.jcboReason;
    }

    Component getJtfLookup() {
        return this.jtfLookup;
    }

    Component getJtfFirmename() {
        return this.jtfFirmename;
    }

    Component getJtfNameZusat() {
        return this.jtfNameZusat;
    }

    CustomTextField getJcboAnrede() {
        return this.jcboAnrede;
    }

    Component getJtfVorname() {
        return this.jtfVorname;
    }

    Component getJtfName() {
        return this.jtfName;
    }

    Component getJtfPlz() {
        return this.jtfPlz;
    }

    CustomTextField getJtfOrt() {
        return this.jtfOrt;
    }

    CustomTextField getJtfStrasse() {
        return this.jtfStrasse;
    }

    CustomTextField getJtfHausNummer() {
        return this.jtfHausNummer;
    }

    JComboBox getJcboLand() {
        return this.jcboLand;
    }

    CustomTextField getJtfPickPost() {
        return this.jtfPickPost;
    }

    CustomTextField getJtfPostFach() {
        return this.jtfPostFach;
    }

    CustomTextField getJtfStockwerk() {
        return this.jtfStockwerk;
    }

    CustomTextField getJtfAddressuzat() {
        return this.jtfAddressuzat;
    }

    CustomTextField getJtfCOAddress() {
        return this.jtfCOAddress;
    }

    JTextField getJtfMyPost24() {
        return this.jtfMyPost24;
    }

    CustomTextField getJtfPostLagend() {
        return this.jtfPostLagend;
    }

    void hiddenToolTip() {
        for (final Component comp : this.getComponents()) {
            if (comp instanceof CustomTextField) {
                ((CustomTextField) comp).setVisibleTooltip(false);
            }
        }
    }

    void displayToolTip() {
        for (final Component component : this.getComponents()) {
            if (component instanceof CustomTextField) {
                final CustomTextField field = (CustomTextField) component;
                field.setVisibleTooltip(true);
            }
        }

    }

    void clearTooltip() {
        for (final Component comp : this.getComponents()) {
            if (comp instanceof CustomTextField) {
                ((CustomTextField) comp).clearToolTip();
                ((CustomTextField) comp).clearToolTipValidate();
            }
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equalsIgnoreCase("settext")) {
            if (!this.jtfCOAddress.isEnabled()) {
                return;
            }
            for (final Component comp : CapturePanel.this.getComponents()) {
                if (comp instanceof CustomTextField) {
                    ((CustomTextField) comp).setToolTipValueToText();
                    ((CustomTextField) comp).setVisibleTooltip(false);
                }
            }
            return;
        }
        if (e.getActionCommand().equalsIgnoreCase("clearKdpid")) {

            this.meditor.clearKDP();
            return;
        }
        final Object obj = e.getSource();
        this.clickButton = true;
        this.eventLookup(obj);
    }

    @Override
    public void focusGained(FocusEvent e) {
        final Component comp = e.getComponent();
        final Component eve = this.getJtf(comp);
        if (eve != null) {
            eve.requestFocus();
        }
    }

    @Override
    public void focusLost(FocusEvent e) {
        if (this.clickButton) {
            this.clickButton = false;
            return;
        }
        final Object obj = e.getComponent();
        this.eventLookup(obj);
    }

    private void eventLookup(Object obj) {
        final Component component = this.getJtf(obj);
        if (component != null) {
            this.meditor.getLookup(component);
        }
    }

    private Component getJtf(Object obj) {
        if (obj == this.jbtnLookup) {
            return this.jtfLookup;
        }
        if (obj == this.jbtnFirmename) {
            return this.jtfFirmename;
        }
        if (obj == this.jbtnName) {
            return this.jtfName;
        }
        if (obj == this.jbtnVorname) {
            return this.jtfVorname;
        }
        if (obj == this.jbtnPlz) {
            return this.jtfPlz;
        }
        if (obj == this.jbtnOrt) {
            return this.jtfOrt;
        }
        if (obj == this.jbtnStrasse) {
            return this.jtfStrasse;
        }
        return null;
    }

    void setMediator(CaptureMediator meditor) {
        this.meditor = meditor;
    }

    private JLabel getLabel(Component comp) {
        final String name = comp.getName();
        if (name == null) {
            return null;
        }
        if (name.equals("Reason")) {
            return this.jlbReason;
        }
        if (name.equals("firmenname")) {
            return this.jlbFirmaname;
        }
        if (name.equals("namenszusatz")) {
            return this.jlbNamezusat;
        }
        if (name.equals("vorname")) {
            return this.jlbVorname;
        }
        if (name.equals("name")) {
            return this.jlbNachname;
        }
        if (name.equals("plz")) {
            return this.jlbPlz;
        }
        if (name.equals("ort")) {
            return this.jlbOrt;
        }
        if (name.equals("strasse")) {
            return this.jlbStrasse;
        }
        if (name.equals("hausnummer")) {
            return this.jlbHauseNummer;
        }
        if (name.equals("stockwerk")) {
            return this.jlbStockwerk;
        }
        if (name.equals("adresszusatz")) {
            return this.jlbAddressuzat;
        }
        if (name.equals("co_addresse")) {
            return this.jlbCOAddress;
        }
        if (name.equals("postfachnummer")) {
            return this.jlbPostfach;
        }
        if (name.equals("pickpostnummer")) {
            return this.jlbPickpost;
        }
        if (name.equals("lookup")) {
            return this.jlbLookup;
        }
        if (name.equals("anrede")) {
            return this.jlbAnrede;
        }
        if (name.equals("land")) {
            return this.jlbLand;
        }
        if (name.equals("postlagend")) {
            return this.jlbPostlagend;
        }
        if (name.equals("mypost24")) {
            return this.jlbMyPost24;
        }
        if (name.equals("kdpid")) {
            return this.jlbKDPId;
        }
        return null;
    }

    public void addFocusManagement(VaeFocusTraversalPolicy traversalPolicy) {
        final KeyStroke down = KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0, false);
        final KeyStroke endKey = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, false);
        final KeyStroke up = KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0, false);
        final KeyStroke tab = KeyStroke.getKeyStroke(KeyEvent.VK_TAB, 0, false);
        final HashSet<AWTKeyStroke> keyDown = new HashSet<AWTKeyStroke>();
        keyDown.add(down);
        keyDown.add(endKey);
        final HashSet<AWTKeyStroke> keyUp = new HashSet<AWTKeyStroke>();
        keyUp.add(up);

        final HashSet<AWTKeyStroke> keyNotEnter = new HashSet<AWTKeyStroke>();
        keyNotEnter.add(down);
        final HashSet<AWTKeyStroke> keyTab = new HashSet<AWTKeyStroke>();
        keyTab.add(tab);
        this.addFocusKey(this.jtfLookup, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfFirmename, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfNameZusat, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jcboAnrede, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfVorname, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfName, keyUp, keyNotEnter, traversalPolicy);
        this.addFocusKey(this.jtfPlz, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfOrt, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfStrasse, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfHausNummer, keyUp, keyDown, traversalPolicy);
        // Change request id:
        // addFocusKey(jcboLand.getEditor().getEditorComponent(), keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfPostFach, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfStockwerk, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfAddressuzat, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfCOAddress, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfPickPost, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfPostLagend, keyUp, keyDown, traversalPolicy);
        this.addFocusKey(this.jtfMyPost24, keyUp, keyDown, traversalPolicy);

        this.addFocusCycleKey(this.jtfLookup, this.jbtnLookup, keyTab, traversalPolicy);
        this.addFocusCycleKey(this.jtfFirmename, this.jbtnFirmename, keyTab, traversalPolicy);
        this.addFocusCycleKey(this.jtfVorname, this.jbtnVorname, keyTab, traversalPolicy);
        this.addFocusCycleKey(this.jtfName, this.jbtnName, keyTab, traversalPolicy);
        this.addFocusCycleKey(this.jtfPlz, this.jbtnPlz, keyTab, traversalPolicy);
        this.addFocusCycleKey(this.jtfOrt, this.jbtnOrt, keyTab, traversalPolicy);
        this.addFocusCycleKey(this.jtfStrasse, this.jbtnStrasse, keyTab, traversalPolicy);

        this.jcboReason.getEditor().getEditorComponent().setFocusTraversalKeysEnabled(false);
        this.jcboLand.getEditor().getEditorComponent().setFocusTraversalKeysEnabled(false);
        this.jtfMyPost24.setFocusTraversalKeysEnabled(false);
        this.jtfLookup.setFocusTraversalKeysEnabled(false);
    }

    private void addFocusKey(Component component, HashSet<AWTKeyStroke> backward, HashSet<AWTKeyStroke> forward, VaeFocusTraversalPolicy traversalPolicy) {
        traversalPolicy.addComponent(component);
        component.setFocusTraversalKeys(KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS, backward);
        component.setFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS, forward);

    }

    private void addFocusCycleKey(Container component, Container component1, HashSet<AWTKeyStroke> downStroke, VaeFocusTraversalPolicy traversalPolicy) {
        component.setFocusCycleRoot(true);
        traversalPolicy.addContainer(component);
        traversalPolicy.addContainer(component1);
        component.setFocusTraversalKeys(KeyboardFocusManager.DOWN_CYCLE_TRAVERSAL_KEYS, downStroke);
    }

    /**
     * @note not enable field land from request production.
     * @note using enable field when ocr
     */
    public void enableWhenFocusPickpost() {
        this.jtfNameZusat.setEnabled(true);
        this.jcboAnrede.setEnabled(true);
        this.jtfStockwerk.setEnabled(true);
        this.jtfAddressuzat.setEnabled(true);
        this.jtfCOAddress.setEnabled(true);
        // jcboLand.setEnabled(true);
    }

    public void setDefaultColorBackGroundButton() {
        this.jbtnPlz.setBackground(this.defaultColor);
        this.jbtnOrt.setBackground(this.defaultColor);
        this.jbtnStrasse.setBackground(this.defaultColor);
        this.jbtnName.setBackground(this.defaultColor);
        this.jbtnVorname.setBackground(this.defaultColor);
        this.jbtnFirmename.setBackground(this.defaultColor);
        this.jbtnLookup.setBackground(this.defaultColor);
    }

    public void setColorBackGroundButton(Color color) {
        this.jbtnPlz.setBackground(color);
        this.jbtnOrt.setBackground(color);
        this.jbtnStrasse.setBackground(color);
        this.jbtnName.setBackground(color);
        this.jbtnVorname.setBackground(color);
        this.jbtnFirmename.setBackground(color);
        this.jbtnLookup.setBackground(color);
    }

    private void fieldUtil(KeyEvent evt, JTextField textField) {
        if (evt.getKeyCode() == KeyEvent.VK_BACK_QUOTE) {
            textField.setText("");
            return;
        } else if (evt.getKeyCode() == KeyEvent.VK_F5) {
            textField.setText(Utilities.firstWorld(textField.getText()));
        } else if (evt.getKeyCode() == KeyEvent.VK_F4) {
            if ((textField == this.jtfStrasse) || (textField == this.jtfOrt)) {
                this.meditor.getReLoadData(textField);
            } else {
                textField.setText(Utilities.afterWorld(textField.getText()));
            }
        }
    }

    private int previousCaretPosition;
    private final HighlightPainter lightPaint;

    private void processKey(java.awt.event.KeyEvent evt) {
        if (evt.getKeyCode() == KeyEvent.VK_CONTEXT_MENU) {
            Point caretLocation = new Point();
            final Caret c = ((JTextField) evt.getSource()).getCaret();
            caretLocation = c.getMagicCaretPosition();
            JTextField tmp;
            if (evt.getSource() instanceof JTextField) {
                tmp = (JTextField) evt.getSource();
            } else {
                return;
            }
            this.previousCaretPosition = tmp.getCaretPosition();
            if (this.previousCaretPosition > 0) {
                final char characterAtCaret = tmp.getText().charAt(this.previousCaretPosition - 1);
                if (this.setListModal(characterAtCaret)) {

                    // jList.setSelectedIndex(0);
                    // jPopupMenu.add(jList);
                    this.jListGermanyCharactor.setSelectedIndex(0);
                    this.jPopupMenuGermanyCharactor.add(this.jListGermanyCharactor);

                    final JTextField currentField = tmp;// jtfNameZusat;
                    try {
                        // jPopupMenu.show(currentField, caretLocation.x + 10,
                        // caretLocation.y);
                        // jList.requestFocus();

                        this.jPopupMenuGermanyCharactor.show(currentField, caretLocation.x + 10, caretLocation.y);
                        this.jListGermanyCharactor.requestFocus();
                    } catch (final Exception ex) {
                        log.error(Utilities.getStackTrace(ex));
                    }
                } else {
                    // jPopupMenu.setVisible(false);
                    this.jPopupMenuGermanyCharactor.setVisible(false);
                }
            }
        }
    }

    private void selectCharacterFromSuggest(KeyEvent evt) {
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            final Component component = this.jPopupMenuGermanyCharactor.getInvoker();
            if (component instanceof JTextField) {
                final JTextField field = (JTextField) component;
                if (this.previousCaretPosition < 1) {
                    return;
                }
                final String data = this.jListGermanyCharactor.getSelectedValue().toString();
                final StringBuilder builder = new StringBuilder(field.getText());
                builder.replace(this.previousCaretPosition - 1, this.previousCaretPosition, data);
                field.setText(builder.toString());
                this.jPopupMenuGermanyCharactor.setVisible(false);
                field.setCaretPosition(this.previousCaretPosition);
                field.requestFocus();
            }
        }
        if (evt.getKeyCode() == KeyEvent.VK_ESCAPE) {
            final Component component = this.jPopupMenuGermanyCharactor.getInvoker();
            if (component instanceof JTextField) {
                final JTextField field = (JTextField) component;
                this.jPopupMenuGermanyCharactor.setVisible(false);
                field.requestFocus();
            }
        }

    }

    private void setAutoCompleteLookupModal() {
        this.lookupList = new HashMap<String, DefaultListModel>();
        final String param = "aäáàâæ bß cç eëéèê iìíîï oöòôœ sš uüùû";

        final String data[] = param.split(" ");
        for (final String sour : data) {
            boolean first = true;
            DefaultListModel map = null;
            final char[] array = sour.toCharArray();
            for (final char ar : array) {
                if (first) {
                    map = new DefaultListModel();
                    this.lookupList.put(ar + "", map);
                    first = false;
                    continue;
                }
                map.addElement(ar + "");
            }
        }
    }

    private boolean setListModal(char source) {
        final StringBuilder buffer = new StringBuilder(source + "");
        final DefaultListModel model = this.lookupList.get(buffer.toString().toLowerCase());
        if (model != null) {
            this.jListGermanyCharactor.setModel(model);
            return true;
        }
        return false;
    }

    private void processWarningBlockingWord(JTextField text) {
        final String value = text.getText();
        final ArrayList<Point> match = this.isBlockingWord(value);
        text.getHighlighter().removeAllHighlights();
        // boolean isMatch = isBlockingWord(value);
        if ((match != null) && (match.size() > 0)) {
            for (final Point point : match) {
                try {
                    text.getHighlighter().addHighlight(point.x, point.y, this.lightPaint);
                } catch (final BadLocationException e) {
                    log.warn("", e);
                }
            }
        }
    }

    private static final String PATTERN_WORD_BOUNDARY_END = "(%s)\\b";

    private ArrayList<Point> isBlockingWord(String keyWord) {
        final ArrayList<Point> res = new ArrayList<Point>();
        try {
            keyWord = org.apache.commons.lang3.StringUtils.stripAccents(keyWord.toLowerCase().trim());
            final String BlockingWord = ApplicationConfig.getInstance().getBusinessConfig().getBlockingWord();
            final String[] list = BlockingWord.split(";");
            for (final String blockWord : list) {
                final String tmp = org.apache.commons.lang3.StringUtils.stripAccents(blockWord.toLowerCase());
                Pattern pattern = Pattern.compile(String.format(PATTERN_WORD_BOUNDARY_END, tmp),Pattern.CASE_INSENSITIVE);
                Matcher matcher = pattern.matcher(keyWord);
                while (org.apache.commons.lang3.StringUtils.isNotBlank(tmp) && matcher.find()) {
                    final Point p = new Point(matcher.start(), matcher.end());
                    res.add(p);
                }
            }
        } catch (final Exception e) {
            log.warn("", e);
        }

        return res;
    }


    private int pointLabelY(int i) {
        return 51 + ((34) * i);
    }

    /**
     * this is util get y for capture client use index of frame first is lookup
     * field is 0;
     *
     * @return
     */
    private int pointY(int i) {
        return 46 + ((34) * i);
    }

    private class DisplayInformation extends FocusAdapter {

        @Override
        public void focusGained(FocusEvent e) {
            final String name = e.getComponent().getName();
            CapturePanel.this.meditor.viewInfo(name);
        }
    }

    private class SelectionEventListener extends FocusAdapter {

        private Color currentColor;
        private final Color selectColor = UIManager.getColor("TextField.select");
        private final Font selectFont = UIManager.getFont("Label.selectfont");
        private final Font currentFont = UIManager.getFont("Label.font");
        private final Color lableSelectColor = UIManager.getColor("Label.selectforeground");
        private final Color lableColor = UIManager.getColor("Label.foreground");

        @Override
        public void focusGained(FocusEvent e) {
            if (null == this.selectColor) {
                return;
            }
            final Component comp = e.getComponent();
            if (comp instanceof CustomTextField) {
                ((CustomTextField) comp).setSelect(true);
            } else {
                this.currentColor = comp.getBackground();
                e.getComponent().setBackground(this.selectColor);
                if (null == this.selectFont) {
                    return;
                }
            }
            final JLabel label = CapturePanel.this.getLabel(e.getComponent());
            if (label == null) {
                return;
            }
            label.setFont(this.selectFont);
            label.setForeground(this.lableSelectColor);
            
            /**
             * htvy dev - ABA 113
             * if field postFach haven't data, file postLagernd disable
             * otherwise if field postLagernd haven't data, file postFach disable
             * if choose KDP - 3 field PickPost, PostLagernd, MyPost24 disable
             */
            if(CapturePanel.this.jtfPostFach.getText().isEmpty()) {
            	if(CapturePanel.this.jtfPickPost.isEnabled() && CapturePanel.this.jtfMyPost24.isEnabled()) 
            		CapturePanel.this.jtfPostLagend.setEnabled(true);
            }
            if(CapturePanel.this.jtfPostLagend.getText().isEmpty()) {
            	CapturePanel.this.jtfPostFach.setEnabled(true);
    		}
        }

        @Override
        public void focusLost(FocusEvent e) {
            final Component comp = e.getComponent();

            if (comp instanceof JTextField) {
                String value = Utilities.ignoreNull(((JTextField) comp).getText());
                if (!value.equals("")) {
                    value = value.replaceAll("\\s++", " ");
                    value = StringUtils.capitalize(value);
                    ((JTextField) comp).setText(StringUtils.capitalize(value));
                }
                if (comp instanceof CustomTextField) {
                    ((CustomTextField) comp).setUndoData(value);

                }
            }

            if (null == this.selectColor) {
                return;
            }
            if (comp instanceof CustomTextField) {
                ((CustomTextField) comp).setSelect(false);
            } else {
                e.getComponent().setBackground(this.currentColor);
            }
            if (null == this.selectFont) {
                return;
            }
            final JLabel label = CapturePanel.this.getLabel(e.getComponent());
            if (label == null) {
                return;
            }
            label.setFont(this.currentFont);
            label.setForeground(this.lableColor);
            
            /**
             * htvy dev - ABA 113
             * if field postFach haven't data, file postLagernd disable
             * and if field postLagernd haven't data, file postFach disable
             */
            if(!CapturePanel.this.jtfPostFach.getText().isEmpty()) {
            	CapturePanel.this.jtfPostLagend.setEnabled(false);
            	CapturePanel.this.jtfPostLagend.setText("");
            } else if(!CapturePanel.this.jtfPostLagend.getText().isEmpty()) {
            	CapturePanel.this.jtfPostFach.setEnabled(false);
            	CapturePanel.this.jtfPostFach.setText("");
            }
        }
    }

    private class ProccessKeyEvent extends KeyAdapter {

        @Override
        public void keyPressed(KeyEvent e) {
            if (e.getComponent() instanceof JTextField) {
                CapturePanel.this.fieldUtil(e, (JTextField) e.getComponent());
            }
            CapturePanel.this.processKey(e);
        }
    }

    private class OcrProcessKey extends KeyAdapter {

        @Override
        public void keyPressed(KeyEvent evt) {
            if (evt.isControlDown()) {
                final int keyCode = evt.getKeyCode();
                switch (keyCode) {
                    case KeyEvent.VK_1:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 0);
                        break;
                    case KeyEvent.VK_2:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 1);
                        break;
                    case KeyEvent.VK_3:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 2);
                        break;
                    case KeyEvent.VK_4:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 3);
                        break;
                    case KeyEvent.VK_5:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 4);
                        break;
                    case KeyEvent.VK_6:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 5);
                        break;
                    case KeyEvent.VK_7:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 6);
                        break;
                    case KeyEvent.VK_8:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 7);
                        break;
                    case KeyEvent.VK_9:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 8);
                        break;
                    case KeyEvent.VK_0:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 9);
                        break;

                }
            } else if (evt.isAltDown()) {
                final int keyCode = evt.getKeyCode();
                switch (keyCode) {
                    case KeyEvent.VK_1:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 10);
                        break;
                    case KeyEvent.VK_2:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 11);
                        break;
                    case KeyEvent.VK_3:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 12);
                        break;
                    case KeyEvent.VK_4:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 13);
                        break;
                    case KeyEvent.VK_5:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 14);
                        break;
                    case KeyEvent.VK_6:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 15);
                        break;
                    case KeyEvent.VK_7:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 16);
                        break;
                    case KeyEvent.VK_8:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 17);
                        break;
                    case KeyEvent.VK_9:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 18);
                        break;
                    case KeyEvent.VK_0:
                        CapturePanel.this.meditor.getOcrInformation(evt.getComponent(), (byte) 19);
                        break;

                }
            }

        }
    }

    private class WarningBlockWork extends FocusAdapter {

        @Override
        public void focusLost(FocusEvent e) {
            if (e.getComponent() instanceof JTextField) {
                CapturePanel.this.processWarningBlockingWord((JTextField) e.getComponent());
            }
        }
    }

    /**
     *
     * Copy right code from DefaultHighlighter.DefaultHighlighterPainter
     * <p>
     * change fillRect to drawRect
     *
     */
    private class CustomerHighlightPainter implements Highlighter.HighlightPainter {

        Color color;

        public CustomerHighlightPainter(Color c) {
            this.color = c;
        }

        public Color getColor() {
            return this.color;
        }

        @Override
        public void paint(Graphics g, int offs0, int offs1, Shape bounds, JTextComponent c) {
            final Rectangle alloc = bounds.getBounds();
            try {
                // --- determine locations ---
                final TextUI mapper = c.getUI();
                final Rectangle p0 = mapper.modelToView(c, offs0);
                final Rectangle p1 = mapper.modelToView(c, offs1);

                // --- render ---
                final Color color = this.getColor();

                if (color == null) {
                    g.setColor(c.getSelectionColor());
                } else {
                    g.setColor(color);
                }
                if (p0.y == p1.y) {
                    // same line, render a rectangle
                    final Rectangle r = p0.union(p1);
                    g.drawRect(r.x, r.y, r.width, r.height);
                } else {
                    // different lines
                    final int p0ToMarginWidth = (alloc.x + alloc.width) - p0.x;
                    g.drawRect(p0.x, p0.y, p0ToMarginWidth, p0.height);
                    if ((p0.y + p0.height) != p1.y) {
                        g.drawRect(alloc.x, p0.y + p0.height, alloc.width, p1.y - (p0.y + p0.height));
                    }
                    g.drawRect(alloc.x, p1.y, (p1.x - alloc.x), p1.height);
                }
            } catch (final BadLocationException e) {
                log.warn("", e);
            }
        }
    }

    public void setUseSuggestion(boolean useSuggestion) {
        final Component[] components = this.getComponents();
        for (final Component com : components) {
            if (com instanceof AutoTextFieldInterface) {
                ((AutoTextFieldInterface) com).setUseSuggestion(useSuggestion);
            }
        }

    }

    public void setKdpid(String kdpid) {
        this.jlbKDPId.setText("<html> <b>KDP ID</b>: <font color=red size =5><b>" + kdpid + "</b></font></html>");
    }
    
    //Handle error Font of JTextField- UTF8
    // Dev by htvy
    public String handleErrorFontTextField(String str) {
    	if(str != null) {
			try {
				str = new String(str.getBytes("UTF-8"), "UTF-8");	
	 		} catch (UnsupportedEncodingException e) {
	 			e.printStackTrace();
			}
			return str;
    	}else {
			return "";
		}	
  	}
}
