package com.ghp.vae.data_entry.common.autocomplete;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ComboBoxAdaptor extends AbstractComponentAdaptor implements
		ActionListener {

	private JComboBox comboBox;

	public ComboBoxAdaptor(JComboBox comboBox) {
		this.comboBox = comboBox;
		comboBox.addActionListener(this);
	}

	public void actionPerformed(ActionEvent actionEvent) {
		markEntireText();
	}

	public int getItemCount() {
		return comboBox.getItemCount();
	}

	public Object getItem(int index) {
		return comboBox.getItemAt(index);
	}

	public void setSelectedItem(Object item) {
		comboBox.setSelectedItem(item);
	}

	public Object getSelectedItem() {
		return comboBox.getModel().getSelectedItem();
	}

	public JTextComponent getTextComponent() {
		return (JTextComponent) comboBox.getEditor().getEditorComponent();
	}
}