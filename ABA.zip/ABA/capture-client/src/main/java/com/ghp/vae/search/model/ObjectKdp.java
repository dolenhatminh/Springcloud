package com.ghp.vae.search.model;

public class ObjectKdp {

	Integer plz;
	String ort;
	String strasse;
	String name;
	String vname;
	String hausNummer;
	String hausNummer_a;
	String landcode;
	String pf;

	String kdpType;
	String anrede;
	String adr_id;
	String aadr_id;
	String hauskey;

	int type;

	public ObjectKdp(Integer plz, String ort, String strasse, String name, String vname, String hausNummer, String hausNummer_a, String landcode, String pf,
			String kdpType, String anrede, String adr_id, String aadr_id, String hauskey, int type) {
		super();
		this.plz = plz;
		this.ort = ort;
		this.strasse = strasse;
		this.name = name;
		this.vname = vname;
		this.hausNummer = hausNummer;
		this.hausNummer_a = hausNummer_a;
		this.landcode = landcode;
		this.pf = pf;

		this.kdpType = kdpType;
		this.anrede = anrede;
		this.adr_id = adr_id;
		this.aadr_id = aadr_id;
		this.hauskey = hauskey;

		this.type = type;
	}

	public Integer getPlz() {
		return this.plz;
	}

	public void setPlz(Integer plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return this.ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getStrasse() {
		return this.strasse;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getVname() {
		return this.vname;
	}

	public void setVname(String vname) {
		this.vname = vname;
	}

	public String getHausNummer_a() {
		return this.hausNummer_a;
	}

	public void setHausNummer_a(String hausNummer_a) {
		this.hausNummer_a = hausNummer_a;
	}

	public String getLandcode() {
		return this.landcode;
	}

	public void setLandcode(String landcode) {
		this.landcode = landcode;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getHausNummer() {
		return this.hausNummer;
	}

	public void setHausNummer(String hausNummer) {
		this.hausNummer = hausNummer;
	}

	public String getPf() {
		return this.pf;
	}

	public void setPf(String pf) {
		this.pf = pf;
	}

	public String getKdpType() {
		return this.kdpType;
	}

	public void setKdpType(String kdpType) {
		this.kdpType = kdpType;
	}

	public String getAnrede() {
		return this.anrede;
	}

	public void setAnrede(String anrede) {
		this.anrede = anrede;
	}

	public String getAdr_id() {
		return this.adr_id;
	}

	public void setAdr_id(String adr_id) {
		this.adr_id = adr_id;
	}

	public String getAadr_id() {
		return this.aadr_id;
	}

	public void setAadr_id(String aadr_id) {
		this.aadr_id = aadr_id;
	}

	public String getHauskey() {
		return this.hauskey;
	}

	public void setHauskey(String hauskey) {
		this.hauskey = hauskey;
	}

	public int getType() {
		return this.type;
	}

	public void setType(int type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "ObjectKdp [plz=" + this.plz + ", ort=" + this.ort + ", strasse=" + this.strasse + ", name=" + this.name + ", vname=" + this.vname
				+ ", hausNummer=" + this.hausNummer + ", hausNummer_a=" + this.hausNummer_a + ", landcode=" + this.landcode + ", pf=" + this.pf + ", kdpType="
				+ this.kdpType + ", anrede=" + this.anrede + ", adr_id=" + this.adr_id + ", aadr_id=" + this.aadr_id + ", hauskey=" + this.hauskey + ", type="
				+ this.type + "]";
	}

}
