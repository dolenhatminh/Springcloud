/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ghp.vae.data_entry.bll;

/**
 *
 * @author vtbinh
 */
public class BLLField implements Cloneable{

    //field name
    private String name;
    //value of field
    private String value;
    //typed of field
    private String typeid;

    public BLLField()
    {
        //do nothing
    }
    @Override
    public BLLField clone() throws CloneNotSupportedException
    {
        return (BLLField)super.clone();
    }
    //<editor-fold defaultstate="collapsed" desc="get/set methods">
    public BLLField(String name, String value, String typeid) {
        this.name = name;
        this.value = value;
        this.typeid = typeid;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTypeid() {
        return typeid;
    }

    public void setTypeid(String typeid) {
        this.typeid = typeid;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
    //</editor-fold>
}
