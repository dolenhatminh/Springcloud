package com.ghp.vae.data_entry.common;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EncryptionHelper {

	private static Logger log = LoggerFactory.getLogger(EncryptionHelper.class);

	private static final String PASS_PHRASE = "ghpfareasthoathan";

	public static String encrypt(String msg) {
		try {
			final KeySpec keySpec = new DESKeySpec(PASS_PHRASE.getBytes());
			final SecretKey key = SecretKeyFactory.getInstance("DES").generateSecret(keySpec);
			final Cipher ecipher = Cipher.getInstance(key.getAlgorithm());
			ecipher.init(Cipher.ENCRYPT_MODE, key);
			// Encode the string into bytes using utf-8
			final byte[] utf8 = msg.getBytes("UTF8");
			// Encrypt
			final byte[] enc = ecipher.doFinal(utf8);
			// Encode bytes to base64 to get a string
			return new sun.misc.BASE64Encoder().encode(enc);
		} catch (final InvalidKeyException e) {
			log.error("", e);
		} catch (final InvalidKeySpecException e) {
			log.error("", e);
		} catch (final NoSuchAlgorithmException e) {
			log.error("", e);
		} catch (final NoSuchPaddingException e) {
			log.error("", e);
		} catch (final IllegalStateException e) {
			log.error("", e);
		} catch (final IllegalBlockSizeException e) {
			log.error("", e);
		} catch (final BadPaddingException e) {
			log.error("", e);
		} catch (final UnsupportedEncodingException e) {
			log.error("", e);
		}
		return null;
	}

	public static String decrypt(String msg) {
		try {
			final KeySpec keySpec = new DESKeySpec(PASS_PHRASE.getBytes());
			final SecretKey key = SecretKeyFactory.getInstance("DES").generateSecret(keySpec);
			final Cipher decipher = Cipher.getInstance(key.getAlgorithm());
			decipher.init(Cipher.DECRYPT_MODE, key);
			// Decode base64 to get bytes
			final byte[] dec = new sun.misc.BASE64Decoder().decodeBuffer(msg);
			// Decrypt
			final byte[] utf8 = decipher.doFinal(dec);
			// Decode using utf-8
			return new String(utf8, "UTF8");
		} catch (final InvalidKeyException e) {
			log.error("", e);
		} catch (final InvalidKeySpecException e) {
			log.error("", e);
		} catch (final NoSuchAlgorithmException e) {
			log.error("", e);
		} catch (final NoSuchPaddingException e) {
			log.error("", e);
		} catch (final IOException e) {
			log.error("", e);
		} catch (final IllegalStateException e) {
			log.error("", e);
		} catch (final IllegalBlockSizeException e) {
			log.error("", e);
		} catch (final BadPaddingException e) {
			log.error("", e);
		}
		return null;
	}

	public static String getParameter(String data, String key) {
		String res = "";
		boolean found = false;
		try {
			if (data != null) {
				final String[] arrData = data.split("&");
				for (int i = 0; (i < arrData.length) && !found; i++) {
					final String dataI = arrData[i];
					final String[] arrDataI = dataI.split("=");
					// compare key to get the value
					if (arrDataI[0].trim().equalsIgnoreCase(key.trim())) {
						res = arrDataI[1];
						found = true;
					}
				}
			}
		} catch (final Exception e) {
		}
		return res;
	}

	public static String encodeURL(String url) {
		try {
			return URLEncoder.encode(url, "UTF-8");
		} catch (final UnsupportedEncodingException e) {
			log.error("", e);
		}
		return null;
	}
}
