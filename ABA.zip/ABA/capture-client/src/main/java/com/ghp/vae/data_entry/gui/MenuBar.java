package com.ghp.vae.data_entry.gui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuBar extends JMenuBar implements ActionListener {
	private String SAVE   = "SAVE";
	private String SEARCH = "SEARCH";
	private String EXIT   = "EXIT";
	private String LEFT   = "LEFT";
	private String RIGHT  = "RIGHT";
	private String SUGGEST  = "SUGGEST";
	private String NOT_SUGGEST  = "NOT_SUGGEST";
	private String HELP   = "HELP";
	private String ABOUT  = "ABOUT";
	
	private CaptureMediator meditor;
	
	public MenuBar() {
		initComponent();
	}

	//init menubar with file, actions, tools, about.
	private void initComponent() {
		createMenuFile();
		createMenuAction();
		createMenuTool();
		createMenuAbout();		
	}

	private void createMenuAbout() {
		JMenu jmAbout = new JMenu("About");
		this.add(jmAbout);
		
		JMenuItem jmiHelp= new javax.swing.JMenuItem("Help");
		jmiHelp.setActionCommand(HELP);
		jmiHelp.addActionListener(this);
		
		JMenuItem jmiAbout= new javax.swing.JMenuItem("About");
		jmiAbout.setActionCommand(ABOUT);
		jmiAbout.addActionListener(this);
		
		jmAbout.add(jmiHelp);
		jmAbout.add(jmiAbout);
	}

	private void createMenuTool() {
		JMenu jmTool = new JMenu("Tools");
		this.add(jmTool);
		
		JMenuItem jmiRotateLeft = new javax.swing.JMenuItem("Rotate Left");
		jmiRotateLeft.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
		jmiRotateLeft.setMnemonic('L');
		jmiRotateLeft.setActionCommand(LEFT);
		jmiRotateLeft.addActionListener(this);
		
		JMenuItem jmiRotateRight = new javax.swing.JMenuItem("Rotate Right");
		jmiRotateRight.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_MASK));
		jmiRotateRight.setMnemonic('R');
		jmiRotateRight.setActionCommand(RIGHT);
		jmiRotateRight.addActionListener(this);
		
		jmTool.add(jmiRotateLeft);
		jmTool.add(jmiRotateRight);
		
		JRadioButtonMenuItem jmiUse = new JRadioButtonMenuItem("Use Suggestion");
		JRadioButtonMenuItem jmiNotUse = new JRadioButtonMenuItem("Not Suggestion");
		ButtonGroup group= new ButtonGroup();
		group.add(jmiUse);
		group.add(jmiNotUse);
		
		jmiUse.setSelected(true);
		
		jmiUse.setActionCommand(SUGGEST);
		jmiNotUse.setActionCommand(NOT_SUGGEST);
		
		jmiUse.addActionListener(this);
		jmiNotUse.addActionListener(this);
		
		jmTool.add(jmiUse);
		jmTool.add(jmiNotUse);
		
	}

	private JMenuItem jmiSearch;
	private JMenuItem jmiSave;
	private void createMenuAction() {
		JMenu jmAction = new JMenu("Actions");
		this.add(jmAction);

		jmiSearch = new javax.swing.JMenuItem("Search");
		jmiSearch.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F, java.awt.event.InputEvent.CTRL_MASK));
		jmiSearch.setActionCommand(SEARCH);
		jmiSearch.addActionListener(this);
		
		jmAction.add(jmiSearch);
	}

	private void createMenuFile() {
		JMenu jmFile = new JMenu("File");
		this.add(jmFile);
		
		/**
		 * Request ID : 1329 Change| New Hot key for saving card 
		 */
		jmiSave = new javax.swing.JMenuItem("Save");
		jmiSave.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_SPACE, java.awt.event.InputEvent.CTRL_MASK));
		jmiSave.setActionCommand(SAVE);
		jmiSave.addActionListener(this);
//		jmiSave.setMnemonic('S');
		
		JMenuItem jmiExit = new javax.swing.JMenuItem("Exit");
		jmiExit.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_MASK));
		jmiExit.setActionCommand(EXIT);
		jmiExit.addActionListener(this);
		jmiExit.setMnemonic('X');
		
		jmFile.add(jmiSave);
		jmFile.add(jmiExit);	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String actionCommand = e.getActionCommand();
		if(actionCommand.equals(SAVE)){
			meditor.saveMenuItem();
			return;
		}
		if(actionCommand.equals(SEARCH)){			
			meditor.search();		
			return;
		}
		if(actionCommand.equals(EXIT)){
			meditor.exit();
			return;
		}
		if(actionCommand.equals(LEFT)){
			meditor.rotataLeft();
			return;
		}
		if(actionCommand.equals(RIGHT)){
			meditor.rotataRight();
			return;
		}
		if(actionCommand.equals(HELP)){
			meditor.help();
			return;
		}
		if(actionCommand.equals(SUGGEST)){
			Object source = e.getSource();
			if(source instanceof JRadioButtonMenuItem){
				meditor.setUseSuggestion(((JRadioButtonMenuItem) source).isSelected());
			}else{
				meditor.setUseSuggestion(true);
			}
			return;
		}
		if(actionCommand.equals(NOT_SUGGEST)){
			Object source = e.getSource();
			if(source instanceof JRadioButtonMenuItem){
				meditor.setUseSuggestion(!((JRadioButtonMenuItem) source).isSelected());
			}else{
				meditor.setUseSuggestion(false);
			}
			return;
		}
		if(actionCommand.equals(ABOUT)){
			meditor.about();
			return;
		}
	}
	//<ndtuan>
	public void actionPerformed(){
		meditor.search();
		return;
	}
	//<ndtuan>

	public void setEnableSearch(boolean enable) {
		jmiSearch.setEnabled(enable);
	}

	public void setEnableSave(boolean disableLookup) {
		jmiSave.setEnabled(disableLookup);
	}

	JMenuItem getJmiSave() {
		return jmiSave;
	}
	void setMediator(CaptureMediator meditor) {
		this.meditor = meditor;
	}

	public void enableSaveButton(boolean b) {
		jmiSave.setEnabled(b);
	}
}
