/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ghp.vae.data_entry.ptl.autocomplete;

import net.java.balloontip.BalloonTip;
import net.java.balloontip.positioners.BasicBalloonTipPositioner;
import net.java.balloontip.styles.BalloonTipStyle;
import net.java.balloontip.styles.EdgedBalloonStyle;
import org.apache.commons.collections.KeyValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

/**
 * 
 * @author lthieu
 */
public class CustomTextField extends JTextField {

	private static Logger log = LoggerFactory.getLogger(CustomTextField.class);
	private BalloonTip tip;
	private BalloonTip tipValidate;
	private JLabel lblTip;
	private JLabel lblTipValidate;
	private String undoData;

	/**
	 * this is for change background.
	 * Request ID : 1125 So sánh thông tin của mặt nạ nhập và thông tin trên kết quả KDP đã được chọn
	 */
	private Color normalColor;
	private Color selectColor;
	private Color differentColor;
	private boolean different;
	private boolean select;

	public CustomTextField() {
		init();
	}

	private void init() {
		lblTipValidate = new JLabel("");
		lblTipValidate.setFont(new Font("Tahoma", Font.BOLD, 16));
		tipValidate = new BalloonTip(this, lblTipValidate,
				createBalloonTipStyleValidate(),
				BalloonTip.Orientation.LEFT_ABOVE,
				BalloonTip.AttachLocation.ALIGNED, 0, 5, true);
		tipValidate.setVisible(false);

		normalColor = UIManager.getColor("TextField.background");
		selectColor = UIManager.getColor("TextField.select");
		initTooltip();
		eventCopy();
	}

	public class SuggestionCellRenderer extends DefaultListCellRenderer {
		private static final long serialVersionUID = 1L;

		public Component getListCellRendererComponent(JList list,
				Object value, int index, boolean isSelected,
				boolean cellHasFocus) {
			super.getListCellRendererComponent(list, value, index, isSelected,
					cellHasFocus);
			if (value instanceof KeyValue) {
				KeyValue kv = (KeyValue) value;
				String text = kv.getValue() != null
						&& !kv.getValue().toString().isEmpty() ? "    (***)"
						: "";
				if (!text.isEmpty()) {
					setForeground(Color.GRAY);
				}else
				{
					setForeground(Color.BLACK);
				}
				setText(kv.getKey().toString());

			}
			return this;
		}
	}

	private void initTooltip() {
		lblTip = new JLabel("");
		lblTip.setFont(new Font("Tahoma", Font.BOLD, 12));
		tip = new BalloonTip(this, lblTip, createBalloonTipStyle(), true);
		// BalloonTip.Orientation.LEFT_ABOVE,
		// BalloonTip.AttachLocation.ALIGNED, 0, 5, true);

		tip.setPositioner(new CustomerPointerTooltip(this));
		tip.setVisible(false);
	}

	private void eventCopy() {
		KeyStroke gettext = KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, false);
		/**
		 * Request ID : 1126 Chuc Nang Undo 
		 */
		KeyStroke undoText = KeyStroke.getKeyStroke(KeyEvent.VK_U,
				KeyEvent.CTRL_MASK, false);
		ActionListener copyAction = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (e.getActionCommand().equalsIgnoreCase("GetText")) {
						if (tip != null) {
							if (!lblTip.getText().equals("")) {
								setText(lblTip.getText());
								tip.setVisible(false);
							}
						}
					}
					if (e.getActionCommand().equalsIgnoreCase("Copy")) {
						if (tip != null) {
							undoText();
						}
					}
				} catch (Exception ex) {
					log.error("", ex);
				}
			}

		};
		this.registerKeyboardAction(copyAction, "GetText", gettext,
				JComponent.WHEN_FOCUSED);
		this.registerKeyboardAction(copyAction, "Copy", undoText,
				JComponent.WHEN_FOCUSED);
	}

	public void setToolTip(String text) {
		if (tip != null) {
			lblTip.setText(text);
			tip.setContents(lblTip);

		}
		tip.setLocation(this.getWidth() + this.getLocation().x,
				this.getLocation().y + 50);
	}

	public void clearToolTip() {
		if (tip != null) {
			lblTip.setText("");
			tip.setContents(lblTip);
			setVisibleTooltip(false);
		}
	}

	private BalloonTipStyle createBalloonTipStyle() {
		return new EdgedBalloonStyle(Color.white, Color.blue);
	}

	private BalloonTipStyle createBalloonTipStyleValidate() {
		return new EdgedBalloonStyle(new Color(255, 227, 187), Color.blue);
	}

	public void setVisibleTooltip(boolean isVisible) {
		if (tip != null) {
			if (isVisible == false) {
				tip.setVisible(isVisible);
			} else {
				if (!lblTip.getText().equals("")
						&& !this.getText().equalsIgnoreCase(lblTip.getText())) {
					tip.setVisible(isVisible);
				}
			}
		}
	}

	public String getToolTipValue() {
		return lblTip.getText().trim();
	}

	public boolean getTipExist() {
		return tip == null ? false : true;
	}

	public void setToolTipValueToText() {
		if (tip != null) {
			if (!lblTip.getText().equals("")) {
				setText(lblTip.getText());
			}
		}
	}

	@Override
	public void setText(String text) {
		if (this.getText().equals(text)) {
			setCaretPosition(super.getText().length());
			return;
		}
		super.setText(text);
		setCaretPosition(super.getText().length());
	}

	public void setToolTipValidate(String text) {
		if (tipValidate != null) {
			lblTipValidate.setText(text);
			tipValidate.setContents(lblTipValidate);
			if (!text.equals("")) {
				setVisibleTooltipValidate(true);
			} else {
				setVisibleTooltipValidate(false);
			}
		}
		tipValidate.setLocation(this.getWidth() + this.getLocation().x,
				this.getLocation().y + 50);
	}

	public void clearToolTipValidate() {
		if (tipValidate != null) {
			lblTipValidate.setText("");
			tipValidate.setContents(lblTipValidate);
			setVisibleTooltipValidate(false);
		}
	}

	public void setVisibleTooltipValidate(boolean isVisible) {
		if (tipValidate != null) {
			tipValidate.setVisible(isVisible);
		}
	}

	public JPopupMenu getPopupMenu() {
		return null;
	}

	@Override
	public void setBounds(int x, int y, int width, int height) {
		super.setBounds(x, y, width, height);
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
	}

	private class CustomerPointerTooltip extends BasicBalloonTipPositioner {
		public CustomerPointerTooltip(Component parent) {
			super(0, 0);
			this.parent = parent;
		}

		Component parent;

		public void determineLocation(Rectangle attached) {

			Dimension dimension = balloonTip.getPreferredSize();
			int balloonWidth = dimension.width;
			int balloonHeight = dimension.height;
			flipX = false;
			flipY = false;

			hOffset = preferredHorizontalOffset;
			if (fixedAttachLocation) {
				x = new Float(attached.x + attached.width * attachLocationX)
						.intValue() - hOffset;
				y = new Float(attached.y + attached.height * attachLocationY)
						.intValue() - balloonHeight;
			} else {
				x = attached.x;
				y = attached.y - balloonHeight;
			}

			if (orientationCorrection) {
				if (y < 0) {
					flipY = true;
					if (fixedAttachLocation) {
						y += balloonHeight;
					} else {
						y = attached.y + attached.height;
					}
				}
			}

			if (x < 0) {
				flipX = true;
				if (fixedAttachLocation) {
					x -= balloonWidth - 2 * hOffset;
				} else {
					x = attached.x + attached.width - balloonWidth;
				}
				hOffset = balloonWidth - hOffset;
			}

			if (offsetCorrection) {
				applyOffsetCorrection();
			}

		}
	}

	public void setUndoData(String undoData) {
		this.undoData = undoData;
	}

	private void undoText() {
		this.setText(undoData);
	}

	public void setNormalColor(Color normalColor) {
		this.normalColor = normalColor;
	}

	public void setSelectColor(Color selectColor) {
		this.selectColor = selectColor;
	}

	public void setDifferentColor(Color differentColor) {
		this.differentColor = differentColor;
	}

	public void setDifferent(boolean different) {
		this.different = different;
	}

	public void changeBackGround() {
		if (different) {
			this.setBackground(differentColor);
		} else {
			if (select) {
				this.setBackground(selectColor);
			} else {
				this.setBackground(normalColor);
			}
		}
	}

	public void changeBackGround(boolean different) {
		if (this.different == different) {
			return;
		}
		this.different = different;
		if (different) {
			this.setBackground(differentColor);
		} else {
			if (select) {
				this.setBackground(selectColor);
			} else {
				this.setBackground(normalColor);
			}
		}
	}

	public void setSelect(boolean select) {
		this.select = select;
		if (different) {
			this.setBackground(differentColor);
			return;
		}
		if (select) {
			this.setBackground(selectColor);
		} else {
			this.setBackground(normalColor);
		}
	}
	// @Override
	// public void setBackground(Color bg) {
	// super.setBackground(bg);
	// }
	//
}
