package com.ghp.vae.search.model;

public class ZubofiAddress {
    public ZubofiAddress(String plz, String ort, String strasse,
            String hausNummer, String hausNummera) {
        super();
        this.plz = plz;
        this.ort = ort;
        this.strasse = strasse;
        this.hausNummer = hausNummer;
        this.hausNummera = hausNummera;
    }

    public ZubofiAddress(String plz, String ort, String strasse,
            String hausNummer, String hausNummera, int type) {
        super();
        this.plz = plz;
        this.ort = ort;
        this.strasse = strasse;
        this.hausNummer = hausNummer;
        this.hausNummera = hausNummera;
        this.type = type;
    }

    public ZubofiAddress(String plz, String ort, int type) {
        super();
        this.ort = ort;
        this.plz = plz;
        this.type = type;
    }

    String plz;
    String ort;
    String strasse;
    String hausNummer;
    String hausNummera;
    /**
     * 1 - POSTFACH 
     * 2 - PICKPOST
     * 3 - MYPOST24
     * 4 - POSTLAGERND
     */
    int type;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getPlz() {
        return plz;
    }

    public void setPlz(String plz) {
        this.plz = plz;
    }

    public String getOrt() {
        return ort;
    }

    public void setOrt(String ort) {
        this.ort = ort;
    }

    public String getStrasse() {
        return strasse;
    }

    public void setStrasse(String strasse) {
        this.strasse = strasse;
    }

    public String getHausNummer() {
        return hausNummer;
    }

    public void setHausNummer(String hausNummer) {
        this.hausNummer = hausNummer;
    }

    public String getHausNummera() {
        return hausNummera;
    }

    public void setHausNummera(String hausNummera) {
        this.hausNummera = hausNummera;
    }

    @Override
    public String toString() {
        return "ZubofiAddress [plz=" + plz + ", ort=" + ort + ", strasse="
                + strasse + ", hausNummer=" + hausNummer + ", hausNummera="
                + hausNummera + ", type=" + type + "]";
    }
    
}
