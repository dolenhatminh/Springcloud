package com.ghp.vae.data_entry.common;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public class CheckInput extends PlainDocument {
	private static final long serialVersionUID = 1L;
	private int MAXLENGTH;
	private String CheckString="";

	public CheckInput(int maxlength, String sOption){
		this.MAXLENGTH = maxlength;
		this.CheckString = sOption;
	}

	public CheckInput(int maxlength, int Option){
		this.MAXLENGTH = maxlength;
		// accept mark *
		switch  (Option) {
		case 1:// check Vorname
			this.CheckString ="`!@#$^&()+=\\|{}[]:\"<>,/?0123456789~";
			break;
		case 2:// check Nachname
			this.CheckString ="`!@#$^()+=\\|{}[]:\"<>,/?~";
			break;
		case 3:// check Strasse
			this.CheckString ="`!@#$&()+=\\|{}[]:,\"<>?~";
			break;
		case 4:// check Hausenumer
			this.CheckString ="`'!@#$&,^()+=\\|{}[ ]:\"<>?;ABCDEFGHIJKLMNOPQRSTUVWXYZÃ¶Ã–Ã¤Ã„Ã¼ÃœÃŸ%~";
			break;
		case 5:// check PLZ
			this.CheckString ="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz Ã¶Ã–Ã¤Ã„Ã¼ÃœÃŸ`!@#$&^()+=\\|{}[]:\";<>?/-'~";
			break;
		case 6:// check Ort
			this.CheckString ="`0123456789!@#$&()+=\\|{}[]:\"<>?/~";
			break;
		case 7:// check email
			this.CheckString ="`ABCDEFGHIJKLMNOPQRSTUVWXYZï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½!^%,#$&( )+=\\|{}[]:\";<>?'~";
			break;
		case 8:// check telefone
			this.CheckString =" `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½!@#$&^.()+=\\|{}[]:\";,<>?%_-'~";
			break;
		case 9:// check mobile
			this.CheckString =" `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½!@#$&^.()+=\\|{}[]:\";,<>?%_-'";
			break;
		case 10:// check domain
			this.CheckString ="`ABCDEFGHIJKLMNOPQRSTUVWXYZï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½!@^%,#$&( )+=\\|{}[]:\";<>?~";
			break;
		case 11: // check number
			this.CheckString =" `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½!@#$&^.()+=\\|{}/[]:\";,<>?%_-'~";
			break;
		case 12: // check date
			this.CheckString =" `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½!@#$&^()+=\\|{}/[]:\";,<>?%_-'~";
			break;
		case 13:// check name supplementary.
			this.CheckString ="`!@#$^&()+=\\|{}[]:\"<>,?0123456789~";
			break;
		case 14:// No check all.
			this.CheckString ="";
			break;
		case 15:// No check all.
			this.CheckString ="`!@#$^()+=\\|{}[]:\"<>,?~";
			break;
		case 16: // check double
			this.CheckString =" `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½!@#$&^()+=\\|{}/[]:\";,<>?%_-'~";
			break;
		}
	}

	/**
	 *  Call function insert when typing key
	 **/ 
    @Override
	public void insertString(int offs,String str,AttributeSet a){
    	int textlength = this.getEndPosition().getOffset();
		if (textlength<= this.MAXLENGTH){
          	int remain = MAXLENGTH - textlength;
        	int count = 0;
			if(str==null) {
				return;
			}
			char[] addedFigures=str.toCharArray();
			char c;
			StringBuffer buffer = new StringBuffer();
			for(int i= 0 ; i < addedFigures.length;i++){
				c=addedFigures[i];
				if( !Utilities.inString(CheckString,c)){
					buffer.append(c);
					count++;
					if(count > remain){
						break;
					}
				}
			}
			String data = buffer.toString();
			if(data.equals("")){
				return;
			}
			try {
				super.insertString(offs,data,a);
			} catch (BadLocationException e) {
			}
		}
	}	
}