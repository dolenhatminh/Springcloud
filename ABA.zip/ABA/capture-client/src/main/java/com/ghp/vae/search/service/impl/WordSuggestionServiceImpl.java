/*
 * To change this license header, choose License Headers in Project Properties. To change this template file, choose
 * Tools | Templates and open the template in the editor.
 */
package com.ghp.vae.search.service.impl;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import org.apache.commons.lang.WordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.ptl.autocomplete.service.dto.ItemSearchResult;
import com.ghp.vae.data_entry.ptl.state.AroundDialog;
import com.ghp.vae.search.service.IWordSuggestionService;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.sps.vn.config.ApplicationConfig;

/**
 *
 * @author pnmai
 */
public class WordSuggestionServiceImpl extends AbstractLookupProxyService implements IWordSuggestionService {

	/**
	 * The log.
	 */
	private static Logger log = LoggerFactory.getLogger(WordSuggestionServiceImpl.class);

	List<ItemSearchResult> currentSuggest = null;
	List<String> selections = new ArrayList<String>();

	@Override
	public List<ItemSearchResult> suggest(String word) throws Exception {
		final List<ItemSearchResult> itemSearchResults = new ArrayList<ItemSearchResult>();

		try {
			String remoteUrl;
			word = word.trim();
			if (word.matches("\\d+\\w*")) {
				remoteUrl = ApplicationConfig.getInstance().getLookupConfig().getWordSuggestionConfig()
						.getSearchSuggestRestService();
				log.debug("Search suggest :" + word + "####" + remoteUrl);
			} else {
				remoteUrl = ApplicationConfig.getInstance().getLookupConfig().getWordSuggestionConfig()
						.getSuggestRestService();
				log.debug("suggest :" + word + "####" + remoteUrl);
			}
			final Map<String, String> params = new HashMap<String, String>();
			params.put("word", word);
			final String res = this.callRemote(params, remoteUrl);
			final JsonParser parser = new JsonParser();
			final JsonArray hits = parser.parse(res).getAsJsonArray();
			final Gson gson = new Gson();

			for (final JsonElement jsonElement : hits) {
				itemSearchResults.add(gson.fromJson(jsonElement, ItemSearchResult.class));
			}
			this.currentSuggest = itemSearchResults;
		} catch (final Exception e) {
			log.error("", e);
			EventQueue.invokeLater(new Runnable() {

				@Override
				public void run() {
					AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
							JOptionPane.WARNING_MESSAGE);
				}
			});
		}
		return itemSearchResults;
	}

	@Override
	public void accept(int indexWord) throws Exception {
		final ItemSearchResult result = this.currentSuggest.get(indexWord);
		if (result.getKey().isEmpty()) {
			return;
		}
		final String remoteUrl = ApplicationConfig.getInstance().getLookupConfig().getWordSuggestionConfig()
				.getWeightSuggestRestService() + "/" + result.getKey() + "/" + (result.getNumberOfSuggestion() + 1);
		final Map<String, String> params = new HashMap<String, String>();
		this.callPostRemote(params, remoteUrl);
		this.selections.add(result.getValue().toLowerCase());
	}

	@Override
	public void learn(String word) throws Exception {
		// TODO
	}

	@Override
	public void clearSelection() {
		this.selections.clear();
	}

}
