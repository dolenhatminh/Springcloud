package com.ghp.vae.data_entry.face;

public interface ObjectInformation {

	byte getAction();
	void setAction(byte lookupNormal);
	//us sugesst for field.
	Object getSource();
	void setSource(Object source);
	void clearData();
}