package com.ghp.vae.data_entry.gui;

import java.util.HashMap;

import javax.jms.JMSException;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.ptl.state.AroundDialog;
import com.sps.vn.config.ApplicationConfig;

public class Communication implements Runnable {

	private static Logger log = LoggerFactory.getLogger(Communication.class);

	CaptureMediator mediator;
	JDialog dialog;
	private Thread scheduler;
	private long timeDelay;
	private ActiveMQClient client;

	public Communication(CaptureMediator mediator) throws JMSException {
		this.mediator = mediator;
		final JOptionPane panel = new JOptionPane("Ban co the qua du an khac", JOptionPane.WARNING_MESSAGE);
		this.dialog = panel.createDialog(mediator.getProcessLoadCard(), "warning");
		this.dialog.setModal(false);
		this.timeDelay = 10000;

		try {
			this.timeDelay = ApplicationConfig.getInstance().getBusinessConfig().getShowPopupTime();
		} catch (final Exception ex) {
			log.error("", ex);
		}

		if (this.client == null) {
			this.client = new ActiveMQClient();
		}
	}

	public void loadCardEvent(boolean gettingCard) throws JMSException {
		if (gettingCard) {
			this.createScheduleOpenPopup();
		} else {
			this.createScheduleClosePopup();
		}

	}

	private void createScheduleClosePopup() throws JMSException {
		if (this.dialog.isVisible()) {
			try {
				Thread.sleep(100);
			} catch (final InterruptedException e) {
			}
			this.dialog.setVisible(false);
			this.dialog.dispose();
		}
		if (this.scheduler.isAlive()) {
			this.scheduler.interrupt();
		}
		log.info("VAE Capture starting capture");

		// *** Killing Softly - PAUSE
		new Thread() {
			@Override
			public void run() {
				try {
					if (ApplicationConfig.getInstance().getWorking2ProjectConfig().isConnectToBrokerActiveMQ()) {
						final HashMap<String, String> message = ApplicationConfig.getInstance()
								.getWorking2ProjectConfig().getPauseCmd();
						Communication.this.client.sendCommand(message,
								ApplicationConfig.getInstance().getWorking2ProjectConfig().getActiveMQJmsTimeout());
					}
				} catch (final javax.jms.IllegalStateException ise) {
					AroundDialog.showMessageDialog(null, Utilities.getStackTrace(ise), "Canh bao",
							JOptionPane.WARNING_MESSAGE);
					log.error("", ise);
				} catch (final Exception e) {
					log.error("", e);
				}
			}
		}.start();

		this.mediator.activeWindows();
	}

	/**
	 * time open popup form and system out for common login
	 */
	private void createScheduleOpenPopup() {

		this.scheduler = new Thread(this);
		this.scheduler.start();
	}

	@Override
	public void run() {
		try {
			Thread.sleep(this.timeDelay);
			log.info("VAE Capture getting card");

			// *** Killing Softly - RESUME
			if (ApplicationConfig.getInstance().getWorking2ProjectConfig().isConnectToBrokerActiveMQ()) {
				final HashMap<String, String> message = ApplicationConfig.getInstance().getWorking2ProjectConfig()
						.getResumeCmd();
				this.client.sendCommand(message,
						ApplicationConfig.getInstance().getWorking2ProjectConfig().getActiveMQJmsTimeout());
			}

			this.dialog.setVisible(true);
		} catch (final javax.jms.IllegalStateException ise) {
			AroundDialog.showMessageDialog(null, Utilities.getStackTrace(ise), "Canh bao", JOptionPane.WARNING_MESSAGE);
			log.error("", ise);
		} catch (final Exception e) {
			log.error("", e);
		}
	}
}
