package com.ghp.vae.data_entry.face;

import com.ghp.vae.data_entry.bll.BLLField;
import com.ghp.vae.data_entry.entity.Card;
import com.ghp.vae.data_entry.entity.UserName;

import java.util.Map;

public interface LoadCardInterface {
	
	boolean checkValidServer();
	Card getCard() throws Exception;
	void checkOut();
	Map<String , BLLField> getFieldList();
	void setUserName(UserName user);
	void pause(boolean r);
	boolean cancelGettingCard();
}
