package com.ghp.vae.data_entry.ptl;

import com.ghp.vae.data_entry.entity.Card;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.ptl.state.StateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vae.client.transfer.LookupKey;

import javax.swing.*;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class LogUtil {

	private static Logger log = LoggerFactory.getLogger(LogUtil.class);

	public static List<Byte> logFields = Arrays.asList(
			 MainFieldInterface.PLZ,
			MainFieldInterface.ORT, MainFieldInterface.STRASSE,
			MainFieldInterface.HAUSE);

	/**
	 * Compare the result of lookup and ocr then log to graylog server
	 * 
	 * @param logger
	 * @param int row selected row
	 * @param main
	 * @param ocrValues
	 * @return void
	 * */
	public static void logLookupResult(org.slf4j.Logger logger, int row,
			MainFieldInterface main, Map<Byte, String> ocrValues) {
		try {
			StringBuilder logText = new StringBuilder();
			String logTextPattern = "[%s:%s|%s:%s|lmatch:%d]";
			Card card = main.getEntity();
			Map<String, String> vectorKDP = card.getVectorKDP();

			if (vectorKDP == null) {
				return;
			}

			for (Byte field : logFields) {
				JTextField control = (JTextField) main.getComponent(field);				
				String lookupText = "";
				if (ocrValues.containsKey(field)) {
					lookupText = ocrValues.get(field);
				}
				String lookupResult = StateUtil.getDataInKDP(control.getName(),
						false, vectorKDP);
				/**
				 * search|result|is_match
				 * */
				logText.append(String.format(logTextPattern,
						"locr" + control.getName(), lookupText, "lsearch"
								+ control.getName(), lookupResult,
						(lookupText != null && lookupText
								.equalsIgnoreCase(lookupResult)) ? 1 : 0));
			}
			String kdp_alias = vectorKDP.get(LookupKey.KDP_ALIAS.getKey());
			String vname_alias = vectorKDP.get(LookupKey.VNAME_ALIAS.getKey());
			Boolean isAlias = !kdp_alias.isEmpty() || vname_alias.equalsIgnoreCase("true");
			String lookup = ((JTextField) main.getComponent(MainFieldInterface.LOOKUP)).getText();
			logText.append("[selectedRow:").append(row).append(" | isAlias:").append(isAlias).append(" | lookup:").append(lookup).append(" ]");
			logger.info("OCR_LOOKUP_MEASURE###" + logText);
		} catch (Exception e) {
			log.error("", e);
		}
	}
}
