package com.ghp.vae.search.model;

/**
 * The class defines address lookup extra(suggest when typing and tab) such as plz, ort, strasse
 *
 * @author pnmai
 *
 */
public class LookupExtra {
	String plz;
	String ort;
	String strasse;
	String type;

	public enum Type {
		PLZ("plz"), ORT("ort"), STRASSE("strasse");

		private final String type;

		public String getType() {
			return this.type;
		}

		private Type(String type) {
			this.type = type;
		}
	}

	public LookupExtra(String plz, String ort, String strasse, String type) {
		super();
		this.plz = plz;
		this.ort = ort;
		this.strasse = strasse;
		this.type = type;
	}

	public String getPlz() {
		return this.plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return this.ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getStrasse() {
		return this.strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "LookupExtra [plz=" + this.plz + ", ort=" + this.ort + ", strasse=" + this.strasse + ", type=" + this.type + "]";
	}

}
