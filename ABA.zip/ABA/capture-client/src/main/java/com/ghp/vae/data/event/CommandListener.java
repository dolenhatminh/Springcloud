//package com.ghp.vae.data.event;
//
//import vae.client.bao.BAOJmsOperator;
//
//import javax.jms.*;
//import javax.naming.Context;
//
//public class CommandListener {
//
//	int clientID;
//	Context ctx;
//	Connection connection;
//	Session session;
//	BAOJmsOperator jmsSender;
//	
//	enum ECommand{
//		RESEND
//	}
//
//	public CommandListener(int clientID, int level, Context ctx, Connection connection,
//			Session session) throws Exception {
//		this.clientID = clientID;
//		this.ctx = ctx;
//		this.connection = connection;
//		this.session = session;
//		Destination commandTopic = (Destination) ctx.lookup("/commandTopic");
//		MessageConsumer subscriber = session.createConsumer(commandTopic);
//		subscriber.setMessageListener(new SimpleMessageListener());
//	}
//
//	public class SimpleMessageListener implements MessageListener {
//		public void onMessage(Message msg) {
//			try {
//				String txt = ((TextMessage) msg).getText();
//				System.out.println("RECCEIVE MESSAGE: " + txt);
//				if(ECommand.RESEND.name().equalsIgnoreCase(txt)){
//					// message when  close connection.
//					connection.close();
//					System.exit(0);
//				}
//
//			} catch (Exception e) {
//			}
//		}
//
//	}
//}
