package com.ghp.vae.data_entry.ptl.autocomplete.service.dto;

import java.io.Serializable;

public class ItemSearchResult implements Serializable, Comparable<ItemSearchResult> {

	private static final long serialVersionUID = -945431975052901533L;
	private String key;
	private String value;
	private long numberOfSuggestion;
	
	public ItemSearchResult(String key, String value, long numberOfSuggestion) {
		super();
		this.key = key;
		this.value = value;
		this.numberOfSuggestion = numberOfSuggestion;
	}
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

	public long getNumberOfSuggestion() {
		return numberOfSuggestion;
	}

	public void setNumberOfSuggestion(long numberOfSuggestion) {
		this.numberOfSuggestion = numberOfSuggestion;
	}
	
	@Override
	public int compareTo(ItemSearchResult o) {
		return (int) (o.getNumberOfSuggestion() - this.numberOfSuggestion);
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof ItemSearchResult){
			String sample = ((ItemSearchResult) obj).getValue();
			return this.getValue().equals(sample);
		}
		return false;
	}
	
}
