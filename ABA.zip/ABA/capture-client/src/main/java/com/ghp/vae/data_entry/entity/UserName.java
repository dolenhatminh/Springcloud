package com.ghp.vae.data_entry.entity;

public class UserName {
	private String userName;
	private String fullName;
	private int level ;
	private int userId;
	
	
	public UserName(String userName , String fullName) {
		this(userName, fullName, 1);
	}
	public UserName(String userName , String fullName, int level) {
		this(userName, fullName, level,((int) ( Math.random()*500)) );
	}
	public UserName(String userName , String fullName, int level, int userId) {
		
		this.userName = userName;
		this.fullName = fullName;
		this.level = level;
		this.userId = userId ;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
	
	
}
