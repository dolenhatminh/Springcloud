package com.ghp.vae.data_entry.display;

public class JTableDisplay {

	// Search Normal
//	public static Vector<Vector<String>> getDataVector(List<Map<String, String>> rawData, boolean isNormal) {
//		Vector<Vector<String>> result = new Vector<Vector<String>>();
//
//		Vector<String> row = null;
//		for (Map<String, String> mapData : rawData) {
//			row = new Vector<String>();
//
//			row.add(mapData.get(LookupKey.FIRMENNAME));
//			row.add(mapData.get(LookupKey.VORNAME));
//			row.add(mapData.get(LookupKey.NAME));
//			row.add(mapData.get(LookupKey.NAMENSZUSATZ));
//			row.add(mapData.get(LookupKey.PLZ));
//			row.add(mapData.get(LookupKey.ORT));
//			row.add(mapData.get(LookupKey.STRASSE));
//			row.add(mapData.get(LookupKey.HAUS));
//			row.add(mapData.get(LookupKey.POSTFACH));
//			row.add(mapData.get(LookupKey.ANDREDE));
//			row.add(mapData.get(LookupKey.ADDRESSZUSATZ));
//			row.add(mapData.get(LookupKey.KDP_ID));
//			row.add(mapData.get(LookupKey.ORT_SET));
//			row.add(mapData.get(LookupKey.STRASSE_SET));
//			row.add(mapData.get(LookupKey.EXPIRE_DATE));
//			row.add(mapData.get(LookupKey.START_DATE));
//			if (isNormal) {
//				row.add(mapData.get(LookupKey.AMP_STATUS));
//			}
//			row.add(mapData.get(LookupKey.HAUSKEY));
//
//			result.add(row);
//		}
//
//		return result;
//
//	}

}
