package com.ghp.vae.data_entry.face;


public interface StateCapture {
	
	byte GETTING_CARD = 0;
	byte SAVE_CARD_BUTTON = 1;
	byte OPEN_SUGGEST =2;
	byte LOOKUP =3;
//	byte LOOKUP_SPECIAL =4;
//	byte LOOKUP_NORMAL =5;
	byte NORMAL =6;
	byte SUGGESTION =7;
	byte OCR = 8;
	byte SAVE_PAUSE = 9;
	byte SAVE_LOAD_CARD = 10;
	byte PAUSE = 11;
	byte LOAD_CARD = 12;
	byte SAVE_CARD_CTRL = 13;
	byte LOAD_PAUSE = 14;
	byte LOAD = 15;
	byte OCR_IMAGE = 16;
	byte CANCEL_PROCESS = 17; // using for ocr, lookup.
	byte OCR_INFORMATION = 18; // using when information.
	byte INIT_GUI = 19;
	byte INIT = 20;
	byte EXIT = 21;
	byte LOOKUP_UISPEC= 22;
	byte UPDATE_KDP = 23 ;
	byte FIND_NEXT_KDP = 24;
	byte SEARCH_GUI_CLOSE = 25;
	byte CLEAR_KDPID = 26;
	byte ROLLBACK_KDP = 27;
	
	/**
	 * handle event from main gui
	 *  @param information :contain action event , source for handle.
	 *  @param main :this is main gui for handleEvent.
	 *  
	 */
	void handleEvent(ObjectInformation information ,MainFieldInterface main);
}