package com.ghp.vae.data_entry.ptl.autocomplete.service.dto;

import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author nqvu
 *
 */

public class ResponseMessage implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5498600651921071464L;
	private int resultCode;
	private String resultMessage;
	private String errorMessage;
	private List<ItemSearchResult> resultContent;

	public ResponseMessage() {}

	public ResponseMessage(int resultCode, String resultMessage,
			String errorMessage, List<ItemSearchResult> resultContent) {
		super();
		this.resultCode = resultCode;
		this.resultMessage = resultMessage;
		this.errorMessage = errorMessage;
		this.resultContent = resultContent;
	}

	public int getResultCode() {
		return resultCode;
	}

	public void setResultCode(int resultCode) {
		this.resultCode = resultCode;
	}

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<ItemSearchResult> getResultContent() {
		return resultContent;
	}

	public void setResultContent(List<ItemSearchResult> resultContent) {
		this.resultContent = resultContent;
	}
}
