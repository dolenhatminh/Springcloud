package com.ghp.vae.data_entry.ptl;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

/**
 * 
 *
 * Preferences - Java - Code Style - Code Templates
 */
public class CheckInput_IN extends PlainDocument {

	/**
     *
     */
	private static final long serialVersionUID = 1L;
	private int MAXLENGTH;
	private String CheckString = "";

	public CheckInput_IN(int maxlength) {
		this.MAXLENGTH = maxlength;
	}

	public CheckInput_IN(int maxlength, String StringValue) {
		this.CheckString = StringValue;
		this.MAXLENGTH = maxlength;
	}

	// Check Input String

	public CheckInput_IN(String StringValue) {
		this.CheckString = StringValue;
		this.MAXLENGTH = 100;
	}

	/**
	 * @author nvhviet
	 * @param offset
	 * @param str
	 * @param attr
	 * @throws BadLocationException
	 */
	@Override
	public void insertString(int offset, String str, AttributeSet attr)
			throws BadLocationException {
		if (str == null) {
			return;
		}
		char[] addedFigures = str.toCharArray();
		char c;
		for (int i = Math
				.min(addedFigures.length, this.MAXLENGTH - getLength()) - 1; i >= 0; --i) {
			c = addedFigures[i];
			if (getLength() < this.MAXLENGTH) {
				if (inString(CheckString, c)) {
					try {
						super.insertString(offset, c + "", attr);
					} catch (Exception ex) {
					}
				} else if (CheckString.equals("")) {
					try {
						super.insertString(offset, c + "", attr);
					} catch (Exception ex) {
					}
				}
			}
		}
	}

	private static boolean inString(String strMT, char c) {
		String temp = String.valueOf(c);
		if (strMT.indexOf(temp) >= 0) {
			return true;
		} else {
			return false;
		}
	}
}
