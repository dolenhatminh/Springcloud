package com.ghp.vae.data_entry.ptl.state;

import com.ghp.vae.data_entry.face.StateCapture;

interface ReloadState extends StateCapture{
	public void reloadStatus();
}
