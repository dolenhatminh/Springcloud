/*
 * Class: OCRServiceImpl Created on Mar 8, 2016 (c) Swiss Post Solutions Vietnam, unpublished work All use, disclosure,
 * and/or reproduction of this material is prohibited unless authorized in writing. All Rights Reserved. Rights in this
 * program belong to: Swiss Post Solutions Vietnam. Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package com.ghp.vae.search.service.impl;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.search.model.ocr.FirmaSign;
import com.ghp.vae.search.service.IOCRService;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sps.vn.config.ApplicationConfig;
import com.sps.vn.utilities.StringUtil;

import vae.client.transfer.HttpClientFailover;
import vae.client.transfer.JsonUtils;

/**
 * The Class OCRCheckingServiceImpl.
 */
public class OCRServiceImpl extends AbstractLookupProxyService implements IOCRService {

	/** The Constant FIELD_FIRMA_SIGN_TYPE. */
	private static final String FIELD_FIRMA_SIGN_TYPE = "firma_type";

	/** The Constant FIELD_FIRMA_SIGN_SIGN. */
	private static final String FIELD_FIRMA_SIGN_SIGN = "sign";

	/** The log. */
	private static Logger log = LoggerFactory.getLogger(LookupServiceImpl.class);

	/**
	 * Instantiates a new OCR service impl.
	 */
	public OCRServiceImpl() {
		super();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see com.ghp.vae.search.service.IOCRService#countExistingKDP(java.lang.String)
	 */
	@Override
	public int countExistingKDP(final String kdp) {
		int ret = 0;

		try {
			if ((kdp != null) && !kdp.isEmpty()) {
				log.debug("Counting KDP: " + kdp);
				ret = this.countSeparateType(ApplicationConfig.getInstance().getLookupConfig().getOcrKdpCountService(),
						kdp);
				log.debug("Returned: " + ret);
			}
		} catch (final Exception e) {
			log.error("Error occured while counting KDP", e);
		}

		return ret;
	}

	/**
	 * Count separate type.
	 *
	 * @param url
	 *            the url
	 * @param value
	 *            the value
	 * @return the int
	 * @throws URISyntaxException
	 *             the URI syntax exception
	 * @throws Exception
	 *             the exception
	 */
	private int countSeparateType(final String url, final String value) throws URISyntaxException, Exception {
		final URI uri = new URIBuilder(url).addParameter("value", JsonUtils.object2Json(value)).build();
		final HttpUriRequest request = new HttpGet(uri);
		// final String response = HTTPUtils.doGET(request, 1000, 1);
		final String response = HttpClientFailover.intance().doGET(request,
				ApplicationConfig.getInstance().getLookupConfig().getHosts(),
				ApplicationConfig.getInstance().getLookupConfig().getDelay(),
				ApplicationConfig.getInstance().getLookupConfig().getRetryTimes(),
				ApplicationConfig.getInstance().getLookupConfig().getSocketTimeout(),
				ApplicationConfig.getInstance().getLookupConfig().getConnectionTimeout());
		return this.extractCountValue(response);
	}

	/**
	 * Extract count value.
	 *
	 * @param response
	 *            the response
	 * @return the int
	 */
	private int extractCountValue(final String response) {
		int ret = 0;

		if ((response != null) && !response.isEmpty()) {
			final JsonParser parser = new JsonParser();
			final JsonObject obj = parser.parse(response).getAsJsonObject();
			final String countElement = "count";
			if (obj.has(countElement)) {
				final JsonElement eleCount = obj.get(countElement);
				if (eleCount != null) {
					ret = eleCount.getAsInt();
				}
			}
		}

		return ret;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see com.ghp.vae.search.service.IOCRService#countExistingOrt(java.lang.String)
	 */
	@Override
	public int countExistingOrt(final String ort) {
		int ret = 0;

		try {
			if ((ort != null) && !ort.isEmpty()) {
				log.debug("Counting ORT: " + ort);
				ret = this.countSeparateType(ApplicationConfig.getInstance().getLookupConfig().getOcrOrtCountService(),
						ort);
				log.debug("Returned: " + ret);
			}
		} catch (final Exception e) {
			log.error("Error occured while counting ORT", e);
		}

		return ret;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see com.ghp.vae.search.service.IOCRService#countExistingPlz(java.lang.String)
	 */
	@Override
	public int countExistingPlz(final String plz) {
		int ret = 0;

		try {
			if ((plz != null) && !plz.isEmpty()) {
				final String plzValue = plz.trim();
				if (StringUtil.isInteger(plzValue)) {
					log.debug("Counting PLZ: " + plz);
					ret = this.countSeparateType(
							ApplicationConfig.getInstance().getLookupConfig().getOcrPlzCountService(), plzValue);
					log.debug("Returned: " + ret);
				} else {
					log.warn("Invalid PLZ value [" + plz + "]. PLZ must be in integer format.");
				}
			}
		} catch (final Exception e) {
			log.error("Error occured while counting PLZ", e);
		}

		return ret;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see com.ghp.vae.search.service.IOCRService#countExistingStrasse(java.lang.String)
	 */
	@Override
	public int countExistingStrasse(final String strasse) {
		int ret = 0;

		try {
			if ((strasse != null) && !strasse.isEmpty()) {
				log.debug("Counting STRASSE: " + strasse);
				ret = this.countSeparateType(
						ApplicationConfig.getInstance().getLookupConfig().getOcrStrasseCountService(), strasse);
				log.debug("Returned: " + ret);
			}
		} catch (final Exception e) {
			log.error("Error occured while counting STRASSE", e);
		}

		return ret;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see com.ghp.vae.search.service.IOCRService#getAllFirmaSign()
	 */
	@Override
	public List<FirmaSign> getAllFirmaSign() {
		final List<FirmaSign> ret = new ArrayList<FirmaSign>();
		final String firmaSignSearchURIString = ApplicationConfig.getInstance().getLookupConfig()
				.getOcrFirmaSignSearchService();

		try {
			log.debug("Fetching all Firma Sign...");
			final URI uri = new URIBuilder(firmaSignSearchURIString).build();
			final HttpUriRequest request = new HttpGet(uri);
			// final String response = HTTPUtils.doGET(request, 1000, 1);
			final String response = HttpClientFailover.intance().doGET(request,
					ApplicationConfig.getInstance().getLookupConfig().getHosts(),
					ApplicationConfig.getInstance().getLookupConfig().getDelay(),
					ApplicationConfig.getInstance().getLookupConfig().getRetryTimes(),
					ApplicationConfig.getInstance().getLookupConfig().getSocketTimeout(),
					ApplicationConfig.getInstance().getLookupConfig().getConnectionTimeout());
			if ((response != null) && !response.isEmpty()) {
				final JsonParser parser = new JsonParser();
				final JsonObject obj = parser.parse(response).getAsJsonObject();
				final JsonElement hitObject = obj.get("hits");
				if ((hitObject != null) && hitObject.isJsonArray()) {
					final JsonArray hits = hitObject.getAsJsonArray();
					for (final JsonElement hitEl : hits) {
						final JsonObject hit = hitEl.getAsJsonObject().get("_source").getAsJsonObject();
						final FirmaSign firmaSign = new FirmaSign();
						firmaSign.setSign(hit.get(FIELD_FIRMA_SIGN_SIGN).getAsString());
						firmaSign.setType(hit.get(FIELD_FIRMA_SIGN_TYPE).getAsString());
						ret.add(firmaSign);
					}
					log.info("Fetched " + ret.size() + " firma signs");
				}
			}
		} catch (final URISyntaxException e) {
			log.error("Invalid URI: " + firmaSignSearchURIString, e);
		} catch (final Exception e) {
			log.error("Failed to get all firma sign", e);
		}

		return ret;
	}

}
