package com.ghp.vae.data_entry.ptl.autocomplete;

public interface LearningInterface {
	void learn();
}
