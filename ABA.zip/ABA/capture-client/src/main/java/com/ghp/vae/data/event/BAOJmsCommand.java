package com.ghp.vae.data.event;

import javax.jms.*;
import javax.naming.Context;

public class BAOJmsCommand {

	private static String USER_ID = "UserID";

	Context ctx;
	Connection connection;
	Session session;
	MessageProducer userMsgProducer;
	MessageProducer capturedMsgProducer;
	MessageConsumer commandConsumer;
	int level;
	Queue OperatorQueue;

	public BAOJmsCommand(Context ctx, Connection connection, Session session) throws Exception {
		this.ctx = ctx;
		this.connection = connection;
		this.session = session;
	}

	public void receiveCommand(int clientID) throws Exception {

		String filterStr = String.format("%s=%s",USER_ID, clientID);

		// create producer
		Topic command = (javax.jms.Topic) ctx.lookup("/commandTopic");
		commandConsumer = session.createConsumer(command, filterStr);

		Message msg = commandConsumer.receive();
		if (msg instanceof ObjectMessage) {
			ObjectMessage objMsg = (ObjectMessage) msg;
			String text = objMsg.toString();

			System.out.println("////// " + text);
		}

	}
}
