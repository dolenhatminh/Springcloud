package com.ghp.vae.data_entry.bll;

import java.sql.Timestamp;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.entity.Card;
import com.ghp.vae.data_entry.entity.UserName;
import com.ghp.vae.data_entry.face.LoadCardInterface;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.sps.vn.writing.datasource.DALLoadCard;

import vae.bb.core.hibernate.model.Collection;
import vae.bb.core.hibernate.model.CollectionStatus;
import vae.client.bao.BAOJmsConnection;
import vae.client.transfer.ITransferService;

/*
 * Not apply image not exist.
 */
public class BLLoadCard implements LoadCardInterface {
	private static Logger log = LoggerFactory.getLogger(BLLoadCard.class);
	private final BLLCard card;
	private final DALLoadCard dal;
	Card cardBP = new Card();
	// private BAOJmsConnection jmsConnection;
	// private BAOJmsConsumer jmsConsumer;
	ITransferService transferService;

	public BLLoadCard() {
		this.card = new BLLCard();
		this.dal = new DALLoadCard();
		this.constructFieldInfo();
		this.init();
	}

	public void setMainField(MainFieldInterface main) {
		this.main = main;
	}

	private void init() {
		// if (Utilities.isWindowOS()) {
		// this.prefix = ConfigInfo.getWinPrefix();
		// } else {
		// this.prefix = ConfigInfo.getLinuxPrefix();
		// }
	}

	@Override
	public boolean checkValidServer() {
		return true;
	}

	@Override
	public Card getCard() throws Exception {
		final Card card = this.getCardBT();
		if (card != null) {
			final String longTime = this.transferService.getCurrentTime();
			Long.parseLong(longTime);
			card.setTimeGetCard(Long.parseLong(longTime));
		}
		return card;
	}

	private Card getCardBT() throws Exception {
		try {
			return this.startCapture();
		} catch (final Exception ex) {
			throw ex;
		}

	}

	private boolean isPause = false;
	private UserName user;
	private MainFieldInterface main;
	private int REQUEST_ID = 0;
	private volatile boolean isGettingCard;

	private Card startCapture() throws Exception {
		Card result;
		if (this.isPause) {
			this.stopCapture();
			return null;
			// result = true;
		}
		try {
			result = this.getCardData();
		} catch (final Exception e) {
			throw e;
		}
		return result;
	}

	/*
	 * get data from collection. Remove image byte into collection. add collection into need transffer.
	 */
	private Card getCardData() throws Exception {
		this.card.resetData();
		log.info("[Capture]-[REQUEST:" + (++this.REQUEST_ID) + "]-[START]-request card");
		final String timeRequest = this.transferService.getCurrentTime();
		this.isGettingCard = true;
		this.main.loadCardEvent(true);
		this.transferService.requestCollection();

		this.updateStatusCard(this.main, "Cho nhan collection");
		log.info("[Capture]-[REQUEST:" + this.REQUEST_ID + "][LOAD]-get collection");
		final Collection collection = this.transferService.getCollection(this.user.getUserId());
		this.isGettingCard = false;
		this.checkInterrupted("when interrupted collection");
		this.updateStatusCard(this.main, "Xu ly collection");
		log.info("[Capture]-[COLLECTION:" + collection.getCollectionId() + "][LOAD]-start loading collection");
		collection.getCollectionStatus().setCaptureUser(this.user.getUserId());
		this.checkInterrupted("when proccess collection");
		this.transferService.updateCapturingCollection(collection);
		this.cardBP.clearValue();
		this.cardBP.setNeedTransfer(null);
		final boolean check = this.updateFieldCard(collection);
		if (!check) {
			return null;
		}
		this.cardBP.setImageByte(collection.getImage());
		this.cardBP.setValueHausnummer(collection.getHausnummer());
		this.cardBP.setValueHausnummerzusatz(collection.getHausnummerzusatz());

		collection.setImage(null);
		this.cardBP.setCard(this.card);
		this.cardBP.setDecription(this.card.getFilePath() + this.card.getFilename());
		this.cardBP.setNeedTransfer(collection);
		this.card.setRequestTime(new Timestamp(Long.parseLong(timeRequest)));
		return this.cardBP;
	}

	private boolean updateFieldCard(Collection collection) {
		try {
			BLLAddressField field = null;
			field = (BLLAddressField) this.card.getField(BLLDataStructure.ANREDE_FIELD);
			this.updateField(field, collection.getAnredeValue(), collection.getAnrede());
			field = (BLLAddressField) this.card.getField(BLLDataStructure.CO_ADDRESSE_FIELD);
			this.updateField(field, collection.getCoAddresseValue(), collection.getCoAdresse());
			field = (BLLAddressField) this.card.getField(BLLDataStructure.FIRMENNAME_FIELD);
			this.updateField(field, collection.getFirmennameValue(), collection.getFirmenname());
			field = (BLLAddressField) this.card.getField(BLLDataStructure.HAUSNUMMER_FIELD);
			this.updateField(field, "", "");
			field = (BLLAddressField) this.card.getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD);
			this.updateField(field, "", "");
			field = (BLLAddressField) this.card.getField(BLLDataStructure.LAND_FIELD);
			this.updateField(field, collection.getLandValue(), collection.getLand());
			field = (BLLAddressField) this.card.getField(BLLDataStructure.NAME_FIELD);
			this.updateField(field, collection.getNameValue(), collection.getName());
			field = (BLLAddressField) this.card.getField(BLLDataStructure.NAMENSZUSATZ_FIELD);
			this.updateField(field, collection.getNamenszusatzValue(), collection.getNameZusatz());
			field = (BLLAddressField) this.card.getField(BLLDataStructure.ORT_FIELD);
			this.updateField(field, collection.getOrtValue(), collection.getOrt());
			field = (BLLAddressField) this.card.getField(BLLDataStructure.PICKPOSTNUMMER_FIELD);
			// Hoang add new field.
			// updateField(field, collection.getPickpostnummerValue(), collection.getPickpostnummerTyped());
			field = (BLLAddressField) this.card.getField(BLLDataStructure.PLZ_FIELD);
			this.updateField(field, collection.getPlzValue(), collection.getPlz());

			field = (BLLAddressField) this.card.getField(BLLDataStructure.POSTFACHNUMMER_FIELD);
			this.updateField(field, "", "");
			field = (BLLAddressField) this.card.getField(BLLDataStructure.STOCKWERK_FIELD);
			this.updateField(field, collection.getStockwerkValue(), collection.getStockwerk());
			field = (BLLAddressField) this.card.getField(BLLDataStructure.STRASSE_FIELD);
			this.updateField(field, collection.getStrasseValue(), collection.getStrasse());
			field = (BLLAddressField) this.card.getField(BLLDataStructure.VORNAME_FIELD);
			this.updateField(field, collection.getVornameValue(), collection.getVorname());
			field = (BLLAddressField) this.card.getField(BLLDataStructure.ADRESSZUSATZ_FIELD);
			this.updateField(field, collection.getAdresszusatzValue(), collection.getAdresszusatz());

			this.card.setManagementID(collection.getCollectionId());
			final CollectionStatus status = collection.getCollectionStatus();
			this.card.setCollectionID(status.getId());

			// Hoang disable not data for check
			try {
				this.card.setBarcodeLeftX(status.getLowerBarcodeLeftX().floatValue());
			} catch (final Exception ex) {
				this.card.setBarcodeLeftX(0.0f);
			}
			try {
				this.card.setBarcodeLeftY(status.getLowerBarcodeLeftY().floatValue());
			} catch (final Exception ex) {
				this.card.setBarcodeLeftY(0.0f);
			}
			try {
				this.card.setBarcodeRightX(status.getLowerBarcodeRightX().floatValue());
			} catch (final Exception ex) {
				this.card.setBarcodeRightX(0.0f);
			}
			try {
				this.card.setBarcodeRightY(status.getLowerBarcodeRightY().floatValue());
			} catch (final Exception ex) {
				this.card.setBarcodeRightY(0.0f);
			}
			this.card.setFilePath(status.getImageFilePath());
			this.card.setFilename(status.getImageFileName());
			this.card.setUntarStatus("1");
			this.card.setVgPicid(status.getParPicId());
			final String longTime = this.transferService.getCurrentTime();
			Long.parseLong(longTime);
			this.card.setStartTime(new Timestamp(Long.parseLong(longTime)));
		} catch (final Exception ex) {
			log.warn("", ex);
			// return false;
			return true;
		}
		return true;
	}

	private void updateField(BLLAddressField field, String value, String type) {
		field.setTyped(type);
		field.setValue(value);

	}

	private void stopCapture() {
	}

	@Override
	public void checkOut() {
		this.transferService.close();
		// if (jmsConnection.getConnection() != null) {
		// try {
		// jmsConnection.getConnection().close();
		// } catch (JMSException e) {
		// log.error("", e);
		// }
		// }
	}

	@Override
	public Map<String, BLLField> getFieldList() {
		return this.card.getFieldList();
	}

	@Override
	public void setUserName(UserName user) {
		this.user = user;

		if (this.transferService == null) {
			try {
				this.initConnectionProxy();
			} catch (final Exception ex) {
				log.error("", ex);
			}
		}
	}

	private void initConnectionProxy() throws Exception {
		this.transferService = BAOJmsConnection.createTransferService(this.user.getUserId(), this.user.getLevel(), this.user.getUserName());
	}

	@Override
	public void pause(boolean b) {
		this.isPause = b;
		if (b) {
			this.stopCapture();
		}
	}

	private void constructFieldInfo() {

		log.info(" >>> [STEP-2] Load Card ");

		// fieldname, typeid, inputconstraint, tablename, fieldnames
		try {
			final String[][] array = this.dal.getInputFields();
			// <editor-fold defaultstate="collapsed"
			// desc="construct address fields">
			for (int i = 0; (array != null) && (i <= (array.length - 1)); i++) {
				final String fieldname = array[i][0];
				final String typeid = array[i][1];
				final String constraint = array[i][2];
				final String lookupTable = array[i][3];
				final String lookupField = array[i][4];
				BLLAddressField field = new BLLAddressField(fieldname, "", typeid, "", constraint, lookupTable, lookupField);
				this.card.addField(field);
				if (fieldname.equals("pickpostnummer")) {
					field = new BLLAddressField(BLLDataStructure.MYPOST24, "", "", "", constraint, lookupTable, lookupField);
					this.card.addField(field);
				}
			}
			// </editor-fold>
			// <editor-fold defaultstate="collapsed"
			// desc="construc master fields">
			BLLField masterField = new BLLField(BLLDataStructure.KDPID_FIELD, "", "1920");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.PERSIBS_FIELD, "", "");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.ORTZIBS_FIELD, "", "");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.ORTZTYP_FIELD, "", "");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.ADDRESSTYPE_FIELD, "", "");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.ANREDEID_FIELD, "", "1901");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.ISOLANDCODE_FIELD, "", "1902");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.ZUBO_PLZAID_FIELD, "", "1917");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.ZUBO_PLZID_FIELD, "", "1911");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.ZUBO_LOKID_FIELD, "", "1912");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.ZUBO_LOKAID_FIELD, "", "1913");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.ZUBO_LOKUID_FIELD, "", "1914");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.ZUBO_ADRID_FIELD, "", "1915");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.ZUBO_AADRID_FIELD, "", "1916");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.RESPONSECODE_FIELD, "", "");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.POSTLAGEND_FIELD, "", "");
			this.card.addField(masterField);
			// add new field
			masterField = new BLLField(BLLDataStructure.AMP_STATUS, "", "");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.HAUSKEY, "", "");
			this.card.addField(masterField);
			/*
			 * 25/08/2016 Add new some fields: adr_id, aadr_id for check duplicate
			 */
			masterField = new BLLField(BLLDataStructure.ADR_ID, "", "");
			this.card.addField(masterField);
			masterField = new BLLField(BLLDataStructure.AADR_ID, "", "");
			this.card.addField(masterField);

			masterField = new BLLField(BLLDataStructure.PARCEL_HAUSKEY, "", "");
			this.card.addField(masterField);

			// masterField =new BLLAddressField(BLLDataStructure.MYPOST24, "", "", "", "", "", "");
			// card.addField(masterField);
			// </editor-fold>
		} catch (final Exception ex) {
			log.error("", ex);// day message
		}
	}

	private void updateStatusCard(final MainFieldInterface main, final String status) {
		main.setStatusCard(status);
	}

	@Override
	public synchronized boolean cancelGettingCard() {
		if (this.isGettingCard) {
			this.isGettingCard = false;
			try {
				// transferService.cancelRequestCard(user.getUserId());
				this.transferService.close();
			} catch (final Exception e) {
				log.error("cancel error", e);

			}
			return true;
		}
		return false;
	}

	private void checkInterrupted(String message) throws InterruptedException {
		if (Thread.interrupted()) {
			throw new InterruptedException(message);
		}
	}
}
