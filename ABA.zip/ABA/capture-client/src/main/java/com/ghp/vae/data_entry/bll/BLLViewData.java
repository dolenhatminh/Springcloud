package com.ghp.vae.data_entry.bll;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.KeyValue;
import org.apache.commons.collections.keyvalue.DefaultKeyValue;

import vae.client.transfer.LookupKey;

import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.ptl.autocomplete.AutoTextFieldDataSourceInf;
import com.ghp.vae.search.model.LookupExtra;
import com.ghp.vae.search.service.impl.LookupServiceImpl;
import com.ghp.vae.search.service.impl.SuggestionServiceImpl;
import com.sps.vn.lookup.datasource.LookupDALViewData;
import com.sps.vn.writing.datasource.WritingDALViewData;

public class BLLViewData {
	LookupDALViewData lookupDal;
	WritingDALViewData writingDal;
	LookupServiceImpl lookupService;
	SuggestionServiceImpl suggestionService;

	private final FirmenameImp firmenameImp;
	// Implement Vorname data source
	private final VornammeImp vornammeImp;
	// Implement Name data source
	private final NameImp nameImp;
	// Implement Ort data source
	private final OrtImp ortImp;
	// Implement Plz data source
	private final PlzImp plzImp;
	// Implement Strasse data source
	private final StrasseImp strasseImp;
	private final NameZuzatImp nameZuzatImp;
	// Implement Strasse data source
	private final AnredeImp anredeImp;

	public BLLViewData() {
		this.lookupDal = new LookupDALViewData();
		this.writingDal = new WritingDALViewData();
		this.lookupService = new LookupServiceImpl();
		this.suggestionService = new SuggestionServiceImpl();

		this.firmenameImp = new FirmenameImp();
		this.vornammeImp = new VornammeImp();
		this.nameImp = new NameImp();
		this.ortImp = new OrtImp();
		this.plzImp = new PlzImp();
		this.strasseImp = new StrasseImp();
		this.anredeImp = new AnredeImp();
		this.nameZuzatImp = new NameZuzatImp();
	}

	public String[][] getLand() {
		return this.writingDal.getLand();
	}

	public String[][] getReason() {
		return this.writingDal.getReason();
	}

	public boolean get_StatusRunOCR() {
		return this.writingDal.get_StatusRunOCR();
	}

	public FirmenameImp getFirmenameDataSource() {
		return this.firmenameImp;
	}

	public NameImp getNameDataSource() {
		return this.nameImp;
	}

	public VornammeImp getVornammeDataSoure() {
		return this.vornammeImp;
	}

	public AnredeImp getAnredeDataSoure() {
		return this.anredeImp;
	}

	public OrtImp getOrtDataSource() {
		return this.ortImp;
	}

	public PlzImp getPlzDataSource() {
		return this.plzImp;
	}

	public StrasseImp getStrasseDataSource() {
		return this.strasseImp;
	}

	public NameZuzatImp getZuzatDataSource() {
		return this.nameZuzatImp;
	}

	class FirmenameImp implements AutoTextFieldDataSourceInf {

		@Override
		public List<KeyValue> getDataSource(String arg0) {
			final String key = LookupKey.SUG_PER_09_NAME.getKey();
			final List<KeyValue> result = new LinkedList<KeyValue>();
			final List<Map<String, String>> tmp = BLLViewData.this.suggestionService
					.getSuggestion(LookupServiceImpl.INDEX_KDPFA_TYPE, key, arg0);
			for (int i = 0; tmp != null && i < tmp.size(); i++) {
				result.add(new DefaultKeyValue(tmp.get(i).get(key), null));
			}
			return result;
		}

	}

	/**
	 * Vorname data source
	 */
	class VornammeImp implements AutoTextFieldDataSourceInf {

		@Override
		public List<KeyValue> getDataSource(String arg0) {
			final String key = LookupKey.SUG_NAME.getKey();
			final List<KeyValue> result = new LinkedList<KeyValue>();
			final List<Map<String, String>> tmp = BLLViewData.this.suggestionService
					.getSuggestion(LookupServiceImpl.INDEX_VORNAME_TYPE, key, arg0);
			for (int i = 0; tmp != null && i < tmp.size(); i++) {
				result.add(new DefaultKeyValue(tmp.get(i).get(key), null));
			}
			return result;
		}

	}

	/**
	 * Name data source
	 */
	class NameImp implements AutoTextFieldDataSourceInf {

		@Override
		public List<KeyValue> getDataSource(String arg0) {
			final String key = LookupKey.SUG_NAME.getKey();

			final List<KeyValue> result = new LinkedList<KeyValue>();
			final List<Map<String, String>> tmp = BLLViewData.this.suggestionService
					.getSuggestion(LookupServiceImpl.INDEX_NACHNAME_TYPE, key, arg0);
			for (int i = 0; tmp != null && i < tmp.size(); i++) {
				result.add(new DefaultKeyValue(tmp.get(i).get(key), null));
			}
			return result;
		}

	}

	/**
	 * Plz data source
	 */
	class PlzImp implements AutoTextFieldDataSourceInf {

		@Override
		public List<KeyValue> getDataSource(String arg0) {
			final List<KeyValue> result = new LinkedList<KeyValue>();
			final LookupExtra lookupExtra = new LookupExtra(arg0, "", "", LookupExtra.Type.ORT.getType());
			final List<Map<String, String>> arr = BLLViewData.this.lookupService.lookupExtra(lookupExtra);
			for (final Map<String, String> map : arr) {
				result.add(new DefaultKeyValue(map.get(LookupKey.SUGGEST_PLZ.getKey()), null));
			}
			return result;
		}

	}

	/**
	 * Anrede data source
	 */
	class AnredeImp implements AutoTextFieldDataSourceInf {

		@Override
		public List<KeyValue> getDataSource(String arg0) {

			final String key = LookupKey.SUG_ANREDE.getKey();

			final List<KeyValue> result = new LinkedList<KeyValue>();
			final List<Map<String, String>> tmp = BLLViewData.this.suggestionService
					.getSuggestion(LookupServiceImpl.INDEX_ANREDE_TYPE, key, arg0);
			for (int i = 0; tmp != null && i < tmp.size(); i++) {
				// result.add(tmp.get(i).get(ELookupKey.ANREDE.getKey()));
				result.add(new DefaultKeyValue(tmp.get(i).get(key), null));
			}
			return result;
		}

	}

	/**
	 * Ort data source
	 */
	public class OrtImp implements AutoTextFieldDataSourceInf {

		private javax.swing.JTextField plz;

		public void setPlzObject(javax.swing.JTextField plz) {
			this.plz = plz;
		}

		@Override
		public List<KeyValue> getDataSource(String arg0) {
			final List<KeyValue> result = new LinkedList<KeyValue>();
			final String plzValue = Utilities.ignoreNull(this.plz.getText());

			final LookupExtra lookupExtra = new LookupExtra(plzValue, arg0, "", LookupExtra.Type.ORT.getType());
			final List<Map<String, String>> arr = BLLViewData.this.lookupService.lookupExtra(lookupExtra);
			for (final Map<String, String> map : arr) {
				result.add(new DefaultKeyValue(map.get(LookupKey.SUGGEST_ORT.getKey()), null));
			}
			return result;
		}

	}

	/**
	 * Strasse data source
	 */
	public class StrasseImp implements AutoTextFieldDataSourceInf {

		private javax.swing.JTextField plz;
		private javax.swing.JTextField ort;

		public void setPlzObject(javax.swing.JTextField plz) {
			this.plz = plz;
		}

		public void setOrtObject(javax.swing.JTextField ort) {
			this.ort = ort;
		}

		@Override
		public List<KeyValue> getDataSource(String arg0) {
			final List<KeyValue> result = new LinkedList<KeyValue>();
			final String ortValue = Utilities.ignoreNull(this.ort.getText());
			final String plzValue = Utilities.ignoreNull(this.plz.getText());

			final LookupExtra lookupExtra = new LookupExtra(plzValue, ortValue, arg0,
					LookupExtra.Type.STRASSE.getType());
			final List<Map<String, String>> arr = BLLViewData.this.lookupService.lookupExtra(lookupExtra);
			for (final Map<String, String> map : arr) {
				result.add(new DefaultKeyValue(map.get(LookupKey.SUGGEST_STRASSE.getKey()), null));
			}
			return result;
		}

	}

	public class NameZuzatImp implements AutoTextFieldDataSourceInf {

		@Override
		public List<KeyValue> getDataSource(String arg0) {

			final String key = LookupKey.SUG_NAME.getKey();

			final List<KeyValue> result = new LinkedList<KeyValue>();

			final List<Map<String, String>> tmp = BLLViewData.this.suggestionService
					.getSuggestion(LookupServiceImpl.INDEX_ZUSAT_TYPE, key, arg0);
			for (int i = 0; tmp != null && i < tmp.size(); i++) {
				result.add(new DefaultKeyValue(tmp.get(i).get(key), null));
			}
			return result;
		}

	}

	// TODO
	public boolean checkSwapCondtion(String vorname, String nachname, int iPercent) {
		return this.suggestionService.checkSwapCondition(vorname, nachname, iPercent);
	}
	
	public String checkMoveCondition(String indexType, String value) {
		return this.suggestionService.checkMoveCondition(indexType, value);
	}
	
	public String translateData(String data) {
		return this.lookupService.translate(data);
	}

	public List<Map<String, String>> getLookupStrasse(String strasse, String ort, String plz) {
		final LookupExtra lookupExtra = new LookupExtra(plz, ort, strasse, LookupExtra.Type.STRASSE.getType());
		return this.lookupService.lookupExtra(lookupExtra);
	}

	public List<Map<String, String>> getLookupOrt(String ort, String plz) {
		final LookupExtra lookupExtra = new LookupExtra(plz, ort, "", LookupExtra.Type.ORT.getType());
		return this.lookupService.lookupExtra(lookupExtra);
	}

	public List<Map<String, String>> getLookupPlz(String plz) {
		final LookupExtra lookupExtra = new LookupExtra(plz, "", "", LookupExtra.Type.PLZ.getType());
		return this.lookupService.lookupExtra(lookupExtra);
	}

	public List<Map<String, String>> getSuggestion(String indexType, String fieldName, String fieldNameLike) {
		return this.suggestionService.getSuggestion(indexType, fieldName, fieldNameLike);
	}

	public String[] getChangeCase() {
		return this.writingDal.getChangeCase();
	}

	public List<String> getListOrtChecks() {
		final String listStringOrt = this.writingDal.getListStringOrt();

		final ArrayList<String> listOrtChecks = new ArrayList<String>();
		if (!listStringOrt.equals("")) {
			final String[] orts = listStringOrt.split(",");
			for (final String ort : orts) {
				listOrtChecks.add(ort);
			}
		}
		return listOrtChecks;
	}

}
