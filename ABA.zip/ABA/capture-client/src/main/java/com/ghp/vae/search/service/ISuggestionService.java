/*
 * Class: ISuggestionService
 *
 * Created on Mar 30, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package com.ghp.vae.search.service;

import java.util.List;
import java.util.Map;


/**
 * @author tvbinh
 *
 */
public interface ISuggestionService extends ILookupProxyService {

    public List<Map<String, String>> getSuggestion(String indexType, String fieldName, String term);
    public boolean checkSwapCondition(String strVN, String strNN, int iPercent);
    
}
