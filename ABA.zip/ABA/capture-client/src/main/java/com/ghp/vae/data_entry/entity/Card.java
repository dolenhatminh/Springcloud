package com.ghp.vae.data_entry.entity;

import com.ghp.vae.data_entry.bll.BLLCard;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class Card {
	private static Logger log = LoggerFactory.getLogger(Card.class);
	private BLLCard card;
	private String decription;
	private byte[] imageByte;
	private boolean haveValueFromSearchKdp;
	private Integer adr_id ;
//	public Map<String, BLLField> fieldBeforSearch;
	private Map<String, String> vectorKDP;
	public Object needTransfer;
	public boolean change;
	
	private String valuePostFach ;
	private String valuePickPost ;
	private String valueStrasse ;
	private String valueHausnummer ;
	private String valueHausnummerzusatz;

	private Map<String , String> fieldValue = new HashMap<String, String>();
	
	
	public BLLCard getCard() {
		return card;
	}
	public void setCard(BLLCard card) {
		this.card = card;
	}
	public byte[] getImageByte() {
		return imageByte;
	}
	public void setImageByte(byte[] imageByte) {
		this.imageByte = imageByte;
	}
	public String getValuePostFach() {
		return valuePostFach;
	}
	public void setValuePostFach(String valuePostFach) {
		this.valuePostFach = valuePostFach;
	}
	public String getValuePickPost() {
		return valuePickPost;
	}
	public void setValuePickPost(String valuePickPost) {
		this.valuePickPost = valuePickPost;
	}
	public String getValueStrasse() {
		return valueStrasse;
	}
	public void setValueStrasse(String valueStrasse) {
		this.valueStrasse = valueStrasse;
	}
	
	public Map<String, String> getFieldValue() {
		return fieldValue;
	}
	public boolean isHaveValueFromSearchKdp() {
		return haveValueFromSearchKdp;
	}

	public void setHaveValueFromSearchKdp(boolean haveValueFromSearchKdp) {
		this.haveValueFromSearchKdp = haveValueFromSearchKdp;
	}
	
	public void setAdr_id(Integer adr_id) {
		this.adr_id = adr_id;
	}
	
	public Integer getAdr_id() {
		return adr_id;
	}

	private int kdpType;
	public int getKdpType() {
		return kdpType;
	}
	
	public void setKdpType(int kdpType) {
		this.kdpType = kdpType;
	}
	
	public void setDecription(String decription) {
		this.decription = decription;
	}
	public String getDecription() {
		return decription;
	}
	
	private long timeGetCard ;
	private MainFieldInterface main;
	public void setTimeGetCard(long timeGetCard) {
		this.timeGetCard = timeGetCard;
	}
	
	public long getTimeGetCard() {
		return timeGetCard;
	}
	
	public String getValueHausnummer() {
		return valueHausnummer;
	}
	public void setValueHausnummer(String valueHausnummer) {
		this.valueHausnummer = valueHausnummer;
	}
	
	public String getValueHausnummerzusatz() {
		return valueHausnummerzusatz;
	}
	public void setValueHausnummerzusatz(String valueHausnummerzusatz) {
		this.valueHausnummerzusatz = valueHausnummerzusatz;
	}
	
	public Object getNeedTransfer() {
		return needTransfer;
	}
	public void setNeedTransfer(Object needTransfer) {
		this.needTransfer = needTransfer;
	}
	public void setMyPost24(boolean myPost) {
		card.setMyPost24(myPost);
	}
	public boolean isMyPost24() {
		return card.isMyPost24();
	}
	
	public Map<String, String> getVectorKDP() {
		return vectorKDP;
	}
	public void setVectorKDP(Map<String, String> vectorKDP) {
		if(vectorKDP == null){
			log.debug("vectorKDP is null");
		}else{
			log.debug("vectorKDP is not null");
		}
		this.vectorKDP = vectorKDP;
	}
	public void clearValue() {
		if(card != null){
			card.clearValue();
		}
		haveValueFromSearchKdp =false;
		adr_id  = 0;
//		public Map<String, BLLField> fieldBeforSearch;
		vectorKDP = null;
		valuePostFach  = null ;
		valuePickPost = null ;
		valueStrasse  = null;
		
	}
}
