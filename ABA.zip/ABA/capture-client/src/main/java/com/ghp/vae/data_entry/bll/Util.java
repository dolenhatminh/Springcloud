package com.ghp.vae.data_entry.bll;

import vae.bb.core.hibernate.model.Collection;
import vae.bb.core.hibernate.model.CollectionStatus;

public class Util {

	public static  Collection convertToColection(BLLCard card, Object cardNeed) {
		if(!(cardNeed instanceof Collection)){
			return null;
		}
		Collection collection = (Collection) cardNeed;

		collection.setBadReason(card.getBaditem());
		
		BLLAddressField field = null;
		BLLField field2  = null;
		field = (BLLAddressField) card.getField(BLLDataStructure.ANREDE_FIELD);
//		collection.setAnredeId(field.getTypeid());
		collection.setAnredeTyped(field.getTyped());
		collection.setAnredeValue(field.getValue());

		
		field = (BLLAddressField) card.getField(BLLDataStructure.CO_ADDRESSE_FIELD);
		collection.setCoAddresseTyped(field.getTyped());	
		collection.setCoAddresseValue(field.getValue());

		field = (BLLAddressField) card.getField(BLLDataStructure.FIRMENNAME_FIELD);
		collection.setFirmennameTyped(field.getTyped());
		collection.setFirmennameValue(field.getValue());

		field = (BLLAddressField) card.getField(BLLDataStructure.HAUSNUMMER_FIELD);
		collection.setHausnummerTyped(field.getTyped());
		collection.setHausnummerValue(field.getValue());

		field = (BLLAddressField) card.getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD);
		collection.setHausnummerzusatzTyped(field.getTyped());
		collection.setHausnummerzusatzValue(field.getValue());

		
//		collection.setLandTyped(field.getTyped());
//		collection.setLandValue(field.getValue());
		field = (BLLAddressField) card.getField(BLLDataStructure.NAME_FIELD);
		collection.setNameTyped(field.getTyped());
		collection.setNameValue(field.getValue());

		field = (BLLAddressField) card.getField(BLLDataStructure.NAMENSZUSATZ_FIELD);
		String namenszusatzType = field.getTyped();
		String namenszusatzValue = field.getValue();
		if(namenszusatzType.length() > 100){
			namenszusatzType = namenszusatzType.substring(0,100);
		}
		
		if(namenszusatzValue.length() > 100){
			namenszusatzValue = namenszusatzValue.substring(0,100);
		}
		collection.setNamenszusatzTyped(namenszusatzType);
		collection.setNamenszusatzValue(namenszusatzValue);

		field = (BLLAddressField) card.getField(BLLDataStructure.ORT_FIELD);
		collection.setOrtTyped(field.getTyped());
		collection.setOrtValue(field.getValue());

		
		field = (BLLAddressField) card.getField(BLLDataStructure.PICKPOSTNUMMER_FIELD);
		String pickPostValue = field.getValue();
		String pickPostType = field.getTyped();
		collection.setPickPostType(pickPostType);
		collection.setPickPostValue(pickPostValue);
		field = (BLLAddressField) card.getField(BLLDataStructure.MYPOST24);
		String myPost24Value = field.getValue();
		String myPost24Type = field.getTyped();
		collection.setMyPost24Type(myPost24Type);
		collection.setMyPost24Value(myPost24Value);
		
		field2 = card.getField(BLLDataStructure.POSTLAGEND_FIELD);
		String postlengend = field2.getValue();
		collection.setPostlagernd(postlengend);
		updateDataKunderAnDienstleitung(pickPostType, pickPostValue, myPost24Type, myPost24Value, postlengend, collection);
			
		field = (BLLAddressField) card.getField(BLLDataStructure.PLZ_FIELD);
		collection.setPlzTyped(field.getTyped());
		collection.setPlzValue(field.getValue());

		field = (BLLAddressField) card.getField(BLLDataStructure.POSTFACHNUMMER_FIELD);
		collection.setPostfachnummerTyped(field.getTyped());
		collection.setPostfachnummerValue(field.getValue());

		field = (BLLAddressField) card.getField(BLLDataStructure.STOCKWERK_FIELD);
		collection.setStockwerkTyped(field.getTyped());
		collection.setStockwerkValue(field.getValue());

		field = (BLLAddressField) card.getField(BLLDataStructure.STRASSE_FIELD);
		collection.setStrasseTyped(field.getTyped());
		collection.setStrasseValue(field.getValue());

		field = (BLLAddressField) card.getField(BLLDataStructure.VORNAME_FIELD);
		collection.setVornameTyped(field.getTyped());
		collection.setVornameValue(field.getValue());

		field = (BLLAddressField) card.getField(BLLDataStructure.ADRESSZUSATZ_FIELD);
		collection.setAdresszusatzTyped(field.getTyped());
		collection.setAdresszusatzValue(field.getValue());
		// master data.
		
		field2 = card.getField(BLLDataStructure.KDPID_FIELD);
		String kdpid = field2.getValue();
		boolean hasKDPID = !kdpid.equals("");
		
		field = (BLLAddressField) card.getField(BLLDataStructure.LAND_FIELD);
		workAroundLandField(field.getTyped(), field.getValue(), card.getBaditem(), collection, hasKDPID);
		
		if(kdpid.equals("0")){
			kdpid = "";
		}
		collection.setKdpid(kdpid);
		if(hasKDPID){
			field2 = card.getField(BLLDataStructure.AMP_STATUS);
			String ampStatus = "";
			if(field2.getValue() != null){
				ampStatus =field2.getValue() ; 
			}
			collection.setAmpStatus(ampStatus);
			
			if(card.getKdpType() == 0){
				collection.setPers08Type("");
			}else{
				collection.setPers08Type(card.getKdpType()+"");
			}
		}
		else{
			collection.setAmpStatus("");
			collection.setPers08Type("");
		}
		
		field2 = card.getField(BLLDataStructure.RESPONSECODE_FIELD);
		String captureResultCode = "";
		if(field2.getValue() != null){
			captureResultCode =field2.getValue() ; 
		}
		
		collection.setCaptureResultCode(captureResultCode);
		
		field2 = card.getField(BLLDataStructure.HAUSKEY);
		collection.setHauskey(field2.getValue());	
		
		field2 = card.getField(BLLDataStructure.PARCEL_HAUSKEY);
		collection.setParcelHauskey(field2.getValue());	
		
		field2 = card.getField(BLLDataStructure.ZUBO_ADRID_FIELD);
		collection.setAdrID(field2.getValue());
		
		field2 = card.getField(BLLDataStructure.ADDRESSTYPE_FIELD);
		
		Integer value= convertInt(field2.getValue());
		
		collection.setAddressType(value);
		
		field2 = card.getField(BLLDataStructure.ANREDEID_FIELD);
		collection.setAnredeId(field2.getValue());
		Long streetNumber  =  card.getStreetNumber();
		if(streetNumber ==null || streetNumber < 1){
			collection.setParcelStreetNumber("");
		}else{
			collection.setParcelStreetNumber(streetNumber+"");
		}
		field2 = card.getField(BLLDataStructure.POSTLAGEND_FIELD);

		CollectionStatus status = collection.getCollectionStatus();
		status.setStartTime(card.getStartTime());
		
		status.setEndTime(card.getEndTime());
		status.setClientRequestTime(card.getRequestTime());
		return collection;
	}
	
	public static Collection convertToFirmenPlzCollection(BLLCard card, Object cardNeed, String plz_and_ort) {
		if(!(cardNeed instanceof Collection)){
			return null;
		}
		
		/**
		 * Set
		 * addressType = 2 => FirmenAddress
		 * plzValue = 6 digits
		 * responeCode = 6
		 * landValue = "CH"
		 */
		String [] plz_Ort = plz_and_ort.split("AND");
		
		Collection collection = (Collection) cardNeed;
		// BB Use To Export XML <=> Parcel Address Type = 2
		System.out.println("COLLECTION_ID: " + collection.getCollectionId());
		collection.setAddressType(2);
		collection.setPlzValue(plz_Ort[0].trim());
		collection.setOrtValue(plz_Ort[1].trim());
		collection.setCaptureResultCode("6");
		collection.setLandValue("CH");
		
		/**
		 *  Fields don't set 
		 */
		collection.setPlzTyped("");
		collection.setOrtTyped("");
		collection.setLandTyped("");
		
		collection.setAdresszusatzValue("");
		collection.setAdresszusatzTyped("");
		
		collection.setAnredeValue("");
		collection.setAnredeTyped("");
		
		collection.setCoAddresseValue("");
		collection.setCoAddresseTyped("");
		
		collection.setFirmennameValue("");
		collection.setFirmennameTyped("");
		
		collection.setHausnummerzusatzValue("");
		collection.setHausnummerzusatzTyped("");
		
		collection.setNameValue("");
		collection.setNameTyped("");
		
		collection.setNamenszusatzValue("");
		collection.setNamenszusatzTyped("");
		
		collection.setPostfachnummerValue("");
		collection.setPostfachnummerTyped("");
		
		collection.setStockwerkValue("");
		collection.setStockwerkTyped("");
		
		collection.setStrasseValue("");
		collection.setStrasseTyped("");
		
		collection.setVornameValue("");
		collection.setVornameTyped("");
		
		collection.setKdpid("");
		collection.setParcelHauskey("");
		collection.setHauskey("");
		collection.setParcelStreetNumber("");
		collection.setAdrID("");
		collection.setAmpStatus("");
		collection.setPers08Type("");
		
		CollectionStatus status = collection.getCollectionStatus();
		status.setStartTime(card.getStartTime());
		
		status.setEndTime(card.getEndTime());
		status.setClientRequestTime(card.getRequestTime());
		return collection;
	}
	/**
	 * @note this workAround for request from customer with land field
	 * Lay bad reason 5 ==> khong xuat Land field
	 * Chon KDPID co gi xuat do o field land value.
	 * Truong hop khac xuat CH o field land type
	 * @param typed
	 * @param value
	 * @param baditem
	 * @param collection
	 */
	private static void workAroundLandField(String typed, String value, String baditem, Collection collection, boolean hasKdpid) {
		if(baditem.trim().equals("5. Dia chi nuoc ngoai, quan doi")){
			
			collection.setLandTyped("");
			collection.setLandValue("");
		}else if(hasKdpid){
			collection.setLandTyped("");
			if(value == null){
				collection.setLandValue("");
			}else{
				collection.setLandValue(value);
			}
		}else{
			collection.setLandTyped("CH");
			collection.setLandValue("");
		}
	}
	/**
	 * make document request into meeting : 20131203 
	 * mail subject: Meeting: pickpost field and my post 24 
	 * @param pickPostType
	 * @param pickPostValue
	 * @param myPost24Type
	 * @param myPost24Value
	 * @param collection
	 */
	private static void updateDataKunderAnDienstleitung(String pickPostType, String pickPostValue, String myPost24Type, String myPost24Value, String postlagend, Collection collection) {
		if(myPost24Value != null && !myPost24Value.equals("")){
			collection.setKundennummerValue(myPost24Value);
			collection.setDienstleitungValue(2);
			return;
		}
		if(pickPostValue != null && !pickPostValue.equals("")){
			collection.setKundennummerValue(pickPostValue);
			collection.setDienstleitungValue(1);
			return;
		}
		if(myPost24Type != null && !myPost24Type.equals("")){
			if(!myPost24Type.trim().toLowerCase().equals("x")){
				collection.setKundennummerTyped(myPost24Type);
			}
			collection.setDienstleitungTyped(2);
			return;
		}
		if(pickPostType != null && !pickPostType.equals("")){
			if(!pickPostType.trim().toLowerCase().equals("x")){				
				collection.setKundennummerTyped(pickPostType);
			}
			collection.setDienstleitungTyped(1);
			return;
		}
		if(postlagend != null  && !postlagend.equals("") && !postlagend.toLowerCase().trim().equals("x")){
			collection.setKundennummerTyped(postlagend);
			return;
		}
	}

	private static Integer convertInt(String convert){
		Integer value = null;
		try{
			value = Integer.parseInt(convert);
		}catch(Exception ex){
			value = null;
		}
		return value;
				
	}
	
//	public static void main(String arg[]){
//		Properties ties = System.getProperties();
//		for (Entry<Object , Object> et : ties.entrySet()){
//			System.out.print(et.getKey() +" :");
//			System.out.println(et.getValue());
//		}
//	}
}

