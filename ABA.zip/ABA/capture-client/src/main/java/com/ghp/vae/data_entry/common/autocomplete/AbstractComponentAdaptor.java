package com.ghp.vae.data_entry.common.autocomplete;

import javax.swing.text.JTextComponent;

public abstract class AbstractComponentAdaptor {

	public abstract Object getSelectedItem();

	public abstract void setSelectedItem(Object item);

	public abstract int getItemCount();

	public abstract Object getItem(int index);

	public boolean listContainsSelectedItem() {
		Object selectedItem = getSelectedItem();
		for (int i = 0, n = getItemCount(); i < n; i++) {
			if (getItem(i) == selectedItem)
				return true;
		}
		return false;
	}

	public abstract JTextComponent getTextComponent();

	public void markEntireText() {
		markText(0);
	}

	public void markText(int start) {
		getTextComponent().setCaretPosition(
				getTextComponent().getText().length());
		getTextComponent().moveCaretPosition(start);
	}
}