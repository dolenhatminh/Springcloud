package com.ghp.vae.data_entry.ptl.state;

import java.awt.EventQueue;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vae_ocr.OCR.OCRProcessing;

import com.ghp.vae.data_entry.bll.BLLSaveCard;
import com.ghp.vae.data_entry.bll.BLLViewData;
import com.ghp.vae.data_entry.bll.BLLoadCard;
import com.ghp.vae.data_entry.entity.UserName;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.ObjectInformation;
import com.ghp.vae.data_entry.face.StateCapture;
import com.ghp.vae.data_entry.gui.CaptureMediatorImplement;
import com.ghp.vae.data_entry.ptl.OCRInformation;

/*
 * User use state as.
 * Lookup,Save, Suggestion.
 *  
 * */
public class NormalState implements StateCapture {
	
	
	private static Logger log = LoggerFactory.getLogger("Main State");
	private BLLoadCard loadCard;
	private BLLSaveCard saveCard;
	private BLLViewData viewData;
	private List<String> listOrtChecks;
	private String[] changeCase;
	private OCRProcessing ocr;
	private Map<Byte, ReloadState> states;
	private LookupState lookupState;
	public NormalState(UserName user, MainFieldInterface main,BLLViewData viewData) throws SQLException {
		loadCard = new BLLoadCard();
		saveCard = new BLLSaveCard(user);
		loadCard.setUserName(user);
		
		saveCard.setMainField(main);
		loadCard.setMainField(main);
		this.viewData = viewData;
		init();
	}
	
	/**
	 * not use new in normal
	 * not have for init_gui , Ocr_ifnormation.
	 */
	private void init(){
		this.changeCase = viewData.getChangeCase();
		saveCard.setChangeCase(viewData.getChangeCase());
		this.listOrtChecks = viewData.getListOrtChecks();
		
		try {
			ocr = new OCRProcessing();
		} catch (java.lang.ArrayIndexOutOfBoundsException aioobe) {				
			JOptionPane.showMessageDialog(null, "Khong co ket qua nao duoc tim thay !!!");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
		states = new HashMap<Byte, ReloadState>();
		
		lookupState = new LookupState(listOrtChecks, changeCase, viewData);
		states.put(LOOKUP, lookupState);
		states.put(ROLLBACK_KDP, lookupState);
		
		PauseState pauseState = new PauseState(loadCard);  
		LoadCardState loadState  =new LoadCardState(loadCard,pauseState);
		pauseState.setLoadCardState(loadState);
		states.put(LOAD, loadState );
		ReloadState saveState = new SaveState(saveCard, loadCard, changeCase,ocr,loadState, pauseState);
		states.put(SAVE_CARD_BUTTON, saveState);
		states.put(SAVE_CARD_CTRL, saveState);
		states.put(OPEN_SUGGEST,new SuggestState(viewData));
		states.put(CLEAR_KDPID,new ClearKdp());
		states.put(OCR, new OcrState(ocr));

	}
	
	/**
	 * this is function handle Event default from main.<br/>
	 * catch event: LOOKUP, SAVE_CARD_BUTTON, SAVE_CARD_CTRL, OPEN_SUGGEST, LOAD, OCR_INFORMATION,
	 *  INIT_GUI, EXIT
	 *  @see StateCapture
	 */
	
	public void handleEvent(ObjectInformation information, MainFieldInterface main) {
		
		int action = information.getAction();
		try{
			switch (action) {
			case LOOKUP:
				openLookup(information, main);
				break;
			case ROLLBACK_KDP:
				openRollbackKDP(information, main);
				CaptureMediatorImplement.resetCountLookup();
				OcrState.resetCountLookup();
				break;
			case SAVE_CARD_BUTTON:
				openSaveCardButton(information, main);
				break;
			case SAVE_CARD_CTRL:
				openSaveCardCTRL(information, main);
				CaptureMediatorImplement.resetCountLookup();
				OcrState.resetCountLookup();
				//ABA-175: Clear List contain data as soon as look up (Search KDP)
				lookupState.resetData();
				break;
			case OPEN_SUGGEST:
				openSuggestion(information, main);
				break; 
			case LOAD:
				openLoadCard(information, main);
				break;
			case OCR:
				openOcrImage(information, main);
				break;
			case OCR_INFORMATION:
				openInformation(information, main);
				break;
			case INIT_GUI:
				openInitGUi(information, main);
				break;
			case CLEAR_KDPID:
				openClearKdpid(information, main);
				break;
			case EXIT:
		 		openPopupCannotNotExit("Ban phai nhap xong moi thoat khoi ung dung");
		 		break;
			case CANCEL_PROCESS:				
				cancelProcess(information, main);
				break;
			default:
				log.info("This type of action is not support in NormalState: " + action);
				break;
			}
		}catch(Exception ex){
			log.error("", ex);
		}catch(Error er){
			if(er instanceof NoClassDefFoundError){
				log.error("", er);
				JOptionPane.showMessageDialog(null, "cannot load lib from server");
			}else{
				log.error("", er);
				JOptionPane.showMessageDialog(null,er);
			}
		}
	}
	
	private void cancelProcess(ObjectInformation information, final MainFieldInterface main) {
		log.debug("CHECK EDT THREAD HERE: " + EventQueue.isDispatchThread());
		log.info("CANCEL_NORMAL_PROCESS");
		
		main.setProcessStatus(false);
	}
	

	private void openClearKdpid(ObjectInformation information, MainFieldInterface main) {
				
		controlState(states.get(information.getAction()), main, CLEAR_KDPID, information);
		
	}

	private void openPopupCannotNotExit(String message) {
		AroundDialog.showMessageDialog(null, message, "Canh bao", JOptionPane.WARNING_MESSAGE);
	}

	private void openInitGUi(ObjectInformation information, MainFieldInterface main) {
		StateCapture state = new InitState(viewData, loadCard);
//		controlState(state, main, INIT, information);		
		main.changeState(state);
		information.setAction(INIT);
		
		main.request(information,main);
		
	}

	private void openInformation(ObjectInformation information, MainFieldInterface main) {
		OCRInformation ocr = (OCRInformation) main.getComponent(MainFieldInterface.OCRINFORMATION);
		if(ocr == null ) return ;
		@SuppressWarnings("unchecked")
		HashMap<String, Object> data = (HashMap<String, Object>) information.getSource();
		//Hoang: code disable for test
		JTextField field = (JTextField) data.get("component");
		Byte index = (Byte) data.get("index");
		if(index > 9){
			insertData(ocr, (byte)(index-10) ,field );
		}else{
			overideData(ocr, index ,field );
		}
		field.requestFocus();
		
	}

	
	private void overideData(OCRInformation ocr, byte i, JTextField field) {
		String dataOcr = ocr.getDataIndex(i);
		if(dataOcr.equals("")){
			return;
		}
		field.setText(dataOcr);
	}

	private void insertData(OCRInformation ocr, byte i, JTextField field) {
		
		String text = field.getText();
		String dataOcr = ocr.getDataIndex(i);
		if(dataOcr.equals("")){
			return;
		}
		if(text.equals("") ){
			field.setText(dataOcr);
		}else{
			field.setText(text+ ", "+dataOcr);
		}
	}

	private void openLoadCard(ObjectInformation information, MainFieldInterface main) {
				
		controlState(states.get(information.getAction()), main, LOAD_CARD, information);
	}

	private void openOcrImage(ObjectInformation information, MainFieldInterface main) {
				
		controlState(states.get(information.getAction()), main, OCR_IMAGE, information);
	}

	private void openSuggestion(ObjectInformation information, MainFieldInterface main) {
				
		controlState(states.get(information.getAction()), main, SUGGESTION, information);
	}


	private void openSaveCardButton(ObjectInformation information, MainFieldInterface main) {
				
		controlState(states.get(information.getAction()), main, SAVE_PAUSE, information);
	}
	
	private void openSaveCardCTRL(ObjectInformation information, MainFieldInterface main) {
				
		controlState(states.get(information.getAction()), main, SAVE_LOAD_CARD, information);
	}

	private void openLookup(ObjectInformation information, MainFieldInterface main) {
		controlState(states.get(information.getAction()), main, LOOKUP, information);
	}
	
	private void openRollbackKDP(ObjectInformation information, MainFieldInterface main) {
		controlState(states.get(information.getAction()), main, ROLLBACK_KDP, information);
	}
	/**
	 * this is utility set status and add action for main.
	 * @param state
	 * @param main
	 * @param action
	 * @param information
	 */
	private void controlState(ReloadState state, MainFieldInterface main, byte action, ObjectInformation information) {
		state.reloadStatus();
		log.debug("Current state: " + state.getClass().getName());
		
		main.changeState(state);
		information.setAction(action);
		main.request(information,main);
//				String.format("--- Class: %s - Method: %s ---", NormalState.class.getCanonicalName(), "controlState()"));
	}		
	
}
