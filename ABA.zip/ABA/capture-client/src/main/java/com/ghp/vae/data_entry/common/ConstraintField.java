package com.ghp.vae.data_entry.common;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.text.Document;

public class ConstraintField {
	
	private static Logger  log = LoggerFactory.getLogger(ConstraintField.class);
	
	static String  maxlength;
	static String option;
	public static String SPACE = "";
	
	public ConstraintField(){
		
	}
	public static void setConstraintField(int FieldType,JTextField txtTextField,String inputCons) throws Exception{
		try{
			maxlength = Utilities.getdata_seperator(inputCons,1,";");
			option = Utilities.getdata_seperator(inputCons,2,";");
			// Type of field is date.
			if (FieldType==6){
				txtTextField.setDocument(new CheckInput(8,11));
			}
			else if (FieldType==1 || FieldType==2 || FieldType==4 || FieldType==7){				
				if (Utilities.hasNumber(option)){
					int iOption = Integer.parseInt(option);
					txtTextField.setDocument(new CheckInput(Integer.parseInt(maxlength),iOption));	
				}else{
					Document document = new CheckInput(Integer.parseInt(maxlength),option+";");
					txtTextField.setDocument(document);
				}									
			}
		}
		catch(Exception ex){
			throw ex;
		}catch (Throwable e) {
			log.error("", e);
		}
		
	}
	public static void setConstraintField(JTextField txtVorwahlen,JTextField txttelefon,String maxlength) throws Exception{
		int lenVorwahlen = 8;
		String sMaxlength = Utilities.getdata_seperator(maxlength,1,";");
		try{
			txtVorwahlen.setDocument(new CheckInput(lenVorwahlen,8));
			txttelefon.setDocument(new CheckInput(Integer.parseInt(sMaxlength)-8,8));
		}
		catch(Exception ex){
			throw ex;
		}
	}

}
