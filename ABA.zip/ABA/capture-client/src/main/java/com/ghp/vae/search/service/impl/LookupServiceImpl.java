package com.ghp.vae.search.service.impl;

import java.awt.EventQueue;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import org.apache.commons.lang3.text.WordUtils;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.ptl.state.AroundDialog;
import com.ghp.vae.search.model.LookupExtra;
import com.ghp.vae.search.model.ObjectKdp;
import com.ghp.vae.search.model.ObjectSearch;
import com.ghp.vae.search.model.ZubofiAddress;
import com.ghp.vae.search.service.ILookupService;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sps.vn.config.ApplicationConfig;

import org.apache.commons.lang3.StringUtils;

import vae.client.transfer.HttpClientFailover;
import vae.client.transfer.JsonUtils;
import vae.client.transfer.LookupKey;

public class LookupServiceImpl extends AbstractLookupProxyService implements ILookupService {
    public static final String INDEX_KDPFA_TYPE = "firma";
    public static final String INDEX_VORNAME_TYPE = "vorname";
    public static final String INDEX_NACHNAME_TYPE = "nachname";
    public static final String INDEX_ZUSAT_TYPE = "zusat";
    public static final String INDEX_ANREDE_TYPE = "anrede";
    public static final String INDEX_VORNAMEMORE_TYPE = "vornamemore";
    public static final String INDEX_NACHNAMEMORE_TYPE = "nachnamemore";
    public static final String INDEX_FIRMENAMEMORE_TYPE = "firmenamemore";
    public static final String INDEX_TYPE_NAME = "name";
    public static final String PARAM_PLZ = "plz";
    public static final String PARAM_ORT = "ort";

    public static final Map<String, String> SEARCHMORE_KEYS = new HashMap<String, String>();
    public static final Map<String, String> INDEX_TYPES = new HashMap<String, String>();
    
    static {
        SEARCHMORE_KEYS.put("vorname", LookupKey.SUG_PERS_10_VNAME_NAME.getKey());
        SEARCHMORE_KEYS.put("name", LookupKey.SUG_PER_09_NAME.getKey());
        SEARCHMORE_KEYS.put("firmenname", LookupKey.SUG_PER_09_NAME.getKey());
        // SEARCHMORE_KEYS.put("vorname", LookupKey.SUG_PERS_10_VNAME_NAME.getKey());
        // SEARCHMORE_KEYS.put("vorname", LookupKey.SUG_PERS_10_VNAME_NAME.getKey());

        INDEX_TYPES.put("vorname", INDEX_VORNAMEMORE_TYPE);
        INDEX_TYPES.put("name", INDEX_NACHNAMEMORE_TYPE);
        INDEX_TYPES.put("firmenname", INDEX_FIRMENAMEMORE_TYPE);
    }

    private static Logger log = LoggerFactory.getLogger(LookupServiceImpl.class);

	/** The Constant PARAM_ADDRESS. */
    private static final String PARAM_ADDRESS = "address";

    private String notWordData = ApplicationConfig.getInstance().getBusinessConfig().getNotWord();
    
    /**
     * {@inheritDoc}
     */
    @Override
    public List<Map<String, String>> lookupKDP(ObjectSearch obj, boolean isFirstSearch) {
        List<Map<String, String>> listRows = new ArrayList<Map<String, String>>(0);
        log.info("LOOKUP_INPUT###" + obj.toString());

        try {
            final ObjectSearch objectSearch = org.apache.commons.lang3.SerializationUtils.clone(obj);

            String strasse = objectSearch.getStrasse();
            strasse = this.filterStrasse(strasse);
            objectSearch.setStrasse(strasse);
            final URI uri;
            if (isFirstSearch) {
            	log.info("THE 1ST STEP: LOOKUP MATCH PARAMETERS" );
            	 log.debug("LOOKUP_REST :" + ApplicationConfig.getInstance().getLookupConfig().getSearchFirst()
                         + "|strasse:" + strasse);
            	 uri  = new URIBuilder(ApplicationConfig.getInstance().getLookupConfig().getSearchFirst())
                 .addParameter("objectSearch", JsonUtils.object2Json(objectSearch)).build();
			} else {
				 log.debug("LOOKUP_REST :" + ApplicationConfig.getInstance().getLookupConfig().getSearchRestService()
		                    + "|strasse:" + strasse);
				uri = new URIBuilder(ApplicationConfig.getInstance().getLookupConfig().getSearchRestService())
                .addParameter("objectSearch", JsonUtils.object2Json(objectSearch)).build();
			}
            final HttpUriRequest request = new HttpGet(uri);
            // final String response = HTTPUtils.doGET(request, 1000, 1);
            final String response = HttpClientFailover.intance().doGET(request,
                    ApplicationConfig.getInstance().getLookupConfig().getHosts(),
                    ApplicationConfig.getInstance().getLookupConfig().getDelay(),
                    ApplicationConfig.getInstance().getLookupConfig().getRetryTimes(),
                    ApplicationConfig.getInstance().getLookupConfig().getSocketTimeout(),
                    ApplicationConfig.getInstance().getLookupConfig().getConnectionTimeout());
            listRows = this.getKdpObjectList(response, objectSearch);
            log.info("LOOKUP_REST -RESULT :" + listRows.size());
            
        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
      
        return listRows;
    }
	
    /**
     * {@inheritDoc}
     */
    @Override
    public List<Map<String, String>> lookupExtra(LookupExtra lookupExtra) {
        List<Map<String, String>> listRows = new ArrayList<Map<String, String>>(0);
        log.info("LOOKUP_EXTRA_INPUT###" + lookupExtra.toString());

        try {
            final String strasse = lookupExtra.getStrasse();
            log.debug("LOOKUP_REST :" + ApplicationConfig.getInstance().getLookupConfig().getSearchRestService()
                    + "|strasse:" + strasse);
            lookupExtra.setStrasse(strasse);
            final URI uri = new URIBuilder(
                    ApplicationConfig.getInstance().getLookupConfig().getLookupExtraRestService())
                    .addParameter("lookupExtra", JsonUtils.object2Json(lookupExtra)).build();
            final HttpUriRequest request = new HttpGet(uri);
            // final String response = HTTPUtils.doGET(request, 1000, 1);
            final String response = HttpClientFailover.intance().doGET(request,
                    ApplicationConfig.getInstance().getLookupConfig().getHosts(),
                    ApplicationConfig.getInstance().getLookupConfig().getDelay(),
                    ApplicationConfig.getInstance().getLookupConfig().getRetryTimes(),
                    ApplicationConfig.getInstance().getLookupConfig().getSocketTimeout(),
                    ApplicationConfig.getInstance().getLookupConfig().getConnectionTimeout());
            listRows = this.getLookupExtra(response);
            log.info("LOOKUP_EXTRA_REST-RESULT :" + listRows.size());

        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        return listRows;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Map<String, String> getParcelHauskeyFromZubofi(ZubofiAddress address) {
        final Map<String, String> row = new HashMap<String, String>();
        log.info("getParcelHauskeyFromZubofi###" + address.toString());

        try {
            log.debug(
                    "LOOKUP_REST :" + ApplicationConfig.getInstance().getLookupConfig().getZubofiHauskeyRestService());
            final URI uri = new URIBuilder(
                    ApplicationConfig.getInstance().getLookupConfig().getZubofiHauskeyRestService())
                    .addParameter("address", JsonUtils.object2Json(address)).build();
            final HttpUriRequest request = new HttpGet(uri);
            // final String response = HTTPUtils.doGET(request, 1000, 1);
            final String response = HttpClientFailover.intance().doGET(request,
                    ApplicationConfig.getInstance().getLookupConfig().getHosts(),
                    ApplicationConfig.getInstance().getLookupConfig().getDelay(),
                    ApplicationConfig.getInstance().getLookupConfig().getRetryTimes());
            return this.getAddress(response, LookupKey.HAUSKEY);

        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        return row;
    }

    @Override
    public Map<String, String> getAddressFromZubofiSpecial(ZubofiAddress address) {
        Map<String, String> row = new HashMap<String, String>();
        log.info("getAddressFromZubofiSpecial###" + address.toString());

        try {
            final String remoteUrl = ApplicationConfig.getInstance().getLookupConfig()
                    .getZubofiSpecialAddressidRestService();
            log.debug("getAddressFromZubofiSpecial :" + remoteUrl);
            final Map<String, String> params = new HashMap<String, String>();
            params.put(PARAM_ADDRESS, JsonUtils.object2Json(address));
            row = this.getAddressSpecial(this.callRemote(params, remoteUrl));
        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        return row;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Map<String, String> getAddressFromZubofiSpecialCheck(ZubofiAddress address) {
        Map<String, String> row = new HashMap<String, String>();
        log.info("getAddressFromZubofiSpecialCheck###" + address.toString());
        try {
            final String remoteUrl = ApplicationConfig.getInstance().getLookupConfig()
                    .getZubofiSpecialAddressidRestServiceCheck();
            log.debug("getAddressFromZubofiSpecialCheck :" + remoteUrl);
            final Map<String, String> params = new HashMap<String, String>();
            params.put(PARAM_ADDRESS, JsonUtils.object2Json(address));
            row = this.getAddressSpecial(this.callRemote(params, remoteUrl));
        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        return row;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Map<String, String>> getAddressFromZubofiSpecialSimilarCheck(ZubofiAddress address) {
        final List<Map<String, String>> row = new ArrayList<Map<String, String>>();
        log.info("getAddressFromZubofiSpecialSimilarCheck###" + address.toString());

        try {
            final String remoteUrl = ApplicationConfig.getInstance().getLookupConfig()
                    .getZubofiSpecialAddressidRestServiceSameCheck();
            log.debug("getAddressFromZubofiSpecialSimilarCheck :" + remoteUrl);
            final Map<String, String> params = new HashMap<String, String>();
            params.put(PARAM_ADDRESS, JsonUtils.object2Json(address));
            return this.getAddressSpecialSimilarCheck(this.callRemote(params, remoteUrl));
        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        return row;
    }

    /**
     * Get addressid from zubo address (plz,ort,strasse,haus,hauszusat)
     *
     * @param address
     * @return Map<String, String>
     */
    @Override
    public Map<String, String> getAddressFromZubofi(ZubofiAddress address) {
        final Map<String, String> row = new HashMap<String, String>();
        log.info("getAddressFromZubofi###" + address.toString());

        try {
            final String remoteUrl = ApplicationConfig.getInstance().getLookupConfig().getZubofiAddressidRestService();
            log.debug("getAddressFromZubofi :" + remoteUrl);
            final Map<String, String> params = new HashMap<String, String>();
            params.put(PARAM_ADDRESS, JsonUtils.object2Json(address));
            final String response = this.callRemote(params, remoteUrl);
            return this.getAddress(response, LookupKey.ADR_ID);
        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }

        return row;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Long getHauskeyByKdpid(Long kdpid) {

        try {
            log.debug("getHauskeyByKdpid :"
                    + ApplicationConfig.getInstance().getLookupConfig().getLookupHauskeyRestService() + "|kdpid:"
                    + kdpid);
            final URI uri = new URIBuilder(
                    ApplicationConfig.getInstance().getLookupConfig().getLookupHauskeyRestService() + "/" + kdpid)
                    .build();
            final HttpUriRequest request = new HttpGet(uri);
            // final String response = HTTPUtils.doGET(request, 1000, 1);
            final String response = HttpClientFailover.intance().doGET(request,
                    ApplicationConfig.getInstance().getLookupConfig().getHosts(),
                    ApplicationConfig.getInstance().getLookupConfig().getDelay(),
                    ApplicationConfig.getInstance().getLookupConfig().getRetryTimes());
            final JsonParser parser = new JsonParser();
            final JsonObject obj = parser.parse(response).getAsJsonObject();
            return obj.has(LookupKey.HAUSKEY.getKey()) ? obj.get(LookupKey.HAUSKEY.getKey()).getAsLong() : null;

        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int countDuplicatedKdp(ObjectKdp kdp) {

        try {
            log.debug("countDuplicatedKdp :"
                    + ApplicationConfig.getInstance().getLookupConfig().getLookupDuplicationCountRestService() + "|kdp:"
                    + kdp);
            final URI uri = new URIBuilder(
                    ApplicationConfig.getInstance().getLookupConfig().getLookupDuplicationCountRestService())
                    .addParameter("kdp", JsonUtils.object2Json(kdp)).build();
            final HttpUriRequest request = new HttpGet(uri);
            // final String response = HTTPUtils.doGET(request, 1000, 1);
            final String response = HttpClientFailover.intance().doGET(request,
                    ApplicationConfig.getInstance().getLookupConfig().getHosts(),
                    ApplicationConfig.getInstance().getLookupConfig().getDelay(),
                    ApplicationConfig.getInstance().getLookupConfig().getRetryTimes());
            final JsonParser parser = new JsonParser();
            final JsonObject obj = parser.parse(response).getAsJsonObject();
            return obj.get("count").getAsInt();

        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        return 0;
    }

    @Override
    public Long getStreetNumberByParcelHauskey(Long parcelhauskey) {
        try {
            log.debug("getStreetNumberByParcelHauskey :"
                    + ApplicationConfig.getInstance().getLookupConfig().getZubofiStreetnumberRestService()
                    + "|parcelhauskey:" + parcelhauskey);
            final URI uri = new URIBuilder(
                    ApplicationConfig.getInstance().getLookupConfig().getZubofiStreetnumberRestService() + "/"
                    + parcelhauskey).build();
            final HttpUriRequest request = new HttpGet(uri);
            // final String response = HTTPUtils.doGET(request, 1000, 1);
            final String response = HttpClientFailover.intance().doGET(request,
                    ApplicationConfig.getInstance().getLookupConfig().getHosts(),
                    ApplicationConfig.getInstance().getLookupConfig().getDelay(),
                    ApplicationConfig.getInstance().getLookupConfig().getRetryTimes());
            final JsonParser parser = new JsonParser();
            final JsonObject obj = parser.parse(response).getAsJsonObject();
            final String street = this.getValidValue(obj.get(LookupKey.STREETNUMBER.getKey()));
            if (street.isEmpty()) {
                return Long.valueOf(0);
            }
            return Long.parseLong(street);

        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        return null;
    }

    private Map<String, String> getAddress(String res, LookupKey key) {
        System.out.println("#######res:" + res);
        final Map<String, String> row = new HashMap<String, String>(2);
        final JsonParser parser = new JsonParser();
        final JsonObject hit = parser.parse(res).getAsJsonObject();
        if (!hit.has(key.getKey())) {
            return null;
        }
        row.put(LookupKey.ADR_ID.getKey(), this.getValidValue(hit.get(LookupKey.ADR_ID.getKey())));
        row.put(LookupKey.PLZ.getKey(), this.getValidValue(hit.get(LookupKey.PLZ.getKey())));
        row.put(LookupKey.ORT.getKey(), this.getValidValue(hit.get(LookupKey.ORT.getKey())));
        row.put(LookupKey.STRASSE.getKey(), this.getValidValue(hit.get(LookupKey.STRASSE.getKey())));
        row.put(LookupKey.HAUSKEY.getKey(), this.getValidValue(hit.get(LookupKey.HAUSKEY.getKey())));
        row.put(LookupKey.STREETNUMBER.getKey(), this.getValidValue(hit.get(LookupKey.STREETNUMBER.getKey())));
        row.put(LookupKey.HAUSNUMMER.getKey(), this.getValidValue(hit.get(LookupKey.HAUSNUMMER.getKey())));
        row.put(LookupKey.HAUSNUMMER_A.getKey(), this.getValidValue(hit.get(LookupKey.HAUSNUMMER_A.getKey())));
        log.info("getAddress### not null row: " + row);
        return row;
    }

    private Map<String, String> getAddressSpecial(String res) {
        System.out.println("#######res:" + res);
        final JsonParser parser = new JsonParser();
        final JsonObject hit = parser.parse(res).getAsJsonObject();
        if (!hit.has(LookupKey.ADR_ID.getKey())) {
            return null;
        }

        return this.getFromJson(hit);
    }

    private List<Map<String, String>> getAddressSpecialSimilarCheck(String res) {
        final List<Map<String, String>> result = new ArrayList<Map<String, String>>(0);
        final JsonParser parser = new JsonParser();
        final JsonArray jArr = parser.parse(res).getAsJsonArray();
        if (jArr != null) {
            for (final JsonElement item : jArr) {
                if ((item != null) && item.isJsonObject()) {
                    final JsonObject obj = item.getAsJsonObject();
                    if (obj != null) {
                        result.add(this.getFromJson(obj));
                    }
                }
            }
        }

        return result;
    }

    private List<Map<String, String>> getLookupExtra(String res) {
        final List<Map<String, String>> result = new ArrayList<Map<String, String>>(0);
        Map<String, String> row = null;
        final JsonParser parser = new JsonParser();
        final JsonObject obj = parser.parse(res).getAsJsonObject();
        final JsonElement hitObject = obj.get("hits");
        if ((hitObject != null) && hitObject.isJsonArray()) {
            final JsonArray array = hitObject.getAsJsonArray();
            for (final JsonElement hitEl : array) {
                final JsonObject hit = hitEl.getAsJsonObject().get("_source").getAsJsonObject();
                row = new HashMap<String, String>(2);
                row.put(LookupKey.SUGGEST_ORT.getKey(), this.getValidValue(hit.get(LookupKey.SUGGEST_ORT.getKey())));
                row.put(LookupKey.SUGGEST_PLZ.getKey(), this.getValidValue(hit.get(LookupKey.SUGGEST_PLZ.getKey())));
                row.put(LookupKey.SUGGEST_STRASSE.getKey(),
                        this.getValidValue(hit.get(LookupKey.SUGGEST_STRASSE.getKey())));
                result.add(row);
            }
        }
        return result;
    }

    /**
     * COnvert ElasticSearch result to capture data mapping
     *
     * @param res
     * @param lookup
	 * @return List<Map<String, String>>
	 * @throws UnsupportedEncodingException
     */
    private List<Map<String, String>> getKdpObjectList(String res, ObjectSearch objectSearch)
            throws UnsupportedEncodingException {
        final String lookup = objectSearch.getLookup();
        final List<Map<String, String>> listRows = new ArrayList<Map<String, String>>(0);
        final JsonParser parser = new JsonParser();
        final JsonObject obj = parser.parse(res).getAsJsonObject();
        final JsonElement hitObject = obj.get("hits");
        if ((hitObject != null) && hitObject.isJsonArray()) {
            final JsonArray array = hitObject.getAsJsonArray();
            for (final JsonElement hitEl : array) {
                final JsonObject hit = hitEl.getAsJsonObject().get("_source").getAsJsonObject();
                // pvgiang_1 -13/07/2016- UPDATE: Remove fields which are
                // removed from lookup key. View Lookupkey.java for detail!
                final Map<String, String> row = new HashMap<String, String>(0);
                final String type = this.getValidValue(hit.get(LookupKey.PERS_08_TYP.getKey()));
                row.put(LookupKey.PERS_08_TYP.getKey(), type);
                final String name = this.getValidValue(hit.get(LookupKey.NAME_09.getKey()));
                final String vname = this.getValidValue(hit.get(LookupKey.NAME_10.getKey()));
                // TYPE equal 'P' is person, 'O' is office
                if (type.equalsIgnoreCase("P")) {
                    row.put(LookupKey.FIRMENNAME.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.NAMENSZUSATZ.getKey(), StringUtils.EMPTY);

                    row.put(LookupKey.NAME.getKey(), name);
                    row.put(LookupKey.VORNAME.getKey(), vname);

                    // Anrede equal 'W' is Frau, 'M' is Herr
                    final String anrede = this.getValidValue(hit.get(LookupKey.ANREDE.getKey()));
                    row.put(LookupKey.ANREDE.getKey(),
                            anrede.equalsIgnoreCase("M") ? "Herr" : anrede.equalsIgnoreCase("W") ? "Frau" : StringUtils.EMPTY);
                } else {
                    row.put(LookupKey.FIRMENNAME.getKey(), name);
                    row.put(LookupKey.NAMENSZUSATZ.getKey(), vname);

                    row.put(LookupKey.NAME.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.VORNAME.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.ANREDE.getKey(), StringUtils.EMPTY);
                }

                row.put(LookupKey.ADR_ID.getKey(), this.getValidValue(hit.get(LookupKey.ADR_ID.getKey())));
                row.put(LookupKey.AADR_ID.getKey(), this.getValidValue(hit.get(LookupKey.AADR_ID.getKey())));

                row.put(LookupKey.HAUSKEY.getKey(), this.getValidValue(hit.get(LookupKey.HAUSKEY.getKey())));
                row.put(LookupKey.KDP_ID.getKey(), this.getValidValue(hit.get(LookupKey.KDP_ID.getKey())));

                //default value
                row.put(LookupKey.IS_SPECIAL.getKey(), Boolean.FALSE.toString());
                row.put(LookupKey.MY_POST_24.getKey(), StringUtils.EMPTY);
                row.put(LookupKey.PICKPOST.getKey(), StringUtils.EMPTY);
                row.put(LookupKey.POSTFACHNUMMER.getKey(), StringUtils.EMPTY);
                row.put(LookupKey.IS_POSTFACH.getKey(), StringUtils.EMPTY);
                row.put(LookupKey.IS_IGNORE_KUNDENNUMBER.getKey(), Boolean.FALSE.toString());

                // full fill address such as ort, ort set, plz, strasse, strasse set, haunr , haunr_a , fullhaunr
                row.put(LookupKey.ORT.getKey(), this.getValidValue(hit.get(LookupKey.ORT.getKey())));
                row.put(LookupKey.ORT_SET.getKey(), this.getValidValue(hit.get(LookupKey.ORT_SET.getKey())));
                row.put(LookupKey.PLZ.getKey(), this.getValidValue(hit.get(LookupKey.PLZ.getKey())));
                row.put(LookupKey.STRASSE.getKey(), this.getValidValue(hit.get(LookupKey.STRASSE.getKey())));
                row.put(LookupKey.STRASSE_SET.getKey(),
                        this.getValidValue(hit.get(LookupKey.STRASSE_SET.getKey())));
                row.put(LookupKey.HAUSNUMMER.getKey(), this.getValidValue(hit.get(LookupKey.HAUSNUMMER.getKey())));
                row.put(LookupKey.HAUSNUMMER_A.getKey(),
                        this.getValidValue(hit.get(LookupKey.HAUSNUMMER_A.getKey())));
                row.put(LookupKey.FULLHAUSNUMMER.getKey(),
                        row.get(LookupKey.HAUSNUMMER.getKey()) + row.get(LookupKey.HAUSNUMMER_A.getKey()));

                final String kundennumber = this.getValidValue(hit.get(LookupKey.KUNDENNUMBER.getKey()));

                if (!StringUtils.isBlank(objectSearch.getMypost24()) || !StringUtils.isBlank(objectSearch.getPickpost())) {
                    // mypost24 + pickpost addresss
                    /**
                     * Request #10890(update 30/09/2016): do not fill data of
                     * plz, ort, strasse, hausnr when kdp is pickpost/mypost24
                     */
                    row.put(LookupKey.IS_SPECIAL.getKey(), Boolean.TRUE.toString());
                    row.put(LookupKey.ORT.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.ORT_SET.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.PLZ.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.ORT.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.ORT_SET.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.PLZ.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.STRASSE.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.STRASSE_SET.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.HAUSNUMMER.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.HAUSNUMMER_A.getKey(), StringUtils.EMPTY);
                    row.put(LookupKey.FULLHAUSNUMMER.getKey(), StringUtils.EMPTY);
                    if (!objectSearch.getMypost24().equalsIgnoreCase(StringUtils.EMPTY)) {
                        row.put(LookupKey.MY_POST_24.getKey(), kundennumber);
                    } else if (!objectSearch.getPickpost().equalsIgnoreCase(StringUtils.EMPTY)) {
                        row.put(LookupKey.PICKPOST.getKey(), kundennumber);
                    }
                } else {
                    // the object search is domizil/postfach address and kundennumber has value --> set is_ignore_kundennumber = true (don't care it when saving) + default display on myposy24 field
                    if (!StringUtils.isBlank(kundennumber)) {
                        row.put(LookupKey.IS_IGNORE_KUNDENNUMBER.getKey(), Boolean.TRUE.toString());
                        row.put(LookupKey.MY_POST_24.getKey(), kundennumber);
                    }
                    if (!StringUtils.isBlank(objectSearch.getPf()) && StringUtils.isBlank(objectSearch.getStrasse())) {
                        //postfach address don't fill strasse, hausnr
                        row.put(LookupKey.IS_POSTFACH.getKey(), "X");
                        row.put(LookupKey.STRASSE.getKey(), StringUtils.EMPTY);
                        row.put(LookupKey.STRASSE_SET.getKey(), StringUtils.EMPTY);
                        row.put(LookupKey.HAUSNUMMER.getKey(), StringUtils.EMPTY);
                        row.put(LookupKey.HAUSNUMMER_A.getKey(), StringUtils.EMPTY);
                        row.put(LookupKey.FULLHAUSNUMMER.getKey(), StringUtils.EMPTY);
                    }
                }

                row.put(LookupKey.NIXIE_CODE.getKey(), this.getValidValue(hit.get(LookupKey.NIXIE_CODE.getKey())));
                row.put(LookupKey.STREETNUMBER.getKey(), this.getValidValue(hit.get(LookupKey.STREETNUMBER.getKey())));

                // get alias for vorname/name/kdp
                final String name_synonym = this.getValidValue(hit.get(LookupKey.NAME_SET.getKey()));
                final String vname_synonym = this.getValidValue(hit.get(LookupKey.VNAME_SET.getKey()));
                row.put(LookupKey.NAME_SET.getKey(), name_synonym);
                row.put(LookupKey.VNAME_SET.getKey(), vname_synonym);
                row.put(LookupKey.NAME_ALIAS.getKey(), Boolean.FALSE.toString());
                row.put(LookupKey.VNAME_ALIAS.getKey(), Boolean.FALSE.toString());
                if ((lookup != null) && !lookup.isEmpty() && type.equalsIgnoreCase("P")) {
                    final String[] name_set = name_synonym.split("\\|");
                    final String[] vname_set = vname_synonym.split("\\|");

                    row.put(LookupKey.NAME_ALIAS.getKey(), this.isAliasLookup(name_set, lookup, name).toString());
                    row.put(LookupKey.VNAME_ALIAS.getKey(), this.isAliasLookup(vname_set, lookup, vname).toString());
                }

                // KDP_ALIAS is combined from KDP_NAME_ALIAS and
                // KDP_VORNAME_ALIAS
                final String kdp_name_alias = this.getValidValue(hit.get(LookupKey.KDP_NAME_ALIAS.getKey()));
                final String kdp_vorname_alias = this.getValidValue(hit.get(LookupKey.KDP_VORNAME_ALIAS.getKey()));

                final StringBuilder kdp_synonyms_builder = new StringBuilder();
                kdp_synonyms_builder.append(kdp_name_alias);
                kdp_synonyms_builder.append(kdp_vorname_alias);

                final String kdp_synonyms = kdp_synonyms_builder.toString();

                row.put(LookupKey.KDP_ALIAS.getKey(), kdp_synonyms);
                row.put(LookupKey.IS_KDP_ALIAS.getKey(), Boolean.FALSE.toString());
                if (!kdp_synonyms.isEmpty()) {
                    row.put(LookupKey.IS_KDP_ALIAS.getKey(), Boolean.TRUE.toString());
                } 

                listRows.add(row);
            }
        }
        this.sortKdp(listRows);
        log.info("total size:" + obj.get("total") + " | took:" + obj.get("took"));
        return listRows;

    }

    private static String PATTERN_START_ALIAS = "(?=.*?\\b(%s)).*$";
    private static String PATTERN_CONTAIN_ALIAS = "(?=.*?(%s)).*$";

    /**
     * Indicate lookup is in alias list and not equal name word
     *
     * @param aliasList
     * @param lookup
     * @param name
     * @return Boolean
     */
    private Boolean isAliasLookup(String[] aliasList, String lookup, String name) {

        final boolean isContain = lookup.trim().startsWith("%");
        final String lookup_translate = translateForDisplay(lookup).replace(" ", "|");
        final String orginal = translateForDisplay(name);
        final String ipattern = String.format(isContain ? PATTERN_CONTAIN_ALIAS : PATTERN_START_ALIAS,
                lookup_translate);
        if (!orginal.isEmpty() && !orginal.matches(ipattern)) {
            for (String str : aliasList) {
                str = translateForDisplay(str);
                if (str.matches(ipattern)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Replace multiple spaces by one space
     *
     * @param value
     * @return String
     */
    public static String removeSpace(String value) {
        value = value.replaceAll("\\s+", " ");
        return value;
    }

    /**
     * Replace not word data (defined in config file) by white space
     *
     * @param strasse
     * @return String
     */
    public String removeNotWordsData(String strasse) {
        this.notWordData = this.notWordData.replace(";", "|");
        this.notWordData = this.notWordData.replace(".", "\\.");
        return removeSpace(strasse.replaceAll(this.notWordData, " "));
    }

    /**
     * Remove accent on String and translate special word to common.Example:
     * ß==>ss ,œ ==>oe,ö==>o, ä==>a, ü ==>u
     *
     * @Note : replaceAll without '%'
     * @param str
     * @return String
     */
    public static String translateForDisplay(String str) {
        String translateWord = org.apache.commons.lang3.StringUtils.stripAccents(str.trim().toLowerCase());
        translateWord = translateWord.replace("ß", "ss");
        translateWord = translateWord.replace("œ", "oe");
        translateWord = translateWord.replace("ae", "a");
        translateWord = translateWord.replace("oe", "o");
        translateWord = translateWord.replace("ue", "u");
        translateWord = translateWord.replaceAll("[^a-z0-9]+", " ");
        return translateWord.trim();
    }

    public String translate(String str) {
        String translateWord = org.apache.commons.lang3.StringUtils.stripAccents(str.trim().toLowerCase());
        translateWord = translateWord.replace("ß", "ss");
        translateWord = translateWord.replace("œ", "oe");
        translateWord = translateWord.replace("ae", "a");
        translateWord = translateWord.replace("oe", "o");
        translateWord = translateWord.replace("ue", "u");
        return translateWord.trim();
    }

    private void sortKdp(List<Map<String, String>> kdps) {
        final List<Map<String, String>> topList = new ArrayList<Map<String, String>>(0);
        final List<Map<String, String>> bottomList = new ArrayList<Map<String, String>>(0);
        for (int i = 0; i < kdps.size(); i++) {
            final Map<String, String> kdp = kdps.get(i);
            if ("false".equalsIgnoreCase(kdp.get(LookupKey.VNAME_ALIAS.getKey()))
                    && "true".equalsIgnoreCase(kdp.get(LookupKey.NAME_ALIAS.getKey()))) {
                bottomList.add(kdp);
            } else {
                topList.add(kdp);
            }
        }
        kdps.clear();
        kdps.addAll(topList);
        kdps.addAll(bottomList);
    }

    // public static void main(String[] args) {
    // LookupService service = new LookupService();
    // log.debug(service.filterStrasse("Dornacherstrasse-Rue ru"));
    // }
    /**
     * Bug #9532 KDPID Searching result isn't displayed when strasse has
     * NOT_WORD= strasse
     *
     * @param strasse
     * @return
     */
    public String filterStrasse(String strasse) {
        final String[] arr = this.removeNotWordsData(strasse).split(" ");
        final StringBuilder builder = new StringBuilder();

        for (final String singleWord : arr) {
            builder.append(this.processStrasse(singleWord)).append(" ");
        }

        return builder.toString().trim();

    }

    private String processStrasse(String singleWord) {

        final String[] wordEndWith = ApplicationConfig.getInstance().getBusinessConfig().getReplaceEndWith().split(",");

        String result = singleWord;

        for (final String replace : wordEndWith) {
            if (this.endsWith(singleWord, replace, false)) {
                result = this.replaceEndsWith(singleWord, replace);
                break;
            }
        }

        return result;
    }

    private String replaceEndsWith(String str, String suffix) {
        final int strOffset = str.length() - suffix.length();

        return str.substring(0, strOffset);
    }

    private boolean endsWith(String str, String suffix, boolean ignoreCase) {
        if ((str == null) || (suffix == null)) {
            return ((str == null) && (suffix == null));
        }

        if (suffix.length() > str.length()) {
            return false;
        }

        final int strOffset = str.length() - suffix.length();

        return str.toLowerCase().regionMatches(ignoreCase, strOffset, suffix.toLowerCase(), 0, suffix.length());
    }

    private Map<String, String> getFromJson(JsonObject hit) {
        final Map<String, String> row = new HashMap<String, String>(2);
        row.put(LookupKey.ADR_ID.getKey(), this.getValidValue(hit.get(LookupKey.ADR_ID.getKey())));
        row.put(LookupKey.PLZ.getKey(), this.getValidValue(hit.get(LookupKey.PLZ.getKey())));
        row.put(LookupKey.ORT.getKey(), this.getValidValue(hit.get(LookupKey.ORT.getKey())));
        row.put(LookupKey.STRASSE.getKey(), this.getValidValue(hit.get(LookupKey.STRASSE.getKey())));
        row.put(LookupKey.HAUSNUMMER.getKey(), this.getValidValue(hit.get(LookupKey.HAUSNUMMER.getKey())));
        row.put(LookupKey.HAUSNUMMER_A.getKey(), this.getValidValue(hit.get(LookupKey.HAUSNUMMER_A.getKey())));
        row.put(LookupKey.HAUSKEY.getKey(), this.getValidValue(hit.get(LookupKey.HAUSKEY.getKey())));
        row.put(LookupKey.STREETNUMBER.getKey(), this.getValidValue(hit.get(LookupKey.STREETNUMBER.getKey())));
        row.put("by_rule", this.getValidValue(hit.get("by_rule")));
        log.info("getAddress### not null row: " + row);
        return row;
    }

    @Override
    public Long getParcelHauskeyFromAmpplus(ZubofiAddress address) {
        log.info("getParcelHauskeyFromAmpplus###" + address.toString());

        try {
            log.debug(
                    "LOOKUP_REST :" + ApplicationConfig.getInstance().getLookupConfig().getLookupHauskeyRestService());
            final URI uri = new URIBuilder(
                    ApplicationConfig.getInstance().getLookupConfig().getLookupHauskeyRestService())
                    .addParameter("kdp", JsonUtils.object2Json(address)).build();

            final HttpUriRequest request = new HttpGet(uri);
            // final String response = HTTPUtils.doGET(request, 1000, 1);
            final String response = HttpClientFailover.intance().doGET(request,
                    ApplicationConfig.getInstance().getLookupConfig().getHosts(),
                    ApplicationConfig.getInstance().getLookupConfig().getDelay(),
                    ApplicationConfig.getInstance().getLookupConfig().getRetryTimes());
            final JsonParser parser = new JsonParser();
            final JsonObject obj = parser.parse(response).getAsJsonObject();
            return obj.has(LookupKey.HAUSKEY.getKey()) ? obj.get(LookupKey.HAUSKEY.getKey()).getAsLong() : -1L;

        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        return -1L;
    }

    @Override
    public Map<String, String> getParcelHauskeyFromZubofiSpecial(String plz) {
    	Map<String, String> results = new HashMap<String, String>();
        log.info("getParcelHauskeyFromZubofiSpecial###" + plz.toString());
        try {
            log.debug("getParcelHauskeyFromZubofiSpecial: "
                    + ApplicationConfig.getInstance().getLookupConfig().getZubofiSpecialAddressidRestService() + "|plz:"
                    + plz);
            final URI uri = new URIBuilder(
                    ApplicationConfig.getInstance().getLookupConfig().getZubofiSpecialAddressidRestService() + "/"
                    + plz).build();
            final HttpUriRequest request = new HttpGet(uri);
            // final String response = HTTPUtils.doGET(request, 1000, 1);
            final String response = HttpClientFailover.intance().doGET(request,
                    ApplicationConfig.getInstance().getLookupConfig().getHosts(),
                    ApplicationConfig.getInstance().getLookupConfig().getDelay(),
                    ApplicationConfig.getInstance().getLookupConfig().getRetryTimes());
            final JsonParser parser = new JsonParser();
            final JsonObject obj = parser.parse(response).getAsJsonObject();
            results = this.getFromJson(obj);

        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        return results;
    }

    @Override
    public Map<String, String> getParcelHauskeyFromZubofiSpecial(ZubofiAddress zubofiAddress) {
    	Map<String, String> results = new HashMap<String, String>();
        log.info("getParcelHauskeyFromZubofiSpecial###" + zubofiAddress.toString());
        try {
            log.debug("LOOKUP_REST :"
                    + ApplicationConfig.getInstance().getLookupConfig().getZubofiSpecialPickpostHauskeyRestService());
            final URI uri = new URIBuilder(
                    ApplicationConfig.getInstance().getLookupConfig().getZubofiSpecialPickpostHauskeyRestService())
                    .addParameter("address", JsonUtils.object2Json(zubofiAddress)).build();
            final HttpUriRequest request = new HttpGet(uri);
            // final String response = HTTPUtils.doGET(request, 1000, 1);
            final String response = HttpClientFailover.intance().doGET(request,
                    ApplicationConfig.getInstance().getLookupConfig().getHosts(),
                    ApplicationConfig.getInstance().getLookupConfig().getDelay(),
                    ApplicationConfig.getInstance().getLookupConfig().getRetryTimes());
            final JsonParser parser = new JsonParser();
            final JsonObject obj = parser.parse(response).getAsJsonObject();
            results = this.getFromJson(obj);
        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        return results;
    }

    @Override
    public Map<String, String> getParcelHauskeyPostfachFromZubofiSpecial(ZubofiAddress zubofiAddress) {
    	Map<String, String> results = new HashMap<String, String>();
        log.info("getParcelHauskeyPostfachFromZubofiSpecial###" + zubofiAddress.toString());
        try {
            log.debug("LOOKUP_REST :"
                    + ApplicationConfig.getInstance().getLookupConfig().getZubofiSpecialPostfachHauskeyRestService());
            final URI uri = new URIBuilder(
                    ApplicationConfig.getInstance().getLookupConfig().getZubofiSpecialPostfachHauskeyRestService())
                    .addParameter("address", JsonUtils.object2Json(zubofiAddress)).build();
            final HttpUriRequest request = new HttpGet(uri);
            // final String response = HTTPUtils.doGET(request, 1000, 1);
            final String response = HttpClientFailover.intance().doGET(request,
                    ApplicationConfig.getInstance().getLookupConfig().getHosts(),
                    ApplicationConfig.getInstance().getLookupConfig().getDelay(),
                    ApplicationConfig.getInstance().getLookupConfig().getRetryTimes());
            final JsonParser parser = new JsonParser();
            final JsonObject obj = parser.parse(response).getAsJsonObject();
            results = this.getFromJson(obj);
        } catch (final Exception e) {
            log.error("", e);
            EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    AroundDialog.showMessageDialog(null, WordUtils.wrap(Utilities.getStackTrace(e), 100), "Canh bao",
                            JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        return results;
    }
    
	@Override
	public Map<String, String> getParcelHauskeyPostlagerndFromZubofiSpecial(
			ZubofiAddress zubofiAddress) {
		Map<String, String> results = new HashMap<String, String>();
		log.info("get ParcelHauskey Postlagernd From ZubofiSpecial ###" + zubofiAddress.toString());
		try {
			log.debug("LOOKUP_REST :" + ApplicationConfig.getInstance().getLookupConfig().getZubofiSpecialPostlagerndHauskeyRestService());
			final URI uri = new URIBuilder(ApplicationConfig.getInstance().getLookupConfig()
											.getZubofiSpecialPostlagerndHauskeyRestService())
											.addParameter("address", JsonUtils.object2Json(zubofiAddress)).build();
			final HttpUriRequest request = new HttpGet(uri);
			// final String response = HTTPUtils.doGET(request, 1000, 1);
			final String response = HttpClientFailover.intance().doGET(
					request,
					ApplicationConfig.getInstance().getLookupConfig().getHosts(),
					ApplicationConfig.getInstance().getLookupConfig().getDelay(),
					ApplicationConfig.getInstance().getLookupConfig().getRetryTimes());
			final JsonParser parser = new JsonParser();
			final JsonObject obj = parser.parse(response).getAsJsonObject();
			results = this.getFromJson(obj);
		} catch (final Exception e) {
			log.error("", e);
			EventQueue.invokeLater(new Runnable() {

				@Override
				public void run() {
					AroundDialog.showMessageDialog(null,
							WordUtils.wrap(Utilities.getStackTrace(e), 100),
							"Canh bao", JOptionPane.WARNING_MESSAGE);
				}
			});
		}
		return results;
	}

	@Override
	public Map<String, String> getPlzFromASDPPlz(String plz, String ort) {
		log.info("get PLZ from ASDP PLZ");
		Map<String, String> row = new HashMap<String, String>();
		Map<String, String> params = new HashMap<String, String>();
		try {
			params.put(PARAM_PLZ, plz);
			params.put(PARAM_ORT, ort);
			String remoteUrl = ApplicationConfig.getInstance().getLookupConfig().getLookupASDPPlz();
			String respone = this.callRemote(params, remoteUrl);
			final JsonParser parser = new JsonParser();
			final JsonArray arrayPLZ = parser.parse(respone).getAsJsonArray();
			if (arrayPLZ.size() == 1) {
				row = parseFromPlzJsonArray(arrayPLZ, row);
			}
		} catch (final Exception e) {
			log.error("", e);
			EventQueue.invokeLater(new Runnable() {
				
				@Override
				public void run() {
					AroundDialog.showMessageDialog(null,
							WordUtils.wrap(Utilities.getStackTrace(e), 100),
							"Canh bao", JOptionPane.WARNING_MESSAGE);
				}
			});
		}
		return row;
	}
    
    private  Map<String, String> parseFromPlzJsonArray(JsonArray jArr, Map<String, String> row) {
    	 if (jArr != null) {
             for (final JsonElement item : jArr) {
                 if ((item != null) && item.isJsonObject()) {
                     final JsonObject obj = item.getAsJsonObject();
                     if (obj != null) {
                    	 row = this.parseFromPlzJsonObject(obj);
                     }
                 }
             }
         }
    	return row; 
	}
    
    private Map<String, String> parseFromPlzJsonObject(JsonObject plzJsonObject) {
		Map<String, String> plz = new HashMap<String, String>();
		plz.put(LookupKey.PLZ_PLZ.getKey(), this.getValidValue(plzJsonObject.get(LookupKey.PLZ_PLZ.getKey())));
		plz.put(LookupKey.PLZ_TYP.getKey(), this.getValidValue(plzJsonObject.get(LookupKey.PLZ_TYP.getKey())));
		plz.put(LookupKey.PLZ_LOGTYP.getKey(), this.getValidValue(plzJsonObject.get(LookupKey.PLZ_LOGTYP.getKey())));
		plz.put(LookupKey.ORT.getKey(), this.getValidValue(plzJsonObject.get(LookupKey.ORT.getKey())));
		return plz;
	}
}
