/*
 * Class: ILookupService
 *
 * Created on Mar 30, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package com.ghp.vae.search.service;

import java.util.List;
import java.util.Map;

import com.ghp.vae.search.model.LookupExtra;
import com.ghp.vae.search.model.ObjectKdp;
import com.ghp.vae.search.model.ObjectSearch;
import com.ghp.vae.search.model.ZubofiAddress;

/**
 * @author tvbinh
 *
 */
public interface ILookupService extends ILookupProxyService {
	/**
	 * Lookup KDP from Lookup_Proxy_Servie (ElasticSearch server)
	 *
	 * @param obj
	 *            {@link ObjectSearch}
	 * @return List<Map<String, String>>
	 */
	List<Map<String, String>> lookupKDP(ObjectSearch obj, boolean isFirstSearch);
	
	/**
	 * Get lookup extra (plz, ort, strasse) from given lookup extra
	 *
	 * @param lookupExtra
	 *            {@link LookupExtra}
	 * @return List<Map<String, String>>
	 */
	List<Map<String, String>> lookupExtra(LookupExtra lookupExtra);

	/**
	 * Read parcel hauskey from zubofi
	 *
	 * @param address
	 *            {@link ZubofiAddress}
	 * @return Map<String, String>
	 */
	Map<String, String> getParcelHauskeyFromZubofi(ZubofiAddress address);

	/**
	 * Read parcel hauskey form amp-plus
	 *
	 * @param address
	 * @return Map<String, String>
	 */
	Long getParcelHauskeyFromAmpplus(ZubofiAddress address);

	/**
	 * Get addressid from zubo address (plz,ort,strasse,haus,hauszusat)
	 *
	 * @param address
	 * @return Map<String, String>
	 */
	Map<String, String> getAddressFromZubofi(ZubofiAddress address);

	/**
	 * Get address postfach from zubofi special (plz,ort,strasse,haus,hauszusat)
	 *
	 * @param address
	 *            {@link ZubofiAddress} the param object
	 * @return {@link Map} the list of found zubofi
	 */
	Map<String, String> getAddressFromZubofiSpecial(ZubofiAddress address);

	/**
	 * Get address pickpost from zubofi special, compare the same
	 *
	 * @param address
	 *            {@link ZubofiAddress}
	 * @return {@link Map}
	 */
	Map<String, String> getAddressFromZubofiSpecialCheck(ZubofiAddress address);

	/**
	 * Get address pickpost from zubofi special, compare like
	 *
	 * @param address
	 *            {@link ZubofiAddress}
	 * @return {@link Map}
	 */
	List<Map<String, String>> getAddressFromZubofiSpecialSimilarCheck(ZubofiAddress address);

	/**
	 * Get hauskey from kdpid
	 *
	 * @param kdpid
	 *            {@link Long}
	 * @return {@link Long}
	 */
	Long getHauskeyByKdpid(Long kdpid);

	/**
	 * Get count duplicate KDP
	 *
	 * @param kdp
	 *            {@link ObjectKdp}
	 * @return int
	 */
	int countDuplicatedKdp(ObjectKdp kdp);

	/**
	 * Get street number by parcel hauskey
	 *
	 * @param parcelhauskey
	 *            {@link Long}
	 * @return {@link Long}
	 */
	Long getStreetNumberByParcelHauskey(Long parcelhauskey);

	/**
	 * Get parcel hauskey from zubofi special by plz
	 *
	 * @param plz
	 * @return
	 */
	Map<String, String> getParcelHauskeyFromZubofiSpecial(String plz);

	Map<String, String> getParcelHauskeyFromZubofiSpecial(ZubofiAddress zubofiAddress);

	Map<String, String> getParcelHauskeyPostfachFromZubofiSpecial(ZubofiAddress zubofiAddress);
	
	Map<String, String> getParcelHauskeyPostlagerndFromZubofiSpecial(ZubofiAddress zubofiAddress);
	
	/**
	 * Lookup PLZ from ASDP_PLZ (ElasticSearch server)
	 * For checking Firmen-PLZ
	 * @param plz
	 *            {@link ObjectSearch}
	 * @return List<Map<String, String>>
	 */
	Map<String, String> getPlzFromASDPPlz (String plz, String ort);
}
