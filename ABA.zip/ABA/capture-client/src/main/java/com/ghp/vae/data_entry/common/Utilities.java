package com.ghp.vae.data_entry.common;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

public class Utilities {
	private static Logger log = LoggerFactory.getLogger(Utilities.class);
    public Utilities() {
    }

    /**
     * get date following delameter and format type
     * @param sDate: date input
     * @param input_type: input format (0 --> DDMMYYYY, 1 --> MMDDYYYY, 2 --> YYYYMMDD)
     * @param delemeter: delemeter out put format
     * @param type_of_format: type of out put format (0 --> DDMMYYYY, 1 --> MMDDYYYY, 2 --> YYYYMMDD)
     * @author vtbinh
     * @return string
     **/
    public static String formatDate(String sDate, int input_type, String delemeter, int type_of_format) {
        String s = "";
        String sD = "";
        String sM = "";
        String sY = "";
        if (sDate.trim().length() == 8) {
            switch (input_type) {
                case 0:
                    sD = sDate.substring(0, 2);
                    sM = sDate.substring(2, 4);
                    sY = sDate.substring(4, sDate.length());
                    break;
                case 1:
                    sM = sDate.substring(0, 2);
                    sD = sDate.substring(4, 2);
                    sY = sDate.substring(4, sDate.length());
                    break;
                case 2:
                    sY = sDate.substring(0, 4);
                    sM = sDate.substring(4, 2);
                    sD = sDate.substring(6, sDate.length());
                    break;
                default:
                    break;
            }
            switch (type_of_format) {
                case 0:
                    s = sD.concat(delemeter).concat(sM).concat(delemeter).concat(sY);//DDMMYY
                    break;
                case 1:
                    s = sM.concat(delemeter).concat(sD).concat(delemeter).concat(sY);//MMDDYY
                    break;
                case 2:
                    s = sY.concat(delemeter).concat(sM).concat(delemeter).concat(sD);//YYMMDD
                    break;
                default:
                    break;
            }
            //s =sD.concat(seperate).concat(sM).concat(seperate).concat(sY);
        } else {
            s = sDate;
        }
        return s;
    }

    /**
     * get current date following delemeter and format type
     * @param delemeter: delemeter out put
     * @param type_of_format: format type of out put (0 --> DDMMYY, 1 --> MMDDYY, 2 --> YYMMDD)
     * @return string
     * @author vtbinh
     **/
    public static String getCurrentDate(String delemeter, int type_of_format) {
        try {
            Date fDate = new Date();
            SimpleDateFormat dateformat = new SimpleDateFormat("ddMMyyyy");
            return formatDate(dateformat.format(fDate).toString(), 0, delemeter, type_of_format);

        } catch (Exception ex) {
            return "";
        }
    }

    /**
     * Check value if Null return Blank
     * @param strTemp
     * @return String Ignore Null
     */
    public static String ignoreNull(String strTemp) {
        if (strTemp == null) {
            return "";
        } else {
            return strTemp.trim();
        }
    }
     public static String firstWorld(String value) {
        if (StringUtils.isEmpty(value)) {
            return "";
        }
        String result = value;
        //------------------pml-clear last a test of string------
        if (StringUtils.countMatches(value, "-") >= 1) {
            result = result.substring(0, result.lastIndexOf('-')).trim();
        } else if (StringUtils.countMatches(result, " ") >= 1) {
                result = result.substring(0, result.lastIndexOf(' '));
                //result = result.replaceAll("\\s+", " ");
        }else {
        	result="";
        }
        //------------------pml-clear last a test of string------
        return result;
    }

    public static String afterWorld(String value) {
        if (StringUtils.isEmpty(value)) {
            return "";
        }
        String result = value;
        //------------------pml-clear first a test of string------
        if (StringUtils.countMatches(value, "-") >= 1) {
           result = result.substring(result.indexOf('-')+1).trim();
        } else if (StringUtils.countMatches(result, " ") >= 1) {
                result = result.substring(result.indexOf(' ')+1).trim();
                // result = result.replaceAll("\\s+", " ");
        }else {
        	result="";
        }
        //------------------pml-clear first a test of string------
        return result;
    }

    public static String toString(Object strTemp) {
        if (strTemp == null) {
            return "";
        } else {
            return strTemp.toString().trim();
        }
    }

//	Author: Nguyen Duc Tuan
//	doing: return a String after trim
//	Input: a string
//	Output: a trimed  string     
    public static String trimData(String value) {
        String valuereturn = "";
        if (value == null) {
            valuereturn = "";
        } else {
            valuereturn = value.trim();
        }

        return valuereturn;
    }

    /**
     * Author: Nguyen Duc Tuan
     * @param value
     * @return
     */
    public static boolean createFolders(String value) {
        File folder = new File(value);
        if (!folder.isDirectory()) {
            try {
                if (folder.mkdirs()) {
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "can not create the new folder");
                    return false;
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "can not create the new folder");
                return false;
            }

        } else {
            return true;
        }

    }

    public static boolean checkFutureDate(String sDate, String sFormat, String minDate, String maxDate) {
        int t = sFormat.length();
        // MMyyyy,yyyy,ddMMyyyy
        if ((t != 4) && (t != 6) && (t != 8)) {
            return false;
        }
        StringBuffer tmp = new StringBuffer(sDate);
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat(sFormat);
            dateFormat.setLenient(false);
            Date dt2 = dateFormat.parse(tmp.toString());
            Date dmax = dateFormat.parse(maxDate);

            Date dmin = dateFormat.parse(minDate);
            if (dt2.after(dmin) && dt2.before(dmax)) {
                return true;
            } else {
                return false;
            }
        } catch (Exception ex) {
            return false;
        }

    }

    public static String previousDate(String date) {
        StringBuffer temp = new StringBuffer(date);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        try {
            Date d = dateFormat.parse(temp.toString());
            Date previousDate = new Date(d.getTime() - 86400000);
            String strPreviousDate = dateFormat.format(previousDate);
            return strPreviousDate;
        } catch (ParseException e) {
            return null;
        }
    }
    /***
     * Check string if whether it is in ar.
     * @author hnmthu
     **/
    public static boolean inArray(String[] ar, String s) {
        if (!s.equals("") && (ar != null)) {
            for (int i = 0; i <= ar.length - 1; i++) {
                if (ar[i].toString().equalsIgnoreCase(s)) {
                    return true;
                }
            }
        }
        return false;
    }

    /***
     * Upercase before " ", "-"
     * @param String[]
     * @param String
     * @return String
     ***/
    public static String toMyUpcase(String[] arr, String sString) {
        String tmp = "";
        String s = "";
        if (!sString.equals("")) {
            // The first, search "-"
            String[] tiretString = sString.trim().split("-");
            if (tiretString.length > 0) {
                for (int i = 0; i < tiretString.length; i++) {
                    tmp = tiretString[i].trim();
                    // The second, search a space character.
                    String[] emptyString = tmp.split(" ");
                    if (emptyString.length > 1) {
                        if (i != 0 && !tmp.equals("")) {
                            s += "-";
                        }
                        for (int l = 0; l < emptyString.length; l++) {
                            if (!emptyString[l].trim().equals("")) {
                                // Upcase first character.
                                s += String.valueOf(emptyString[l].trim().charAt(0)).toUpperCase() + emptyString[l].trim().substring(1) + " ";
                            }
                        }
                        s = s.trim();
                    } else {// no has space.
                        if (!tiretString[i].trim().equals("")) {
                            s += "-" + String.valueOf(tiretString[i].trim().charAt(0)).toUpperCase() + tiretString[i].trim().substring(1);
                        }
                    }
                }
            }
        } else {
            s = sString;
        }
        if (s.endsWith("-")) {
            s = s.substring(0, s.length() - 1);
        } else if (s.startsWith("-")) {
            s = s.substring(1, s.length());
        }

        String sUperCase = "";
        if (!s.equals("")) {
            String[] subS;
            ArrayList<Integer> arrIndex = new ArrayList<Integer>();
            ArrayList<String> srrSubName = new ArrayList<String>();
            int parafix1 = 0, parafix2 = 0;

            tmp = s;
            int j = 0;
            while (tmp.indexOf(" ") >= 0 || tmp.indexOf("-") >= 0)// || tmp.indexOf("-") >= 0)
            {
                parafix1 = tmp.indexOf(" ");
                parafix2 = tmp.indexOf("-");
                try {
                    if (j == 0) {
                        if (parafix1 >= 0 && parafix2 >= 0) {
                            if (parafix1 < parafix2) {
                                arrIndex.add(Integer.valueOf(parafix1));
                            } else {
                                arrIndex.add(Integer.valueOf(parafix2));
                            }
                        } else if (parafix1 < 0 && parafix2 >= 0) {
                            arrIndex.add(Integer.valueOf(parafix2));
                        } else {
                            arrIndex.add(Integer.valueOf(parafix1));
                        }
                    } else {
                        if (parafix1 >= 0 && parafix2 >= 0) {
                            if (parafix1 < parafix2) {
                                arrIndex.add(Integer.valueOf(parafix1 + 1 + Integer.valueOf(arrIndex.get(j - 1).toString()).intValue()));
                            } else {
                                arrIndex.add(Integer.valueOf(parafix2 + 1 + Integer.valueOf(arrIndex.get(j - 1).toString()).intValue()));
                            }
                        } else if (parafix1 < 0 && parafix2 >= 0) {
                            arrIndex.add(Integer.valueOf(parafix2 + 1 + Integer.valueOf(arrIndex.get(j - 1).toString()).intValue()));
                        } else {
                            arrIndex.add(Integer.valueOf(parafix1 + 1 + Integer.valueOf(arrIndex.get(j - 1).toString()).intValue()));
                        }
                    }
                    if (parafix1 >= 0 && parafix2 >= 0) {
                        if (parafix1 < parafix2) {
                            tmp = tmp.substring(parafix1 + 1, tmp.length());
                        } else {
                            tmp = tmp.substring(parafix2 + 1, tmp.length());
                        }
                    } else if (parafix1 < 0 && parafix2 >= 0) {
                        tmp = tmp.substring(parafix2 + 1, tmp.length());
                    } else {
                        tmp = tmp.substring(parafix1 + 1, tmp.length());
                    }
                    j++;
                } catch (Exception ex) {
                    ex.getMessage();
                }
            }

            int count = 0;
            if (arrIndex.size() <= 2) {
                for (int i = 0; i < arrIndex.size(); i++) {
                    count++;

                    if (count == 1) {
                        srrSubName.add(s.substring(0, Integer.parseInt(arrIndex.get(i).toString())));
                        //srrSubName.add(s.substring(Integer.parseInt(arrIndex.get(i).toString()),Integer.parseInt(arrIndex.get(i).toString())+1));

                        if (i == arrIndex.size() - 1) {
                            srrSubName.add(s.substring(Integer.parseInt(arrIndex.get(i).toString()), Integer.parseInt(arrIndex.get(i).toString()) + 1));
                            srrSubName.add(s.substring(Integer.parseInt(arrIndex.get(i).toString()) + 1, s.length()));
                        }
                        continue;
                    }
                    srrSubName.add(s.substring(Integer.parseInt(arrIndex.get(i - 1).toString()), Integer.parseInt(arrIndex.get(i - 1).toString()) + 1));
                    srrSubName.add(s.substring(Integer.parseInt(arrIndex.get(i - 1).toString()) + 1, Integer.parseInt(arrIndex.get(i - 1).toString()) + 1 + (Integer.parseInt(arrIndex.get(i).toString()) - Integer.parseInt(arrIndex.get(i - 1).toString()) - 1)));

                    srrSubName.add(s.substring(Integer.parseInt(arrIndex.get(i).toString()), Integer.parseInt(arrIndex.get(i).toString()) + 1));
                    if (i == arrIndex.size() - 1) {
                        srrSubName.add(s.substring(Integer.parseInt(arrIndex.get(i).toString()) + 1, s.length()));
                    } else {
                        srrSubName.add(s.substring(Integer.parseInt(arrIndex.get(i).toString()) + 1, Integer.parseInt(arrIndex.get(i).toString()) + 1 + (Integer.parseInt(arrIndex.get(i + 1).toString()) - Integer.parseInt(arrIndex.get(i).toString()) - 1)));
                    }
                    //srrSubName.add(s.substring(Integer.parseInt(arrIndex.get(i).toString()),Integer.parseInt(arrIndex.get(i+1).toString())));

                }
                if (srrSubName.size() > 0) {
                    int lengh = 0;
                    for (int i = 0; i < srrSubName.size(); i++) {
                        if (inArray(arr, srrSubName.get(i).toString())) {
                            sUperCase += srrSubName.get(i).toString().toLowerCase();
                        } else {
                            sUperCase += srrSubName.get(i);
                            lengh = srrSubName.get(i).toString().length();

                        }
                        if (i > 0 && srrSubName.get(i).toString().equalsIgnoreCase("jun.") || i > 0 && srrSubName.get(i).toString().equalsIgnoreCase("sen.") ||
                                i > 0 && srrSubName.get(i).toString().equalsIgnoreCase("junior") || i > 0 && srrSubName.get(i).toString().equalsIgnoreCase("senior")) {
                            sUperCase = sUperCase.substring(0, sUperCase.length() - lengh);
                            sUperCase += srrSubName.get(i).toString().toLowerCase();
                        }
                    }
                } else //if (inArray(arr,s))
                {
                    sUperCase = s;
                }


            } else if (s.trim().indexOf(" ") != -1) {
                subS = s.split(" ");
                if (subS.length > 0) {
                    for (int i = 0; i < subS.length; i++) {
                        if (inArray(arr, subS[i].toString())) {
                            sUperCase += subS[i].toLowerCase() + " ";
                        } else {
                            sUperCase += subS[i] + " ";
                        }
                    }
                }
            } else if (s.trim().indexOf("-") != -1) {
                subS = s.split("-");
                if (subS.length > 0) {
                    for (int i = 0; i < subS.length; i++) {
                        if (inArray(arr, subS[i].toString())) {
                            sUperCase += subS[i].toLowerCase() + " ";
                        } else {
                            sUperCase += subS[i] + "-";
                        }
                    }
                    sUperCase = sUperCase.substring(0, sUperCase.length() - 1);
                }
            } else {
                return s;
            }
        }

        return sUperCase;
    }

    /**
     * Change case
     * @author hnmthu - add 4 case.
     * @param value: a String to change case
     * @param i: =0 is "no change", =1 is "uppercase the first letter", =2 is "Uppercase all",
     * 			 =3 is "lowercase all", =4 is "uppercase of word"
     * @return
     */
    public static String changeCase(String[] arr, String value, int i) {
        String tmp = value;
        if (i == 0) {
            return tmp;
        }

        if (value.trim().equalsIgnoreCase("")) {
            return "";
        } else {
            switch (i) {
                case 1:// Majuscule for first character. Ki tu dau tien cua String la ki tu hoa
                    tmp = String.valueOf(tmp.charAt(0)).toUpperCase() + tmp.substring(1);
                    break;
                case 2:// Majuscule for all characters.
                    tmp = tmp.toUpperCase();
                    break;
                case 3: // Mijuscule for all characters
                    tmp = tmp.toLowerCase();
                    break;
                case 4: // Majuscule before "-"; " " Ki tu hoa o moi tu
                    tmp = toMyUpcase(arr, value);
                    break;
                default:
                    break;
            }
        }
        return tmp;
    }

    public static boolean inString(String strMT, char c) {
        String temp = String.valueOf(c);
        if (strMT.indexOf(temp) >= 0) {
            return true;
        } else {
            return false;
        }
    }

//	Author: Nguyen Duc Tuan
//	doing: return a String after trim
//	Input: a string
//	Output: a trimed  string     
    public static String blanktonull(String value) {

        if (value == null || trimData(value).equalsIgnoreCase("")) {
            return null;
        } else {
            return "'" + value + "'";
        }
    }

    public static boolean checkstring(String strtemp, String instring) {
        if (strtemp == null) {
            return true;
        }
        char[] addedFigures = strtemp.toCharArray();
        char c;
        for (int i = addedFigures.length; i > 0; i--) {
            c = addedFigures[i - 1];
            if (!inString(instring, c)) {
                return false;
            }

        }

        return true;
    }

    /**
     * Author: Nguyen Duc Tuan
     * @param value
     * @param i: position where seperator of String happen
     * @return substring seperator after i ';'
     */
    public static String getdata_seperator(String value, int i, String seperator) throws Exception {
        String tmp = value.trim();
        int pos;
        try {
            for (int j = 1; j < i; j++) {
                pos = tmp.indexOf(seperator);
                tmp = tmp.substring(pos + 1);
            }
            pos = tmp.indexOf(seperator);
            if (pos == -1) {
                pos = tmp.length();
            }
            tmp = tmp.substring(0, pos);
        } catch (Exception ex) {
            throw ex;
        }
        return tmp;
    }

    public static String getdata_seperator(String value, boolean isSeperaAtFirst, String seperator) throws Exception {
        if (value != null && !value.equals("")) {
            String tmp = value.trim();
            int pos;
            try {
                if (isSeperaAtFirst) {
                    pos = tmp.indexOf(seperator);
                    if (pos == -1) {
                        pos = tmp.length();
                    }
                    tmp = tmp.substring(0, pos);
                } else {
                    pos = tmp.lastIndexOf(seperator);
                    tmp = tmp.substring(pos + 1, tmp.length());
                }
            } catch (Exception ex) {
                throw ex;
            }
            return tmp;
        } else {
            return "";
        }
    }

    public static int checkInt(String s) {
        if (s.equals("") || s.equalsIgnoreCase("null") || (s == null)) {
            return 0;
        } else {
            for (int j = 0; j < s.length(); j++) {
                if (s.charAt(j) < '0' || s.charAt(j) > '9') {
                    return 0;
                }
            }
            return Integer.parseInt(s);
        }
    }

    public static float checFloat(String s) {
        if (s.equals("") || s.equalsIgnoreCase("null") || (s == null)) {
            return 0;
        } else {
            return Float.parseFloat(s);
        }
    }

    public static long checkLong(String s) {
        if (s.equals("") || s.equalsIgnoreCase("null") || (s == null)) {
            return 0;
        } else {
            return Long.parseLong(s);
        }

    }

    public static boolean inUnion(String[] arr, String s) {
        for (int i = 0; i < arr.length; i++) {
            if (s.equalsIgnoreCase(arr[i])) {
                return true;
            }
        }
        return false;
    }

    /***************************************************************************
     * Check t is in the s string.
     **************************************************************************/
    public static boolean checkString(String s, String t) {
        if (s == null) {
            return true;
        }
        char[] addedFigures = s.toCharArray();
        char c;
        for (int i = addedFigures.length; i > 0; i--) {
            c = addedFigures[i - 1];
            if (!inString(t, c)) {
                return false;
            }

        }

        return true;
    }

    public static boolean hasNumber(String s) {
        for (int j = 0; j < s.length(); j++) {
            if (!Character.isDigit(s.charAt(j))) {
                return false;
            }
        }
        return true;
    }

    /**
     * Get current date with date format : f
     */
    public static String getCurrentDate(String f) {
        try {
            Date fDate = new Date();
            SimpleDateFormat dateformat = new SimpleDateFormat(f);
            return dateformat.format(fDate).toString();
        } catch (Exception ex) {
            return "";
        }
    }

    /***************************************************************************
     * Check string if whether it is in ar.
     */
    public static String inArray(String[][] ar, String s, int pos) {
        if (pos == 13) {
            pos = 1;
        }
        for (int i = 0; i <= ar.length - 1; i++) {
            if (ar[i][0].toString().equalsIgnoreCase(s)) {
                return ar[i][pos].toString().toLowerCase();
            }
        }
        return ar[0][pos].toString().toLowerCase();
    }

    public static boolean isDate(String date, String format) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat(format);
            dateFormat.setLenient(false);            
            return true;
        } catch (Exception e) {
            System.err.println(e);
            return false;
        }
    }   

    public static boolean isWindowOS() {
        if (System.getProperty("os.name").startsWith("Windows")) {
            return true;
        } else {
            return false;
        }
    }
    public static String getStackTrace(Exception ex) {
        String stackTrace = "";
        StringWriter in = new StringWriter();
        PrintWriter ps = new PrintWriter(in);
        // Write the stack trace to the string
        ex.printStackTrace(ps);

        // get the string
        StringBuffer output = in.getBuffer();
        stackTrace = output.toString();
        return stackTrace;
    }
    
    public static String getStackTrace(Throwable ex) {
        String stackTrace = "";
        StringWriter in = new StringWriter();
        PrintWriter ps = new PrintWriter(in);
        // Write the stack trace to the string
        ex.printStackTrace(ps);

        // get the string
        StringBuffer output = in.getBuffer();
        stackTrace = output.toString();
        return stackTrace;
    }

    /**
     * Set access right for folder or file
     * @param file or folder
     * @return
     * @throws java.io.IOException
     */
    public static boolean setFullPermition(String folder) {
        //Process p=null;
        boolean result = true;
        try {
            File file = new File(folder);
            result = file.setReadable(true, false);
            result = file.setWritable(true, false);
            result = file.setExecutable(true, false);
        } catch (Exception ex) {
            log.error(getStackTrace(ex));
            result = false;
        }
        return result;
    }

    public static String convert2YYYYMMDD(String sDate, String space) {
        try {
            if (sDate.length() == 8) {
                sDate = sDate.substring(4, 8) + space + sDate.substring(2, 4) + space + sDate.substring(0, 2);
            } else {
                sDate = "";
            }

        } catch (Exception ex) {
            return "";
        }
        return sDate;
    }
    
    //lpnlam added
	/**
	 * @todo copy srFile to destFile
	 * @param srFile
	 * @param destFile
	 */
	public static void copyFile(String srFile, String destFile) {
		try {
			File f1 = new File(srFile);
			File f2 = new File(destFile);
			InputStream in = new FileInputStream(f1);
			// For Overwrite the file.
			OutputStream out = new FileOutputStream(f2);

			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			in.close();
			out.close();
		} catch (FileNotFoundException ex) {
		} catch (IOException e) {
		}
	}

	/**
	 * convert input string into sql stament format
	 * @param value input string
	 * @return sql format string
	 */
	public static String convertStringToSqlFormat(String value) {
		try {
			if (value == null || value.equals("")) {
				return "";
			} else {
				String newValue = value.toLowerCase().trim();
				newValue = newValue.replaceAll("'", "''");

				log.debug(
						"\nvalue:" + value + "\nnew value:" + newValue);
				return newValue;
			}
		}catch (Exception e) {
			log.error("", e);
		}
		return "";
	}
	
	/**
	 * remove duplicate and empty substring. Ex:  removeDuplicateAndEmptySubString("a", "a,,") = "" 
	 * @param pattern: string to search for replace
	 * @param value: value need to replace
	 * @return: distinct string
	 */
	public static String removeDuplicateAndEmptySubString(String pattern, String value) {
		try {
			if (value == null || value.equals("")) {
				return "";
			} else {
				value = value.substring(value.indexOf(",") + 1);
				
				String tempValue = "";
				String[] arr = value.split(",");
				for(int i=0; i<arr.length; i++) {
					if(arr[i] != null && arr[i].trim().length() > 0) {
						tempValue += arr[i] + ",";
					}
				}
				
				if(tempValue != "") tempValue = tempValue.substring(0, tempValue.length() - 1); // remove last ',' character
				
				log.debug(
						"\nvalue:" + value + "\nnew value:" + tempValue);
				return tempValue;
			}
		}catch (Exception e) {
			log.error("", e);
		}
		return "";
	}
	
	public static String getValidChar(String value, String seperator)
			throws Exception {
		if (value != null && !value.equals("")) {
			String tmp = value.trim();
			int firstPos, lastPost;
			try {
				firstPos = tmp.indexOf(seperator);
				if (firstPos == -1) {
					firstPos = 0;
				}
				lastPost = tmp.lastIndexOf(seperator);
				if (lastPost == -1) {
					firstPos = value.length();
				}
				tmp = tmp.substring(firstPos + 1, lastPost);
			} catch (Exception ex) {
				throw ex;
			}
			return tmp;
		} else {
			return "";
		}
	}
	
	public static Date convertStringtoDate(String inputDate){
		Date result = null;
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			result = format.parse(inputDate);
		} catch (ParseException e) {
			log.error("", e);
		}
		
		return result;
	}
	public static String getCharShort(String tmpValue){
		String result="";
		String[] arrayValue = tmpValue.split(" ");
		try {
			for (String values:arrayValue) {
				if(values.length() > 3){
					values = values.substring(0,3);
				}
				result +=values +" ";
			}
			
		} catch (Exception e) {
			log.error("", e);
		}
		return result.trim();
	}

}
