package com.ghp.vae.data_entry.ptl.state;

import java.util.List;
import java.util.Map;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.bll.BLLViewData;
import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.ObjectInformation;
import com.ghp.vae.data_entry.ptl.UISearch;
import com.ghp.vae.data_entry.ptl.UISearchNomal;
import com.ghp.vae.search.service.impl.LookupServiceImpl;

import vae.client.transfer.LookupKey;

class SuggestState implements ReloadState {

	private static Logger log = LoggerFactory.getLogger(SuggestState.class);
	BLLViewData viewData;

	public SuggestState(BLLViewData viewData) {
		this.viewData = viewData;
	}

	@Override
	public void handleEvent(ObjectInformation information, MainFieldInterface main) {
		final int action = information.getAction();
		switch (action) {
		case SUGGESTION:
			this.openSuggest(information, main);
			main.resetState();
		}
		return;
	}

	private void openSuggest(ObjectInformation information, MainFieldInterface main) {
		final Object source = information.getSource();
		if (source == main.getComponent(MainFieldInterface.LOOKUP)) {
			// TODO
		}
		if (source == main.getComponent(MainFieldInterface.FIRMA)) {
			this.getLookup((JTextField) main.getComponent(MainFieldInterface.FIRMA),
					(JComponent) main.getComponent(MainFieldInterface.FIRMA), main);
		}
		if (source == main.getComponent(MainFieldInterface.VORNAME)) {
			this.getLookup((JTextField) main.getComponent(MainFieldInterface.VORNAME),
					(JComponent) main.getComponent(MainFieldInterface.NAME), main);
		}
		if (source == main.getComponent(MainFieldInterface.NAME)) {
			this.getLookup((JTextField) main.getComponent(MainFieldInterface.NAME),
					(JComponent) main.getComponent(MainFieldInterface.PLZ), main);
		}
		if (source == main.getComponent(MainFieldInterface.PLZ)) {
			this.getLookup((JTextField) main.getComponent(MainFieldInterface.PLZ),
					(JComponent) main.getComponent(MainFieldInterface.ORT), main);
		}
		if (source == main.getComponent(MainFieldInterface.ORT)) {
			this.getLookup((JTextField) main.getComponent(MainFieldInterface.ORT),
					(JComponent) main.getComponent(MainFieldInterface.STRASSE), main);
		}
		if (source == main.getComponent(MainFieldInterface.STRASSE)) {
			this.getLookup((JTextField) main.getComponent(MainFieldInterface.STRASSE), null, main);
		}
		main.resetState();
	}

	// private boolean getLookupCombineUI(JTextField jtf,
	// JComponent nextFocusComp, MainFieldInterface main) {
	// try {
	// String fieldNameLike = jtf.getText();
	// String fieldName = Utilities.ignoreNull(jtf.getName());
	// LookupKey title = LookupKey.fromKey(fieldName);
	// if ("".equalsIgnoreCase(fieldNameLike)) {
	// AroundDialog.showMessageDialog(null,
	// "You must type character to search", "Canh bao",
	// JOptionPane.WARNING_MESSAGE);
	// return false;
	// }
	// List<Map<String, String>> arrValues = viewData.getLookup(fieldName, fieldNameLike);
	//
	// if (arrValues != null && arrValues.size() > 0) {
	// UISearchNomal search = UISearchNomal.intance((JFrame) main
	// .getComponent(MainFieldInterface.FRAME_VIEW));
	// search.clearData();
	// search.setParentMainFace(main);
	// search.setSearchType(UISearch.searchOther);
	// search.setDataResult(arrValues);
	// search.setTitle(new LookupKey[] { title });
	// search.setCurrentJtf(jtf);
	// search.setNextFocus(nextFocusComp);
	// search.viewResult();
	//
	// } else {
	// AroundDialog.showMessageDialog(null,
	// "Khong co ket qua nao duoc tim thay", "Thong tin",
	// JOptionPane.INFORMATION_MESSAGE);
	// }
	// return true;
	// } catch (Exception ex) {
	// log.error("", ex);
	// return false;
	// }
	// }

	private void getLookup(JTextField jtf, JComponent nextFocusComp, MainFieldInterface main) {
		final String fieldNameLike = jtf.getText();
		final String fieldName = Utilities.ignoreNull(jtf.getName());
		if (!"".equals(fieldNameLike) && !"".equals(fieldName)) {
			if ("strasse".equalsIgnoreCase(fieldName))// if is search strasse
			{
				final List<Map<String, String>> arrValues = this.viewData.getLookupStrasse(jtf.getText(),
						main.getFieldValue(MainFieldInterface.ORT), main.getFieldValue(MainFieldInterface.PLZ));
				final LookupKey titles[] = new LookupKey[] { LookupKey.SUGGEST_STRASSE, LookupKey.SUGGEST_ORT,
						LookupKey.SUGGEST_PLZ };
				this.openSuggestForm(fieldName, arrValues, UISearch.searchStrasse, titles, jtf, nextFocusComp, main);

			} else if ("ort".equalsIgnoreCase(fieldName))// if is search ort
			{
				final List<Map<String, String>> arrValues = this.viewData.getLookupOrt(jtf.getText(),
						main.getFieldValue(MainFieldInterface.PLZ));
				final LookupKey titles[] = new LookupKey[] { LookupKey.SUGGEST_ORT, LookupKey.SUGGEST_PLZ };
				this.openSuggestForm(fieldName, arrValues, UISearch.searchOrt, titles, jtf, nextFocusComp, main);
			} else if ("plz".equalsIgnoreCase(fieldName))// if is search plz
			{
				final List<Map<String, String>> arrValues = this.viewData.getLookupPlz(jtf.getText());
				final LookupKey titles[] = new LookupKey[] { LookupKey.SUGGEST_PLZ, LookupKey.SUGGEST_ORT };
				this.openSuggestForm(fieldName, arrValues, UISearch.searchPlz, titles, jtf, nextFocusComp, main);
			} else {
				// BINHTV: Modify search elastic
				String lookupKey = LookupServiceImpl.SEARCHMORE_KEYS.get(fieldName);
				final String indexType = LookupServiceImpl.INDEX_TYPES.get(fieldName);
				if (lookupKey == null) {
					lookupKey = fieldName;
				}
				final List<Map<String, String>> arrValues = this.viewData.getSuggestion(indexType, lookupKey,
						fieldNameLike);
				this.openSuggestForm(fieldName, arrValues, UISearch.searchOther,
						new LookupKey[] { LookupKey.fromKey(lookupKey) }, jtf, nextFocusComp, main);
			}
		} else {
			AroundDialog.showMessageDialog(null, "Ban phai nhap gia tri de tim kiem!", "Canh bao",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	private void openSuggestForm(String fieldName, List<Map<String, String>> arrValues, int typeSuggest,
			LookupKey[] titles, JTextField jtf, JComponent nextFocusComp, MainFieldInterface main) {
		if (arrValues != null && arrValues.size() > 0) {
			log.debug("Lookup " + fieldName + " thanh cong");
			final UISearchNomal search = UISearchNomal
					.intance((JFrame) main.getComponent(MainFieldInterface.FRAME_VIEW));
			search.clearData();
			search.setParentMainFace(main);
			search.setSearchType(typeSuggest);
			search.setDataResult(arrValues);
			search.setTitle(titles);
			search.setCurrentJtf(jtf);
			search.setNextFocus(nextFocusComp);
			try {
				search.viewResult();
			} catch (final Exception ex) {
				log.error("", ex);
			}
		} else {
			log.debug("Lookup " + fieldName + " khong thanh cong");
			AroundDialog.showMessageDialog(null, "Khong co ket qua nao duoc tim thay", "Thong tin",
					JOptionPane.INFORMATION_MESSAGE);
		}
	}

	@Override
	public void reloadStatus() {
	}

}
