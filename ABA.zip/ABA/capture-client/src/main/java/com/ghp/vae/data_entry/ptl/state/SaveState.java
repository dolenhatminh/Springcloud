package com.ghp.vae.data_entry.ptl.state;

import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingWorker;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.bll.BLLAddressField;
import com.ghp.vae.data_entry.bll.BLLCard;
import com.ghp.vae.data_entry.bll.BLLDataStructure;
import com.ghp.vae.data_entry.bll.BLLSaveCard;
import com.ghp.vae.data_entry.bll.BLLoadCard;
import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.entity.Card;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.ObjectInformation;
import com.ghp.vae.data_entry.ptl.ProgressBarLoadCard;
import com.ghp.vae.data_entry.ptl.autocomplete.CustomTextField;
import com.sps.vn.config.ApplicationConfig;
import com.sps.vn.writing.datasource.WritingBaseDAL;

import vae.client.transfer.LookupKey;
import vae_ocr.OCR.OCRProcessing;

/**
 * this function handle event save card change state to Load card or pauseCard.
 *
 * @author vmhoang
 *
 */

class SaveState implements ReloadState {

	private static Logger log = LoggerFactory.getLogger("SAVE CARD");
	private final BLLSaveCard saveCard;
	private final BLLoadCard loadCard;
	private boolean exit = false;
	private final OCRProcessing ocr;
	private ReloadState nextStatus;
	private ObjectInformation information;
	private final LoadCardState loadCardState;
	private final PauseState pauseState;

	public SaveState(BLLSaveCard saveCard, BLLoadCard loadCard, String[] changeCase, OCRProcessing ocr,
			LoadCardState loadCardState, PauseState pauseState) {

		this.saveCard = saveCard;
		this.loadCard = loadCard;
		this.ocr = ocr;
		this.loadCardState = loadCardState;
		this.pauseState = pauseState;
	}

	@Override
	public void reloadStatus() {
		this.exit = false;
		this.nextStatus = null;
		this.information = null;
	}

	/**
	 * handleEvent action SAVE_PAUSE, SAVE_LOAD_CARD, EXIT
	 *
	 * @note EXIT open jdialog
	 */
	@Override
	public void handleEvent(ObjectInformation information, MainFieldInterface main) {
		final byte action = information.getAction();
		switch (action) {
		case SAVE_PAUSE:
			this.openSaveCardPause(information, main);
			break;
		case SAVE_LOAD_CARD:
			this.openSaveCardLoad(information, main);
			break;
		case EXIT:
			this.openPopupCannotNotExit("Dang save card");
			break;

		}
	}

	private void openPopupCannotNotExit(String message) {
		if (this.exit) {
			final WritingBaseDAL baseDAL = new WritingBaseDAL();
			baseDAL.releaseALLConnection();
			System.exit(0);
		} else {
			AroundDialog.showMessageDialog(null, message, "Canh bao", JOptionPane.WARNING_MESSAGE);
		}
	}

	/**
	 * saveCard and change Pause Status when successful or resetStatus when fails. resetGui of MainFieldInterface
	 *
	 * @param information
	 * @param main
	 */
	private void openSaveCardPause(ObjectInformation information, MainFieldInterface main) {
		log.info("[SaveState][openSaveCardPause]-[COLLECTION:" + main.getEntity().getCard().getManagementID()
				+ "][SAVE]-start save");
		this.nextStatus = this.pauseState;// new PauseState(loadCard);
		this.nextStatus.reloadStatus();
		this.information = information;
		this.information.setAction(PAUSE);
		this.saveCardAndNextStep(main);
	}

	private void saveCardAndNextStep(final MainFieldInterface main) {
		log.info("[SaveState][saveCardAndNextStep]-[COLLECTION:" + main.getEntity().getCard().getManagementID()
				+ "][SAVE]-start save");
		final ExtendSwingWorker worker = new ExtendSwingWorker(main);
		worker.execute();
		this.updateStatusCard(main, "Xu ly Card");
	}

	// change for function done in swingworker.

	/**
	 * function is same with {@link #openSaveCardPause(ObjectInformation, MainFieldInterface)}. <br/>
	 * different change status to LoadCard.
	 *
	 * @param information
	 * @param main
	 */
	private void openSaveCardLoad(ObjectInformation information, MainFieldInterface main) {
		log.info("[SaveState][openSaveCardLoad]-[COLLECTION:" + main.getEntity().getCard().getManagementID()
				+ "][SAVE]-start save");
		this.nextStatus = this.loadCardState; // new LoadCardState(loadCard);
		this.nextStatus.reloadStatus();
		this.information = information;
		this.information.setSource(this.loadCard);
		this.information.setAction(LOAD_CARD);
		this.saveCardAndNextStep(main);

	}

	/**
	 * save Card: update status for Entity card into MainFieldInterface and send status for BLLLoadCard <br/>
	 *
	 * @param main
	 * @param information
	 * @return boolean save ok or not ok
	 */

	private boolean saveCard(MainFieldInterface main, ObjectInformation information) {
		final String badCard = ((JComboBox) main.getComponent(MainFieldInterface.BADREASON)).getSelectedItem()
				.toString();
		
		/** If Card is Bad Card, app will keep checking Firmen-PLZ condition
		 *  Firmen_PLZ has higher Priority than Bad Image
		 */
		boolean isFirmenPlz = false;
		Component plzComp = main.getComponent(MainFieldInterface.PLZ);
		Component ortComp = main.getComponent(MainFieldInterface.ORT);
		String plz = ((JTextField) plzComp).getText().trim();
		String ort = ((JTextField) ortComp).getText().trim();
		
		/**	check Constraint and then display warning message dialog.*/
		boolean answer = false;
		answer = this.checkSaveConstraint(main);
		
		/** Condition Firmen-Plz:   
		 *  PLZ is NOT Empty && TYP=40 && (LogTYP= 0 || 1)
		 */
		if (!plz.equals("") && !ort.equals("")) {
			if (answer) {
				isFirmenPlz = this.saveCard.saveFirmenPLZ(plz, ort, main);
			} else {
				return false;
			}
		}
		
		/**	Switch Firmen-plz case and Normal case	 */
		if (isFirmenPlz) {
			log.info("[Capture]-[COLLECTION:"
					+ main.getEntity().getCard().getManagementID()
					+ "][SAVE FIRMEN-PLZ]");
			return isFirmenPlz;
		} else {
			final Card card = main.getEntity();
			if (this.isSaveCard(main)) {
			} else {
				log.info("[Capture]-[COLLECTION:"
						+ main.getEntity().getCard().getManagementID()
						+ "][SAVE]-not save");
				return false;
			}
			if (answer) {
				main.learn();
				// Hoang move to save card.
				// updateTypeValueData(main);
				if (!badCard.equals("")) {
					card.getCard().setBadCard(true);
					card.getCard().setBaditem(badCard);
					card.getCard().setReasonBad(main.getBadRepondcode(badCard));
				}
				try {
					this.putFieldIntoCard(card.getFieldValue(), main);
					this.updateParamAddressSpecial(main);// update for param
					card.setMyPost24(!main
							.getFieldValue(MainFieldInterface.MYPOST24).trim()
							.equals(""));

					// ### Helpdesk - Request ID : 5641
					if (card.getVectorKDP() != null) {
						final String kdpId = card.getVectorKDP().get(
								LookupKey.KDP_ID.getKey());

						try {
							log.info(String
									.format("[STATISTIC] :: Col-ID [%s] - KDP ID [%s] - PickPost [%s] - PostFach [%s] - Strasse [%s]",
											(card != null ? card.getCard()
													.getCollectionID() : ""),
											kdpId, card.getValuePickPost(),
											card.getValuePostFach(), card
													.getValueStrasse()));
						} catch (final Exception e) {
							log.warn("", e);
						}

						/**
						 * Request ID : 5641 [VAE]alarm_message
						 */

						/**
						 * Issue #11573: The message is only display when kdp_id
						 * is exactly the same with kdp_ids from configuration
						 */
						boolean isContainAlarmKdp = false;
						isContainAlarmKdp = Arrays.asList(
								ApplicationConfig.getInstance()
										.getBusinessConfig().getAlarmKDPID()
										.split(",")).contains(kdpId);

						if ((kdpId != null) && !kdpId.equalsIgnoreCase("0")
								&& isContainAlarmKdp) {
							final int accept = AroundDialog
									.showConfirmDialog(
											null,
											"Vui long kiem tra lai ten tren hinh co dung voi Ket qua muon lay khong",
											"Xac nhan",
											JOptionPane.YES_NO_OPTION,
											JOptionPane.WARNING_MESSAGE);

							/**
							 * Bug #8806 Should not save card when user click
							 * "x" button at warning message >>> Fix Error ::
							 * Show dialog and click ESC -> save a collection
							 */
							if (accept == JOptionPane.YES_OPTION) {
								// continue to save a collection
							} else {
								return false;
							}
						}
					}

					return this.saveCard.saveCard(card);
				} catch (final Exception e) {

					AroundDialog
							.showMessageDialog(
									null,
									"khong the xuat du lieu. Yeu cau ban thong bao voi quan li ngay",
									"Warning", JOptionPane.ERROR_MESSAGE);
					log.error(Utilities.getStackTrace(e));
					this.exit = true;
					main.doExit(true);
					return false;
				}
			} else {
				log.info("[Capture]-[COLLECTION:"
						+ main.getEntity().getCard().getManagementID()
						+ "][SAVE]-not save");
				return false;
			}
		}
	}

	/**
	 * update status card is procces
	 *
	 * @param main
	 */
	private void updateStatusCard(final MainFieldInterface main, final String status) {
		main.setStatusCard(status);
		main.setProcessLoadCard(true);
	}

	/**
	 * function check data is postfact, pickpost, postlagend save card : need has some field or bad card.
	 *
	 * @param main
	 * @return
	 */

	private boolean checkSaveConstraint(MainFieldInterface main) {
		final Card card = main.getEntity();
		final boolean contraint = this.viewMessage(main);
		if (contraint) {
			if (StringUtils.isNotEmpty(main.getFieldValue(MainFieldInterface.POSTFACH).trim())) {
				card.getCard().setPostfachAddress(true);
			} else {
				card.getCard().setPostfachAddress(false);
			}
			if (StringUtils.isNotEmpty(main.getFieldValue(MainFieldInterface.PICKPOST).trim())) {
				card.getCard().setPickpockAddress(true);
			} else {
				card.getCard().setPickpockAddress(false);
			}
			if (StringUtils.isNotEmpty(main.getFieldValue(MainFieldInterface.POSTLAGEND).trim())) {
				card.getCard().setPostLagenAddress(true);
			} else {
				card.getCard().setPostLagenAddress(false);
			}
		}
		return contraint;
	}

	/**
	 * update data for POSTFACH, PICKPOST, STRASSE.
	 *
	 * @param main
	 */
	private void updateParamAddressSpecial(MainFieldInterface main) {
		final Card card = main.getEntity();
		card.setValuePostFach(main.getFieldValue(MainFieldInterface.POSTFACH).trim());
		card.setValuePickPost(main.getFieldValue(MainFieldInterface.PICKPOST).trim()
				+ main.getFieldValue(MainFieldInterface.MYPOST24).trim());
		card.setValueStrasse(main.getFieldValue(MainFieldInterface.STRASSE).trim());
	}

	/**
	 * view Message confirm ok or not ok.
	 *
	 * @param main
	 * @return
	 */

	private boolean viewMessage(MainFieldInterface main) {
		final BLLCard entry = main.getEntity().getCard();
		int answer = JOptionPane.YES_OPTION;
		String message;
		if (!main.getFieldValue(MainFieldInterface.BADREASON).equals("")) {
			final String selectedReason = main.getFieldValue(MainFieldInterface.BADREASON);
			message = "Ban co muon chon li do \"" + selectedReason.substring(selectedReason.indexOf('.') + 2)
					+ " \" khong?";
			answer = AroundDialog.showConfirmDialog(null, message, "Xac nhan", JOptionPane.YES_NO_OPTION,
					JOptionPane.WARNING_MESSAGE);
		} else {
			final String plz = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.PLZ));
			final String ort = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.ORT));
			final String strasse = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.STRASSE));
			final String hausnumber = Utilities.ignoreNull(main.getFieldValue(MainFieldInterface.HAUSE));
			int emptyField = 0; // check many field error.
			if (plz.equals("")) {
				emptyField++;
			}
			if (ort.equals("")) {
				emptyField++;
			}
			if (strasse.equals("")) {
				emptyField++;
			}
			if (hausnumber.equals("")) {
				emptyField++;
			}

			final String houseNummerTyped = ((BLLAddressField) entry.getField(BLLDataStructure.HAUSNUMMER_FIELD))
					.getTyped();
			final String housezusatTyped = ((BLLAddressField) entry.getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD))
					.getTyped();
			final String houseNummerValue = entry.getField(BLLDataStructure.HAUSNUMMER_FIELD).getValue();
			final String housezusatValue = entry.getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD).getValue();
			final boolean plzCheck = plz.matches("\\d{4}") || plz.equals("");
			// Hoang ort khong chua % ort chua word + so + any
			final boolean ortCheck = (!ort.matches(".*%.*") && ort.matches("\\D+|\\D+\\d+.*")) || ort.equals("");
			if (!plzCheck) {
				AroundDialog.showMessageDialog(null, "PLZ khong hop le", "Canh bao", JOptionPane.WARNING_MESSAGE);
				return false;
			}
			if (!ortCheck) {
				AroundDialog.showMessageDialog(null, "ORT khong hop le", "Canh bao", JOptionPane.WARNING_MESSAGE);
				return false;
			}
			if ((houseNummerTyped != null) && (houseNummerTyped.length() > 10)) {
				AroundDialog.showMessageDialog(null, "So nha khong hop le", "Canh bao", JOptionPane.WARNING_MESSAGE);
				return false;
			}
			if ((housezusatTyped != null) && (housezusatTyped.length() > 10)) {
				return false;
			}
			if ((houseNummerValue != null) && (houseNummerValue.length() > 10)) {
				AroundDialog.showMessageDialog(null, "So nha khong hop le", "Canh bao", JOptionPane.WARNING_MESSAGE);
				return false;
			}
			if ((housezusatValue != null) && (housezusatValue.length() > 10)) {
				AroundDialog.showMessageDialog(null, "So nha khong hop le", "Canh bao", JOptionPane.WARNING_MESSAGE);
				return false;
			}
			if (emptyField > 2) {
				AroundDialog.showMessageDialog(null, "Ban da nhap thieu/sai thong tin dia chi, vui long kiem tra lai.",
						"Warning", JOptionPane.WARNING_MESSAGE);
				return false;
			}

			/**
			 * Bug #9014 Card is saved although this case can't be saved when user pres Ctrl + Space
			 */
			if (StringUtils.isBlank(main.getFieldValue(MainFieldInterface.FIRMA))
					&& StringUtils.isBlank(main.getFieldValue(MainFieldInterface.NAME))
					&& StringUtils.isBlank(main.getFieldValue(MainFieldInterface.VORNAME))) {
				answer = this.messageDialogForcusNoButton(null,
						"Khong co mot trong cac thong tin sau: " + "Firmename, Name, Vorname \nBan co muon luu khong",
						"Xac nhan");
			}
		}
		return answer == JOptionPane.YES_OPTION;
	}

	private int messageDialogForcusNoButton(Component comp, String message, String title) {
		final int option = JOptionPane.showOptionDialog(comp, message, title, JOptionPane.YES_NO_OPTION,
				JOptionPane.WARNING_MESSAGE, null, new Object[] { "Yes", "No" }, "No");
		return option;
	}

	/**
	 * check capture can save or not save : field save button enable and bad reason has data
	 *
	 * @param main
	 * @return
	 */
	private boolean isSaveCard(MainFieldInterface main) {
		final String reason = main.getFieldValue(MainFieldInterface.BADREASON);
		final boolean enableSave = main.getComponent(MainFieldInterface.SAVE_BUTTON).isEnabled();
		return enableSave || ((reason != null) && reason.equals(""));
	}

	private void putFieldIntoCard(Map<String, String> fieldValue, MainFieldInterface main) {
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.BADREASON);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.LOOKUP);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.FIRMA);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.ZUSAT);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.ANREDE);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.VORNAME);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.NAME);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.PLZ);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.ORT);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.STRASSE);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.HAUSE);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.LAND);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.POSTFACH);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.STOCKWERK);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.ADRESSZUSAT);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.COADDRESS);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.PICKPOST);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.POSTLAGEND);
		this.putFieldIntoCard(fieldValue, main, MainFieldInterface.MYPOST24);
	}
	
	/**
	 * add function for clear undo data.
	 *
	 * @param fieldValue
	 * @param main
	 * @param field
	 */
	private void putFieldIntoCard(Map<String, String> fieldValue, MainFieldInterface main, byte field) {
		final Component comp = main.getComponent(field);
		final String fieldName = comp.getName();
		if (comp instanceof JTextField) {
			final String value = ((JTextField) comp).getText().trim();
			fieldValue.put(fieldName, value);
			if (comp instanceof CustomTextField) {
				((CustomTextField) comp).setUndoData("");
			}

		}
		if (comp instanceof JComboBox) {
			final String value = ((JTextField) ((JComboBox) comp).getEditor().getEditorComponent()).getText();
			fieldValue.put(fieldName, value);
		}
	}

	private void resetData(Card card) {
		card.clearValue();
	}

	private class ExtendSwingWorker extends SwingWorker<Boolean, String> {
		private final MainFieldInterface main;
		private final String prReallyDone = "SAVE_STATE_DONE";

		private ExtendSwingWorker(MainFieldInterface main) {
			this.main = main;
			this.getPropertyChangeSupport().addPropertyChangeListener(this.prReallyDone, new PropertyChangeListener() {
				@Override
				public void propertyChange(PropertyChangeEvent evt) {
					log.debug("run in property change :" + evt.getNewValue());
					if (evt.getNewValue().equals(true)) {
						ExtendSwingWorker.this.whenReallyDone(true);
					} else {
						ExtendSwingWorker.this.whenReallyDone(false);
					}
				}
			});
			this.addPropertyChangeListener(new PropertyChangeListener() {

				@Override
				public void propertyChange(PropertyChangeEvent evt) {
					log.info("[SwingWorker] evt :: " + evt.getNewValue());

				}
			});

		}

		@Override
		protected Boolean doInBackground() throws Exception {
			boolean value = false;
			try {

				Thread.sleep(50);
				if (!SaveState.this.saveCard(this.main, SaveState.this.information)) {
					this.main.resetState();
					value = false;
					return false;
				}
			
				log.info("[SaveState] Print :: Tra card ve !!!");
				this.publish(" TRA CARD VE !!! ");
				SaveState.this.saveCard.processSaveCard(this.main.getEntity());

				value = true;
				return true;
			} catch (final Exception ex) {
				value = false;
				log.error("Save card error", ex);
				return false;
			} finally {
				log.debug("fire event property change");
				this.firePropertyChange(this.prReallyDone, !value, value);
			}
		}

		@Override
		protected void process(List<String> chunks) {
			log.info("[SaveState] Display :: Tra card ve !!!");
			((ProgressBarLoadCard) this.main.getComponent((byte) 27))
					.setStr(chunks.get(0) + ". Dung tat chuong trinh!!!");
		}

		private void whenReallyDone(boolean isSave) {
			if (isSave) {
				if (SaveState.this.nextStatus instanceof PauseState) {
					SaveState.this.information.setAction(PAUSE);
					this.main.setProcessLoadCard(false);
				} else {
					SaveState.this.information.setAction(LOAD_CARD);
				}
				if (SaveState.this.ocr != null) {
					SaveState.this.ocr.resetOCRData();
				}
				SaveState.this.resetData(this.main.getEntity());
				log.debug("after getEntity");
				this.main.changeState(SaveState.this.nextStatus);
				log.debug("after request:" + SaveState.this.nextStatus.getClass().getName() + " , information:"
						+ SaveState.this.information.getAction());

				this.main.request(SaveState.this.information, this.main);
			} else {
				this.main.setProcessLoadCard(false);
			}
		}

	}
}
