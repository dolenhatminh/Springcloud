package com.ghp.vae.data_entry.bll;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.entity.Card;
import com.ghp.vae.data_entry.entity.HauskeyAddress;
import com.ghp.vae.data_entry.entity.UserName;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.SaveCardInterface;
import com.sps.vn.config.ApplicationConfig;
import com.sps.vn.lookup.datasource.DALSaveCard;
import com.sps.vn.utilities.StringUtil;

import vae.bb.core.hibernate.model.Collection;
import vae.client.bao.BAOJmsConnection;
import vae.client.transfer.ITransferService;
import vae.client.transfer.LookupKey;

// import com.ghp.vae.data_entry.face.ValidateCardInterface;
public class BLLSaveCard implements SaveCardInterface {

    private static Logger log = LoggerFactory.getLogger(BLLSaveCard.class);
    private final DALSaveCard dal;
    private final UserName user;
    private String reasonBad;
    // private BAOJmsOperator jmsSender;
    private String changeCase[];
    // private ValidateCardInterface validate;
    private MainFieldInterface mainField;
    private final int INPUTSTEP = 1;
	private final String anredeid1[] = new String[] { "Herr", "Hr.", "Monsieur", "M.", "Signore", "Monsignore",
			"Signor.", "Sig.", "Signur", "Sigr.", "Sar.,Mr." };
    // list of anrede which anredeid = 2
	private final String anredeid2[] = new String[] { "Frau", "Fr.", "Fräulein", "Frl.", "Madame", "Mme",
			"Mademaiselle", "Mle", "Signora", "Signorina", "Dounna", "Giunfra", "Mrs.", "Miss." };
    private long startTime;
    private int cardAmount = 0;
    // private BAOJmsConnection jmsConnection;
    private ITransferService transferService;

    private static String FIRMENAME = "firmenname";
    private static String NAMEZUSAT = "namenszusatz";
    private static String ANREDE = "anrede";
    private static String VORNAME = "vorname";
    private static String NAME = "name";
    private static String PLZ = "plz";
    private static String ORT = "ort";
    private static String STRASSE = "strasse";
    private static String HAUSNUMER = "hausnummer";
    private static String LAND = "land";
    private static String POSTFACH = "postfachnummer";
    private static String STOCKWERK = "stockwerk";
    private static String ADRESSZUSATZ = "adresszusatz";
    private static String COADRESS = "co_addresse";
    private static String PICKPOST = "pickpostnummer";
    private static String POSTLAGEND = "postlagend";
    private static final String resultS = "result";
    private static final String addressID = "addressId";
    private static final String hauskey = "hauskey";
    // list of caserner sign.
    private List<String> signCaserne;
    private String CaptureUser;

    public BLLSaveCard(UserName user) throws SQLException {
        this.dal = new DALSaveCard();
        this.user = user;
        this.init();
        this.initConnectionProxy();

    }

    private void initConnectionProxy() {
        try {
            this.transferService = BAOJmsConnection.createTransferService(this.user.getUserId(), this.user.getLevel(),
                    this.user.getUserName());
        } catch (final Exception ex) {
            log.error("", ex);
        }
    }

    private void init() {
        // try {
        // validate = new BLLValidateCard();
        // } catch (Exception ex) {
        // validate = null;
        // } catch (NoClassDefFoundError error) {
        // validate = null;
        // }
        this.startTime = new Date().getTime();
        try {
            this.CaptureUser = InetAddress.getLocalHost().getHostName();
        } catch (final UnknownHostException e) {
            this.CaptureUser = "Unknown";
            log.error("", e);
        }

        final String casernes = ApplicationConfig.getInstance().getBusinessConfig().getSignArmy();
        this.signCaserne = new ArrayList<String>();
        final String caser[] = casernes.split(",");
        for (final String sign : caser) {
            this.signCaserne.add(sign);
        }
    }

    @Override
    public boolean checkValidServer() {
        return true;
    }

    /**
     *
	 * saveCard: update type /value on bllFile use zubofi special respose code/addresstype.. check validate card. view
	 * time
     */
    @Override
    public boolean saveCard(Card card) throws Exception {
        card.getCard().setCheckZubofiSpecical(this.checkAddressSpecial(card));
        this.updateTypeValueData(card);
        this.reCalculateTypedAndValue(card);
        // if (validate != null) {
        // if (validate.checkValidate(card)) {
        // return false;
        // }
        // }
        this.doExport(card);
        this.cardAmount++;
        this.showCardAmount(card.getTimeGetCard(), card.getCard().getEndTime().getTime());
        log.info("[BLLSaveCard][saveCard]-[COLLECTION:" + card.getCard().getManagementID() + "]-[END]");

        if (this.getErrorAmount() > 0) {
            throw new Exception("cannot export card");
        }
        return true;
    }

    // update data, value data for with address from kdp
    private void updateTypeValueData(Card card) {
        final Map<String, String> vectorKDP = card.getVectorKDP();
        if (vectorKDP == null) {
            return;
        }
        if (card.getCard().isCheckZubofiSpecial()) {
            this.updateTypeValueForZubofiSpecial(card);
        } else if (card.isMyPost24()) {
            this.updateTypeValueForMyPost24(card);
        } else {
            this.updateTypeValueForDomizilAddress(card);
        }
    }

    // special address : postfach only get imformation person(name, vorname, firmaname ,kdp special ....).
    private void updateTypeValueForZubofiSpecial(Card card) {
        final int type = card.getCard().getTypeZubofiSpecical();
        if (((type == 2) || (type == 4))) { // pickpost address.
            this.updateTypeValueForPickpost(card);
        } else if ((type == 3)) { // kaserner address
            this.updateTypeValueForKaserne(card);
        } else { // postfach address.
            this.updateTypeValueForPostfach(card);
        }
    }

    // postfach address get inforamtion from vgdl.
    private void updateTypeValueForPostfach(Card card) {
        final Map<String, BLLField> fields = card.getCard().getFieldList();
        final Map<String, String> vectorKDP = card.getVectorKDP();
        final Set<String> keys = fields.keySet();
        for (final String keyWorks : keys) {
            if (keyWorks.equals(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD)
                    || keyWorks.equals(BLLDataStructure.PARCEL_HAUSKEY)
                    || keyWorks.equals(BLLDataStructure.STRASSE_FIELD) || keyWorks.equals(BLLDataStructure.PLZ_FIELD)
                    || keyWorks.equals(BLLDataStructure.ORT_FIELD)
                    || keyWorks.equals(BLLDataStructure.HAUSNUMMER_FIELD)) {
                continue;
            }

            if (keyWorks.equals(BLLDataStructure.KDPID_FIELD)) {
                final String value = this.getDataInKDP(keyWorks, card.getCard().isKdpSpecial(), vectorKDP);
                final BLLField field = card.getCard().getField(keyWorks);
                field.setValue(value);
                // Hoang chi su ly voi truong hop lay tu kdp special.
                // if(card.getCard().isKdpSpecial()){
                // field = card.getCard().getField(BLLDataStructure.HAUSKEY);
                // try{
                // Long kdpid = Long.parseLong(value);
                // Long hausKey = dal.getHauskeyFromKdpid(kdpid);
                // field.setValue(""+hauskey);
                // }catch(Exception ex){
                // field.setValue("");
                // }
                // }
                continue;
            }

            String value = this.getDataInKDP(keyWorks, card.getCard().isKdpSpecial(), vectorKDP);
            if (value == null) {
                continue;
            }
            try {
                value = this.checkContraint(keyWorks, value, card);
            } catch (final Exception ex) {
                log.error("", ex);
            }

            final BLLField field = card.getCard().getField(keyWorks);

            if (keyWorks.equals(BLLDataStructure.HAUSNUMMER_FIELD)) {
                final String[] tmp = this.spilitHauseNum(value);
                final BLLField hauzusatField = card.getCard().getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD);
                field.setValue(tmp[0]);
                hauzusatField.setValue(tmp[1]);
                continue;
            }

            if (keyWorks.equalsIgnoreCase(BLLDataStructure.LAND_FIELD)) {
                field.setValue(value);
                continue;
            }
            field.setValue(value);
        }
        final String kdp_type = this.getDataInKDP("kdp_type", card.getCard().isKdpSpecial(), vectorKDP);
        int kdptype = 0;
        // pvgiang_1 -14/07/2016- TYPE 'P' is person, 'O' is company
        if (kdp_type.toUpperCase().equalsIgnoreCase("P")) {
            kdptype = 1;
        } else {
            kdptype = 2;
        }
        // try {
        // kdptype = Integer.parseInt(kdp_type);
        // } catch (final Exception ex) {
        //
        // }
        card.setKdpType(kdptype);
    }

    // kaserne not update hause key
    private void updateTypeValueForKaserne(Card card) {
        final Map<String, BLLField> fields = card.getCard().getFieldList();
        final Map<String, String> vectorKDP = card.getVectorKDP();
        final Set<String> keys = fields.keySet();
        for (final String keyWorks : keys) {
            if (keyWorks.equals(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD)
                    || keyWorks.equals(BLLDataStructure.PARCEL_HAUSKEY) || keyWorks.equals(BLLDataStructure.HAUSKEY)) {
                continue;
            }
            String value = this.getDataInKDP(keyWorks, card.getCard().isKdpSpecial(), vectorKDP);
            if (value == null) {
                continue;
            }
            try {
                value = this.checkContraint(keyWorks, value, card);
            } catch (final Exception ex) {
                log.error("", ex);
            }

            final BLLField field = card.getCard().getField(keyWorks);

            if (keyWorks.equals(BLLDataStructure.HAUSNUMMER_FIELD)) {
                final String[] tmp = this.spilitHauseNum(value);
                final BLLField hauzusatField = card.getCard().getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD);
                field.setValue(tmp[0]);
                hauzusatField.setValue(tmp[1]);
                continue;
            }

            if (keyWorks.equalsIgnoreCase(BLLDataStructure.LAND_FIELD)) {
                field.setValue(value);
                continue;
            }
            field.setValue(value);
            
        }
        final String adr_id = this.getDataInKDP("adr_id", card.getCard().isKdpSpecial(), vectorKDP);
        int adrs = -1;
        try {
            adrs = Integer.parseInt(adr_id);
        } catch (final Exception ex) {

        }
        card.setAdr_id(adrs);
        final String kdp_type = this.getDataInKDP("kdp_type", card.getCard().isKdpSpecial(), vectorKDP);
        int kdptype = 0;
        // pvgiang_1 -14/07/2016- TYPE 'P' is person, 'O' is company
        if (kdp_type.toUpperCase().equalsIgnoreCase("P")) {
            kdptype = 1;
        } else {
            kdptype = 2;
        }
        // try {
        // kdptype = Integer.parseInt(kdp_type);
        // } catch (final Exception ex) {
        //
        // }
        card.setKdpType(kdptype);
    }

    private void updateTypeValueForPickpost(Card card) {
        final Map<String, BLLField> fields = card.getCard().getFieldList();
        final Map<String, String> vectorKDP = card.getVectorKDP();
        final Set<String> keys = fields.keySet();
        for (final String keyWorks : keys) {
            if (keyWorks.equals(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD)) {
                continue;
            }
            if (keyWorks.equals(BLLDataStructure.PARCEL_HAUSKEY)) {
                continue;
            }

            /*
			 * 25/08/2016 Request #10890: pickpost, mypost24 get hauskey from kdp. Do not need find hauskey by kdp_id.
             */

            // hoang disable request from customer
            if (keyWorks.equals(BLLDataStructure.KDPID_FIELD)) {
                final String value = this.getDataInKDP(keyWorks, card.getCard().isKdpSpecial(), vectorKDP);
                final BLLField field = card.getCard().getField(keyWorks);
                field.setValue(value);

                continue;
            }
            String value = this.getDataInKDP(keyWorks, card.getCard().isKdpSpecial(), vectorKDP);
            if (value == null) {
                continue;
            }
            try {
                value = this.checkContraint(keyWorks, value, card);
            } catch (final Exception ex) {
                log.error("", ex);
            }

            final BLLField field = card.getCard().getField(keyWorks);

            if (keyWorks.equals(BLLDataStructure.HAUSNUMMER_FIELD)) {
                final String[] tmp = this.spilitHauseNum(value);
                final BLLField hauzusatField = card.getCard().getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD);
                field.setValue(tmp[0]);
                hauzusatField.setValue(tmp[1]);
                continue;
            }

            if (keyWorks.equalsIgnoreCase(BLLDataStructure.LAND_FIELD)) {
                field.setValue(value);
                continue;
            }
            field.setValue(value);
        }

        // 24/08/2016 Request #10890: mypost24, pickpost do not get ard_id from kdp.

        final String kdp_type = this.getDataInKDP("kdp_type", card.getCard().isKdpSpecial(), vectorKDP);
        int kdptype = 0;
        // pvgiang_1 -14/07/2016- TYPE 'P' is person, 'O' is company
        if (kdp_type.toUpperCase().equalsIgnoreCase("P")) {
            kdptype = 1;
        } else {
            kdptype = 2;
        }
        // try {
        // kdptype = Integer.parseInt(kdp_type);
        // } catch (final Exception ex) {
        //
        // }
        card.setKdpType(kdptype);
    }

    /*
	 * not update parcel hauskey from kdp for myPost 24
     */
    private void updateTypeValueForMyPost24(Card card) {
        final Map<String, BLLField> fields = card.getCard().getFieldList();
        final Map<String, String> vectorKDP = card.getVectorKDP();
        final Set<String> keys = fields.keySet();
        for (final String keyWorks : keys) {
            if (keyWorks.equals(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD)) {
                continue;
            }
            if (keyWorks.equals(BLLDataStructure.PARCEL_HAUSKEY)) {
                continue;
            }

            /*
			 * 25/08/2016 Request #10890: pickpost, mypost24 get hauskey from kdp. Do not need find hauskey by kdp_id.
             */
            // if (keyWorks.equals(BLLDataStructure.HAUSKEY)) {
            // continue;
            // }

            if (keyWorks.equals(BLLDataStructure.KDPID_FIELD)) {
                final String value = this.getDataInKDP(keyWorks, card.getCard().isKdpSpecial(), vectorKDP);
                final BLLField field = card.getCard().getField(keyWorks);
                field.setValue(value);

                // field = card.getCard().getField(BLLDataStructure.HAUSKEY);
                // try {
                // final Long kdpid = Long.parseLong(value);
                // final Long hausKey = this.dal.getHauskeyFromKdpid(kdpid);
                // if ((hausKey != null) && (hausKey != 0)) {
                // field.setValue(hausKey + "");
                // }
                // } catch (final Exception ex) {
                // field.setValue("");
                // }
                continue;
            }

            String value = this.getDataInKDP(keyWorks, card.getCard().isKdpSpecial(), vectorKDP);
            if (value == null) {
                continue;
            }
            try {
                value = this.checkContraint(keyWorks, value, card);
            } catch (final Exception ex) {
                log.error("", ex);
            }

            final BLLField field = card.getCard().getField(keyWorks);

            if (keyWorks.equals(BLLDataStructure.HAUSNUMMER_FIELD)) {
                final String[] tmp = this.spilitHauseNum(value);
                final BLLField hauzusatField = card.getCard().getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD);
                field.setValue(tmp[0]);
                hauzusatField.setValue(tmp[1]);
                continue;
            }

            if (keyWorks.equalsIgnoreCase(BLLDataStructure.LAND_FIELD)) {
                field.setValue(value);
                continue;
            }
            field.setValue(value);
        }

        // 24/08/2016 Request #10890: mypost24, pickpost do not get ard_id from kdp.
        // final String adr_id = this.getDataInKDP("adr_id", card.getCard().isKdpSpecial(), vectorKDP);
        // int adrs = -1;
        // try {
        // adrs = Integer.parseInt(adr_id);
        // } catch (final Exception ex) {
        //
        // }
        // card.setAdr_id(adrs);

        final String kdp_type = this.getDataInKDP("kdp_type", card.getCard().isKdpSpecial(), vectorKDP);
        int kdptype = 0;
        // pvgiang_1 -14/07/2016- TYPE 'P' is person, 'O' is company
        if (kdp_type.toUpperCase().equalsIgnoreCase("P")) {
            kdptype = 1;
        } else {
            kdptype = 2;
        }
        // try {
        // kdptype = Integer.parseInt(kdp_type);
        // } catch (final Exception ex) {
        //
        // }
        card.setKdpType(kdptype);
    }

    // when has kdpid is hauskey and parcel hauskey same
    private void updateTypeValueForDomizilAddress(Card card) {
        final Map<String, BLLField> fields = card.getCard().getFieldList();
        final Map<String, String> vectorKDP = card.getVectorKDP();
        final Set<String> keys = fields.keySet();
        for (final String keyWorks : keys) {
            if (keyWorks.equals(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD)) {
                continue;
            }
            if (keyWorks.equals(BLLDataStructure.PARCEL_HAUSKEY)) {
                continue;
            }

            String value = this.getDataInKDP(keyWorks, card.getCard().isKdpSpecial(), vectorKDP);
            if (value == null) {
                continue;
            }
            try {
                value = this.checkContraint(keyWorks, value, card);
            } catch (final Exception ex) {
                log.error("", ex);
            }

            final BLLField field = card.getCard().getField(keyWorks);

            if (keyWorks.equals(BLLDataStructure.HAUSKEY)) {
                field.setValue(value);
                final BLLField parcelHauskeyField = card.getCard().getField(BLLDataStructure.PARCEL_HAUSKEY);
                parcelHauskeyField.setValue(value);
                continue;
            }
            if (keyWorks.equals(BLLDataStructure.HAUSNUMMER_FIELD)) {
                final String[] tmp = this.spilitHauseNum(value);
                final BLLField hauzusatField = card.getCard().getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD);
                field.setValue(tmp[0]);
                hauzusatField.setValue(tmp[1]);
                continue;
            }

            if (keyWorks.equalsIgnoreCase(BLLDataStructure.LAND_FIELD)) {
                field.setValue(value);
                continue;
            }
            field.setValue(value);
        }
        // Hoang disable from request bug id 0016612/
        // if(card.getCard().isKdpSpecial()){
        // String streetNumber = getDataInKDP("streetnumber", card.getCard().isKdpSpecial(), vectorKDP);
        // try {
        // long street = Long.parseLong(streetNumber);
        // card.getCard().setStreetNumber(street);
        // } catch (Exception ex) {
        //
        // }
        // }
        final String adr_id = this.getDataInKDP("adr_id", card.getCard().isKdpSpecial(), vectorKDP);
        int adrs = -1;
        try {
            adrs = Integer.parseInt(adr_id);
        } catch (final Exception ex) {

        }
        card.setAdr_id(adrs);
        final String kdp_type = this.getDataInKDP("kdp_type", card.getCard().isKdpSpecial(), vectorKDP);
        int kdptype = 0;
        // pvgiang_1 -14/07/2016- TYPE 'P' is person, 'O' is company
        if (kdp_type.toUpperCase().equalsIgnoreCase("P")) {
            kdptype = 1;
        } else {
            kdptype = 2;
        }
        // try {
        // kdptype = Integer.parseInt(kdp_type);
        // } catch (final Exception ex) {
        //
        // }
        card.setKdpType(kdptype);

    }

    /**
     * Have ADRID ?
     *
     * @param card
     * @return
     */
    private boolean checkAddressSpecial(Card card) {
        final String valuePostFach = card.getValuePostFach();
        final String valuePickPost = card.getValuePickPost();
        final String valueStrasse = card.getValueStrasse();

        if (card.isMyPost24()) {
            return false;
        }
        // pvgiang_1 -26/07/2016- Disable process for Kaserne
        // if (card.getCard().isBadCard()) {
        // final String badCard = card.getCard().getBaditem();
        // if (badCard.equalsIgnoreCase("5. Dia chi nuoc ngoai, quan doi")) {
        // if (this.hasArmySign(card.getFieldValue().get(STRASSE))) {
        // card.getCard().setTypeZubofiSpecical(3);
        // return true;
        // }
        // }
        // }
        if (!valuePickPost.equals("")) {
            if (!valuePostFach.equals("") && valueStrasse.equals("")) {
                card.getCard().setTypeZubofiSpecical(4); // special pickpost+postfach;
            } else {
                card.getCard().setTypeZubofiSpecical(2); // special pickpost;
            }
            return true;
        }
        if (!valuePostFach.equals("") && valueStrasse.equals("")) {
            card.getCard().setTypeZubofiSpecical(1); // // special postfach;
            return true;
        }
        card.getCard().setTypeZubofiSpecical(0);
        return false;
    }

    private void preProcessBeforeExport(int adr_id, Card card2) {
        // <editor-fold defaultstate="collapsed" desc="set anredeid">
        final BLLCard card = card2.getCard();
        String anredeid = "";
        String andereValue = Utilities.ignoreNull(card.getField(BLLDataStructure.ANREDE_FIELD).getValue());
        String andereTyped = Utilities
                .ignoreNull(((BLLAddressField) card.getField(BLLDataStructure.ANREDE_FIELD)).getTyped());
        if (andereValue.indexOf(". ") == 1) {
            andereValue = andereValue.substring(andereValue.indexOf(". ") + 2, andereValue.length());
            card.getField(BLLDataStructure.ANREDE_FIELD).setValue(andereValue);
        }
        if (andereTyped.indexOf(". ") == 1) {
            andereTyped = andereTyped.substring(andereTyped.indexOf(". ") + 2, andereTyped.length());
            ((BLLAddressField) card.getField(BLLDataStructure.ANREDE_FIELD)).setTyped(andereTyped);
        }
        for (final String element : this.anredeid1) {
            if (element.equalsIgnoreCase(andereValue)) {
                anredeid = "1";
                break;
            }
        }
        if (anredeid.equals("")) {
            for (final String element : this.anredeid2) {
                if (element.equalsIgnoreCase(andereValue)) {
                    anredeid = "2";
                    break;
                }
            }
        }
        card.getField(BLLDataStructure.ANREDEID_FIELD).setValue(anredeid);
        // </editor-fold>
        // <editor-fold defaultstate="collapsed" desc="set iso land code">
        String landValue = Utilities.ignoreNull(card.getField(BLLDataStructure.LAND_FIELD).getValue());
        String landTyped = Utilities
                .ignoreNull(((BLLAddressField) card.getField(BLLDataStructure.LAND_FIELD)).getTyped());
        if (landValue.indexOf(". ") == 1) {
            landValue = landValue.substring(landValue.indexOf(". ") + 2, landValue.length());
            card.getField(BLLDataStructure.LAND_FIELD).setValue(landValue);
        }
        if (landTyped.indexOf(". ") == 1) {
            landTyped = landTyped.substring(landTyped.indexOf(". ") + 2, landTyped.length());
            ((BLLAddressField) card.getField(BLLDataStructure.LAND_FIELD)).setTyped(landTyped);
        }
        log.debug("Land: " + landValue);
        if (!landValue.equals("")) {
            card.getField(BLLDataStructure.ISOLANDCODE_FIELD).setValue("CH");
        }
        // </editor-fold>
        String plz = Utilities.ignoreNull(card.getField(BLLDataStructure.PLZ_FIELD).getValue());
        if (!plz.equals("")) {
            plz = plz.substring(0, 4);
        }

        String hausNummer = Utilities.ignoreNull(card.getField(BLLDataStructure.HAUSNUMMER_FIELD).getValue());
        if (hausNummer.equals("")) {
            hausNummer = "0";
        }

        this.updateReponseCode(adr_id, card);
        System.out.println("#########response code:" + card.getField(BLLDataStructure.RESPONSECODE_FIELD).getValue());
        final Map<String, String> fieldValues = card2.getFieldValue();
        // updateAddressType(name, vname, firma, adr_id, card);
        this.updateAddressType(fieldValues.get(NAME), fieldValues.get(VORNAME), fieldValues.get(FIRMENAME), adr_id,
                card2);

    }

    public void updateReponseCode(int addressID, BLLCard card) {
        final BLLField reponseCodeField = card.getField(BLLDataStructure.RESPONSECODE_FIELD);

        /*
		 * 25/08/2016 Request #10890: If parcel_hauskey is found and kdp is Pickpost or Mypost24, set response code =
		 * 102 If parcel_hauskey is not found and kdp is Pickpost or Mypost24, set response code = 61
         */
        if (card.isPickpockAddress() || card.isMyPost24()) {
            final String parcelHauskey = Utilities
                    .ignoreNull(card.getField(BLLDataStructure.PARCEL_HAUSKEY).getValue());
            if (!parcelHauskey.equalsIgnoreCase("")) {
                reponseCodeField.setValue("102");
            } else {
                reponseCodeField.setValue("61");
            }
            return;
        }

        /* check reponse code 60,61,62 */
        final String kdpid = Utilities.ignoreNull(card.getField(BLLDataStructure.KDPID_FIELD).getValue());
        if (!kdpid.equals("")) { // has kdp id;
            // String addressID = Utilities.ignoreNull(card.getField(BLLDataStructure.ZUBO_ADRID_FIELD).getValue());

            if (addressID < 1) { // khong co address id
                if (card.isCheckZubofiSpecial()) {
                    reponseCodeField.setValue("60");
                    return;
                } else {
                    reponseCodeField.setValue("61");
                    return;
                }
			} else {
				if (card.isNotAddress()) {
                reponseCodeField.setValue("62");
                return;
            }
        }
		}

        /* check reponse code 101,102 */
        if (card.isKdpSpecial()) {
            reponseCodeField.setValue("101");
            return;
        }
        if (card.isZubofiSpecial()) {
            reponseCodeField.setValue("102");
            return;
        }
        /* check reason bad card */
        if (card.isBadCard()) {
            reponseCodeField.setValue(card.getReasonBad());
            return;
        }
        if (card.isCheckZubofiSpecial()) { // not check normal when search
            reponseCodeField.setValue("");
            return;
        }
        /* check reason from 50 to 100 */
        this.checkNormalRespondeCode(reponseCodeField, card);
    }

    private void checkNormalRespondeCode(BLLField reponseCodeField, BLLCard card) {
        final String kdpid = Utilities.ignoreNull(card.getField(BLLDataStructure.KDPID_FIELD).getValue());
        final int kdpType = card.getKdpType(); // when kdp_type =1 is person , =2 is company
        final String strasse = Utilities.ignoreNull(card.getField(BLLDataStructure.STRASSE_FIELD).getValue());
        final String plz = Utilities.ignoreNull(card.getField(BLLDataStructure.PLZ_FIELD).getValue());
        final String ort = Utilities.ignoreNull(card.getField(BLLDataStructure.ORT_FIELD).getValue());
        final String house = Utilities.ignoreNull(card.getField(BLLDataStructure.HAUSNUMMER_FIELD).getValue());
        final String hausezusat = card.getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD).getValue();
        final String land = card.getField(BLLDataStructure.LAND_FIELD).getValue();
        final String p_postfach = card.getField(BLLDataStructure.POSTFACHNUMMER_FIELD).getValue();
        final String p_ort = this.translateAscii(ort);
        final String p_strasse = this.translateAscii(strasse);
        Integer plzin = null;
        try {
            plzin = Integer.parseInt(plz.substring(0, 3));
        } catch (final Exception ex) {
            log.warn("", "", ex);
        }
        Integer housein = -1;
        try {
            housein = Integer.parseInt(house);
        } catch (final Exception ex) {
            log.warn("", "", ex);
        }

        if (kdpid.equals("")) { // no kdpid
            final String strasseType = Utilities
                    .ignoreNull(((BLLAddressField) card.getField(BLLDataStructure.STRASSE_FIELD)).getTyped());
            final String ortType = Utilities
                    .ignoreNull(((BLLAddressField) card.getField(BLLDataStructure.ORT_FIELD)).getTyped());
            final String plzType = Utilities
                    .ignoreNull(((BLLAddressField) card.getField(BLLDataStructure.PLZ_FIELD)).getTyped());
            final String hausType = Utilities
                    .ignoreNull(((BLLAddressField) card.getField(BLLDataStructure.HAUSNUMMER_FIELD)).getTyped())
                    + Utilities.ignoreNull(
                            ((BLLAddressField) card.getField(BLLDataStructure.HAUSNUMMER_FIELD)).getTyped());
            final int count = this.checkFieldValue(plz, ort, strasse, house, hausezusat, strasseType, ortType, plzType,
                    hausType);
            if (count != 0) { // trung nhieu field
                if ((count != 1) && (count != 2) && (count != 4) && (count != 8)) {
                    reponseCodeField.setValue("50");// many field.
                    return;
                } else {
                    if (count == 1) {
                        reponseCodeField.setValue("");// khong xay ra truong hop
                        // nay
                        return;
                    }
                    if (count == 2) {
                        reponseCodeField.setValue("51");
                        return;
                    }
                    if (count == 4) {
                        reponseCodeField.setValue("52");
                        return;
                    }
                    if (count == 8) {
                        reponseCodeField.setValue("53");
                        return;
                    }
                }
            }
            final BLLAddressField field = (BLLAddressField) card.getField(BLLDataStructure.NAME_FIELD);
            String nameType = Utilities.ignoreNull(field.getTyped());
            if (p_ort.equals("") || (plzin == null) || p_strasse.equals("")) {

            } else {
				if (nameType.equals("")) {
				} else {
                final String p_strasse_tmp = p_strasse;
                // if ((p_strasse != null) && (p_strasse.indexOf("'") != -1)) {
                // p_strasse_tmp = p_strasse.replace("'", "\\'");
                // }

                final String p_ort_tmp = p_ort;
                // if ((p_ort != null) && (p_ort.indexOf("'") != -1)) {
                // p_ort_tmp = p_ort.replace("'", "\\'");
                // }
                // nameType = nameType.replace("'", "\\'");
                nameType = this.translateAscii(nameType);
                log.info("[Capture]-[COLLECTION:" + card.getManagementID() + "][SAVE]-start count duplicate kdp");
                final int countDuplicate = this.countDuplicateKDP(plzin, p_ort_tmp, p_strasse_tmp, nameType, null,
                        housein, null, null, null);
                log.info("[Capture]-[COLLECTION:" + card.getManagementID() + "][SAVE]-end count duplicate kdp");

                if (countDuplicate > 1) {
                    reponseCodeField.setValue("55");
                    return;
                }
            }
			}
        } else {
            final String postFachType = Utilities
                    .ignoreNull(((BLLAddressField) card.getField(BLLDataStructure.POSTFACHNUMMER_FIELD)).getTyped());
            if (!postFachType.equals("")) {
                if (card.isChange()) {
                    reponseCodeField.setValue("100");
                } else {
                    reponseCodeField.setValue("");
                }
                return;
            }
            String name = null;
            String vName = null;
            if (kdpType == 1) { // person kdp_id
                name = Utilities.ignoreNull(card.getField(BLLDataStructure.NAME_FIELD).getValue());
                vName = Utilities.ignoreNull(card.getField(BLLDataStructure.VORNAME_FIELD).getValue());
                name = this.translateAscii(name);
                // name = name.replace("'", "\\'");
                vName = this.translateAscii(vName);
                // vName = vName.replace("'", "\\'");
            }
            if (kdpType == 2) {
                name = Utilities.ignoreNull(card.getField(BLLDataStructure.FIRMENNAME_FIELD).getValue());
                name = this.translateAscii(name);
                // name = name.replace("'", "\\'");
                vName = null;
            }

            // String p_strasse_tmp = p_strasse;
            // if ((p_strasse != null) && (p_strasse.indexOf("'") != -1)) {
            // p_strasse_tmp = p_strasse.replace("'", "\\'");
            // }
            //
            // String p_ort_tmp = p_ort;
            // if ((p_ort != null) && (p_ort.indexOf("'") != -1)) {
            // p_ort_tmp = p_ort.replace("'", "\\'");
            // }

            log.info("[BLLSaveCard][checkNormalRespondeCode]-[COLLECTION:" + card.getManagementID()
                    + "][SAVE]-start count duplicate kdp");

            /*
			 * 25/08/2016 Request #10890: check response code 54 based on these fields: kun_type, kun_geschlecht,
			 * kun_name, kun_vorname, zub_adr_id, zub_aadr_id, zub_hauskey
             */
            final String anrede = Utilities.ignoreNull(card.getField(BLLDataStructure.ANREDE_FIELD).getValue());
            final String adr_id = Utilities.ignoreNull(card.getField(BLLDataStructure.ADR_ID).getValue());
            final String aadr_id = Utilities.ignoreNull(card.getField(BLLDataStructure.AADR_ID).getValue());
            final String hauskey = Utilities.ignoreNull(card.getField(BLLDataStructure.HAUSKEY).getValue());

            final int countDuplicate = this.countDuplicateKDP(kdpType == 1 ? "P" : "O",
                    anrede.equalsIgnoreCase("") ? "" : anrede.equalsIgnoreCase("Frau") ? "W" : "M", name, vName, adr_id,
                    aadr_id, hauskey);
            // final int countDuplicate = this.countDuplicateKDP(plzin, p_ort_tmp, p_strasse_tmp, name, vName, housein,
            // hausezusat, land, p_postfach);

            if (countDuplicate > 1) {
                reponseCodeField.setValue("54");
                return;
            }
            if (card.isChange()) {
                reponseCodeField.setValue("100");
                return;
            }
        }
        reponseCodeField.setValue("");
    }

    private void updateAddressType(String name, String vname, String firma, int adr_id, Card cardData) {
        final BLLCard card = cardData.getCard();
        final boolean isKDP = card.isHasInKDP();
        final String strasse = this.mainField.getFieldValue(MainFieldInterface.STRASSE);
        int kdpType = 0;

        if (isKDP) {
            kdpType = card.getKdpType();
        }

        int iAddressType = -1;

        final BLLAddressField postFachField = (BLLAddressField) card.getField(BLLDataStructure.POSTFACHNUMMER_FIELD);
        final BLLAddressField pickPostField = (BLLAddressField) card.getField(BLLDataStructure.PICKPOSTNUMMER_FIELD);

        // Hoang update for bug 0012308 with requirement
        final String fimavalue = card.getField(BLLDataStructure.FIRMENNAME_FIELD).getValue();
        final String nameValue = card.getField(BLLDataStructure.NAME_FIELD).getValue();
        final String vnameValue = card.getField(BLLDataStructure.VORNAME_FIELD).getValue();
        if (fimavalue != null) {
            firma = fimavalue + firma;
        }

        if (nameValue != null) {
            name = nameValue + name;
        }
        if (vnameValue != null) {
            vname = vnameValue + vname;
        }
        // --------------------end code for bug id 0012308----------
        final boolean isPostfachAddress = card.isPostfachAddress();
        final boolean isPostLagenAddress = card.isPostLagenAddress();
        final boolean isPickpockAddress = card.isPickpockAddress();
        if (!isKDP && (!isPostfachAddress || !isPostLagenAddress || !isPickpockAddress)) {
            iAddressType = 0;
        } else if (isKDP && (!isPostfachAddress || !isPostLagenAddress || !isPickpockAddress)) {
            if (kdpType == 1) {
                iAddressType = 1;
            }
            if (kdpType == 2) {
                iAddressType = 2;
            }
        }

        // truong hop co' kdp id , strasse co thi` khong qua addresstype 16,17,18.
        if (isPostfachAddress) {
            if ((iAddressType != 0) && !strasse.isEmpty()) {
            } else {
                iAddressType = 16; // Hoang add address type
                if (!StringUtils.isEmpty(vname) || !StringUtils.isEmpty(name)) {
                    if (strasse.isEmpty()) {
                        iAddressType = 17;
                    } else {
                        iAddressType = 1;
                    }
                }

                if (!StringUtils.isEmpty(firma)) {
                    if (strasse.isEmpty()) {
                        iAddressType = 18;
                    } else {
                        iAddressType = 2;
                    }
                }
            }
            // Hoang disable for new solution about addresstype
        }

        if (isPostLagenAddress) {
            iAddressType = 32;
            if (!StringUtils.isEmpty(vname) || !StringUtils.isEmpty(name)) {
                iAddressType = 33;
            }

            if (!StringUtils.isEmpty(firma)) {
                iAddressType = 34;
            }
        }

        if (isPickpockAddress) {
            iAddressType = 64;
            if (!StringUtils.isEmpty(vname) || !StringUtils.isEmpty(name)) {
                iAddressType = 65;
            }

            if (!StringUtils.isEmpty(firma)) {
                iAddressType = 66;
            }
        }
        if (card.isMyPost24()) {
            iAddressType = 128;
            if (!StringUtils.isEmpty(vname) || !StringUtils.isEmpty(name)) {
                iAddressType = 129;
            }
            if (!StringUtils.isEmpty(firma)) {
                iAddressType = 130;
            }
        }
        // end calculate addressType
        // pvgiang-1 -25/07/2016- disable this function because address type is only 'P' or 'O'.
        // function for kdp special has addrtype = 18
        // final Map<String, String> vectorKDP = cardData.getVectorKDP();
        // final String addresstype = this.getDataInKDP("adr_type", card.isKdpSpecial(), vectorKDP);
        // if ((addresstype != null) && !addresstype.isEmpty()) {
        // try {
        // final int type = Integer.parseInt(addresstype);
        // if ((type != 1) && (type != 2)) {
        // iAddressType = type;
        // }
        // } catch (final Exception e) {
        // log.warn("", "", e);
        // }
        // }
        if (iAddressType > -1) {
            card.getField(BLLDataStructure.ADDRESSTYPE_FIELD).setValue(iAddressType + "");
        }

        pickPostField.setTyped(pickPostField.getTyped().replace("#", "").trim());
        pickPostField.setValue(pickPostField.getValue().replace("#", "").trim());
        if (postFachField.getValue().equalsIgnoreCase("x") || postFachField.getTyped().equalsIgnoreCase("x")) {
            postFachField.setTyped("");
        }
        final int values = adr_id;
        if (values > 0) {
            card.getField(BLLDataStructure.ZUBO_ADRID_FIELD).setValue("" + values);
        }
    }

    public String translateAscii(String s) {
        return this.dal.translateAscii(s);
    }

    private int checkFieldValue(String plz, String ort, String strasse, String house, String hausezusat,
            String strasseType, String ortType, String plzType, String hausType) {
        int count = 0;
        if (plz.equals("") && !plzType.equals("")) {
            count = 1;
        }
        if (ort.equals("") && !ortType.equals("")) {
            count += 2;
        }
        if (!ort.equals("") && !ortType.equals("") && !ortType.equalsIgnoreCase(ort)) {
            count += 2;
        }
        if (strasse.equals("") && !strasseType.equals("")) {
            count += 4;
        }
        if (house.equals("") && ((hausezusat == null) || hausezusat.equals("")) && !hausType.equals("")) {
            count += 8;
        }
        return count;
    }

    public int countDuplicateKDP(Integer plz, String ort, String strasse, String name, String vName, Integer hausnr,
            String hausrn_a, String land, String postfach) {
        return this.dal.countDuplicateKDP(plz, ort, strasse, name, vName, hausnr, hausrn_a, land, postfach);

    }

    public int countDuplicateKDP(String type, String anrede, String name, String vorname, String adr_id, String aadr_id,
            String hauskey) {
        return this.dal.countDuplicateKDP(type, anrede, name, vorname, adr_id, aadr_id, hauskey);
    }

    public void setReasonBad(String reasonBad) {
        this.reasonBad = reasonBad;
    }

    public String getReasonBad() {
        return this.reasonBad;
    }

    private String changeCase(String value, int type) {
        try {
            if (value.length() > 0) {
                return Utilities.changeCase(this.changeCase, value, type);
            }
        } catch (final Exception ex) {
            log.error("", ex);
            return value;
        }
        return value;
    }

    private void reCalculateTypedAndValue(Card card) {
        // int adr_id = 0;
        if (!card.isHaveValueFromSearchKdp()) {
            this.reCalculateWhenNotChosenKdp(card);
        } else {
            this.reCalculateWhenChosenKdp(card);
        }

        card.getCard().hasInKDP(card.isHaveValueFromSearchKdp());
        card.getCard().setKdpType(card.getKdpType());
        card.setAdr_id(card.getAdr_id());
    }

    private void reCalculateWhenChosenKdp(Card card) {
        if ((card.getAdr_id() == null) || (card.getAdr_id() < 1)) {
            final Map<String, Integer> map = this.findAddressID(card);
            final Integer result = map.get(resultS);
            final Integer addressid = map.get(addressID);

            if (card.isMyPost24() || card.getCard().isCheckZubofiSpecial()) {
                try {
                    final Integer hkey = map.get(hauskey);
                    if ((hkey != null) && (hkey > 0)) {
                        card.getCard().getField(BLLDataStructure.PARCEL_HAUSKEY).setValue(hkey + "");
                    }
                } catch (final Exception ex) {
                    log.warn("", "", ex);
                }
            }

            card.setAdr_id(addressid);
            // my post 24 not has result 11.
            if ((result != null) && (result == 11)) {
                card.getCard().setZubofiSpecial(true);
            }
		} else {
			/**
			 * Request #10890: Get parcel_hauskey for special domizil address(has strasse is null and postfach is null)
			 * from ASDP when kdp_id is not null.
         */
        if ("".equalsIgnoreCase(card.getValuePostFach()) && "".equalsIgnoreCase(card.getValueStrasse())
					&& "".equalsIgnoreCase(card.getFieldValue().get(HAUSNUMER))) {
				final HauskeyAddress parcelHauskey = this.dal.findParcelHauskeyAndAddressForZubofiSpecial(
						card.getFieldValue().get(PLZ), card.getFieldValue().get(ORT), card.getFieldValue().get(STRASSE),
						card.getFieldValue().get(HAUSNUMER));
				if (parcelHauskey != null && !StringUtil.isEmpty(parcelHauskey.getHauskey())) {
					card.getCard().getField(BLLDataStructure.PARCEL_HAUSKEY).setValue(String.valueOf(parcelHauskey));
				}
			}
		}
        if (card.getCard().getStreetNumber() == 0) {
            final String value = card.getCard().getField(BLLDataStructure.PARCEL_HAUSKEY).getValue();
            if ((value == null) || value.equals("")) {
            } else {
                try {
                    final Long parcelHauskey = Long.parseLong(value);
                    this.findStreetNumberFromParcelHauskey(parcelHauskey, card);
                } catch (final Exception e) {

                }
            }
        }
        final String parcelhauskey = card.getCard().getField(BLLDataStructure.PARCEL_HAUSKEY).getValue();
        if ((parcelhauskey == null) || parcelhauskey.equals("")) {
            if (card.getCard().getStreetNumber() > 0) {
                card.getCard().setStreetNumber(0);
            }
        }

        this.setTyped(card.getFieldValue(), card);
        boolean isChange = false; // check KDP not match 1:1

        Iterator<BLLField> fields = card.getCard().getFieldList().values().iterator();
        while (fields.hasNext()) {
            final BLLField field = fields.next();

            if (field instanceof BLLAddressField) {
                String value = Utilities.ignoreNull(((BLLAddressField) field).getValue());
                if (field.getName().equals("plz")) {
                    if (value.length() > 4) {
                        value = value.substring(0, 4);
                    }
                }
                final String typed = Utilities.ignoreNull(((BLLAddressField) field).getTyped());
                if (!value.toLowerCase().equalsIgnoreCase(typed.toLowerCase())
                        && !field.getName().equalsIgnoreCase(BLLDataStructure.LOOKUP_FIELD)
                        && !field.getName().equalsIgnoreCase(BLLDataStructure.POSTFACHNUMMER_FIELD)
                        && !field.getName().equalsIgnoreCase(BLLDataStructure.PICKPOSTNUMMER_FIELD)
                        && !field.getName().equalsIgnoreCase(BLLDataStructure.LAND_FIELD) && !typed.equals("")) {
                    // final String fieldName = Utilities.ignoreNull(field.getName());
                    if (!field.getName().equalsIgnoreCase(BLLDataStructure.ANREDE_FIELD)) {
                        isChange = true;
                    }
                }
            }
        }
        card.getCard().setChange(isChange);
        fields = card.getCard().getFieldList().values().iterator();
        while (fields.hasNext()) {
            final BLLField field = fields.next();

            if (field instanceof BLLAddressField) {
                String value = Utilities.ignoreNull(((BLLAddressField) field).getValue());
                if (field.getName().equals("plz")) {
                    if (value.length() > 4) { // fix bug
                        value = value.substring(0, 4);
                    }
                }
                String typed = Utilities.ignoreNull(((BLLAddressField) field).getTyped());

                if (field.getName().equalsIgnoreCase(BLLDataStructure.LAND_FIELD)) {
                    typed = typed.substring(typed.indexOf(" ") + 1, typed.length());
                }

                if (isChange) { // found KDP but not match 1:1
                    if (value.equalsIgnoreCase(typed)) {
                        ((BLLAddressField) field).setTyped("");
                    }
                } else if (!field.getName().equalsIgnoreCase(BLLDataStructure.POSTFACHNUMMER_FIELD)
                        && !field.getName().equalsIgnoreCase(BLLDataStructure.PICKPOSTNUMMER_FIELD)
                        && !field.getName().equalsIgnoreCase(BLLDataStructure.LAND_FIELD)) {

                    ((BLLAddressField) field).setTyped("");
                } else if (value.equalsIgnoreCase(typed)) {
                    ((BLLAddressField) field).setTyped("");
                }
            }
        }

    }

    private void reCalculateWhenNotChosenKdp(Card card) {
        final Map<String, String> fieldValue = card.getFieldValue();
        card.getCard().getField(BLLDataStructure.KDPID_FIELD).setValue("");
        String plz;
        try {
            plz = Utilities.ignoreNull(fieldValue.get(PLZ));
        } catch (final StringIndexOutOfBoundsException strex) {
            plz = "";
        }

        final String ort = fieldValue.get(ORT);

        final String str = fieldValue.get(STRASSE);

        final String hnr = fieldValue.get(HAUSNUMER);
        final String name = fieldValue.get(NAME);

        final List<String> plzList = new ArrayList<String>(11);
        log.debug("Search zobofi : '" + plz + "', '" + ort + "', '" + str + "','" + hnr + "','" + name + "'");

        final int searchADRID = this.dal.getFromZoboFi(plz, ort, str, hnr, name, plzList, card);
        if (searchADRID == 11) {
            card.getCard().setZubofiSpecial(true);
        }
        final String plzZubo = "";
        if (plzList.size() > 0) {
            if ((plzList.get(0) != null) && !plzList.get(0).equals("")) {
                card.setAdr_id(Integer.parseInt(plzList.get(0)));
            } else {
                card.setAdr_id(0);
            }
        }
        
        this.processFillAdrData(fieldValue, plzZubo, card, plzList);

        final String parcelhauskey = card.getCard().getField(BLLDataStructure.PARCEL_HAUSKEY).getValue();
        if ((parcelhauskey == null) || parcelhauskey.equals("")) {
            if (card.getCard().getStreetNumber() > 0) {
                card.getCard().setStreetNumber(0);
            }
        }
       
    }

    private void findStreetNumberFromParcelHauskey(Long adr_id, Card card) {
        final Long street = this.dal.getStreetNumberFromParcelHauskey(adr_id);
        if (street > 0) {
            card.getCard().setStreetNumber(street);
        }
    }

    private void processFillAdrData(Map<String, String> fieldValue, String plzZubo, Card card, List<String> plzList) {
    	
    	this.clearDuplicateData(plzList);
        final Set<String> keyString = fieldValue.keySet();
        final BLLCard bllCard = card.getCard();
        final BLLField fieldHauskey = bllCard.getField(BLLDataStructure.PARCEL_HAUSKEY);
        if ((fieldHauskey.getValue() == null) || fieldHauskey.getValue().equals("")) {
            try {
                fieldHauskey.setValue(plzList.get(11));
            } catch (final Exception ex) {
                fieldHauskey.setValue("");
            }
        }
        for (final String fieldName : keyString) {
            String value = Utilities.ignoreNull(fieldValue.get(fieldName));
            final BLLField field = bllCard.getField(fieldName);
            // add field for hauskey when null.

            if ((field != null) && (field instanceof BLLAddressField)) {
                if (fieldName.equals(PLZ)) {
                    value = plzZubo;
                }
                final String inputConstraint = ((BLLAddressField) field).getConstraint();
                int changeCaseType = 0;
                try {
                    changeCaseType = Integer.parseInt(Utilities.getdata_seperator(inputConstraint, false, ";"));
                } catch (final Exception e) {
                    log.warn("", "At field name: " + fieldName, e);
                }
                value = this.changeCase(value, changeCaseType);
                if (fieldName.equalsIgnoreCase(BLLDataStructure.PICKPOSTNUMMER_FIELD)) {
                    if (!value.equals("")) { // jtfpickPost has value
                        ((BLLAddressField) field).setTyped(value);
                        ((BLLAddressField) field).setValue("");
                    }
                    continue;
                }
                if ((fieldName.equalsIgnoreCase(BLLDataStructure.PLZ_FIELD)
                        || fieldName.equalsIgnoreCase(BLLDataStructure.ORT_FIELD)
                        || fieldName.equalsIgnoreCase(BLLDataStructure.STRASSE_FIELD)
                        || fieldName.equalsIgnoreCase(BLLDataStructure.HAUSNUMMER_FIELD)) && (plzList.size() > 0)) {

					if (fieldName.equalsIgnoreCase(BLLDataStructure.PLZ_FIELD)) {
						((BLLAddressField) field).setValue(plzList.get(2));
						((BLLAddressField) field).setTyped(plzList.get(1));
					}

					if (fieldName.equalsIgnoreCase(BLLDataStructure.ORT_FIELD)) {
						((BLLAddressField) field).setValue(plzList.get(4));
						((BLLAddressField) field).setTyped(this.removeSpecialCharacter(plzList.get(3)));
					}

					if (fieldName.equalsIgnoreCase(BLLDataStructure.STRASSE_FIELD)) {
						((BLLAddressField) field).setValue(plzList.get(6));
						((BLLAddressField) field).setTyped(this.removeSpecialCharacter(plzList.get(5)));
					}

					if (fieldName.equalsIgnoreCase(BLLDataStructure.HAUSNUMMER_FIELD)) {
						final BLLAddressField hauzusatField = (BLLAddressField) bllCard
								.getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD);

						((BLLAddressField) field).setValue(plzList.get(8));
						((BLLAddressField) field).setTyped(plzList.get(7));

						hauzusatField.setValue(plzList.get(10));
						hauzusatField.setTyped(plzList.get(9));
					}
                    continue;
                }
                ((BLLAddressField) field).setTyped(value);
                ((BLLAddressField) field).setValue("");
            }
        }
    }

    private void clearDuplicateData(List<String> plzList) {
    	if (plzList.get(1).equals(plzList.get(2))) {
    		plzList.set(1, "");
    	}
    	
    	if (plzList.get(3).equals(plzList.get(4))) {
    		plzList.set(3, "");
    	}
    	
    	if (plzList.get(5).equals(plzList.get(6))) {
    		plzList.set(5, "");
    	}
    	
    	if (plzList.get(7).equals(plzList.get(8))) {
    		plzList.set(7, "");
    	}
    	
    	if (plzList.get(9).equals(plzList.get(10))) {
    		plzList.set(9, "");
    	}
	}

	public String removeSpecialCharacter(String s) {
        if (s.indexOf("\\'") != -1) {
            // str = str.substring(0, str.indexOf("'"));
            s = s.replace("\\'", "'");
        }
        return s;
    }

    private Map<String, Integer> findAddressID(Card card) {
        final HashMap<String, Integer> map = new HashMap<String, Integer>();
        String plz;
        final Map<String, String> fieldValues = card.getFieldValue();

        try {
            // plz = Utilities.ignoreNull(jtfPlz.getText()).substring(0, 3);
            plz = Utilities.ignoreNull(card.getFieldValue().get(PLZ));
        } catch (final StringIndexOutOfBoundsException strex) {
            plz = "";
        }

        final String ort = fieldValues.get(ORT);
        // if (ort.indexOf("'") != -1) {
        // // ort = ort.substring(0, ort.indexOf("'"));
        // ort = ort.replace("'", "\\'");
        // }

        final String str = fieldValues.get(STRASSE);
        // if (str.indexOf("'") != -1) {
        // str = str.replace("'", "\\'");
        // }

        final String hnr = fieldValues.get(HAUSNUMER);
        final String name = fieldValues.get(NAME);

        final List<String> plzList = new ArrayList<String>(11);
        card.getCard().setNotAddress(true);

        if (card.isMyPost24()) {
            final int result = this.dal.getFromZoboFi(plz, ort, str, hnr, name, plzList, card);
            if (plzList.size() > 0) {
                if ((plzList.get(0) != null) && !plzList.get(0).equals("")) {
                    this.updateKundennummerAddressField(card, plzList);
                    map.put(resultS, result);
                    try {
                        map.put(addressID, Integer.parseInt(plzList.get(0)));
                    } catch (final Exception e) {
                        log.warn("", e);
                    }
                } else {
                    map.put(resultS, 0);
                    map.put(addressID, 0);
                    // map.put(hauskey, 0);
                }

                map.put(hauskey, 0);
                try {
                    if (!"".equalsIgnoreCase(plzList.get(11))) {
                        map.put(hauskey, Integer.parseInt(plzList.get(11)));
                    }
                } catch (final Exception e) {
                    log.warn("", e);
                }
            }
            return map;
        }
		if (this.hasPickPostAddress(card)) {
			map.put(resultS, 0);
			map.put(addressID, 0);
			map.put(hauskey, 0);
			try {
				final HauskeyAddress parcelHauskeyResults = this.dal.findParcelHauskeyAndAddressForPickpost(plz, ort,
						str, hnr, 2);
				if (!StringUtils.isEmpty(parcelHauskeyResults.getHauskey())) {
					this.updateKundennummerAddressField(card, parcelHauskeyResults);
					map.put(hauskey, Integer.parseInt(parcelHauskeyResults.getHauskey()));
					map.put(addressID, Integer.parseInt(parcelHauskeyResults.getAddrId()));
					map.put(resultS, 11);
				}
			} catch (Exception e) {
				log.warn("", e);
			}
			return map;
		} else {
            final int result = this.dal.getFromZoboFi(plz, ort, str, hnr, name, plzList, card);
            if (plzList.size() > 0) {
                if (((plzList.get(0) != null) && !plzList.get(0).equals("")) || (result == 11)) {

                    if (card.getCard().getTypeZubofiSpecical() > 0) {
                        this.updateKundennummerAddressField(card, plzList);
                    }
                    map.put(resultS, result);
                    try {
                        map.put(addressID, Integer.parseInt(plzList.get(0)));
                    } catch (final Exception ex) {
                        map.put(addressID, 0);
                    }
                    map.put(hauskey, 0);
                    try {
                        map.put(hauskey, Integer.parseInt(plzList.get(11)));
                    } catch (final Exception e) {
                        log.warn("", e);
                    }
                } else {
                    map.put(resultS, 0);
                    map.put(addressID, 0);
                    map.put(hauskey, 0);
                    try {
                        map.put(hauskey, Integer.parseInt(plzList.get(11)));
                    } catch (final Exception e) {
                        log.warn("", e);
                    }
                }
            }
            return map;
        }
    }

    // clear value in card Before search
    private void updateKundennummerAddressField(Card card, HauskeyAddress parcelHauskeyResults) {
        // clear value in card before search.
        BLLAddressField field;
        field = (BLLAddressField) card.getCard().getField(BLLDataStructure.PLZ_FIELD);
        field.setTyped(parcelHauskeyResults.getPlzType());
        field.setValue(parcelHauskeyResults.getPlzValue());
        field = (BLLAddressField) card.getCard().getField(BLLDataStructure.ORT_FIELD);
        field.setTyped(parcelHauskeyResults.getOrtType());
        field.setValue(parcelHauskeyResults.getOrtValue());
        field = (BLLAddressField) card.getCard().getField(BLLDataStructure.STRASSE_FIELD);
        field.setTyped(parcelHauskeyResults.getStrasseType());
        field.setValue(parcelHauskeyResults.getStrasseValue());
        field = (BLLAddressField) card.getCard().getField(BLLDataStructure.HAUSNUMMER_FIELD);
        field.setTyped(parcelHauskeyResults.getHausnummerType());
        field.setValue(parcelHauskeyResults.getHausnummerValue());
        field = (BLLAddressField) card.getCard().getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD);
        field.setTyped(parcelHauskeyResults.getHausnummerZusatType());
        field.setValue(parcelHauskeyResults.getHausnummerZusatValue());
    }
    
 // clear value in card Before search
    private void updateKundennummerAddressField(Card card, List<String> plzList) {
        // clear value in card before search.
        // Iterator<BLLField> bllField =
        // card.getFieldBeforSearch().values().iterator();
        // while (bllField.hasNext()) {
        // BLLField field = bllField.next();
        // field.setValue("");
        // }
        // add value from plzlist into contructor
        BLLAddressField field;
        field = (BLLAddressField) card.getCard().getField(BLLDataStructure.PLZ_FIELD);
        field.setTyped(plzList.get(1));
        field.setValue(plzList.get(2));
        field = (BLLAddressField) card.getCard().getField(BLLDataStructure.ORT_FIELD);
        field.setTyped(plzList.get(3));
        field.setValue(plzList.get(4));
        field = (BLLAddressField) card.getCard().getField(BLLDataStructure.STRASSE_FIELD);
        field.setTyped(plzList.get(5));
        field.setValue(plzList.get(6));
        field = (BLLAddressField) card.getCard().getField(BLLDataStructure.HAUSNUMMER_FIELD);
        field.setTyped(plzList.get(7));
        field.setValue(plzList.get(8));
        field = (BLLAddressField) card.getCard().getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD);
        field.setTyped(plzList.get(9));
        field.setValue(plzList.get(10));

    }


    private boolean hasPickPostAddress(Card card) {
        final String pickpost = card.getFieldValue().get(PICKPOST);
        if (pickpost.equals("")) {
            return false;
        }
        return true;

    }

    private void setTyped(Map<String, String> fieldValues, Card card) {
        final Set<String> key = fieldValues.keySet();
        final BLLCard bllCard = card.getCard();
        for (final String fieldName : key) {
            if (fieldName.equalsIgnoreCase(POSTLAGEND)) {
                continue;
            }
            final BLLField field = card.getCard().getField(fieldName);
            if ((field != null) && (field instanceof BLLAddressField)) {
                String value = Utilities.ignoreNull(fieldValues.get(fieldName));
                final String inputConstraint = ((BLLAddressField) field).getConstraint();
                int changeCaseType = 0;

                try {
                    changeCaseType = Integer.parseInt(Utilities.getdata_seperator(inputConstraint, false, ";"));
                } catch (final Exception ex) {
                    log.warn("", "At field name: " + fieldName, ex);
                }
                value = this.changeCase(value, changeCaseType);
                if (fieldName.equalsIgnoreCase(BLLDataStructure.HAUSNUMMER_FIELD)) {
                    final String[] tmp = this.spilitHauseNum(value);
                    final BLLAddressField hauzusatField = (BLLAddressField) bllCard
                            .getField(BLLDataStructure.HAUSNUMMERZUSATZ_FIELD);
                    ((BLLAddressField) field).setTyped(tmp[0]);
                    hauzusatField.setTyped(tmp[1]);
                    continue;
                }
                if (fieldName.equalsIgnoreCase(BLLDataStructure.PICKPOSTNUMMER_FIELD)) {
                    if (!value.equals("")) {
                        ((BLLAddressField) field).setTyped(value);
                    }
                    continue;
                }
                ((BLLAddressField) field).setTyped(value);

            }
        }
    }

    private String[] spilitHauseNum(String str) {
        final String result[] = new String[2];
        String hausuzat = "";
        String hausNum = str;
        for (int j = 0; j < str.length(); j++) {
            if ((str.charAt(j) < '0') || (str.charAt(j) > '9')) {
                hausuzat = str.substring(j);
                hausNum = str.substring(0, j);
                break;
            }
        }

        result[0] = hausNum.trim();
        // result[1] = hausuzat.trim();
        result[1] = hausuzat;
        // }

        return result;
    }

    private void doExport(Card card) {
        try {
            card.getCard().getField(BLLDataStructure.POSTLAGEND_FIELD).setValue(card.getFieldValue().get(POSTLAGEND));
            this.export(card.getAdr_id() == null ? 0 : card.getAdr_id(), card);
        } catch (final Exception ex) {
            log.error("", ex);
        }
    }

    public void export(int adr_id, Card card) {
        try {
            log.info("[BLLSaveCard][export]-[COLLECTION:" + card.getCard().getManagementID()
                    + "][SAVE]-process typist data");
            this.preProcessBeforeExport(adr_id, card);
            log.info("[BLLSaveCard][export]-[COLLECTION:" + card.getCard().getManagementID()
                    + "][SAVE]-get time end card");
            final String longTime = this.transferService.getCurrentTime();
            card.getCard().setEndTime(new Timestamp(Long.parseLong(longTime)));
            card.getCard().setUsername(this.user.getUserName());
            card.getCard().setStep(this.INPUTSTEP);
            log.info("[BLLSaveCard][export]-[COLLECTION:" + card.getCard().getManagementID()
                    + "][SAVE]-add data from card to collection");
            final Collection collection = Util.convertToColection(card.getCard(), card.getNeedTransfer());
            
            collection.getCollectionStatus().setCoderID(this.user.getUserName());
            collection.getCollectionStatus().setCodingStation(this.CaptureUser);
            
        } catch (final Exception ex) {
            log.error("", ex);
        }
    }

    public void processSaveCard(Card card) throws Exception {
        // updateStatusCard(mainField, "TRA CARD VE");
        log.info("[BLLSaveCard][processSaveCard]-[COLLECTION:" + card.getCard().getManagementID()
                + "][SAVE]-return collection to proxy");
        this.transferService.returnCapturedCollection((Collection) card.getNeedTransfer());
    }

    @Override
    public void setMainField(MainFieldInterface mainField) {
        this.mainField = mainField;
        // if (validate != null) {
        // validate.setMainField(mainField);
        // }
        mainField.addStatus(0, 0f);
    }

    private float minutes;

    private void showCardAmount(long startTime, long endTime) {
        try {
            this.minutes += ((float) (endTime - startTime) / 1000);
            float speed;
            if (this.cardAmount == 0) {
                speed = 0;
            } else {
                speed = this.minutes / this.cardAmount;
            }
            this.mainField.addStatus(startTime, endTime);
        } catch (final Exception ex) {
            log.warn("", ex);
        }

    }

    public long getErrorAmount() {
        return 0;
    }

    /**
     * @note: not close about reast service
     */
    @Override
    public synchronized void doExit() {
        // BAOJmsConsumer jmsConsumer = transferService.getJmsConnection();
        // if (jmsConsumer != null) {
        // jmsConsumer.close();
        // }
        this.transferService.close();
    }

    @Override
    public void setChangeCase(String[] changeCase) {
        this.changeCase = changeCase;
    }

    /**
     * @note add new code : if (vectorKDP == null) return ""; kdp_special =
     * vectorKDP.size() > 28;
     */
    private String getDataInKDP(String fieldName, boolean kdp_special, Map<String, String> vectorKDP) {
        if ((vectorKDP == null) || vectorKDP.isEmpty()) {
            return "";
        }
        // pvgiang_1 -13/07/2016- UPDATE: Remove fields which are removed. View Lookupkey.java for detail!
        if (fieldName.equals("firmenname")) {
            return Utilities.toString(vectorKDP.get(LookupKey.FIRMENNAME.getKey()));
        }
        if (fieldName.equals("vorname")) {
            return Utilities.toString(vectorKDP.get(LookupKey.VORNAME.getKey()));
        }
        if (fieldName.equals("name")) {
            return Utilities.toString(vectorKDP.get(LookupKey.NAME.getKey()));
        }
        if (fieldName.equals("namenszusatz")) {
            // return Utilities.toString(vectorKDP.get(LookupKey.NAMENSZUSATZ.getKey()));

            /**
             * Remove '|' between NAMESUZAT_1("pers_11_name3") and NAMENSZUSATZ
             */
            final String value = vectorKDP.get(LookupKey.NAMENSZUSATZ.getKey());

            if (value.indexOf(" | ") > 0) {
                return Utilities.toString(value.replace(" | ", " "));
            }

            return Utilities.toString(value);

        }
        if (fieldName.equals("plz")) {
            return Utilities.toString(vectorKDP.get(LookupKey.PLZ.getKey()));
        }
        if (fieldName.equals("ort")) {
            return Utilities.toString(vectorKDP.get(LookupKey.ORT.getKey()));
        }
        if (fieldName.equals("strasse")) {
            return Utilities.toString(vectorKDP.get(LookupKey.STRASSE.getKey()));
        }
        if (fieldName.equals("hausnummer")) {
            return Utilities.toString(vectorKDP.get(LookupKey.FULLHAUSNUMMER.getKey()));
        }
        if (fieldName.equals("postfachnummer")) {
            return Utilities.toString(vectorKDP.get(LookupKey.POSTFACHNUMMER.getKey()));
        }

        if (fieldName.equals("pickpostnummer")) {

            if (kdp_special) {
                // Update add data my post 24 into field pickpostnummer
                return Utilities.toString(vectorKDP.get(LookupKey.PICKPOST.getKey()));
            } else {
                return "";
            }
        }
        // need usser add size
        if (fieldName.equals("anrede")) {
            return Utilities.toString(vectorKDP.get(LookupKey.ANREDE.getKey()));
        }
        if (fieldName.equals("kdpid")) {
            return Utilities.toString(vectorKDP.get(LookupKey.KDP_ID.getKey()));
        }

        if (fieldName.equals("kdp_type")) {
            // *** Giang update kdp_type = PERS_08_TYP
            // TYPE equal 'P' is person, 'O' is office
            final String kdp_type = Utilities.toString(vectorKDP.get(LookupKey.PERS_08_TYP.getKey()));
            if (!kdp_special) {
                return kdp_type;
            }
            return "";
        }
        if (fieldName.equals("adr_type")) {
            // note use for address type in kdp special
            if (kdp_special) {
                return Utilities.toString(vectorKDP.get(LookupKey.PERS_08_TYP.getKey()));
            } else {
                return "";
            }
        }
        if (fieldName.equals("adr_id")) {
            return Utilities.toString(vectorKDP.get(LookupKey.ADR_ID.getKey()));
        }
        if (fieldName.equals("aadr_id")) {
            System.out.println("AADR_ID: " + Utilities.toString(vectorKDP.get(LookupKey.AADR_ID.getKey())));
            return Utilities.toString(vectorKDP.get(LookupKey.AADR_ID.getKey()));
        }
        if (fieldName.equals("postlagend")) {
            return "";
        }
        if (fieldName.equals(BLLDataStructure.HAUSKEY)) {
            log.debug("hauskey : " + Utilities.toString(vectorKDP.get(LookupKey.HAUSKEY.getKey())));
            return Utilities.toString(vectorKDP.get(LookupKey.HAUSKEY.getKey()));
        }

        if (fieldName.equals("streetnumber")) {
            log.debug("streetnumber : " + Utilities.toString(vectorKDP.get(LookupKey.STREETNUMBER.getKey())));
            return Utilities.toString(vectorKDP.get(LookupKey.STREETNUMBER.getKey()));
        }
        if (fieldName.equals(BLLDataStructure.MYPOST24)) {
            if (kdp_special) {
                String value = "";
                try {
                    //ignore kundennumber value if the kdp is domizil/postfach address
                    value = Utilities.toString(vectorKDP.get(LookupKey.IS_IGNORE_KUNDENNUMBER.getKey())).equalsIgnoreCase(Boolean.TRUE.toString()) ? StringUtils.EMPTY : Utilities.toString(vectorKDP.get(LookupKey.MY_POST_24.getKey()));
                } catch (final Exception ex) {
                }
                return value;
            } else {
                return "";
            }
        }
        return null;
    }

    private String checkContraint(String fieldName, String valueCheck, Card card) {
        final BLLCard bllCard = card.getCard();
        final BLLField field = bllCard.getField(fieldName);
        if ((field != null) && (field instanceof BLLAddressField)) {
            final String contraint = ((BLLAddressField) field).getConstraint();
            int changeCaseType = 0;
            try {
                changeCaseType = Integer.parseInt(Utilities.getdata_seperator(contraint, false, ";"));
            } catch (final NumberFormatException ex) {
                log.warn("", Utilities.getStackTrace(ex));
            } catch (final Exception ex) {
                log.warn("", Utilities.getStackTrace(ex));
            }
            valueCheck = this.changeCase(valueCheck, changeCaseType);
        }
        return valueCheck;
    }
    
    public boolean saveFirmenPLZ(String plz, String ort, MainFieldInterface main) {
    	log.info("Check Firmen-PLZ Card:### " + plz);
    	boolean isFirmenPlz = false;
    	String plz_And_ort = this.dal.checkFirmenPlz(plz, ort);
    	if (!plz_And_ort.equalsIgnoreCase("")) {
    		isFirmenPlz = true;
    		final Card card = main.getEntity();
    		log.info("[BLLSaveCard][export]-[COLLECTION:" + card.getCard().getManagementID()
    				 + "][SAVE]-process typist data");
    		 final String longTime = this.transferService.getCurrentTime();
    		 card.getCard().setEndTime(new Timestamp(Long.parseLong(longTime)));
    		 card.getCard().setUsername(this.user.getUserName());
    		 card.getCard().setStep(this.INPUTSTEP);
    		 log.info("[BLLSaveCard][export]-[COLLECTION:" + card.getCard().getManagementID()
    					+ "][SAVE]-add data from card to collection");
    		final Collection collection = Util.convertToFirmenPlzCollection(card.getCard(), card.getNeedTransfer(), plz_And_ort);
    		collection.getCollectionStatus().setCoderID(this.user.getUserName());
    		collection.getCollectionStatus().setCodingStation(this.CaptureUser);
    	}
    	return isFirmenPlz;
    }
}
