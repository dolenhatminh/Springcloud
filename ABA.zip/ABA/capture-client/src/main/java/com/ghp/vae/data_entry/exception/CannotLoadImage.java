package com.ghp.vae.data_entry.exception;

public class CannotLoadImage extends Exception {

	private static final long serialVersionUID = -7501958478038834456L;

	public CannotLoadImage(String string) {
		super(string);
	}
}
