package com.ghp.vae.data_entry.bll;

public class BLLDataStructure {
	// Node in the schema file
	public static final String NODE_VGCAPTURERESPONSE = "VGCaptureResponse";
	public static final String NODE_MSGHEADER = "MsgHeader";
	public static final String NODE_MESSAGEID = "MessageID";
	public static final String NODE_VERSION = "Version";
	public static final String NODE_PARCELDATA = "ParcelData";
	public static final String NODE_CODINGKEY = "CodingKey";
	public static final String NODE_CODINGDATE = "CodingDate";
	public static final String NODE_CODINGSITEID = "CodingSiteID";
	public static final String NODE_PRODUCERID = "ProducerID";
	public static final String NODE_SEQUENCENUMBER = "SequenceNumber";
	public static final String NODE_RECEIVERADDRESS = "ReceiverAddress";
	public static final String NODE_KDP_ID = "KDPID";
	public static final String NODE_PERSKDPID = "PersKDPId";
	public static final String NODE_PERSIBS = "PersIbs";
	public static final String NODE_ORTZIBS = "OrtzIbs";
	public static final String NODE_ORTZTYP = "OrtzTyp";

	public static final String NODE_ADDRESSTYPE = "AddressType";
	public static final String NODE_ADDRESSFIELD = "AddressField";
	public static final String NODE_ADDRESSFIELD_TYPEID = "TypeID";
	public static final String NODE_ADDRESSFIELD_TYPED = "Typed";
	public static final String NODE_ADDRESSFIELD_VALUE = "Value";
	public static final String NODE_MASTERDATA = "MasterData";
	public static final String NODE_MASTERDATA_TYPEID = "TypeID";
	public static final String NODE_MASTERDATA_VALUE = "Value";
	public static final String NODE_RESPONSECODE = "ResponseCode";

	// address field
	public static final String LOOKUP_FIELD = "lookup";
	public static final String ANREDE_FIELD = "anrede";
	public static final String NAME_FIELD = "name";
	public static final String VORNAME_FIELD = "vorname";
	public static final String NAMENSZUSATZ_FIELD = "namenszusatz";
	public static final String FIRMENNAME_FIELD = "firmenname";
	public static final String STRASSE_FIELD = "strasse";
	public static final String HAUSNUMMER_FIELD = "hausnummer";
	public static final String HAUSNUMMERZUSATZ_FIELD = "hausnummerzusatz";
	public static final String STOCKWERK_FIELD = "stockwerk";
	public static final String ADRESSZUSATZ_FIELD = "adresszusatz";
	public static final String CO_ADDRESSE_FIELD = "co_addresse";
	public static final String PLZ_FIELD = "plz";
	public static final String ORT_FIELD = "ort";
	public static final String LAND_FIELD = "land";
	public static final String POSTFACHNUMMER_FIELD = "postfachnummer";
	public static final String PICKPOSTNUMMER_FIELD = "pickpostnummer";
	public static final String POSTLAGEND_FIELD = "postlagend";

	// master field
	public static final String KDPID_FIELD = "kdpid";
	public static final String PERSIBS_FIELD = "PersIbs";
	public static final String ORTZIBS_FIELD = "OrtzIbs";
	public static final String ORTZTYP_FIELD = "OrtzTyp";
	public static final String ANREDEID_FIELD = "anredeid";
	public static final String ISOLANDCODE_FIELD = "isolandcode";
	public static final String ZUBO_PLZAID_FIELD = "zubo_plzaid";
	public static final String ZUBO_PLZID_FIELD = "zubo_plzid";
	public static final String ZUBO_LOKID_FIELD = "zubo_lokid";
	public static final String ZUBO_LOKAID_FIELD = "zubo_lokaid";
	public static final String ZUBO_LOKUID_FIELD = "zubo_lokuid";
	public static final String ZUBO_ADRID_FIELD = "zubo_adrid";
	public static final String ZUBO_AADRID_FIELD = "zubo_aadrid";
	public static final String ADDRESSTYPE_FIELD = "addresstype";
	public static final String RESPONSECODE_FIELD = "responsecode";
	public static final String AMP_STATUS = "ampstatus";
	public static final String HAUSKEY = "hauskey";
	public static final String PARCEL_HAUSKEY = "parcel_hauskey";
	public static final String MYPOST24 = "mypost24";

	public static final String ADR_ID = "adr_id";
	public static final String AADR_ID = "aadr_id";
}
