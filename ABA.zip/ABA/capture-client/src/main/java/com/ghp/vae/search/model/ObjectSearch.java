package com.ghp.vae.search.model;

import java.io.Serializable;

public class ObjectSearch implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "ObjectSearch [lookup=" + lookup + ", plz=" + plz + ", ort="
				+ ort + ", strasse=" + strasse + ", hausNummer=" + hausNummer
				+ ", pf=" + pf + ", pickpost=" + pickpost + ", mypost24="
				+ mypost24 + "]";
	}

	String lookup;
	String plz;
	String ort;
	String strasse;
	String hausNummer;
	String pf;
	String pickpost;
	String mypost24;

	public ObjectSearch() {
		super();
	}

	public ObjectSearch(String lookup, String plz, String ort, String strasse,
			String hausNummer, String pf, String pickpost, String mypost24) {
		super();
		this.lookup = lookup;
		this.plz = plz;
		this.ort = ort;
		this.strasse = strasse;
		this.hausNummer = hausNummer;
		this.pf = pf;
		this.pickpost = pickpost;
		this.mypost24 = mypost24;
	}

	public String getLookup() {
		return lookup;
	}

	public void setLookup(String lookup) {
		this.lookup = lookup;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getHausNummer() {
		return hausNummer;
	}

	public void setHausNummer(String hausNummer) {
		this.hausNummer = hausNummer;
	}

	public String getPf() {
		return pf;
	}

	public void setPf(String pf) {
		this.pf = pf;
	}

	public String getPickpost() {
		return pickpost;
	}

	public void setPickpost(String pickpost) {
		this.pickpost = pickpost;
	}

	public String getMypost24() {
		return mypost24;
	}

	public void setMypost24(String mypost24) {
		this.mypost24 = mypost24;
	}
}
