package com.ghp.vae.data_entry.gui;

import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;

class InfoPanel extends JPanel{
	private JLabel jlbUsername;
	private JLabel jlbSpeed;
	private JLabel jlKdpid;
	private JLabel jlPer;
	private JLabel jlbCardAmount;
	private JLabel jlbStatus;
	
	
	public InfoPanel() {
		initComponent();
		
	}

	private void initComponent() {
		initGui();
		
		jlbUsername.setFont(new Font("SansSerif", Font.PLAIN, 14));
		this.add(jlbUsername);
		jlbUsername.setBounds(10, 20, 140, 15);
		
		jlbSpeed.setFont(new Font("SansSerif", Font.PLAIN, 14));
		jlbSpeed.setText("Spd: 00.00");
		this.add(jlbSpeed);
		jlbSpeed.setBounds(160, 20, 90, 14);
		
		jlbStatus.setFont(new Font("SansSerif", Font.ITALIC, 14));
		jlbStatus.setText("Status:");
		this.add(jlbStatus);
		jlbStatus.setBounds(160, 50, 164, 15);
		
		jlbCardAmount.setFont(new Font("SansSerif", Font.PLAIN, 14));
		jlbCardAmount.setText("Card Amount: 0");
		this.add(jlbCardAmount);
		jlbCardAmount.setBounds(10, 50, 175, 15);
		
		jlKdpid = new JLabel();
		jlKdpid.setText("KDP ID: ");
		jlKdpid.setFont(new Font("SansSerif", Font.PLAIN, 14));
		jlKdpid.setBounds(272, 20, 203, 15);
		//Request: https://helpdesk.spsvietnam.vn/WorkOrder.do?woMode=viewWO&woID=10025&&fromListView=true
		jlKdpid.setVisible(false);
		this.add(jlKdpid);
		
		jlPer = new JLabel();
		jlPer.setText("Percent: ");
		jlPer.setFont(new Font("SansSerif", Font.PLAIN, 14));
		jlPer.setBounds(272, 50, 203, 15);
		this.add(jlPer);
	}


	private void initGui() {
		
		this.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 0, 11))); // NOI18N
		this.setAlignmentX(0.0F);
		this.setAlignmentY(0.0F);
		this.setFont(new java.awt.Font("Tahoma", 0, 10));
		this.setLayout(null);
		jlbUsername = new JLabel();
		jlbSpeed = new JLabel();
		jlKdpid = new JLabel();
		jlbCardAmount = new JLabel();
		jlbStatus = new JLabel();

	}

	public void setKdpid(String kdpid) {
		jlKdpid.setText("<html> <b>KDP ID</b>: <font color=red size =5><b>" + kdpid + "</b></font></html>");
	}


	public void setCardAmount(int cardAmount) {
		jlbCardAmount.setText("Card Amount:"+ cardAmount);
	}


	public void setSpeed(float speed, boolean warning) {
		DecimalFormat df = new DecimalFormat("0.00");
		jlbSpeed.setText("Spd: " + df.format(speed));
		if(warning){
			jlbSpeed.setForeground(Color.RED);
		}else{
			jlbSpeed.setForeground(Color.BLUE);
		}
		
	}


	public void showStatus(String status) {
		jlbStatus.setText(status);
	}

	public JLabel getJlKdpid() {
		return jlKdpid;
	}
	public void setUsername(String user){
		jlbUsername.setText(user);
	}


	public void setPercentCardGood(int percent) {
		jlPer.setText("Percent: " +percent);
	}
}
