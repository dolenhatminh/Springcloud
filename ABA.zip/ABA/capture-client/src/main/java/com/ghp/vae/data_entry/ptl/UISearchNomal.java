package com.ghp.vae.data_entry.ptl;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Event;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.regex.Pattern;

import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.KeyStroke;
import javax.swing.SwingWorker;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.CheckInput;
import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.ObjectInformation;
import com.ghp.vae.data_entry.face.StateCapture;
import com.ghp.vae.data_entry.ptl.state.CaptureMessage;

import net.java.balloontip.BalloonTip;
import net.java.balloontip.styles.BalloonTipStyle;
import net.java.balloontip.styles.EdgedBalloonStyle;
import vae.client.transfer.LookupKey;

/**
 * @author other Class using in view data from lookup db. fill data into fill is lookup.
 */
public class UISearchNomal extends JDialog implements ActionListener {

	private static final long serialVersionUID = 215877504251966234L;
	// public static final UISearchNomal singleton = new UISearchNomal();
	private static Logger log = LoggerFactory.getLogger(UISearchNomal.class);
	private static org.slf4j.Logger sloger = LoggerFactory.getLogger(UISearchNomal.class);

	MainFieldInterface parentFrame;
	private final int screen_lenx;
	private final int screen_leny;
	private JPanel jpMain;
	private Vector<String> tableTitleEx = null;
	private int searchType;
	private JTextField curJtf;
	private JButton jbtnPrevious = null;
	private JButton jbtnNext = null;
	private JLabel jlblAmountRecord = null;
	private JLabel jlblResult = null;
	private JLabel jlblRecordsDisplayed = null;
	private JScrollPane jsbData = null;
	private JTable jtData = null;
	private JButton jbtnSelect = null;
	private JButton jbtnCancel = null;
	private Vector<Vector<String>> bufferDataEx = null;
	private final int MAXROW = 9;
	private int curPage = 0;
	private int maxPage = 0;
	ModeForTable dTableModel = null;
	private JLabel jlblRecordPerPage = null;
	private JLabel jlblCurrPage = null;
	private JLabel jlblCurrentPage = null;
	private JPanel jpnlLabel = null;
	private JPanel jpnlButton = null;
	private JTextField jtfSelectedRow;
	public static final int searchKDP = 1;
	public static final int searchOther = 2;
	public static final int searchPlz = 5;
	public static final int searchStrasse = 3;
	public static final int searchOrt = 4;
	public JComponent nextFocusComp;
	private XTableColumnModel xTableColumnModel = null;
	JPopupMenu popup;
	// private BalloonTip rowTip = null;

	private List<Map<String, String>> dataArr;
	private LookupKey[] title;
	// Hoang add new ;
	ColorColumnRenderer normalRenderBlack;
	ColorColumnRenderer normalRenderBlue;
	ColorColumnRenderer normalRenderSpecial;
	private final WindowAdapter adapter = new WindowExcute();

	/***
	 *
	 * Constructor.
	 ***/
	private UISearchNomal(JFrame parent) {
		super(parent);
		this.setModal(true);
		final Rectangle rec = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice()
				.getDefaultConfiguration().getBounds();
		this.screen_leny = rec.height;
		this.screen_lenx = rec.width;
		this.initComponent();
		this.addUpdate();
		this.addActionListerning();
		this.addWindowListener(this.adapter);
	}

	private UISearchNomal() {
		this(null);
	}

	private void addUpdate() {
		this.dTableModel = new ModeForTable();
		this.normalRenderBlack = new ColorColumnRenderer(Color.BLACK, new Font("Tahoma", Font.PLAIN, 16), Color.WHITE);
		this.normalRenderBlue = new ColorColumnRenderer(Color.BLUE, new Font("Tahoma", Font.PLAIN, 17), Color.WHITE);
		this.normalRenderSpecial = new ColorColumnRenderer(new Color(139, 0, 139), new Font("Tahoma", Font.PLAIN, 17),
				Color.WHITE);
		this.xTableColumnModel = new XTableColumnModel();
	}

	public void viewResult() throws InterruptedException {
		final SwingWorker exWorker = new SwingWorker() {

			@Override
			protected Object doInBackground() throws Exception {
				UISearchNomal.this.initPageEx(UISearchNomal.this.dataArr, UISearchNomal.this.title);
				UISearchNomal.this.init2();
				UISearchNomal.this.initialize();
				UISearchNomal.this.parentFrame.setProcessStatus(false);
				UISearchNomal.this.jtData.revalidate();
				UISearchNomal.this.jsbData.getHorizontalScrollBar().setValue(0);
				UISearchNomal.this.jsbData.setColumnHeaderView(UISearchNomal.this.jtData.getTableHeader());
				UISearchNomal.this.jsbData.getColumnHeader().setViewPosition(new Point(0, 0));
				return null;
			}

			@Override
			protected void done() {
				UISearchNomal.this.setVisible(true);
			}
		};
		exWorker.execute();
	}

	@Override
	public void setVisible(boolean b) {
		// if(b){
		// addEvent();
		// addActionListerning();
		// }
		super.setVisible(b);
	}

	public void setCurrentJtf(JTextField currentField) {
		this.curJtf = currentField;
	}

	public void setNextFocus(JComponent nextFocus) {
		this.nextFocusComp = nextFocus;
	}

	public void setDataResult(List<Map<String, String>> data) {
		this.dataArr = data;
	}

	public void setParentMainFace(MainFieldInterface parent) {
		this.parentFrame = parent;
	}

	public void setTitle(LookupKey[] title) {
		this.title = title;
	}

	public void setSearchType(int searchType) {
		this.searchType = searchType;
	}

	public void clearData() {
		this.dataArr = null;
		this.title = null;
		this.searchType = 0;
		this.nextFocusComp = null;
		this.curJtf = null;
		this.isSelectKDPID = false;
		this.curPage = 0;
		this.maxPage = 0;
		this.totalSize = 0;
		this.bufferDataEx = null;
		this.splitPage.clear();
		this.jtData.clearSelection();
	}

	public void removeEvent() {

		//
		// for (WindowListener lister : this.getWindowListeners()){
		// this.removeWindowListener(lister);
		// }
		// if(jtData != null){
		// jtData.getActionMap().clear();
		// }

	}

	/**
	 * This method initializes this
	 *
	 */
	/**
	 * function update kdpid when select kdp id .
	 */

	private void updateKDPID() {
		if (this.searchKDP()) {
			// if (!isSelectKDPID) {
			// UISearchNomal.this.parentFrame.getEntity().setVectorKDP(null);
			// }

			UISearchNomal.this.parentFrame.displayToolTip();
			final ObjectInformation message = CaptureMessage.intance();
			message.clearData();
			message.setAction(StateCapture.UPDATE_KDP);
			UISearchNomal.this.parentFrame.request(message, UISearchNomal.this.parentFrame);
		}
	}

	private boolean searchKDP() {
		return this.searchType == searchKDP;
	}

	private void initialize() {
		this.setContentPane(this.jpMain);
	}

	private void addActionListerning() {
		final ActionMap am = this.jtData.getActionMap();
		am.put("Search_KDP_Ctrl_F", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (UISearchNomal.this.searchType == searchKDP) {
					log.debug("action find next kdp");
					final CaptureMessage message = CaptureMessage.intance();
					message.clearData();
					message.setAction(StateCapture.FIND_NEXT_KDP);
					UISearchNomal.this.parentFrame.request(message, UISearchNomal.this.parentFrame);
					UISearchNomal.this.sleepWhenClose();
					// setVisible(false);
					UISearchNomal.this.dispose();
				}
			}
		});
		final KeyStroke key = KeyStroke.getKeyStroke(KeyEvent.VK_F, Event.CTRL_MASK);
		final InputMap im = this.jtData.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
		im.put(key, "Search_KDP_Ctrl_F");
	}

	private void setEnableButton() {
		if ((this.curPage == 0) && (this.maxPage <= 1)) {
			this.jbtnPrevious.setEnabled(false);
			this.jbtnNext.setEnabled(false);
		} else {
			if ((this.curPage == 0) && (this.curPage < this.maxPage)) {
				this.jbtnPrevious.setEnabled(false);
				this.jbtnNext.setEnabled(true);
			} else {
				if ((this.curPage > 0) && (this.curPage >= this.maxPage - 1)) {
					this.jbtnPrevious.setEnabled(true);
					this.jbtnNext.setEnabled(false);
				} else {
					if ((this.curPage > 0) && (this.curPage < this.maxPage)) {
						this.jbtnPrevious.setEnabled(true);
						this.jbtnNext.setEnabled(true);
					}
				}
			}
		}
	}

	private final HashMap<Integer, Vector<Vector<String>>> splitPage = new HashMap<Integer, Vector<Vector<String>>>();
	private int totalSize;

	/**
	 * add data into map for get page keyIndex from 1 to end
	 */

	private void initPageEx(List<Map<String, String>> data, LookupKey[] title) {
		if (data == null) {
			return;
		}
		int index = 0;
		int currentPage = 0;
		this.totalSize = data.size();
		Vector<Vector<String>> rows = new Vector<Vector<String>>();
		for (final Map<String, String> mapData : data) {

			final Vector<String> row = new Vector<String>();

			for (int i = 0; i < title.length; i++) {
				row.add(mapData.get(title[i].getKey()));
			}

			rows.add(row);
			index++;
			if (index == this.MAXROW) {
				this.splitPage.put(new Integer(currentPage), rows);
				rows = new Vector<Vector<String>>();
				currentPage++;
				index = 0;
			}
		}
		if (index > 0) {
			this.splitPage.put(new Integer(currentPage), rows);
		}
		this.maxPage = this.splitPage.keySet().size();

		this.tableTitleEx = new Vector<String>();
		for (final LookupKey header : title) {
			this.tableTitleEx.add(header.getHeader());
		}
	}

	private Vector<Vector<String>> getRecords(Integer page) {
		return this.splitPage.get(page);
	}

	/**
	 * @param
	 * @return
	 * @throws InterruptedException
	 **/
	// private void init() throws InterruptedException {
	// initComponent();
	// setTableModel();
	// addActionListerning();
	// // showMouseOnTable();
	// setEnableButton();
	//
	// }

	private void init2() throws InterruptedException {
		// initComponent();
		this.setTableModel();
		this.setEnableButton();
		// addOlderEvent();
		this.updateRecordInformation();
	}

	private void updateRecordInformation() {
		this.jlblResult.setText(String.valueOf(this.totalSize));
		this.jlblCurrentPage.setText(String.valueOf((this.curPage + 1)));
		if (this.bufferDataEx != null) {
			final String tmp = String.valueOf(this.bufferDataEx.size()) + "/" + this.totalSize;
			this.jlblRecordsDisplayed.setText(tmp);
		}

	}

	/**
	 * @param
	 * @return
	 **/
	private void setTableModel() {
		try {
			this.bufferDataEx = (Vector<Vector<String>>) this.getRecords(this.curPage).clone();
			// dTableModel = new ModeForTable(bufferDataEx, tableTitleEx);
			this.xTableColumnModel.clearAllColumn();
			this.dTableModel.setDataVector(this.bufferDataEx, this.tableTitleEx);
			this.dTableModel.addColumn("No.");
			this.jtData.setModel(this.dTableModel);
			this.positionColumn(this.jtData, 0);

			if (this.jtData.getModel().getRowCount() != 0) {
				this.jtData.getSelectionModel().setSelectionInterval(0, 0);
			}
			// Set height for row.
			this.jtData.setRowHeight(29);

			// add value for first column
			this.addValueForFirstColunm();

			this.changeLocationAndSize();
			final int columNum = this.jtData.getColumnCount();
			if (columNum > 1 && columNum < 14) {
				this.jtData.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				final long w = Math.round(this.getBounds().getWidth() - 40) / (columNum - 1);
				final String sw = String.valueOf(w);
				for (int k = 0; k < columNum; k++) {
					final TableColumn column = this.jtData.getColumnModel().getColumn(k);
					if (k == 0) {
						column.setPreferredWidth(40);
					} else if (this.searchType == searchKDP && (k == 1 || k == 6)) {
						column.setPreferredWidth(Integer.valueOf((int) w * 3));
					} else if (this.searchType == searchKDP && (k == 2 || k == 3 || k == 5)) {
						column.setPreferredWidth(Integer.valueOf((int) w * 2));
					} else {
						column.setPreferredWidth(Integer.valueOf(sw));
					}
				}
			}
			if (columNum >= 10) {
				this.jtData.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				// xTableColumnModel = new XTableColumnModel();
				this.jtData.setColumnModel(this.xTableColumnModel);
				this.jtData.createDefaultColumnsFromModel();
				this.positionColumn(this.jtData, 0);
				this.addValueForFirstColunm();

				// Hidden field by comment below *** Hidden ***
				// for (int i = 18; i <= 20; i++) {
				// TableColumn column = xTableColumnModel.getColumnByModelIndex(i);
				// xTableColumnModel.setColumnVisible(column, false);
				// }

				this.xTableColumnModel.setColumnVisible(this.xTableColumnModel.getColumnByModelIndex(13), true);

				// fix width
				this.jtData.getColumnModel().getColumn(0).setPreferredWidth(25);// No. 0
				this.jtData.getColumnModel().getColumn(1).setPreferredWidth(300);// Firmenname 1
				this.jtData.getColumnModel().getColumn(2).setPreferredWidth(150);// Alias 2
				this.jtData.getColumnModel().getColumn(3).setPreferredWidth(140);// Vorname 3
				this.jtData.getColumnModel().getColumn(4).setPreferredWidth(180);// Name 4
				this.jtData.getColumnModel().getColumn(5).setPreferredWidth(220);// Namezuzat 5
				this.jtData.getColumnModel().getColumn(6).setPreferredWidth(60);// plz 6
				this.jtData.getColumnModel().getColumn(7).setPreferredWidth(170);// Ort 7
				this.jtData.getColumnModel().getColumn(8).setPreferredWidth(240);// Strasse 8
				this.jtData.getColumnModel().getColumn(9).setPreferredWidth(50);// Hausnumber 9
				this.jtData.getColumnModel().getColumn(10).setPreferredWidth(75);// Postfach 10
				this.jtData.getColumnModel().getColumn(11).setPreferredWidth(60);// ANREDE 11
				this.jtData.getColumnModel().getColumn(12).setPreferredWidth(115);// Stockwerk 12
				this.jtData.getColumnModel().getColumn(13).setPreferredWidth(100);// Kdp ID 13
				this.jtData.getColumnModel().getColumn(14).setPreferredWidth(50);// Ort set 14
				this.jtData.getColumnModel().getColumn(15).setPreferredWidth(100);// Strasse set 15
				this.jtData.getColumnModel().getColumn(16).setPreferredWidth(50);// Expire Date 16
				this.jtData.getColumnModel().getColumn(17).setPreferredWidth(50);// Start Date 17
				this.jtData.getColumnModel().getColumn(18).setPreferredWidth(0);// PERS_08_TYP 18 *** Hidden ***
				this.jtData.getColumnModel().getColumn(19).setPreferredWidth(0);// AMP_STATUS 19 *** Hidden ***
				this.jtData.getColumnModel().getColumn(20).setPreferredWidth(0);// HAUSKEY 20 *** Hidden ***
				this.jtData.getColumnModel().getColumn(21).setPreferredWidth(0);// LANDCODE 21 *** Hidden ***
				this.jtData.getColumnModel().getColumn(22).setPreferredWidth(0);// ADR_ID 22 *** Hidden ***
				this.jtData.getColumnModel().getColumn(23).setPreferredWidth(0);// ORTZTYP_FIELD 23 *** Hidden ***
				this.jtData.getColumnModel().getColumn(24).setPreferredWidth(0);// ORTZIBS_FIELD 24 *** Hidden ***
				this.jtData.getColumnModel().getColumn(25).setPreferredWidth(0);// PERSIBS_FIELD 25 *** Hidden ***
				this.jtData.getColumnModel().getColumn(26).setPreferredWidth(0);// CO_ADRESSE 26 *** Hidden ***
				this.jtData.getColumnModel().getColumn(27).setPreferredWidth(0);// ADDRESSZUSATZ 27 *** Hidden ***
				this.jtData.getColumnModel().getColumn(28).setPreferredWidth(0);// NAMESUZAT_1 28 *** Hidden ***

				for (int i = 0; i < this.jtData.getColumnCount(); i++) {
					this.jtData.getColumnModel().getColumn(i).setCellRenderer(this.normalRenderBlack);
				}

				this.jtData.getColumnModel().getColumn(13).setCellRenderer(this.normalRenderBlue);
				this.jtData.getColumnModel().getColumn(14).setCellRenderer(this.normalRenderSpecial);

			}
			this.jtData.revalidate();
			this.jtData.repaint();
			this.jtData.doLayout();
		} catch (final Exception ex) {
			log.error(Utilities.getStackTrace(ex));
		}
	}

	private void changeLocationAndSize() {
		final Frame frame = JOptionPane.getRootFrame();
		if (this.searchType == searchKDP) {
			final int pointX = frame.getLocation().x;
			this.setBounds(pointX, (this.screen_leny * 2 / 3) - 80, this.screen_lenx,
					((this.screen_leny + 200) / 3 - this.screen_leny / 20 + 15));
		} else if (this.searchType == searchStrasse) {
			this.setSize(this.screen_lenx / 2, this.screen_leny / 3 - this.screen_leny / 20 + 15);
			this.setLocationRelativeTo(frame);
		} else {
			this.setSize(this.screen_lenx / 3, this.screen_leny / 3 - this.screen_leny / 20 + 15);
			this.setLocationRelativeTo(frame);
		}
	}

	private void addValueForFirstColunm() {
		for (int i = 0; i < this.jtData.getModel().getRowCount(); i++) {
			this.jtData.getModel().setValueAt(i + 1, i, this.jtData.getColumnCount() - 1);
		}
	}

	/**
	 * Initialize component.
	 *
	 * @param
	 * @return
	 **/
	private void initComponent() {
		try {
			this.setTitle("Search");
			this.jpMain = new javax.swing.JPanel();
			this.jpMain.setLayout(new BorderLayout());
			this.setContentPane(this.jpMain);
			this.jpMain.setBackground(Color.cyan);
			this.jpMain.add(this.getJPanel(), java.awt.BorderLayout.SOUTH);
			this.jpMain.add(this.getJsbData(), java.awt.BorderLayout.CENTER);
			this.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
			this.setLocation(200, 50);
			this.pack();
		} catch (final Exception ex) {
			log.error("", ex);
		}
	}

	int kdpType = 0;

	/*
	 * 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 Firmenname(0)", "Vorname(1)
	 * ", "Name(2)", "Namenszusatz(3)", "Plz(4)", "Ort (5)", "Strasse(6)", "Hausnummer(7)", "Postfach(8)
	 * ", "Anrede(9)", "Addresszusatz(10)", "C/o adresse(11)", "Stockwerk(12)", "
	 * Kdp_id(13)", "Landcode(14)", "Pers_08_typ(15)", "pers_06_ibs(16)", "
	 * ortz_04_ibs(17)", "ortz_06_typ(18)", "namesuzat_1(19)", "adr_id(20)"
	 */
	private boolean isSelectKDPID = false;

	@SuppressWarnings("unchecked")
	private void setData2AddressInfo(int rowSelected) {
		// Store ocr value for logging
		final Map<Byte, String> ocrValues = new HashMap<Byte, String>();
		for (final Byte field : LogUtil.logFields) {
			final JTextField control = (JTextField) this.parentFrame.getComponent(field);
			ocrValues.put(field, control.getText());
		}

		int row;
		if (rowSelected < 0) {
			row = this.jtData.getSelectedRow();
		} else {
			row = rowSelected;
		}

		log.info("row selected: " + row);
		if (this.jtData.getModel().getRowCount() > 0) {
			String plz;
			switch (this.searchType) {
			case searchKDP:
				final Vector vectorData = (Vector) ((DefaultTableModel) this.jtData.getModel()).getDataVector()
						.get(row);

				final Map<String, String> map = new HashMap<String, String>(vectorData.size());

				for (int i = 0; i < this.title.length; i++) {
					map.put(this.title[i].getKey(), vectorData.get(i) == null ? null : vectorData.get(i).toString());
				}

				this.parentFrame.getEntity().getCard().setKdpSpecical(false);
				this.parentFrame.getEntity().setVectorKDP(map);
				this.parentFrame.getEntity().setHaveValueFromSearchKdp(true);
				this.isSelectKDPID = true;
				this.updateKDPID();
				break;
			case searchOther:
				if ("plz".equalsIgnoreCase(this.curJtf.getName())) {
					plz = Utilities.toString(this.jtData.getModel().getValueAt(row, 0));
					if (plz.length() > 4) {
						plz = plz.substring(0, 4);
					}
					this.curJtf.setText(plz);
				} else {
					this.curJtf.setText(this.jtData.getModel().getValueAt(row, 0).toString());
				}
				break;
			case searchStrasse:
				this.curJtf.setText(this.jtData.getModel().getValueAt(row, 0).toString());// strasse
				((JTextField) this.parentFrame.getComponent(MainFieldInterface.ORT))
						.setText(this.jtData.getModel().getValueAt(row, 1).toString());
				plz = Utilities.toString(this.jtData.getModel().getValueAt(row, 2));
				if (plz.length() > 4) {
					plz = plz.substring(0, 4);
				}
				((JTextField) this.parentFrame.getComponent(MainFieldInterface.PLZ)).setText(plz);
				break;
			case searchOrt:
				this.curJtf.setText(this.jtData.getModel().getValueAt(row, 0).toString());// ort
				plz = Utilities.toString(this.jtData.getModel().getValueAt(row, 1));
				if (plz.length() > 4) {
					plz = plz.substring(0, 4);
				}
				((JTextField) this.parentFrame.getComponent(MainFieldInterface.PLZ)).setText(plz);
				break;
			case searchPlz:// plz
				plz = Utilities.toString(this.jtData.getModel().getValueAt(row, 0));
				if (plz.length() > 4) {
					plz = plz.substring(0, 4);
				}
				this.curJtf.setText(plz);// plz
				((JTextField) this.parentFrame.getComponent(MainFieldInterface.ORT))
						.setText(this.jtData.getModel().getValueAt(row, 1).toString());
				break;
			}
		}

		// send to gray log
		LogUtil.logLookupResult(sloger, row, this.parentFrame, ocrValues);
		// End log
	}

	private void tblDataKeyPressed(java.awt.event.KeyEvent evt) {
		if (this.popup != null) {
			this.popup.setVisible(false);
		}

		if (evt.getKeyCode() == 27) {
			if (this.curJtf != null) {
				this.curJtf.requestFocus();
			}
			this.parentFrame.displayToolTip();
			this.sleepWhenClose();
			// setVisible(false);
			this.dispose();
		} else if (evt.getKeyCode() == 10) {
			this.setData2AddressInfo(-1);
			this.resetRequestfocus();
			this.sleepWhenClose();
			// setVisible(false);
			this.dispose();
		} else if (((evt.getKeyCode()) >= 97 && evt.getKeyCode() <= 105)
				|| ((evt.getKeyCode()) >= 49 && evt.getKeyCode() <= 57)) {
			final String selectedRow = this.jtfSelectedRow.getText();
			final int currentRow = this.jtData.getSelectedRow();
			if (selectedRow != null && !selectedRow.equals("") && selectedRow.equals("" + (currentRow + 1))) {
				this.setData2AddressInfo(-1);
				this.resetRequestfocus();
				this.sleepWhenClose();
				// setVisible(false);
				this.dispose();
			}
		} else if (evt.getKeyCode() == 37 && this.jbtnPrevious.isEnabled()) // left
		{
			this.goPrevious();
			this.displayRowTip(0);
			evt.consume();
		} else if (evt.getKeyCode() == 39 && this.jbtnNext.isEnabled()) // right
		{
			this.goNext();
			this.displayRowTip(0);
			evt.consume();
		} else if (evt.getKeyCode() == KeyEvent.VK_DOWN) {
			final int currentRow = this.jtData.getSelectedRow() + 1;
			if (currentRow >= 0 & currentRow < this.jtData.getRowCount()) {
				final String vorname = this.jtData.getModel().getValueAt(currentRow, 1).toString();
				// searchVornameSynonym(vorname);
				this.displayRowTip(currentRow);
			} else if (this.jtData.getRowCount() == 1) {
				final String vorname = this.jtData.getModel().getValueAt(0, 1).toString();
				// searchVornameSynonym(vorname);
				this.displayRowTip(0);
			}
		} else if (evt.getKeyCode() == KeyEvent.VK_UP) {
			final int currentRow = this.jtData.getSelectedRow() - 1;
			if (currentRow >= 0 & currentRow < this.jtData.getRowCount()) {
				final String vorname = this.jtData.getModel().getValueAt(currentRow, 1).toString();
				// searchVornameSynonym(vorname);
				this.displayRowTip(currentRow);
			} else if (this.jtData.getRowCount() == 1) {
				final String vorname = this.jtData.getModel().getValueAt(0, 1).toString();
				// searchVornameSynonym(vorname);
				this.displayRowTip(0);
			}
		}

	}

	/**
	 * Select event.
	 *
	 * @param java
	 *            .awt.event.ActionEvent evt.
	 * @return
	 **/
	private void btnSelectActionPerformed(java.awt.event.ActionEvent evt) {
		this.setData2AddressInfo(-1);
		this.resetRequestfocus();
		this.sleepWhenClose();
		// setVisible(false);
		this.dispose();
	}

	/**
	 * Cancel event.
	 *
	 * @param java
	 *            .awt.event.ActionEvent evt
	 * @return
	 **/
	private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {
		if (this.parentFrame.getEntity().getKdpType() != 1 && this.parentFrame.getEntity().getKdpType() != 2) {
			this.parentFrame.getEntity().setHaveValueFromSearchKdp(false);
		}
		this.resetRequestfocus();
		this.sleepWhenClose();
		// setVisible(false);
		this.dispose();
	}

	private void resetRequestfocus() {
		if (this.nextFocusComp != null) {
			if (this.nextFocusComp.isEnabled()) {
				this.nextFocusComp.requestFocus();
			}
		} else if (this.curJtf != null) {
			this.curJtf.requestFocus();
		}
	}

	/**
	 * This method initializes jbtnPrevious
	 *
	 * @return javax.swing.JButton
	 */
	private static String PREVIOUS = "previous";
	private static String NEXT = "next";
	private static String SELECT = "select";
	private static String CANCEL = "cancel";

	private JButton getJbtnPrevious() {
		if (this.jbtnPrevious == null) {
			this.jbtnPrevious = new JButton();
			this.jbtnPrevious.setText("<");
			this.jbtnPrevious.setActionCommand(PREVIOUS);
			this.jbtnPrevious.setMnemonic(',');
			this.jbtnPrevious.setBounds(new java.awt.Rectangle(7, 30, 45, 24));
			this.jbtnPrevious.addActionListener(this);
		}
		return this.jbtnPrevious;
	}

	/**
	 * This method initializes jbtnNext
	 *
	 * @return javax.swing.JButton
	 */
	private JButton getJbtnNext() {
		if (this.jbtnNext == null) {
			this.jbtnNext = new JButton();
			this.jbtnNext.setText(">");
			this.jbtnNext.setMnemonic('.');
			this.jbtnNext.setActionCommand(NEXT);
			this.jbtnNext.setBounds(new java.awt.Rectangle(55, 30, 45, 24));
			this.jbtnNext.addActionListener(this);
		}
		return this.jbtnNext;
	}

	/**
	 * This method initializes jsbData
	 *
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getJsbData() {
		if (this.jsbData == null) {
			this.jsbData = new JScrollPane();
			this.jsbData.setViewportView(this.getJtData());
		}
		return this.jsbData;
	}

	/**
	 * This method initializes jtfSelectedRow
	 *
	 * @return javax.swing.JTextField
	 */

	private JTextField getJtfSelectedRow() {
		if (this.jtfSelectedRow == null) {
			this.jtfSelectedRow = new JTextField();
			this.jtfSelectedRow.setBounds(new Rectangle(104, 32, 43, 21));
			this.jtfSelectedRow.setDocument(new CheckInput(3, 11));
			this.jtfSelectedRow.setBackground(Color.YELLOW);
			this.jtfSelectedRow.addKeyListener(new java.awt.event.KeyAdapter() {

				@Override
				public void keyReleased(java.awt.event.KeyEvent e) {
					final int selectedRow = Integer
							.valueOf(Utilities.checkInt(UISearchNomal.this.jtfSelectedRow.getText()));
					if (selectedRow > 0 && selectedRow <= UISearchNomal.this.jtData.getRowCount()) {
						UISearchNomal.this.jtData.setRowSelectionInterval(selectedRow - 1, selectedRow - 1);
					} else {
						UISearchNomal.this.jtData.setRowSelectionInterval(0, 0);
					}
					UISearchNomal.this.tblDataKeyPressed(e);
				}
			});
		}
		return this.jtfSelectedRow;
	}

	/**
	 * This method initializes jtData
	 *
	 * @return javax.swing.JTable
	 */
	@SuppressWarnings("serial")
	protected JTable getJtData() {
		if (this.jtData == null) {
			this.jtData = new JTable() {
				@Override
				public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
					final Component c = super.prepareRenderer(renderer, row, column);
					if (!this.isRowSelected(row)) {
						c.setBackground(row % 2 == 0 ? this.getBackground() : new Color(230, 230, 250));
					} else {
						c.setBackground(new Color(255, 222, 173));
						c.setFont(new Font("Tahoma", Font.BOLD, 16));
					}
					final JTableHeader header = super.getTableHeader();
					header.setFont(new Font("Tahoma", Font.BOLD, 16));
					return c;
				}
			};
			this.jtData.setSize(new java.awt.Dimension(390, 120));
			this.jtData.addKeyListener(new java.awt.event.KeyAdapter() {
				@Override
				public void keyPressed(java.awt.event.KeyEvent e) {
					UISearchNomal.this.tblDataKeyPressed(e);
					UISearchNomal.this.getDataFromKeyboard(e);
				}

			});
			this.jtData.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
				@Override
				public void valueChanged(ListSelectionEvent arg0) {

					if (UISearchNomal.this.jtData.getSelectedRow() > -1) {
						UISearchNomal.this.displayRowTip(UISearchNomal.this.jtData.getSelectedRow());
					}
				}
			});
		}
		return this.jtData;
	}

	/**
	 * This method initializes jbtnSelect
	 *
	 * @return javax.swing.JButton
	 */
	private JButton getJbtnSelect() {
		if (this.jbtnSelect == null) {
			this.jbtnSelect = new JButton();
			this.jbtnSelect.setText("Select");
			this.jbtnSelect.setMnemonic('S');
			this.jbtnSelect.setBounds(new java.awt.Rectangle(169, 30, 78, 24));
			this.jbtnSelect.setActionCommand(SELECT);
			this.jbtnSelect.addActionListener(this);
		}
		return this.jbtnSelect;
	}

	/**
	 * This method initializes jbtncancel
	 *
	 * @return javax.swing.JButton
	 */
	private JButton getJbtnCancel() {
		if (this.jbtnCancel == null) {
			this.jbtnCancel = new JButton();
			this.jbtnCancel.setText("Cancel");
			this.jbtnCancel.setMnemonic('C');
			this.jbtnCancel.setBounds(new java.awt.Rectangle(256, 30, 73, 24));
			this.jbtnCancel.setActionCommand(CANCEL);
			this.jbtnCancel.addActionListener(this);
		}
		return this.jbtnCancel;
	}

	private synchronized void goPrevious() {
		// String tmp = "0";
		this.curPage--;
		this.jlblCurrentPage.setText(String.valueOf((this.curPage + 1)));
		this.updateTable(this.curPage);
	}

	private void updateTable(int curPage) {

		this.bufferDataEx = (Vector<Vector<String>>) this.getRecords(curPage).clone();
		this.dTableModel.getDataVector().clear();
		this.jtData.clearSelection();
		for (final Vector<String> tmp : this.bufferDataEx) {
			this.dTableModel.addRow(tmp);
		}
		if (this.jtData.getModel().getRowCount() != 0) {
			this.jtData.getSelectionModel().setSelectionInterval(0, 0);
		}
		for (int i = 0; i < this.jtData.getRowCount(); i++) {
			this.jtData.setValueAt(i + 1, i, 0);
		}
		this.setEnableButton();
		if (this.bufferDataEx != null) {
			final String tmp = String.valueOf(this.bufferDataEx.size()) + "/" + this.totalSize;
			this.jlblRecordsDisplayed.setText(tmp);
		}
	}

	private synchronized void goNext() {
		this.jtData.requestFocus();
		this.curPage += 1;
		this.jlblCurrentPage.setText(String.valueOf((this.curPage + 1)));
		this.updateTable(this.curPage);
	}

	/**
	 * This method initializes jpnlLabel
	 *
	 * @return javax.swing.JPanel
	 */
	private JPanel getJpnlLabel() {
		if (this.jpnlLabel == null) {
			this.jpnlLabel = new JPanel();
			this.jpnlLabel.setLayout(null);
			this.jpnlLabel.setBounds(new java.awt.Rectangle(-2, 4, 354, 23));
			this.jlblCurrentPage = new JLabel();
			this.jlblCurrentPage.setBounds(new java.awt.Rectangle(156, 1, 17, 23));
			this.jlblCurrentPage.setText("1");
			this.jlblCurrPage = new JLabel();
			this.jlblCurrPage.setBounds(new java.awt.Rectangle(85, 1, 69, 23));
			this.jlblCurrPage.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 10));
			this.jlblCurrPage.setText("Current page");
			this.jlblRecordPerPage = new JLabel();
			this.jlblRecordPerPage.setBounds(new java.awt.Rectangle(174, 1, 108, 23));
			this.jlblRecordPerPage.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 10));
			this.jlblRecordPerPage.setText("Current records/Total");
			this.jlblRecordsDisplayed = new JLabel();
			this.jlblRecordsDisplayed.setBounds(new java.awt.Rectangle(283, 1, 48, 23));
			this.jlblRecordsDisplayed.setText("");
			this.jlblResult = new JLabel();
			this.jlblResult.setBounds(new java.awt.Rectangle(49, 1, 34, 23));
			this.jlblResult.setText("0");
			this.jlblResult.setText(String.valueOf(this.totalSize));
			this.jlblAmountRecord = new JLabel();
			this.jlblAmountRecord.setBounds(new java.awt.Rectangle(5, 1, 40, 23));
			this.jlblAmountRecord.setText("Result");
			this.jpnlLabel.add(this.jlblAmountRecord, null);
			this.jpnlLabel.add(this.jlblResult, null);
			this.jpnlLabel.add(this.jlblRecordsDisplayed, null);
			this.jpnlLabel.add(this.jlblRecordPerPage, null);
			this.jpnlLabel.add(this.jlblCurrPage, null);
			this.jpnlLabel.add(this.jlblCurrentPage, null);
		}
		return this.jpnlLabel;
	}

	/**
	 * This method initializes jPanel
	 *
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel() {
		if (this.jpnlButton == null) {
			this.jpnlButton = new JPanel();
			this.jpnlButton.setLayout(null);
			this.jpnlButton.setPreferredSize(new java.awt.Dimension(1, 60));
			this.jpnlButton.add(this.getJbtnPrevious(), null);
			this.jpnlButton.add(this.getJbtnNext(), null);
			this.jpnlButton.add(this.getJbtnSelect(), null);
			this.jpnlButton.add(this.getJbtnCancel(), null);
			this.jpnlButton.add(this.getJpnlLabel(), null);
			this.jpnlButton.add(this.getJtfSelectedRow(), null);
		}
		return this.jpnlButton;
	}

	private void positionColumn(JTable table, int col_Index) {
		table.moveColumn(table.getColumnCount() - 1, col_Index);
	}

	private class ModeForTable extends javax.swing.table.DefaultTableModel {

		private static final long serialVersionUID = 1L;

		public ModeForTable(Vector<Vector<String>> rows, Vector headerColumns) {
			super(rows, headerColumns);
		}

		public ModeForTable() {
			super();
		}

		@Override
		public boolean isCellEditable(int row, int column) {
			return false;
		}
	}

	private void getDataFromKeyboard(java.awt.event.KeyEvent evt) {
		switch (evt.getKeyCode()) {
		case KeyEvent.VK_1:
		case KeyEvent.VK_NUMPAD1:
			this.selectDataAddress(0);
			break;
		case KeyEvent.VK_2:
		case KeyEvent.VK_NUMPAD2:
			this.selectDataAddress(1);
			break;
		case KeyEvent.VK_3:
		case KeyEvent.VK_NUMPAD3:
			this.selectDataAddress(2);
			break;
		case KeyEvent.VK_4:
		case KeyEvent.VK_NUMPAD4:
			this.selectDataAddress(3);
			break;
		case KeyEvent.VK_5:
		case KeyEvent.VK_NUMPAD5:
			this.selectDataAddress(4);
			break;
		case KeyEvent.VK_6:
		case KeyEvent.VK_NUMPAD6:
			this.selectDataAddress(5);
			break;
		case KeyEvent.VK_7:
		case KeyEvent.VK_NUMPAD7:
			this.selectDataAddress(6);
			break;
		case KeyEvent.VK_8:
		case KeyEvent.VK_NUMPAD8:
			this.selectDataAddress(7);
			break;
		case KeyEvent.VK_9:
		case KeyEvent.VK_NUMPAD9:
			this.selectDataAddress(8);
			break;
		case KeyEvent.VK_HOME:
			this.goHome();
			break;
		case KeyEvent.VK_END:
			this.goEnd();
			break;
		case KeyEvent.VK_ESCAPE:
			// if (parentFrame.getEntity().getKdpType() != 1 &&
			// parentFrame.getEntity().getKdpType() != 2) {
			// this.parentFrame.getEntity().clearValue();
			// .setHaveValueFromSearchKdp(false);
			// this.parentFrame.getEntity().setAdr_id(0);
			// this.parentFrame.getEntity().getCard().getField(BLLDataStructure.ZUBO_ADRID_FIELD).setValue("");
			// }
			break;
		}
	}

	private synchronized void goHome() {
		this.jtData.requestFocus();
		this.curPage = 0;
		this.jlblCurrentPage.setText(String.valueOf((this.curPage + 1)));
		this.updateTable(this.curPage);

	}

	private synchronized void goEnd() {
		this.jtData.requestFocus();
		this.curPage = this.maxPage - 1;
		this.jlblCurrentPage.setText(String.valueOf((this.curPage + 1)));
		this.updateTable(this.curPage);
	}

	// public void searchVornameSynonym(String vorname) throws IllegalComponentStateException {
	// try {
	// FileInputStream fstream = new FileInputStream(ApplicationConfig.VORNAME_SYNONYM_FILEPATH);
	// DataInputStream in = new DataInputStream(fstream);
	// BufferedReader br = new BufferedReader(new InputStreamReader(in));
	// String strLine;
	// DefaultListModel model = new DefaultListModel();
	//
	// // Read File Line By Line
	// while ((strLine = br.readLine()) != null) {
	// String[] tmp = strLine.split("\\;");
	//
	// for (int i = 0; i < tmp.length; i++) {
	// if (vorname.equals(tmp[i])) {
	// for (int j = 0; j < tmp.length; j++) {
	// model.addElement(tmp[j]);
	// }
	// break;
	// }
	// }
	//
	// }
	// in.close();
	//
	// popup = new JPopupMenu();
	// JList jList = new JList();
	// jList.setModel(model);
	// popup.add(jList);
	// popup.setFocusable(false);
	//
	// if (model.size() > 0) {
	// // System.out.println("Show Popup");
	// popup.show(jtData, 190, -185);
	// } else {
	// // System.out.println("Disable Popup");
	// popup.show(jtData, 0, 100);
	// }
	//
	// } catch (Exception e) {
	//
	// }
	//
	// }

	private class ColorColumnRenderer extends DefaultTableCellRenderer {
		private static final long serialVersionUID = 3808450006624702167L;
		Color fgndColor;
		Font font;
		Color bgColor;

		public ColorColumnRenderer(Color foregnd, Font f, Color bg) {
			super();
			this.fgndColor = foregnd;
			this.font = f;
			this.bgColor = bg;
		}

		@Override
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
				int row, int column) {
			final Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
			cell.setForeground(this.fgndColor);
			cell.setFont(this.font);
			cell.setBackground(this.bgColor);
			return cell;
		}
	}

	private BalloonTip rowTip = null;

	protected void displayRowTip(int rowIndex) {
		if (this.jtData.getColumnCount() > 10) {

			final int FIRMEN_NAME = 1;
			final int ALIAS = 2;
			final int VORNAME = 3;
			final int NAME = 4;
			final int NAMENSZUSATZ = 5;
			final int PLZ = 6;
			final int ORT = 7;
			final int STRASSE = 8;
			final int HAUS = 9;
			final int POSTFACH = 10;
			final int MYPOST24 = 11;
			final int PICKPOST = 12;

			if (this.rowTip != null) {
				this.rowTip.setVisible(false);
			}

			final JPanel pnlTip = new JPanel();
			pnlTip.setBackground(Color.WHITE);

			final JTextPane pane = new JTextPane();

			// Firmenname
			final Object firmenname = this.jtData.getValueAt(rowIndex, FIRMEN_NAME);
			if (firmenname != null && firmenname.toString().length() > 0) {
				this.appendToPane(pane, firmenname.toString() + "\n", Color.BLACK);
			}

			// alias
			final Object alias = this.jtData.getValueAt(rowIndex, ALIAS);
			if (alias != null && alias.toString().length() > 0) {
				final List<String> arrAlias = Arrays.asList(alias.toString().split(Pattern.quote("|")));

				final StringBuilder builder = new StringBuilder();
				StringBuilder limitChar = new StringBuilder();

				final String separator = System.getProperty("line.separator");

				for (final String item : arrAlias) {
					// Verify length too long
					limitChar.append(item).append("|");

					if (limitChar.toString().length() < 50) {
						builder.append(item).append("|");
					} else {
						// reset limit
						limitChar = new StringBuilder();
						limitChar.append(item).append("|");

						builder.append(separator).append(item).append("|");
					}

				}

				final String strAlias = builder.replace(builder.length() - 1, builder.length(), "").toString()
						.replace("|" + separator, separator);

				this.appendToPane(pane, strAlias + "\n", Color.RED);
			}

			// namenszusatz
			final Object namenszusatz = this.jtData.getValueAt(rowIndex, NAMENSZUSATZ);
			if (namenszusatz != null && namenszusatz.toString().length() > 0) {
				this.appendToPane(pane, namenszusatz.toString() + "\n", Color.BLACK);
			}

			// vorname
			final Object vorname = this.jtData.getValueAt(rowIndex, VORNAME);
			if (vorname != null && vorname.toString().length() > 0) {
				this.appendToPane(pane, vorname.toString() + " ", Color.BLACK);
			}

			// name
			final Object name = this.jtData.getValueAt(rowIndex, NAME);
			if (name != null && name.toString().length() > 0) {
				this.appendToPane(pane, name.toString(), Color.BLACK);
			}

			/*** Break line */
			if ((vorname != null && vorname.toString().length() > 0)
					|| (name != null && name.toString().length() > 0)) {
				this.appendToPane(pane, "\n", Color.BLACK);
			}

			// MyPost24
			final Object mypost24 = this.jtData.getValueAt(rowIndex, MYPOST24);
			if (mypost24 != null && mypost24.toString().length() > 0) {
				final String strMyPost24 = this.jtData.getColumnName(MYPOST24) + " - " + mypost24.toString();
				this.appendToPane(pane, strMyPost24, Color.BLACK);
				this.appendToPane(pane, "\n", Color.BLACK);
			}

			// Postfach
			final Object postfach = this.jtData.getValueAt(rowIndex, POSTFACH);
			if (postfach != null && postfach.toString().trim().length() > 0) {
				this.appendToPane(pane, "Postfach " + this.jtData.getValueAt(rowIndex, POSTFACH) + "\n", Color.BLACK);
			}

			// Strasse
			final Object strasse = this.jtData.getValueAt(rowIndex, STRASSE);
			if (strasse != null && strasse.toString().length() > 0) {
				this.appendToPane(pane, strasse.toString() + " ", Color.BLACK);
			}

			// Haus
			final Object haus = this.jtData.getValueAt(rowIndex, HAUS);
			if (haus != null && haus.toString().length() > 0) {
				this.appendToPane(pane, haus.toString(), Color.BLACK);
			}

			/*** Break line */
			if ((postfach != null && postfach.toString().trim().length() > 0)
					|| (strasse != null && strasse.toString().length() > 0)
					|| (haus != null && haus.toString().length() > 0)) {
				this.appendToPane(pane, "\n", Color.BLACK);
			}

			// PLZ
			final Object plz = this.jtData.getValueAt(rowIndex, PLZ);
			if (plz != null && plz.toString().length() > 4) {
				this.appendToPane(pane, this.jtData.getValueAt(rowIndex, PLZ).toString().substring(0, 4) + " ",
						Color.BLACK);
			}

			// Ort
			final Object ort = this.jtData.getValueAt(rowIndex, ORT);
			if (ort != null && ort.toString().length() > 0) {
				this.appendToPane(pane, ort.toString(), Color.BLACK);
			}

			/*** Break line */
			if ((plz != null && plz.toString().length() > 4) || (ort != null && ort.toString().length() > 0)) {
				this.appendToPane(pane, "\n", Color.BLACK);
			}

			// Pickpost
			final Object pickpost = this.jtData.getValueAt(rowIndex, PICKPOST);

			if (pickpost != null && pickpost.toString().length() > 0) {
				final String strPickpost = this.jtData.getColumnName(PICKPOST) + " - " + pickpost.toString();
				this.appendToPane(pane, strPickpost, Color.BLACK);
			}

			pnlTip.add(pane);

			this.rowTip = new BalloonTip((JComponent) this.parentFrame.getComponent(MainFieldInterface.IMAGE_VIEW),
					pnlTip, this.createBalloonTipStyle(), BalloonTip.Orientation.RIGHT_BELOW,
					BalloonTip.AttachLocation.NORTHWEST, 0, 0, true);
		}
	}

	protected BalloonTipStyle createBalloonTipStyle() {
		return new EdgedBalloonStyle(Color.white, Color.blue);
	}

	private void appendToPane(JTextPane tp, String msg, Color c) {
		final StyleContext sc = StyleContext.getDefaultStyleContext();
		AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

		aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Tahoma");
		aset = sc.addAttribute(aset, StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED);
		aset = sc.addAttribute(aset, StyleConstants.FontSize, 18);
		aset = sc.addAttribute(aset, StyleConstants.Bold, false);

		final int len = tp.getDocument().getLength();
		tp.setCaretPosition(len);
		tp.setCharacterAttributes(aset, false);
		tp.replaceSelection(msg);
	}

	private void checkInterrupted(String message) throws InterruptedException {
		if (Thread.interrupted()) {
			throw new InterruptedException(message);
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		final String command = e.getActionCommand();
		if (command.equals(PREVIOUS)) {
			this.goPrevious();
		} else if (command.equals(NEXT)) {
			this.goNext();
		} else if (command.equals(SELECT)) {
			this.btnSelectActionPerformed(e);
		} else if (command.equals(CANCEL)) {
			this.btnCancelActionPerformed(e);
		}

	}

	private void sleepWhenClose() {
		try {
			Thread.sleep(100);
		} catch (final InterruptedException ie) {
			log.warn("", ie);
		}
	}

	private void selectDataAddress(int index) {
		this.setData2AddressInfo(index);
		this.sleepWhenClose();
		this.setVisible(false);
		this.dispose();
	}

	private class WindowExcute extends WindowAdapter {
		@Override
		public void windowOpened(WindowEvent e) {
			if (UISearchNomal.this.searchType == searchKDP) {
				UISearchNomal.this.displayRowTip(0);
			}
		}

		@Override
		public void windowClosed(WindowEvent e) {
			UISearchNomal.this.removeEvent();
			if (UISearchNomal.this.rowTip != null) {
				UISearchNomal.this.rowTip.setVisible(false);
			}
			if (UISearchNomal.this.searchKDP()) {
				log.info("Event close search ui");
				final CaptureMessage information = CaptureMessage.intance();
				information.clearData();
				information.setAction(StateCapture.SEARCH_GUI_CLOSE);
				UISearchNomal.this.parentFrame.request(information, UISearchNomal.this.parentFrame);
			}
		}
	}

	public static UISearchNomal intance() {
		return new UISearchNomal();
	}

	public static UISearchNomal intance(JFrame parent) {
		return new UISearchNomal(parent);
	}

}
