package com.ghp.vae.data_entry.ptl.autocomplete;

import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPopupMenu;
import javax.swing.plaf.TextUI;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

import org.apache.commons.collections.KeyValue;
import org.apache.commons.collections.keyvalue.DefaultKeyValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.ptl.autocomplete.service.dto.ItemSearchResult;
import com.sps.vn.config.ApplicationConfig;
import com.ghp.vae.search.service.IWordSuggestionService;
import com.ghp.vae.search.service.impl.WordSuggestionServiceImpl;

//not use db lookup.
/**
 * Request ID : 1328 [VAE]Suggestion words
 *
 * @author lqbinh
 *
 */
public class AutoTextFieldSuggestionService extends CustomTextField implements
        AutoTextFieldInterface, LearningInterface {

    /**
     * this is component using for text box have to suggestion auto suggestion,
     * word suggestion.
     */
    private static final long serialVersionUID = 1L;
    private static Logger log = LoggerFactory.getLogger("GUI");
    private JList jList;
    private JPopupMenu jPopupMenu;

    private DefaultListModel lookupModel;
    boolean isAutoComplete = true;
    java.awt.event.KeyEvent keyPressed;
    private AutoTextFieldDataSourceInf dataSource;
    IWordSuggestionService aci;

    public AutoTextFieldSuggestionService() {
        aci = new WordSuggestionServiceImpl();
        jList = new JList();
        jPopupMenu = new JPopupMenu() {
            @Override
            public void setVisible(boolean b) {
                try {
                    AutoTextFieldSuggestionService.this
                            .setFocusTraversalKeysEnabled(!b);
                    super.setVisible(b);
                } catch (Exception ex) {
                    log.error("", ex);
                } finally {
                    if (!b) {
                        AutoTextFieldSuggestionService.this.requestFocus();

                    }
                }
            }
        };
        jPopupMenu.setFocusable(false);
        jList.setFocusTraversalKeysEnabled(false);
        jList.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_TAB) {
                    jPopupMenu.setVisible(false);
                    AutoTextFieldSuggestionService.this.transferFocusDownCycle();
                    e.consume();
                }
            }
        });
        dataSource = null;
        init();
    }

    public void setDataSource(AutoTextFieldDataSourceInf ds) {
        this.dataSource = ds;
    }

    private void init() {
        try {
            this.delayTime = ApplicationConfig.getInstance().getBusinessConfig().getDelaySuggestion();
        } catch (Exception e) {
            this.delayTime = 300;
        }
        this.delayTime = delayTime - 100;

        this.setDocument(new AutoDocument());

        this.addKeyListener(new java.awt.event.KeyAdapter() {

            @Override
            public void keyTyped(KeyEvent evt) {
                if (!jPopupMenu.isVisible()) {
                    return;
                }
                if (evt.getKeyCode() == KeyEvent.VK_DOWN) {
                    jList.requestFocus();
                    evt.consume();
                }
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt) {
                if (getText().indexOf("*") != -1
                        || getText().indexOf("_") != -1
                        || evt.getKeyChar() == '*' || evt.getKeyChar() == '_') {
                    /**
                     * remove because this is split work *
                     */
                    isAutoComplete = false;
                } else {
                    isAutoComplete = true;
                }
                if (evt.getKeyCode() == KeyEvent.VK_DOWN) {
                    jList.requestFocus();
                    evt.consume();

                } else if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                    if (jPopupMenu.isVisible()) {
                        jPopupMenu.setVisible(false);
                        AutoTextFieldSuggestionService.this.transferFocus();
                    }
                } else if (evt.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
                } else if (evt.getKeyCode() == KeyEvent.VK_TAB) {
                    jPopupMenu.setVisible(false);
                    AutoTextFieldSuggestionService.this
                            .transferFocusDownCycle();
                } else if (evt.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    setDbSearch(false);
                    jPopupMenu.setVisible(false);
                }
                keyPressed = evt;
            }
        });
        jPopupMenu.setBackground(new java.awt.Color(204, 255, 204));
        jList.setBackground(new java.awt.Color(204, 255, 204));
        jList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jList.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyPressed(java.awt.event.KeyEvent evt) {
                if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                    KeyValue tmp = (KeyValue) jList.getSelectedValue();
                    if (tmp != null) {
                        changeWordSuggestion(tmp.getKey().toString(),
                                jList.getSelectedIndex());
                    }
                    jPopupMenu.setVisible(false);
                } else if (evt.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    setDbSearch(false);
                    jPopupMenu.setVisible(false);
                } else if (evt.getKeyCode() == 40 || evt.getKeyCode() == 38) {
                    //jList.requestFocus();
                    // TODO
                }
            }
        });
        jList.setCellRenderer(new SuggestionCellRenderer());
        jPopupMenu.add(jList);
        jList.setAutoscrolls(true);
        jPopupMenu.setAutoscrolls(true);
    }

    String outDate;
    private boolean dbSearch = true; // this is status use datasource or server
    // suggestion.

    private void getMatch(String s) {
        if (s.isEmpty()) {
            jPopupMenu.setVisible(false);
            return;
        }
        List<KeyValue> tmp = null;
        if (getDbSearch()) {
            if (dataSource != null) {
                if (s.contains("%")) {
                } else {
                    tmp = dataSource.getDataSource(s);
                }
                if (tmp.isEmpty()) {
                    setDbSearch(false);
                }
            }
        }

        if (!getDbSearch()) {
            tmp = wordSuggestion(s);
        }
        if (tmp == null || tmp.isEmpty()) {
            jPopupMenu.setVisible(false);
            return;
        }
        lookupModel = new DefaultListModel();
        for (KeyValue data : tmp) {
            lookupModel.addElement(data);
        }
        jList.setModel(lookupModel);
        jPopupMenu.add(jList);
        jList.setSelectedIndex(0);
        if (this.isFocusOwner()) {
            if (jPopupMenu.isVisible()) {
                jPopupMenu.pack();
            }
            if (!getDbSearch()) {
                String currentWord = this.getText();
                int x = getMinWord(currentWord, index);
                x = x < 0 ? 0 : x + 1;
                int point = 0;
                // int x = this.getCaretPosition();
                TextUI mapper = this.getUI();
                try {
                    Rectangle p0 = mapper.modelToView(this, x);
                    Rectangle p1 = this.getBounds();
                    point = p0.x;
                } catch (BadLocationException e) {
                }
                jPopupMenu.show(this, point, this.getBounds().height);
            } else {
                jPopupMenu.show(this, 0, this.getBounds().height);
            }
            jPopupMenu.updateUI();
            jList.setVisibleRowCount(5);
        }

    }

    private List<KeyValue> wordSuggestion(String s) {
        if (index < 0) {
            return null;
        }
        String needSuggest = getWordSuggest(s, index);
        if (needSuggest.isEmpty()) {
            return null;
        }
        List<ItemSearchResult> results;
        try {
            results = aci.suggest(needSuggest);
            if (results == null || results.isEmpty()) {
                return null;
            }
            List<KeyValue> tmp = new ArrayList<KeyValue>();
            for (ItemSearchResult result : results) {
                tmp.add(new DefaultKeyValue(result.getValue(), null));
            }
            return tmp;
        } catch (Exception e) {
            log.error("", e);
            return null;
        }
    }

    /**
     * get word from index to character ' ' with
     *
     * @param s
     * @param index2
     * @return
     */
    private String getWordSuggest(String s, int index) {
        int min = getMinWord(s, index);
        min = min > 0 ? min + 1 : 0;
        try {
            return s.substring(min, index);
        } catch (Exception e) {
        }
        return "";

    }

    private boolean isSetText;

    @Override
    public void setText(String value) {
        if (value.isEmpty()) {
            setDbSearch(true);
        }

        isSetText = true;
        super.setText(value);
    }

    // @Override
    // public void replaceSelection(String s) {
    // AutoDocument _lb = (AutoDocument) this.getDocument();
    // if (_lb != null) {
    // try {
    // int i = Math.min(this.getCaret().getDot(), this.getCaret().getMark());
    // int j = Math.max(this.getCaret().getDot(), this.getCaret().getMark());
    // _lb.replace(i, j - i, s, null);
    // } catch (Exception exception) {
    // log.error(Utilities.getStackTrace(exception));
    // }
    // }
    // }
    public void setConstraint(int maxLength, String invalidCharacter) {
        try {
            setDocument(new AutoDocument(maxLength, invalidCharacter));
        } catch (Exception ex) {
            log.error(Utilities.getStackTrace(ex));
        }
    }

    class AutoDocument extends PlainDocument {

        private static final long serialVersionUID = 1L;
        private int maxLength = 0;
        private String invalidCharacter = "";

        public AutoDocument() {
            maxLength = 0;
            invalidCharacter = "";
        }

        public AutoDocument(int maxlength, String sOption) {
            this.maxLength = maxlength;
            this.invalidCharacter = sOption;
        }

        @Override
        public void replace(int i, int j, String s, AttributeSet attributeset)
                throws BadLocationException {
            super.remove(i, j);
            insertString(i, s, attributeset);
            isSetText = false;
        }

        @Override
        public void insertString(int offset, String insertCharacter,
                AttributeSet attributeset) throws BadLocationException {

            changeBackGround(false);
            if (insertCharacter == null || "".equals(insertCharacter)) {
                return;
            }
            String wordPass = insertCharacter;
            if (getDbSearch() && offset != this.getLength()) { // insert o vi
                // tri khac
                setDbSearch(false);
            }
            if (maxLength > 0 && !invalidCharacter.equals("")) {
                wordPass = checkContraintForInsert(insertCharacter, this
                        .getEndPosition().getOffset());
                if (!wordPass.isEmpty()) {
                    super.insertString(offset, wordPass, attributeset);
                }
            } else {
                super.insertString(offset, wordPass, attributeset);
            }

            if (!isAutoComplete) {
                if (jPopupMenu.isShowing()) {
                    jPopupMenu.setVisible(false);
                }
            } else if (isSetText) {
                isSetText = false;
            } else {
                suggestion(offset + wordPass.length());
            }
        }

        /**
         * function check length and contraint can use in field.
         *
         * @param s
         * @param textlength
         * @return String have use.
         */
        private String checkContraintForInsert(String s, int textlength) {
            String tmp = "";
            if (textlength <= this.maxLength) {
                int remain = maxLength - textlength;
                int count = 0;
                char[] addedFigures = s.toCharArray();
                char c;
                for (int z = 0; tmp.length() < this.maxLength
                        && z < addedFigures.length; z++) {
                    c = addedFigures[z];
                    if (!Utilities.inString(invalidCharacter, c)) {
                        tmp = tmp + c;
                        count++;
                        if (count > remain) {
                            break;
                        }
                    }
                }
            }
            return tmp;
        }

        @Override
        public void remove(int i, int j) {
            changeBackGround(false);
            try {
                if (this.getLength() == j) {
                    setDbSearch(true);
                }
                super.remove(i, j);
                if (!isSetText) {
                    suggestion(i);
                }
                isSetText = false;
            } catch (BadLocationException e) {
                log.error("", e);
            }
        }
    }

    private void suggestion(int index) {
        this.index = index;
        if (suggestThread == null || !suggestThread.isAlive()) {
            createSuggestThread();
        }
        time = System.currentTimeMillis();
    }

    private void suggestPopup(String source) {
        if (outDate != null
                && source.toLowerCase().startsWith(outDate.toLowerCase())) {
            jPopupMenu.setVisible(false);
        } else {
            getMatch(source);
        }
    }

    volatile long time;
    int delayTime;
    Thread suggestThread;

    private long checkTime() {
        return delayTime + time - System.currentTimeMillis();
    }

    int index;

    private void createSuggestThread() {
        suggestThread = new Thread() {
            @Override
            public void run() {
                while (true) {
                    long distanceTime = checkTime();
                    if (distanceTime < 0) {
                        suggestion();
                        return;
                    } else {
                        try {
                            sleep(distanceTime + 1);
                        } catch (Exception e) {
                            log.error("", e);
                        }
                    }
                }
            }
        };
        suggestThread.start();
    }

    public void suggestion() {
        if (this.isFocusOwner() && delayTime > 0) {
            suggestPopup(this.getText());
        }
    }

    /**
     * use dbSearch is overide. not use dbSearch overide suggestion word.
     *
     * @param desText
     */
    private void changeWordSuggestion(String desText, int selectIndex) {
        if (getDbSearch()) {
            this.setText(desText);
            setDbSearch(false);
        } else {
            String currentWord = this.getText();
            StringBuffer buffer = new StringBuffer(currentWord);
            int minWord = getMinWord(currentWord, index);
            int maxWord = getMaxWord(currentWord, index);
            minWord = minWord < 0 ? 0 : minWord + 1;
            maxWord = maxWord < 0 ? currentWord.length() : maxWord;
            buffer.replace(minWord, maxWord, desText);
            this.setText(buffer.toString());
            try {
                aci.accept(selectIndex); // this is accept word.
            } catch (Exception e) {
                log.error("", e);
            }
        }
    }

    char[] splitChar = {' ', '!', '@', '#', '$', '%', '&', '-'};
    private boolean useSuggestion = true;

    public int getMinWord(String currentWord, int index) {
        int minWord = -1;
        for (char split : splitChar) {
            int tmp = currentWord.lastIndexOf(split, index - 1);
            if (tmp > 0) {
                minWord = Math.max(minWord, tmp);
            }
        }
        return minWord;

    }

    public int getMaxWord(String currentWord, int index) {
        int maxWord = currentWord.length();
        for (char split : splitChar) {
            int tmp = currentWord.indexOf(split, index);
            if (tmp > 0) {
                maxWord = Math.min(maxWord, tmp);
            }

        }
        return maxWord;

    }

    public void learn() {
        String text = this.getText();
        if (text.isEmpty()) {
            return;
        }
        String[] learns = text.split("[ !@#$%&-]");
        for (String learn : learns) {
            try {
                if (learn.isEmpty() || learn.length() < 3) {
                    continue;
                }
                aci.learn(learn.toLowerCase());
            } catch (Exception e) {
                log.debug("", e);
            }
        }
        setDbSearch(true);
        aci.clearSelection();
    }

    public boolean getDbSearch() {
        return !(!dbSearch & useSuggestion);
    }

    public void setUseSuggestion(boolean useSuggestion) {
        this.useSuggestion = useSuggestion;
    }

    public void setDbSearch(boolean dbSearch) {
        this.dbSearch = dbSearch;
    }

}
