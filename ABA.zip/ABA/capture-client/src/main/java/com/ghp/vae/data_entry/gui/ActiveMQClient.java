package com.ghp.vae.data_entry.gui;

import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.ptl.state.AroundDialog;
import com.sps.vn.config.ApplicationConfig;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.*;
import javax.swing.*;

import java.awt.*;
import java.util.HashMap;

public class ActiveMQClient {
	private static Logger log = LoggerFactory.getLogger(ActiveMQClient.class);
	
	// ActiveMQ
	private ActiveMQConnectionFactory factory;
	private Connection connection;
	private Session session;
	private Destination destination;
	private MessageProducer messageProducer;
	
	public void sendCommand(HashMap<String, String> message, long timeToLive) throws JMSException{
		// *** Killing Softly
		if (messageProducer != null && session != null) {
			
			log.info("--- SEND MESSAGE :: " + message);
			ObjectMessage objMessage = session.createObjectMessage(message);
			messageProducer.send(destination, objMessage, DeliveryMode.NON_PERSISTENT, 9, timeToLive);
		} else {
			throw new NullPointerException("MessageProducer OR Session is NULL");
		}
	}
	
	public ActiveMQClient() throws JMSException {
		if(ApplicationConfig.getInstance().getWorking2ProjectConfig().isConnectToBrokerActiveMQ()){
			// Init ActiveMQ Factory
			if (factory == null) {
				factory = new ActiveMQConnectionFactory("tcp://localhost:61616");				
			}
	
			if (connection == null) {
				connection = factory.createConnection();
				
				connection.setExceptionListener(new ExceptionListener() {
					
					@Override
					public void onException(final JMSException jmse) {
						EventQueue.invokeLater(new Runnable() {
							
							@Override
							public void run() {
								AroundDialog.showMessageDialog(null, Utilities.getStackTrace(jmse), "Canh bao", JOptionPane.WARNING_MESSAGE);
							}
						});
						
					}
				});

				connection.start();
			}
	
			if (session == null) {
				session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			}
	
			// Create the destination
			if (destination == null) {
				destination = session.createTopic("cl.command");
			}
	
			// Create a producer
			if (messageProducer == null) {
				messageProducer = session.createProducer(destination);
			}
		}
	}	
	
}
