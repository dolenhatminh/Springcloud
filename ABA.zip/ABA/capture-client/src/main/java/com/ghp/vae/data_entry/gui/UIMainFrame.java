package com.ghp.vae.data_entry.gui;

import com.ghp.vae.data_entry.common.Utilities;
import com.sps.vn.config.ApplicationConfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.concurrent.TimeUnit;

class UIMainFrame extends JFrame {

	private static Logger log = LoggerFactory.getLogger(UIMainFrame.class);

	public UIMainFrame(CaptureMediator meditor) {
		try {
			this.meditor = meditor;
			String training = ApplicationConfig.getInstance().getBusinessConfig().getTraining();
			isTraining = false;
			if (training != null) {
				try {
					isTraining = Boolean.parseBoolean(training);
				} catch (Exception ex) {
				}
			}
			initComponent();
			initMeditor();
			this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

			this.addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosing(WindowEvent e) {
					UIMainFrame.this.meditor.exit();
				}
			});

		} catch (Exception ex) {
			log.error("", ex);
		}
	}

	private void initMeditor() {
		buttonBar.setMediator(meditor);
		capturePanel.setMediator(meditor);
		menubar.setMediator(meditor);
		imagePanel.setMediator(meditor);
		meditor.setButtonBar(buttonBar);
		meditor.setCapturePanel(capturePanel);
		meditor.setDisplayPanel(displayPanel);
		meditor.setImagePanel(imagePanel);
		meditor.setInfoPanel(infoPanel);
		meditor.setMenubar(menubar);
		meditor.setMainFrame(this);

	}

	private ButtonBar buttonBar;

	private CapturePanel capturePanel;
	private DisplayPanel displayPanel;
	private ImagePanel imagePanel;
	private InfoPanel infoPanel;
	private MenuBar menubar;

	private CaptureMediator meditor;
	private JPanel panel;
	private JLabel lblNewLabel;

	private boolean isTraining;

	private void initComponent() {
		buttonBar = new ButtonBar();
		capturePanel = new CapturePanel();
		displayPanel = new DisplayPanel();
		imagePanel = new ImagePanel();
		infoPanel = new InfoPanel();
		menubar = new MenuBar();
		
		getContentPane().add(buttonBar);
		getContentPane().add(capturePanel);
		getContentPane().add(displayPanel);
		getContentPane().add(imagePanel);
		getContentPane().add(infoPanel);
		// this.add(menubar);
		setJMenuBar(menubar);

		panel = new JPanel();

		GroupLayout layout = new GroupLayout(getContentPane());
		layout.setHorizontalGroup(layout
				.createParallelGroup(Alignment.LEADING)
				.addGroup(
						layout.createSequentialGroup()
								.addGroup(
										layout.createParallelGroup(
												Alignment.TRAILING, false)
												.addGroup(
														layout.createSequentialGroup()
																.addContainerGap()
																.addComponent(
																		buttonBar,
																		GroupLayout.PREFERRED_SIZE,
																		GroupLayout.DEFAULT_SIZE,
																		GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		ComponentPlacement.RELATED)
																.addComponent(
																		panel,
																		GroupLayout.PREFERRED_SIZE,
																		137,
																		GroupLayout.PREFERRED_SIZE)
																.addGap(54))
												.addComponent(
														capturePanel,
														GroupLayout.PREFERRED_SIZE,
														495,
														GroupLayout.PREFERRED_SIZE)
												.addGroup(
														layout.createSequentialGroup()
																.addContainerGap()
																.addComponent(
																		infoPanel,
																		GroupLayout.PREFERRED_SIZE,
																		485,
																		GroupLayout.PREFERRED_SIZE))
												.addGroup(
														layout.createSequentialGroup()
																.addContainerGap()
																.addComponent(
																		displayPanel,
																		GroupLayout.DEFAULT_SIZE,
																		485,
																		Short.MAX_VALUE)))
								.addPreferredGap(ComponentPlacement.RELATED)
								// htv - modify imagePanel, move left or right 
								.addGap(Integer.parseInt(ApplicationConfig.getInstance().getDisplayConfig().getMoveImage()))
								
								.addComponent(imagePanel,
										GroupLayout.DEFAULT_SIZE, 24,
										Short.MAX_VALUE)));
		layout.setVerticalGroup(layout
				.createParallelGroup(Alignment.LEADING)
				.addGroup(
						layout.createSequentialGroup()
								.addGroup(
										layout.createParallelGroup(
												Alignment.LEADING, false)
												.addComponent(
														panel,
														GroupLayout.DEFAULT_SIZE,
														GroupLayout.DEFAULT_SIZE,
														Short.MAX_VALUE)
												.addComponent(
														buttonBar,
														GroupLayout.PREFERRED_SIZE,
														27, Short.MAX_VALUE))
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(capturePanel,
										GroupLayout.PREFERRED_SIZE, 638,
										GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(infoPanel,
										GroupLayout.PREFERRED_SIZE, 85,
										GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(displayPanel,
										GroupLayout.DEFAULT_SIZE,
										GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE))
				.addComponent(imagePanel, GroupLayout.DEFAULT_SIZE, 769,
						Short.MAX_VALUE));
		panel.setLayout(new BorderLayout(0, 0));

		if (isTraining) {
			lblNewLabel = new JLabel("Training");
			lblNewLabel.setFont(new java.awt.Font("SansSerif", Font.BOLD
					| Font.ITALIC, 34));
			lblNewLabel.setForeground(Color.RED);
			panel.add(lblNewLabel);
		}
		getContentPane().setLayout(layout);

	}

	private void goToTop() {
		while (getExtendedState() != JFrame.MAXIMIZED_BOTH) {
			setExtendedState(JFrame.MAXIMIZED_BOTH);
			try {
				TimeUnit.MILLISECONDS.sleep(100);
			} catch (InterruptedException e) {
				log.error("", e);
			}
		}
	}

	// active windows if window inactive
	public void activeWindow() {

		final boolean isWindows = Utilities.isWindowOS();

		// System.out.println("chay trong active window");
		Runnable run = new Runnable() {

			@Override
			public void run() {
				// System.out.println("chay trong run thread");
				if (UIMainFrame.this.getState() == JFrame.ICONIFIED) {
					System.out.println("ico");
					UIMainFrame.this.setExtendedState(Frame.MAXIMIZED_BOTH);
					UIMainFrame.this.setAlwaysOnTop(true);

					if (isWindows) {
						goToTop();
					}
					UIMainFrame.this.toFront();

				} else {
					UIMainFrame.this.setAlwaysOnTop(true);

					if (isWindows) {
						goToTop();
					}
					UIMainFrame.this.toFront();

					UIMainFrame.this.setExtendedState(Frame.MAXIMIZED_BOTH);
				}

				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					log.error("", e);
				}
				Point oldMouseLocation = MouseInfo.getPointerInfo()
						.getLocation();
				Robot robot = null;
				try {
					robot = new Robot();
				} catch (AWTException ex) {
				}
				robot.mouseMove(UIMainFrame.this.getX() + 100,
						UIMainFrame.this.getY() + 5);
				// System.out.println("chay trong run thread 4");
				robot.mousePress(InputEvent.BUTTON1_MASK);
				robot.mouseRelease(InputEvent.BUTTON1_MASK);
				UIMainFrame.this.setAlwaysOnTop(false);
				// System.out.println("chay trong run thread 5");
				robot.mouseMove((int) oldMouseLocation.getX(),
						(int) oldMouseLocation.getY());

				// try {
				// SwingUtilities.invokeAndWait(new Runnable() {
				//
				// @Override
				// public void run() {
				// }
				// });
				// } catch (InterruptedException e) {
				// log.error("", e);
				// } catch (InvocationTargetException e) {
				// log.error("", e);
				// }

			}
		};
		new Thread(run).start();
	}
}
