package com.ghp.vae.data_entry.gui;

import imagecontrol_vae.UIImage;
import imagecontrol_vae.UIImage.MyEvent;
import imagecontrol_vae.UIImage.VAE_EventListener;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.media.jai.RenderedOp;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import jpl.mipl.jade.BackgroundPainter;
import jpl.mipl.jade.JadeDisplay;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sps.vn.config.ApplicationConfig;

class ImagePanel extends JPanel implements VAE_EventListener{

	private static Logger log = LoggerFactory.getLogger("GUI");
	byte[] avaiableImage;
	public ImagePanel() {
		initComponent();
		initAvaiableImage();
		try{
			controlImage.setAverageSize(ApplicationConfig.getInstance().getBusinessConfig().getAverageImageSize());
		}catch(Exception ex){
			log.warn("", ex);
		}
	}
	private UIImage controlImage = new UIImage();
	private JScrollPane jscpImage;
	private RenderedOp _finalImage = null;
	private JadeDisplay _jadeDisplay;
	private CaptureMediator meditor ;
	
	public void setMediator(CaptureMediator meditor) {
		this.meditor = meditor;
	}
	private void initComponent() {
		this.setAlignmentX(0.0F);
		this.setAlignmentY(0.0F);
		jscpImage = new JScrollPane();
		jscpImage = JadeDisplay.createDisplay(_finalImage, 1024, 768, true);
		this.setLayout(new BorderLayout());
		this.add(controlImage);
		_jadeDisplay = (JadeDisplay) (jscpImage.getViewport().getView());
		_jadeDisplay.setRepaintPolicy(JadeDisplay.REPAINT_IMMEDIATE);
		_jadeDisplay.setBackgroundPainter(new BackgroundPainter() {
			public void paintBackground(Graphics g, int x, int y, int width, int height, boolean isNoErase, boolean isInsideImage, boolean isDeferredTile) {
				g.setColor(Color.WHITE);
				g.fillRect(x, y, width, height);
			}
		});
		_jadeDisplay.setRepaintPolicy(JadeDisplay.REPAINT_IMMEDIATE);
		controlImage.addVAE_EventListener(this);
		try{
			int heightSize = ApplicationConfig.getInstance().getBusinessConfig().getZoomHeight();
			int widthSize = ApplicationConfig.getInstance().getBusinessConfig().getZoomWidth();
			controlImage.setConfigHeightSize(heightSize);
			controlImage.setConfigWidthSize(widthSize);
		}catch(Exception ex){
			log.error("", ex);
		}
	}

	public void rotato(float angle) {
		controlImage.rotate(angle);
	}

	public void loadImageAvailable() {
		log.debug("run in load Image Available");
		synchronized (controlImage) {
			log.debug("run in load Image Available synchronized");
			if(avaiableImage != null){
				controlImage.initImage(avaiableImage, 0);
				controlImage.invalidate();
				controlImage.repaint();
			}
		}
	}
	
	private void initAvaiableImage() {
                String userDir = System.getProperty("user.dir");
                
		try {
                        File img = new File(userDir + "/resources/img/no_image.tif");
			FileInputStream file = new FileInputStream(img);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			byte[] byteImage = new byte[1024];
			boolean loadImage = false;
			while (true) {
				int size = file.read(byteImage);
				if (size < 0) {
					break;
				} else {
					loadImage = true;
					baos.write(byteImage, 0, size);
				}

			}
			file.close();
			byteImage = baos.toByteArray();
			baos.close();
			if(loadImage){
				avaiableImage = byteImage;
			}
			
		} catch (Exception ex) {
			log.error("", ex);

		}
	}

	public void fillImage(byte[] imageByte, float angle) {
		synchronized (controlImage) {
			controlImage.initImage(imageByte, (int) angle);
		}
		_jadeDisplay.setImage(_finalImage);
		_jadeDisplay.updateUI();
		jscpImage.updateUI();
	
	}
	@Override
	public void cropEvent(MyEvent arg0) {
		try {
			meditor.ocrCropImage(controlImage.getCropImage());
		} catch (IOException e) {
			log.error("", e);
		}
	}
	
	
}
