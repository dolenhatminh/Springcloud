package com.ghp.vae.data_entry.entity;

public class HauskeyAddress {

	private HauskeyAddress(Builder builder) {
		this.addrId = builder.getbAddrId();
		this.plzType = builder.getbPlzType();
		this.plzValue = builder.getbPlzValue();
		this.ortType = builder.getbOrtType();
		this.ortValue = builder.getbOrtValue();
		this.strasseType = builder.getbStrasseType();
		this.strasseValue = builder.getbStrasseValue();
		this.hausnummerType = builder.getbHausnummerType();
		this.hausnummerValue = builder.getbHausnummerValue();
		this.hausnummerZusatType = builder.getbHausnummerZusatType();
		this.hausnummerZusatValue = builder.getbHausnummerZusatValue();
		this.hauskey = builder.getbHauskey();
		this.streetNumber = builder.getbStreetNumber();
	}

	public HauskeyAddress() {
	}

	private String addrId;
	
	private String plzType;
	
	private String plzValue;
	
	private String ortType;
	
	private String ortValue;
	
	private String strasseType;
	
	private String strasseValue;
	
	private String hausnummerType;
	
	private String hausnummerValue;
	
	private String hausnummerZusatType;
	
	private String hausnummerZusatValue;
	
	private String hauskey;
	
	private String streetNumber;
	
	public String getAddrId() {
		return addrId;
	}

	public void setAddrId(String addrId) {
		this.addrId = addrId;
	}

	public String getPlzType() {
		return plzType;
	}

	public void setPlzType(String plzType) {
		this.plzType = plzType;
	}

	public String getPlzValue() {
		return plzValue;
	}

	public void setPlzValue(String plzValue) {
		this.plzValue = plzValue;
	}

	public String getOrtType() {
		return ortType;
	}

	public void setOrtType(String ortType) {
		this.ortType = ortType;
	}

	public String getOrtValue() {
		return ortValue;
	}

	public void setOrtValue(String ortValue) {
		this.ortValue = ortValue;
	}

	public String getStrasseType() {
		return strasseType;
	}

	public void setStrasseType(String strasseType) {
		this.strasseType = strasseType;
	}

	public String getStrasseValue() {
		return strasseValue;
	}

	public void setStrasseValue(String strasseValue) {
		this.strasseValue = strasseValue;
	}

	public String getHausnummerType() {
		return hausnummerType;
	}

	public void setHausnummerType(String hausnummerType) {
		this.hausnummerType = hausnummerType;
	}

	public String getHausnummerValue() {
		return hausnummerValue;
	}

	public void setHausnummerValue(String hausnummerValue) {
		this.hausnummerValue = hausnummerValue;
	}

	public String getHausnummerZusatType() {
		return hausnummerZusatType;
	}

	public void setHausnummerZusatType(String hausnummerZusatType) {
		this.hausnummerZusatType = hausnummerZusatType;
	}

	public String getHausnummerZusatValue() {
		return hausnummerZusatValue;
	}

	public void setHausnummerZusatValue(String hausnummerZusatValue) {
		this.hausnummerZusatValue = hausnummerZusatValue;
	}

	public String getHauskey() {
		return hauskey;
	}

	public void setHauskey(String hauskey) {
		this.hauskey = hauskey;
	}

	public String getStreetNumber() {
		return streetNumber;
	}

	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}

	public static class Builder {
		
		private String bAddrId;
		
		private String bPlzType;
		
		private String bPlzValue;
		
		private String bOrtType;
		
		private String bOrtValue;
		
		private String bStrasseType;
		
		private String bStrasseValue;
		
		private String bHausnummerType;
		
		private String bHausnummerValue;
		
		private String bHausnummerZusatType;
		
		private String bHausnummerZusatValue;
		
		private String bHauskey;
		
		private String bStreetNumber;
		
		public Builder() {
			
		}
		
		public Builder addrId(String addrId) {
			this.bAddrId = addrId;
			return this;
		}

		public Builder plzType(String plzType) {
			this.bPlzType = plzType;
			return this;
		}

		public Builder plzValue(String plzValue) {
			this.bPlzValue = plzValue;
			return this;
		}

		public Builder ortType(String ortType) {
			this.bOrtType = ortType;
			return this;
		}

		public Builder ortValue(String ortValue) {
			this.bOrtValue = ortValue;
			return this;
		}

		public Builder strasseType(String strasseType) {
			this.bStrasseType = strasseType;
			return this;
		}

		public Builder strasseValue(String strasseValue) {
			this.bStrasseValue = strasseValue;
			return this;
		}

		public Builder hausnummerType(String hausnummerType) {
			this.bHausnummerType = hausnummerType;
			return this;
		}

		public Builder hausnummerValue(String hausnummerValue) {
			this.bHausnummerValue = hausnummerValue;
			return this;
		}

		public Builder hausnummerZusatType(String hausnummerZusatType) {
			this.bHausnummerZusatType = hausnummerZusatType;
			return this;
		}

		public Builder hausnummerZusatValue(String hausnummerZusatValue) {
			this.bHausnummerZusatValue = hausnummerZusatValue;
			return this;
		}

		public Builder hauskey(String hauskey) {
			this.bHauskey = hauskey;
			return this;
		}

		public Builder streetNumber(String streetNumber) {
			this.bStreetNumber = streetNumber;
			return this;
		}
		
		public HauskeyAddress build() {
			return new HauskeyAddress(this);
		}

		public String getbAddrId() {
			return bAddrId;
		}

		public void setbAddrId(String bAddrId) {
			this.bAddrId = bAddrId;
		}

		public String getbPlzType() {
			return bPlzType;
		}

		public void setbPlzType(String bPlzType) {
			this.bPlzType = bPlzType;
		}

		public String getbPlzValue() {
			return bPlzValue;
		}

		public void setbPlzValue(String bPlzValue) {
			this.bPlzValue = bPlzValue;
		}

		public String getbOrtType() {
			return bOrtType;
		}

		public void setbOrtType(String bOrtType) {
			this.bOrtType = bOrtType;
		}

		public String getbOrtValue() {
			return bOrtValue;
		}

		public void setbOrtValue(String bOrtValue) {
			this.bOrtValue = bOrtValue;
		}

		public String getbStrasseType() {
			return bStrasseType;
		}

		public void setbStrasseType(String bStrasseType) {
			this.bStrasseType = bStrasseType;
		}

		public String getbStrasseValue() {
			return bStrasseValue;
		}

		public void setbStrasseValue(String bStrasseValue) {
			this.bStrasseValue = bStrasseValue;
		}

		public String getbHausnummerType() {
			return bHausnummerType;
		}

		public void setbHausnummerType(String bHausnummerType) {
			this.bHausnummerType = bHausnummerType;
		}

		public String getbHausnummerValue() {
			return bHausnummerValue;
		}

		public void setbHausnummerValue(String bHausnummerValue) {
			this.bHausnummerValue = bHausnummerValue;
		}

		public String getbHausnummerZusatType() {
			return bHausnummerZusatType;
		}

		public void setbHausnummerZusatType(String bHausnummerZusatType) {
			this.bHausnummerZusatType = bHausnummerZusatType;
		}

		public String getbHausnummerZusatValue() {
			return bHausnummerZusatValue;
		}

		public void setbHausnummerZusatValue(String bHausnummerZusatValue) {
			this.bHausnummerZusatValue = bHausnummerZusatValue;
		}

		public String getbHauskey() {
			return bHauskey;
		}

		public void setbHauskey(String bHauskey) {
			this.bHauskey = bHauskey;
		}

		public String getbStreetNumber() {
			return bStreetNumber;
		}

		public void setbStreetNumber(String bStreetNumber) {
			this.bStreetNumber = bStreetNumber;
		}
	}
}
