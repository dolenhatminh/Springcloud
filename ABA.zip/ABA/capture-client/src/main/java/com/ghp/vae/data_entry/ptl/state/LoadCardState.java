package com.ghp.vae.data_entry.ptl.state;

import java.awt.BorderLayout;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;

import javax.jms.JMSException;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingWorker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.bll.BLLoadCard;
import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.entity.Card;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.ObjectInformation;
import com.ghp.vae.data_entry.face.StateCapture;
import com.sps.vn.config.ApplicationConfig;
import com.sps.vn.writing.datasource.WritingBaseDAL;

//import com.ghp.vae.data_entry.common.Logger;

/**
 * LoadCardState handle loading card from server proxy. Class need bll Load card.
 *
 * @author vmhoang
 */

class LoadCardState implements ReloadState {
	private static Logger log = LoggerFactory.getLogger("LOAD CARD");
	private boolean disableLookUp;
	BLLoadCard loadCard;
	private boolean exit = false;
	private final PauseState stateNext;
	@SuppressWarnings("rawtypes")
	private SwingWorker worker;

	/**
	 * need BLLoadCard for Load card
	 *
	 * @param loadCard
	 */
	public LoadCardState(BLLoadCard loadCard, PauseState stateNext) {
		try {
			// String pro = ApplicationConfig.getProperties().getProperty("DISABLE_LOOKUP");
			// disableLookUp = Boolean.parseBoolean(pro);
		} catch (final Exception ex) {
			this.disableLookUp = false;
		}
		this.loadCard = loadCard;
		this.stateNext = stateNext;
	}

	@Override
	public void reloadStatus() {
		this.exit = false;
	}

	/**
	 * handle for action : LOAD_CARD , LOAD_PAUSE, EXIT.
	 *
	 * @see StateCapture
	 */
	@Override
	public void handleEvent(ObjectInformation information, MainFieldInterface main) {
		final byte action = information.getAction();
		log.debug("handleEvent Load card:" + action);
		switch (action) {
		case LOAD_CARD:
			this.openLoadCard(information, main);
			break;
		case LOAD_PAUSE:
			this.openLoadCardWhenPause(information, main);
			break;
		case CANCEL_PROCESS:
			this.cancelProcess(information, main);
			break;
		case EXIT:
			this.openPopupCannotNotExit("Dang lay du lieu khong the thoat.");
			break;
		}
	}

	private void cancelProcess(ObjectInformation information, MainFieldInterface main) {
		if (this.worker.isDone()) {
			return;
		}
		if (this.loadCard.cancelGettingCard()) {
			this.worker.cancel(true);
			main.setProcessLoadCard(false);
		}
	}

	/**
	 * function handle exit capture client.
	 *
	 * @note exit when load card error.
	 * @param message
	 *            : mesage when exit application when loading card.
	 */
	private void openPopupCannotNotExit(String message) {
		if (this.exit) {
			final WritingBaseDAL baseDAL = new WritingBaseDAL();
			baseDAL.releaseALLConnection();
			System.exit(0);
		} else {
			AroundDialog.showMessageDialog(null, message, "Canh bao", JOptionPane.WARNING_MESSAGE);
		}
	}

	/**
	 * handle load card after state pause card.
	 *
	 * @different with openLoadCard : main.loadImageAvailable();
	 * @param information
	 * @param main
	 * @see PauseState
	 * @see #getCard(MainFieldInterface, ObjectInformation)
	 * @see #openLoadCard(ObjectInformation, MainFieldInterface)
	 */
	private void openLoadCardWhenPause(final ObjectInformation information, final MainFieldInterface main) {
		this.loadCardProcess(main, information);
	}

	/**
	 * handle load card after normal state or save state.
	 *
	 * @param information
	 * @param main
	 * @see PauseState
	 * @see #getCard(MainFieldInterface, ObjectInformation)
	 * @see #openLoadCard(ObjectInformation, MainFieldInterface)
	 */

	private void openLoadCard(final ObjectInformation information, final MainFieldInterface main) {
		log.debug("before loadImagte Available");
		main.loadImageAvailable();
		log.debug("after loadImagte Available");
		this.loadCardProcess(main, information);
	}

	private void loadCardProcess(final MainFieldInterface main, final ObjectInformation information) {
		main.setStatusCard(" >>> [STEP-3] Dang ky lay collection");

		this.worker = new ExtendSwingWorker(main, information);
		this.worker.execute();

		main.setProcessLoadCard(true);
	}

	/**
	 * get card from BLLLoad card and handle error from load card process and reset stateCapture is default status of MainFieldInterface <br/>
	 *
	 * @param main
	 * @param information
	 */

	private void getCardProcess(final MainFieldInterface main, ObjectInformation information) {
		try {

			Card card = this.loadCard.getCard();
			if (card == null) {
				final int accept = AroundDialog.showConfirmDialog(null, "Het Card, Ban co muon doi khong?", "Xac nhan", JOptionPane.YES_NO_OPTION,
						JOptionPane.WARNING_MESSAGE);
				if (accept != JOptionPane.YES_OPTION) {
					this.stateNext.reloadStatus();
					main.changeState(this.stateNext);
					information.setAction(PAUSE);

					main.request(information, main);

					return;
				} else {
					card = this.waittingGetCard(information, main);
					if (card == null) {
						return;
					}
				}
				// return;
			}
			main.setEntity(card);
		} catch (final InterruptedException ex) {
			log.error("interrupted", ex);
			return;
		} catch (final Throwable ex) {
			log.error("", ex);
			String mess = "Thong bao loi tu proxy \nThong bao voi quan li du an ngay!\n";
			mess = mess + Utilities.getStackTrace(ex);
			final JPanel panel = new JPanel();
			panel.setLayout(new BorderLayout());
			final JTextArea area = new JTextArea(20, 60);
			final JScrollPane scrollBar = new JScrollPane(area);
			area.setText(mess);
			scrollBar.setSize(300, 200);
			panel.add(scrollBar, BorderLayout.CENTER);
			JOptionPane.showMessageDialog(null, panel, "Canh bao", JOptionPane.ERROR_MESSAGE);
			this.exit = true;
			main.doExit(true);
			return;
		}
	}

	/**
	 * function waitting getCard handle loadCard when Card is null from getCardProccess.
	 *
	 * @param information
	 * @param main
	 * @return
	 */

	private Card waittingGetCard(ObjectInformation information, MainFieldInterface main) {
		Card card = null;
		try {
			while (true) {
				card = this.loadCard.getCard();
				try {
					log.info("Is trying to get card...");
					Thread.sleep(ApplicationConfig.getInstance().getBusinessConfig().getWaitingTimeRequestCard());
				} catch (final InterruptedException ex) {
					log.error("interupted ", ex);
				}
				if (card != null) {
					break;
				}

			}
		} catch (final Throwable ex) {
			log.error("", ex);
			String mess = "Thong bao loi tu proxy \nThong bao voi quan li du an ngay!\n";
			mess = mess + Utilities.getStackTrace(ex);
			final JPanel panel = new JPanel();
			panel.setLayout(new BorderLayout());
			final JTextArea area = new JTextArea(20, 60);
			final JScrollPane scrollBar = new JScrollPane(area);
			area.setText(mess);
			scrollBar.setSize(300, 200);
			panel.add(scrollBar, BorderLayout.CENTER);
			JOptionPane.showMessageDialog(null, panel, "Canh bao", JOptionPane.ERROR_MESSAGE);
			this.exit = true;
			main.doExit(true);
			return null;
		}
		return card;
	}

	/**
	 * function setEnableSomeField: is utility enable or disable field <br/>
	 * for field: ZUSAT , ANREDE, STOCKWERK, ADRESSZUSAT, COADDRESS, LAND, SAVE_BUTTON, SAVE_MENU.<br/>
	 * enable field POSTLAGEND, PICKPOST, MYPOST24
	 *
	 * @param visible
	 * @param main
	 * @note field land not action for request from production.
	 */

	private void setEnableSomeField(boolean visible, MainFieldInterface main) {
		main.getComponent(MainFieldInterface.ZUSAT).setEnabled(visible);
		main.getComponent(MainFieldInterface.ANREDE).setEnabled(visible);
		main.getComponent(MainFieldInterface.STOCKWERK).setEnabled(visible);
		main.getComponent(MainFieldInterface.ADRESSZUSAT).setEnabled(visible);
		main.getComponent(MainFieldInterface.COADDRESS).setEnabled(visible);
		main.getComponent(MainFieldInterface.SAVE_BUTTON).setEnabled(visible);
		main.getComponent(MainFieldInterface.SAVE_MENU).setEnabled(visible);
		main.getComponent(MainFieldInterface.POSTLAGEND).setEnabled(true);
		main.getComponent(MainFieldInterface.PICKPOST).setEnabled(true);
		main.getComponent(MainFieldInterface.MYPOST24).setEnabled(true);

		main.getComponent(MainFieldInterface.STRASSE).setEnabled(true);
		main.getComponent(MainFieldInterface.HAUSE).setEnabled(true);
	}

	private class ExtendSwingWorker extends SwingWorker<Boolean, Object> {
		private final MainFieldInterface main;
		private final String prReallyDone = "LOAD_STATE_DONE";
		private final ObjectInformation information;

		private ExtendSwingWorker(MainFieldInterface main, ObjectInformation information) {
			this.main = main;
			this.information = information;
			this.getPropertyChangeSupport().addPropertyChangeListener(this.prReallyDone, new PropertyChangeListener() {
				@Override
				public void propertyChange(PropertyChangeEvent evt) {
					log.debug("run in property change");
					if (evt.getNewValue().equals(true)) {
						try {
							ExtendSwingWorker.this.whenReallyDone(true);
						} catch (final JMSException e) {
							log.error("", e);
						}
					} else {
						try {
							ExtendSwingWorker.this.whenReallyDone(false);
						} catch (final JMSException e) {
							log.error("", e);
						}
					}
				}
			});
		}

		@Override
		protected Boolean doInBackground() {

			this.publish("reset data");
			log.debug("after resetGui");
			boolean value = false;
			try {
				LoadCardState.this.getCardProcess(this.main, this.information);
				value = true;
				return null;
			} catch (final Exception ex) {
				log.error("", ex);
				return null;
			} finally {
				log.debug("fire event property change");
				this.firePropertyChange(this.prReallyDone, !value, value);
			}
		}

		@Override
		protected void process(List<Object> chunks) {
			this.main.resetGui();
		}

		private void whenReallyDone(boolean loadCard) throws JMSException {
			if (this.isCancelled()) {
				LoadCardState.this.exit = true;
				this.information.setAction(EXIT);

				this.main.request(this.information, this.main);
			} else {
				LoadCardState.this.setEnableSomeField(LoadCardState.this.disableLookUp, this.main);
				this.main.clearTooltip();
				this.main.loadDataCard();
				this.main.loadCardEvent(false);
				this.main.setProcessLoadCard(false);
				// main.defaultFocus();
				log.info("[Capture]-[COLLECTION:" + this.main.getEntity().getCard().getManagementID() + "][LOAD]-end loading collection");
				this.main.resetState();
			}
		}

	}
}
