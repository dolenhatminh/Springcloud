/*
 * Class: FirmaSign
 *
 * Created on Mar 8, 2016
 *
 * (c) Copyright Global Cybersoft VN, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Global Cybersoft VN.
 * Floor 4-5, Helios Building, Quang Trung Software City
 */
package com.ghp.vae.search.model.ocr;

/**
 * The Class FirmaSign.
 */
public class FirmaSign {

    /** The type. */
    private String type;

    /** The sign. */
    private String sign;

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return this.type;
    }

    /**
     * Sets the type.
     *
     * @param type the new type
     */
    public void setType(final String type) {
        this.type = type;
    }

    /**
     * Gets the sign.
     *
     * @return the sign
     */
    public String getSign() {
        return this.sign;
    }

    /**
     * Sets the sign.
     *
     * @param sign the new sign
     */
    public void setSign(final String sign) {
        this.sign = sign;
    }
}
