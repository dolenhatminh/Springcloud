package com.ghp.vae.data_entry.bll;
/*
 * To change this template, choose Tools | Templates and open the template in the editor.
 */

import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.Utilities;

/**
 *
 * @author vtbinh
 */
public class BLLCard implements Cloneable {

	private static Logger log = LoggerFactory.getLogger(BLLCard.class);
	// list of fields
	private final Map<String, BLLField> fields;

	// managementid
	private long managementID = -1;
	private long collectionID = -1;
	// image file path
	private String filePath;
	// image file name
	private String filename;
	// reason
	private String reason;
	// lower left barcode x coordinator
	private float barcodeLeftX;
	private float barcodeLeftY;
	// lower right barcode x coordinator
	private float barcodeRightX;
	// lower right barcode y coordinator
	private float barcodeRightY;
	// messageid
	private String messageid;
	// version of schema
	private String version;
	// coding date
	private String codingdate;
	// coding site id
	private String codingsiteid;
	// produc id
	private String productid;
	// sequence number
	private String sequencenumber;
	// the time start capture data
	private Timestamp startTime;
	// the time end capture data
	private Timestamp endTime;
	// = true if config application direct from database
	private Timestamp requestTime;

	private boolean isGetCardDirectFromDB;
	private int step;
	// status of card after untar
	private String untar_status;
	// =true if this card have in kdp
	private boolean hasInKDP = true;

	private String vg_picid = ""; // Hoang add for request new field VG_PICID

	/* status of card need for check zubofi */
	private boolean kdpSpecial;
	private boolean checkZubofiSpecial;
	private boolean notAddress;
	private boolean zubofiSpecial;
	private boolean badCard = false; // use for export bad card.

	private boolean isPostfachAddress = false;
	private boolean isPickpockAddress = false;
	private boolean isPostLagenAddress = false;
	private boolean change = false;
	private String reasonBad = "";
	private String baditem = "";
	int typeZubofiSpecial;
	private boolean myPost24;

	private long streetNumber;

	// KDP TYPE: 1-person 2-company
	private int kdpType;

	public boolean isBadCard() {
		return this.badCard;
	}

	public void setBadCard(boolean badCard) {
		this.badCard = badCard;
	}

	public int getKdpType() {
		return this.kdpType;
	}

	public void setKdpType(int kdpType) {
		this.kdpType = kdpType;
	}

	public int getStep() {
		return this.step;
	}

	public void setStep(int step) {
		this.step = step;
	}

	public void hasInKDP(boolean has) {
		this.hasInKDP = has;
	}

	public boolean isHasInKDP() {
		final String kdpid = Utilities.ignoreNull(this.fields.get(BLLDataStructure.KDPID_FIELD).getValue());
		return (this.hasInKDP & !kdpid.equals(""));
	}

	public boolean isGetCardDirectFromDB() {
		return this.isGetCardDirectFromDB;
	}

	public void setGetCardDirectFromDB(boolean isGetCardDirectFromDB) {
		this.isGetCardDirectFromDB = isGetCardDirectFromDB;
	}

	private boolean isNoChange;// indicated the value is not changed after modifying them
	private String username;

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public BLLCard() {
		this.fields = new java.util.concurrent.ConcurrentHashMap<String, BLLField>();
		this.isNoChange = false;
	}

	public void resetData() {
		final Iterator<BLLField> tmp = this.fields.values().iterator();
		while (tmp.hasNext()) {
			final BLLField field = tmp.next();
			field.setValue("");
			if (field instanceof BLLAddressField) {
				((BLLAddressField) field).setTyped("");
			}
		}
		this.resetStatus();
	}

	public Map<String, BLLField> getFieldList() {
		return this.fields;
	}
	// <editor-fold defaultstate="collapsed" desc="get/set methods">

	public String getUntarStatus() {
		return this.untar_status;
	}

	public void setUntarStatus(String status) {
		this.untar_status = status;
	}

	public Timestamp getEndTime() {
		if (this.endTime == null) {
			this.endTime = new Timestamp(new Date().getTime());
		}
		return this.endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	public Timestamp getStartTime() {
		if (this.startTime == null) {
			this.startTime = new Timestamp(new Date().getTime());
		}
		return this.startTime;
	}

	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}

	public BLLField getField(String name) {
		if ((name != null) && !name.equals("") && (this.fields != null) && !this.fields.isEmpty()) {
			return this.fields.get(name);
		} else {
			return null;
		}
	}

	public void addField(BLLField field) {
		if ((this.fields != null) && !this.fields.containsKey(field.getName())) {
			this.fields.put(field.getName(), field);
		}
	}

	public float getBarcodeLeftX() {
		return this.barcodeLeftX;
	}

	public void setBarcodeLeftX(float barcodeLeftX) {
		this.barcodeLeftX = barcodeLeftX;
	}

	public float getBarcodeLeftY() {
		return this.barcodeLeftY;
	}

	public void setBarcodeLeftY(float barcodeLeftY) {
		this.barcodeLeftY = barcodeLeftY;
	}

	public float getBarcodeRightX() {
		return this.barcodeRightX;
	}

	public void setBarcodeRightX(float barcodeRightX) {
		this.barcodeRightX = barcodeRightX;
	}

	public float getBarcodeRightY() {
		return this.barcodeRightY;
	}

	public void setBarcodeRightY(float barcodeRightY) {
		this.barcodeRightY = barcodeRightY;
	}

	public String getCodingdate() {
		return this.codingdate;
	}

	public void setCodingdate(String codingdate) {
		this.codingdate = codingdate;
	}

	public String getCodingsiteid() {
		return this.codingsiteid;
	}

	public void setCodingsiteid(String codingsiteid) {
		this.codingsiteid = codingsiteid;
	}

	public String getFilePath() {
		return this.filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getFilename() {
		return this.filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public long getManagementID() {
		return this.managementID;
	}

	public void setManagementID(long managementID) {
		this.managementID = managementID;
	}

	public String getMessageid() {
		return this.messageid;
	}

	public void setMessageid(String messageid) {
		this.messageid = messageid;
	}

	public String getProductid() {
		return this.productid;
	}

	public void setProductid(String productid) {
		this.productid = productid;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getSequencenumber() {
		return this.sequencenumber;
	}

	public void setSequencenumber(String sequencenumber) {
		this.sequencenumber = sequencenumber;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public boolean isNoChange() {
		return this.isNoChange;
	}

	public void setNoChange(boolean b) {
		this.isNoChange = b;
	}
	// </editor-fold>

	public double getAngle(double defaultAngle) {
		double angle;
		if ((this.barcodeLeftY == this.barcodeRightY) && (this.barcodeLeftX == this.barcodeRightX)
				&& (this.barcodeLeftX < 1)) {
			angle = 0.0;
		} else {
			angle = (180 - (Math.toDegrees(
					Math.atan2(this.barcodeLeftY - this.barcodeRightY, this.barcodeLeftX - this.barcodeRightX))));
		}
		log.debug("bacode left = (" + this.barcodeLeftX + ", " + this.barcodeLeftY + ")");
		log.debug("bacode right = (" + this.barcodeRightX + ", " + this.barcodeRightY + ")");
		log.debug("Angle = " + angle);
		// return angle + 90;
		return angle + defaultAngle;
	}

	public void setVgPicid(String vg_picid) {
		this.vg_picid = vg_picid;
	}

	public String getVgPicid() {
		return this.vg_picid;
	}

	public void setKdpSpecical(boolean kdpSpecial) {
		this.kdpSpecial = kdpSpecial;
	}

	public boolean isKdpSpecial() {
		return this.kdpSpecial;
	}

	public void setCheckZubofiSpecical(boolean zubofiSpecial) {
		this.checkZubofiSpecial = zubofiSpecial;
	};

	public boolean isCheckZubofiSpecial() {
		return this.checkZubofiSpecial;
	}

	public void setTypeZubofiSpecical(int typeZubofiSpecial) {
		this.typeZubofiSpecial = typeZubofiSpecial;
	}

	public int getTypeZubofiSpecical() {
		return this.typeZubofiSpecial;
	}

	public boolean isNotAddress() {
		return this.notAddress;
	}

	public void setNotAddress(boolean notAddress) {
		this.notAddress = notAddress;
	}

	public boolean isZubofiSpecial() {
		return this.zubofiSpecial;
	}

	public void setZubofiSpecial(boolean zubofiSpecial) {
		this.zubofiSpecial = zubofiSpecial;
	}

	public boolean isPostfachAddress() {
		return this.isPostfachAddress;
	}

	public void setPostfachAddress(boolean isPostfachAddress) {
		this.isPostfachAddress = isPostfachAddress;
	}

	public boolean isPickpockAddress() {
		return this.isPickpockAddress;
	}

	public void setPickpockAddress(boolean isPickpockAddress) {
		this.isPickpockAddress = isPickpockAddress;
	}

	public boolean isPostLagenAddress() {
		return this.isPostLagenAddress;
	}

	public void setPostLagenAddress(boolean isPostLagenAddress) {
		this.isPostLagenAddress = isPostLagenAddress;
	}

	public boolean isChange() {
		return this.change;
	}

	public void setChange(boolean change) {
		this.change = change;
	}

	public void setReasonBad(String reasonBad) {
		this.reasonBad = reasonBad;
	}

	public String getReasonBad() {
		return this.reasonBad;
	}

	public void setBaditem(String baditem) {
		this.baditem = baditem;
	}

	public String getBaditem() {
		return this.baditem;
	}

	public void resetStatus() {
		this.kdpSpecial = false;
		this.checkZubofiSpecial = false;
		this.notAddress = false;
		this.zubofiSpecial = false;
		this.badCard = false; // use for export bad card.

		this.isPostfachAddress = false;
		this.isPickpockAddress = false;
		this.isPostLagenAddress = false;
		this.change = false;
		this.reasonBad = "";
		this.baditem = "";
		this.streetNumber = 0;
		this.myPost24 = false;
	}

	public void setCollectionID(long collectionID) {
		this.collectionID = collectionID;
	}

	public long getCollectionID() {
		return this.collectionID;
	}

	public boolean isMyPost24() {
		return this.myPost24;
	}

	public void setMyPost24(boolean myPost24) {
		this.myPost24 = myPost24;
	}

	public long getStreetNumber() {
		return this.streetNumber;
	}

	public void setStreetNumber(long streetNumber) {
		this.streetNumber = streetNumber;
	}

	public void clearValue() {
		for (final String key : this.fields.keySet()) {
			this.fields.get(key).setValue("");
		}

		this.kdpSpecial = false;
		this.checkZubofiSpecial = false;
		this.notAddress = false;
		this.zubofiSpecial = false;
		this.badCard = false; // use for export bad card.
		this.isPostfachAddress = false;
		this.isPickpockAddress = false;
		this.isPostLagenAddress = false;
		this.change = false;
		this.reasonBad = "";
		this.baditem = "";
		this.typeZubofiSpecial = 0;
		this.myPost24 = false;
	}

	public void setRequestTime(Timestamp requestTime) {
		this.requestTime = requestTime;

	}

	public Timestamp getRequestTime() {
		return this.requestTime;
	}
}
