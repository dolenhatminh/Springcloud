package com.ghp.vae.data_entry.ptl.state;

import com.ghp.vae.data_entry.bll.*;
import com.ghp.vae.data_entry.common.ConstraintField;
import com.ghp.vae.data_entry.common.Utilities;
import com.ghp.vae.data_entry.common.autocomplete.Configurator;
import com.ghp.vae.data_entry.face.MainFieldInterface;
import com.ghp.vae.data_entry.face.ObjectInformation;
import com.ghp.vae.data_entry.face.StateCapture;
import com.ghp.vae.data_entry.ptl.autocomplete.AutoTextFieldDataSourceInf;
import com.ghp.vae.data_entry.ptl.autocomplete.AutoTextFieldInterface;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

//import com.ghp.vae.data_entry.ptl.autocomplete.AutoTextField;

/**
 * @author vmhoang
 * init resource suggesttion, contraint for main interface.
 */
class InitState implements StateCapture {
	private static Logger log = LoggerFactory.getLogger("InitGui");
	private BLLViewData viewData;
	private BLLoadCard loadCard;

	public InitState(BLLViewData viewData, BLLoadCard loadCard) {
		this.viewData = viewData;
		this.loadCard = loadCard; 
	}

	/**
	 * handle for action : INIT , EXIT
	 * @see StateCapture
	 */
	
	public void handleEvent(ObjectInformation information, MainFieldInterface main) {
		byte action = information.getAction();
		switch (action) {
		case INIT:
			openInitGUi(information, main);
			break;
		case EXIT:
	 		openPopupCannotNotExit("Dang lay du lieu khong the thoat.");
	 		break;
		}
	}

	/**
	 * call when handle action : EXIT <br/>
	 * Open dialog with message.
	 * @param message message display on jdialog
	 */
	
	private void openPopupCannotNotExit(String message) {
		AroundDialog.showMessageDialog(null, message, "Canh bao", JOptionPane.WARNING_MESSAGE);
	}
	
	/**
	 * call when handle action : INIT <br/>
	 * <b>function call</b>
	 * <ol>
	 *  <li>function: addSuggesstionForMain. </li>
	 *  <li>function: addContraintForMain) </li>
	 *  <li>resetState of MainFieldInterface when finish.</li>
	 * </ol> 
	 */
	
	private void openInitGUi(ObjectInformation information, MainFieldInterface main) {
		log.info("[Capture][LOAD VALIDATE]");
		addSuggesttionForMain(main);
		addContraintForMain(main);
		main.resetState();
	}

	/**
	 * add datasource for MainFieldInterface some field:ANREDE, FIRMA, VORNAME, NAME, ZUSAT, ORT, STRASSE, PLZ, ORT,LOOKUP
	 * @note compare with strasse, ort, plz  in dataSource
	 * @param MainFieldInterface Main
	 * @see #updateDataSourceIntoField
	 */
	
	private void addSuggesttionForMain(MainFieldInterface main) {
		
		updateDataSourceIntoField(main.getComponent(MainFieldInterface.ANREDE), viewData.getAnredeDataSoure());
		updateDataSourceIntoField(main.getComponent(MainFieldInterface.FIRMA), viewData.getFirmenameDataSource());
		updateDataSourceIntoField(main.getComponent(MainFieldInterface.VORNAME), viewData.getVornammeDataSoure());
		updateDataSourceIntoField(main.getComponent(MainFieldInterface.NAME), viewData.getNameDataSource());
		updateDataSourceIntoField(main.getComponent(MainFieldInterface.ZUSAT), viewData.getZuzatDataSource());
		updateDataSourceIntoField(main.getComponent(MainFieldInterface.ORT), viewData.getOrtDataSource());
		updateDataSourceIntoField(main.getComponent(MainFieldInterface.STRASSE), viewData.getStrasseDataSource());
//		updateDataSourceIntoField(main.getComponent(MainFieldInterface.LOOKUP), viewData.getLookupDataSource());
		
		viewData.getOrtDataSource().setPlzObject((JTextField) main.getComponent(MainFieldInterface.PLZ));
		viewData.getStrasseDataSource().setPlzObject((JTextField) main.getComponent(MainFieldInterface.PLZ));
		viewData.getStrasseDataSource().setOrtObject((JTextField) main.getComponent(MainFieldInterface.ORT));
		
//		viewData.getLookupDataSource().setOrtObject((JTextField) main.getComponent(MainFieldInterface.ORT));
//		viewData.getLookupDataSource().setPlzObject((JTextField) main.getComponent(MainFieldInterface.PLZ));
//		viewData.getLookupDataSource().setStrasseObject((JTextField) main.getComponent(MainFieldInterface.STRASSE));

	}

	/**
	 * utility for update data source.
	 * @param field this is field need update data source, AutotexfieldDataSourceInf dataSource.
	 */
	private void updateDataSourceIntoField(Component field, AutoTextFieldDataSourceInf dataSource) {
//		System.out.println("field:"+field +" | AutoTextFieldDataSourceInf"+dataSource);
		((AutoTextFieldInterface) field).setDataSource(dataSource);
	}
	
	/**
	 * main function of add Contraint, set data for field. <br/>
	 * @see #addDataForComboBox(MainFieldInterface)
	 * @see #addContraintForTextField(MainFieldInterface)
	 * @see #addContraintForComboBoxField(MainFieldInterface)
	 */

	private void addContraintForMain(MainFieldInterface main) {
		addDataForComboBox(main);
		addContraintForTextField(main);
		addContraintForComboBoxField(main);
		
	}

	/**
	 * function for add data for badreason.
	 * @param main
	 */
	
	private void addDataForComboBox(MainFieldInterface main) {
		String arr[][] = viewData.getReason();
		JComboBox reason = (JComboBox) main.getComponent(MainFieldInterface.BADREASON);
		for (int i = 0; arr != null && i < arr.length; i++) {
			reason.addItem(arr[i][0]);
		}
		
		String land[][] = viewData.getLand();
		JComboBox cbLand = (JComboBox) main.getComponent(MainFieldInterface.LAND);
		cbLand.removeAllItems();
		for (String data[]:land) {
			cbLand.addItem(data[1]);
		}
		
	}
	
	/**
	 * function for add contraint for combobox field land and bad reason. <br/>
	 * @see #addContraintForTextField(MainFieldInterface)
	 * @param main
	 */
	private void addContraintForComboBoxField(MainFieldInterface main) {
		//for comboBox land
		JComboBox land = (JComboBox) main.getComponent(MainFieldInterface.LAND);
		Map<String, BLLField> fields = loadCard.getFieldList();
		land.setMaximumRowCount(20);
		((JTextField) land.getEditor().getEditorComponent()).setFocusAccelerator('l');
		try {
			String inputCons = ((BLLAddressField) fields.get(BLLDataStructure.LAND_FIELD)).getConstraint();
			int maxlength = Utilities.checkInt(Utilities.getdata_seperator(inputCons, true, ";"));
			String option = Utilities.getdata_seperator(inputCons, 2, ";");
			Configurator.enableAutoCompletion(land, option, maxlength);
		} catch (Exception ex) {
			log.warn("", ex);
		}
		JComboBox reason = (JComboBox) main.getComponent(MainFieldInterface.BADREASON);
		((JTextField) reason.getEditor().getEditorComponent()).setFocusAccelerator('B');
		Configurator.enableAutoCompletion(reason);
	}
/**
 * Function add contraint for text field <br/>
 * Contraints get from table fieldnamelist in database write. <br/>
 * Add Contraints for field : LOOKUP, FIRMA, ZUSAT, ANREDE, VORNAME, NAME, PLZ, ORT,
 * STRASSE, HAUSE, POSTFACH, STOCKWERK, COADDRESS, ADRESSZUSAT, PICKPOST, POSTLAGEND. <br/>
 * @see #addContraintJTextField(String, JTextField)
 * @param main
 */
	
	private void addContraintForTextField(MainFieldInterface main) {
		Map<String, BLLField> fields = loadCard.getFieldList();
		JTextField field = (JTextField) main.getComponent(MainFieldInterface.LOOKUP);
		String inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.FIRMA);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.ZUSAT);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();;
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.ANREDE);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.VORNAME);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.NAME);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.PLZ);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.ORT);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.STRASSE);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.HAUSE);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.POSTFACH);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.STOCKWERK);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.COADDRESS);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.ADRESSZUSAT);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		field = (JTextField) main.getComponent(MainFieldInterface.PICKPOST);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		
		field = (JTextField) main.getComponent(MainFieldInterface.MYPOST24);
		inputCons = ((BLLAddressField) fields.get(field.getName())).getConstraint();
		addContraintJTextField(inputCons,field);
		
		field = (JTextField) main.getComponent(MainFieldInterface.POSTLAGEND);
		addContraintJTextField(inputCons,field);
	}

	/**
	 * utility get constraint from value , seperator.
	 * @param value
	 * @param seperator
	 * @return valid character
	 * @throws Exception
	 */
	private String getValidChar(String value, String seperator) throws Exception {
		if (value != null && !value.equals("")) {
			String tmp = value.trim();
			int firstPos, lastPost;
			try {
				firstPos = tmp.indexOf(seperator);
				if (firstPos == -1) {
					firstPos = 0;
				}
				lastPost = tmp.lastIndexOf(seperator);
				if (lastPost == -1) {
					firstPos = value.length();
				}
				tmp = tmp.substring(firstPos + 1, lastPost);
			} catch (Exception ex) {
				throw ex;
			}
			return tmp;
		} else {
			return "";
		}
	}

	/**
	 * add contraints for text field.
	 * @param inputCons
	 * @param tmp
	 */
	private void addContraintJTextField(String inputCons, JTextField tmp) {
		try {
			int maxlength = Utilities.checkInt(Utilities.getdata_seperator(inputCons, true, ";"));
			String option = getValidChar(inputCons, ";");
			if (maxlength > 0 && !option.equals("")) {
				if (tmp instanceof AutoTextFieldInterface) {
					((AutoTextFieldInterface) tmp).setConstraint(maxlength, option);
				} else {
					ConstraintField.setConstraintField(1, tmp, inputCons);
				}
			}
		} catch (Exception e) {
			log.error("", e);
		}
	}
	
}

