package com.ghp.vae.data_entry.ptl.autocomplete;

import org.apache.commons.collections.KeyValue;

import java.util.List;
import java.util.Map;

public interface AutoTextFieldDataSourceInf {
	public List<KeyValue> getDataSource(String patern);

}
