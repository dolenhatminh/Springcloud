/*
 * Created on November 05, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.sps.vn.lookup.datasource;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author vtbinh
 * 
 * Window - Preferences - Java - Code Style - Code Templates
 */
public abstract class LookupDBase {
	
	private static Logger log = LoggerFactory.getLogger(LookupDBase.class);  

    /**
     * Execute the select query
     *
     * @param query:
     *            the query to be executed
     * @return: the ResultSet
     * @throws SQLException
     */
    public ResultSet exec_query_read(Connection conn, String query) throws SQLException {
        if (query.trim().toLowerCase().indexOf("select") != 0) {
            throw new SQLException("Only select query, other query is invalid");
        }
        Statement stmt = null;
        ResultSet res = null;

        try {
            stmt = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY,
                    ResultSet.CONCUR_READ_ONLY);
            res = stmt.executeQuery(query);
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw ex;
        }
        return res;
    }

    /**
     * Execute update insert or delete query
     *
     * @param query:
     *            the query to be executed
     * @return number of records is effective
     * @throws SQLException
     */
    public int exec_query_write(Connection conn, String query) throws SQLException {
        if (query.trim().toLowerCase().indexOf("select") == 0) {
            throw new SQLException("Only insert, update and delete query, other query is invalid");
        }
        Statement stmt = null;
        int res = 0;
        try {
            stmt = conn.createStatement();
            res = stmt.executeUpdate(query);
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw ex;
        }
        return res;
    }
    
    @SuppressWarnings("unused")
	private static Statement mapStatement ;
	@SuppressWarnings("unused")
	private static Savepoint save ;
	
    public static Object processStoreISCancel(Connection conn, String store_name, Object[] params,
            int output_type) throws Exception {
        CallableStatement proc = null;
        try {
            String strparam = "";
            for (int i = 1; params != null && i <= params.length; i++) {
                strparam += "?,";
            }
            if (strparam.length() > 0) {
                strparam = strparam.substring(0, strparam.lastIndexOf(","));
            }
            strparam = "(" + strparam + ")";
            proc = conn.prepareCall("{ ? = call " + store_name + strparam + "}");
            proc.registerOutParameter(1, output_type);
            //<editor-fold defaultstate="collapsed" desc="process proc parameter">
            for (int i = 0; params != null && i < params.length; i++) {
                Object obj = params[i];
                if (obj instanceof Integer) {
                    setInt(proc, i + 2, (Integer) params[i]);
                } else if (obj instanceof String) {
                    setString(proc, i + 2, (String) params[i]);
                } else if (obj instanceof Date) {
                    setDate(proc, i + 2, (Date) params[i]);
                } else if (obj instanceof Timestamp) {
                    setTimestamp(proc, i + 2, (Timestamp) params[i]);
                } else if (obj instanceof Time) {
                    setTime(proc, i + 2, (Time) params[i]);
                } else if (obj instanceof Double) {
                    setDouble(proc, i + 2, (Double) params[i]);
                } else if (obj instanceof Float) {
                    setFloat(proc, i + 2, (Float) params[i]);
                } else if (obj instanceof Boolean) {
                    setBoolean(proc, i + 2, (Boolean) params[i]);
                } else if (obj instanceof Long) {
                    setLong(proc, i + 2, (Long) params[i]);
                } else {
                    proc.setObject(i + 2, params[i]);
                }
            }
            
            //proc.get
            
            //</editor-fold>
            addStatement(proc);
            save = conn.setSavepoint();
            checkInterrupted("interrupted when after execute");
            proc.execute();
            return proc.getObject(1);
        } catch (SQLException e) {
            log.error(e.getMessage());
            throw e;
        } catch (Exception e) {
            throw e;
        }finally{
        	removeStatement();
        }
    }
    
    private static void checkInterrupted(String message) throws InterruptedException{
		if(Thread.interrupted()){
			throw new InterruptedException(message);
		}
		
	}
    
    private static void addStatement(Statement proc) {
    	mapStatement = proc;
	}
    private static void removeStatement(){
    	mapStatement = null;
		save = null;
    }

    /**
     * Execute the store procedure
     *
     * @param store_name:
     *            store procedure name
     * @param params:
     *            list of parameter
     * @param output_type:
     *            type of out put parameter
     * @return the Object
     * @throws SQLException
     */
    public static Object processStore(Connection conn, String store_name, Object[] params,
            int output_type) throws Exception {
        CallableStatement proc = null;
        try {
            String strparam = "";
            for (int i = 1; params != null && i <= params.length; i++) {
                strparam += "?,";
            }
            if (strparam.length() > 0) {
                strparam = strparam.substring(0, strparam.lastIndexOf(","));
            }
            strparam = "(" + strparam + ")";

            proc = conn.prepareCall("{ ? = call " + store_name + strparam + "}");
            proc.registerOutParameter(1, output_type);
            //<editor-fold defaultstate="collapsed" desc="process proc parameter">
            for (int i = 0; params != null && i < params.length; i++) {
                Object obj = params[i];
                if (obj instanceof Integer) {
                    setInt(proc, i + 2, (Integer) params[i]);
                } else if (obj instanceof String) {
                    setString(proc, i + 2, (String) params[i]);
                } else if (obj instanceof Date) {
                    setDate(proc, i + 2, (Date) params[i]);
                } else if (obj instanceof Timestamp) {
                    setTimestamp(proc, i + 2, (Timestamp) params[i]);
                } else if (obj instanceof Time) {
                    setTime(proc, i + 2, (Time) params[i]);
                } else if (obj instanceof Double) {
                    setDouble(proc, i + 2, (Double) params[i]);
                } else if (obj instanceof Float) {
                    setFloat(proc, i + 2, (Float) params[i]);
                } else if (obj instanceof Boolean) {
                    setBoolean(proc, i + 2, (Boolean) params[i]);
                } else if (obj instanceof Long) {
                    setLong(proc, i + 2, (Long) params[i]);
                } else {
                    proc.setObject(i + 2, params[i]);
                }
            }
            
            //proc.get
            
            //</editor-fold>
            proc.execute();

            return proc.getObject(1);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Execute select query
     *
     * @param query:
     *            query is executed
     * @param cols:
     *            number of column in select query
     * @return: array of rows with $cols of column
     * @throws SQLException
     */
    public String[][] select(Connection conn, String query, int cols) throws Exception {
        if (query.trim().toLowerCase().indexOf("select") != 0) {
            throw new SQLException("Only select query, other query is invalid");
        }
        ResultSet rs = null;
        String[][] tmp = null;
        Statement stmt;

        try {
            stmt = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY,
                    ResultSet.CONCUR_READ_ONLY);
            rs = stmt.executeQuery(query);
            rs.last();
            int rows = rs.getRow();
            if (rows == 0) {
                return null;
            }
            tmp = new String[rows][cols];
            int j = 0;
            rs.beforeFirst();
            while (rs.next()) {
                for (int i = 0; i <= cols - 1; i++) {
                    tmp[j][i] = rs.getString(i + 1);
                    if (rs.wasNull()) {
                        tmp[j][i] = "";
                    }
                }
                j++;
            }
            rs.close();
            stmt.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        }
        return tmp;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected static CallableStatement setInt(CallableStatement proc, int pos,
            Integer value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.INTEGER);
        } else {
            proc.setInt(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected static CallableStatement setString(CallableStatement proc, int pos,
            String value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.VARCHAR);
        } else {
            proc.setString(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected static CallableStatement setDate(CallableStatement proc, int pos,
            Date value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.DATE);
        } else {
            proc.setDate(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected static CallableStatement setTimestamp(CallableStatement proc, int pos,
            Timestamp value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.DATE);
        } else {
            proc.setTimestamp(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected static CallableStatement setTime(CallableStatement proc, int pos,
            Time value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.TIME);
        } else {
            proc.setTime(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected static CallableStatement setLong(CallableStatement proc, int pos,
            Long value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.BIGINT);
        } else {
            proc.setLong(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected static CallableStatement setDouble(CallableStatement proc, int pos,
            Double value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.DOUBLE);
        } else {
            proc.setDouble(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected static CallableStatement setFloat(CallableStatement proc, int pos,
            Float value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.FLOAT);
        } else {
            proc.setFloat(pos, value);
        }
        return proc;
    }

    /**
     *
     * @param proc
     * @param pos
     * @param value
     * @return
     * @throws SQLException
     */
    protected static CallableStatement setBoolean(CallableStatement proc, int pos,
            Boolean value) throws SQLException {
        if (value == null) {
            proc.setNull(pos, Types.BOOLEAN);
        } else {
            proc.setBoolean(pos, value);
        }
        return proc;
    }
    @SuppressWarnings("unused")
	private static int failTimes = 0;

    protected boolean isAlive(Connection conn) {
        boolean result = true;
        try {
            conn.createStatement().execute("select 1");
        } catch (Exception ex) {
            ex.printStackTrace();
            failTimes++;
            result = false;
        }
        return result;
    }
}
