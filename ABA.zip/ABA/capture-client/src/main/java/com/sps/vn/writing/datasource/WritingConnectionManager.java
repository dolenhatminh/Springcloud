package com.sps.vn.writing.datasource;

import com.ghp.vae.data_entry.common.Utilities;
import com.sps.vn.config.ApplicationConfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.util.Hashtable;

/**
 * @author vxhoa
 * 
 */
public class WritingConnectionManager {

	private static Logger log = LoggerFactory
			.getLogger(WritingConnectionManager.class);
	static private WritingConnectionManager m_inst;
	private Driver driver;
	private WritingDBConnectionPool connPool;

	@SuppressWarnings("rawtypes")
	private Hashtable Hash_DBCode_Pool = new Hashtable();

	static synchronized public WritingConnectionManager instance() {
		if (m_inst == null) { // a bit careful here
			synchronized (WritingConnectionManager.class) {
				if (m_inst == null) {
					m_inst = new WritingConnectionManager();
				}
			}
		}
		return m_inst;
	}

	private WritingConnectionManager() {
		initEx();
	}

	private void initEx() {
		createPoolsEx();
	}

	private int createPoolsEx() {
		String sdriver = "org.postgresql.Driver";
		String url = "jdbc:postgresql://"
				+ ApplicationConfig.getInstance().getWritingConfig().getUrl()
				+ "/" + ApplicationConfig.getInstance().getWritingConfig().getDatabase();
		String username = ApplicationConfig.getInstance().getWritingConfig().getUsername();
		String password = ApplicationConfig.getInstance().getWritingConfig().getPassword();
		int iMax = 200;
		connPool = new WritingDBConnectionPool(sdriver, url, username, password, iMax);
		return 0;
	}

	/**
	 * <summary> * Returns an open connection. If no one is available, and the
	 * max number of connections has not been reached, a new connection will be
	 * created. </summary> <returns>Connection</returns>
	 */
	public Connection getConn() throws Exception {
		return connPool.getConn();
	}

	public void releaseConn() {
		connPool.releaseConn();
	}

	/**
	 * <summary> Returns an open connection. If no one is available, and the max
	 * number of connections has not been reached, a new connection will be
	 * created. If the max number has been reached, waits until one is available
	 * or the specified time has elapsed </summary> <param name="ltime">long:
	 * number of milliseconds to wait </param> <returns>Connection</returns>
	 */
	public Connection getConn(long ltime) {
		return connPool.getConn(ltime);
	}

	/**
	 * <summary> Return a connection to the pool </summary> <param
	 * name="conn">Connection: Connection that will be returned to the
	 * pool</param> <returns>void</returns>
	 */
	public void freeConn(Connection conn) {
		connPool.freeConn(conn);
	}

	public void removeConnError(Connection conn) {
		connPool.removeConnError(conn);
	}

	/**
	 * <summary> Close all open connections and de-registers all drivers
	 * </summary> <returns>void</returns>
	 */
	public synchronized void release() throws Exception {
		// pool
		try {
			connPool.release();
		} catch (Exception e) {
			throw e;

		}
		// driver
		try {
			DriverManager.deregisterDriver(driver);
		} catch (Exception e) {
			log.error(Utilities.getStackTrace(e));
			throw e;

		}
	}

	// Additional Pool Here
	@SuppressWarnings("unchecked")
	private int createPoolsEx(String dbcode) {
		String sdriver = "org.postgresql.Driver";
		String url = "jdbc:postgresql://" + ApplicationConfig.getInstance().getWritingConfig().getUrl()
				+ "/" + ApplicationConfig.getInstance().getWritingConfig().getDatabase();
		String username = ApplicationConfig.getInstance().getWritingConfig().getUsername();
		String password = ApplicationConfig.getInstance().getWritingConfig().getPassword();
		int iMax = 200;
		Hash_DBCode_Pool.put(dbcode, new WritingDBConnectionPool(sdriver, url,
				username, password, iMax));
		return 0;
	}

	private WritingDBConnectionPool getPool(String dbcode) {
		WritingDBConnectionPool pool = (WritingDBConnectionPool) Hash_DBCode_Pool.get(dbcode);
		if (pool == null) {
			createPoolsEx(dbcode);
			return getPool(dbcode);
		} else {
			return pool;
		}
	}

	/**
	 * <summary> * Returns an open connection from the pool of the associated
	 * database. If no one is available, and the max number of connections has
	 * not been reached, a new connection will be created. </summary>
	 * <returns>Connection</returns>
	 */
	public Connection getConn(String dbcode) throws Exception {
		WritingDBConnectionPool pool = getPool(dbcode);
		if (pool != null) {
			return pool.getConn();
		}
		return null;
	}

	/**
	 * <summary> Return a connection to the pool associated with the dbcode
	 * </summary> <param name="dbcpde">Database code: The code prepresent for
	 * the database</param> <param name="conn">Connection: Connection that will
	 * be returned to the pool</param> <returns>void</returns>
	 */
	public void freeConn(String dbcode, Connection conn) throws Exception {
		WritingDBConnectionPool pool = getPool(dbcode);
		if (pool != null) {
			pool.freeConn(conn);
		}
	}

	/**
	 * <summary> Close all open connections and de-registers all drivers
	 * associated with the database mentioned through the dbcode </summary>
	 * <returns>void</returns>
	 */
	public synchronized void release(String dbcode) throws Exception {
		// pool
		try {
			WritingDBConnectionPool pool = getPool(dbcode);
			if (pool != null) {
				pool.release();
			}
		} catch (Exception e) {
			throw e;
		}
	}

}
