package com.sps.vn.config;

public class DisplayConfig {
	private String lookupTitle;
	private String[] lookupInfo;
	
	private String firmaTitle;
	private String[] firmaInfo;
	
	private String zusatTitle;
	private String[] zusatInfo;
	
	private String anredeTitle;
	private String[] anredeInfo;
	
	private String vornameTitle;
	private String[] vornameInfo;
	
	private String nameTitle;
	private String[] nameInfo;
	
	private String plzTitle;
	private String[] plzInfo;
	
	private String ortTitle;
	private String[] ortInfo;
	
	private String strasseTitle;
	private String[] strasseInfo;
	
	private String houseTitle;
	private String[] houseInfo;
	
	private String postfachTitle;
	private String[] postfachInfo;
	
	private String stockwerkTitle;
	private String[] stockwerkInfo;
	
	private String adresszusatzTitle;
	private String[] adresszusatzInfo;
	
	private String co_addresseTitle;
	private String[] co_addresseInfo;
	
	private String pickpostTitle;
	private String[] pickpostInfo;
	
	private String postlagerndTitle;
	private String[] postlagerndInfo;
	
	private String mypost24Title;
	private String[] mypost24Info;
	
	private String moveImage;
	
	public String getLookupTitle() {
		return lookupTitle;
	}
	public void setLookupTitle(String lookupTitle) {
		this.lookupTitle = lookupTitle;
	}
	public String[] getLookupInfo() {
		return lookupInfo;
	}
	public void setLookupInfo(String[] lookupInfo) {
		this.lookupInfo = lookupInfo;
	}
	public String getFirmaTitle() {
		return firmaTitle;
	}
	public void setFirmaTitle(String firmaTitle) {
		this.firmaTitle = firmaTitle;
	}
	public String[] getFirmaInfo() {
		return firmaInfo;
	}
	public void setFirmaInfo(String[] firmaInfo) {
		this.firmaInfo = firmaInfo;
	}
	public String getZusatTitle() {
		return zusatTitle;
	}
	public void setZusatTitle(String zusatTitle) {
		this.zusatTitle = zusatTitle;
	}
	public String[] getZusatInfo() {
		return zusatInfo;
	}
	public void setZusatInfo(String[] zusatInfo) {
		this.zusatInfo = zusatInfo;
	}
	public String getAnredeTitle() {
		return anredeTitle;
	}
	public void setAnredeTitle(String anredeTitle) {
		this.anredeTitle = anredeTitle;
	}
	public String[] getAnredeInfo() {
		return anredeInfo;
	}
	public void setAnredeInfo(String[] anredeInfo) {
		this.anredeInfo = anredeInfo;
	}
	public String getVornameTitle() {
		return vornameTitle;
	}
	public void setVornameTitle(String vornameTitle) {
		this.vornameTitle = vornameTitle;
	}
	public String[] getVornameInfo() {
		return vornameInfo;
	}
	public void setVornameInfo(String[] vornameInfo) {
		this.vornameInfo = vornameInfo;
	}
	public String getNameTitle() {
		return nameTitle;
	}
	public void setNameTitle(String nameTitle) {
		this.nameTitle = nameTitle;
	}
	public String[] getNameInfo() {
		return nameInfo;
	}
	public void setNameInfo(String[] nameInfo) {
		this.nameInfo = nameInfo;
	}
	public String getPlzTitle() {
		return plzTitle;
	}
	public void setPlzTitle(String plzTitle) {
		this.plzTitle = plzTitle;
	}
	public String[] getPlzInfo() {
		return plzInfo;
	}
	public void setPlzInfo(String[] plzInfo) {
		this.plzInfo = plzInfo;
	}
	public String getOrtTitle() {
		return ortTitle;
	}
	public void setOrtTitle(String ortTitle) {
		this.ortTitle = ortTitle;
	}
	public String[] getOrtInfo() {
		return ortInfo;
	}
	public void setOrtInfo(String[] ortInfo) {
		this.ortInfo = ortInfo;
	}
	public String getStrasseTitle() {
		return strasseTitle;
	}
	public void setStrasseTitle(String strasseTitle) {
		this.strasseTitle = strasseTitle;
	}
	public String[] getStrasseInfo() {
		return strasseInfo;
	}
	public void setStrasseInfo(String[] strasseInfo) {
		this.strasseInfo = strasseInfo;
	}
	public String getHouseTitle() {
		return houseTitle;
	}
	public void setHouseTitle(String houseTitle) {
		this.houseTitle = houseTitle;
	}
	public String[] getHouseInfo() {
		return houseInfo;
	}
	public void setHouseInfo(String[] houseInfo) {
		this.houseInfo = houseInfo;
	}
	public String getPostfachTitle() {
		return postfachTitle;
	}
	public void setPostfachTitle(String postfachTitle) {
		this.postfachTitle = postfachTitle;
	}
	public String[] getPostfachInfo() {
		return postfachInfo;
	}
	public void setPostfachInfo(String[] postfachInfo) {
		this.postfachInfo = postfachInfo;
	}
	public String getStockwerkTitle() {
		return stockwerkTitle;
	}
	public void setStockwerkTitle(String stockwerkTitle) {
		this.stockwerkTitle = stockwerkTitle;
	}
	public String[] getStockwerkInfo() {
		return stockwerkInfo;
	}
	public void setStockwerkInfo(String[] stockwerkInfo) {
		this.stockwerkInfo = stockwerkInfo;
	}
	public String getAdresszusatzTitle() {
		return adresszusatzTitle;
	}
	public void setAdresszusatzTitle(String adresszusatzTitle) {
		this.adresszusatzTitle = adresszusatzTitle;
	}
	public String[] getAdresszusatzInfo() {
		return adresszusatzInfo;
	}
	public void setAdresszusatzInfo(String[] adresszusatzInfo) {
		this.adresszusatzInfo = adresszusatzInfo;
	}
	public String getCo_addresseTitle() {
		return co_addresseTitle;
	}
	public void setCo_addresseTitle(String co_addresseTitle) {
		this.co_addresseTitle = co_addresseTitle;
	}
	public String[] getCo_addresseInfo() {
		return co_addresseInfo;
	}
	public void setCo_addresseInfo(String[] co_addresseInfo) {
		this.co_addresseInfo = co_addresseInfo;
	}
	public String getPickpostTitle() {
		return pickpostTitle;
	}
	public void setPickpostTitle(String pickpostTitle) {
		this.pickpostTitle = pickpostTitle;
	}
	public String[] getPickpostInfo() {
		return pickpostInfo;
	}
	public void setPickpostInfo(String[] pickpostInfo) {
		this.pickpostInfo = pickpostInfo;
	}
	public String getPostlagerndTitle() {
		return postlagerndTitle;
	}
	public void setPostlagerndTitle(String postlagerndTitle) {
		this.postlagerndTitle = postlagerndTitle;
	}
	public String[] getPostlagerndInfo() {
		return postlagerndInfo;
	}
	public void setPostlagerndInfo(String[] postlagerndInfo) {
		this.postlagerndInfo = postlagerndInfo;
	}
	public String getMypost24Title() {
		return mypost24Title;
	}
	public void setMypost24Title(String mypost24Title) {
		this.mypost24Title = mypost24Title;
	}
	public String[] getMypost24Info() {
		return mypost24Info;
	}
	public void setMypost24Info(String[] mypost24Info) {
		this.mypost24Info = mypost24Info;
	}
	
	public String getMoveImage() {
		return moveImage;
	}
	public void setMoveImage(String moveImage) {
		this.moveImage = moveImage;
	}
}
