package com.sps.vn.writing.datasource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;


public class DALLogin extends WritingDBase{
	private static Logger log = LoggerFactory.getLogger(DALLogin.class);
	public static boolean confirmUser(String username, String fullname) {
		Boolean result = false;
		Connection conn = null;
		WritingBaseDAL baseDAL = null;
		try {
			baseDAL = new WritingBaseDAL();
			conn = baseDAL.getConnection();
			result = (Boolean) processStore(conn, "vae.confirm_user",
					new String[] { username, fullname }, Types.BOOLEAN);
		} catch (SQLException ex) {
			log.error("",ex);
		} catch (Exception ex) {
			log.error("",ex);
		} finally {
			baseDAL.freeCommitConnection(conn);
		}
		return result;
	}
	
	public static String getRole(String username, String pass) {
		String result = "";
		Connection conn = null;
		WritingBaseDAL baseDAL = null;
		try {
			baseDAL = new WritingBaseDAL();
			conn = baseDAL.getConnection();
			result = (String) processStore(conn, "vae.getrole", new String[] {
					username, pass }, Types.VARCHAR);
		} catch (SQLException ex) {
			log.error("",ex);
		} catch (Exception ex) {
			log.error("",ex);
		} finally {
			baseDAL.freeCommitConnection(conn);
		}
		return result;
	}
	
	public static Map<String, Object> getInformation(String username, String pass) {
		Map<String, Object>  result = new HashMap<String, Object>();
		Connection conn = null;
		WritingBaseDAL baseDAL = null;
		try {
			baseDAL = new WritingBaseDAL();
			conn = baseDAL.getConnection();
			conn.setAutoCommit(false);
			ResultSet rs = (ResultSet) processStore(conn, "vae.get_information",new String[] { username, pass }, Types.OTHER);
			while (rs.next()){
				result.put("username",rs.getString("username"));
				result.put("fullname",rs.getString("fullname"));
				Integer level = rs.getInt("level");
				if(level == null  || level == 0){
					result.put("level",9);
				}else{
					result.put("level",level);
				}
				
				result.put("id",rs.getInt("id"));
				
			}
			conn.commit();
		} catch (SQLException ex) {
			log.error("",ex);
		} catch (Exception ex) {
			log.error("",ex);
		} finally {
			baseDAL.freeCommitConnection(conn);
		}
		return result;
	}
	
	public static Map<String, Object> getInformation(String username) {
		Map<String, Object>  result = new HashMap<String, Object>();
		Connection conn = null;
		WritingBaseDAL baseDAL = null;
		try {
			baseDAL = new WritingBaseDAL();
			conn = baseDAL.getConnection();
			conn.setAutoCommit(false);
			ResultSet rs = (ResultSet) processStore(conn, "vae.get_information",new String[] { username }, Types.OTHER);
			while (rs.next()){
				result.put("username",rs.getString("username"));
				result.put("fullname",rs.getString("fullname"));
				Integer level = rs.getInt("level");
				if(level == null ){
					result.put("level",9);
				}else{
					result.put("level",level);
				}
				
				result.put("id",rs.getInt("id"));
				
			}
			conn.commit();
		} catch (SQLException ex) {
			log.error("",ex);
		} catch (Exception ex) {
			log.error("",ex);
		} finally {
			
			baseDAL.freeCommitConnection(conn);
		}
		return result;
	}

}
