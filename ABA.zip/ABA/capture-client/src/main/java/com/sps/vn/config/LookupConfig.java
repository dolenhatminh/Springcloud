package com.sps.vn.config;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpHost;

public class LookupConfig {

	private String searchRestService;
	private String searchFirst;
	private String lookupExtraRestService;

	private String ocrKdpCountService;
	private String ocrPlzCountService;
	private String ocrOrtCountService;
	private String ocrStrasseCountService;
	private String ocrFirmaSignSearchService;

	private String vaeUtilNormalize;

	private String lookupHauskeyRestService;
	private String lookupDuplicationCountRestService;

	private String zubofiAddressidRestService;
	private String zubofiHauskeyRestService;
	private String zubofiSpecialAddressidRestService;
	private String zubofiStreetnumberRestService;
	private String zubofiSpecialAddressidRestServiceCheck;
	private String zubofiSpecialAddressidRestServiceSameCheck;
	private String kdpSuggestionRestService;
	private String kdpCheckSwapConditionRestService;
	private String zubofiSpecialPickpostHauskeyRestService;
	private String zubofiSpecialPostfachHauskeyRestService;
	private String zubofiSpecialPostlagerndHauskeyRestService;

	private WordSuggestionConfig wordSuggestionConfig;

	private List<HttpHost> hosts;
	private int retryTimes;
	private int delay;
	private int socketTimeout;
	private int connectionTimeout;
	
	private String checkMoveConditionRestService;
	private String lookupASDPPlz;

	public WordSuggestionConfig getWordSuggestionConfig() {
		return this.wordSuggestionConfig;
	}

	public void setWordSuggestionConfig(WordSuggestionConfig wordSuggestionConfig) {
		this.wordSuggestionConfig = wordSuggestionConfig;
	}

	public LookupConfig() {
		this.hosts = new ArrayList<HttpHost>();
		this.retryTimes = 0;
		this.delay = 0;
		this.wordSuggestionConfig = new WordSuggestionConfig();
	}

	public String getLookupDuplicationCountRestService() {
		return this.lookupDuplicationCountRestService;
	}

	public void setLookupDuplicationCountRestService(String lookupDuplicationCountRestService) {
		this.lookupDuplicationCountRestService = lookupDuplicationCountRestService;
	}

	public String getLookupHauskeyRestService() {
		return this.lookupHauskeyRestService;
	}

	public void setLookupHauskeyRestService(String lookupHauskeyRestService) {
		this.lookupHauskeyRestService = lookupHauskeyRestService;
	}

	public String getZubofiAddressidRestService() {
		return this.zubofiAddressidRestService;
	}

	public String getOcrKdpCountService() {
		return this.ocrKdpCountService;
	}

	public void setOcrKdpCountService(String ocrKdpCountService) {
		this.ocrKdpCountService = ocrKdpCountService;
	}

	public String getOcrPlzCountService() {
		return this.ocrPlzCountService;
	}

	public void setOcrPlzCountService(String ocrPlzCountService) {
		this.ocrPlzCountService = ocrPlzCountService;
	}

	public String getOcrOrtCountService() {
		return this.ocrOrtCountService;
	}

	public void setOcrOrtCountService(String ocrOrtCountService) {
		this.ocrOrtCountService = ocrOrtCountService;
	}

	public String getOcrStrasseCountService() {
		return this.ocrStrasseCountService;
	}

	public String getVaeUtilNormalize() {
		return this.vaeUtilNormalize;
	}

	public void setVaeUtilNormalize(String vaeUtilNormalize) {
		this.vaeUtilNormalize = vaeUtilNormalize;
	}

	public void setOcrStrasseCountService(String ocrStrasseCountService) {
		this.ocrStrasseCountService = ocrStrasseCountService;
	}

	public String getOcrFirmaSignSearchService() {
		return this.ocrFirmaSignSearchService;
	}

	public void setOcrFirmaSignSearchService(String ocrFirmaSignSearchService) {
		this.ocrFirmaSignSearchService = ocrFirmaSignSearchService;
	}

	public void setZubofiAddressidRestService(String zubofiAddressidRestService) {
		this.zubofiAddressidRestService = zubofiAddressidRestService;
	}

	public String getZubofiHauskeyRestService() {
		return this.zubofiHauskeyRestService;
	}

	public void setZubofiHauskeyRestService(String zubofiHauskeyRestService) {
		this.zubofiHauskeyRestService = zubofiHauskeyRestService;
	}

	public String getZubofiSpecialAddressidRestService() {
		return this.zubofiSpecialAddressidRestService;
	}

	public void setZubofiSpecialAddressidRestService(String zubofiSpecialAddressidRestService) {
		this.zubofiSpecialAddressidRestService = zubofiSpecialAddressidRestService;
	}

	public String getZubofiStreetnumberRestService() {
		return this.zubofiStreetnumberRestService;
	}

	public void setZubofiStreetnumberRestService(String zubofiStreetnumberRestService) {
		this.zubofiStreetnumberRestService = zubofiStreetnumberRestService;
	}
	
	public String getSearchFirst() {
		return searchFirst;
	}

	public void setSearchFirst(String searchFirst) {
		this.searchFirst = searchFirst;
	}

	public String getSearchRestService() {
		return this.searchRestService;
	}

	public void setSearchRestService(String searchRestService) {
		this.searchRestService = searchRestService;
	}

	public String getLookupExtraRestService() {
		return this.lookupExtraRestService;
	}

	public void setLookupExtraRestService(String lookupExtraRestService) {
		this.lookupExtraRestService = lookupExtraRestService;
	}

	public String getZubofiSpecialAddressidRestServiceCheck() {
		return this.zubofiSpecialAddressidRestServiceCheck;
	}

	public void setZubofiSpecialAddressidRestServiceCheck(String zubofiSpecialAddressidRestServiceCheck) {
		this.zubofiSpecialAddressidRestServiceCheck = zubofiSpecialAddressidRestServiceCheck;
	}

	public String getZubofiSpecialAddressidRestServiceSameCheck() {
		return this.zubofiSpecialAddressidRestServiceSameCheck;
	}

	public void setZubofiSpecialAddressidRestServiceSameCheck(String zubofiSpecialAddressidRestServiceSameCheck) {
		this.zubofiSpecialAddressidRestServiceSameCheck = zubofiSpecialAddressidRestServiceSameCheck;
	}

	public String getKdpSuggestionRestService() {
		return this.kdpSuggestionRestService;
	}

	public void setKdpSuggestionRestService(String kdpSuggestionRestService) {
		this.kdpSuggestionRestService = kdpSuggestionRestService;
	}

	public String getKdpCheckSwapConditionRestService() {
		return this.kdpCheckSwapConditionRestService;
	}

	public void setKdpCheckSwapConditionRestService(String kdpCheckSwapConditionRestService) {
		this.kdpCheckSwapConditionRestService = kdpCheckSwapConditionRestService;
	}

	public String getZubofiSpecialPickpostHauskeyRestService() {
		return this.zubofiSpecialPickpostHauskeyRestService;
	}

	public void setZubofiSpecialPickpostHauskeyRestService(String zubofiSpecialHauskeyRestService) {
		this.zubofiSpecialPickpostHauskeyRestService = zubofiSpecialHauskeyRestService;
	}

	public String getZubofiSpecialPostfachHauskeyRestService() {
		return this.zubofiSpecialPostfachHauskeyRestService;
	}

	public void setZubofiSpecialPostfachHauskeyRestService(String zubofiSpecialPostfachHauskeyRestService) {
		this.zubofiSpecialPostfachHauskeyRestService = zubofiSpecialPostfachHauskeyRestService;
	}

	public String getZubofiSpecialPostlagerndHauskeyRestService() {
		return zubofiSpecialPostlagerndHauskeyRestService;
	}

	public void setZubofiSpecialPostlagerndHauskeyRestService(
			String zubofiSpecialPostlagerndHauskeyRestService) {
		this.zubofiSpecialPostlagerndHauskeyRestService = zubofiSpecialPostlagerndHauskeyRestService;
	}

	public int getRetryTimes() {
		return this.retryTimes;
	}

	public void setRetryTimes(int retryTimes) {
		this.retryTimes = retryTimes;
	}

	public long getDelay() {
		return this.delay;
	}

	public void setDelay(int delay) {
		this.delay = delay;
	}

	public List<HttpHost> getHosts() {
		return this.hosts;
	}

	public void setHosts(List<HttpHost> hosts) {
		this.hosts = hosts;
	}

	public void setHosts(List<String> hosts, List<String> ports) {
		if (hosts.size() > 0) {
			int i = 0;
			while (i < hosts.size()) {
				final String sHost = hosts.get(i);
				final String sPort = ports.get(i) == null ? "0" : ports.get(i);
				final HttpHost host = new HttpHost(sHost, Integer.parseInt(sPort));
				this.hosts.add(new HttpHost(host));
				i++;
			}
		}
	}

	public int getSocketTimeout() {
		return this.socketTimeout;
	}

	public void setSocketTimeout(int socketTimeout) {
		this.socketTimeout = socketTimeout;
	}

	public int getConnectionTimeout() {
		return this.connectionTimeout;
	}

	public void setConnectionTimeout(int connectionTimeout) {
		this.connectionTimeout = connectionTimeout;
	}

	public void setCheckMoveConditionRestService(
			String checkMoveConditionRestService) {
		this.checkMoveConditionRestService = checkMoveConditionRestService;
	}

	public String getCheckMoveConditionRestService() {
		return checkMoveConditionRestService;
	}

	public String getLookupASDPPlz() {
		return lookupASDPPlz;
	}

	public void setLookupASDPPlz(String lookupASDPPlz) {
		this.lookupASDPPlz = lookupASDPPlz;
	}
	
	
}
