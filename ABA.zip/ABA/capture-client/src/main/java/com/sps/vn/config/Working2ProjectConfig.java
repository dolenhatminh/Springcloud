package com.sps.vn.config;

import java.util.HashMap;

public class Working2ProjectConfig {
	private boolean connectToBrokerActiveMQ;
	private int activeMQJmsTimeout;
	private HashMap<String, String> pauseCmd;
	private HashMap<String, String> resumeCmd;

	public HashMap<String, String> getPauseCmd() {
		return pauseCmd;
	}

	public void setPauseCmd(HashMap<String, String> pauseCmd) {
		this.pauseCmd = pauseCmd;
	}

	public HashMap<String, String> getResumeCmd() {
		return resumeCmd;
	}

	public void setResumeCmd(HashMap<String, String> resumeCmd) {
		this.resumeCmd = resumeCmd;
	}

	public boolean isConnectToBrokerActiveMQ() {
		return connectToBrokerActiveMQ;
	}

	public void setConnectToBrokerActiveMQ(boolean connectToBrokerActiveMQ) {
		this.connectToBrokerActiveMQ = connectToBrokerActiveMQ;
	}

	public int getActiveMQJmsTimeout() {
		return activeMQJmsTimeout;
	}

	public void setActiveMQJmsTimeout(int activeMQJmsTimeout) {
		this.activeMQJmsTimeout = activeMQJmsTimeout;
	}

}
