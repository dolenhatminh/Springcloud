package com.sps.vn.lookup.datasource;

import com.ghp.vae.data_entry.common.Utilities;
import com.sps.vn.config.ApplicationConfig;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vae.client.transfer.LookupKey;

import java.sql.*;
import java.util.*;

public class LookupDALViewData extends LookupDBase {

	// <editor-fold defaultstate="collapsed" desc="constructor method">
	private static Logger log = LoggerFactory
			.getLogger(LookupDALViewData.class);

	public LookupDALViewData() {
	}

	private String processdata(String value) {
		if (value == null || value.equals("")) {
			return "";
		} else {
			String newValue = value.toLowerCase();
			String tmp = "";
			for (char c : newValue.toCharArray()) {
				if (c == '+') {
					tmp += "\\\\+";
				} else {
					tmp += c;
				}
				newValue = tmp;
			}
			newValue = newValue.replace('*', '%');
			newValue = newValue.replace("'", "''");
			if (newValue.indexOf(';') != newValue.length() - 1) {
				newValue = newValue + "%";
			} else {
				newValue = newValue.substring(0, newValue.length() - 1);
			}
			log.debug("\nvalue:" + value + "\nnew value:" + newValue);
			return newValue;
		}
	}

	public String checkSpace(String fieldNameLike) {
		char[] arr = null;
		String searchKey = "";
		if (fieldNameLike.contains(" ")) {
			arr = fieldNameLike.toCharArray();
			for (int i = 0; i < arr.length; i++) {
				if (Character.isWhitespace(arr[i])) {
					searchKey = processdata(searchKey);
					searchKey = searchKey + arr[i];
				} else {
					searchKey = searchKey + arr[i];
				}
				if (i == arr.length - 1) {
					searchKey = processdata(searchKey);
				}
			}
		} else {
			searchKey = processdata(fieldNameLike);
		}
		return searchKey;
	}

	public String removeDuplicateWord(String original) {
		String[] data = original.split(";");
		List<String> list = Arrays.asList(data);
		Set<String> set = new HashSet<String>(list);
		String[] result = new String[set.size()];
		set.toArray(result);
		return set.toString().replace("[", "").replace("]", "");
	}

}
