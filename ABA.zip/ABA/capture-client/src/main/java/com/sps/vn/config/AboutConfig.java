package com.sps.vn.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class AboutConfig {
	private static Logger log = LoggerFactory.getLogger(AboutConfig.class);
	private String appname;
	private String version;
	private String copyright;

	private Map<String, String> members = new HashMap<String, String>(0);

	public AboutConfig() {
		init();

	}

	public void init() {
		try {
			String xmlFile = "About.xml";
                        
//			File file = new File(this.getClass().getResource(xmlFile).toURI());
                        
                        String userDir = System.getProperty("user.dir");
                        String filePath = userDir + "/config/" + xmlFile;
                        File file = new File(filePath);
                        
			if (file.exists()) {
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				Document doc = builder.parse(file);

				Element element = doc.getDocumentElement();

				String appname = element.getElementsByTagName("appname").item(0).getTextContent();
//				String version = element.getElementsByTagName("version").item(0).getTextContent();
				String copyright = element.getElementsByTagName("copyright").item(0).getTextContent();

				NodeList node = element.getElementsByTagName("author");

				int i = 0;
				while (true) {

					if (node.item(i) == null) {
						break;
					}

					String name = node.item(i).getChildNodes().item(1).getTextContent();
					String role = node.item(i).getChildNodes().item(3).getTextContent();

					members.put(name, role);

					i++;
				}

				setAppname(appname);
				setVersion(version);
				setCopyright(copyright);

			} else {
				log.debug(xmlFile + " (file name) doesn't found!");
			}

		} catch (Exception e) {
			log.error("", e);
		}

	}

	public String getAppname() {
		return appname;
	}

	public void setAppname(String appname) {
		this.appname = appname;
	}

	public String getVersion() {
        try{
            if (version == null) {
                String filePath = System.getProperty("user.dir") + "/pom.properties";
                InputStream is = new FileInputStream(filePath);
                if (is == null) {
                    version = "Fail to get version.";
                } else {
                    Properties props = new Properties();
                    props.load(is);

                    version = props.getProperty("version");
                }
            }
            return version;
        }catch (Exception e){
            log.error("", e);
            return version;
        }
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getCopyright() {
		return copyright;
	}

	public void setCopyright(String copyright) {
		this.copyright = copyright;
	}

	public Map<String, String> getMembers() {
		return members;
	}

	public void setMembers(Map<String, String> members) {
		this.members = members;
	}

}
