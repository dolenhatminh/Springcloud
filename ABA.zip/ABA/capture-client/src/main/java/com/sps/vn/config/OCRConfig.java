package com.sps.vn.config;

import java.util.Properties;

public class OCRConfig {
	private String hostname;
	private String port;
	private String controller;
	private String username;
	private String password;
	private String httpClientTimeout;
	private String totalConnection;

	private int height;
	private int width;
	private int size;
	private String forCheck;
	private String type;
	private String imageType;
	private String projectName;
	private boolean deskew;
	private String language;
	private boolean acceptFirstResult;
	private boolean includeCharacterResult;
	private int priority;
	private String pattern;
	private String serverTimeout;

	private double defaultAngle;

	public String getHostname() {
		return this.hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getPort() {
		return this.port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getController() {
		return this.controller;
	}

	public void setController(String controller) {
		this.controller = controller;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getHttpClientTimeout() {
		return this.httpClientTimeout;
	}

	public void setHttpClientTimeout(String httpClientTimeout) {
		this.httpClientTimeout = httpClientTimeout;
	}

	public String getTotalConnection() {
		return this.totalConnection;
	}

	public void setTotalConnection(String totalConnection) {
		this.totalConnection = totalConnection;
	}

	public String getServerTimeout() {
		return this.serverTimeout;
	}

	public void setServerTimeout(String serverTimeout) {
		this.serverTimeout = serverTimeout;
	}

	public String getForCheck() {
		return this.forCheck;
	}

	public void setForCheck(String forCheck) {
		this.forCheck = forCheck;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getImageType() {
		return this.imageType;
	}

	public void setImageType(String imageType) {
		this.imageType = imageType;
	}

	public String getProjectName() {
		return this.projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public boolean isDeskew() {
		return this.deskew;
	}

	public void setDeskew(boolean deskew) {
		this.deskew = deskew;
	}

	public String getLanguage() {
		return this.language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public boolean isAcceptFirstResult() {
		return this.acceptFirstResult;
	}

	public void setAcceptFirstResult(boolean acceptFirstResult) {
		this.acceptFirstResult = acceptFirstResult;
	}

	public boolean isIncludeCharacterResult() {
		return this.includeCharacterResult;
	}

	public void setIncludeCharacterResult(boolean includeCharacterResult) {
		this.includeCharacterResult = includeCharacterResult;
	}

	public int getPriority() {
		return this.priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getPattern() {
		return this.pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public int getSize() {
		return this.size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public int getHeight() {
		return this.height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWidth() {
		return this.width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public double getDefaultAngle() {
		return this.defaultAngle;
	}

	public void setDefaultAngle(double defaultAngle) {
		this.defaultAngle = defaultAngle;
	}

	public Properties toProperties() {
		final Properties prop = new Properties();

		prop.put("sps.ocrcenter.hostname", this.hostname);
		prop.put("sps.ocrcenter.port", this.port);
		prop.put("sps.ocrcenter.controller", this.controller);
		prop.put("sps.ocrcenter.username", this.username);
		prop.put("sps.ocrcenter.password", this.password);
		prop.put("sps.ocrcenter.timeout", this.httpClientTimeout);
		prop.put("sps.ocrcenter.totalConnection", this.totalConnection);
		prop.put("sps.ocrcenter.server.timeout", this.serverTimeout);

		prop.put("sps.ocrcenter.custom.ocrType", this.type);
		prop.put("sps.ocrcenter.custom.deskew", this.deskew);
		prop.put("sps.ocrcenter.custom.imageUrl", "");
		prop.put("sps.ocrcenter.custom.imageType", this.imageType);
		prop.put("sps.ocrcenter.custom.projectName", this.projectName);
		prop.put("sps.ocrcenter.custom.language", this.language);
		prop.put("sps.ocrcenter.custom.acceptFirstResult", this.acceptFirstResult);
		prop.put("sps.ocrcenter.custom.includeCharacterResult", this.includeCharacterResult);
		prop.put("sps.ocrcenter.custom.pattern", this.pattern);
		prop.put("sps.ocrcenter.custom.priority", this.priority);

		return prop;

	}
}
