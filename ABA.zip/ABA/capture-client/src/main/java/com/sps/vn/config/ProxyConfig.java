package com.sps.vn.config;

public class ProxyConfig {
	private String host;
	private int proxyPort;
	private int nettyPort;
	private int retryTimes;
	private String restServiceTime;

	public int getRetryTimes() {
		return retryTimes;
	}

	public void setRetryTimes(int retryTimes) {
		this.retryTimes = retryTimes;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public int getProxyPort() {
		return proxyPort;
	}

	public void setProxyPort(int proxyPort) {
		this.proxyPort = proxyPort;
	}

	public int getNettyPort() {
		return nettyPort;
	}

	public void setNettyPort(int nettyPort) {
		this.nettyPort = nettyPort;
	}

	public String getRestServiceTime() {
		return restServiceTime;
	}

	public void setRestServiceTime(String restServiceTime) {
		this.restServiceTime = restServiceTime;
	}

}
