package com.sps.vn.config;

public class BusinessConfig {
	private String signArmy;
	private String timeZone;
	private float serviceLevel;
	private int validPercent;
	private String blockingWord;
	private long showPopupTime;
	private int averageImageSize;
	private int zoomHeight;
	private int zoomWidth;
	private String training;
	private String locationLDAP;
	private String validRoleList;
	private boolean loginWithLdap;
	private boolean runOnCL;

	private int delaySuggestion;
	private int delayTryingTime;
	private int waitingTimeRequestCard;
	private String notWord;
	private String replaceEndWith;
	private String alarmKDPID;
		
	public String getReplaceEndWith() {
		return replaceEndWith;
	}

	public void setReplaceEndWith(String replaceEndWith) {
		this.replaceEndWith = replaceEndWith;
	}

	public String getAlarmKDPID() {
		return alarmKDPID;
	}

	public void setAlarmKDPID(String alarmKDPID) {
		this.alarmKDPID = alarmKDPID;
	}

	public String getNotWord() {
		return notWord;
	}

	public void setNotWord(String notWord) {
		this.notWord = notWord;
	}

	public int getWaitingTimeRequestCard() {
		return waitingTimeRequestCard;
	}

	public void setWaitingTimeRequestCard(int waitingTimeRequestCard) {
		this.waitingTimeRequestCard = waitingTimeRequestCard;
	}

	public int getDelayTryingTime() {
		return delayTryingTime;
	}

	public int getDelaySuggestion() {
		return delaySuggestion;
	}

	public void setDelaySuggestion(int delaySuggestion) {
		this.delaySuggestion = delaySuggestion;
	}

	public int geteplayTryingTime() {
		return delayTryingTime;
	}

	public void setDelayTryingTime(int delayTryingTime) {
		this.delayTryingTime = delayTryingTime;
	}

	public boolean isRunOnCL() {
		return runOnCL;
	}

	public void setRunOnCL(boolean runOnCL) {
		this.runOnCL = runOnCL;
	}

	public boolean isLoginWithLdap() {
		return loginWithLdap;
	}

	public void setLoginWithLdap(boolean loginWithLdap) {
		this.loginWithLdap = loginWithLdap;
	}

	public String getValidRoleList() {
		return validRoleList;
	}

	public void setValidRoleList(String validRoleList) {
		this.validRoleList = validRoleList;
	}

	public String getLocationLDAP() {
		return locationLDAP;
	}

	public void setLocationLDAP(String locationLDAP) {
		this.locationLDAP = locationLDAP;
	}

	public String getTraining() {
		return training;
	}

	public void setTraining(String training) {
		this.training = training;
	}

	public int getZoomHeight() {
		return zoomHeight;
	}

	public void setZoomHeight(int zoomHeight) {
		this.zoomHeight = zoomHeight;
	}

	public int getZoomWidth() {
		return zoomWidth;
	}

	public void setZoomWidth(int zoomWidth) {
		this.zoomWidth = zoomWidth;
	}

	public int getAverageImageSize() {
		return averageImageSize;
	}

	public void setAverageImageSize(int averageImageSize) {
		this.averageImageSize = averageImageSize;
	}

	public long getShowPopupTime() {
		return showPopupTime;
	}

	public void setShowPopupTime(long showPopupTime) {
		this.showPopupTime = showPopupTime;
	}

	public String getBlockingWord() {
		return blockingWord;
	}

	public void setBlockingWord(String blockingWord) {
		this.blockingWord = blockingWord;
	}

	public int getValidPercent() {
		return validPercent;
	}

	public void setValidPercent(int validPercent) {
		this.validPercent = validPercent;
	}

	public float getServiceLevel() {
		return serviceLevel;
	}

	public void setServiceLevel(float serviceLevel) {
		this.serviceLevel = serviceLevel;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}


	public String getSignArmy() {
		return signArmy;
	}

	public void setSignArmy(String signArmy) {
		this.signArmy = signArmy;
	}

}
