package com.sps.vn.utilities;

/**
 *
 * @author Pritom K Mondal
 */
public class AsciiString {
    public static void main(String[] args) {
        String inputString = "Ëéèêüùûuìíîïöòôœäáàâæšßç";
        String encoded1 = "&#123;&#34;collectionId&#34;&#58;61&#44;&#34;collectionStatus&#34;&#58;&#123;&#34;id&#34;&#58;61&#44;&#34;imageFileName&#34;&#58;&#34;c6a985d4-876c-4c52-8825-debde837e03d.tif&#34;&#44;&#34;imageFilePath&#34;&#58;&#34;&#47;data&#47;Working&#47;20160229&#47;1&#47;&#34;&#44;&#34;discoStatus&#34;&#58;1&#44;&#34;discoSubStatus&#34;&#58;1&#44;&#34;proxyStatus&#34;&#58;1&#44;&#34;proxySubStatus&#34;&#58;1&#44;&#34;captureUser&#34;&#58;500&#44;&#34;proxyLocation&#34;&#58;&#34;ICT&#34;&#44;&#34;parPicId&#34;&#58;&#34;20121013&#95;131000&#95;0900&#95;0019483&#34;&#44;&#34;destinationStation&#34;&#58;&#34;DAI-001&#34;&#44;&#34;sourceStation&#34;&#58;&#34;HAE-ACS88&#34;&#44;&#34;vcsCase&#34;&#58;&#34;1&#34;&#44;&#34;identCode&#34;&#58;&#34;20121013&#95;131000&#95;0900&#95;0019483&#34;&#44;&#34;coderID&#34;&#58;&#34;lqbinh&#34;&#44;&#34;codingStation&#34;&#58;&#34;201407COM0037&#34;&#44;&#34;addressSource&#34;&#58;100&#44;&#34;produktZusatzleistungenCode&#34;&#58;&#34;&#126;&#126;0&#34;&#44;&#34;acsTimeStamp&#34;&#58;&#34;2012.10.13 01&#58;10&#58;07.00&#34;&#44;&#34;startTime&#34;&#58;&#34;2016.02.29 08&#58;41&#58;19.174&#34;&#44;&#34;endTime&#34;&#58;&#34;2016.02.29 08&#58;41&#58;31.620&#34;&#44;&#34;discoCreateTime&#34;&#58;&#34;2016.02.29 08&#58;41&#58;18.897&#34;&#44;&#34;discoDeliverTime&#34;&#58;&#34;2016.02.29 08&#58;41&#58;19.35&#34;&#44;&#34;proxyReceiveTime&#34;&#58;&#34;2016.02.29 08&#58;41&#58;19.50&#34;&#44;&#34;proxyDeliverClientTime&#34;&#58;&#34;2016.02.29 08&#58;41&#58;19.149&#34;&#44;&#34;clientRequestTime&#34;&#58;&#34;2016.02.29 08&#58;41&#58;17.95&#34;&#44;&#34;imageSize&#34;&#58;91029&#125;&#44;&#34;strasse&#34;&#58;&#34;Galdinen 17 17&#34;&#44;&#34;plz&#34;&#58;&#34;395300&#34;&#44;&#34;ort&#34;&#58;&#34;&#34;&#44;&#34;hausnummer&#34;&#58;&#34;&#34;&#44;&#34;hausnummerzusatz&#34;&#58;&#34;&#34;&#44;&#34;postfach&#34;&#58;&#34;&#34;&#44;&#34;adresszusatz&#34;&#58;&#34;&#34;&#44;&#34;hauskey&#34;&#58;&#34;&#34;&#44;&#34;parcelStreetNumber&#34;&#58;&#34;&#34;&#44;&#34;parcelHauskey&#34;&#58;&#34;&#34;&#44;&#34;pers08Type&#34;&#58;&#34;&#34;&#44;&#34;ampStatus&#34;&#58;&#34;&#34;&#44;&#34;adrID&#34;&#58;&#34;&#34;&#44;&#34;captureResultCode&#34;&#58;&#34;50&#34;&#44;&#34;kdpid&#34;&#58;&#34;&#34;&#44;&#34;anredeId&#34;&#58;&#34;&#34;&#44;&#34;anredeTyped&#34;&#58;&#34;&#34;&#44;&#34;nameTyped&#34;&#58;&#34;&#203;&#233;&#232;&#234;&#252;&#249;&#251;u&#236;&#237;&#238;&#239;&#246;&#242;&#244;&#339;&#228;&#225;&#224;&#226;&#230;&#353;&#223;&#231;&#34;&#44;&#34;vornameTyped&#34;&#58;&#34;&#203;&#233;&#232;&#234;&#252;&#249;&#251;u&#236;&#237;&#238;&#239;&#246;&#242;&#244;&#339;&#228;&#225;&#224;&#226;&#230;&#353;&#223;&#231;&#34;&#44;&#34;namenszusatzTyped&#34;&#58;&#34;&#34;&#44;&#34;firmennameTyped&#34;&#58;&#34;&#203;&#233;&#232;&#234;&#252;&#249;&#251;u&#236;&#237;&#238;&#239;&#246;&#242;&#244;&#339;&#228;&#225;&#224;&#226;&#230;&#353;&#223;&#231;&#34;&#44;&#34;strasseTyped&#34;&#58;&#34;&#203;&#233;&#232;&#234;&#252;&#249;&#251;u&#236;&#237;&#238;&#239;&#246;&#242;&#244;&#339;&#228;&#225;&#224;&#226;&#230;&#353;&#223;&#231;&#34;&#44;&#34;hausnummerTyped&#34;&#58;&#34;&#34;&#44;&#34;hausnummerzusatzTyped&#34;&#58;&#34;&#34;&#44;&#34;stockwerkTyped&#34;&#58;&#34;&#34;&#44;&#34;adresszusatzTyped&#34;&#58;&#34;&#34;&#44;&#34;coAddresseTyped&#34;&#58;&#34;&#34;&#44;&#34;plzTyped&#34;&#58;&#34;&#34;&#44;&#34;ortTyped&#34;&#58;&#34;&#203;&#233;&#232;&#234;&#252;&#249;&#251;u&#236;&#237;&#238;&#239;&#246;&#242;&#244;&#339;&#228;&#225;&#224;&#226;&#230;&#353;&#223;&#231;&#34;&#44;&#34;landTyped&#34;&#58;&#34;CH&#34;&#44;&#34;postfachnummerTyped&#34;&#58;&#34;&#34;&#44;&#34;anredeValue&#34;&#58;&#34;&#34;&#44;&#34;nameValue&#34;&#58;&#34;&#34;&#44;&#34;vornameValue&#34;&#58;&#34;&#34;&#44;&#34;namenszusatzValue&#34;&#58;&#34;&#34;&#44;&#34;firmennameValue&#34;&#58;&#34;&#34;&#44;&#34;strasseValue&#34;&#58;&#34;&#34;&#44;&#34;hausnummerValue&#34;&#58;&#34;&#34;&#44;&#34;hausnummerzusatzValue&#34;&#58;&#34;&#34;&#44;&#34;stockwerkValue&#34;&#58;&#34;&#34;&#44;&#34;adresszusatzValue&#34;&#58;&#34;&#34;&#44;&#34;coAddresseValue&#34;&#58;&#34;&#34;&#44;&#34;plzValue&#34;&#58;&#34;395300&#34;&#44;&#34;ortValue&#34;&#58;&#34;&#34;&#44;&#34;landValue&#34;&#58;&#34;&#34;&#44;&#34;postfachnummerValue&#34;&#58;&#34;&#34;&#44;&#34;badReason&#34;&#58;&#34;&#34;&#44;&#34;addressType&#34;&#58;0&#44;&#34;postlagernd&#34;&#58;&#34;&#34;&#44;&#34;pickPostType&#34;&#58;&#34;&#34;&#44;&#34;pickPostValue&#34;&#58;&#34;&#34;&#44;&#34;myPost24Type&#34;&#58;&#34;&#34;&#44;&#34;myPost24Value&#34;&#58;&#34;&#34;&#125;";
        System.out.println("ORIGINAL:      " + inputString);
        String encoded = AsciiString.encode(inputString);
        System.out.println("ASCII ENCODED: " + encoded);
        String decoded = AsciiString.decode(encoded1);
        System.out.println("ASCII DECODED: " + decoded);
    }
    
    public static String encode(String word) {
        String encoded = "";
        for(Integer index = 0; index < word.length(); index++) {
            int ascii = (int) word.charAt(index);
            Boolean keepAscii = true;
            if(ascii >= 48 && ascii <= 57) {
                keepAscii = false;
            }
            if(ascii >= 65 && ascii <= 90) {
                keepAscii = false;
            }
            if(ascii >= 97 && ascii <= 122) {
                keepAscii = false;
            }
            if(ascii == 32 || ascii == 43 || ascii == 45 || ascii == 46) {
                keepAscii = false;
            }
            if(keepAscii) {
                encoded += "&#" + ascii + ";";
            } else {
                encoded += word.charAt(index);
            }
        }
        return encoded;
    }
    
    public static String decode(String word) {
        String decoded = "";
        for(Integer index = 0; index < word.length(); index++) {
            String charAt = "" + word.charAt(index);
            if(charAt.equals("&") && index < word.length() && ("" + word.charAt(index + 1)).equals("#")) {
                try {
                    Integer length = word.indexOf(";", index);
                    String sub = word.substring(index + 2, length);
                    decoded += Character.toString((char) Integer.parseInt(sub));
                    index = length;
                } catch (Exception ex) {
                    decoded += charAt;
                }
            } else {
                decoded += charAt;
            }
        }
        return decoded;
    }
}