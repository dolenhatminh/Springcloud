package com.sps.vn.lookup.datasource;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.bll.BLLCard;
import com.ghp.vae.data_entry.common.ConstraintField;
import com.ghp.vae.data_entry.entity.Card;
import com.ghp.vae.data_entry.entity.HauskeyAddress;
import com.ghp.vae.search.model.ObjectKdp;
import com.ghp.vae.search.model.ZubofiAddress;
import com.ghp.vae.search.service.impl.LookupServiceImpl;
import com.sps.vn.utilities.StringUtil;
import com.sps.vn.writing.datasource.WritingDBase;

import vae.client.transfer.LookupKey;

public class DALSaveCard extends WritingDBase {
    private static Logger log = LoggerFactory.getLogger(DALSaveCard.class);
    private final LookupServiceImpl lookupService;

    public DALSaveCard() {
        this.lookupService = new LookupServiceImpl();
    }

    public String translateAscii(String s) {
        return this.lookupService.translate(s);
    }

    public int countDuplicateKDP(int plz, String ort, String strasse, String name, String vName, int hausnr, String hausrn_a, String land, String postfach) {
        String iHausnr;

        if (hausnr == -1) {
            iHausnr = null;
        } else {
            iHausnr = String.valueOf(hausnr);
        }
        final ObjectKdp kdp = new ObjectKdp(plz, ort, strasse, name, vName, iHausnr, hausrn_a, land, postfach, "", "", "", "", "", 0);
        log.info("[DALSaveCard]-[countDuplicateKDP]-[PARAMETER]" + "'" + plz + "','" + ort + "','" + strasse + "','" + name + "','" + vName + "','" + iHausnr
                + "','" + hausrn_a + "','" + land + "','" + postfach);
        return this.lookupService.countDuplicatedKdp(kdp);
    }

    public int countDuplicateKDP(String type, String anrede, String name, String vorname, String adr_id, String aadr_id, String hauskey) {

        final ObjectKdp kdp = new ObjectKdp(0, "", "", name, vorname, "", "", "", "", type, anrede, adr_id, aadr_id, hauskey, 1);
        log.info("[DALSaveCard]-[countDuplicateKDP]-[PARAMETER]" + "'" + type + "','" + "'" + name + "','" + vorname + "','" + anrede + "','" + adr_id + "','"
                + aadr_id + "','" + hauskey);
        return this.lookupService.countDuplicatedKdp(kdp);
    }


    public int getFromZoboFi(String plz, String ort, String strasse, String hausNum, String name, List<String> plzList, Card card) {
        final BLLCard bllCard = card.getCard();
        HauskeyAddress parcelHauskeyResults = null;
        int result = 0;
        log.info("[DALSaveCard]-[getFromZobofi]-[COLLECTION:" + bllCard.getManagementID() + "][SAVE]-start find zobofi");
        if (card.isMyPost24()) {
            log.info("[DALSaveCard][getFromZobofi]-isMyPost24");
			try {
				parcelHauskeyResults = this.findParcelHauskeyAndAddressForMypost24h(plz, ort, strasse, hausNum, 3);

				if (!StringUtils.isEmpty(parcelHauskeyResults.getHauskey())) {
					result = 1;
					final long streetNumber = this
							.getStreetNumberFromParcelHauskey(Long.parseLong(parcelHauskeyResults.getHauskey()));
					if (streetNumber > 0) {
						card.getCard().setStreetNumber(streetNumber);
					}
				}
			} catch (final Exception ex) {
                log.error("", ex);
            }
			
            updateIntoList(plzList, parcelHauskeyResults);
            log.info("[DALSaveCard]-[getFromZobofi]-[COLLECTION:" + bllCard.getManagementID() + "][SAVE]-end find zobofi mypost 24 ");
            return result;
        }
        if (bllCard.isCheckZubofiSpecial()) {
			if ((bllCard.getTypeZubofiSpecical() == 4) || (bllCard.getTypeZubofiSpecical() == 2)) {
				log.info("[DALSaveCard]-[getFromZobofi]-[COLLECTION:" + bllCard.getManagementID()
						+ "][SAVE]-end find zobofi special ");
				try {
					parcelHauskeyResults = this.findParcelHauskeyAndAddressForPickpost(plz, ort, strasse, hausNum, 2);
					if (!StringUtils.isEmpty(parcelHauskeyResults.getHauskey())) {
						result = 11;
						final long streetNumber = this
								.getStreetNumberFromParcelHauskey(Long.parseLong(parcelHauskeyResults.getHauskey()));
						if (streetNumber > 0) {
							card.getCard().setStreetNumber(streetNumber);
						}
					}
				} catch (final Exception ex) {
					log.error("", ex);
				}
			} else {
                try {
                	parcelHauskeyResults = this.findParcelHauskeyAndAddressForPostfach(plz, ort, strasse, hausNum);
					if (!StringUtils.isEmpty(parcelHauskeyResults.getHauskey())) {
						result = 11;
						final long streetNumber = this
								.getStreetNumberFromParcelHauskey(Long.parseLong(parcelHauskeyResults.getHauskey()));
						if (streetNumber > 0) {
							card.getCard().setStreetNumber(streetNumber);
						}
					}
				} catch (final Exception ex) {
					log.error("", ex);
				}
            }
			updateIntoList(plzList, parcelHauskeyResults);
            log.info("[DALSaveCard]-[getFromZobofi]-[COLLECTION:" + bllCard.getManagementID() + "][SAVE]-end find zobofi special");
            return result;
        } else {
        	/**
        	 * Request #10890: Get parcel_hauskey for post lagernd address from ASDP.
        	 */
        	final String postlagend = card.getFieldValue().get("postlagend");
        	if (!ConstraintField.SPACE.equalsIgnoreCase(postlagend)) {
        		parcelHauskeyResults = this.findParcelHauskeyAndAddressForPostlagernd(plz, ort, strasse, hausNum);
        		
        		//TODO Dev by htvy, bug ABA-179: Warning message is displayed when user saves with bad reason and Postlagernd
    			/*if(!plzList.isEmpty()) {
    				plzList.set(11, "");
    			}*/
        		
        	} else {
        		/**
        		 * Request #10890: Get parcel_hauskey for special domizil address(has strasse is null and postfach is null) from ASDP when kdp_id is not null.
        		 */
        		final String postfach = card.getValuePostFach();
        		
        		if (card.isHaveValueFromSearchKdp() && ("".equalsIgnoreCase(strasse) && "".equalsIgnoreCase(postfach))) {
        			parcelHauskeyResults = this.findParcelHauskeyAndAddressForZubofiSpecial(plz, ort, strasse, hausNum);
        		} else {
        			parcelHauskeyResults = this.getParcelHauskeyFromZubofi(plz, ort, strasse, hausNum, name);
        		}
        	}

            if (!StringUtils.isEmpty(parcelHauskeyResults.getHauskey())) {
				result = 1;
				final long streetNumber = this
						.getStreetNumberFromParcelHauskey(Long.parseLong(parcelHauskeyResults.getHauskey()));
				if (streetNumber > 0) {
					card.getCard().setStreetNumber(streetNumber);
				}
			}
            updateIntoList(plzList, parcelHauskeyResults);
            log.info("[DALSaveCard]-[getFromZobofi]-[COLLECTION:" + bllCard.getManagementID() + "][SAVE]-end find zobofi");
            return result; // getFromZoboFi(plz, ort, strasse, hausNum, name, plzList);
        }
    }

    private Map<String, String> getParcelHauskeyPostfachFromZubofiSpecial(String plz, String ort) {
        final ZubofiAddress zubofiAddress = new ZubofiAddress(plz, ort, 1);
        return this.lookupService.getParcelHauskeyPostfachFromZubofiSpecial(zubofiAddress);
    }
    
    private HauskeyAddress findParcelHauskeyAndAddressForPostfach(String plz, String ort, String strasse, String hausNum) {
    	String hausnr = hausNum;
        String hausuzat = "";
    	if (!StringUtil.isEmpty(hausNum)) {
            final boolean addHausNumberType = hausNum.trim().equals(hausuzat) && !hausNum.trim().equals("");
            if (addHausNumberType) {
            	hausuzat = hausNum;
            } else {
            	final String haus[] = this.spilitHauseNum(hausNum);
                if ((haus != null) && (haus.length > 0)) {
                	hausnr = haus[0];
                    hausuzat = haus[1];
                }
            }
    	}
		Map<String, String> results = this.getParcelHauskeyPostfachFromZubofiSpecial(plz, ort);
		
		if (results != null && !StringUtils.isEmpty(results.get(LookupKey.HAUSKEY.getKey()))) {
			return new HauskeyAddress.Builder()
					.addrId(results.get(LookupKey.ADR_ID.getKey()))
					.plzType(plz)
					.plzValue(results.get(LookupKey.PLZ.getKey()))
					.ortType(ort)
					.ortValue(results.get(LookupKey.ORT.getKey()))
					.strasseType(strasse)
					.strasseValue(results.get(LookupKey.STRASSE.getKey()))
					.hausnummerType(hausnr)
					.hausnummerValue(results.get(LookupKey.HAUSNUMMER.getKey()))
					.hausnummerZusatType(hausuzat)
					.hausnummerZusatValue(results.get(LookupKey.HAUSNUMMER_A.getKey()))
					.hauskey(results.get(LookupKey.HAUSKEY.getKey()))
					.streetNumber(results.get(LookupKey.STREETNUMBER.getKey()))
					.build();
		}
		
		return new HauskeyAddress.Builder()
				.addrId(ConstraintField.SPACE)
				.plzType(plz)
				.plzValue(ConstraintField.SPACE)
				.ortType(plz)
				.ortValue(ConstraintField.SPACE)
				.strasseType(strasse)
				.strasseValue(ConstraintField.SPACE)
				.hausnummerType(hausnr)
				.hausnummerValue(ConstraintField.SPACE)
				.hausnummerZusatType(hausuzat)
				.hausnummerZusatValue(ConstraintField.SPACE)
				.hauskey(ConstraintField.SPACE)
				.streetNumber(ConstraintField.SPACE)
				.build();
    }
    
    private HauskeyAddress findParcelHauskeyAndAddressForPostlagernd(String plz, String ort, String strasse, String hausNum) {
    	String hausnr = hausNum;
        String hausuzat = "";
    	if (!StringUtil.isEmpty(hausNum)) {
            final boolean addHausNumberType = hausNum.trim().equals(hausuzat) && !hausNum.trim().equals("");
            if (addHausNumberType) {
            	hausuzat = hausNum;
            } else {
            	final String haus[] = this.spilitHauseNum(hausNum);
                if ((haus != null) && (haus.length > 0)) {
                	hausnr = haus[0];
                    hausuzat = haus[1];
                }
            }
    	}
		Map<String, String> results = this.getParcelHauskeyPostlagerndFromZubofiSpecial(plz, ort);
		
		if (results != null && !StringUtils.isEmpty(results.get(LookupKey.HAUSKEY.getKey()))) {
			return new HauskeyAddress.Builder()
					.addrId(results.get(LookupKey.ADR_ID.getKey()))
					.plzType(plz)
					.plzValue(results.get(LookupKey.PLZ.getKey()))
					.ortType(ort)
					.ortValue(results.get(LookupKey.ORT.getKey()))
					.strasseType(strasse)
					.strasseValue(results.get(LookupKey.STRASSE.getKey()))
					.hausnummerType(hausnr)
					.hausnummerValue(results.get(LookupKey.HAUSNUMMER.getKey()))
					.hausnummerZusatType(hausuzat)
					.hausnummerZusatValue(results.get(LookupKey.HAUSNUMMER_A.getKey()))
					.hauskey(results.get(LookupKey.HAUSKEY.getKey()))
					.streetNumber(results.get(LookupKey.STREETNUMBER.getKey()))
					.build();
		}
		
		return new HauskeyAddress.Builder()
				.addrId(ConstraintField.SPACE)
				.plzType(plz)
				.plzValue(ConstraintField.SPACE)
				.ortType(plz)
				.ortValue(ConstraintField.SPACE)
				.strasseType(strasse)
				.strasseValue(ConstraintField.SPACE)
				.hausnummerType(hausnr)
				.hausnummerValue(ConstraintField.SPACE)
				.hausnummerZusatType(hausuzat)
				.hausnummerZusatValue(ConstraintField.SPACE)
				.hauskey(ConstraintField.SPACE)
				.streetNumber(ConstraintField.SPACE)
				.build();
    }
    
    private Map<String, String> getParcelHauskeyPostlagerndFromZubofiSpecial(String plz, String ort) {
    	final ZubofiAddress zubofiAddress = new ZubofiAddress(plz, ort, 4);
    	return this.lookupService.getParcelHauskeyPostlagerndFromZubofiSpecial(zubofiAddress);
	}

    /**
     * ABA-22/#12476 Rules of find ParcelHauskey for Mypost24
     * Request #10890(update 30/09/2016): search parcel hauskey for pickpost or mypost24
     * with plz, ort, strasse, hausnr(without hausnr_zusat)
     * @param plz
     * @param ort
     * @param strasse
     * @param hausnr
     * @param hausuzat 
     * @param type
     * @return 
     */
	public Map<String, String> findParcelHauskeyAndAddressForPickpostAndMypost24h(String plz, String ort, String strasse, String hausnr, int type) {
		ZubofiAddress zubofiAddress = new ZubofiAddress(plz, ort, strasse, hausnr, null, type);

		Map<String, String> results = this.lookupService.getParcelHauskeyFromZubofiSpecial(zubofiAddress);

		if (results != null && !StringUtils.isEmpty(results.get(LookupKey.HAUSKEY.getKey()))) {
			return results;
		}
		
		zubofiAddress = new ZubofiAddress(plz, ort, strasse, null, null, type);
		results = this.lookupService.getParcelHauskeyFromZubofiSpecial(zubofiAddress);
		if (results != null && !StringUtils.isEmpty(results.get(LookupKey.HAUSKEY.getKey()))) {
			return results;
		}
		
		zubofiAddress = new ZubofiAddress(plz, ort, null, null, null, type);
		results = this.lookupService.getParcelHauskeyFromZubofiSpecial(zubofiAddress);
		if (results != null && !StringUtils.isEmpty(results.get(LookupKey.HAUSKEY.getKey()))) {
			return results;
		}
		
		zubofiAddress = new ZubofiAddress(plz, null, null, null, null, type);
		if (results != null && !StringUtils.isEmpty(results.get(LookupKey.HAUSKEY.getKey()))) {
			return results;
		}
		return null;
	}
	
	
	public HauskeyAddress findParcelHauskeyAndAddressForMypost24h(String plz, String ort, String strasse, String hausNum, int type) {
		
		final String haus[] = this.spilitHauseNum(hausNum);
        String hausuzat = hausNum;
        String hausnr = "";
        if ((haus != null) && (haus.length > 0)) {
        	hausnr = haus[0];
            hausuzat = haus[1];
        }
		
		Map<String, String> results = this.findParcelHauskeyAndAddressForPickpostAndMypost24h(plz, ort, strasse, hausnr, type);

		if (results != null && !StringUtils.isEmpty(results.get(LookupKey.HAUSKEY.getKey()))) {
			return new HauskeyAddress.Builder()
					.addrId(results.get(LookupKey.ADR_ID.getKey()))
					.plzType(plz)
					.plzValue(results.get(LookupKey.PLZ.getKey()))
					.ortType(ort)
					.ortValue(results.get(LookupKey.ORT.getKey()))
					.strasseType(strasse)
					.strasseValue(results.get(LookupKey.STRASSE.getKey()))
					.hausnummerType(hausnr)
					.hausnummerValue(results.get(LookupKey.HAUSNUMMER.getKey()))
					.hausnummerZusatType(hausuzat)
					.hausnummerZusatValue(results.get(LookupKey.HAUSNUMMER_A.getKey()))
					.hauskey(results.get(LookupKey.HAUSKEY.getKey()))
					.streetNumber(results.get(LookupKey.STREETNUMBER.getKey()))
					.build();
		}
		
		return new HauskeyAddress.Builder()
				.addrId(ConstraintField.SPACE)
				.plzType(plz)
				.plzValue(ConstraintField.SPACE)
				.ortType(plz)
				.ortValue(ConstraintField.SPACE)
				.strasseType(strasse)
				.strasseValue(ConstraintField.SPACE)
				.hausnummerType(hausnr)
				.hausnummerValue(ConstraintField.SPACE)
				.hausnummerZusatType(hausuzat)
				.hausnummerZusatValue(ConstraintField.SPACE)
				.hauskey(ConstraintField.SPACE)
				.streetNumber(ConstraintField.SPACE)
				.build();
	}
	
	/*
	 * Currently, pickpost's rule is the same with mypost24h
	 */
	public HauskeyAddress findParcelHauskeyAndAddressForPickpost(String plz, String ort, String strasse, String hausNum,
			int type) {
		return findParcelHauskeyAndAddressForMypost24h(plz, ort, strasse, hausNum, type);
	}

    public Map<String, String> getParcelHauskeyFromZubofiSpecial(String plz) {
        return this.lookupService.getParcelHauskeyFromZubofiSpecial(plz);
    }
    
    public HauskeyAddress findParcelHauskeyAndAddressForZubofiSpecial(String plz, String ort, String strasse, String hausNum) {
    	final String haus[] = this.spilitHauseNum(hausNum);
        String hausuzat = hausNum;
        String hausnr = "";
        if ((haus != null) && (haus.length > 0)) {
        	hausnr = haus[0];
            hausuzat = haus[1];
        }
		
		Map<String, String> results = this.getParcelHauskeyFromZubofiSpecial(plz);

		if (results != null && !StringUtils.isEmpty(results.get(LookupKey.HAUSKEY.getKey()))) {
			return new HauskeyAddress.Builder()
					.addrId(results.get(LookupKey.ADR_ID.getKey()))
					.plzType(plz)
					.plzValue(results.get(LookupKey.PLZ.getKey()))
					.ortType(ort)
					.ortValue(results.get(LookupKey.ORT.getKey()))
					.strasseType(strasse)
					.strasseValue(results.get(LookupKey.STRASSE.getKey()))
					.hausnummerType(hausnr)
					.hausnummerValue(results.get(LookupKey.HAUSNUMMER.getKey()))
					.hausnummerZusatType(hausuzat)
					.hausnummerZusatValue(results.get(LookupKey.HAUSNUMMER_A.getKey()))
					.hauskey(results.get(LookupKey.HAUSKEY.getKey()))
					.streetNumber(results.get(LookupKey.STREETNUMBER.getKey()))
					.build();
		}
		
		return new HauskeyAddress.Builder()
				.addrId(ConstraintField.SPACE)
				.plzType(plz)
				.plzValue(ConstraintField.SPACE)
				.ortType(plz)
				.ortValue(ConstraintField.SPACE)
				.strasseType(strasse)
				.strasseValue(ConstraintField.SPACE)
				.hausnummerType(hausnr)
				.hausnummerValue(ConstraintField.SPACE)
				.hausnummerZusatType(hausuzat)
				.hausnummerZusatValue(ConstraintField.SPACE)
				.hauskey(ConstraintField.SPACE)
				.streetNumber(ConstraintField.SPACE)
				.build();
    }

    private HauskeyAddress getParcelHauskeyFromZubofi(String plz, String ort, String strasse, String address, String name) {

        log.info("[DALSaveCard][getParcelHauskeyFromZubofi]-[PARAMETER][FIND_HAUSEKEY_ZUBOFI]" + "'" + plz + "', '" + "','" + strasse + "','" + address + "','"
                + name + "'");
        String hausNum = address;
        final String haus[] = this.spilitHauseNum(hausNum);
        String hausuzat = "";
        if ((haus != null) && (haus.length > 0)) {
            hausNum = haus[0];
            hausuzat = haus[1];
        }
        try {
            final ZubofiAddress zuaddress = new ZubofiAddress(plz, "", strasse, hausNum, hausuzat);
            final Map<String, String> row = this.lookupService.getParcelHauskeyFromZubofi(zuaddress);

            if (row != null) {
                return new HauskeyAddress.Builder()
    					.addrId(row.get(LookupKey.ADR_ID.getKey()))
    					.plzType(plz)
    					.plzValue(row.get(LookupKey.PLZ.getKey()))
    					.ortType(ort)
    					.ortValue(row.get(LookupKey.ORT.getKey()))
    					.strasseType(strasse)
    					.strasseValue(row.get(LookupKey.STRASSE.getKey()))
    					.hausnummerType(hausNum)
    					.hausnummerValue(row.get(LookupKey.HAUSNUMMER.getKey()))
    					.hausnummerZusatType(hausuzat)
    					.hausnummerZusatValue(row.get(LookupKey.HAUSNUMMER_A.getKey()))
    					.hauskey(row.get(LookupKey.HAUSKEY.getKey()))
    					.streetNumber(row.get(LookupKey.STREETNUMBER.getKey()))
    					.build();
            }

        } catch (final Exception ex) {
            log.error("", ex);
        }
        return new HauskeyAddress.Builder()
				.addrId(ConstraintField.SPACE)
				.plzType(plz)
				.plzValue(ConstraintField.SPACE)
				.ortType(plz)
				.ortValue(ConstraintField.SPACE)
				.strasseType(strasse)
				.strasseValue(ConstraintField.SPACE)
				.hausnummerType(hausNum)
				.hausnummerValue(ConstraintField.SPACE)
				.hausnummerZusatType(hausuzat)
				.hausnummerZusatValue(ConstraintField.SPACE)
				.hauskey(ConstraintField.SPACE)
				.streetNumber(ConstraintField.SPACE)
				.build();
    }

    public String[] spilitHauseNum(String str) {
        // final String result[] = new String[2];
        // String hausuzat = "";
        // String hausNum = str;
        // for (int j = 0; j < str.length(); j++) {
        // if ((str.charAt(j) < '0') || (str.charAt(j) > '9')) {
        // hausuzat = str.substring(j);
        // hausNum = str.substring(0, j);
        // break;
        // }
        // }
        // result[0] = hausNum.trim();
        // // result[1] = hausuzat.trim();
        // result[1] = hausuzat;
        // return result;

        // pvgiang_1 -26/07/2016- update splitHauseNum use regular expression
        final String REGEX = "^([0-9]+)";
        final String result[] = new String[2];

        final String hausnr_a = str.replaceFirst(REGEX, "");
        final String hausnr = str.replace(hausnr_a, "");

        result[0] = hausnr;
        result[1] = hausnr_a;

        return result;
    }

	private void updateIntoList(List<String> plzList, HauskeyAddress hauskeyResults) {
		plzList.add(0, hauskeyResults.getAddrId()); // adr_id
		plzList.add(1, hauskeyResults.getPlzType()); // plz_type
		plzList.add(2, hauskeyResults.getPlzValue()); // plz_value
		plzList.add(3, hauskeyResults.getOrtType()); // ort_type
		plzList.add(4, hauskeyResults.getOrtValue()); // ort_value
		plzList.add(5, hauskeyResults.getStrasseType()); // str_type
		plzList.add(6, hauskeyResults.getStrasseValue()); // str_value
		plzList.add(7, hauskeyResults.getHausnummerType()); // hrn_type
		plzList.add(8, hauskeyResults.getHausnummerValue()); // hrn_value
		plzList.add(9, hauskeyResults.getHausnummerZusatType()); // hrna_type
		plzList.add(10, hauskeyResults.getHausnummerZusatValue());// hrna_value
		plzList.add(11, hauskeyResults.getHauskey());// hauskey
		plzList.add(12, hauskeyResults.getStreetNumber());// streetnumber
	}

    public long getStreetNumberFromParcelHauskey(Long parcelhauskey) {
        return this.lookupService.getStreetNumberByParcelHauskey(parcelhauskey);

    }

    public static void main(String arg[]) {
        String ort = "ab 12 de";
        try {
            System.out.println(ort.lastIndexOf(' '));
            Integer.parseInt(ort.substring(ort.lastIndexOf(' ') + 1));
            System.out.println(ort.lastIndexOf(' '));
            ort = ort.substring(0, ort.lastIndexOf(' '));
        } catch (final Exception e) {
            log.error("", e);
        }
        System.out.println(ort);
    }

    public Long getParcelHauskeyFromAmpplus(String plz, String ort, String strasse) {
        final ZubofiAddress zubofiAddress = new ZubofiAddress(plz, ort, strasse, "", "", 0);
        return this.lookupService.getParcelHauskeyFromAmpplus(zubofiAddress);
    }
    
    public String checkFirmenPlz(String plz, String ort) {
    	Map<String, String> respone = this.lookupService.getPlzFromASDPPlz(plz, ort);
    	StringBuilder plz_And_ort = new StringBuilder();
    	if (!respone.isEmpty()) {
    		plz_And_ort.append(respone.get(LookupKey.PLZ_PLZ.getKey()));
    		plz_And_ort.append(" AND ");
    		plz_And_ort.append(respone.get(LookupKey.SUGGEST_ORT.getKey()));
    	}
    	return plz_And_ort.toString();
    }
    
}
