/*
 * Class: OCRPostProcessingConfiguration
 *
 * Created on Mar 17, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package com.sps.vn.config;

import java.util.ArrayList;
import java.util.List;

/**
 * <tt>OCRPostProcessingConfiguration</tt> ...
 */
public class OCRPostProcessingConfiguration {

    /**
     * The known anredes.
     */
    private List<String> knownAnredes;

    /**
     * The known pickposts.
     */
    private List<String> knownPickposts;

    /**
     * The known mypost24.
     */
    private List<String> knownMypost24s;

    /**
     * The known postfatches.
     */
    private List<String> knownPostfaches;

    /**
     * The known postlagernds.
     */
    private List<String> knownPostlagernds;

    /**
     * The known strasses.
     */
    private List<String> knownStrasses;

    /**
     * The special addresses.
     */
    private List<String> specialAddresses;

    /**
     * The stop words.
     */
    private List<String> stopWords;

    /**
     * Constructs a new <tt>OCRPostProcessingConfiguration</tt>.
     */
    OCRPostProcessingConfiguration() {
    }

    /**
     * Gets the known Mypost24s.
     *
     * @param knownMypost24s
     */
    public void setKnownMypost24s(List<String> knownMypost24s) {
        this.knownMypost24s = knownMypost24s;
    }

    /**
     * Gets the known anredes.
     *
     * @return the known anredes
     */
    public String[] getKnownAnredes() {
        return this.knownAnredes.toArray(new String[this.knownAnredes.size()]);
    }

    /**
     * Gets the known pickposts.
     *
     * @return the known pickposts
     */
    public String[] getKnownPickposts() {
        return this.knownPickposts.toArray(new String[this.knownPickposts.size()]);
    }
    
    /**
     * Gets the known pickposts.
     *
     * @return the known pickposts
     */
    public String[] getKnownMypost24s() {
        return this.knownMypost24s.toArray(new String[this.knownMypost24s.size()]);
    }

    /**
     * Gets the known postfatches.
     *
     * @return the known postfatches
     */
    public String[] getKnownPostfatches() {
        return this.knownPostfaches.toArray(new String[this.knownPostfaches.size()]);
    }

    /**
     * Gets the known postlagernds.
     *
     * @return the known postlagernds
     */
    public String[] getKnownPostlagernds() {
        return this.knownPostlagernds.toArray(new String[this.knownPostlagernds.size()]);
    }

    /**
     * Gets the known strasses.
     *
     * @return the known strasses
     */
    public String[] getKnownStrasses() {
        return this.knownStrasses.toArray(new String[this.knownStrasses.size()]);
    }

    /**
     * Gets the special addresses.
     *
     * @return the special addresses
     */
    public String[] getSpecialAddresses() {
        return this.specialAddresses.toArray(new String[this.specialAddresses.size()]);
    }

    /**
     * Gets the stop words.
     *
     * @return the stop words
     */
    public String[] getStopWords() {
        return this.stopWords.toArray(new String[this.stopWords.size()]);
    }

    /**
     * Sets the known anredes.
     *
     * @param knownAnredes the new known anredes
     */
    void setKnownAnredes(final String knownAnredes) {
        if (this.knownAnredes == null) {
            this.knownAnredes = new ArrayList<String>();
        }
        this.string2List(this.knownAnredes, knownAnredes);
    }

    /**
     * Sets the known pickposts.
     *
     * @param knownPickposts the new known pickposts
     */
    void setKnownPickposts(final String knownPickposts) {
        if (this.knownPickposts == null) {
            this.knownPickposts = new ArrayList<String>();
        }
        this.string2List(this.knownPickposts, knownPickposts);
    }

    /**
     * Sets the known Mypost24.
     *
     * @param knownMypost24s the new known Mypost24
     */
    void setKnownMypost24s(final String knownMypost24s) {
        if (this.knownMypost24s == null) {
            this.knownMypost24s = new ArrayList<String>();
        }
        this.string2List(this.knownMypost24s, knownMypost24s);
    }

    /**
     * Sets the known postfatches.
     *
     * @param knownPostfatches the new known postfatches
     */
    void setKnownPostfatches(final String knownPostfatches) {
        if (this.knownPostfaches == null) {
            this.knownPostfaches = new ArrayList<String>();
        }
        this.string2List(this.knownPostfaches, knownPostfatches);
    }

    /**
     * Sets the known postlagernds.
     *
     * @param knownPostlagernds the new known postlagernds
     */
    void setKnownPostlagernds(final String knownPostlagernds) {
        if (this.knownPostlagernds == null) {
            this.knownPostlagernds = new ArrayList<String>();
        }
        this.string2List(this.knownPostlagernds, knownPostlagernds);
    }

    /**
     * Sets the known strasses.
     *
     * @param knownStrasses the new known strasses
     */
    void setKnownStrasses(final String knownStrasses) {
        if (this.knownStrasses == null) {
            this.knownStrasses = new ArrayList<String>();
        }
        this.string2List(this.knownStrasses, knownStrasses);
    }

    /**
     * Sets the special addresses.
     *
     * @param specialAddresses the new special addresses
     */
    void setSpecialAddresses(final String specialAddresses) {
        if (this.specialAddresses == null) {
            this.specialAddresses = new ArrayList<String>();
        }
        this.string2List(this.specialAddresses, specialAddresses);
    }

    /**
     * Sets the stop words.
     *
     * @param stopWords the new stop words
     */
    void setStopWords(final String stopWords) {
        if (this.stopWords == null) {
            this.stopWords = new ArrayList<String>();
        }
        this.string2List(this.stopWords, stopWords);
    }

    /**
     * String to list.
     *
     * @param list the list which contains the split items
     * @param string the string of item separated by comma
     */
    private void string2List(final List<String> list, final String string) {
        if (string != null) {
            String[] items = string.split(",");
            for (String item : items) {
                if (!item.isEmpty()) {
                    list.add(item);
                }
            }
        }
    }

}
