/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sps.vn.writing.datasource;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.Utilities;

/**
 *
 * @author vxhoa
 */
public class WritingBaseDAL {

	private static Logger log = LoggerFactory.getLogger(WritingBaseDAL.class);
    public WritingBaseDAL() {
    }

    /**
     * Subclass calls this method to retrieve a connection from the pool.
     *
     * @return an active Connection. If no connection is currently available,
     *         NULL is returned.
     * @throws VAEException
     * @throws Exception
     */
    protected Connection getConnection() throws Exception {
        WritingConnectionManager dbcManager = WritingConnectionManager.instance();
        return dbcManager.getConn();
    }

    // subclass calls this method to retrieve a connection from the pool
    // the timeout specifies how long the client is willing to wait for a
    // connection
    // after the time-out and no connection is available then NULL is returned
    protected Connection getConnection(long timeOut) throws Exception {
        WritingConnectionManager dbcManager = WritingConnectionManager.instance();
        return dbcManager.getConn(timeOut);
    }

    // subclass calls this to return a connection to the pool
    protected void freeConnection(Connection conn) {
        try {
            WritingConnectionManager dbcManager = WritingConnectionManager.instance();
            dbcManager.freeConn(conn);
        } catch (Exception e) {
            log.error(Utilities.getStackTrace(e));
        }

    }

    protected void freeCommitConnection(Connection conn) {
        try {
        	if(!conn.getAutoCommit()){
        		conn.commit();
        	}
            WritingConnectionManager dbcManager = WritingConnectionManager.instance();
            dbcManager.freeConn(conn);
        } catch (Exception e) {
            log.error(Utilities.getStackTrace(e));
        }

    }

    protected void removeConnectionError(Connection conn) {
        try {
            WritingConnectionManager dbcManager = WritingConnectionManager.instance();
            dbcManager.removeConnError(conn);
        } catch (Exception e) {
            log.error(Utilities.getStackTrace(e));
        }

    }
	protected Connection getConnection(String driver, String url, String un,
            String pw) throws Exception {
		@SuppressWarnings("rawtypes")
		Class cls = Class.forName(driver);
        DriverManager.registerDriver((Driver) cls.newInstance());
        return DriverManager.getConnection(url, un, pw);
    }

    protected void closeConnection(Connection conn) throws SQLException {
        if (conn != null && !conn.isClosed()) {
            conn.close();
        }
    }
    protected void commitConnection(Connection conn) throws SQLException {
        if (!conn.getAutoCommit()) {
            conn.commit();
        }
    }

    protected Connection getConnection(String dbcode) throws Exception {
        WritingConnectionManager dbcManager = WritingConnectionManager.instance();
        return dbcManager.getConn(dbcode);
    }

    protected void freeConnection(String dbcode, Connection conn) {
        try {
            WritingConnectionManager dbcManager = WritingConnectionManager.instance();
            dbcManager.freeConn(dbcode, conn);
        } catch (Exception e) {
            log.error(Utilities.getStackTrace(e));
        }
    }

    protected void freeCommitConnection(String dbcode, Connection conn) {
        try {
        	if(!conn.getAutoCommit()){
        		conn.commit();
        	}
            WritingConnectionManager dbcManager = WritingConnectionManager.instance();
            dbcManager.freeConn(dbcode, conn);
        } catch (Exception e) {
            log.error(Utilities.getStackTrace(e));
        }
    }

    public void releaseALLConnection() {
        try {
            WritingConnectionManager dbcManager = WritingConnectionManager.instance();
            dbcManager.release();
        } catch (Exception ex) {
            log.error(Utilities.getStackTrace(ex));
        }
    }
    
    public void releaseConnection() {
        try {
            WritingConnectionManager dbcManager = WritingConnectionManager.instance();
            dbcManager.release();
        } catch (Exception ex) {
            log.error(Utilities.getStackTrace(ex));
        }
    }
}
