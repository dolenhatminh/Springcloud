/*
 * Class: DALLookup
 *
 * Created on Mar 17, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package com.sps.vn.lookup.datasource;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.search.model.ocr.FirmaSign;
import com.ghp.vae.search.service.IOCRService;
import com.ghp.vae.search.service.impl.OCRServiceImpl;

/**
 * The Class DALLookup.
 */
public class DALLookup extends LookupDBase {

    /** The log. */
    private static Logger log = LoggerFactory.getLogger(DALLookup.class);

    /** The ocr service. */
    private final IOCRService ocrService;

    /**
     * Instantiates a new DAL lookup.
     */
    public DALLookup() {
        this.ocrService = new OCRServiceImpl();
    }

    /**
     * Check keyword exist.
     *
     * @param keyWord the key word
     * @return the string
     * @throws Exception the exception
     */
    public String checkKeywordExist(final String keyWord) throws Exception {
        String ret = keyWord;

        try {
            if ((keyWord != null) && !keyWord.isEmpty()) {
                log.debug("Checking keywords: " + keyWord);
                String existingKeywords = "";
                final String[] keywords = keyWord.split(" ");
                for (final String keyword : keywords) {
                    if (!keyword.isEmpty()) {
                        final int count = this.ocrService.countExistingKDP(keyword);
                        if (count > 0) {
                            existingKeywords = existingKeywords + keyword + " ";
                        }
                    }
                }
                existingKeywords = existingKeywords.trim();
                if (!keyWord.equals(existingKeywords)) {
                    ret = existingKeywords;
                }
                log.debug("Done checking with returned string: " + ret);
            }
        }
        catch (final Exception e) {
            log.error("Error occured while checking existence of keyword", e);
            throw e;
        }

        return ret;
    }

    /**
     * Check ort exist.
     *
     * @param ort the ort
     * @return the int
     * @throws Exception the exception
     */
    public int checkORTExist(final String ort) throws Exception {
        int ret = 0;

        try {
            if ((ort != null) && !ort.isEmpty()) {
                ret = this.ocrService.countExistingOrt(ort);
            }
        }
        catch (final Exception ex) {
            log.error("Error occured while checking existence of ORT", ex);
            throw ex;
        }

        return ret;
    }

    /**
     * Check plz exist.
     *
     * @param plz the plz
     * @return the int
     * @throws Exception the exception
     */
    public int checkPLZExist(final String plz) throws Exception {
        int ret = 0;

        try {
            if ((plz != null) && !plz.isEmpty()) {
                ret = this.ocrService.countExistingPlz(plz);
            }
        }
        catch (final Exception ex) {
            log.error("Error occured while checking existence of PLZ", ex);
            throw ex;
        }

        return ret;
    }

    /**
     * Check strasse exist.
     *
     * @param strasse the strasse
     * @return the int
     * @throws Exception the exception
     */
    public int checkStrasseExist(final String strasse) throws Exception {
        int ret = 0;

        try {
            if ((strasse != null) && !strasse.isEmpty()) {
                ret = this.ocrService.countExistingStrasse(strasse);
            }
        }
        catch (final Exception ex) {
            log.error("Error occured while checking existence of STRASSE", ex);
            throw ex;
        }

        return ret;
    }

    /**
     * Check typ ofkeyword.
     *
     * @param keyword the keyword
     * @return the int
     * @throws Exception the exception
     */
    public int checkTypOfkeyword(final String keyword) throws Exception {
        int ret = 0;

        try {
            if ((keyword != null) && !keyword.isEmpty()) {
                ret = this.ocrService.countExistingKDP(keyword);
            }
        }
        catch (final Exception e) {
            log.error("Error occured while checking existence of KDP", e);
            throw e;
        }

        return ret;
    }

    /**
     * Gets the all firma sign.
     *
     * @return the all firma sign
     * @throws Exception the exception
     */
    public List<String> getAllFirmaSign() throws Exception {
        final List<String> ret = new ArrayList<String>();

        try {
            final List<FirmaSign> firmaSigns = this.ocrService.getAllFirmaSign();
            for (final FirmaSign firmaSign : firmaSigns) {
                ret.add(firmaSign.getSign());
            }
        }
        catch (final Exception e) {
            log.error("Error occured while listing the firma sign", e);
            throw e;
        }

        return ret;
    }

    /**
     * Translate ascii.
     *
     * @param keyWord the key word
     * @return the string
     * @throws Exception the exception
     */
    public String translateASCII(final String keyWord) {
        String ret = keyWord;

        if ((keyWord != null) && !keyWord.isEmpty()) {
            ret = this.ocrService.normalize(keyWord);
        }

        return ret;
    }
}
