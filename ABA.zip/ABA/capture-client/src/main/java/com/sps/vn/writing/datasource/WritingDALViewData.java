package com.sps.vn.writing.datasource;

import java.sql.Array;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.Utilities;

public class WritingDALViewData extends WritingDBase {
	private WritingBaseDAL baseDAL;

	// <editor-fold defaultstate="collapsed" desc="constructor method">
	private static Logger log = LoggerFactory.getLogger(WritingDALViewData.class);
	public WritingDALViewData() {
		baseDAL = new WritingBaseDAL();
	}
	public String[][] getLand() {
		String anrede[][] = null;
		Array tmp;
		Connection conn = null;
		try {
			conn = baseDAL.getConnection();
			tmp = (Array) processStore(conn, "vae.get_land", null, Types.ARRAY);
			if (tmp != null) {
				anrede = (String[][]) tmp.getArray();
			}
		} catch (SQLException ex) {
			log.error("" ,ex);
		} catch (Exception ex) {
			log.error("",ex);
		}finally{
			baseDAL.freeCommitConnection(conn);
		}
		return anrede;
	}
	
	public String[][] getReason() {
		Connection conn = null;
		String result[][] = null;
		Array tmp;
		try {
			conn = baseDAL.getConnection();			
			tmp = (Array) processStore(conn, "vae.get_reason", null,
					Types.ARRAY);
			if (tmp != null) {
				result = (String[][]) tmp.getArray();
			}
		} catch (SQLException ex) {
			log.error("",ex);
		} catch (Exception ex) {
			log.error("",ex);
		} finally {
			baseDAL.freeCommitConnection(conn);
		}
		return result;
	}
	public boolean get_StatusRunOCR(){
		Connection conn=null;
		boolean flat=false;
		String tmpValue = "";
		try {
			conn = baseDAL.getConnection();
			conn.setAutoCommit(false);
			ResultSet rs = (ResultSet) processStore(conn, "vae.get_statusrunocr", null,Types.OTHER);
						
			while(rs.next()){
				tmpValue =  rs.getString(1);
			}	
			if(tmpValue.trim().equals("1")){
				flat = true;
			}
		} catch (SQLException ex) {
			log.error("",ex);
		} catch (Exception ex) {
			log.error("",ex);
		} finally {
			baseDAL.freeCommitConnection(conn);
		}
		return flat;
	}
	
	
	private String processdata(String value) {
		if (value == null || value.equals("")) {
			return "";
		} else {
			String newValue = value.toLowerCase();
			String tmp = "";
			for (char c : newValue.toCharArray()) {
				if (c == '+') {
					tmp += "\\\\+";
				} else {
					tmp += c;
				}
				newValue = tmp;
			}
			newValue = newValue.replace('*', '%');
			newValue = newValue.replace("'", "''");
			if (newValue.indexOf(';') != newValue.length() - 1) {
				newValue = newValue + "%";
			} else {
				newValue = newValue.substring(0, newValue.length() - 1);
			}
			log.debug("\nvalue:" + value + "\nnew value:" + newValue);
			return newValue;
		}
	}

	@SuppressWarnings("unused")
	private String getStoreName(String fieldName) {
		String storeName = "";
		if ("vorname".equalsIgnoreCase(fieldName)) {
			storeName = "vae.search_vorname_ascii";
		} else if ("ort".equalsIgnoreCase(fieldName)) {
			storeName = "vae.search_ort_ascii";
		} else if ("plz".equalsIgnoreCase(fieldName)) {
			storeName = "vae.search_plz";
		} else if ("strasse".equalsIgnoreCase(fieldName)) {
			storeName = "vae.search_strasse_ascii";
		} else if ("firmenname".equalsIgnoreCase(fieldName)) {
			storeName = "vae.search_firmenname_ascii";
		} else if ("name".equalsIgnoreCase(fieldName)) {
			storeName = "vae.search_name_ascii";
		} else if ("firmenname_auto".equalsIgnoreCase(fieldName)) {
			storeName = "vae.search_firmenname_ascii_auto";
		} else if ("name_auto".equalsIgnoreCase(fieldName)) {
			storeName = "vae.search_name_ascii_auto";
		} else if ("vorname_auto".equalsIgnoreCase(fieldName)) {
			storeName = "vae.search_vorname_ascii_auto";
		} else if ("anrede_auto".equalsIgnoreCase(fieldName)) {
			storeName = "vae.search_anrede_ascii_auto";
		} else if ("zuzat_auto".equalsIgnoreCase(fieldName)) {
			storeName = "vae.search_zuzat_ascii";
		}
		return storeName;
	}
		
	
	
	public String checkSpace(String fieldNameLike) {
		char[] arr = null;
		String searchKey = "";
		if (fieldNameLike.contains(" ")) {
			arr = fieldNameLike.toCharArray();
			for (int i = 0; i < arr.length; i++) {
				if (Character.isWhitespace(arr[i])) {
					searchKey = processdata(searchKey);
					searchKey = searchKey + arr[i];
				} else {
					searchKey = searchKey + arr[i];
				}
				if (i == arr.length - 1) {
					searchKey = processdata(searchKey);
				}
			}
		} else {
			searchKey = processdata(fieldNameLike);
		}
		return searchKey;
	}
	
	public String removeDuplicateWord(String original) {
		String[] data = original.split(";");
		List<String> list = Arrays.asList(data);
		Set<String> set = new HashSet<String>(list);
		String[] result = new String[set.size()];
		set.toArray(result);
		return set.toString().replace("[", "").replace("]", "");
	}
	
	
	public String[] getChangeCase() {
		Connection conn = null;
		String result[] = null;
		Array tmp;
		try {
			conn = baseDAL.getConnection();
			tmp = (Array) processStore(conn, "vae.get_change_case", null, Types.ARRAY);
			if (tmp != null) {;}
		} catch (SQLException ex) {
			log.error(Utilities.getStackTrace(ex));
		} catch (Exception ex) {
			log.error(Utilities.getStackTrace(ex));
		} finally {
			baseDAL.freeCommitConnection(conn);
		}
		return result;
	}
	public String getListStringOrt() {
		Connection conn = null;
		String result ="";	
		try {
			conn = baseDAL.getConnection();
			result = (String) processStore(conn, "vae.get_ort_list", null, Types.VARCHAR);
		} catch (SQLException ex) {
			log.error(Utilities.getStackTrace(ex));
		} catch (Exception ex) {
			log.error(Utilities.getStackTrace(ex));
		} finally {
			baseDAL.freeCommitConnection(conn);
		}
		return result;
	}
	public void releaseConnectionWritingDB() {
		baseDAL.releaseConnection();
		
	}
}
