/*
 * To change this template, choose Tools | Templates and open the template in the editor.
 */
package com.sps.vn.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ghp.vae.data_entry.common.EncryptionHelper;

/**
 *
 * @author lqbinh
 */
public class ApplicationConfig {

	private final Logger log = LoggerFactory.getLogger(ApplicationConfig.class);

	private boolean errorLoadConfig = false;
	private String errorLoadConfigMessage;

	private static ApplicationConfig instance = null;
	private Properties props = null;

	private BusinessConfig businessConfig;
	private Working2ProjectConfig working2ProjectConfig;
	private WordSuggestionConfig textualServiceConfig;
	private LookupConfig lookupConfig;
	private OCRConfig ocrConfig;
	private ProxyConfig proxyConfig;
	private WritingConfig writingConfig;
	private OCRPostProcessingConfiguration ocrPostProcessingConfiguration;

	private DisplayConfig displayConfig;

	protected ApplicationConfig() {
		// Exists only to defeat instantiation.
		this.init();
	}

	public static ApplicationConfig getInstance() {
		if (instance == null) {
			instance = new ApplicationConfig();
		}
		return instance;
	}

	public boolean isErrorLoadConfig() {
		return this.errorLoadConfig;
	}

	public String getErrorLoadConfigMessage() {
		return this.errorLoadConfigMessage;
	}

	public WritingConfig getWritingConfig() {
		return this.writingConfig;
	}

	public BusinessConfig getBusinessConfig() {
		return this.businessConfig;
	}

	public Working2ProjectConfig getWorking2ProjectConfig() {
		return this.working2ProjectConfig;
	}

	public WordSuggestionConfig getTextualServiceConfig() {
		return this.textualServiceConfig;
	}

	public LookupConfig getLookupConfig() {
		return this.lookupConfig;
	}

	public DisplayConfig getDisplayConfig() {
		return this.displayConfig;
	}

	/**
	 * @return Returns the ocrPostProcessingConfiguration.
	 */
	public OCRPostProcessingConfiguration getOcrPostProcessingConfiguration() {
		return this.ocrPostProcessingConfiguration;
	}

	public ProxyConfig getProxyConfig() {
		return this.proxyConfig;
	}

	public OCRConfig getOcrConfig() {
		return this.ocrConfig;
	}

	public static HashMap<String, String> jsonToMap(String t) throws JSONException, ParseException {

		final HashMap<String, String> map = new HashMap<String, String>(4);
		final JSONObject jObject = new JSONObject(t);
		final Iterator<?> keys = jObject.keys();

		while (keys.hasNext()) {
			final String key = (String) keys.next();
			final String value = jObject.getString(key);
			map.put(key, value);

		}

		return map;
	}

	private boolean getBoolean(String propertyName) {
		final String value = this.getString(propertyName);

		return Boolean.parseBoolean(value);
	}

	private int getInt(String propertyName) {
		final String value = this.getString(propertyName);

		return Integer.parseInt(value);
	}

	private long getLong(String propertyName) {
		final String value = this.getString(propertyName);

		return Long.parseLong(value);
	}

	private float getFloat(String propertyName) {
		final String value = this.getString(propertyName);

		return Float.parseFloat(value);
	}

	private String getString(String propertyName) {
		final String value = this.props.getProperty(propertyName);

		if (value == null) {
			throw new NullPointerException(propertyName + " is NULL");
		}

		return value.trim();
	}

	private String[] getArray(String propertyName) {
		final String[] values = this.props.getProperty(propertyName).split(",");

		if (values == null) {
			throw new NullPointerException(propertyName + " is NULL");
		}

		return values;
	}

	private void init() {
		try {
			this.props = new Properties();
			// Load configuration properties
			final String filePath = System.getProperty("user.dir") + "/config/application.properties";
			this.loadProperties(filePath);

			/**
			 * * 1 - Writing Info **
			 */
			final String writingUrl = this.getString("app.custom.writing.datasource.url");
			final String writingDatabase = this.getString("app.custom.writing.datasource.database");
			final String writingUsername = this.getString("app.custom.writing.datasource.username");
			final String writingPassword = EncryptionHelper
					.decrypt(this.getString("app.custom.writing.datasource.password"));

			this.writingConfig = new WritingConfig(writingUrl, writingDatabase, writingUsername, writingPassword);

			/**
			 * * - Working on 2 Projects Info **
			 */
			this.working2ProjectConfig = new Working2ProjectConfig();
			this.working2ProjectConfig
					.setConnectToBrokerActiveMQ(this.getBoolean("app.custom.connectToBrokerActivemq"));
			this.working2ProjectConfig.setActiveMQJmsTimeout(this.getInt("app.custom.activemqJmsTimeout"));
			this.working2ProjectConfig.setPauseCmd(jsonToMap(this.getString("app.custom.sendPauseToCL")));
			this.working2ProjectConfig.setResumeCmd(jsonToMap(this.getString("app.custom.sendResumeToCL")));

			/**
			 * * - Lookup Search **
			 */
			this.lookupConfig = new LookupConfig();

			this.lookupConfig.setRetryTimes(this.getInt("app.custom.lookup.retryTimes"));
			this.lookupConfig.setDelay(this.getInt("app.custom.lookup.delay"));
			this.lookupConfig.setSocketTimeout(this.getInt("app.custom.lookup.socket-timeout"));
			this.lookupConfig.setConnectionTimeout(this.getInt("app.custom.lookup.connection-timeout"));

			final List<String> hosts = Arrays.asList(this.getArray("app.custom.lookup.hosts"));
			final List<String> ports = Arrays.asList(this.getArray("app.custom.lookup.ports"));
			this.lookupConfig.setHosts(hosts, ports);

			this.lookupConfig.setSearchRestService(this.getString("app.custom.lookup.kdp.restService"));
			this.lookupConfig.setSearchFirst(this.getString("app.custom.lookup.kdp.searchFirst"));
			this.lookupConfig.setLookupExtraRestService(this.getString("app.custom.lookup.lookupExtra.restService"));
			this.lookupConfig.setOcrKdpCountService(this.getString("app.custom.lookup.ocr.kdp.count"));
			this.lookupConfig.setOcrOrtCountService(this.getString("app.custom.lookup.ocr.ort.count"));
			this.lookupConfig.setOcrPlzCountService(this.getString("app.custom.lookup.ocr.plz.count"));
			this.lookupConfig.setOcrStrasseCountService(this.getString("app.custom.lookup.ocr.strasse.count"));
			this.lookupConfig.setOcrFirmaSignSearchService(this.getString("app.custom.lookup.ocr.firmasign.search"));
			this.lookupConfig.setVaeUtilNormalize(this.getString("app.custom.lookup.util.normalize"));
			this.lookupConfig.setLookupHauskeyRestService(this.getString("app.custom.lookup.hauskey.restService"));
			this.lookupConfig.setLookupDuplicationCountRestService(
					this.getString("app.custom.lookup.duplication.count.restService"));
			this.lookupConfig
					.setZubofiAddressidRestService(this.getString("app.custom.lookup.zubofi.addressid.restService"));
			this.lookupConfig
					.setZubofiHauskeyRestService(this.getString("app.custom.lookup.zubofi.hauskey.restService"));
			this.lookupConfig.setZubofiSpecialAddressidRestService(
					this.getString("app.custom.lookup.zubofi.special.addressid.restService"));
			this.lookupConfig.setZubofiStreetnumberRestService(
					this.getString("app.custom.lookup.zubofi.streetnumber.restService"));
			this.lookupConfig.setZubofiSpecialAddressidRestServiceCheck(
					this.getString("app.custom.lookup.zubofi.special.addressid.restService.check"));
			this.lookupConfig.setZubofiSpecialAddressidRestServiceSameCheck(
					this.getString("app.custom.lookup.zubofi.special.addressid.restService.sameCheck"));
			this.lookupConfig
					.setKdpSuggestionRestService(this.getString("app.custom.lookup.suggestion.restService.kdp"));
			this.lookupConfig.setKdpCheckSwapConditionRestService(
					this.getString("app.custom.suggestion.restService.checkswapcondition"));
			this.lookupConfig.setCheckMoveConditionRestService(this.getString("app.custom.suggestion.restService.checkmovecondition"));
			this.lookupConfig.setZubofiSpecialPickpostHauskeyRestService(
					this.getString("app.custom.lookup.zubofi.special.pickpost.hauskey.restService"));
			this.lookupConfig.setZubofiSpecialPostfachHauskeyRestService(
					this.getString("app.custom.lookup.zubofi.special.postfach.hauskey.restService"));
			this.lookupConfig.setZubofiSpecialPostlagerndHauskeyRestService(
					this.getString("app.custom.lookup.zubofi.special.postlagernd.hauskey.restService"));
			this.lookupConfig.setLookupASDPPlz(this.getString("app.custom.lookup.asdpplz"));

			/**
			 * Word suggestion *
			 */
			this.lookupConfig.getWordSuggestionConfig()
					.setSuggestRestService(this.getString("app.custom.lookup.word-suggestion.suggest"));
			this.lookupConfig.getWordSuggestionConfig()
					.setSearchSuggestRestService(this.getString("app.custom.lookup.word-suggestion.search"));
			this.lookupConfig.getWordSuggestionConfig()
					.setWeightSuggestRestService(this.getString("app.custom.lookup.word-suggestion.weight"));
			this.lookupConfig.getWordSuggestionConfig()
					.setEnableLearnWord(this.getBoolean("app.custom.lookup.word-suggestion.enableLearnWord"));

			this.ocrPostProcessingConfiguration = new OCRPostProcessingConfiguration();
			this.ocrPostProcessingConfiguration
					.setKnownAnredes(this.getString("app.custom.ocr.postprocessing.knownAnredes"));
			this.ocrPostProcessingConfiguration
					.setKnownPickposts(this.getString("app.custom.ocr.postprocessing.knownPickposts"));
                        this.ocrPostProcessingConfiguration
					.setKnownMypost24s(this.getString("app.custom.ocr.postprocessing.knownMypost24s"));
			this.ocrPostProcessingConfiguration
					.setKnownPostfatches(this.getString("app.custom.ocr.postprocessing.knownPostfatches"));
			this.ocrPostProcessingConfiguration
					.setKnownPostlagernds(this.getString("app.custom.ocr.postprocessing.knownPostlagernds"));
			this.ocrPostProcessingConfiguration
					.setKnownStrasses(this.getString("app.custom.ocr.postprocessing.knownStrasses"));
			this.ocrPostProcessingConfiguration
					.setSpecialAddresses(this.getString("app.custom.ocr.postprocessing.specialAddresses"));
			this.ocrPostProcessingConfiguration.setStopWords(this.getString("app.custom.ocr.postprocessing.stopWords"));

			/**
			 * *** OCR ****
			 */
			this.ocrConfig = new OCRConfig();

			this.ocrConfig.setHostname(this.getString("app.custom.ocr.hostname"));
			this.ocrConfig.setPort(this.getString("app.custom.ocr.port"));
			this.ocrConfig.setController(this.getString("app.custom.ocr.controller"));
			this.ocrConfig.setUsername(this.getString("app.custom.ocr.username"));
			this.ocrConfig.setPassword(EncryptionHelper.decrypt(this.getString("app.custom.ocr.password")));
			this.ocrConfig.setHttpClientTimeout(this.getString("app.custom.ocr.httpClientTimeout"));
			this.ocrConfig.setTotalConnection(this.getString("app.custom.ocr.totalConnection"));

			this.ocrConfig.setServerTimeout(this.getString("app.custom.ocr.serverTimeout"));

			this.ocrConfig.setHeight(this.getInt("app.custom.ocr.height"));
			this.ocrConfig.setWidth(this.getInt("app.custom.ocr.width"));
			this.ocrConfig.setSize(this.getInt("app.custom.ocr.size"));
			this.ocrConfig.setForCheck(this.getString("app.custom.ocr.forCheck"));

			this.ocrConfig.setType(this.getString("app.custom.ocr.type"));
			this.ocrConfig.setImageType(this.getString("app.custom.ocr.imageType"));
			this.ocrConfig.setProjectName(this.getString("app.custom.ocr.projectName"));
			this.ocrConfig.setDeskew(this.getBoolean("app.custom.ocr.deskew"));
			this.ocrConfig.setLanguage(this.getString("app.custom.ocr.language"));
			this.ocrConfig.setAcceptFirstResult(this.getBoolean("app.custom.ocr.acceptFirstResult"));
			this.ocrConfig.setIncludeCharacterResult(this.getBoolean("app.custom.ocr.includeCharacterResult"));
			this.ocrConfig.setPriority(this.getInt("app.custom.ocr.priority"));
			this.ocrConfig.setPattern(this.getString("app.custom.ocr.pattern"));

			/**
			 * * Proxy **
			 */
			this.proxyConfig = new ProxyConfig();
			this.proxyConfig.setHost(this.getString("app.custom.proxy.host"));
			this.proxyConfig.setProxyPort(this.getInt("app.custom.proxy.port"));
			this.proxyConfig.setNettyPort(this.getInt("app.custom.netty.port"));
			this.proxyConfig.setRestServiceTime(String.format(this.getString("app.custom.proxy.restServiceTime"),
					this.getString("app.custom.proxy.host")));
			this.proxyConfig.setRetryTimes(this.getInt("app.custom.proxy.retryTimes"));

			/**
			 * * Bussiness **
			 */
			this.businessConfig = new BusinessConfig();
			this.businessConfig.setSignArmy(this.getString("app.custom.signArmy"));
			this.businessConfig.setTimeZone(this.getString("app.custom.timeZone"));
			this.businessConfig.setServiceLevel(this.getFloat("app.custom.serviceLevel"));
			this.businessConfig.setValidPercent(this.getInt("app.custom.validPercent"));
			this.businessConfig.setBlockingWord(this.getString("app.custom.blockingWord"));
			this.businessConfig.setShowPopupTime(this.getLong("app.custom.showPopupTime"));
			this.businessConfig.setAverageImageSize(this.getInt("app.custom.averageImageSize"));
			this.businessConfig.setTraining(this.getString("app.custom.training"));
			this.businessConfig.setLocationLDAP(this.getString("app.custom.locationLDAP"));
			this.businessConfig.setLoginWithLdap(this.getBoolean("app.custom.loginWithLDAP"));
			this.businessConfig.setValidRoleList(this.getString("app.custom.validRoleList"));
			this.businessConfig.setRunOnCL(this.getBoolean("app.custom.runOnCL"));
			this.businessConfig.setDelaySuggestion(this.getInt("app.custom.delaySuggestion"));
			this.businessConfig.setDelayTryingTime(this.getInt("app.custom.delayTryingTime"));
			this.businessConfig.setWaitingTimeRequestCard(this.getInt("app.custom.waitingTimeRequestCard"));
			this.businessConfig.setNotWord(this.getString("app.custom.notWord"));
			this.businessConfig.setReplaceEndWith(this.getString("app.custom.replaceEndWith"));
			this.businessConfig.setAlarmKDPID(this.getString("app.custom.alarmKDPID"));

			this.businessConfig.setZoomHeight(this.getInt("app.custom.zoomHeight"));
			this.businessConfig.setZoomWidth(this.getInt("app.custom.zoomWidth"));

			/**
			 * * Display **
			 */
			this.displayConfig = new DisplayConfig();
			this.displayConfig.setLookupTitle(this.getString("app.custom.displaypane.lookup.title"));
			this.displayConfig.setLookupInfo(this.getArray("app.custom.displaypane.lookup.info"));

			this.displayConfig.setFirmaTitle(this.getString("app.custom.displaypane.firma.title"));
			this.displayConfig.setFirmaInfo(this.getArray("app.custom.displaypane.firma.info"));

			this.displayConfig.setZusatTitle(this.getString("app.custom.displaypane.zusat.title"));
			this.displayConfig.setZusatInfo(this.getArray("app.custom.displaypane.zusat.info"));

			this.displayConfig.setAnredeTitle(this.getString("app.custom.displaypane.anrede.title"));
			this.displayConfig.setAnredeInfo(this.getArray("app.custom.displaypane.anrede.info"));

			this.displayConfig.setVornameTitle(this.getString("app.custom.displaypane.vorname.title"));
			this.displayConfig.setVornameInfo(this.getArray("app.custom.displaypane.vorname.info"));

			this.displayConfig.setNameTitle(this.getString("app.custom.displaypane.name.title"));
			this.displayConfig.setNameInfo(this.getArray("app.custom.displaypane.name.info"));

			this.displayConfig.setPlzTitle(this.getString("app.custom.displaypane.plz.title"));
			this.displayConfig.setPlzInfo(this.getArray("app.custom.displaypane.plz.info"));

			this.displayConfig.setOrtTitle(this.getString("app.custom.displaypane.ort.title"));
			this.displayConfig.setOrtInfo(this.getArray("app.custom.displaypane.ort.info"));

			this.displayConfig.setStrasseTitle(this.getString("app.custom.displaypane.strasse.title"));
			this.displayConfig.setStrasseInfo(this.getArray("app.custom.displaypane.strasse.info"));

			this.displayConfig.setHouseTitle(this.getString("app.custom.displaypane.house.title"));
			this.displayConfig.setHouseInfo(this.getArray("app.custom.displaypane.house.info"));

			this.displayConfig.setPostfachTitle(this.getString("app.custom.displaypane.postfach.title"));
			this.displayConfig.setPostfachInfo(this.getArray("app.custom.displaypane.postfach.info"));

			this.displayConfig.setStockwerkTitle(this.getString("app.custom.displaypane.stockwerk.title"));
			this.displayConfig.setStockwerkInfo(this.getArray("app.custom.displaypane.stockwerk.info"));

			this.displayConfig.setAdresszusatzTitle(this.getString("app.custom.displaypane.adresszusatz.title"));
			this.displayConfig.setAdresszusatzInfo(this.getArray("app.custom.displaypane.adresszusatz.info"));

			this.displayConfig.setCo_addresseTitle(this.getString("app.custom.displaypane.co_addresse.title"));
			this.displayConfig.setCo_addresseInfo(this.getArray("app.custom.displaypane.co_addresse.info"));

			this.displayConfig.setPickpostTitle(this.getString("app.custom.displaypane.pickpost.title"));
			this.displayConfig.setPickpostInfo(this.getArray("app.custom.displaypane.pickpost.info"));

			this.displayConfig.setPostlagerndTitle(this.getString("app.custom.displaypane.postlagernd.title"));
			this.displayConfig.setPostlagerndInfo(this.getArray("app.custom.displaypane.postlagernd.info"));

			this.displayConfig.setMypost24Title(this.getString("app.custom.displaypane.mypost24.title"));
			this.displayConfig.setMypost24Info(this.getArray("app.custom.displaypane.mypost24.info"));
			
			this.displayConfig.setMoveImage(this.getString("app.custom.displaypane.moveImage"));
			
			/**
			 * * Original Properties File **
			 */
			final StringBuilder originalProperties = new StringBuilder();
			for (final String key : this.props.stringPropertyNames()) {
				originalProperties.append(String.format(" + %s :: %s\n", key, this.props.get(key)));
			}
			this.log.info("+++ Original Properties File +++");
			this.log.info(originalProperties.toString());

			final StringBuilder logConfig = new StringBuilder("\n");

			this.log.info(logConfig.toString());
		} catch (final FileNotFoundException ex) {
			this.log.error("", ex);
			this.errorLoadConfig = true;
			this.errorLoadConfigMessage = ex.getMessage();

		} catch (final IOException ex) {
			this.log.error("", ex);
			this.errorLoadConfig = true;
			this.errorLoadConfigMessage = ex.getMessage();

		} catch (final Exception ex) {
			this.log.error("", ex);
			this.errorLoadConfig = true;
			this.errorLoadConfigMessage = ex.getMessage();

		}
	}

	/**
	 * Load properties.
	 *
	 * @param filePath
	 *            the file path
	 * @throws IOException
	 */
	private void loadProperties(String filePath) throws IOException {
		InputStream is = null;

		try {
			is = new FileInputStream(filePath);
			if (is != null) {
				this.props.load(is);
			}
		} finally {
			if (is != null) {
				is.close();
			}
		}
	}
}
