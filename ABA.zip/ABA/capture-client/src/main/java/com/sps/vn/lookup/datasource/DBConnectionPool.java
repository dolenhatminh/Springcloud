package com.sps.vn.lookup.datasource;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;

/**
 * @author vxhoa
 * 
 */
public class DBConnectionPool {

    private String m_sdriver;
    private String m_sURL;
    private String m_suser;
    private String m_spassword;
    private int m_imaxConn;
    private int m_icheckedOut = 0;

	@SuppressWarnings("rawtypes")
	private Vector m_vtfreeConnections = new Vector();

    /**
     *
     */
    public DBConnectionPool(String sdriver, String sURL, String suser,
            String spassword, int imaxConn) {
        this.m_sdriver = sdriver;
        this.m_sURL = sURL;
        this.m_suser = suser;
        this.m_spassword = spassword;
        this.m_imaxConn = imaxConn;
        loadDriver();
    }

    /**
     * <summary> Check out a connection from the pool. -If there is no available
     * connection, a new connection will be created if number of connections
     * hasn't been reached max connections allowed </summary>
     * <returns>Connection</returns>
     *
     * @throws VAEException
     */
    public synchronized Connection getConn() {
        Connection conn = null;
        if (m_vtfreeConnections.size() > 0) {
            // Pick the first Connection
            conn = (Connection) m_vtfreeConnections.firstElement();
            m_vtfreeConnections.removeElementAt(0);
            try {
                if (conn == null || conn.isClosed()) {
                    // Try to get another available connection
                    conn = getConn();
                }
            } catch (Exception e) {
                
                conn = getConn();
            }
        } else if (m_imaxConn == 0 || m_icheckedOut < m_imaxConn) {
            try {
                // Create new connection
                conn = newConn();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (conn != null) {
            m_icheckedOut++;
        }
        try {
            if (!conn.getAutoCommit()) {
                conn.setAutoCommit(true);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return conn;
    }

    /**
     * <summary> Check out a connection from the pool. -If there is no available
     * connection, a new connection will be created if number of connections
     * hasn't been reached max connections allowed -If there is no available
     * connection and number of connections has been reached max connections
     * allowed, the method will wait for one to be checked in </summary> <param
     * name="ltimeout">long: The timeout value in milliseconds </param>
     * <returns>Connection</returns>
     */
    public synchronized Connection getConn(long ltimeout) {
        try {
            long lstartTime = new Date().getTime();
            Connection conn;
            while ((conn = getConn()) == null) {
                try {
                    wait(ltimeout);
                } catch (InterruptedException e) {
                    
                }
                if ((new Date().getTime() - lstartTime) >= ltimeout) {
                    // Timeout has expired
                    
                    return null;
                }
            }
            try {
                if (!conn.getAutoCommit()) {
                    conn.setAutoCommit(true);
                }
            } catch (SQLException ex) {
            }
            return conn;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


	@SuppressWarnings("rawtypes")
	private boolean loadDriver() {
        try {
            Class cls = Class.forName(m_sdriver);
            Driver driver = (Driver) cls.newInstance();
            DriverManager.registerDriver(driver);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            
            return false;
        }
    }

    private Connection newConn() throws Exception {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(m_sURL, m_suser, m_spassword);
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        return conn;
    }

    /**
     * <summary> Checks in a connection to the pool. Notify other Threads that
     * are waiting for a connection. </summary> <param name="conn">Connection:
     * The connection that will be checked into the pool </param> <returns>void</returns>
     */
    @SuppressWarnings("unchecked")
	public synchronized void freeConn(Connection conn) {
        // Check in the conenction
        m_vtfreeConnections.addElement(conn);
        m_icheckedOut--;
        // Notify that there is a conenction has just been free
        notifyAll();
    }

    public synchronized void releaseConn() {
        m_icheckedOut--;
    }

    /**
     * <summary> Closes all available connections </summary> <returns>void</returns>
     */

	@SuppressWarnings("rawtypes")
	public synchronized void release() throws Exception {
		Enumeration allConns = m_vtfreeConnections.elements();
        while (allConns.hasMoreElements()) {
            Connection conn = (Connection) allConns.nextElement();
            try {
                // Close connection
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
                
                /**
                 * One the errorhandler package is implemented, we will throw
                 * ELM exception instead of SQLException as currently
                 */
                throw e;
            }
        }
        m_vtfreeConnections.removeAllElements();
    }
}
