/*
 * Class: StringUtil
 *
 * Created on Mar 8, 2016
 *
 * (c) Swiss Post Solutions Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solutions Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package com.sps.vn.utilities;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import com.ghp.vae.data_entry.bll.BLLViewData;
import com.ghp.vae.search.service.impl.LookupServiceImpl;

/**
 * The Class StringUtil.
 */
public final class StringUtil {

    /**
     * Checks if is integer string.
     *
     * @param string the string
     * @return true, if is integer
     */
    public static boolean isInteger(final String string) {
        boolean ret = false;

        if (string != null) {
            final Pattern pattern = Pattern.compile("[0-9]+");
            final Matcher matcher = pattern.matcher(string);
            ret = matcher.matches();
        }

        return ret;
    }
    
    public static String containValue(String value, String paragraph) {
    	 String result = "";
         if (value != null) {
        	 // String regex = value + "\\w+";
        	 String regex = processRegex(value, true);
        	 System.out.println(regex);
        	 Pattern pattern = Pattern.compile(regex);
        	 Matcher matcher = pattern.matcher(paragraph);
        	 int start = 0;
        	 int end = 0;
        	 while (matcher.find()) {
				if (end == 0) {
					start = matcher.start();
					end = matcher.end();
				}
			}
        	 if (end != 0) {
        		result = paragraph.substring(start + 1, end);
			}
        	 System.out.println(result);
         }
         return result;
	}
    
    public static String containValue(String value, List<String> paragraph, BLLViewData viewData) {
    	value = viewData.translateData(value);
    	StringBuffer result = new StringBuffer();
    	if (value != null) {
        	String regexCheckTrust = processRegex(value, true);
        	String regexSimilar = processRegex(value, false);
        	Pattern patternCheckTrust = Pattern.compile(regexCheckTrust);
        	Pattern patterSimilar = Pattern.compile(regexSimilar);
        	for (String line : paragraph) {
        		String comparableValue = viewData.translateData(line);
        		Matcher matcherCheckTrust = patternCheckTrust.matcher(comparableValue);
        		Matcher matcherSimilar = patterSimilar.matcher(comparableValue);
            	if (matcherCheckTrust.find() || matcherSimilar.find()) {
            		result.append(line.substring(2));
            		break;
            	}
			}
    	 }
    	 return result.toString().trim();
	}
    
    private static String processRegex(String value, Boolean isCheckTrust) {
		StringBuffer regex = new StringBuffer("(\\W|\\s)");
		char[] arrayChar = value.toCharArray();
		for (char item : arrayChar) {
			regex.append("(");
			regex.append(Character.toLowerCase(item));
			regex.append("|");
			regex.append(Character.toUpperCase(item));
			regex.append(")");
		} 
		if (!isCheckTrust) {
			regex.append("[a-zA-Z]+");
		}
		return regex.toString();
	}

    /**
     * Instantiates a new string util.
     */
    private StringUtil() {
    }
    
    public static boolean isEmpty(String value) {
    	if (value == null)
    		return true;
    	if (StringUtils.isEmpty(value.trim()))
    		return true;
    	return false;
    }
}
