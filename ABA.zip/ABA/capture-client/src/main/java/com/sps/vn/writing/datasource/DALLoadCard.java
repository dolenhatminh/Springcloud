package com.sps.vn.writing.datasource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Array;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

public class DALLoadCard extends WritingDBase{
	@SuppressWarnings("unused")
	private static Logger log = LoggerFactory.getLogger(DALLoadCard.class);
	private WritingBaseDAL baseDAL;
	
	public DALLoadCard() {
		baseDAL = new WritingBaseDAL();
	}
	
	public String[][] getInputFields() throws Exception {
		Connection conn = null;
		String result[][] = null;
		Array tmp;
		try {
			conn = baseDAL.getConnection();
			String args[] = null;
			tmp = (Array) processStore(conn, "vae.dae_get_fields", args,
					Types.ARRAY);
			if (tmp != null) {
				result = (String[][]) tmp.getArray();
			}
		} catch (SQLException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		} finally {
			baseDAL.freeCommitConnection(conn);
		}
		return result;
	}
	
}
