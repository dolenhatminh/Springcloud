package com.sps.vn.config;

public class WordSuggestionConfig {

    private boolean enableLearnWord;

    private String suggestRestService;
    private String searchSuggestRestService;
    private String weightSuggestRestService;

    public boolean isEnableLearnWord() {
        return enableLearnWord;
    }

    public void setEnableLearnWord(boolean enableLearnWord) {
        this.enableLearnWord = enableLearnWord;
    }

    public String getSuggestRestService() {
        return suggestRestService;
    }

    public void setSuggestRestService(String suggestRestService) {
        this.suggestRestService = suggestRestService;
    }

    public String getSearchSuggestRestService() {
        return searchSuggestRestService;
    }

    public void setSearchSuggestRestService(String searchSuggestRestService) {
        this.searchSuggestRestService = searchSuggestRestService;
    }

    public String getWeightSuggestRestService() {
        return weightSuggestRestService;
    }

    public void setWeightSuggestRestService(String weightSuggestRestService) {
        this.weightSuggestRestService = weightSuggestRestService;
    }

}
