package vae.client.transfer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.lang.reflect.Type;

public class JsonUtils {
	static Gson gson = new GsonBuilder().setDateFormat("yyyy.MM.dd HH:mm:ss.SS").create();

	public static String object2Json(Object object) {
		return gson.toJson(object);
	}

	public static <T> T json2Object(String json, Class<T> t) {
		return gson.fromJson(json, t);
	}

	public static <T> T json2Object(String json, Type type) {
		return gson.fromJson(json, type);
	}

	public static boolean mayBeJSON(String string) {
		return ((string != null) && ((("null".equals(string)) || ((string.startsWith("[")) && (string.endsWith("]"))) || ((string
				.startsWith("{")) && (string.endsWith("}"))))));
	}

}
