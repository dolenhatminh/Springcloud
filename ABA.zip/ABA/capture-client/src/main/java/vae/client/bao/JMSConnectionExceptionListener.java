package vae.client.bao;

import com.ghp.vae.data_entry.common.Utilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.Connection;
import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.swing.*;
import java.awt.*;

public class JMSConnectionExceptionListener implements ExceptionListener {
	private static Logger log= LoggerFactory.getLogger(JMSConnectionExceptionListener.class);
	private Connection connection;
	public JMSConnectionExceptionListener(Connection connection) {
		this.connection = connection;
	}
	
	
	@Override
	public void onException(JMSException ex) {
		log.error("", ex);
		excuteWhenError(ex);
		
	}
	private void excuteWhenError(Throwable e) {
		String mess = "Khong connect duoc\nThong bao voi quan li du an ngay!\n";
		mess = mess+ Utilities.getStackTrace(e);
		JPanel panel  = new JPanel();
		panel.setLayout(new BorderLayout());
		JTextArea area = new JTextArea(20,60);
		JScrollPane scrollBar = new JScrollPane(area);
		area.setText(mess);
		scrollBar.setSize(300, 200);
		panel.add(scrollBar,BorderLayout.CENTER);
		try{
			connection.close();
		}catch(Exception ex){
		}
		JOptionPane.showMessageDialog(null, panel, "Canh bao", JOptionPane.ERROR_MESSAGE);
		System.exit(0);
	}

}
