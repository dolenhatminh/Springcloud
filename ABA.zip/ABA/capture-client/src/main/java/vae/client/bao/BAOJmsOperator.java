//package vae.client.bao;
//
//import com.sps.vn.config.ApplicationConfig;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import vae.bb.core.hibernate.model.Collection;
//
//import javax.jms.*;
//import javax.naming.Context;
//
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.util.concurrent.TimeUnit;
//
//public class BAOJmsOperator {
//
//	private static Logger log = LoggerFactory.getLogger(BAOJmsOperator.class);
//	Context ctx;
//	Connection connection;
//	Session session;
//	MessageProducer userMsgProducer;
//	MessageProducer capturedMsgProducer;
//	MessageConsumer collectionConsumer;
//	int level;
//	Queue OperatorQueue;
//	String restTime ;
//	private long delaytime;
//	private String restRemoveUserIsHoldingCollectionUrl = "";
//
//  
//	public BAOJmsOperator(int level, Context ctx, Connection connection, Session session) throws Exception {
//		this.level = level;
//		this.ctx = ctx;
//		this.connection = connection;
//		this.session = session;
//		restTime = ApplicationConfig.getProperties().getProperty("REST_SERVICE_TIME");
//		try{
//			delaytime = ApplicationConfig.getInstance().getBusinessConfig().getDelayTryingTime();
//		}catch(Exception ex){
//			delaytime = 1000;
//		}
//		
//		restRemoveUserIsHoldingCollectionUrl = ApplicationConfig.getProperties().getProperty("REST_SERVICE_REMOVE_USER_IS_HOLDING_COLLECTION_URL");
//	}
//
//	
//	public boolean registerUser(int clientID) throws Exception {
//		boolean retVal = false;
//
//		// create producer
//		Queue UserQueue = (javax.jms.Queue) ctx.lookup("/userQueue");
//		userMsgProducer = session.createProducer(UserQueue);
//		TextMessage mess = session.createTextMessage();
//		mess.setText(clientID + "");
//		userMsgProducer.setPriority(10 - level);
//		userMsgProducer.send(mess);
//		userMsgProducer.close();
//		retVal = true;
//		return retVal;
//	}
//
//	public void sendCapturedCollection(Collection collection) throws Exception {
//		Queue capturedQueue = (javax.jms.Queue) ctx.lookup("/returnQueue");
//		capturedMsgProducer = session.createProducer(capturedQueue);
//		ObjectMessage msg = session.createObjectMessage();
//		msg.setObject(collection);
//		capturedMsgProducer.send(msg);
//		capturedMsgProducer.close();
//	}
//	
//	public void notifyProxyToRemoveUserIsHoldingCollection(int userID)  {
//		URL url = null;
//		HttpURLConnection conn = null;
//		try {
//			url = new URL(restRemoveUserIsHoldingCollectionUrl + "?userID=" + userID);
//			conn = (HttpURLConnection) url.openConnection();
//			conn.setRequestMethod("PUT");
//			conn.getInputStream().close();
//		
//		} catch (Exception e) {
//			url = null;
//			
//			if(conn != null){
//				conn.disconnect();
//			}
//			conn = null;
//			log.error("", e.fillInStackTrace());
//			
//			try {
//				TimeUnit.SECONDS.sleep(delaytime);
//			} catch (InterruptedException ie) {
//				log.error("", e.fillInStackTrace());
//			}
//			
//			notifyProxyToRemoveUserIsHoldingCollection(userID);
//		} finally{
//			url = null;
//	
//			if(conn != null){
//				conn.disconnect();
//			}
//			conn = null;
//		}
//	}
//	public String getCurrentTime() throws Exception {
//		while(true){
//			try{
//				URL url = new URL(restTime);
//				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//				conn.setRequestMethod("PUT");
//				InputStream stream = conn.getInputStream();
//				BufferedReader br = new BufferedReader(new InputStreamReader(stream));
//				String line = br.readLine();
//			
//				br.close();
//				conn.disconnect();
//				return line;
//			}catch(IOException ex){
//				try{
////					System.out.println("get time");
//					Thread.sleep(delaytime);
//				}catch(Exception e){
//				}
//			}
//		}
////		return System.currentTimeMillis()+"";
//	}
//
//	
//}
