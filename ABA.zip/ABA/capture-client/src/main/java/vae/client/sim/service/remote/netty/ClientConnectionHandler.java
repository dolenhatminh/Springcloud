package vae.client.sim.service.remote.netty;

import vae.bb.core.hibernate.model.Collection;
import vae.netty.IConnection;
import vae.netty.IConnectionHandler;

public class ClientConnectionHandler implements IConnectionHandler {
	public Collection receivedCollection;

	@Override
	public void onConnected(IConnection conn) {
		System.out.println("CONNECT TO SERVER " + conn.getRemoteAddress());
	}

	@Override
	public void onDisconnected(IConnection conn) {
	
		System.out.println("DISCONNECT FROM SERVER ");
	}

	@Override
	public void onException(IConnection conn, Throwable ex) {
	
		System.out.println("NETWORK ERROR");
	}

	@Override
	public void onMessage(IConnection conn, Object msg) {
		if(msg instanceof Collection){
			receivedCollection = (Collection) msg;
			synchronized (this) {
				this.notify();
			}
		}
	}

}
