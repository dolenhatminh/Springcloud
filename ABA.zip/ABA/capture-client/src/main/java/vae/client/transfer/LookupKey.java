package vae.client.transfer;

public enum LookupKey {
    NO("No","No.",25),
    NAME_09("name", "Name", 180),
    NAME_10("vorname", "Vorname", 143),
    FIRMENNAME("Firmenname", "Firmenname", 390),
    NAME("Name", "Name", 180),
    NAMENSZUSATZ("Namenszusatz", "Namenszusatz", 0),
    VORNAME("Vorname", "Vorname", 143),
    NAME_SET("name_galias", "Name Set", 0),
    NAME_ALIAS("Name Alias", "Name Alias", 0),
    VNAME_ALIAS("Vorname Alias", "Vorname Alias", 0),
    FULLHAUSNUMMER("FULLHAUS", "Haus", 50),
    VNAME_SET("vorname_galias", "Vorname Set", 0),
    PLZ("plz", "Plz", 70),
    ORT("ort", "Ort", 170),
    STRASSE("strasse", "Strasse", 240),
    HAUSNUMMER("hausnr", "Haus", 50),
    HAUSNUMMER_A("hausnrzusatz", "Haus_a", 50),
    LEVEL("level", "Level", 0),
    KUNDENNUMBER("kundennumber", "kundennumber", 0),
    POSTFACHNUMMER("ortz_07_pf_nr", "Postfach", 75),
    IS_POSTFACH("is_postfach", "Is Postfach", 75),
    PICKPOST("pickpost", "Pickpost", 60),
    ANREDE("geschlecht", "Anrede", 50),
    NIXIE_CODE("nixie_code", "Nixie Code", 50),
    AADR_ID("aadr_id", "Aadr Id", 0),
    KDP_ID("kdp_id", "Kdp_id", 100),
    PERS_08_TYP("type", "Type", 0),
    IS_IGNORE_KUNDENNUMBER("ignore_kundennumber", "Ignore_kundennumber", 0),
    ORT_SET("ort_search", "Ort Set", 100),// is removed on new lookup kdp.
    STRASSE_SET("strasse_search", "Strasse Set", 230),// is removed on new lookup kdp.
    KDP_ALIAS("kdp_synonyms", "KDP Alias", 0),
    KDP_VORNAME_ALIAS("vorname_alias", "KDP Alias", 0),
    KDP_NAME_ALIAS("name_alias", "KDP Alias", 0),
    IS_KDP_ALIAS("is_kdp_alias", "Is KDP Alias", 0),
    ADR_ID("adr_id", "Adr_id", 0),
    MY_POST_24("mypost24", "My Post 24", 75),
    HAUSKEY("hauskey", "Hauskey", 0),
    STREETNUMBER("streetnumber", "StreetNumber", 0),
    IS_SPECIAL("is_special", "Is_Special", 0),
    SRT_COMBINATION("str_combination", "SRT_COMBINATION", 0),
    ORT_COMBINATION("ort_combination", "ORT_COMBINATION", 0),
    SUGGEST_FIRMENNAME("firmenname", "Firmenname", 0),
    SUGGEST_VORNAME("vorname", "Vorname", 0),
    SUGGEST_NAME("name", "Name", 0),
    LOOKUP("lookup", "Lookup", 0),
    SUGGEST_STRASSE("strasse", "Strasse", 0),
    SUGGEST_ORT("ort", "Ort", 0),
    SUGGEST_PLZ("plz", "Plz", 0),
    ALIAS("ALIAS", "ALIAS", 0),
    SUG_PER_09_NAME("pers_09_name", "Pers 09 name", 0),
    SUG_QUANTITY("quantity", "Quantity", 0),
    SUG_PER_09_NAME_SEARCHING("pers_09_name_searching", "Pers 09 name searching", 0),
    SUG_NAME("name", "Table kdp_vornname_autocomplete", 0),
    SUG_ANREDE("anrede_searching", "Anrede", 0),
    SUG_PERS_10_VNAME_NAME("pers_10_vname_name", "Vorname Tab", 0),
    PLZ_PLZ("plz_plz", "plz_plz", 0),
    PLZ_TYP("plz_typ", "plz_typ", 0),
    PLZ_LOGTYP("plz_logtyp", "plz_logtyp", 0);

    private String key;
    private String header;
    private int width;

    LookupKey(String key, String header, int width) {
        this.key = key;
        this.header = header;
        this.width = width;
    }

    public String getKey() {
        return key;
    }

    public String getHeader() {
        return header;
    }

    public int getWidth() {
        return width;
    }

    /**
     * Bug #8807 Table lookup of Firma, Vorname, Name are empty when user press
     * tab or click mini lookup
     */
    // avoid lowercase when compare
    public static LookupKey fromHeader(String header) {
        for (LookupKey e : LookupKey.values()) {
            if (e.header.equals(header)) {
                return e;
            }
        }
        throw new IllegalArgumentException(header);
    }

    /**
     * Bug #8807 Table lookup of Firma, Vorname, Name are empty when user press
     * tab or click mini lookup
     */
    // avoid lowercase when compare
    public static LookupKey fromKey(String key) {
        for (LookupKey e : LookupKey.values()) {
            if (e.key.equals(key)) {
                return e;
            }
        }
        throw new IllegalArgumentException(key);
    }

}
