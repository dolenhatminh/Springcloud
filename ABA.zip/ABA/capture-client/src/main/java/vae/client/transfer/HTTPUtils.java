package vae.client.transfer;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.entity.EntityBuilder;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HTTPUtils {

	private static Logger log = LoggerFactory.getLogger(HTTPUtils.class);
	public static EntityBuilder getEntityBuilder() {
		return EntityBuilder.create();
	}

	public static MultipartEntityBuilder getMultipartEntityBuilder() {
		return MultipartEntityBuilder.create();
	}

	public static HttpResponse doPost(String url, HttpEntity entity, long retryInterval, int retryTimes)
			throws Exception {
		HttpPost httpPost = new HttpPost(url);
		if (entity != null) {
			httpPost.setEntity(entity);
		}

		return doHttpRequest(httpPost, retryInterval, retryTimes);
	}

	public static HttpResponse doPut(String url, HttpEntity entity, long retryInterval, int retryTimes)
			throws Exception {
		HttpPut httpPut = new HttpPut(url);
		if (entity != null) {
			httpPut.setEntity(entity);
		}

		return doHttpRequest(httpPut, retryInterval, retryTimes);
	}
	
	public static HttpResponse doDelete(String url, long retryInterval, int retryTimes)
			throws Exception {
		HttpDelete httpDelete = new HttpDelete(url);
		
		return doHttpRequest(httpDelete, retryInterval, retryTimes);
	}

	public static HttpResponse doHttpRequest(HttpUriRequest request, long retryInterval, int retryTimes)
			throws Exception {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpResponse response = null;
		try {
			for (int i = 1; i <= retryTimes; i++) {
				try {
					response = httpClient.execute(request);
					if (response.getStatusLine().getStatusCode() == 200) {
						return response;
					} else {
						String error = IOUtils.toString(response.getEntity().getContent());
						throw new Exception(error);
					}
				} catch (Exception e) {
					if (i == retryTimes) {
						throw e;
					}
					log.debug("TRANSACTION FAILS, ATTEMPT RETRY");
					Thread.sleep(retryInterval);
				}
			}
		} catch (Exception e) {
			log.debug("ALL ATTEMPT RETRY FAILS");
			throw e;
		} finally {
			httpClient.close();
		}
		return response;
	}
	
	public static String doGET(HttpUriRequest request, long retryInterval, int retryTimes)
			throws Exception {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpResponse response = null;
		try {
			for (int i = 1; i <= retryTimes; i++) {
				try {
					response = httpClient.execute(request);
					if (response.getStatusLine().getStatusCode() == 200) {
						return IOUtils.toString(response.getEntity().getContent(),"UTF-8");
					} else {
						String error = IOUtils.toString(response.getEntity().getContent());
						throw new Exception(error);
					}
				} catch (Exception e) {
					if (i == retryTimes) {
						throw e;
					}
					log.debug("TRANSACTION FAILS, ATTEMPT RETRY");
					Thread.sleep(retryInterval);
				}
			}
		} catch (Exception e) {
			log.debug("ALL ATTEMPT RETRY FAILS");
			throw e;
		} finally {
			httpClient.close();
		}
		return "";
	}
}
