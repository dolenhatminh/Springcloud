package vae.client.sim.service.remote.netty;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.entity.mime.MultipartEntityBuilder;

import vae.bb.core.hibernate.model.Collection;
import vae.client.sim.service.remote.ICollectionRemoteService;
import vae.client.transfer.HTTPUtils;
import vae.client.transfer.JsonUtils;
import vae.netty.IConnection;
import vae.netty.IConnectionHandler;
import vae.netty.client.NettyClient;

import com.sps.vn.config.ApplicationConfig;
import com.sps.vn.utilities.AsciiString;

public class NettyCollectionRemoteService implements ICollectionRemoteService {
	Integer clientID;
	Integer level;
	IConnection conn;
	ClientConnectionHandler clientConnectionHandler = new ClientConnectionHandler();
	NettyClient client;
	String host;
	List<IConnectionHandler> handlers = new ArrayList<IConnectionHandler>();
	
	private NettyCollectionRemoteService() {}
	
	public static NettyCollectionRemoteService instance(){
		return new NettyCollectionRemoteService();
	}

	@Override
	public boolean requestCollection() throws Exception {
		String url = String.format("http://%s:8080/GHP-Proxy/rest/user/register/", host) + clientID + "/" + level;
		HTTPUtils.doPost(url, null, 1000, 1);

		return true;
	}

	@Override
	public boolean returnCapturedCollection(Collection col) throws Exception {
		String url = String.format("http://%s:8080/GHP-Proxy/rest/collection/captured", host);
		MultipartEntityBuilder builder = HTTPUtils.getMultipartEntityBuilder();
		/**
		 * Defects #9932 Value is '?' when input "œ" or "ç"
		 */
		String encoded = AsciiString.encode( JsonUtils.object2Json(col));
		
		builder.addTextBody("data", encoded);
		
		HTTPUtils.doPut(url, builder.build(), 1000, 1);
		clientConnectionHandler.receivedCollection = null;
		
		return true;
	}

	@Override
	public Collection getRequestCollection() throws Exception {
		if(clientConnectionHandler.receivedCollection == null){
			synchronized (clientConnectionHandler) {
				clientConnectionHandler.wait();
			}
		}
		
		return clientConnectionHandler.receivedCollection;
	}

	@Override
	public void start() throws Exception {
		try {
			conn = client.connect();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void stop() throws Exception {
		try {
			conn.close();
		} catch (Throwable e) {
			e.printStackTrace();
		}finally{
			client.shutdown();
		}
	}

	@Override
	public void init(Integer clientID, Integer priority) {
		this.clientID = clientID;
		this.level = priority;
		
		this.host = ApplicationConfig.getInstance().getProxyConfig().getHost();
		
		int port = 0;		
		try {
			port = ApplicationConfig.getInstance().getProxyConfig().getNettyPort();
		} catch (NumberFormatException e) {
			System.out.println(" *** ERROR : Invalid port number :" + ApplicationConfig.getInstance().getProxyConfig().getNettyPort());
		}
		
		client = NettyClient.instance(host, port);
		client.addHandler(clientConnectionHandler);
		client.setClientID(clientID.toString());
	}

	@Override
	public void addHandler(IConnectionHandler handler) {
		client.addHandler(handler);
	}

}
