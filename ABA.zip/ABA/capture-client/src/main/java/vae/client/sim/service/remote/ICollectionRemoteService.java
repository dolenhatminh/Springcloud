package vae.client.sim.service.remote;

import vae.bb.core.hibernate.model.Collection;
import vae.netty.IConnectionHandler;

public interface ICollectionRemoteService {
	boolean requestCollection() throws Exception;
	boolean returnCapturedCollection(Collection col) throws Exception;
	Collection getRequestCollection() throws Exception;
	
	void start() throws Exception;
	void stop() throws Exception;
	void init(Integer clientID, Integer priority);
	void addHandler(IConnectionHandler handler);
}
