package vae.client.sim.service.remote.jms;

import javax.naming.Context;

public class JMSContext {
	public static final String CONNECTION_FACTORY = "CONNECTION_FACTORY";
	public static final String SECURITY_PRINCIPAL = Context.SECURITY_PRINCIPAL;
	public static final String SECURITY_CREDENTIALS = Context.SECURITY_CREDENTIALS;
	public static final String PROVIDER_URL = Context.PROVIDER_URL;
	public static final String INITIAL_CONTEXT_FACTORY = Context.INITIAL_CONTEXT_FACTORY;
	
	public static final String OPERATOR_QUEUE_URL = "OPERATOR_QUEUE_URL";
	public static final String HOST = "HOST";
	public static final String PORT = "PORT";
	
}
