package vae.client.bao;

import com.sps.vn.config.ApplicationConfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.Connection;
import javax.jms.Session;
import javax.naming.Context;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class BAOJmsConsumer {
	@SuppressWarnings("unused")
	private static Logger logger = LoggerFactory
			.getLogger(BAOJmsConsumer.class);
	Context ctx;
	Connection connection;
	Session session;
	int level;
	private String restTime;
	private long delaytime;
	boolean isTest = false;

	public BAOJmsConsumer(int level, Context ctx, Connection connection,
			Session session) throws Exception {
		this.level = level;
		this.ctx = ctx;
		this.connection = connection;
		this.session = session;

		restTime = ApplicationConfig.getInstance().getProxyConfig()
				.getRestServiceTime();
		try {
			delaytime = ApplicationConfig.getInstance().getBusinessConfig()
					.getDelayTryingTime();
		} catch (Exception ex) {
			delaytime = 1000;
		}
	}

	public BAOJmsConsumer(int level) throws Exception {
		this.level = level;
		restTime = ApplicationConfig.getInstance().getProxyConfig()
				.getRestServiceTime();
		try {
			delaytime = ApplicationConfig.getInstance().getBusinessConfig()
					.getDelayTryingTime();
		} catch (Exception ex) {
			delaytime = 1000;
		}
	}

	public String getCurrentTime() throws Exception {
		if (isTest) {
			return System.currentTimeMillis() + "";
		}
		while (true) {
			try {
				URL url = new URL(restTime);
				HttpURLConnection conn = (HttpURLConnection) url
						.openConnection();
				conn.setRequestMethod("PUT");
				InputStream stream = conn.getInputStream();
				BufferedReader br = new BufferedReader(new InputStreamReader(
						stream));
				String line = br.readLine();

				br.close();
				conn.disconnect();
				return line;
			} catch (IOException ex) {
				try {
					System.out.println("get time");
					Thread.sleep(delaytime);
				} catch (Exception e) {
				}
			}
		}
		// return System.currentTimeMillis()+"";
	}

}
