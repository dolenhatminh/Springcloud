package vae.client.transfer;

import vae.bb.core.hibernate.model.Collection;

public interface ITransferService {
	boolean requestCollection() throws Exception;
	boolean returnCapturedCollection(Collection col) throws Exception;
	boolean updateCapturingCollection(Collection col) throws Exception;
	Collection getRequestCollection() throws Exception;
	void close();
	void cancelRequestCard(int userID) throws Exception;
	String getCurrentTime();
	Collection getCollection(int userID)throws Exception;
	void fireEventDisconnection();
	void fireEventDisconnection(Throwable arg1);
}
