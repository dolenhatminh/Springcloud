package vae.client.sim.service.remote;

import java.util.Properties;

import vae.client.sim.service.remote.jms.JMSContext;

public class PropertyInitializer {

	public static Properties properties(String initialContextFactory, String providerUrl, String username,
			String password, String connectionFactory, String operatorQueueUrl, String host, String port) {

		Properties env = new Properties();
		env.put(JMSContext.INITIAL_CONTEXT_FACTORY, initialContextFactory);
		env.put(JMSContext.PROVIDER_URL, providerUrl);
		env.put(JMSContext.SECURITY_PRINCIPAL, username);
		env.put(JMSContext.SECURITY_CREDENTIALS, password);
		env.put(JMSContext.CONNECTION_FACTORY, connectionFactory);
		env.put(JMSContext.OPERATOR_QUEUE_URL, operatorQueueUrl);
		env.put(JMSContext.HOST, host);
		env.put(JMSContext.PORT, port);

		return env;
	}
}
