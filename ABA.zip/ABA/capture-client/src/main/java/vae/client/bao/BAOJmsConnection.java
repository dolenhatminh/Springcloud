package vae.client.bao;

import com.ghp.vae.data_entry.common.Utilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vae.client.transfer.ITransferService;
import vae.client.transfer.TransferService;

import javax.swing.*;
import java.awt.*;


//import vae.client.sim.configuration.Configuration;

public class BAOJmsConnection {

	private static TransferService transferService;
	private static Logger log = LoggerFactory.getLogger(BAOJmsConnection.class);
	boolean isTest =false;
	public BAOJmsConnection(int clientID, String useName) throws Exception{
		if(isTest){
			return;
		}
	}
	
	public static ITransferService createTransferService(int userId, int level, String userName) {
		if(transferService== null){
			try {
				transferService =  new TransferService(userId, level,userName);
			} catch (Throwable e) {
				log.error("", e);
				String mess = "Khong connect duoc nhap du lieu duoc \nThong bao voi quan li du an ngay!\n";
				mess = mess+ Utilities.getStackTrace(e);
				JPanel panel  = new JPanel();
				panel.setLayout(new BorderLayout());
				JTextArea area = new JTextArea(20,60);
				JScrollPane scrollBar = new JScrollPane(area);
				area.setText(mess);
				scrollBar.setSize(300, 200);
				panel.add(scrollBar,BorderLayout.CENTER);
				JOptionPane.showMessageDialog(null, panel, "Canh bao", JOptionPane.ERROR_MESSAGE);
				System.exit(0);
			}finally{
			}
		}
		return transferService;
	}
	public static ITransferService createTransferService() {
		return transferService;
	}
}
