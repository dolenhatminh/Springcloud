package vae.client.transfer;

import java.awt.BorderLayout;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vae.bb.core.hibernate.model.Collection;
import vae.client.bao.BAOJmsConsumer;
import vae.client.sim.service.remote.ICollectionRemoteService;
import vae.client.sim.service.remote.netty.NettyCollectionRemoteService;
import vae.netty.IConnection;
import vae.netty.IConnectionHandler;

import com.ghp.vae.data_entry.bll.BLLoadCard;
import com.ghp.vae.data_entry.common.Utilities;
import com.sps.vn.config.ApplicationConfig;

public class TransferService implements ITransferService {

	private static Logger log = LoggerFactory.getLogger(BLLoadCard.class);

	ICollectionRemoteService remote;
	BAOJmsConsumer jmsConsumer;
	Integer clientID;
	Integer level;
	int retryTimes;
	int delayTime;
	boolean isTest = false;
	boolean isClose = false;

	/**
	 * 
	 * @param clientID
	 * @param level
	 * @param userName
	 * @throws Exception
	 */
	public TransferService(Integer clientID, Integer level, String userName)
			throws Exception {
		this.clientID = clientID;
		this.level = level;
		initService(level, userName);

		// jmsConnection = BAOJmsConnection.instance(clientID, userName);
		jmsConsumer = new BAOJmsConsumer(level);
		try {
			delayTime = ApplicationConfig.getInstance().getBusinessConfig().getDelayTryingTime();
		} catch (Exception ex) {
			delayTime = 1000;
		}
		try {
			retryTimes = ApplicationConfig.getInstance().getProxyConfig().getRetryTimes();
			if (retryTimes < 1) {
				retryTimes = 1;
			}

		} catch (Exception ex) {
			retryTimes = 3;
		}

	}

	private void initService(Integer level, String userName) throws Exception {		
		remote = NettyCollectionRemoteService.instance();
		remote.init(clientID, level);
		ConnectionServiceHandler handler = new ConnectionServiceHandler();
		handler.setTransferService(this);
		remote.addHandler(handler);
		remote.start();
	}

	@Override
	public boolean requestCollection() throws Exception {
		if (isTest) {
			return true;
		}
		return remote.requestCollection();
	}

	@Override
	public boolean returnCapturedCollection(Collection col) throws Exception {
		if (isTest) {
			return true;
		}
		return remote.returnCapturedCollection(col);
	}

	/**
	 * not use :return true
	 */
	@Deprecated
	@Override
	public boolean updateCapturingCollection(Collection col) throws Exception {
		return true;
	}

	@Deprecated
	@Override
	public Collection getRequestCollection() throws Exception {
		return null;
	}

	@Override
	public void close() {
		try {
			isClose = true;
			remote.stop();
		} catch (Exception ex) {
			log.error("", ex);
		}
		// if (jmsConnection.getConnection() != null) {
		// try {
		// jmsConnection.getConnection().close();
		// } catch (JMSException e) {
		// log.error("", e);
		// }
		// }
	}

	public BAOJmsConsumer getJmsConnection() {
		return jmsConsumer;
	}

	@Deprecated
	public void cancelRequestCard(int userID) throws Exception {
		//
		return;
		// String url =
		// String.format(ConfigInfo.getProperties().getProperty("CANCEL_CAPTURING_COLLECTION"),
		// ConfigInfo.getProperties().getProperty("IP_ADDRESS")) + userID;
		// HTTPUtils.doDelete(url, delayTime, retryTimes);
	}

	public String getCurrentTime() {
		try {
			return jmsConsumer.getCurrentTime();
		} catch (Exception e) {
			log.error("", e);
		}
		return "";
	}

	public Collection getCollection(int userID) throws Exception {
		return remote.getRequestCollection();
		// return jmsConsumer.getCollection(userID);
	}

	private class ConnectionServiceHandler implements IConnectionHandler {

		ITransferService transferService;

		public ConnectionServiceHandler() {
		}

		public void setTransferService(ITransferService transferService) {
			this.transferService = transferService;
		}

		@Override
		public void onConnected(IConnection arg0) {
		}

		@Override
		public void onDisconnected(IConnection arg0) {
			transferService.fireEventDisconnection();
		}

		@Override
		public void onException(IConnection arg0, Throwable arg1) {
			transferService.fireEventDisconnection(arg1);
		}

		@Override
		public void onMessage(IConnection arg0, Object arg1) {

		}

	}

	@Override
	public void fireEventDisconnection() {
		if (isClose)
			return;
		String mess = "Khong connect duoc\nThong bao voi quan li du an ngay!\n";
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		JTextArea area = new JTextArea(20, 60);
		JScrollPane scrollBar = new JScrollPane(area);
		area.setText(mess);
		scrollBar.setSize(300, 200);
		panel.add(scrollBar, BorderLayout.CENTER);
		JOptionPane.showMessageDialog(null, panel, "Canh bao",
				JOptionPane.ERROR_MESSAGE);
		System.exit(0);

	}

	@Override
	public void fireEventDisconnection(Throwable ex) {
		if (isClose)
			return;
		String mess = "Khong connect duoc\nThong bao voi quan li du an ngay!\n";
		mess = mess + " error";
		mess = mess + Utilities.getStackTrace(ex);
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		JTextArea area = new JTextArea(20, 60);
		JScrollPane scrollBar = new JScrollPane(area);
		area.setText(mess);
		scrollBar.setSize(300, 200);
		panel.add(scrollBar, BorderLayout.CENTER);
		JOptionPane.showMessageDialog(null, panel, "Canh bao",
				JOptionPane.ERROR_MESSAGE);
		System.exit(0);
	}
}
