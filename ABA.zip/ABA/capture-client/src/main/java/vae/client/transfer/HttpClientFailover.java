package vae.client.transfer;

import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.config.SocketConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*import httpfailover.FailoverHttpClient;*/

public class HttpClientFailover {
	private static Logger log = LoggerFactory.getLogger(HttpClientFailover.class);

	public String doGET(HttpUriRequest request, List<HttpHost> targets, long retryInterval, int retryTimes,
			int socketTimeout, int connectionTimeout) throws Exception {

		if (targets.isEmpty()) {
			throw new IllegalArgumentException("Targets parameter may not be null or empty");
		}

		if (retryTimes < 1) {
			retryTimes = 1;
		}

		final RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(connectionTimeout).build();
		final SocketConfig socketConfig = SocketConfig.custom().setSoTimeout(socketTimeout).build();

		final CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig)
				.setDefaultSocketConfig(socketConfig).build();

		HttpResponse response = null;

		final StringBuilder errorMessage = new StringBuilder();

		for (int i = 0; i < retryTimes; i++) {
			for (final HttpHost host : targets) {
				try {
					response = httpClient.execute(host, request);

					if (response.getStatusLine().getStatusCode() == 200) {
						final String result = IOUtils.toString(response.getEntity().getContent(), "UTF-8");
						httpClient.close();
						return result;
					} else {
						errorMessage.append(host).append(": ");
						errorMessage.append(response.getStatusLine().getReasonPhrase()).append("\n");
						log.error(request + " " + response.getStatusLine().getReasonPhrase());
					}
				} catch (final Exception e) {
					errorMessage.append(host.getHostName()).append(": ");
					errorMessage.append(e.getMessage()).append("\n");
					if ((targets.indexOf(host) == targets.size() - 1) && (i >= retryTimes - 1)) {
						httpClient.close();
						throw new Exception(errorMessage.toString());
					}
					log.error(e.getMessage());
				}
			}
			Thread.sleep(retryInterval);
		}

		httpClient.close();
		return "";
	}

	public String doGET(HttpUriRequest request, List<HttpHost> targets, long retryInterval, int retryTimes)
			throws Exception {

		if (targets.isEmpty()) {
			throw new IllegalArgumentException("Targets parameter may not be null or empty");
		}

		if (retryTimes < 1) {
			retryTimes = 1;
		}

		final RequestConfig requestConfig = RequestConfig.DEFAULT;
		final SocketConfig socketConfig = SocketConfig.DEFAULT;

		final CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig)
				.setDefaultSocketConfig(socketConfig).build();

		HttpResponse response = null;

		final StringBuilder errorMessage = new StringBuilder();

		for (int i = 0; i < retryTimes; i++) {
			for (final HttpHost host : targets) {
				try {
					response = httpClient.execute(host, request);

					if (response.getStatusLine().getStatusCode() == 200) {
						final String result = IOUtils.toString(response.getEntity().getContent(), "UTF-8");
						httpClient.close();
						return result;
					} else {
						errorMessage.append(host).append(": ");
						errorMessage.append(response.getStatusLine().getReasonPhrase()).append("\n");
						log.error(request + " " + response.getStatusLine().getReasonPhrase());
					}
				} catch (final Exception e) {
					errorMessage.append(host.getHostName()).append(": ");
					errorMessage.append(e.getMessage()).append("\n");
					if ((targets.indexOf(host) == targets.size() - 1) && (i >= retryTimes - 1)) {
						httpClient.close();
						throw new Exception(errorMessage.toString());
					}
					log.error(e.getMessage());
				}
			}
			Thread.sleep(retryInterval);
		}

		httpClient.close();
		return "";
	}

	/*public String execute(HttpUriRequest request, List<HttpHost> targets, long retryInterval, int retryTimes)
			throws Exception {

		HttpResponse response = null;
		final FailoverHttpClient failoverHttpClient = new FailoverHttpClient();
		try {
			for (int i = 1; i <= retryTimes; i++) {
				try {
					response = failoverHttpClient.execute(targets, request);
					if (response.getStatusLine().getStatusCode() == 200) {
						return IOUtils.toString(response.getEntity().getContent(), "UTF-8");
					} else {
						final String error = IOUtils.toString(response.getEntity().getContent());
						throw new Exception(error);
					}
				} catch (final Exception e) {
					if (i == retryTimes) {
						throw e;
					}
					Thread.sleep(retryInterval);
				}
			}
		} catch (final Exception e) {
			throw e;
		} finally {

		}
		return "";
	}*/

	// create a client instance
	// private FailoverHttpClient failoverHttpClient;

	// the list of hosts
	List<HttpHost> hosts;

	static HttpClientFailover httpClientFailover;

	private HttpClientFailover() {
	}

	public static HttpClientFailover intance() {
		if (httpClientFailover == null) {
			httpClientFailover = new HttpClientFailover();
		}
		return httpClientFailover;
	}

}
