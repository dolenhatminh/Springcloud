package vae_ocr.test;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import vae_ocr.OCR.OCRProcessing;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lqbinh
 */
public class TestOCR {
    
    ClassLoader classLoader = getClass().getClassLoader();
    private String imagePath = classLoader.getResource("test.tif").getFile();

    public String getImagePath() {
        return imagePath;
    }    
    
    public static void main(String[] args) throws Exception {
        OCRProcessing ocr = new OCRProcessing();

        TestOCR test = new TestOCR();
        
        File file = new File(test.getImagePath());

        InputStream inputStream = null;
        byte[] bFile = new byte[(int) file.length()];
        try {
            //convert file into array of bytes
            inputStream = new FileInputStream(file);
            inputStream.read(bFile);
            inputStream.close();

            System.out.println("Done");
        } catch (Exception e) {
            e.printStackTrace();
        }

        ocr.doOCRArray(read(file), "", "", "");
    }

    public static byte[] read(File file) throws IOException {

        ByteArrayOutputStream ous = null;
        InputStream ios = null;
        try {
            byte[] buffer = new byte[4096];
            ous = new ByteArrayOutputStream();
            ios = new FileInputStream(file);
            int read = 0;
            while ((read = ios.read(buffer)) != -1) {
                ous.write(buffer, 0, read);
            }
        } finally {
            try {
                if (ous != null) {
                    ous.close();
                }
            } catch (IOException e) {
            }

            try {
                if (ios != null) {
                    ios.close();
                }
            } catch (IOException e) {
            }
        }
        return ous.toByteArray();
    }
}
