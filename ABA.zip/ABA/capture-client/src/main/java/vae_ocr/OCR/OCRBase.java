/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vae_ocr.OCR;

import java.util.List;

import org.apache.commons.lang.WordUtils;

import com.sps.vn.lookup.datasource.DALLookup;

/**
 *
 * @author lqbinh
 */
public class OCRBase {

    protected String language = "";
    protected String option = "";
    protected String anrede = "";
    protected String keyword = "";
    protected String plz = "";
    protected String ort = "";
    protected String strasse = "";
    protected String hausnummer = "";
    protected String postfach = "";
    protected boolean canDoKDP = false;
    protected DALLookup dalLK;
    protected int specialCaseAll = 0;
    protected boolean matchKeyword = false;
    protected boolean matchStrasse = false;
    protected boolean matchPLZ = false;
    protected boolean matchORT = false;
    protected boolean hasAnrede = false;
    protected boolean hasPLZ = false;
    protected int indexOfKeyWord = -1;
    protected boolean hasFirma = false;
    protected String fullOCR = "";
    protected long duration;
    protected String name = "";
    protected String vorname = "";
    protected String firmaname = "";
    protected String nameZusat = "";
    protected String pickpost ="";
    protected String mypost24 ="";
    protected int pers_typ = 0;
    protected int indexLast = 0;
    protected int indexStrasse = 0;
    protected String ERROR_IMAGE_SIZE_EXCEED = "ERROR_IMAGE_SIZE_EXCEED";
    protected String ERROR_SERVER_OVERLOAD = "ERROR_SERVER_OVERLOAD";
    protected String ERROR_TRANSYM_OCR_ENGINE = "ERROR_TRANSYM_OCR_ENGINE";
    protected String ERROR_OTHER = "ERROR_OTHER";
    protected String FOR_CHECK = "";
    protected boolean error = false;

    public String getPickpost() {
        return pickpost;
    }

    public void setPickpost(String pickpost) {
        this.pickpost = pickpost;
    }

    public String getMypost24() {
        return mypost24;
    }

    public void setMypost24(String mypost24) {
        this.mypost24 = mypost24;
    }
    
    public void setOption(String option) {
        this.option = option;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public int getSpecialCaseAll() {
        return specialCaseAll;
    }

    public void setFullOCR(String fullOCR) {
        this.fullOCR = WordUtils.capitalizeFully(fullOCR);
    }

    public boolean isError(){
        return error;
    }
    
    public String getPostfach() {
        return postfach;
    }

    public void setPostfach(String postfach) {
        this.postfach = postfach;
    }

    public void setFullOcr(String fullOcr) {
        this.fullOCR = fullOcr;
    }
    
    public void setHausnummer(String hausnummer) {
        this.hausnummer = hausnummer;
    }
    
    public String getNameZusat() {
        return nameZusat;
    }

    public void setNameZusat(String nameZusat) {
        this.nameZusat = nameZusat;
    }

    public String getFirmaname() {
        return firmaname;
    }

    public void setFirmaname(String firmaname) {
        this.firmaname = WordUtils.capitalizeFully(firmaname);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = WordUtils.capitalizeFully(name);
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = WordUtils.capitalizeFully(vorname);
    }

    public String getFullOCR() {
        return fullOCR;
    }

    public boolean isHasFirma() {
        return hasFirma;
    }

    public boolean isMatchKeyword() {
        return matchKeyword;
    }

    public boolean isMatchORT() {
        return matchORT;
    }

    public boolean isMatchPLZ() {
        return matchPLZ;
    }

    public boolean isMatchStrasse() {
        return matchStrasse;
    }

    public boolean isHasAnrede() {
        return hasAnrede;
    }

    public boolean isHasPLZ() {
        return hasPLZ;
    }

    public int getIndexOfKeyWord() {
        return indexOfKeyWord;
    }

    public String getAnrede() {
        return anrede;
    }

    public boolean isCanDoKDP() {
        canDoKDP = matchKeyword && matchORT && matchPLZ;
        return canDoKDP;
    }

    public String getHausnummer() {
        return hausnummer;
    }

    public String getHausnummer(String strHause) {
        if (strHause.equals("")) {
            return this.hausnummer;
        }

        return strHause;
    }

    public String getKeyword() {
        return keyword;
    }

    public String getOrt() {
        return ort;
    }

    public String getPlz() {
        return plz;
    }

    public String getStrasse() {
        return strasse;
    }

    public String getOrt(String strOrt) {
        if (strOrt.equals("")) {
            return ort;
        }
        return strOrt;
    }

    public String getPlz(String strPlz) {
        if (strPlz.equals("")) {
            return plz;
        }
        return strPlz;
    }

    public String getStrasse(String strStrasse) {
        if (strStrasse.equals("")) {
            return strasse;
        }
        return strStrasse;
    }

    public enum OCR_TOOLTIP {

        OTHER, STRASSE, ANREDE, NAMENSZUSATZ, FIRMENNAME,
        VORNAME, NAME, PLZ, ORT, HAUSNUMMER,
        POSTFACHNUMMER, STOCKWERK, ADRESSZUSATZ,
        CO_ADDRESSE, PICKPOSTNUMMER, LOOKUP;

        public static OCR_TOOLTIP value(String field) {
            if (field.equalsIgnoreCase("strasse")) {
                return STRASSE;
            }
            if (field.equalsIgnoreCase("anrede")) {
                return ANREDE;
            }
            if (field.equalsIgnoreCase("namenszusatz")) {
                return NAMENSZUSATZ;
            }
            if (field.equalsIgnoreCase("firmenname")) {
                return FIRMENNAME;
            }
            if (field.equalsIgnoreCase("vorname")) {
                return VORNAME;
            }
            if (field.equalsIgnoreCase("name")) {
                return NAME;
            }
            if (field.equalsIgnoreCase("plz")) {
                return PLZ;
            }
            if (field.equalsIgnoreCase("ort")) {
                return ORT;
            }
            if (field.equalsIgnoreCase("hausnummer")) {
                return HAUSNUMMER;
            }

            if (field.equalsIgnoreCase("postfachnummer")) {
                return POSTFACHNUMMER;
            }
            if (field.equalsIgnoreCase("stockwerk")) {
                return STOCKWERK;
            }
            if (field.equalsIgnoreCase("adresszusatz")) {
                return ADRESSZUSATZ;
            }
            if (field.equalsIgnoreCase("co_addresse")) {
                return CO_ADDRESSE;
            }
            if (field.equalsIgnoreCase("pickpostnummer")) {
                return PICKPOSTNUMMER;
            }
            if (field.equalsIgnoreCase("lookup")) {
                return LOOKUP;
            }

            return OTHER;

        }
    ;
};

}
