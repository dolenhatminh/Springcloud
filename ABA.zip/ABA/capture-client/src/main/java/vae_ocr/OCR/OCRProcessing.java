/*
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work All use, disclosure, and/or reproduction of this material
 * is prohibited Rights in this program belong to: Swiss Post Solution Vietnam. Floor 4-5-8, ICT Tower, Quang Trung
 * Software City
 */
package vae_ocr.OCR;

import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import org.apache.commons.lang.WordUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sps.vn.config.ApplicationConfig;
import com.sps.vn.lookup.datasource.DALLookup;

import sps.vn.ocr.client.builder.OcrModelBuilder;
import sps.vn.ocr.client.builder.OcrParas;
import sps.vn.ocr.client.impl.OcrClient;
import sps.vn.ocr.client.impl.OcrClientImpl;
import sps.vn.ocr.client.model.OcrClientModel;
import sps.vn.ocr.client.utils.OcrClientUtils;

/**
 * The Class OCRProcessing.
 */
public class OCRProcessing extends OCRBase {

	/**
	 * The Constant CHAR_EMPTY.
	 */
	private static final String CHAR_EMPTY = "";

	/**
	 * The Constant CHAR_LINE_SEPARATOR.
	 */
	private static final String CHAR_LINE_SEPARATOR = "\n";

	/**
	 * The Constant CHAR_PERCENTAGE.
	 */
	private static final String CHAR_PERCENTAGE = "%";

	/**
	 * The Constant CHAR_WHITE_SPACE.
	 */
	private static final String CHAR_WHITE_SPACE = " ";

	/**
	 * The Constant LOG.
	 */
	private static final Logger LOG = LoggerFactory.getLogger(OCRProcessing.class);

	/**
	 * The client.
	 */
	private OcrClient client = null;

	/**
	 * The known anredes.
	 */
	private String[] knownAnredes;

	/**
	 * The known pickposts.
	 */
	private String[] knownPickposts;

	/**
	 * The known mypost24.
	 */
	private String[] knownMypost24s;

	/**
	 * The known postfatches.
	 */
	private String[] knownPostfatches;

	/**
	 * The known postlagernds.
	 */
	private String[] knownPostlagernds;

	/**
	 * The known strasses.
	 */
	private String[] knownStrasses;

	/**
	 * The special addresses.
	 */
	private String[] specialAddresses;

	/**
	 * The stop words.
	 */
	private String[] stopWords;

	/**
	 * Instantiates a new OCR processing.
	 *
	 * @throws Exception
	 *             the exception
	 */
	public OCRProcessing() throws Exception {
		this.dalLK = new DALLookup();
		this.initOCR();
		this.init();
	}

	/**
	 * Check has strasse.
	 *
	 * @param string
	 *            the line
	 * @return true, if successful
	 */
	private boolean checkHasStrasse(final String string) {
		boolean ret = false;

		final String translatedString = this.dalLK.translateASCII(string);
		if (translatedString != null) {
			for (final String strasse : this.knownStrasses) {
				if (Util.checkMatchWord(translatedString, strasse)) {
					ret = true;
					break;
				}
			}
		}

		return ret;
	}

	/**
	 * check keyword is matched with DB.
	 */
	private void checkKeywordMatchKDP() {
		try {
			LOG.debug("Extract KDP phrases from [" + this.keyword + "]");
			this.keyword = this.dalLK.checkKeywordExist(this.keyword);
			if (!this.keyword.isEmpty()) {
				LOG.debug("Found the keyword: [" + this.keyword + "]");
				this.matchKeyword = true;
				this.checkTypOfKeyword();
			} else {
				LOG.debug("No, it 's not a valid keyword, omit it!");
				this.matchKeyword = false;
			}
		} catch (final Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * check ort from customer's OCR is existed in OCR result.
	 *
	 * @param ort
	 *            the ort
	 * @return true if ort is exist
	 */
	private void checkORTExist(final String ort) {
		if (ort.isEmpty()) {
			return;
		}
		this.setOrt(ort);
	}

	/**
	 * check plz from customer's OCR is existed in OCR result.
	 *
	 * @param plz
	 *            the plz
	 * @return true if plz is exist
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	private void checkPLZExist(final String plz) throws InterruptedException {
		if (plz.isEmpty()) {
			return;
		}
		this.setPlz(plz);
		this.hasPLZ = true;
	}

	/**
	 * Check plz only.
	 *
	 * @author lthieu
	 * @param in
	 *            the in
	 * @return true if plz
	 * @description check if string is only plz
	 */
	private boolean checkPLZOnly(final String in) {
		return Pattern.matches("\\d{4}", in);
	}

	/**
	 * Get kundernummer from OCr text of pickpost and mypost24
	 *
	 * @param rawText
	 * @param kwdType
	 * @return kundenummber
	 */
	private String getKundenummer(final String rawText, final String kwdType) {
		final String replacement = "####";
		final String[] values = rawText.replaceAll(String.format("(?i)(%s)", kwdType), replacement).split(replacement);
		return values.length == 0 ? "X" : values[values.length - 1].toUpperCase();
	}

	/**
	 * Check special case.
	 *
	 * @author lthieu
	 * @param in
	 *            : String to check special case
	 * @return <br>
	 *         return 0: normal <br>
	 *         return 1: postfach <br>
	 *         return 2: post lagend <br>
	 *         return 3: pick post <br>
	 *         return 4 mititary <br>
	 *         return 5 foreign; <br>
	 *         return 6 strasseAddress <br>
	 *         return 7 mypost24
	 * @description: check if special case in string
	 */
	private int checkSpecialCase(final String in) {
		LOG.debug("Checking the some special caseses...");
		final String lines[] = in.split(CHAR_LINE_SEPARATOR);

		LOG.debug("Check mypost24");
		for (final String mypost24 : this.knownMypost24s) {
			for (final String line : lines) {
				if (line.trim().isEmpty()) {
					continue;
				}
				if (Util.checkMatchWord(line.trim(), mypost24)) {
					this.mypost24 = this.getKundenummer(line, mypost24);
					LOG.debug("Check MYPOST24 :{}", this.mypost24);
					return 7;
				}
			}
		}
		LOG.debug("Check pickpost");
		for (final String pp : this.knownPickposts) {
			for (final String line : lines) {
				if (line.trim().isEmpty()) {
					continue;
				}
				if (Util.checkMatchWord(line.trim(), pp)) {
					this.pickpost = this.getKundenummer(line, pp);
					LOG.debug("Check PICKPOST :{}", this.pickpost);
					return 3;
				}
			}
		}

		LOG.debug("Check post lagernd");
		for (final String pl : this.knownPostlagernds) {
			for (final String line : lines) {
				if (line.trim().isEmpty()) {
					continue;
				}
				if (Util.checkMatchWord(line.trim(), pl)) {
					return 2;
				}
			}
		}
		LOG.debug("Check postfatch");
		for (final String pf : this.knownPostfatches) {
			for (final String line : lines) {
				if (line.trim().isEmpty()) {
					continue;
				}
				if (Util.checkMatchWord(line.trim(), pf)) {
					final Pattern p = Pattern.compile("\\d+");
					final Matcher m = p.matcher(line);
					if (m.find()) {
						this.postfach = m.group();
					}
					return 1;
				}
			}
		}
		LOG.debug("Check special address");
		for (final String addSpec : this.specialAddresses) {
			for (final String line : lines) {
				if (line.trim().isEmpty()) {
					continue;
				}
				if (Util.checkMatchWord(line.trim(), addSpec)) {
					return 4;
				}
			}
		}

		return 0;
	}

	/**
	 * check strasse from customer's OCR is existed in OCR result.
	 *
	 * @param strasse
	 *            the strasse
	 * @return true if strasse is exist
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	private void checkStrasseExist(final String strasse) throws InterruptedException {
		if (strasse.isEmpty()) {
			return;
		}
		this.setStrasse(strasse);
	}

	/**
	 * Check typ of keyword.
	 */
	private void checkTypOfKeyword() {
		try {
			LOG.debug("Check the type of keyword");
			final String[] lines = this.fullOCR.split(CHAR_LINE_SEPARATOR);
			if (this.pers_typ == 1) {
				final String keyString = lines[this.indexOfKeyWord].toUpperCase().replace(this.anrede.toUpperCase(),
						CHAR_EMPTY);
				final String[] keys = keyString.split(CHAR_WHITE_SPACE);
				if (keys.length > 1) {
					this.setVorname(keys[0]);
					this.setName(keys[1]);

				}
			} else if (this.pers_typ == 2) {
				this.setFirmaname(lines[this.indexOfKeyWord]);
			} else if (this.vorname.isEmpty() && this.name.isEmpty() && this.firmaname.isEmpty()) {
				if (this.dalLK.checkTypOfkeyword(this.keyword.split(CHAR_WHITE_SPACE)[0]) > 0) {
					final String keyString = this.removeFistNumberString(this.fullOCR).trim()
							.split(CHAR_LINE_SEPARATOR)[this.indexOfKeyWord];
					final String[] keys = keyString.split(CHAR_WHITE_SPACE);
					if (keys.length > 1) {
						this.setVorname(keys[0]);
						this.setName(keys[1]);
					}
				} else {
					this.setFirmaname(this.removeFistNumberString(this.fullOCR).trim()
							.split(CHAR_LINE_SEPARATOR)[this.indexOfKeyWord]);
				}
			}
			LOG.debug("Keyword's type is [" + this.pers_typ + "]");
		} catch (final Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * Do ocr array.
	 *
	 * @param image
	 *            the image
	 * @param strasse
	 *            the strasse
	 * @param plz
	 *            the plz
	 * @param ort
	 *            the ort
	 * @throws Exception
	 *             the exception
	 */
	public void doOCRArray(final byte[] image, final String strasse, final String plz, final String ort)
			throws Exception {
		try {
			this.resetOCRData();

			this.duration = new Date().getTime();
			final String content = this.getContent(image);

			final String json = this.client.doOcr(content);

			final String result = this.json2Result(json);

			if (result.startsWith(this.ERROR_IMAGE_SIZE_EXCEED)) {
				this.setFullOCR(result);
				this.error = true;
				throw new Exception(result);
			}
			if (result.startsWith(this.ERROR_SERVER_OVERLOAD)) {
				this.setFullOCR("vui long quet OCR lan nua \n hoac tra tay");
				this.error = true;
				throw new Exception(result);
			}
			if (result.startsWith(this.ERROR_TRANSYM_OCR_ENGINE)) {
				JOptionPane.showMessageDialog(null, result);
				this.error = true;
				throw new Exception(result);
			}
			if (result.startsWith(this.ERROR_OTHER)) {
				JOptionPane.showMessageDialog(null, result);
				this.error = true;
				throw new Exception(result);
			}

			this.setFullOCR(result);
			this.duration = new Date().getTime() - this.duration;
			this.error = false;
			LOG.info(" >> OCR Result << : " + json);
			this.processResultOCR(this.fullOCR, strasse, plz, ort);
			LOG.debug("#############{}", this.getSpecialCaseAll());
			LOG.info(" >> OCR Result << :" + this.fullOCR);
		} catch (final Exception ex) {
			throw ex;
		}
	}

	/**
	 * Gets the content.
	 *
	 * @param image
	 *            the image
	 * @return the content
	 * @throws Exception
	 *             the exception
	 */
	private String getContent(final byte[] image) throws Exception {
		try {
			final String base64 = OcrClientUtils.convertImageBase64ByteArrayToString(image);

			final OcrClientModel ocrClientModel = new OcrModelBuilder.Custom()
					.add(OcrParas.OCRTYPE.value(), ApplicationConfig.getInstance().getOcrConfig().getType())
					.add(OcrParas.IMAGE.value(), base64).add(OcrParas.IMAGEURL.value(), CHAR_EMPTY)
					.add(OcrParas.IMAGETYPE.value(), ApplicationConfig.getInstance().getOcrConfig().getImageType())
					.add(OcrParas.PROJECTNAME.value(), ApplicationConfig.getInstance().getOcrConfig().getProjectName())
					.add(OcrParas.DESKEW.value(), ApplicationConfig.getInstance().getOcrConfig().isDeskew())
					.add(OcrParas.LANGUAGE.value(), ApplicationConfig.getInstance().getOcrConfig().getLanguage())
					.add(OcrParas.TIMEOUT.value(), ApplicationConfig.getInstance().getOcrConfig().getServerTimeout())
					.add(OcrParas.ACCEPTFIRSTRESULT.value(),
							ApplicationConfig.getInstance().getOcrConfig().isAcceptFirstResult())
					.add(OcrParas.INCLUDECHARACTERRESULT.value(),
							ApplicationConfig.getInstance().getOcrConfig().isIncludeCharacterResult())
					.add(OcrParas.PATTERN.value(), ApplicationConfig.getInstance().getOcrConfig().getPattern())
					.add(OcrParas.PRIORITY.value(), ApplicationConfig.getInstance().getOcrConfig().getPriority())
					.build();

			final String content = ocrClientModel.covertToOcrStringContent();

			if (LOG.isDebugEnabled()) {
				final JSONObject debug = new JSONObject(ocrClientModel.toString());
				debug.remove("image");
				LOG.debug("Params :" + debug.toString());
			}

			return content;
		} catch (final Exception e) {
			LOG.error(CHAR_EMPTY, e);
			throw e;
		}
	}

	/**
	 * Gets the key word relate to anrede.
	 *
	 * @author lthieu
	 * @param in
	 *            the in
	 * @return remain string without anrede
	 * @description: check and remove anrede
	 */
	private String getKeyWordRelateToAnrede(final String in) {
		this.hasAnrede = false;
		String result = CHAR_EMPTY;
		for (final String anrede : this.knownAnredes) {
			if (in.toLowerCase().contains(anrede.toString())) {
				this.hasAnrede = true;
				result = in.toLowerCase().replace(anrede.toString().toLowerCase(), CHAR_EMPTY).trim();
				break;
			}
		}
		if (!this.hasAnrede) {
			result = in.trim();
		}
		return result;
	}

	/**
	 * Gets the tool tip.
	 *
	 * @param input
	 *            the input
	 * @param field
	 *            the field
	 * @return the tool tip
	 */
	public String getToolTip(final String input, final OCR_TOOLTIP field) {
		switch (field) {
		case OTHER:
			return Util.getToolTip(input, this.fullOCR);
		case PLZ:
			return this.getPlz();
		case ORT:
			return this.returnField(input, this.getOrt());
		case STRASSE:
			return this.returnField(input, this.getStrasse());
		case ANREDE:
			return this.returnField(input, this.getAnrede());
		case HAUSNUMMER:
			return this.returnField(input, this.getHausnummer());
		case NAMENSZUSATZ:
			return this.returnField(input, this.getNameZusat());
		case NAME:
			return this.returnField(input, this.getName());
		case VORNAME:
			return this.returnField(input, this.getVorname());
		case FIRMENNAME:
			return this.returnField(input, this.getFirmaname());
		case LOOKUP:
			return CHAR_EMPTY;
		default:
			return Util.getToolTip(input, this.fullOCR);
		}
	}

	/**
	 * Initialize.
	 */
	private void init() {
		this.knownAnredes = ApplicationConfig.getInstance().getOcrPostProcessingConfiguration().getKnownAnredes();
		this.knownPickposts = ApplicationConfig.getInstance().getOcrPostProcessingConfiguration().getKnownPickposts();
		this.knownMypost24s = ApplicationConfig.getInstance().getOcrPostProcessingConfiguration().getKnownMypost24s();
		this.knownPostfatches = ApplicationConfig.getInstance().getOcrPostProcessingConfiguration()
				.getKnownPostfatches();
		this.knownPostlagernds = ApplicationConfig.getInstance().getOcrPostProcessingConfiguration()
				.getKnownPostlagernds();
		this.knownStrasses = ApplicationConfig.getInstance().getOcrPostProcessingConfiguration().getKnownStrasses();
		this.specialAddresses = ApplicationConfig.getInstance().getOcrPostProcessingConfiguration()
				.getSpecialAddresses();
		this.stopWords = ApplicationConfig.getInstance().getOcrPostProcessingConfiguration().getStopWords();
	}

	/**
	 * Initialize ocr.
	 *
	 * @throws Exception
	 *             the exception
	 */
	public void initOCR() throws Exception {
		try {
			final Properties properties = ApplicationConfig.getInstance().getOcrConfig().toProperties();
			this.client = OcrClientImpl.initOcrClient(properties);
			this.FOR_CHECK = ApplicationConfig.getInstance().getOcrConfig().getForCheck();
		} catch (final Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}

	/**
	 * Json2 result.
	 *
	 * @param json
	 *            the json
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	private String json2Result(final String json) throws Exception {
		try {
			final JSONArray jsonArray = new JSONArray(json);
			if (jsonArray.length() == 0) {
				return CHAR_EMPTY;
			}
			return jsonArray.getJSONObject(0).get("result").toString();

		} catch (final Exception e) {
			LOG.error(CHAR_EMPTY, e);
			throw e;
		}
	}

	/**
	 * Process general case.
	 *
	 * @param in
	 *            the in
	 * @param plz
	 *            the plz
	 * @param ort
	 *            the ort
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	private void processGeneralCase(String in, final String plz, final String ort) throws InterruptedException {
		LOG.debug("start process keyword");
		in = this.processKeywordGeneral(in);
		LOG.debug("Start process plzort");
		in = this.processPLZORTGeneral(this.fullOCR);
		LOG.debug("Start process hausnummer");
		this.processHausNummer(in);
		LOG.debug("Start process strasse");
		this.processStrasseGeneral(this.fullOCR);
		LOG.debug("Start process name zusat");
		this.processZusat(this.fullOCR);
	}

	/**
	 * Process haus nummer.
	 *
	 * @author lthieu
	 * @param in
	 *            : String to process
	 * @return <br>
	 *         result = 0: has strasse and hausnummer <br>
	 *         result = 1: has strasse
	 * @description separate hausnummer and strasse
	 */
	private int processHausNummer(final String in) {
		this.strasse = CHAR_EMPTY;
		this.hausnummer = CHAR_EMPTY;
		int result = 1;
		final String[] res = in.split(CHAR_LINE_SEPARATOR);
		try {
			for (final String str : res) {
				final Pattern p = Pattern.compile("\\d+");
				final Matcher m = p.matcher(str);
				if (m.find()) {
					final int index = m.start();
					int contain = str.indexOf(CHAR_WHITE_SPACE, index);
					if (contain < 0) {
						contain = str.indexOf(CHAR_LINE_SEPARATOR, index);
					}
					if (contain > 0) {
						this.hausnummer = str.substring(index, contain);
					} else {
						this.hausnummer = str.substring(index);
					}
					result = 0;
					break;
				}
			}
		} catch (final Exception ex) {
			ex.printStackTrace();
		}
		return result;
	}

	/**
	 * Process keyword general.<br>
	 * Inspect for keyword used for lookup:<br>
	 * The phrase is a keyword when it matches one of the following criterion:<br>
	 * <ul>
	 * <li>The phrase must be a KDP full name.</li>
	 * </ul>
	 * The pers_typ is one of following value:<br>
	 * <ul>
	 * <li>0: Invalid, and it try to find out the keyword</li>
	 * <li>1: Person</li>
	 * <li>2: Firma</li>
	 * </ul>
	 *
	 * @param value
	 *            the value
	 * @return the string
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	private String processKeywordGeneral(final String value) throws InterruptedException {
		String string = value;
		this.hasFirma = false;

		final String[] lines = string.split(CHAR_LINE_SEPARATOR);
		if (lines.length > 0) {
			LOG.debug("Inspect for keyword for lookup");
			int lineNumber = 0;
			String lineString = lines[lineNumber];
			lineString = this.removeStopWords(lineString);
			if (!string.isEmpty() && (lines.length > 1) && (lineString.length() < 3)) {
				LOG.debug("This line [" + lineString + "] is too short (less than 3 characters). Omit it!");
				lineString = this.removeStopWords(lines[lineNumber++]);
			}
			try {
				LOG.debug("Check if the first line [" + lineString + "] has firma sign value");
				final List<String> firmas = this.dalLK.getAllFirmaSign();
				for (final String firma : firmas) {
					if (Util.checkMatchWord(lineString, firma)) {
						this.hasFirma = true;
						this.pers_typ = 2;
						// FIXME -- Incorrect index of keyword! In this case, the keyword might be at the second line
						// when the first line length is less than 3.
						this.indexOfKeyWord = 0;
						LOG.debug("Yes, the first line has a firma sign [" + firma + "]");
						LOG.debug("Remove the firma sign out of the string");
						this.setKeyword(Util.removeMatchWord(lineString, firma));
						// FIXME -- Duplicate condition
						// FIXME -- Why use the next line when the current line doesn't contain the keyword ?
						if (this.keyword.isEmpty() || (this.keyword.length() < 2)) {
							if ((lineNumber + 1) < lines.length) {
								this.indexOfKeyWord = lineNumber + 1;
								this.setKeyword(this.removeStopWords(lines[lineNumber + 1]));
								string = string.replace(lineString, CHAR_EMPTY).replace(lines[1], CHAR_EMPTY);
							}
						} else {
							this.indexOfKeyWord = lineNumber;
							string = string.replace(lines[0], CHAR_EMPTY);
						}
						break;
					}
				}
			} catch (final Exception ex) {
				ex.printStackTrace();
			}
			LOG.debug("Inspect for Vorname and Name");
			if (this.hasFirma) {
				// FIXME -- This is incorrect in the case the first line length is less than 3. We will process the 2nd
				// line twice. Is it duplicated ???
				// Because: when a line has a firma sign (company), Does it contain a Anrede also?
				this.indexLast = this.indexOfKeyWord + 1;
				String nextRow = WordUtils.capitalizeFully(lines[this.indexLast]);
				LOG.debug("Check next line [" + nextRow + "]");
				for (final String anrede : this.knownAnredes) {
					if (Util.checkMatchWord(nextRow, anrede)) {
						this.hasAnrede = true;
						this.anrede = WordUtils.capitalize(anrede.toString());
						nextRow = nextRow.replace(this.anrede, CHAR_EMPTY).trim();
						if (nextRow.isEmpty()) {
							this.indexLast = this.indexLast + 1;
							final String person = lines.length > 2 ? lines[this.indexLast].trim() : CHAR_EMPTY;
							if (!person.isEmpty() && (person.split(CHAR_WHITE_SPACE).length > 1)) {
								this.setVorname(person.split(CHAR_WHITE_SPACE)[0]);
								this.setName(person.split(CHAR_WHITE_SPACE)[1]);
							}
						} else if (!nextRow.isEmpty() && (nextRow.split(CHAR_WHITE_SPACE).length > 1)) {
							this.setVorname(nextRow.split(CHAR_WHITE_SPACE)[0]);
							this.setName(nextRow.split(CHAR_WHITE_SPACE)[1]);
						}
						break;
					} else {
						this.indexLast = this.indexOfKeyWord + 2;
						String next2Row = WordUtils.capitalizeFully(lines[this.indexLast]);
						if (Util.checkMatchWord(next2Row, anrede)) {
							this.hasAnrede = true;
							this.anrede = WordUtils.capitalize(anrede.toString());
							next2Row = next2Row.replace(this.anrede, CHAR_EMPTY).trim();
							if (next2Row.isEmpty()) {
								this.indexLast = this.indexLast + 1;
								final String person = lines.length > 2 ? lines[this.indexLast].trim() : CHAR_EMPTY;
								if (!person.isEmpty() && (person.split(CHAR_WHITE_SPACE).length > 1)) {
									this.setVorname(person.split(CHAR_WHITE_SPACE)[0]);
									this.setName(person.split(CHAR_WHITE_SPACE)[1]);
								}
							} else if (!next2Row.isEmpty() && (next2Row.split(CHAR_WHITE_SPACE).length > 1)) {
								this.setVorname(next2Row.split(CHAR_WHITE_SPACE)[0]);
								this.setName(next2Row.split(CHAR_WHITE_SPACE)[1]);
							}
							break;
						}
					}
				}
			} else {
				LOG.debug("Check if the first line has anrede value");
				// It try to get the known Anrede from the three of lines
				// At this point, lineString can be the first or the second line
				for (final String anrede : this.knownAnredes) {
					if (Util.checkMatchWord(lineString, anrede)) {
						this.hasAnrede = true;
						this.pers_typ = 1;
						this.anrede = WordUtils.capitalize(anrede.toString());
						this.indexOfKeyWord = 0;
						this.setKeyword(Util.removeMatchWord(lineString, anrede));
						if (this.keyword.isEmpty()) {
							this.indexOfKeyWord = lineNumber + 1;
							this.setKeyword(this.removeStopWords(lines[lineNumber + 1]));
							string = string.replace(lineString, CHAR_EMPTY).replace(lines[1], CHAR_EMPTY);
						} else {
							this.indexOfKeyWord = lineNumber;
							string = string.replace(lineString, CHAR_EMPTY);
						}
						break;
					} else if (!this.fullOCR.isEmpty() && (this.fullOCR.split(CHAR_LINE_SEPARATOR).length > 2)
							&& Util.checkMatchWord(this.fullOCR.split(CHAR_LINE_SEPARATOR)[1], anrede)) {
						this.anrede = WordUtils.capitalize(anrede.toString());
						String temp = this.fullOCR.split(CHAR_LINE_SEPARATOR)[1];
						if (!(temp = Util.removeMatchWord(temp, anrede).trim()).isEmpty()) {
							if (temp.split(CHAR_WHITE_SPACE).length > 1) {
								this.setVorname(temp.split(CHAR_WHITE_SPACE)[0]);
								this.setName(temp.split(CHAR_WHITE_SPACE)[1]);
							}
						} else {
							temp = this.fullOCR.split(CHAR_LINE_SEPARATOR)[2].trim();
							if (temp.split(CHAR_WHITE_SPACE).length > 1) {
								this.setVorname(temp.split(CHAR_WHITE_SPACE)[0]);
								this.setName(temp.split(CHAR_WHITE_SPACE)[1]);
							}
						}
						break;
					} else if (!this.fullOCR.isEmpty() && (this.fullOCR.split(CHAR_LINE_SEPARATOR).length > 2)
							&& Util.checkMatchWord(this.fullOCR.split(CHAR_LINE_SEPARATOR)[2], anrede)) {
						this.anrede = WordUtils.capitalize(anrede.toString());
						String temp = this.fullOCR.split(CHAR_LINE_SEPARATOR)[2];
						if (!(temp = Util.removeMatchWord(temp, anrede).trim()).isEmpty()) {
							if (temp.split(CHAR_WHITE_SPACE).length > 1) {
								this.setVorname(temp.split(CHAR_WHITE_SPACE)[0]);
								this.setName(temp.split(CHAR_WHITE_SPACE)[1]);
							}
						} else {
							temp = this.fullOCR.split(CHAR_LINE_SEPARATOR)[3].trim();
							if (temp.split(CHAR_WHITE_SPACE).length > 1) {
								this.setVorname(temp.split(CHAR_WHITE_SPACE)[0]);
								this.setName(temp.split(CHAR_WHITE_SPACE)[1]);
							}
						}
						break;
					}
				}
				if (!this.hasAnrede) {
					try {
						if (!lineString.isEmpty()) {
							final String line = lines[0].trim();
							final String[] tmps = line.split(CHAR_WHITE_SPACE);
							this.indexOfKeyWord = 0;
							for (final String tmp : tmps) {
								if (tmp.length() > 2) {
									final String tp = this.dalLK.checkKeywordExist(tmp);
									if (!tp.isEmpty()) {
										this.setKeyword(tp);
										break;
									}
								}
							}
							string = string.replace(lines[0], CHAR_EMPTY);
						} else if (!string.isEmpty() && (lines.length > 1)) {
							final String line = lines[1].trim();
							final String[] tmps = line.split(CHAR_WHITE_SPACE);
							this.indexOfKeyWord = 1;
							for (final String tmp : tmps) {
								if (tmp.length() > 2) {
									final String tp = this.dalLK.checkKeywordExist(tmp);
									if (!tp.isEmpty()) {
										this.setKeyword(tp);
										break;
									}
								}
							}
							string = string.replace(lines[1], CHAR_EMPTY);
						}
					} catch (final InterruptedException ex) {
						throw ex;
					} catch (final Exception ex) {
						ex.printStackTrace();
					}
				}
			}
		}

		return string;
	}

	/**
	 * Process pl z_ ort.
	 *
	 * @author lthieu
	 * @param in
	 *            : String to process
	 * @return <br>
	 *         index=0: has plz + ort <br>
	 *         index=1: has plz only <br>
	 *         index=2: has ort only
	 * @throws Exception
	 *             the exception
	 * @description check if exist ort and plz in string
	 */
	private int processPLZ_ORT(String in) throws Exception {
		LOG.debug("PLZ_ORT: " + in);
		if (in.toLowerCase().startsWith("ch ") || in.toLowerCase().startsWith("ch-")) {
			in = in.substring(2).trim();
		}
		LOG.debug("PLZ_ORT - After check ch prefix: " + in);
		this.plz = CHAR_EMPTY;
		this.ort = CHAR_EMPTY;
		int result = 3;
		final Pattern p = Pattern.compile("\\d+");
		final Matcher m = p.matcher(in);
		while (m.find()) {
			if (m.group().length() == 4) {
				this.plz = m.group();

				if (this.dalLK.checkPLZExist(this.plz) == 0) {
					this.matchPLZ = false;
				} else {
					this.matchPLZ = true;
				}

				result = 1;
				break;
			}
		}
		this.ort = in.replace(this.plz, CHAR_EMPTY).trim();
		if (!this.ort.isEmpty()) {
			if (result == 1) {
				result = 0;
			} else {
				result = 2;
			}
		}
		if (this.dalLK.checkORTExist(this.ort) == 0) {
			this.matchORT = false;
		} else {
			this.matchORT = true;
		}
		return result;
	}

	/**
	 * Process plzort general.
	 *
	 * @param in
	 *            the in
	 * @return the string
	 */
	private String processPLZORTGeneral(final String in) {
		String returnString = in;
		try {
			if (in.isEmpty()) {
				return CHAR_EMPTY;
			}
			if (this.hasPLZ) {
				return in.replace(this.plz, CHAR_EMPTY).replace(this.ort, CHAR_EMPTY);
			}
			this.hasPLZ = false;

			final Pattern p = Pattern.compile("\\d{4}");
			final Matcher m = p.matcher(in);
			while (m.find()) {
				if (m.group().length() == 4) {
					try {
						this.setPlz(m.group());
						this.hasPLZ = true;
					} catch (final Exception ex) {
						LOG.error(CHAR_EMPTY, ex);
					}
				}
			}
			if (!this.hasPLZ) {
				final String temp = in.replace(CHAR_WHITE_SPACE, CHAR_EMPTY);
				final Matcher mTemp = p.matcher(temp);
				while (mTemp.find()) {
					if (mTemp.group().length() == 4) {
						try {
							this.setPlz(mTemp.group());
							this.hasPLZ = true;
						} catch (final Exception ex) {
							LOG.error(CHAR_EMPTY, ex);
						}
					}
				}
				final String remainString = in.substring(temp.indexOf(this.plz) + 4).trim();
				this.setOrt(remainString.split(CHAR_LINE_SEPARATOR)[0]);
			} else {
				final String remainString = in.substring(in.indexOf(this.plz) + 4).trim();
				this.setOrt(remainString.split(CHAR_LINE_SEPARATOR)[0]);
			}
			returnString = in.replace(this.plz, CHAR_EMPTY).replace(this.ort, CHAR_EMPTY);
		} catch (final Exception ex) {
			ex.printStackTrace();
		}
		return returnString;
	}

	/**
	 * Process result ocr.
	 *
	 * @param result
	 *            the result
	 * @param strasse
	 *            the strasse
	 * @param plz
	 *            the plz
	 * @param ort
	 *            the ort
	 * @throws Exception
	 *             the exception
	 */
	public void processResultOCR(String result, final String strasse, String plz, final String ort) throws Exception {
		if (result == null) {
			LOG.info("The ocr data is empty");
			return;
		}
		result = result.trim();
		if (result.isEmpty()) {
			LOG.info("The ocr data is empty");
			return;
		}
		LOG.debug("Start post processing OCR data: " + result);
		result = this.removeFistNumberString(result);
		LOG.debug("Check strasse value [" + strasse + "]");
		this.checkStrasseExist(strasse);
		LOG.debug("Check plz value [" + plz + "]");
		this.checkPLZExist(plz);
		LOG.debug("Check ort value [" + ort + "]");
		this.checkORTExist(ort);
		LOG.debug("Normalize ocr data....");
		result = this.dalLK.translateASCII(result);
		LOG.debug("Remove all special characters out of the result");
		result = this.removeAllSpecialCharacter(result);
		this.specialCaseAll = this.checkSpecialCase(result);
		this.processGeneralCase(result, plz, ort);
		LOG.debug("End Process general case");
		switch (this.specialCaseAll) {
		case 0:
			break;
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;
		default:
			break;
		}

		if (this.keyword.isEmpty()) {
			final String[] resArray = result.split(CHAR_LINE_SEPARATOR);
			this.specialCaseAll = this.checkSpecialCase(result);
			final int arrLength = resArray.length;
			switch (arrLength) {
			case 3:
				this.setKeyword(this.getKeyWordRelateToAnrede(resArray[0]));
				this.processPLZ_ORT(resArray[2]);
				final int specialCase = this.checkSpecialCase(resArray[1]);
				switch (specialCase) {
				case 0:
					this.processHausNummer(resArray[1]);
					break;
				case 1:
					break;
				case 2:
					break;
				case 3:
					break;
				case 4:
					break;
				case 5:
					break;
				}
				break;
			case 4:
				final int hasPLZorORT4 = this.processPLZ_ORT(resArray[3]);
				switch (hasPLZorORT4) {
				case 0:
					this.setKeyword(this.getKeyWordRelateToAnrede(resArray[0]));
					if (this.keyword.isEmpty()) {
						this.setKeyword(resArray[1]);
						this.processHausNummer(resArray[2]);
					} else if (this.specialCaseAll == 0) {
					} else if (this.specialCaseAll == 1) {
						int isSpecial = this.checkSpecialCase(resArray[1]);
						if (isSpecial == 1) {
							this.processHausNummer(resArray[2]);
						} else {
							isSpecial = this.checkSpecialCase(resArray[2]);
							if (isSpecial == 1) {
							}
						}
					}
					break;
				case 1:
					break;
				case 2:
					if (this.checkPLZOnly(resArray[2])) {
						plz = resArray[2];
					}
					this.processHausNummer(resArray[1]);
					this.setKeyword(this.getKeyWordRelateToAnrede(resArray[0]));
					break;
				}
				break;
			case 5:
				int hasPLZorORT5 = this.processPLZ_ORT(resArray[3]);
				if (hasPLZorORT5 == 0) {
					switch (hasPLZorORT5) {
					case 0:
						this.setKeyword(this.getKeyWordRelateToAnrede(resArray[0]));
						if (this.keyword.isEmpty()) {
							this.setKeyword(resArray[1]);
							this.processHausNummer(resArray[2]);
						} else if (this.specialCaseAll == 0) {
						} else if (this.specialCaseAll == 1) {
							int isSpecial = this.checkSpecialCase(resArray[1]);
							if (isSpecial == 1) {
								this.processHausNummer(resArray[2]);
							} else {
								isSpecial = this.checkSpecialCase(resArray[2]);
								if (isSpecial == 1) {
								}
							}
						}
						break;
					case 1:
						break;
					case 2:
						if (this.checkPLZOnly(resArray[2])) {
							plz = resArray[2];
						}
						this.processHausNummer(resArray[1]);
						this.setKeyword(this.getKeyWordRelateToAnrede(resArray[0]));
						break;
					}
				} else {
					hasPLZorORT5 = this.processPLZ_ORT(resArray[4]);

				}
				break;
			case 6:

				break;
			case 7:

				break;
			}
		}
	}

	/**
	 * Process strasse general.
	 *
	 * @param in
	 *            the in
	 * @description: find row has strasse
	 */
	private void processStrasseGeneral(final String in) {
		try {

			if (in.isEmpty()) {
				return;
			}

			final String lines[] = in.split("[\\n,]");
			int index = 0;
			for (String line : lines) {
				if (index >= this.indexLast) {
					if (line.trim().isEmpty()) {
						continue;
					}
					line = line.replace(this.getPlz(), CHAR_EMPTY).replace(this.getOrt(), CHAR_EMPTY);
					if (!this.getHausnummer().isEmpty()) {
						if (line.indexOf(this.getHausnummer()) > 0) {
							line = line.substring(0, line.indexOf(this.getHausnummer()));
						}
						line = line.replace(this.getHausnummer(), "  ");
					}
					if (this.checkHasStrasse(line)) {
						final String strase = this.strasseBase(line);
						this.setStrasse(strase);
						this.indexStrasse = index;
						final String hause = line.replaceAll(strase, CHAR_EMPTY).trim();
						if (!hause.isEmpty()) {
							this.setHausnummer(hause);
						}
						return;
					}
				}
				index++;
			}
		} catch (final Exception ex) {
			ex.printStackTrace();
		}

	}

	/**
	 * Process zusat.
	 *
	 * @param ocrResult
	 *            the ocr result
	 */
	private void processZusat(final String ocrResult) {
		final String[] lines = ocrResult.split(CHAR_LINE_SEPARATOR);
		int index = 0;
		while (true) {
			if (index <= lines.length) {
				if ((this.indexOfKeyWord + 1) < this.indexLast) {
					this.setNameZusat(lines[this.indexOfKeyWord + 1]);
					break;
				} else if ((index > this.indexLast) && (index < this.indexStrasse)) {
					this.setNameZusat(lines[index]);
					break;
				} else {
					index++;
					continue;
				}
			} else {
				break;
			}
		}
	}

	/**
	 * Removes the all special character.
	 *
	 * @author lthieu
	 * @param in
	 *            the in
	 * @return string without special character (include alphabet, number, and space)
	 * @description remove all special character in string
	 */
	private String removeAllSpecialCharacter(final String in) {
		return in.replaceAll("[^\\w\\d\\s-.]", CHAR_WHITE_SPACE).replace("-", CHAR_WHITE_SPACE).replace("_",
				CHAR_EMPTY);
	}

	/**
	 * Removes the fist number string.
	 *
	 * @param in
	 *            the in
	 * @return the string
	 */
	private String removeFistNumberString(final String in) {
		final String[] arr = in.split(CHAR_LINE_SEPARATOR);
		String temp = CHAR_EMPTY;
		if (!arr[0].isEmpty() && Pattern.matches("\\d{1}", arr[0].substring(0, 1))) {
			for (int i = 1; i < arr.length; i++) {
				temp = temp + arr[i].trim() + CHAR_LINE_SEPARATOR;
			}
		} else {
			temp = in;
		}
		return temp;
	}

	/**
	 * Removes the stop words.
	 *
	 * @param key
	 *            the key
	 * @return the string
	 */
	private String removeStopWords(final String key) {
		String ret = key;

		if (!ret.isEmpty()) {
			for (final String stopWord : this.stopWords) {
				ret = ret.replace(stopWord, CHAR_EMPTY);
			}
		}

		return ret;
	}

	/**
	 * reset all variables before OCR.
	 */
	public void resetOCRData() {
		this.fullOCR = CHAR_EMPTY;
		this.anrede = CHAR_EMPTY;
		this.keyword = CHAR_EMPTY;
		this.plz = CHAR_EMPTY;
		this.ort = CHAR_EMPTY;
		this.strasse = CHAR_EMPTY;
		this.hausnummer = CHAR_EMPTY;
		this.canDoKDP = false;
		this.specialCaseAll = 0;
		this.matchKeyword = false;
		this.matchStrasse = false;
		this.matchPLZ = false;
		this.matchORT = false;
		this.hasAnrede = false;
		this.hasPLZ = false;
		this.indexOfKeyWord = -1;
		this.firmaname = CHAR_EMPTY;
		this.vorname = CHAR_EMPTY;
		this.name = CHAR_EMPTY;
		this.nameZusat = CHAR_EMPTY;
		this.pers_typ = 0;
		this.indexLast = 0;
		this.indexStrasse = 0;

		this.postfach = CHAR_EMPTY;
	}

	/**
	 * Return field.
	 *
	 * @param input
	 *            the input
	 * @param comparated
	 *            the comparated
	 * @return the string
	 */
	private String returnField(final String input, final String comparated) {
		if (!comparated.isEmpty()) {
			return comparated;
		}
		if (input.isEmpty()) {
			return CHAR_EMPTY;
		}
		return Util.getToolTip(input, this.fullOCR);
	}

	/**
	 * Sets the keyword.
	 *
	 * @param keyword
	 *            the new keyword
	 */
	public void setKeyword(final String keyword) {
		String value = keyword.toLowerCase();
		value = value.replace(" und", CHAR_EMPTY).replace("und ", CHAR_EMPTY);
		this.keyword = value.trim();
		if (!this.keyword.isEmpty()) {
			try {
				// FIXME -- The snippet to get the lookup phrase (field lookup on UI). Verify if this is correct.
				this.checkKeywordMatchKDP();
				if (this.hasFirma) {
					final String split[] = this.keyword.split(CHAR_WHITE_SPACE);
					if (split[0].length() < 3) {
						this.keyword = this.keyword.replace(CHAR_WHITE_SPACE, CHAR_PERCENTAGE);
					} else {
						this.keyword = split[0];
					}
				}
			} catch (final Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * Sets the ort.
	 *
	 * @param ort
	 *            the new ort
	 */
	public void setOrt(final String ort) {
		try {
			this.ort = ort;
			if (this.dalLK.checkORTExist(this.ort) == 0) {
				this.matchORT = false;
			} else {
				this.matchORT = true;
			}
			this.ort = WordUtils.capitalizeFully(this.ort);
		} catch (final Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * Sets the plz.
	 *
	 * @param plz
	 *            the new plz
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	public void setPlz(final String plz) throws InterruptedException {
		try {
			this.plz = plz;
			if (this.dalLK.checkPLZExist(this.plz) == 0) {
				this.matchPLZ = false;
			} else {
				this.matchPLZ = true;
			}
		} catch (final Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * Sets the strasse.
	 *
	 * @param strasse
	 *            the new strasse
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	public void setStrasse(final String strasse) throws InterruptedException {
		try {
			this.strasse = strasse;
			if (this.dalLK.checkStrasseExist(this.strasse) == 0) {
				this.matchStrasse = false;
			} else {
				this.matchStrasse = true;
			}
			this.strasse = WordUtils.capitalizeFully(this.strasse);
		} catch (final InterruptedException ex) {
			throw ex;
		} catch (final Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * Strasse base.
	 *
	 * @param line
	 *            the line
	 * @return the string
	 */
	private String strasseBase(String line) {
		line = line.replaceAll("[ ][\\d]+[\\D]*", CHAR_EMPTY).trim();
		return line;
	}

}
