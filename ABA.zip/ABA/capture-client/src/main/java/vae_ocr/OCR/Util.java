/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package vae_ocr.OCR;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import uk.ac.shef.wit.simmetrics.similaritymetrics.Levenshtein;

/**
 *
 * @author vmhoang
 */
public class Util {
    static String getToolTip(String input, String fullOCR){
        if (input.equals("")) {
            return "";
        }
        String fullOCRTemp = fullOCR.replace("\n", " ");
        int length = input.trim().split(" ").length;
        double scoreMax = 0.0;
        String toolTip = "";
        Pattern p;
        Matcher m;
        int index = 0;
        switch (length) {
            case 1:
                p = Pattern.compile("[\\S]+");
                m = p.matcher(fullOCRTemp);
                while (m.find()) {
                    System.out.println("Pattern: " + m.group() + " |||| Keyword: " + input);
                    Levenshtein lev = new Levenshtein();
                    double value = lev.getSimilarity(input.toLowerCase(), m.group().toLowerCase());
                    if (scoreMax < value) {
                        scoreMax = value;
                        toolTip = m.group();
                    }
                }
                break;
            case 2:
                p = Pattern.compile("[\\S]+[ ][\\S]+");
                m = p.matcher(fullOCRTemp);
                while (m.find(index)) {
                    index = fullOCRTemp.indexOf(m.group(), index) + m.group().indexOf(" ");
                    System.out.println("Pattern: " + m.group() + " |||| Keyword: " + input + " |||||||||||||| " + index);
                    Levenshtein lev = new Levenshtein();
                    double value = lev.getSimilarity(input.toLowerCase(), m.group().toLowerCase());
                    if (scoreMax < value) {
                        scoreMax = value;
                        toolTip = m.group();
                    }
                }
                break;
            case 3:
                p = Pattern.compile("([\\S]+[ ]){2}[\\S]+");
                m = p.matcher(fullOCRTemp);
                while (m.find(index)) {
                    index = fullOCRTemp.indexOf(m.group(), index) + m.group().indexOf(" ");
                    System.out.println("Pattern: " + m.group() + " |||| Keyword: " + input + " |||||||||||||| " + index);
                    Levenshtein lev = new Levenshtein();
                    double value = lev.getSimilarity(input.toLowerCase(), m.group().toLowerCase());
                    if (scoreMax < value) {
                        scoreMax = value;
                        toolTip = m.group();
                    }
                }
                break;
            case 4:
                p = Pattern.compile("([\\S]+[ ]){3}[\\S]+");
                m = p.matcher(fullOCRTemp);
                while (m.find(index)) {
                    index = fullOCRTemp.indexOf(m.group(), index) + m.group().indexOf(" ");
                    System.out.println("Pattern: " + m.group() + " |||| Keyword: " + input + " |||||||||||||| " + index);
                    Levenshtein lev = new Levenshtein();
                    double value = lev.getSimilarity(input.toLowerCase(), m.group().toLowerCase());
                    if (scoreMax < value) {
                        scoreMax = value;
                        toolTip = m.group();
                    }
                }
                break;
            case 5:
                p = Pattern.compile("([\\S]+[ ]){4}[\\S]+");
                m = p.matcher(fullOCRTemp);
                while (m.find(index)) {
                    index = fullOCRTemp.indexOf(m.group(), index) + m.group().indexOf(" ");
                    System.out.println("Pattern: " + m.group() + " |||| Keyword: " + input + " |||||||||||||| " + index);
                    Levenshtein lev = new Levenshtein();
                    double value = lev.getSimilarity(input.toLowerCase(), m.group().toLowerCase());
                    if (scoreMax < value) {
                        scoreMax = value;
                        toolTip = m.group();
                    }
                }
                break;
        }
        if(scoreMax < 0.55){
            String[] lineArray = fullOCR.split("\n");
            if(lineArray != null){
                for (String line : lineArray) {
                    Levenshtein lev = new Levenshtein();
                    double value = lev.getSimilarity(input.toLowerCase(), line.toLowerCase());
                    if (scoreMax < value) {
                        scoreMax = value;
                        toolTip = line;
                    }
                }
            }
        }
        if (scoreMax >= 0.55) {
            return toolTip;
        } else {
            return "";
        }
    }
    
    static String removeMatchWord(String strCheck, String regWord) {
        strCheck = strCheck.toLowerCase();
        String prefix = "-";
        if (regWord.split(" ").length > 1) {
            return strCheck.replaceAll(regWord, "");
        }
        if (regWord.contains("\"")) {
            return strCheck.replaceAll(regWord.replaceAll("\"", ""), "");
        }
        if (regWord.contains(" ")) {
            regWord = regWord.replace(" ", "");
            int regLeng = regWord.length();
            if (regWord.startsWith(prefix)) {
                String strs[] = strCheck.split(" ");
                regWord = regWord.replace(prefix, "");
                for (String str : strs) {
                    if (str.length() == regLeng) {
                        if (str.endsWith(regWord)) {
                            return strCheck.replaceAll(str, "");
                        }
                    }

                }
            } else if (regWord.endsWith(prefix)) {
                String strs[] = strCheck.split(" ");
                regWord = regWord.replace(prefix, "");
                for (String str : strs) {
                    if (str.length() == regLeng) {
                        if (str.startsWith(regWord)) {
                            return strCheck.replaceAll(str, "");
                        }
                    }

                }
            } else {
                String strs[] = strCheck.split(" ");
                for (String str : strs) {
                    if (str.length() == regLeng) {
                        if (str.equals(regWord)) {
                            return strCheck.replaceAll(str, "");
                        }
                    }
                }
            }


        } else {
            if (regWord.startsWith(prefix)) {
                String strs[] = strCheck.split(" ");
                regWord = regWord.replace(prefix, "");
                for (String str : strs) {
                    if (str.endsWith(regWord)) {
                        return strCheck.replaceAll(str, "");
                    }
                }
            } else if (regWord.endsWith(prefix)) {
                String strs[] = strCheck.split(" ");
                regWord = regWord.replace(prefix, "");
                for (String str : strs) {
                    if (str.startsWith(regWord)) {
                        return strCheck.replaceAll(str, "");
                    }
                }

            } else {
                return strCheck.replaceAll(regWord, "");
            }
        }

        return strCheck;
    }
    /**
     * @note line not contains '\n' not startwith ' ';
     * @param line
     * @param regWord
     * @see if regWord has ' ' : this is word on strCheck regWorg has 'str-' :
     * with str la tu can check trong strCheck co tu bat dau = str; regWorg has
     * '-str' : with str la tu can check trong strCheck co tu ket thuc = str;
     * regWorg has 'str- ' : with str la tu can check trong strCheck co tu bat
     * dau = str và có độ dài = str.length()+1; regWorg has '-str ' : with str
     * la tu can check trong strCheck co tu ket dau = str và có độ dài =
     * str.length()+1; regWorg has 'str str2..' : with str va str2 la 2 tu co'
     * trong strcheck;
     * @return true else return false
     */
    static boolean checkMatchWord(String strCheck, String regWord) {
        strCheck = strCheck.toLowerCase();
        String prefix = "-";
        if (regWord.split(" ").length > 1) {
            return strCheck.contains(regWord);
        }
        if (regWord.contains("\"")) {
            return strCheck.contains(regWord.replaceAll("\"", ""));
        }

        if (regWord.contains(" ")) {
            regWord = regWord.replace(" ", "");
            int regLeng = regWord.length();
            if (regWord.startsWith(prefix)) {
                String strs[] = strCheck.split(" ");
                regWord = regWord.replace(prefix, "");
                for (String str : strs) {
                    if (str.length() == regLeng) {
                        if (str.endsWith(regWord)) {
                            return true;
                        }
                    }

                }
            } else if (regWord.endsWith(prefix)) {
                String strs[] = strCheck.split(" ");
                regWord = regWord.replace(prefix, "");
                for (String str : strs) {
                    if (str.length() == regLeng) {
                        if (str.startsWith(regWord)) {
                            return true;
                        }
                    }

                }
            } else {
                String strs[] = strCheck.split(" ");
                for (String str : strs) {
                    if (str.length() == regLeng) {
                        if (str.equals(regWord)) {
                            return true;
                        }
                    }
                }
            }


        } else {
            if (regWord.startsWith(prefix)) {
                String strs[] = strCheck.split(" ");
                regWord = regWord.replace(prefix, "");
                for (String str : strs) {
                    if (str.endsWith(regWord)) {
                        return true;
                    }
                }
            } else if (regWord.endsWith(prefix)) {
                String strs[] = strCheck.split(" ");
                regWord = regWord.replace(prefix, "");
                for (String str : strs) {
                    if (str.startsWith(regWord)) {
                        return true;
                    }
                }

            } else {
                return strCheck.contains(regWord);
            }
        }

        return false;
    }
    
        
    static String getToolTipEx(String input, String fullOCR){
        if (input.equals("")) {
            return "";
        }
        fullOCR = fullOCR.replace("\n", " ");
        int length = input.trim().split(" ").length;
        
        return ":|";
    }
    
    public static void main(String arg[]){
        String fullOCR =    "Agie Charmille Management SA"+"\n"+
                            "Sig Joly N."+"\n"+
                            "8-10, rue Pre-de -la Fontaine"+"\n"+
                            "CH-1217 Meyrin 1";
        
        System.out.println(getToolTipEx("rue pre-de-la", fullOCR));
        System.out.println(getToolTipEx(null, fullOCR));
        System.out.println(getToolTipEx(null, fullOCR));
        System.out.println(getToolTipEx(null, fullOCR));
        System.out.println(getToolTipEx(null, fullOCR));
    }
}
