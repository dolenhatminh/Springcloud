/*
 * Class: AbstractDataExtractor
 *
 * Created on Mar 22, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vae_ocr.extraction.impl;

import com.sps.vn.config.OCRPostProcessingConfiguration;

/**
 * <tt>AbstractDataExtractor</tt> ...
 */
public abstract class AbstractDataExtractor {
    /** The ocr post processing configuration. */
    private final OCRPostProcessingConfiguration ocrPostProcessingConfiguration;

    /**
     * Constructs a new <tt>AbstractDataExtractor</tt>.
     *
     * @param ocrPostProcessingConfiguration the ocr post processing configuration
     */
    public AbstractDataExtractor(final OCRPostProcessingConfiguration ocrPostProcessingConfiguration) {
        this.ocrPostProcessingConfiguration = ocrPostProcessingConfiguration;
    }

    /**
     * Gets the known anredes.
     *
     * @return the known anredes
     */
    protected String[] getKnownAnredes() {
        return this.ocrPostProcessingConfiguration.getKnownAnredes();
    }

    /**
     * Gets the known pickposts.
     *
     * @return the known pickposts
     */
    protected String[] getKnownPickposts() {
        return this.ocrPostProcessingConfiguration.getKnownPickposts();
    }

    /**
     * Gets the known postfatches.
     *
     * @return the known postfatches
     */
    protected String[] getKnownPostfatches() {
        return this.ocrPostProcessingConfiguration.getKnownPostfatches();
    }

    /**
     * Gets the known postlagernds.
     *
     * @return the known postlagernds
     */
    protected String[] getKnownPostlagernds() {
        return this.ocrPostProcessingConfiguration.getKnownPostlagernds();
    }

    /**
     * Gets the known strasses.
     *
     * @return the known strasses
     */
    protected String[] getKnownStrasses() {
        return this.ocrPostProcessingConfiguration.getKnownStrasses();
    }

    /**
     * Gets the special addresses.
     *
     * @return the special addresses
     */
    protected String[] getSpecialAddresses() {
        return this.ocrPostProcessingConfiguration.getSpecialAddresses();
    }

    /**
     * Gets the stop words.
     *
     * @return the stop words
     */
    protected String[] getStopWords() {
        return this.ocrPostProcessingConfiguration.getStopWords();
    }
}
