/*
 * Class: DefaultDataExtractor
 *
 * Created on Mar 22, 2016
 *
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vae_ocr.extraction.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sps.vn.config.OCRPostProcessingConfiguration;

import vae_ocr.OCR.OCRBase;
import vae_ocr.extraction.IDataExtractor;

/**
 * The Class DefaultDataExtractor.
 */
public class DefaultDataExtractor extends AbstractDataExtractor implements IDataExtractor {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DefaultDataExtractor.class);

    /**
     * Instantiates a new default data extractor.
     *
     * @param ocrPostProcessingConfiguration the ocr post processing configuration
     */
    public DefaultDataExtractor(final OCRPostProcessingConfiguration ocrPostProcessingConfiguration) {
        super(ocrPostProcessingConfiguration);
    }

    /**
     * {@inheritDoc}
     *
     * @see vae_ocr.extraction.IDataExtractor#extract(java.lang.String)
     */
    @Override
    public OCRBase extract(final String data) {
        return null;
    }

}
