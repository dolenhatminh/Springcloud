/*
 * Class: IDataExtractor
 * 
 * Created on Mar 17, 2016
 * 
 * (c) Copyright Swiss Post Solution Vietnam, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution Vietnam.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vae_ocr.extraction;

import vae_ocr.OCR.OCRBase;

/**
 * <tt>IDataExtractor</tt> ...
 */
public interface IDataExtractor {
    
    /**
     * Extract data from input data.
     *
     * @param data the data
     * @return the OCR base
     */
    OCRBase extract(final String data);
}
