import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.ArrayUtils;

public class SynonymOrtCreator {
	public static void main(String[] args) throws IOException {
//		File file = new File("/home/lqbinh/Downloads/ES_Setting/input_synonyms_ort.txt");
		
		BufferedReader br = new BufferedReader(new FileReader("/home/lqbinh/Downloads/ES_Setting/input_synonyms_ort.txt"));
		try {
		    StringBuilder sb = new StringBuilder();
		    String line = br.readLine();

		    while (line != null) {		    	
		    	
		        sb.append(processLine(line));		        
		        line = br.readLine();
		    }
		    String everything = sb.toString();
		    
		    FileUtils.writeStringToFile(new File("/home/lqbinh/Downloads/ES_Setting/out_synonyms_ort.txt"), everything);
		    
		    System.out.println(everything);
		} catch (Exception exception){
			exception.printStackTrace();
		}finally {
		    br.close();
		}
		
//		System.out.println(processLine("lausanne 7,losanna 7,losanna 7 st  paul,lausanne 7 st  paul"));
		
	}
	
	private static String processLine(String line){
		String[] arrLine = line.split(",");
		
		Map<String, String[]> map = new HashMap<String, String[]>(arrLine.length);
		
		for (int i = 0; i < arrLine.length; i++) {
			String[] arrTmp = ArrayUtils.clone(arrLine);
			java.util.List<String> list = new ArrayList<String>(Arrays.asList(arrTmp));
			list.remove(i);
			
			map.put(arrLine[i], list.toArray(new String[0]));;
		}
		
		return map2String(map);
	}
	
	private static String map2String(Map<String, String[]> input){
		StringBuilder builder = new StringBuilder();
		
		for (Entry<String, String[]> entry : input.entrySet()) {
			for (String item : entry.getValue()) {
				builder.append(item).append(",");
			}
			
			int lastComma =  builder.lastIndexOf(",");
			builder.deleteCharAt(lastComma).append("=>").append(entry.getKey()).append(System.getProperty("line.separator"));
		}
		
		return builder.toString();
	}
}
