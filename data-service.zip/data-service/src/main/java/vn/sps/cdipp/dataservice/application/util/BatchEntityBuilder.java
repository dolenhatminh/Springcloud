package vn.sps.cdipp.dataservice.application.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import vn.sps.cdipp.domain.Attachment;
import vn.sps.cdipp.domain.Comment;
import vn.sps.cdipp.domain.Document;
import vn.sps.cdipp.domain.History;
import vn.sps.cdipp.domain.Management;
import vn.sps.cdipp.domain.Section;
import vn.sps.cdipp.domain.Session;
import vn.sps.cdipp.domain.Task;
import vn.sps.cdipp.domain.entity.management.AttachmentEntity;
import vn.sps.cdipp.domain.entity.management.BatchEntity;
import vn.sps.cdipp.domain.entity.management.CommentEntity;
import vn.sps.cdipp.domain.entity.management.DocumentEntity;
import vn.sps.cdipp.domain.entity.management.ExceptionEntity;
import vn.sps.cdipp.domain.entity.management.HistoryEntity;
import vn.sps.cdipp.domain.entity.management.ManagementEntity;
import vn.sps.cdipp.domain.entity.management.SectionEntity;
import vn.sps.cdipp.domain.entity.management.SessionEntity;
import vn.sps.cdipp.domain.entity.management.TaskEntity;

public final class BatchEntityBuilder {
	
	private BatchEntityBuilder() {}
	
	private final static ObjectMapper jackson = new ObjectMapper();
	
	private static final String ATTACHMENT = "ATTACHMENT";
	private static final String ORI_ATTACHMENT = "ORIGINAL";
	
	public static BatchEntity buildBatch (BatchEntity entity, Task task, String batchId) throws JsonProcessingException {
		entity.setBatchId(batchId);
		if (!CollectionUtils.isEmpty(entity.getTasks())) {
			boolean existingTask = false;
			for (TaskEntity taskEntity : entity.getTasks()) {
				if (taskEntity.getTaskInstanceId().equals(task.getTaskInstanceId())) {
					// Update TaskEntity
					taskEntity = buildTask(task, taskEntity, true);
					existingTask = true;
					break;
				}
			}
			
			if (!existingTask) {
				// Create a new TaskEntity
				TaskEntity taskEntity = createNewTask(entity, task);
				entity.getTasks().add(taskEntity);
			}
			
		} else {
			// Create a new TaskEntity
			TaskEntity taskEntity = createNewTask(entity, task);
			entity.setTasks(Arrays.asList(taskEntity));
		}
		entity.setScannedDateTime(task.getManagement().getScannedDateTime());
		entity.setDueDateTime(task.getManagement().getDueDateTime());
		
		return entity;
	}
	
	private static TaskEntity createNewTask(BatchEntity batchEntity, Task task) throws JsonProcessingException {
		TaskEntity entity = buildTask(task, new TaskEntity(), false);
		entity.setBatch(batchEntity);
		return entity;
	}
	
	private static TaskEntity buildTask(Task task, TaskEntity entity, boolean isUpdate) throws JsonProcessingException {
		entity.setProcessId(task.getProcessId());
		entity.setProcessInstanceId(task.getProcessInstanceId());
		entity.setTaskId(task.getTaskId());
		entity.setTaskInstanceId(task.getTaskInstanceId());
		entity.setType(task.getType());
		entity.setUserGroup(task.getUserGroup());
		entity.setTenantId(task.getTenantId());
		entity.setStatus(task.getStatus());
		
		if (task.getManagement() != null) {
			/**
			 * Build ManagementEntity
			 */
			ManagementEntity managementEntity = buildManagement(task, entity, 
					isUpdate && entity.getManagement() != null);
			
			entity.setManagement(managementEntity);
			
			if (task.getManagement().getSession() != null) {
				/**
				 * Build SessionEntity
				 */
				SessionEntity sessionEntity = buildSession(task, managementEntity, 
						isUpdate && managementEntity.getSession() != null);
				managementEntity.setSession(sessionEntity);
				
				/**
				 * Build SectionEntities
				 */
				if (!CollectionUtils.isEmpty(task.getManagement().getSession().getSections())) {
					List<SectionEntity> sectionEntities = buildSections(task, sessionEntity, 
							isUpdate && !CollectionUtils.isEmpty(sessionEntity.getSections()));
					sessionEntity.setSections(sectionEntities);
				}
			}
		}
		
		/**
		 * Build HistoryEntities
		 */
		if (!CollectionUtils.isEmpty(task.getHistory())) {
			List<HistoryEntity> histories = buildHistories(task, entity, 
					isUpdate && !CollectionUtils.isEmpty(entity.getHistories()));
			entity.setHistories(histories);
		}
		
		if (!CollectionUtils.isEmpty(task.getData().getDocuments())) {
			List<DocumentEntity> documentEntities = buildDocuments(task, entity, 
					isUpdate && !CollectionUtils.isEmpty(entity.getDocuments()));
			entity.setDocuments(documentEntities);
		}
		
		return entity;
	}
	
	/**
	 * @see BatchEntityBuilder.buildTask
	 * @param task
	 * @param sessionEntity
	 * @return List SectionEntity
	 */
	private static List<SectionEntity> buildSections(Task task, SessionEntity sessionEntity, boolean isUpdate) {
		List<Section> sections = task.getManagement().getSession().getSections();
		List<SectionEntity> sectionEntities = isUpdate ? sessionEntity.getSections() : new ArrayList<>();
		if (isUpdate) {
			for (SectionEntity sectionEntity : sectionEntities) {
				int index = sectionEntities.indexOf(sectionEntity);
				Section section = sections.get(index);
				
				sectionEntity.setStartTime(section.getStartTime());
				sectionEntity.setComponent(section.getComponent());
				sectionEntity.setEndTime(section.getEndTime());
				sectionEntity.setOperator(section.getOperator());
			}
		} else {
			for (Section section : sections) {
				SectionEntity sectionEntity = new SectionEntity(sessionEntity);
				sectionEntity.setStartTime(section.getStartTime());
				sectionEntity.setComponent(section.getComponent());
				sectionEntity.setEndTime(section.getEndTime());
				sectionEntity.setOperator(section.getOperator());
				sectionEntities.add(sectionEntity);
			}
		}
		return sectionEntities;
		
	}
	
	/**
	 * @see BatchEntityBuilder.buildTask
	 * @param task
	 * @param managementEntity
	 * @return SessionEntity
	 */
	private static SessionEntity buildSession(Task task, ManagementEntity managementEntity, boolean isUpdate) {
		SessionEntity entity = isUpdate ? managementEntity.getSession() : new SessionEntity(managementEntity);
		Session session = task.getManagement().getSession();
		entity.setStartTime(session.getStartTime());
		entity.setEndTime(session.getEndTime());
		entity.setServiceName(session.getServiceName());
		return entity;
	}
	
	/**
	 * @see BatchEntityBuilder.buildTask
	 * @param task
	 * @param taskEntity
	 * @return ManagementEntity
	 */
	private static ManagementEntity buildManagement(Task task, TaskEntity taskEntity, boolean isUpdate) {
		ManagementEntity entity = isUpdate ? taskEntity.getManagement() : new ManagementEntity(taskEntity);
		Management management = task.getManagement();
		entity.setReceivedTime(management.getReceivedTime());
		entity.setDueDateTime(management.getDueDateTime());
		entity.setReturnedTime(management.getReturnedTime());
		entity.setScannedDateTime(management.getScannedDateTime());
		entity.setSource(management.getSource().name());
		return entity;
	}
	
	/**
	 * @see BatchEntityBuilder.buildTask
	 * @param task
	 * @param taskEntity
	 * @return List HistoryEntity
	 */
	private static List<HistoryEntity> buildHistories(Task task, TaskEntity taskEntity, boolean isUpdate) {
		List<History> histories = task.getHistory();
		List<HistoryEntity> historyEntites = isUpdate ? taskEntity.getHistories() : new ArrayList<>();
		if (isUpdate) {
			for (HistoryEntity entity : historyEntites) {
				int index = historyEntites.indexOf(entity);
				History history = histories.get(index);
				entity.setTaskInstanceId(history.getTaskInstanceId());
				entity.setTaskId(history.getTaskId());
			}
		} else {
			for (History history : histories) {
				HistoryEntity entity = new HistoryEntity(taskEntity);
				entity.setTaskInstanceId(history.getTaskInstanceId());
				entity.setTaskId(history.getTaskId());
				historyEntites.add(entity);
			}
		}
		
		return historyEntites;
		
	}
	
	private static List<DocumentEntity> buildDocuments(Task task, TaskEntity taskEntity, 
			boolean isUpdate) 
			throws JsonProcessingException {
		List<DocumentEntity> documentEntities = isUpdate ? taskEntity.getDocuments() : new ArrayList<>();
		List<Document> documents = task.getData().getDocuments();
		if (isUpdate) {
			for (DocumentEntity entity : documentEntities) {
				int index = documentEntities.indexOf(entity);
				Document document = documents.get(index);
				entity = buildDocument(entity, document, taskEntity, isUpdate);
			}
		} else {
			for (Document document : documents) {
				DocumentEntity entity = buildDocument(new DocumentEntity(), document, taskEntity, isUpdate);
				documentEntities.add(entity);
			}
		}
		
		return documentEntities;
	}
	
	private static DocumentEntity buildDocument(DocumentEntity entity, Document document, TaskEntity taskEntity, 
			boolean isUpdate)
			throws JsonProcessingException {
		entity.setDocumentId(document.getId()).setDescription(document.getDescription())
				.setDocumentClass(document.getDocumentClass()).setDocumentType(document.getDocumentType())
				.setExportData(jackson.writeValueAsString(document.getExportData()))
				.setLocators(jackson.writeValueAsString(document.getLocators()))
				.setOrigin(jackson.writeValueAsString(document.getOrigin()))
				.setOther(jackson.writeValueAsString(document.getOther())).setParentDocumentId(document.getParentId())
				.setTask(taskEntity)
				.setUserId(document.getUserId())
				.setUserQcPercent(document.getUserQcPercent())
				.setUserVerifyPercent(document.getUserVerifyPercent());

		if (!CollectionUtils.isEmpty(document.getAttachments())) {
			List<AttachmentEntity> attachmentEntities = buildAttachments(document, entity, 
					isUpdate && !CollectionUtils.isEmpty(entity.getAttachments()));
			entity.setAttachments(attachmentEntities);
		}

		if ((!CollectionUtils.isEmpty(document.getComments()))) {
			List<CommentEntity> commentEntities = buildComments(document, entity, 
					isUpdate && !CollectionUtils.isEmpty(entity.getComments()));
			entity.setComments(commentEntities);
		}

		if (document.getException() != null) {
			ExceptionEntity exceptionEntity = buildException(document, entity, 
					isUpdate && entity.getException() != null);
			entity.setException(exceptionEntity);
		}
		return entity;
	}

	private static ExceptionEntity buildException(Document document, DocumentEntity documentEntity, boolean isUpdate) {
		ExceptionEntity entity = isUpdate ? documentEntity.getException() : new ExceptionEntity();
		entity.setExceptionId(document.getException().getId());
		entity.setMessage(document.getException().getMessage());
		entity.setDocument(documentEntity);
		return entity;
	}

	private static List<AttachmentEntity> buildAttachments(Document document, DocumentEntity documentEntity, 
			boolean isUpdate) 
			throws JsonProcessingException {
		List<AttachmentEntity> entities = isUpdate ? documentEntity.getAttachments() : new ArrayList<>();
		if (isUpdate) {
			for (AttachmentEntity entity : entities) {
				if (entity.getAttachmentType().equals(ATTACHMENT)) {
					int index = entities.indexOf(entity);
					Attachment attachment = document.getAttachments().get(index);
					entity.setAttachmentIndex(attachment.getId());
					entity.setAttachmentType(ATTACHMENT);
					entity.setDocFormat(attachment.getDocFormat());
					entity.setDocUrl(attachment.getDocUrl());
					entity.setOther(jackson.writeValueAsString(attachment.getOther()));
					entity.setDocument(documentEntity);
				} else {
					Attachment originalAttachment = document.getOriginalAttachment();
					entity.setAttachmentIndex(originalAttachment.getId());
					entity.setAttachmentType(ORI_ATTACHMENT);
					entity.setDocFormat(originalAttachment.getDocFormat());
					entity.setDocUrl(originalAttachment.getDocUrl());
					entity.setOther(jackson.writeValueAsString(originalAttachment.getOther()));
					entity.setDocument(documentEntity);
				}
			}
		} else {
			for (Attachment attachment : document.getAttachments()) {
				AttachmentEntity entity = new AttachmentEntity();
				entity.setAttachmentIndex(attachment.getId());
				entity.setAttachmentType(ATTACHMENT);
				entity.setDocFormat(attachment.getDocFormat());
				entity.setDocUrl(attachment.getDocUrl());
				entity.setOther(jackson.writeValueAsString(attachment.getOther()));
				entity.setDocument(documentEntity);
				entities.add(entity);
			}
			Attachment originalAttachment = document.getOriginalAttachment();
			AttachmentEntity entity = new AttachmentEntity();
			entity.setAttachmentIndex(originalAttachment.getId());
			entity.setAttachmentType(ORI_ATTACHMENT);
			entity.setDocFormat(originalAttachment.getDocFormat());
			entity.setDocUrl(originalAttachment.getDocUrl());
			entity.setOther(jackson.writeValueAsString(originalAttachment.getOther()));
			entity.setDocument(documentEntity);
			entities.add(entity);
		}
		return entities;
	}
	
	private static List<CommentEntity> buildComments(Document document, DocumentEntity documentEntity, boolean isUpdate) {
		List<CommentEntity> entities = isUpdate ? documentEntity.getComments() : new ArrayList<>();
		List<Comment> comments = document.getComments();
		if (isUpdate) {
			for (CommentEntity entity : entities) {
				int index = entities.indexOf(entity);
				Comment comment = comments.get(index);
				entity.setContent(comment.getContent());
				entity.setService(comment.getServiceName());
				entity.setTaskInstanceId(comment.getTaskInstanceId());
				entity.setTime(comment.getCommentTime());
				entity.setDocument(documentEntity);
			}
			
		} else {
			for (Comment comment : comments) {
				CommentEntity entity = new CommentEntity();
				entity.setContent(comment.getContent());
				entity.setService(comment.getServiceName());
				entity.setTaskInstanceId(comment.getTaskInstanceId());
				entity.setTime(comment.getCommentTime());
				entity.setDocument(documentEntity);
				entities.add(entity);
			}
		}
		return entities;
	}

}
