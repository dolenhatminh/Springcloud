package vn.sps.cdipp.dataservice.infrastructure.persistence.specification.criteria;

import java.util.ArrayList;
import java.util.List;

public class CustomerDataCriteria {
    private List<String> batchIdList = new ArrayList<>();

    public List<String> getBatchIdList() {
        return batchIdList;
    }

    public void setBatchIdList(List<String> batchIdList) {
        this.batchIdList = batchIdList;
    }
}
