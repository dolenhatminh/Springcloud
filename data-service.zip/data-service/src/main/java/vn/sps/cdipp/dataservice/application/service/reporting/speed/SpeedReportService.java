/*
 * Class: SpeedReportService
 *
 * Created on Sep 13, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
/**
 * 
 */
package vn.sps.cdipp.dataservice.application.service.reporting.speed;

import vn.sps.cdipp.dataservice.domain.reporting.request.speed.SpeedReportRequest;
import vn.sps.cdipp.dataservice.domain.reporting.response.SpeedReportResponse;

/**
 * The Interface SpeedReportService.
 */
public interface SpeedReportService {
    
    /**
     * Handle speed report.
     *
     * @param request the request
     * @return the speed report response
     */
    public SpeedReportResponse handleSpeedReport(SpeedReportRequest request);
}
