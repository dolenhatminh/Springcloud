/*
 * Class: DataServiceRepository
 *
 * Created on Aug 31, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
/**
 * 
 */
package vn.sps.cdipp.dataservice.application.service.dao;

import vn.sps.cdipp.dataservice.infrastructure.configuration.common.Enumeration.PersistenceLevel;

/**
 * The Interface DataServiceRepository.
 * @param <T>
 */
public interface GlobalDataAccess<T> {
	
	void handleRequest(PersistenceLevel level, T data);
}
