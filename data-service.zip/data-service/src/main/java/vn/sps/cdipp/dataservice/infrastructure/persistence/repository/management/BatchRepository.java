package vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import vn.sps.cdipp.domain.entity.management.BatchEntity;

public interface BatchRepository extends JpaRepository<BatchEntity, String>, JpaSpecificationExecutor<BatchEntity>{

}
