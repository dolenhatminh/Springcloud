package vn.sps.cdipp.dataservice.infrastructure.persistence.specification.criteria;

import java.util.List;

/**
 * The Class SpeedReportCriteria.
 */
public class SpeedReportCriteria {

    /** The projects. */
    private List<String> projects;

    /** The users. */
    private List<String> users;

    /** The start time. */
    private long startTime;

    /** The end time. */
    private long endTime;

    /** The componant. */
    private String componant;

    /**
     * Gets the projects.
     *
     * @return the projects
     */
    public List<String> getProjects() {
        return projects;
    }

    /**
     * Sets the projects.
     *
     * @param projects the new projects
     */
    public void setProjects(List<String> projects) {
        this.projects = projects;
    }

    /**
     * Gets the users.
     *
     * @return the users
     */
    public List<String> getUsers() {
        return users;
    }

    /**
     * Sets the users.
     *
     * @param users the new users
     */
    public void setUsers(List<String> users) {
        this.users = users;
    }

    /**
     * Gets the start time.
     *
     * @return the start time
     */
    public long getStartTime() {
        return startTime;
    }

    /**
     * Sets the start time.
     *
     * @param startTime the new start time
     */
    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    /**
     * Gets the end time.
     *
     * @return the end time
     */
    public long getEndTime() {
        return endTime;
    }

    /**
     * Sets the end time.
     *
     * @param endTime the new end time
     */
    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    /**
     * Gets the service name.
     *
     * @return componant
     */
    public String getComponant() {
        return componant;
    }

    /**
     * Sets the service name.
     *
     * @param componant the new componant
     */
    public void setComponant(String componant) {
        this.componant = componant;
    }
}
