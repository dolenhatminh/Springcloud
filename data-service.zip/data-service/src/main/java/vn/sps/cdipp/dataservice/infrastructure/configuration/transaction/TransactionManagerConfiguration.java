package vn.sps.cdipp.dataservice.infrastructure.configuration.transaction;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.transaction.ChainedTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement()
public class TransactionManagerConfiguration {
	
	@Bean
    public ChainedTransactionManager chainedTransactionManager(@Qualifier("managementTransactionManager") PlatformTransactionManager managementTransactionManager,
                                                    @Qualifier("customerTransactionManager") PlatformTransactionManager customerTransactionManager) {
         return new ChainedTransactionManager(managementTransactionManager, customerTransactionManager);
    }
}
