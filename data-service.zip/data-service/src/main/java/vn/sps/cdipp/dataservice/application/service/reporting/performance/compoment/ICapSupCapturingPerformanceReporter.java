package vn.sps.cdipp.dataservice.application.service.reporting.performance.compoment;

import java.util.HashMap;
import java.util.Map;

import vn.sps.cdipp.dataservice.infrastructure.configuration.common.ReportingConstants.PerformanceReport;
import vn.sps.cdipp.domain.entity.management.TaskEntity;

class ICapSupCapturingPerformanceReporter extends AbstractComponentPerformanceReporter {

	private static final String ICAP_SUP_CAPTURING_COMPOMENT = "icapSupUsers";
	
	public ICapSupCapturingPerformanceReporter() {
		super(ICAP_SUP_CAPTURING_COMPOMENT);
	}

	@Override
	public Map<String, Object> analyze(TaskEntity data) {
		Map<String, Object> managementData = new HashMap<>();
		Long icapAlreadyForSupCaptureTime = data.getManagement().getReceivedTime();
		Long icapSupCaptureDone = data.getManagement().getReturnedTime();
		managementData.put(PerformanceReport.ICAP_SUPERVISOR_LOGGING_TIME, icapAlreadyForSupCaptureTime);
		managementData.put(PerformanceReport.ICAP_SUPERVISOR_DONE, icapSupCaptureDone);
		return managementData;
	}
	
	
}
