package vn.sps.cdipp.dataservice.application.service.message.endpoint.impl;

import java.io.IOException;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.Transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import vn.sps.cdipp.dataservice.application.service.message.endpoint.TaskProcessorEndpoint;
import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;

@MessageEndpoint("customerDataProcessor")
class CustomerDataProcessorEndpointImpl implements TaskProcessorEndpoint<CustomerDataEntity> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CustomerDataProcessorEndpointImpl.class);
	
	@Autowired
	private ObjectMapper jackson;
	
	@Transformer(inputChannel="customerChannel", outputChannel="jsonCustomerChannel")
	public JsonNode removeIrrelevantData(String jsonTask) throws JsonProcessingException, IOException {
		LOGGER.info("::: [Process Customer Data] remove management data :::");
		JsonNode custDataNode = this.jackson.createObjectNode();
		ArrayNode arrayNode = this.jackson.createArrayNode();
		JsonNode taskNode = this.jackson.readTree(jsonTask);
		JsonNode documents = taskNode.get("data").get("documents");
		JsonNode batchId = taskNode.get("data").get("batchId");
		JsonNode taskInstanceId = taskNode.get("taskInstanceId");
		if (documents instanceof ArrayNode ) {
			for (JsonNode jsonNode :  (ArrayNode) documents) {
				JsonNode processingData = jsonNode.get("processingData");
				JsonNode qualityControlData = jsonNode.get("qualityControlData");
				JsonNode qcTotalFiled = jsonNode.get("qcTotalFiled");
				JsonNode qcErrorField = jsonNode.get("qcErrorField");
				ObjectNode data = this.jackson.createObjectNode();
				data.set("processingData", processingData);
				data.set("qualityControlData", qualityControlData);
				data.set("qcTotalFiled", qcTotalFiled);
				data.set("qcErrorField", qcErrorField);
				arrayNode.add(data);
			}
			((ObjectNode) custDataNode).set("documents", arrayNode);
			((ObjectNode) custDataNode).set("batchId", batchId);
			((ObjectNode) custDataNode).set("taskInstanceId", taskInstanceId);
		} else {
			LOGGER.error("::: [Process Customer Data] Error format: could not remove management data :::");
		}
		
		return custDataNode;
	}
	
	@Transformer(inputChannel = "jsonCustomerChannel", outputChannel="persistDataChannel")
	public CustomerDataEntity transformData(JsonNode custDataNode) throws JsonProcessingException {
		LOGGER.info("::: [Process Customer Data] transform json customer data to entity :::");
		CustomerDataEntity customerData = new CustomerDataEntity();
		String batchId = custDataNode.get("batchId").asText();
		String taskInstanceId = custDataNode.get("taskInstanceId").asText();
		String jsonData = custDataNode.toString();
		customerData.setBatchId(batchId);
		customerData.setData(jsonData);
		customerData.setTaskInstanceId(taskInstanceId);
		return customerData;
	}
}
