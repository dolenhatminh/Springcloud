package vn.sps.cdipp.dataservice.application.service.reporting.performance;

import vn.sps.cdipp.dataservice.application.service.reporting.ReportingService;
import vn.sps.cdipp.dataservice.domain.reporting.request.performance.SystemPerformanceRequest;

import java.util.Arrays;
import java.util.List;

public interface SystemPerformanceReporter extends ReportingService<SystemPerformanceRequest>{
	
	static final String MANAGEMENT_DATA = "MANAGEMENT_DATA";
	
	static final String CUSTOMER_DATA = "CUSTOMER_DATA";
	
	static final List<String> SOURCES = Arrays.asList(MANAGEMENT_DATA, CUSTOMER_DATA);
}

