/*
 * Class: RescanReporterServiceImpl
 *
 * Created on Sep 6, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
/**
 * 
 */
package vn.sps.cdipp.dataservice.application.service.reporting.rescan;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.customer.CustomerDataRepository;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management.TaskRepository;
import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;
import vn.sps.cdipp.domain.entity.management.TaskEntity;

/**
 * The Class RescanReporterServiceImpl.
 */
@Service
public class RescanReporterServiceImpl implements RescanReporterService {
    
    @Autowired
    private CustomerDataRepository customerDataRepository;
    
    @Autowired
    private TaskRepository taskRepository;

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.cdipp.dataservice.application.service.reporting.rescan.RescanReporterService#getBatchIdInTimeRange(java.lang.Long, java.lang.Long)
     */
    @Override
    public List<TaskEntity> getBatchIdInTimeRange(String status, Long fromTime, Long toTime) {
        return this.taskRepository.getBatchIdForServiceNameInTimeRange(status, fromTime, toTime);
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.cdipp.dataservice.application.service.reporting.rescan.RescanReporterService#getBatchIdNeededRescan()
     */
    @Override
    public List<TaskEntity> getBatchIdNeededRescan(String status) {
        return this.taskRepository.getTaskByStatus(status);
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.cdipp.dataservice.application.service.reporting.rescan.RescanReporterService#getCustomerDataByScannedDateTime(java.util.List)
     */
    @Override
    public List<CustomerDataEntity> getCustomerDataByBatchId(List<String> batchIds, List<String> exceptions) {
        return this.customerDataRepository.getCustomerDataByBatchId(batchIds, exceptions);
    }
}
