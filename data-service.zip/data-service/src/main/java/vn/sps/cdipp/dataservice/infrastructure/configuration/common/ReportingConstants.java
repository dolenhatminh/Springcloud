package vn.sps.cdipp.dataservice.infrastructure.configuration.common;

public final class ReportingConstants {
	
	public static class PerformanceReport {
		public static final String SCANNING_TIME = "scanTime";
		public static final String IMPORTING_TIME = "importTime";
		public static final String BARCODE_PROCESSING_TIME = "barcodeProcessingTime";
		public static final String ICAP_NORMAL_LOGGING_TIME = "iCAPNormalLoggingTime";
		public static final String ICAP_NORMAL_DONE = "iCAPNormalDone";
		public static final String ICAP_SUPERVISOR_LOGGING_TIME = "iCAPSupervisorLoggingTime";
		public static final String ICAP_SUPERVISOR_DONE = "iCAPSupervisorDone";
		public static final String ICAP_QC_LOGGING_TIME = "iCAPQCLoggingTime";
		public static final String ICAP_QC_DONE = "ICAPQCDone";
		public static final String EXPORTING_TIME = "ExportTime";
	}
	
}
