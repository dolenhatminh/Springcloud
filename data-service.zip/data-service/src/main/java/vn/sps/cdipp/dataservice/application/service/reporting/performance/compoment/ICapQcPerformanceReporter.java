package vn.sps.cdipp.dataservice.application.service.reporting.performance.compoment;

import java.util.HashMap;
import java.util.Map;

import vn.sps.cdipp.dataservice.infrastructure.configuration.common.ReportingConstants.PerformanceReport;
import vn.sps.cdipp.domain.entity.management.TaskEntity;

class ICapQcPerformanceReporter extends AbstractComponentPerformanceReporter {
	
	private static final String ICAP_QC_COMPOMENT = "iCapQcUsers";

	public ICapQcPerformanceReporter() {
		super(ICAP_QC_COMPOMENT);
	}
	
	@Override
	public Map<String, Object> analyze(TaskEntity data) {
		Map<String, Object> managementData = new HashMap<>();
		Long icapAlreadyQcTime = data.getManagement().getReceivedTime();
		Long icapQcDone = data.getManagement().getReturnedTime();
		managementData.put(PerformanceReport.ICAP_QC_LOGGING_TIME, icapAlreadyQcTime);
		managementData.put(PerformanceReport.ICAP_QC_DONE, icapQcDone);
		return managementData;
	}
}
