package vn.sps.cdipp.dataservice.infrastructure.persistence.repository.customer;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;

@Repository
public interface CustomerDataRepository extends JpaRepository<CustomerDataEntity, String>, JpaSpecificationExecutor<CustomerDataEntity> {

	@Query("SELECT c FROM CustomerDataEntity c WHERE c.batchId = :batchId AND c.taskInstanceId = :taskInstanceId ")
	CustomerDataEntity getCustomerData(@Param("batchId") String batchId, @Param("taskInstanceId") String taskInstanceId);
	
	@Query("SELECT c FROM CustomerDataEntity c WHERE c.taskInstanceId = :taskInstanceId ")
	CustomerDataEntity getCustomerDataByTaskInstanceId(@Param("taskInstanceId") String taskInstanceId);
	
	@Modifying
	@Transactional
	@Query("UPDATE CustomerDataEntity c SET c.data = ?2 WHERE c.batchId = ?1")
	int updateCustomerData(String batchId, String data);
	
	@Query(value="SELECT data FROM customer where ISJSON(data) > 0 and JSON_VALUE(data, '$.data.documents[0].processingData.physicalBarcode') = :barcode", nativeQuery =true)
	String getCustomerDataByBarcodePhysical(@Param("barcode") String barcode);
	
	@Query(value="SELECT data FROM customer where ISJSON(data) > 0 and JSON_VALUE(data, '$.data.documents[0].processingData.digitalBarcode') = :barcode", nativeQuery =true)
	String getCustomerDataByBarcodeDigital(@Param("barcode") String barcode);
	
	@Query("SELECT c from CustomerDataEntity c where c.batchId IN :batchIds ")
	List<CustomerDataEntity> getCustomerDataByBatchIds(@Param("batchIds") List<String> batchIds);
	
    @Query(
            value = "SELECT * FROM customer where ISJSON(data) > 0 and batch_id in :batchIds"
                    + " and JSON_VALUE(data, '$.data.documents[0].exception.id') in :exceptions",
            nativeQuery = true)
    List<CustomerDataEntity> getCustomerDataByBatchId(
        @Param("batchIds") List<String> batchIds,
        @Param("exceptions") List<String> exceptions);
}
