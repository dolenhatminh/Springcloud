package vn.sps.cdipp.dataservice.application.service.dao;

import vn.sps.cdipp.dataservice.infrastructure.configuration.common.Enumeration.PersistenceLevel;

public interface PersistentService<T> {
	
	void handle(PersistenceLevel level, T data);
	
}
