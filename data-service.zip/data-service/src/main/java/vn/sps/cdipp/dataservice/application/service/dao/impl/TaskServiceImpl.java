package vn.sps.cdipp.dataservice.application.service.dao.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import vn.sps.cdipp.dataservice.application.service.dao.PersistentService;
import vn.sps.cdipp.dataservice.infrastructure.configuration.common.Enumeration.PersistenceLevel;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management.TaskRepository;
import vn.sps.cdipp.domain.entity.management.ManagementEntity;
import vn.sps.cdipp.domain.entity.management.SectionEntity;
import vn.sps.cdipp.domain.entity.management.TaskEntity;

@Deprecated
class TaskServiceImpl implements PersistentService<TaskEntity>{
	
    /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskServiceImpl.class);
	
    /** The task repo. */
    @Autowired
    private TaskRepository taskRepo;
    
    /* (non-Javadoc)
	 * @see vn.sps.cdipp.dataservice.application.service.dao.PersistentService#handle(vn.sps.cdipp.dataservice.infrastructure.configuration.common.Enumeration.PersistenceLevel, java.lang.Object)
	 */
	@Override
	public void handle(PersistenceLevel level, TaskEntity data) {
		boolean isUpdate = level == PersistenceLevel.CREATE_ALL;
		if (isUpdate) {
			this.update(data);
		} else {
			this.save(data);
		}
	}
	
	/**
     * Save task.
     *
     * @param entity the entity
     */
	void save(TaskEntity entity) {
		LOGGER.info("::: [Process Management Data] save management data :::");
		this.taskRepo.save(entity);
	}

    /**
     * Update task.
     *
     * @param entity the entity
     */
	void update(TaskEntity entity) {
		LOGGER.info("::: [Process Management Data] update management data :::");
		TaskEntity task = this.taskRepo.getTaskByTaskId(entity.getTaskId());
        ManagementEntity expectedManagement = this.copyManagementData(task.getManagement(), entity.getManagement());
        task.setManagement(expectedManagement);
        task.setHistories(entity.getHistories());
        this.taskRepo.save(task);
	}
	
	/**
     * Copy management data.
     *
     * @param original the original
     * @param expected the expected
     * @return the management entity
     */
    private ManagementEntity copyManagementData(ManagementEntity original, ManagementEntity expected) {
        expected.getTask().setId(original.getTask().getId());
        expected.setId(original.getId());
        expected.getSession().setId(original.getSession().getId());
        List<SectionEntity> sections = original.getSession().getSections();
        for (int i = 0; i < sections.size(); i++) {
            SectionEntity section = sections.get(i);
            expected.getSession().getSections().get(i).setId(section.getId());
        }
        return expected;
    }

}
