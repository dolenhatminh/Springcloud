package vn.sps.cdipp.dataservice.application.service.rollback.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

import vn.sps.cdipp.dataservice.application.service.dao.rollback.GlobalInvokingData;
import vn.sps.cdipp.dataservice.application.service.rollback.RollbackService;
import vn.sps.cdipp.domain.Attachment;
import vn.sps.cdipp.domain.Comment;
import vn.sps.cdipp.domain.Data;
import vn.sps.cdipp.domain.Document;
import vn.sps.cdipp.domain.Exception;
import vn.sps.cdipp.domain.ExportDetail;
import vn.sps.cdipp.domain.History;
import vn.sps.cdipp.domain.Locator;
import vn.sps.cdipp.domain.Management;
import vn.sps.cdipp.domain.QualityControlData;
import vn.sps.cdipp.domain.Section;
import vn.sps.cdipp.domain.Session;
import vn.sps.cdipp.domain.Task;
import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;
import vn.sps.cdipp.domain.entity.management.AttachmentEntity;
import vn.sps.cdipp.domain.entity.management.CommentEntity;
import vn.sps.cdipp.domain.entity.management.DocumentEntity;
import vn.sps.cdipp.domain.entity.management.ExceptionEntity;
import vn.sps.cdipp.domain.entity.management.HistoryEntity;
import vn.sps.cdipp.domain.entity.management.ManagementEntity;
import vn.sps.cdipp.domain.entity.management.SectionEntity;
import vn.sps.cdipp.domain.entity.management.SessionEntity;
import vn.sps.cdipp.domain.entity.management.TaskEntity;
import vn.sps.cdipp.domain.type.InputResourceType;

@Service
public class RollbackTaskImpl implements RollbackService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RollbackTaskImpl.class);
	
	@Autowired
	private GlobalInvokingData<TaskEntity> invokingTaskService;
	
	@Autowired
	private GlobalInvokingData<CustomerDataEntity> invokingDataService;
	
	@Autowired
	private ObjectMapper jackson;
	
	private static final String DOC_NODE = "documents";
	
	private static final String PRO_NODE = "processingData";
	
	private static final String QC_NODE = "qualityControlData";
	
	private static final String ATTACHMENT = "ATTACHMENT";
	
	private static final String ORI_ATTACHMENT = "ORIGINAL";

	/* (non-Javadoc)
	 * @see vn.sps.cdipp.dataservice.application.service.rollback.RollbackService#calculate(java.lang.String)
	 */
	@Override
	public Task calculate(String taskInstanceId) {
		TaskEntity taskEntity = this.invokingTaskService.fetchData(taskInstanceId);
		Task task = this.analyze(new Task(), taskEntity);
		
		CustomerDataEntity customerDataEntity = this.invokingDataService.fetchData(taskInstanceId);
		try {
			task = this.analyze(task, customerDataEntity, taskEntity);
		} catch (IOException e) {
			LOGGER.error("Error: ", e);
		}
		return task;
	}
	
	private Task analyze(Task task, TaskEntity taskEntity) {
		task.setTenantId(taskEntity.getTenantId());
		task.setProcessId(taskEntity.getProcessId());
		task.setProcessInstanceId(taskEntity.getProcessInstanceId());
		task.setTaskId(taskEntity.getTaskId());
		task.setTaskInstanceId(taskEntity.getTaskInstanceId());
		task.setType(taskEntity.getType());
		task.setUserGroup(taskEntity.getUserGroup());
		// miss priority
		task.setStatus(taskEntity.getStatus());
		
		// Build history
		List<HistoryEntity> historyEntities = taskEntity.getHistories();
		if (!CollectionUtils.isEmpty(historyEntities)) {
			List<History> histories = new ArrayList<>();
			for (HistoryEntity historyEntity : historyEntities) {
				History history = new History();
				history.setTaskId(historyEntity.getTaskId());
				history.setTaskInstanceId(historyEntity.getTaskInstanceId());
				histories.add(history);
			}
			task.setHistory(histories);
		}
		
		ManagementEntity managementEntity = taskEntity.getManagement();
		
		//Build Management
		if (managementEntity != null) {
			Management management = new Management();
			management.setDueDateTime(managementEntity.getDueDateTime());
			management.setScannedDateTime(management.getScannedDateTime());
			
			if (managementEntity.getSource().equalsIgnoreCase(InputResourceType.SFTP.name())) {
				management.setSource(InputResourceType.SFTP);
			} else {
				management.setSource(InputResourceType.SMTP);
			}
			
			// Build Session
			SessionEntity sessionEntity = managementEntity.getSession();
			if (sessionEntity != null) {
				Session session = new Session();
				session.setEndTime(sessionEntity.getEndTime());
				session.setServiceName(sessionEntity.getServiceName());
				session.setStartTime(sessionEntity.getStartTime());
				
				List<SectionEntity> sectionEntities = sessionEntity.getSections();
				
				// Build Sections
				if (!CollectionUtils.isEmpty(sectionEntities)) {
					List<Section> sections = new ArrayList<>();
					for (SectionEntity sectionEntity : sectionEntities) {
						Section section = new Section();
						section.setComponent(sectionEntity.getComponent());
						section.setEndTime(sectionEntity.getEndTime());
						section.setOperator(sectionEntity.getOperator());
						section.setStartTime(sectionEntity.getStartTime());
						sections.add(section);
					}
					session.setSections(sections);
				}
				management.setSession(session);
			}
			task.setManagement(management);
		}
		
		return task;
	}
	
	private Task analyze(Task task, CustomerDataEntity customerDataEntity, TaskEntity taskEntity) throws JsonProcessingException, IOException {
		Data data = new Data();
		String batchId = customerDataEntity.getBatchId();
		data.setId(batchId);
		data.setDocuments(new ArrayList<>());
		
		
		List<DocumentEntity> documentEntities = taskEntity.getDocuments();
		
		String customerData = customerDataEntity.getData();
		JsonNode custDataNode = this.jackson.readTree(customerData);
		ArrayNode documents = (ArrayNode) custDataNode.get(DOC_NODE);
		
		for (int i = 0; i < documents.size(); i++) {
			JsonNode custDocNode = documents.get(i);
			JsonNode proNode = custDocNode.get(PRO_NODE);
			JsonNode qcNode = custDocNode.get(QC_NODE);
			Map<String, Object> processingData = this.jackson.convertValue(proNode, HashMap.class);
			List<QualityControlData> qualityControlData = this.jackson.convertValue(qcNode, List.class);
			
			DocumentEntity documentEntity = documentEntities.get(i);
			List<AttachmentEntity> attachmentEntities = documentEntity.getAttachments();
			
			//Build Attachments
			Attachment originalAttachment = new Attachment();
			List<Attachment> attachments = new ArrayList<>();
			if (!CollectionUtils.isEmpty(attachmentEntities)) {
				for (AttachmentEntity attachmentEntity : attachmentEntities) {
					
					if (attachmentEntity.getAttachmentType().equalsIgnoreCase(ORI_ATTACHMENT)) {
						originalAttachment.setDocFormat(attachmentEntity.getDocFormat());
						originalAttachment.setDocUrl(attachmentEntity.getDocUrl());
						originalAttachment.setId(attachmentEntity.getAttachmentIndex());
						
						if (attachmentEntity.getOther() != null && !attachmentEntity.getOther().equalsIgnoreCase("null")) {
							Map<String, Object> other = this.jackson.convertValue(attachmentEntity.getOther(), Map.class);
							originalAttachment.setOther(other);
						}
						
					}
					
					Attachment attachment = new Attachment();
					attachment.setDocFormat(attachmentEntity.getDocFormat());
					attachment.setDocUrl(attachmentEntity.getDocUrl());
					attachment.setId(attachmentEntity.getAttachmentIndex());
					
					if (attachmentEntity.getOther() != null && !attachmentEntity.getOther().equalsIgnoreCase("null")) {
						Map<String, Object> other = this.jackson.convertValue(attachmentEntity.getOther(), Map.class);
						attachment.setOther(other);
					}
					attachments.add(attachment);
				}
			}
			
			List<CommentEntity> commentEntities = documentEntity.getComments();
			List<Comment> comments = new ArrayList<>();
			if (!CollectionUtils.isEmpty(commentEntities)) {
				for (CommentEntity commentEntity : commentEntities) {
					Comment comment = new Comment();
					comment.setBatchId(batchId);
					comment.setContent(commentEntity.getContent());
					comment.setServiceName(commentEntity.getService());
					comment.setTaskInstanceId(commentEntity.getTaskInstanceId());
					comment.setCommentTime(commentEntity.getTime());
					comments.add(comment);
				}
			}
			
			ExceptionEntity exceptionEntity = documentEntity.getException();
			Exception exception = new Exception();
			if (exceptionEntity != null) {
				exception.setId(exceptionEntity.getExceptionId());
				exception.setMessage(exceptionEntity.getMessage());
			}
		
			Document document = new Document();
			document.setProcessingData(processingData);
			document.setQualityControlData(qualityControlData);
			document.setAttachments(attachments);
			document.setOriginalAttachment(originalAttachment);
			document.setComments(comments);
			document.setException(exception);
			document.setDescription(documentEntity.getDescription());
			document.setDocumentClass(documentEntity.getDocumentClass());
			document.setDocumentType(documentEntity.getDocumentType());
			document.setQcErrorField("");
			// Miss qcTotalField
			// Miss qcErrorField
			
			document.setId(documentEntity.getDocumentId());
			if (documentEntity.getLocators() != null && !documentEntity.getLocators().equalsIgnoreCase("null")) {
				List<Locator> locators = this.jackson.convertValue(documentEntity.getLocators(), List.class);
				document.setLocators(locators);
			}
			
			if (documentEntity.getOrigin() != null && !documentEntity.getOrigin().equalsIgnoreCase("null")) {
				Map<String, Object> origin = this.jackson.convertValue(documentEntity.getOrigin(), Map.class);
				document.setOrigin(origin);
			}
			
			if (documentEntity.getOther() != null && !documentEntity.getOther().equalsIgnoreCase("null")) {
				Map<String, Object> other = this.jackson.convertValue(documentEntity.getOther(), Map.class);
				document.setOther(other);
			}
			
			if (documentEntity.getExportData() != null && !documentEntity.getOther().equalsIgnoreCase("null")) {
				List<ExportDetail> exportData = this.jackson.convertValue(documentEntity.getExportData(), List.class);
				document.setExportData(exportData);
			}
			
			document.setParentId(documentEntity.getParentDocumentId());
			document.setUserId(documentEntity.getUserId());
			document.setUserQcPercent(documentEntity.getUserQcPercent());
			document.setUserVerifyPercent(documentEntity.getUserVerifyPercent());
			
			data.getDocuments().add(document);
		}
		task.setData(data);
		return task;
	}
	
}
