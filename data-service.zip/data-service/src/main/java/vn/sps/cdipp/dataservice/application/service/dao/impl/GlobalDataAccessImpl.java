/*
 * Class: DataServiceRepositoryImpl
 *
 * Created on Aug 31, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
/**
 * 
 */
package vn.sps.cdipp.dataservice.application.service.dao.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import vn.sps.cdipp.dataservice.application.service.dao.GlobalDataAccess;
import vn.sps.cdipp.dataservice.application.service.dao.PersistentService;
import vn.sps.cdipp.dataservice.infrastructure.configuration.common.Enumeration.PersistenceLevel;
import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;
import vn.sps.cdipp.domain.entity.management.BatchEntity;

/**
 * The Class DataServiceRepositoryImpl.
 */
@Service
public class GlobalDataAccessImpl implements GlobalDataAccess<Object> {

    @Autowired
    private PersistentService<BatchEntity> batchPersistenceService;
    
    @Autowired
    private PersistentService<CustomerDataEntity> customerService;
    
    @SuppressWarnings("rawtypes")
	private final Map<String, PersistentService> handlers = new HashMap<>();
    
    @PostConstruct
    private void setup() {
    	this.handlers.put(BatchEntity.class.getName(), this.batchPersistenceService);
    	this.handlers.put(CustomerDataEntity.class.getName(), this.customerService);
	}
    
    /* (non-Javadoc)
	 * @see vn.sps.cdipp.dataservice.application.service.dao.GlobalDataAccess#handleRequest(vn.sps.cdipp.dataservice.infrastructure.configuration.common.Enumeration.PersistenceLevel, java.lang.Object)
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void handleRequest(PersistenceLevel level, Object data) {
		PersistentService persistentService = this.handlers.get(data.getClass().getName());
		persistentService.handle(level, data);
	}
}
