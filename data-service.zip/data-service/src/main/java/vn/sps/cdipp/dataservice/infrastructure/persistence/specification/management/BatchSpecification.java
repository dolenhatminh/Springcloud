package vn.sps.cdipp.dataservice.infrastructure.persistence.specification.management;

import javax.persistence.criteria.Predicate;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;

import vn.sps.cdipp.dataservice.infrastructure.persistence.specification.criteria.BatchCriteria;
import vn.sps.cdipp.domain.entity.management.BatchEntity;
import vn.sps.cdipp.domain.entity.management.BatchEntity_;
import vn.sps.cdipp.domain.entity.management.ManagementEntity_;
import vn.sps.cdipp.domain.entity.management.SessionEntity_;
import vn.sps.cdipp.domain.entity.management.TaskEntity_;

/**
 * This specification have not used since version 0.0.4.3
 *
 */
@Deprecated
public class BatchSpecification {
	
	public static Specification<BatchEntity> search(BatchCriteria criteria) {
    	Specification<BatchEntity> specs = null;
    	if(StringUtils.isNotBlank(criteria.getStatus())) {
    		specs = Specifications.where(specs).and(hasSessionServiceName(criteria.getStatus()));
    	}
    	if(criteria.getFromDueDateTime() != null && criteria.getToDueDateTime() != null) {
    		specs = Specifications.where(specs).and(hasDueDateTimeBetween(criteria.getFromDueDateTime(), criteria.getToDueDateTime()));
    	}
    	return specs;

    }
    
    public static Specification<BatchEntity> hasSessionServiceName(String name) {
    	return (root,query, cb) -> {
            Predicate p = cb.equal(root.join(BatchEntity_.tasks).join(TaskEntity_.management).join(ManagementEntity_.session).get(SessionEntity_.serviceName), name);
            return p;
        };
    }
    
    public static Specification<BatchEntity> hasDueDateTimeBetween(Long from, Long to) {
    	return (root,query, cb) -> {
            Predicate p = cb.between(root.get(BatchEntity_.dueDateTime), from, to);
            return p;
        };
    }
}
