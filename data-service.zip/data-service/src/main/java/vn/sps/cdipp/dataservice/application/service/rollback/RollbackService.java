package vn.sps.cdipp.dataservice.application.service.rollback;

import vn.sps.cdipp.domain.Task;

public interface RollbackService {
	
	Task calculate(String taskInstanceId);
}
