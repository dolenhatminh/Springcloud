/*
 * Class: DataServiceProcessorEndpoint
 *
 * Created on Aug 31, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
/**
 * 
 */
package vn.sps.cdipp.dataservice.application.service.message.endpoint;

import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Headers;

import java.util.List;
import java.util.Map;

/**
 * The Interface DataServiceProcessorEndpoint.
 */
public interface DataProcessorEndpoint {
    
    /**
     * Prepare message.
     * 
     * Receive one message and duplicate it twice
     *
     * @param jsonTask the json task
     * @return the list
     */
    public List<String> prepareMessage(String jsonTask);
    
    /**
     * Distribute message.
     * One send to customer and another one send to management
     *
     * @param headers the headers
     * @param message the message
     * @return the string
     */
    public String distributeMessage(@Headers Map<String, Object> headers, Message<?> message);
    
    /**
     * Persist data.
     *
     * @param message the message
     * @param headers the headers
     * @return true, if successful
     */
    boolean persistData(List<Message<?>> message);
}
