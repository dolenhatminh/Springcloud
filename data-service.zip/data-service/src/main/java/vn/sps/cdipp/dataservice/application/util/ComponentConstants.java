package vn.sps.cdipp.dataservice.application.util;

public class ComponentConstants {
    public static final String WEBVIEW = "webview";
    public static final String IMPORTER = "Importer";
}
