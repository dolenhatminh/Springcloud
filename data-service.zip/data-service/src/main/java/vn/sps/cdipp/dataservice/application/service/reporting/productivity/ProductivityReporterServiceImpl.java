package vn.sps.cdipp.dataservice.application.service.reporting.productivity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import vn.sps.cdipp.dataservice.application.util.ServiceNameConstants;
import vn.sps.cdipp.dataservice.domain.reporting.ReportDetails;
import vn.sps.cdipp.dataservice.domain.reporting.ReportResponse;
import vn.sps.cdipp.dataservice.infrastructure.configuration.common.Enumeration.ICapStatus;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.customer.CustomerDataRepository;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management.BatchRepository;
import vn.sps.cdipp.dataservice.infrastructure.persistence.specification.criteria.BatchCriteria;
import vn.sps.cdipp.dataservice.infrastructure.persistence.specification.criteria.CustomerDataCriteria;
import vn.sps.cdipp.dataservice.infrastructure.persistence.specification.customer.CustomerSpecification;
import vn.sps.cdipp.dataservice.infrastructure.persistence.specification.management.BatchSpecification;
import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;
import vn.sps.cdipp.domain.entity.management.BatchEntity;

@Service
public class ProductivityReporterServiceImpl implements ProductivityReporterService {

    private static final String DATE = "date";

    private static final String DUE_DATE_TIME = "dueDateTime";

    private static final String SCANNED_DATE_TIME = "scannedDateTime";

    private static final String EXPORTED_DATE_TIME = "exportedDateTime";

    private static final String SOURCE_PHYSICAL = "physical";

    private static final String SOURCE_DIGITAL = "digital";

    @Autowired
    private CustomerDataRepository customerDataRepository;

    @Autowired
    private BatchRepository batchRepository;

    @Override
    public boolean checkBarcode(String barcode, String source) {
		if (SOURCE_PHYSICAL.equalsIgnoreCase(source)) {
			String data = this.customerDataRepository.getCustomerDataByBarcodePhysical(barcode);
			return StringUtils.isNotEmpty(data);
		} else if (SOURCE_DIGITAL.equalsIgnoreCase(source)) {
			String data = this.customerDataRepository.getCustomerDataByBarcodeDigital(barcode);
			return StringUtils.isNotEmpty(data);
		}
        return false;
    }

    @Override
    public ReportResponse getQualityReport(Long fromScannedDateTime, Long toScannedDateTime) {
        BatchCriteria batchCriteria = new BatchCriteria();
        batchCriteria.setFromScannedTime(fromScannedDateTime);
        batchCriteria.setToScannedTime(toScannedDateTime);
        batchCriteria.setStatus(ICapStatus.QC_DONE.name());
        Specification<BatchEntity> searchBatchSpecs = BatchSpecification.search(batchCriteria);
        List<BatchEntity> batchList = batchRepository.findAll(searchBatchSpecs);

        List<String> batchIdList = batchList.stream().map(BatchEntity::getBatchId).collect(Collectors.toList());
        CustomerDataCriteria customerDataCriteria = new CustomerDataCriteria();
        customerDataCriteria.setBatchIdList(batchIdList);
        Specification<CustomerDataEntity> searchCustomerDataSpecs = CustomerSpecification.search(customerDataCriteria);
        List<CustomerDataEntity> customerDataList = customerDataRepository.findAll(searchCustomerDataSpecs);

        Map<String, CustomerDataEntity> customerMap = customerDataList.stream().collect(
            Collectors.toMap(CustomerDataEntity::getBatchId, c -> c));

        List<ReportDetails> data = batchList.stream().map(b -> {
            ReportDetails row = new ReportDetails();
            String batchId = b.getBatchId();
            row.setBatchId(batchId);
            row.setCustomerData(customerMap.get(batchId).getData());
            Map<String, Object> managementData = new HashMap<>();
            managementData.put(DATE, b.getStartTime());
            row.setManagementData(managementData);
            return row;
        }).collect(Collectors.toList());

        ReportResponse rs = new ReportResponse();
        rs.setData(data);

        return rs;
    }

    @Override
    public ReportResponse getSLAReport(Long fromDueDateTime, Long toDueDateTime) {
        BatchCriteria batchCriteria = new BatchCriteria();
        batchCriteria.setFromDueDateTime(fromDueDateTime);
        batchCriteria.setToDueDateTime(toDueDateTime);
        batchCriteria.setStatus(ServiceNameConstants.EXPORTER);
        Specification<BatchEntity> searchBatchSpecs = BatchSpecification.search(batchCriteria);
        List<BatchEntity> batchList = batchRepository.findAll(searchBatchSpecs);

        List<String> batchIdList = batchList.stream().map(BatchEntity::getBatchId).collect(Collectors.toList());
        CustomerDataCriteria customerDataCriteria = new CustomerDataCriteria();
        customerDataCriteria.setBatchIdList(batchIdList);
        Specification<CustomerDataEntity> searchCustomerDataSpecs = CustomerSpecification.search(customerDataCriteria);
        List<CustomerDataEntity> customerDataList = customerDataRepository.findAll(searchCustomerDataSpecs);

        Map<String, CustomerDataEntity> customerMap = customerDataList.stream().collect(
            Collectors.toMap(CustomerDataEntity::getBatchId, c -> c));

        List<ReportDetails> data = batchList.stream().map(b -> {
            ReportDetails row = new ReportDetails();
            String batchId = b.getBatchId();
            row.setBatchId(batchId);
            row.setCustomerData(customerMap.get(batchId).getData());
            Map<String, Object> managementData = new HashMap<>();
            managementData.put(DUE_DATE_TIME, b.getDueDateTime());
            managementData.put(SCANNED_DATE_TIME, b.getScannedDateTime());
            Long returnedTime = null;
            if (!CollectionUtils.isEmpty(b.getTasks())) {
                returnedTime = Optional
                    .ofNullable(b.getTasks().get(0))
                    .map(t -> t.getManagement().getReturnedTime())
                    .orElse(0L);
            }
            managementData.put(EXPORTED_DATE_TIME, returnedTime);
            row.setManagementData(managementData);
            return row;
        }).collect(Collectors.toList());

        ReportResponse rs = new ReportResponse();
        rs.setData(data);

        return rs;
    }

}
