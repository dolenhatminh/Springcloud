package vn.sps.cdipp.dataservice.domain.monitoring;

import vn.sps.cdipp.domain.Task;

/**
 * The Class MonitoringRequest.
 */
public class MonitoringRequest {
	
	/** The username. */
	private String username;
	
	/** The task. */
	private Task task;
	
	/**
     * Instantiates a new monitoring request.
     */
	public MonitoringRequest() {
	}

    /**
     * Gets the username.
     *
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username.
     *
     * @param username the new username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the task.
     *
     * @return the task
     */
    public Task getTask() {
        return task;
    }

    /**
     * Sets the task.
     *
     * @param task the new task
     */
    public void setTask(Task task) {
        this.task = task;
    }
}
