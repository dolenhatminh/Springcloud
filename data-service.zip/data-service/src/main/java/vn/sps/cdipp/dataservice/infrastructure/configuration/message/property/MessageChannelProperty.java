package vn.sps.cdipp.dataservice.infrastructure.configuration.message.property;

import java.util.Map;

public class MessageChannelProperty {

	private Map<Integer, String> channelMatrix;

	public Map<Integer, String> getChannelMatrix() {
		return channelMatrix;
	}

	public void setChannelMatrix(Map<Integer, String> channelMatrix) {
		this.channelMatrix = channelMatrix;
	}

}
