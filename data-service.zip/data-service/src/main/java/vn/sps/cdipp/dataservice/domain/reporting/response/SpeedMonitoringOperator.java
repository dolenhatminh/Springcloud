/*
 * Class: ProductivityResponseData
 *
 * Created on Sep 17, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.cdipp.dataservice.domain.reporting.response;

import java.util.List;

/**
 * The Class SpeedMonitoringOperator.
 */
public class SpeedMonitoringOperator {
    
    /** The user name. */
    private String userName;
    
    /** The full name. */
    private String fullName;

    /** The documents. */
    private List<SpeedMonitoringDocument> documents;

    public SpeedMonitoringOperator(String userName, String fullName, List<SpeedMonitoringDocument> documents) {
        this.userName = userName;
        this.fullName = fullName;
        this.documents = documents;
    }

    /**
     * Gets the user name.
     *
     * @return the user name
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the user name.
     *
     * @param userName the new user name
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Gets the documents.
     *
     * @return the documents
     */
    public List<SpeedMonitoringDocument> getDocuments() {
        return documents;
    }

    /**
     * Sets the documents.
     *
     * @param documents the new documents
     */
    public void setDocuments(List<SpeedMonitoringDocument> documents) {
        this.documents = documents;
    }

    /**
     * Gets the full name.
     *
     * @return the full name
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * Sets the full name.
     *
     * @param fullName the new full name
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}
