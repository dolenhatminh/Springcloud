package vn.sps.cdipp.dataservice.presentation.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import vn.sps.cdipp.dataservice.application.service.reporting.performance.SystemPerformanceReporter;
import vn.sps.cdipp.dataservice.application.service.reporting.productivity.ProductivityReporterService;
import vn.sps.cdipp.dataservice.application.service.reporting.speed.SpeedReportService;
import vn.sps.cdipp.dataservice.application.util.CDLDateTimeUtil;
import vn.sps.cdipp.dataservice.domain.reporting.ReportResponse;
import vn.sps.cdipp.dataservice.domain.reporting.request.performance.SystemPerformanceRequest;
import vn.sps.cdipp.dataservice.domain.reporting.request.speed.SpeedReportRequest;
import vn.sps.cdipp.dataservice.domain.reporting.response.SpeedReportResponse;

import java.time.ZonedDateTime;

@RestController()
@RequestMapping("reporter")
public class ReportingController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReportingController.class);

	@Autowired
	private ProductivityReporterService reportService;
	
	@Autowired
	private SystemPerformanceReporter systemPerformanceReporter;
	
	@Autowired
    private SpeedReportService speedReportService;
	
	/**
	 *
	 * @param fromScannedDateTime  2018-09-07T00:00:00.000+08:00
	 * @param toScannedDateTime 2018-09-07T00:00:00.000+08:00
	 * @return
	 */
	@GetMapping("/quality")
	public ResponseEntity<ReportResponse> getQualityReport(@RequestParam("fromScannedDateTime") String fromScannedDateTime,
																 @RequestParam("toScannedDateTime") String toScannedDateTime) {
		ZonedDateTime fromDateTime = CDLDateTimeUtil.isoStringToZonedDateTime(fromScannedDateTime);
		ZonedDateTime toDateTime = CDLDateTimeUtil.isoStringToZonedDateTime(toScannedDateTime);

		ReportResponse rs = this.reportService.getQualityReport(fromDateTime.toInstant().toEpochMilli(), toDateTime.toInstant().toEpochMilli());


		return ResponseEntity.ok().body(rs);
	}
	
	/**
	 *
	 * @param fromDueDateTime  2018-09-07T00:00:00.000+08:00
	 * @param toDueDateTime 2018-09-07T00:00:00.000+08:00
	 * @return
	 */
	@GetMapping("/sla")
	public ResponseEntity<ReportResponse> getSLAReport(@RequestParam("fromDueDateTime") String fromDueDateTime,
																 @RequestParam("toDueDateTime") String toDueDateTime) {
		ZonedDateTime fromDateTime = CDLDateTimeUtil.isoStringToZonedDateTime(fromDueDateTime);
		ZonedDateTime toDateTime = CDLDateTimeUtil.isoStringToZonedDateTime(toDueDateTime);

		ReportResponse rs = this.reportService.getSLAReport(fromDateTime.toInstant().toEpochMilli(), toDateTime.toInstant().toEpochMilli());

		return ResponseEntity.ok().body(rs);
	}

	@PostMapping("/performance/system")
	public ResponseEntity<ReportResponse> getSystemPerformanceReport(@RequestBody SystemPerformanceRequest request) {
		LOGGER.info("::: Process {} FROM {} TO {}", 
				request.getRequestName(),
				request.getFromDate(),
				request.getToDate());
		ReportResponse body = this.systemPerformanceReporter.processReportingRequest(request);
		return ResponseEntity.ok().body(body);
	}
	
	@PostMapping("/speed")
    public SpeedReportResponse name(@RequestBody SpeedReportRequest request) {
	    LOGGER.info("::: Process {} FROM {} TO {}", 
            request.getRequestName(),
            request.getStartTime(),
            request.getEndTime());
        return this.speedReportService.handleSpeedReport(request);
    }
}
