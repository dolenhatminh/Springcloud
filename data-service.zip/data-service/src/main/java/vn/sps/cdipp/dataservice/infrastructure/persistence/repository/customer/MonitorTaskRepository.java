/*
 * Class: MonitorTaskEntity
 *
 * Created on Sep 17, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
/**
 * 
 */
package vn.sps.cdipp.dataservice.infrastructure.persistence.repository.customer;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import vn.sps.cdipp.domain.entity.customer.MonitorTaskEntity;

/**
 * The Interface MonitorTaskRepository.
 */
@Repository
public interface MonitorTaskRepository extends JpaRepository<MonitorTaskEntity, Long> {

    /**
     * Find by document id.
     *
     * @param documentId the document id
     * @return the monitor task entity
     */
    MonitorTaskEntity findByDocumentId(String documentId);

}