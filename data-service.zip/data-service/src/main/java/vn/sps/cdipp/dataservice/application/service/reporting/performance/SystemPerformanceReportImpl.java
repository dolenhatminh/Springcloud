package vn.sps.cdipp.dataservice.application.service.reporting.performance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import vn.sps.cdipp.dataservice.application.service.reporting.performance.compoment.ComponenPerformaceReporterFactory;
import vn.sps.cdipp.dataservice.domain.reporting.ReportDetails;
import vn.sps.cdipp.dataservice.domain.reporting.ReportResponse;
import vn.sps.cdipp.dataservice.domain.reporting.request.performance.SystemPerformanceRequest;
import vn.sps.cdipp.dataservice.infrastructure.configuration.common.ReportingConstants.PerformanceReport;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.customer.CustomerDataRepository;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management.BatchIdAndScannedDate;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management.TaskRepository;
import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;
import vn.sps.cdipp.domain.entity.management.TaskEntity;

@Service
class SystemPerformanceReportImpl implements SystemPerformanceReporter {
	
	private final long requestTimeout = 15000;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SystemPerformanceReportImpl.class);
	
	@Autowired
	private TaskRepository taskRepository;
	
	@Autowired
	private CustomerDataRepository customerRepository;
	
	@Autowired
	private ThreadPoolTaskExecutor reportingPerformanceExecutor;
	
	@Autowired
	private ComponenPerformaceReporterFactory componentPerformanceFactory;
	
	@Override
	public ReportResponse processReportingRequest(SystemPerformanceRequest request) {
		List<String> batchIds = this.fetchBatchIdFromManagement(request.getFromDate(),
																request.getToDate(),
																request);
		if (!CollectionUtils.isEmpty(batchIds)) {
			ReportResponse reportResponse = this.fetchSystemPerformanceData(batchIds);
			return reportResponse;
		} else {
			return new ReportResponse();
		}
	}
	
	private List<String> fetchBatchIdFromManagement(long from, long to, SystemPerformanceRequest request) {
		Pageable pagination = new PageRequest(request.getPage(), request.getSize());
		List<BatchIdAndScannedDate> results = this.taskRepository.getBatchIdsByScannedTime(from, to, pagination);
		List<String> batchIds = results.parallelStream().map(r -> r.getBatchId()).collect(Collectors.toList());
		return batchIds;
	}

	@SuppressWarnings("unchecked")
	private ReportResponse fetchSystemPerformanceData(List<String> batchIds) {
		try {
			Map<String, List<? extends Object>> results = this.submit(batchIds);
			List<TaskEntity> managements = (List<TaskEntity>) results.get(MANAGEMENT_DATA);
			List<CustomerDataEntity> customers = (List<CustomerDataEntity>) results.get(CUSTOMER_DATA);
			ReportResponse reportResponse = this.buildReportResponse(managements, customers);
			return reportResponse;
		} catch (InterruptedException | ExecutionException | TimeoutException e) {
			LOGGER.error("Error while fetching data ", e);
		}
		return new ReportResponse();
	}
	
	private Map<String, List<? extends Object>> submit(List<String> batchIds) throws InterruptedException, ExecutionException, TimeoutException {
		List<Future<List<? extends Object>>> futures = new ArrayList<>(SOURCES.size());
		Map<String, List<? extends Object>> results = new HashMap<>(futures.size());
		
		// Submit request to ThreadPoolTaskExecutor
		for (String source : SOURCES) {
			Future<List<? extends Object>> taskExecutor = this.reportingPerformanceExecutor.submit(() -> {
				if (source.equals(MANAGEMENT_DATA)) {
					return this.taskRepository.getManagementDataByBatchIds(batchIds);
				} else if (source.equals(CUSTOMER_DATA)) {
					return this.customerRepository.getCustomerDataByBatchIds(batchIds);
				}
				return Collections.emptyList();
			});
			futures.add(taskExecutor);
		}
		
		// Wait response and put to results
		for (Future<List<? extends Object>> future : futures) {
			List<? extends Object> result = future.get(requestTimeout, TimeUnit.MILLISECONDS);
			if (!CollectionUtils.isEmpty(result)) {
				Object firstElement = result.get(0);
				if (firstElement instanceof TaskEntity) {
					results.put(MANAGEMENT_DATA, result);
				} else if (firstElement instanceof CustomerDataEntity) {
					results.put(CUSTOMER_DATA, result);
				}
			}
		}

		return results;
	}
	
	private ReportResponse buildReportResponse(List<TaskEntity> managements, List<CustomerDataEntity> customers) {
		List<ReportDetails> details = new ArrayList<>();
		for (CustomerDataEntity customerData : customers) {
			String batchId = customerData.getBatchId();
			
			List<TaskEntity> tasksPerDoc = managements.parallelStream()
					   .filter(m -> m.getBatch().getBatchId().equals(batchId))
					   .collect(Collectors.toList());
			Map<String, Object> managementData = analyzeManagement(tasksPerDoc);
			ReportDetails detail = new ReportDetails()
					.setBatchId(batchId)
					.setCustomerData(customerData.getData())
					.setManagementData(managementData);
			details.add(detail);
		}
		return new ReportResponse().setData(details);
				
	}

	/** TODO: 
	 * Waiting reply from Mr.Duy about Supervisor QC
	 */
	private Map<String, Object> analyzeManagement(List<TaskEntity> tasksPerDoc) {
		Map<String, Object> managementData = new HashMap<>();
		for (TaskEntity taskPerDoc : tasksPerDoc) {
			Long scannedDateTime = taskPerDoc.getManagement().getScannedDateTime();
			Map<String, Object> results = this.componentPerformanceFactory.handleRawManagementData(taskPerDoc);
			managementData.putAll(results);
			managementData.put(PerformanceReport.SCANNING_TIME, scannedDateTime);
		}
		managementData.put("totalRecords", 15);
		return managementData;
	}
	
}