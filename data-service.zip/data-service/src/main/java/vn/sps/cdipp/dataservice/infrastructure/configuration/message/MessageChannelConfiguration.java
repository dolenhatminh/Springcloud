package vn.sps.cdipp.dataservice.infrastructure.configuration.message;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.channel.PublishSubscribeChannel;
import org.springframework.messaging.MessageChannel;
import vn.sps.cdipp.dataservice.infrastructure.configuration.message.property.MessageChannelProperty;

@Configuration
public class MessageChannelConfiguration {

	@Bean
	public PublishSubscribeChannel taskChannel() {
		return new PublishSubscribeChannel();
	}

	@Bean
	public MessageChannel replyChannel() {
		return new DirectChannel();
	}

	@Bean
	@ConfigurationProperties(prefix = "message")
	public MessageChannelProperty channelProperty() {
		return new MessageChannelProperty();
	}
}
