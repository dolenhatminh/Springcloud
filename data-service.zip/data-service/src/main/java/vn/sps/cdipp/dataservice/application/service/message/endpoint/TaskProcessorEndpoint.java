package vn.sps.cdipp.dataservice.application.service.message.endpoint;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;
/**
 * Data processor for persistence data 
 * @author nttung_3
 * @param <T>
 */
public interface TaskProcessorEndpoint <T> {
	
	/**
	 * Remove data which are irrelevant to the persistence level 
	 * @param jsonTask
	 * @return JsonNode
	 */
	JsonNode removeIrrelevantData(String jsonTask) throws JsonProcessingException, IOException;
	
	/**
	 * Transform data from JsonNode to {@code Entity} 
	 * @param taskNode
	 * @return T
	 */
	T transformData(JsonNode taskNode) throws JsonProcessingException;
}
