package vn.sps.cdipp.dataservice.domain.reporting;

import java.util.List;

public class ReportResponse {
	
	private List<ReportDetails> data;

	/**
	 * @return the data
	 */
	public List<ReportDetails> getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public ReportResponse setData(List<ReportDetails> data) {
		this.data = data;
		return this;
	}

	

}
