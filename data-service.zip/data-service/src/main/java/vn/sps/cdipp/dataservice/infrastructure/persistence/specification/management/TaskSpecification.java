package vn.sps.cdipp.dataservice.infrastructure.persistence.specification.management;

import javax.persistence.criteria.Predicate;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;

import vn.sps.cdipp.dataservice.infrastructure.persistence.specification.criteria.QualityTaskCriteria;
import vn.sps.cdipp.domain.entity.management.ManagementEntity_;
import vn.sps.cdipp.domain.entity.management.SessionEntity_;
import vn.sps.cdipp.domain.entity.management.TaskEntity;
import vn.sps.cdipp.domain.entity.management.TaskEntity_;

public class TaskSpecification {

    public static Specification<TaskEntity> search(QualityTaskCriteria criteria) {
    	Specification<TaskEntity> specs = null;
    	if(StringUtils.isNotBlank(criteria.getServiceName())) {
    		specs = Specifications.where(specs).and(hasSessionServiceName(criteria.getServiceName()));
    	}
    	if(criteria.getFromScannedTime() != null && criteria.getToScannedTime() != null) {
    		specs = Specifications.where(specs).and(hasManagementScannedDateTimeBetween(criteria.getFromScannedTime(), criteria.getToScannedTime()));
    	}
    	return specs;
//        return (root,query, cb) -> {
//            Predicate p = cb.and(
//                    cb.equal(root.join(TaskEntity_.management).join(ManagementEntity_.session).get(SessionEntity_.serviceName), ServiceNameConstants.QUALITY_CONTROL),
//                    cb.between(root.join(TaskEntity_.management).get(ManagementEntity_.scannedDateTime), criteria.getFromScannedTime(), criteria.getToScannedTime())
//            );
//            return p;
//        };
    }
    
    public static Specification<TaskEntity> hasSessionServiceName(String name) {
    	return (root,query, cb) -> {
            Predicate p = cb.equal(root.join(TaskEntity_.management).join(ManagementEntity_.session).get(SessionEntity_.serviceName), name);
            return p;
        };
    }
    
    public static Specification<TaskEntity> hasManagementScannedDateTimeBetween(Long from, Long to) {
    	return (root,query, cb) -> {
            Predicate p = cb.between(root.join(TaskEntity_.management).get(ManagementEntity_.scannedDateTime), from, to);
            return p;
        };
    }
}
