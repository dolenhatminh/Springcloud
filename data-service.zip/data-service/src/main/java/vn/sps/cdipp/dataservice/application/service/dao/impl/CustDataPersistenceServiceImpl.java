package vn.sps.cdipp.dataservice.application.service.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import vn.sps.cdipp.dataservice.application.service.dao.PersistentService;
import vn.sps.cdipp.dataservice.infrastructure.configuration.common.Enumeration.PersistenceLevel;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.customer.CustomerDataRepository;
import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;

@Service
class CustDataPersistenceServiceImpl extends AbstractPersistenceService<CustomerDataEntity, String> implements PersistentService<CustomerDataEntity>{
	
	/** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(CustDataPersistenceServiceImpl.class);
    
    public CustDataPersistenceServiceImpl(CustomerDataRepository repository) {
		super(repository);
	}

    /* (non-Javadoc)
	 * @see vn.sps.cdipp.dataservice.application.service.dao.PersistentService#handle(vn.sps.cdipp.dataservice.infrastructure.configuration.common.Enumeration.PersistenceLevel, java.lang.Object)
	 */
	@Override
	public void handle(PersistenceLevel level, CustomerDataEntity data) {
		boolean isCreate = (level == PersistenceLevel.CREATE_ALL || 
				level == PersistenceLevel.CREATE_CUST_AND_UPDATE_MANA);
		if (isCreate) {
			LOGGER.info("::: [Process Management Data] create customer data with batch: {} :::", data.getBatchId());
			this.save(data);
		} 
	}

	/* (non-Javadoc)
	 * @see vn.sps.cdipp.dataservice.application.service.dao.impl.AbstractPersistenceService#update(java.lang.Object)
	 * Unused from version 0.0.5.6 
	 * Customer Data is only CREATED per DONE tasks
	 */
	@Deprecated
	@Override
	protected void update(CustomerDataEntity data) {
//		CustomerDataEntity customerData = this.repository.getOne(data.getBatchId());
//		customerData.setData(data.getData());
//		this.save(customerData);
		return;
	}


}
