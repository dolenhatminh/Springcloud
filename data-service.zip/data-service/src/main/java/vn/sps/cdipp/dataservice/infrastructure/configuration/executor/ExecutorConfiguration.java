package vn.sps.cdipp.dataservice.infrastructure.configuration.executor;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class ExecutorConfiguration {
	
	@Bean
	@ConfigurationProperties(prefix="executor.reporting.performance")
	public ThreadPoolTaskExecutor reportingPerformanceExecutor() {
		return new ThreadPoolTaskExecutor();
	}
}
