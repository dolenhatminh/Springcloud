package vn.sps.cdipp.dataservice.application.service.reporting.performance.compoment;

import vn.sps.cdipp.domain.entity.management.TaskEntity;

abstract class AbstractComponentPerformanceReporter implements ComponentPerformanceReporter<TaskEntity> {
	
	private final String comName;

	public AbstractComponentPerformanceReporter(String comName) {
		this.comName = comName;
	}

	/**
	 * @return the comName
	 */
	public final String getComName() {
		return comName;
	}
	
}
