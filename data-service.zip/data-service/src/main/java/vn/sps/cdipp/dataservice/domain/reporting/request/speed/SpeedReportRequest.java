/*
 * Class: SpeedReportRequest
 *
 * Created on Sep 14, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
/**
 * 
 */
package vn.sps.cdipp.dataservice.domain.reporting.request.speed;

import java.util.List;

import vn.sps.cdipp.dataservice.domain.reporting.request.AbstractReportingRequest;

/**
 * The Class SpeedReportRequest.
 */
public class SpeedReportRequest extends AbstractReportingRequest {
    
    /** The Constant SPEED_REPORTING_REQUEST. */
    private static final String SPEED_REPORTING_REQUEST = "SPEED_REPORTING_REQUEST";
    
    /** The projects. */
    private List<String> projects;
    
    /** The users. */
    private List<String> users;
    
    /** The start time. */
    private Long startTime;
    
    /** The end time. */
    private Long endTime;
    
    /** The page. */
    private int page;
    
    /** The length. */
    private int length;
    
    /** The field sort. */
    private String fieldSort;
    
    /** The order. */
    private String order;
    
    /**
     * Instantiates a new speed report request.
     */
    public SpeedReportRequest() {
        super(SPEED_REPORTING_REQUEST);
    }

    /**
     * Gets the projects.
     *
     * @return the projects
     */
    public List<String> getProjects() {
        return projects;
    }

    /**
     * Sets the projects.
     *
     * @param projects the new projects
     */
    public void setProjects(List<String> projects) {
        this.projects = projects;
    }

    /**
     * Gets the users.
     *
     * @return the users
     */
    public List<String> getUsers() {
        return users;
    }

    /**
     * Sets the users.
     *
     * @param users the new users
     */
    public void setUsers(List<String> users) {
        this.users = users;
    }

    /**
     * Gets the start time.
     *
     * @return the start time
     */
    public Long getStartTime() {
        return startTime;
    }

    /**
     * Sets the start time.
     *
     * @param startTime the new start time
     */
    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    /**
     * Gets the end time.
     *
     * @return the end time
     */
    public Long getEndTime() {
        return endTime;
    }

    /**
     * Sets the end time.
     *
     * @param endTime the new end time
     */
    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    /**
     * Gets the page.
     *
     * @return the page
     */
    public int getPage() {
        return page;
    }

    /**
     * Sets the page.
     *
     * @param page the new page
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * Gets the length.
     *
     * @return the length
     */
    public int getLength() {
        return length;
    }

    /**
     * Sets the length.
     *
     * @param length the new length
     */
    public void setLength(int length) {
        this.length = length;
    }

    /**
     * Gets the field sort.
     *
     * @return the field sort
     */
    public String getFieldSort() {
        return fieldSort;
    }

    /**
     * Sets the field sort.
     *
     * @param fieldSort the new field sort
     */
    public void setFieldSort(String fieldSort) {
        this.fieldSort = fieldSort;
    }

    /**
     * Gets the order.
     *
     * @return the order
     */
    public String getOrder() {
        return order;
    }

    /**
     * Sets the order.
     *
     * @param order the new order
     */
    public void setOrder(String order) {
        this.order = order;
    }
}
