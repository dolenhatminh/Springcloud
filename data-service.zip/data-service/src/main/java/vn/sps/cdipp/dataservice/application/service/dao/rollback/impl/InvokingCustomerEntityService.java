package vn.sps.cdipp.dataservice.application.service.dao.rollback.impl;

import org.springframework.stereotype.Service;

import vn.sps.cdipp.dataservice.application.service.dao.rollback.GlobalInvokingData;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.customer.CustomerDataRepository;
import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;

@Service
class InvokingCustomerEntityService implements GlobalInvokingData<CustomerDataEntity> {
	
	private CustomerDataRepository repository;
	
	public InvokingCustomerEntityService(CustomerDataRepository repository) {
		this.repository = repository;
	}

	@Override
	public CustomerDataEntity fetchData(String taskInstanceId) {
		return this.repository.getCustomerDataByTaskInstanceId(taskInstanceId);
	}

	

}
