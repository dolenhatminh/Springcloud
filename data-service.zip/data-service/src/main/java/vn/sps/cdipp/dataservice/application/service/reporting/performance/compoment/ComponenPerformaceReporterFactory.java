package vn.sps.cdipp.dataservice.application.service.reporting.performance.compoment;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import vn.sps.cdipp.domain.entity.management.TaskEntity;

@Service
public class ComponenPerformaceReporterFactory {
	
	private final Map<String, ComponentPerformanceReporter<TaskEntity>> reportingHandlers = new HashMap<>();
	
	@PostConstruct
	private void setup() {
		ImportingPerformanceReporter importingPerformanceReporter = new ImportingPerformanceReporter();
		BarcodeReadingPerformanceReporter barcodeReadingPerformanceReporter = new BarcodeReadingPerformanceReporter();
		ICapCapturingPerformanceReporter iCapCapturingPerformanceReporter = new ICapCapturingPerformanceReporter();
		ICapSupCapturingPerformanceReporter iCapSupCapturingPerformanceReporter = new ICapSupCapturingPerformanceReporter();
		ICapQcPerformanceReporter iCapQcPerformanceReporter = new ICapQcPerformanceReporter();
		
		// Add handler to reportingHandlers
		this.addHandler(importingPerformanceReporter.getComName(), importingPerformanceReporter);
		this.addHandler(barcodeReadingPerformanceReporter.getComName(), barcodeReadingPerformanceReporter);
		this.addHandler(iCapCapturingPerformanceReporter.getComName(), iCapCapturingPerformanceReporter);
		this.addHandler(iCapSupCapturingPerformanceReporter.getComName(), iCapSupCapturingPerformanceReporter);
		this.addHandler(iCapQcPerformanceReporter.getComName(), iCapQcPerformanceReporter);
	}
	
	private void addHandler(String handlerName, ComponentPerformanceReporter<TaskEntity> handler) {
		this.reportingHandlers.put(handlerName, handler);
	}
	
	public Map<String, Object> handleRawManagementData(TaskEntity task) {
		String serviceName = task.getManagement().getSession().getServiceName();
		String userGroup = task.getUserGroup();
		if (this.reportingHandlers.containsKey(serviceName)) {
			return this.reportingHandlers.get(serviceName).analyze(task);
		} else if (this.reportingHandlers.containsKey(userGroup)) {
			return this.reportingHandlers.get(userGroup).analyze(task);
		}
		return Collections.emptyMap();
	}
	
}
