package vn.sps.cdipp.dataservice.application.service.reporting.performance.compoment;

import java.util.HashMap;
import java.util.Map;

import vn.sps.cdipp.dataservice.infrastructure.configuration.common.ReportingConstants.PerformanceReport;
import vn.sps.cdipp.domain.entity.management.TaskEntity;

class BarcodeReadingPerformanceReporter extends AbstractComponentPerformanceReporter {

	private static final String BARCODE_READING_COMPOMENT_REPORTER = "barcode-reader";
	
	public BarcodeReadingPerformanceReporter() {
		super(BARCODE_READING_COMPOMENT_REPORTER);
	}

	@Override
	public Map<String, Object> analyze(TaskEntity data) {
		Map<String, Object> managementData = new HashMap<>();
		Long barcodeProcessingTime = data.getManagement().getReturnedTime();
		managementData.put(PerformanceReport.BARCODE_PROCESSING_TIME, barcodeProcessingTime);
		return managementData;
	}
	
	
}
