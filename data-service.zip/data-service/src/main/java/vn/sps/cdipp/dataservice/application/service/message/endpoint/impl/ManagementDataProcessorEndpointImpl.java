package vn.sps.cdipp.dataservice.application.service.message.endpoint.impl;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.Transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import vn.sps.cdipp.dataservice.application.service.message.endpoint.TaskProcessorEndpoint;
import vn.sps.cdipp.domain.Task;
import vn.sps.cdipp.domain.entity.management.BatchEntity;

@MessageEndpoint("managementDataProcessor")
class ManagementDataProcessorEndpointImpl implements TaskProcessorEndpoint<BatchEntity>{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ManagementDataProcessorEndpointImpl.class);
	
	@Autowired
	private ObjectMapper jackson;
	
	@Transformer(inputChannel="managementChannel", outputChannel="jsonManagementChannel")
	public JsonNode removeIrrelevantData(String jsonTask) throws JsonProcessingException, IOException {
		LOGGER.info("::: [Process Management Data] remove customer data :::");
		JsonNode taskNode = this.jackson.readTree(jsonTask);
		if (taskNode instanceof ObjectNode) {
			JsonNode data =taskNode.get("data");
			if (data != null) {
				JsonNode batchId = taskNode.get("data").get("batchId");
				((ObjectNode) taskNode).set("batchId", batchId);
			} else {
				LOGGER.error("::: [Process Customer Data] Error: not existing Customer Data :::");
			}
		} else {
			LOGGER.error("::: [Process Customer Data] Error format: could not remove customer data :::");
		}
		return taskNode;
	}
	
	@Transformer(inputChannel="jsonManagementChannel", outputChannel="persistDataChannel")
	public BatchEntity transformData(JsonNode taskNode) throws JsonProcessingException {
		LOGGER.info("::: [Process Management Data] transform management data to entity :::");
		JsonNode batchId = ((ObjectNode) taskNode).remove("batchId");
		Task task = this.jackson.treeToValue(taskNode, Task.class);
		//BatchEntity batchEntity = BatchEntityBuilder.buildBatch(new BatchEntity(), task , batchId.asText());
		BatchEntity batchEntity = new BatchEntity();
		batchEntity.setTransientTask(task);
		batchEntity.setBatchId(batchId.asText());
		return batchEntity;
	}
}
