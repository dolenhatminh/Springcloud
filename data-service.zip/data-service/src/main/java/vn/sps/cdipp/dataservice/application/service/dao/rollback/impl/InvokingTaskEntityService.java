package vn.sps.cdipp.dataservice.application.service.dao.rollback.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import vn.sps.cdipp.dataservice.application.service.dao.rollback.GlobalInvokingData;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management.TaskRepository;
import vn.sps.cdipp.domain.entity.management.TaskEntity;

@Service
class InvokingTaskEntityService implements GlobalInvokingData<TaskEntity> {

	@Autowired
	private TaskRepository repository;
	
	@Override
	public TaskEntity fetchData(String taskInstanceId) {
		return this.repository.getTaskByTaskInstanceId(taskInstanceId);
	}

}
