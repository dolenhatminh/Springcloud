package vn.sps.cdipp.dataservice.application.service.reporting.productivity;

import vn.sps.cdipp.dataservice.domain.reporting.ReportResponse;

public interface ProductivityReporterService {
	
	
	/**
	 *
	 * @param fromScannedDateTime
	 * @param toScannedDateTime
	 * @return
	 */
	ReportResponse getQualityReport(Long fromScannedDateTime, Long toScannedDateTime);
	
	/**
	 *
	 * @param fromScannedDateTime
	 * @param toScannedDateTime
	 * @return
	 */
	ReportResponse getSLAReport(Long fromDueDateTime, Long toDueDateTime);
	
	
	boolean checkBarcode(String barcode, String source);
}
