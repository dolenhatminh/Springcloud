/*
 * Class: SpeedReportResponse
 *
 * Created on Sep 17, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.cdipp.dataservice.domain.reporting.response;

import java.util.List;

/**
 * The Class SpeedReportResponse.
 */
public class SpeedReportResponse {

    /** The speed monitoring resonse datas. */
    private List<SpeedMonitoringOperator> speedMonitoringOperators;

    public List<SpeedMonitoringOperator> getSpeedMonitoringOperators() {
        return speedMonitoringOperators;
    }

    public void setSpeedMonitoringOperators(List<SpeedMonitoringOperator> speedMonitoringOperators) {
        this.speedMonitoringOperators = speedMonitoringOperators;
    }
}
