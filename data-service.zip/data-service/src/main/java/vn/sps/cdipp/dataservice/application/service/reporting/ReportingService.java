package vn.sps.cdipp.dataservice.application.service.reporting;

import vn.sps.cdipp.dataservice.domain.reporting.ReportResponse;
import vn.sps.cdipp.dataservice.domain.reporting.request.AbstractReportingRequest;

/**
 * 
 * @author nttung_3
 * @param <T>
 */
public interface ReportingService<T extends AbstractReportingRequest> {
	
	ReportResponse processReportingRequest(T request);
	
}
