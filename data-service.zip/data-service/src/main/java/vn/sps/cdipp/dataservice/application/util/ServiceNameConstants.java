package vn.sps.cdipp.dataservice.application.util;

public class ServiceNameConstants {
    public static String QUALITY_CONTROL = "quality_control";
    public static String EXPORTER = "exporter";
    public static String BARCODE = "barcode";
    public static String RESOURCE_IMPORTER = "resource-importer";
}
