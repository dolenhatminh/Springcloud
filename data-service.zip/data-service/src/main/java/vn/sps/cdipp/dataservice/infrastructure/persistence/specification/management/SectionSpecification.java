package vn.sps.cdipp.dataservice.infrastructure.persistence.specification.management;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.CollectionUtils;

import vn.sps.cdipp.dataservice.infrastructure.persistence.specification.criteria.SpeedReportCriteria;
import vn.sps.cdipp.domain.entity.management.ManagementEntity_;
import vn.sps.cdipp.domain.entity.management.SectionEntity;
import vn.sps.cdipp.domain.entity.management.SectionEntity_;
import vn.sps.cdipp.domain.entity.management.SessionEntity_;
import vn.sps.cdipp.domain.entity.management.TaskEntity_;

public class SectionSpecification {

    public static Specification<SectionEntity> searchSpeed(SpeedReportCriteria criteria) {
        return (root, query, cb) -> {
            List<Predicate> criteriaList = new ArrayList<Predicate>();
            if (!CollectionUtils.isEmpty(criteria.getProjects())) {
                criteriaList.add(
                    root
                        .join(SectionEntity_.session)
                        .join(SessionEntity_.management)
                        .join(ManagementEntity_.task)
                        .get(TaskEntity_.tenantId)
                        .in(criteria.getProjects()));
            }
            if (!CollectionUtils.isEmpty(criteria.getUsers())) {
                criteriaList.add(root.get(SectionEntity_.operator).in(criteria.getUsers()));
            }
            criteriaList.add(cb.equal(root.get(SectionEntity_.component), criteria.getComponant()));
            criteriaList.add(cb.isNotNull(root.get(SectionEntity_.operator)));
            criteriaList.add(cb.greaterThanOrEqualTo(root.get(SectionEntity_.startTime), criteria.getStartTime()));
            criteriaList.add(cb.lessThanOrEqualTo(root.get(SectionEntity_.endTime), criteria.getEndTime()));
            return cb.and(criteriaList.toArray(new Predicate[criteriaList.size()]));
        };
    }
}