package vn.sps.cdipp.dataservice.infrastructure.configuration.datasource;

import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;

@Configuration
@EnableJpaRepositories(basePackages="vn.sps.cdipp.dataservice.infrastructure.persistence.repository.customer",
						entityManagerFactoryRef = "customerEntityManagerFactory",
						transactionManagerRef="customerTransactionManager")
public class CustomerDatasourceConfiguration {

	@Autowired
	private JpaProperties jpaProperties;
	
	@Bean
	@ConfigurationProperties(prefix = "datasource.customer")
	public DataSource customerDatasource() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean customerEntityManagerFactory(EntityManagerFactoryBuilder builder, 
				@Qualifier("customerDatasource") DataSource customerDatasource) {
		Map<String, String> jpaProperties = this.jpaProperties.getProperties();
		return builder.dataSource(customerDatasource)
					  .packages(CustomerDataEntity.class.getPackage().getName())
					  .properties(jpaProperties)
					  .build();
	}
	
	@Bean
	public PlatformTransactionManager customerTransactionManager(@Qualifier("customerEntityManagerFactory") EntityManagerFactory customerEntityManagerFactory) {
		JpaTransactionManager jpaTransactionManager = new JpaTransactionManager(customerEntityManagerFactory);
		return jpaTransactionManager;
	}
}
