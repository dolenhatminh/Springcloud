package vn.sps.cdipp.dataservice.application.service.reporting.performance.compoment;

import java.util.Map;

interface ComponentPerformanceReporter<T> {
	
	Map<String, Object> analyze(T data);
}
