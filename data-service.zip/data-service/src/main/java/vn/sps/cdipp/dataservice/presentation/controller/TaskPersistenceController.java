package vn.sps.cdipp.dataservice.presentation.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.web.bind.annotation.*;
import vn.sps.cdipp.dataservice.application.service.message.gateway.TaskGateway;
import vn.sps.cdipp.dataservice.infrastructure.configuration.common.Enumeration.PersistenceLevel;

@RestController
@RequestMapping("task")
public class TaskPersistenceController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TaskPersistenceController.class);
	
	public static final String PERSISTENCE_LEVEL = "persistenceLevel";
	
	@Autowired
	private TaskGateway gateway;
	
	/**
	 * Persist task API
	 * @param jsonTask
	 * @param {@link PersistenceLevel} 
	 */
	@PostMapping("/persist/json")
	public void persistTask(@RequestBody String jsonTask, @RequestParam(defaultValue="-1", required=false) int level) {
		LOGGER.info("::: Receive Task with Pesistence Level {} ", PersistenceLevel.valueOf(level));
		Message<String> message = buildMessage(jsonTask, level);
		this.gateway.forwardTaskChannel(message);
	}
	
//	@PostMapping("/persist/json")
//	public void persistTask(@RequestBody String jsonTask, @RequestParam(defaultValue="2", required=false) int level) throws JsonProcessingException, IOException {
//		LOGGER.info("::: Receive ::: {}", level);
//		//LOGGER.info("::: Receive ::: {}", jsonTask);
//	}

	private Message<String> buildMessage(String payload, int level) {
		return MessageBuilder
				.withPayload(payload)
				.setHeader(PERSISTENCE_LEVEL, level)
				.build();
	}
}
