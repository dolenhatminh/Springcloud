package vn.sps.cdipp.dataservice.domain.reporting.request;

/**
 * 
 * @author nttung_3
 */
public class AbstractReportingRequest {
	
	private final String requestName;

	public AbstractReportingRequest(String requestName) {
		this.requestName = requestName;
	}

	/**
	 * @return the requestName
	 */
	public String getRequestName() {
		return requestName;
	}
	
	
}
