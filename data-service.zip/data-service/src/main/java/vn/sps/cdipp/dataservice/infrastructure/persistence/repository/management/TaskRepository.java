package vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import vn.sps.cdipp.domain.entity.management.TaskEntity;

@Repository
public interface TaskRepository extends JpaRepository<TaskEntity, Long>, JpaSpecificationExecutor<TaskEntity> {

	@Query("SELECT t FROM TaskEntity t WHERE t.taskId = :taskId")
	TaskEntity getTaskByTaskId(@Param("taskId") String taskId);

	@Query("SELECT t FROM TaskEntity t WHERE t.taskInstanceId = :taskInstanceId")
	TaskEntity getTaskByTaskInstanceId(@Param("taskInstanceId") String taskInstanceId);
	
	@Query("SELECT distinct t.batch.batchId, t.management.scannedDateTime "
		+ "FROM TaskEntity t "
		+ "WHERE t.management.scannedDateTime >= :from "
			+ "AND t.management.scannedDateTime <= :to "
		+ "ORDER BY t.management.scannedDateTime ASC")
	List<BatchIdAndScannedDate> getBatchIdsByScannedTime(@Param("from") long from, @Param("to") long to, Pageable pagination);
	
	@Query("SELECT t FROM TaskEntity t WHERE t.batch.batchId IN :batchIds" )
	List<TaskEntity> getManagementDataByBatchIds(@Param("batchIds") List<String> batchIds);
	
	@Query("SELECT t FROM TaskEntity t WHERE t.status = :status"
            + " and t.management.session.endTime >= :fromTime and t.management.session.endTime < :toTime")
    List<TaskEntity> getBatchIdForServiceNameInTimeRange(@Param("status") String status, @Param("fromTime") Long fromTime, @Param("toTime") Long toTime);
    
    @Query("SELECT t FROM TaskEntity t WHERE t.status = :status")
    List<TaskEntity> getTaskByStatus(@Param("status") String status);

    @Query("SELECT t FROM TaskEntity t WHERE t.batch.batchId = :batchId and t.status = :status")
    TaskEntity findByBatchIdAndStatus(@Param("batchId")String batchId,@Param("status") String status);
}
