/*
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.cdipp.dataservice.infrastructure.persistence.specification.criteria;

/**
 * The Class BatchCriteria.
 */
public class BatchCriteria {
	
	/** The from scanned time. */
	private Long fromScannedTime;
    
    /** The to scanned time. */
    private Long toScannedTime;
    
    /** The from due date time. */
    private Long fromDueDateTime;
    
    /** The to due date time. */
    private Long toDueDateTime;
    
    /** The status. */
    private String status;

    /**
     * Gets the from scanned time.
     *
     * @return the from scanned time
     */
    public Long getFromScannedTime() {
        return fromScannedTime;
    }

    /**
     * Sets the from scanned time.
     *
     * @param fromScannedTime the new from scanned time
     */
    public void setFromScannedTime(Long fromScannedTime) {
        this.fromScannedTime = fromScannedTime;
    }

    /**
     * Gets the to scanned time.
     *
     * @return the to scanned time
     */
    public Long getToScannedTime() {
        return toScannedTime;
    }

    /**
     * Sets the to scanned time.
     *
     * @param toScannedTime the new to scanned time
     */
    public void setToScannedTime(Long toScannedTime) {
        this.toScannedTime = toScannedTime;
    }

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the from due date time.
	 *
	 * @return the from due date time
	 */
	public Long getFromDueDateTime() {
		return fromDueDateTime;
	}

	/**
	 * Sets the from due date time.
	 *
	 * @param fromDueDateTime the new from due date time
	 */
	public void setFromDueDateTime(Long fromDueDateTime) {
		this.fromDueDateTime = fromDueDateTime;
	}

	/**
	 * Gets the to due date time.
	 *
	 * @return the to due date time
	 */
	public Long getToDueDateTime() {
		return toDueDateTime;
	}

	/**
	 * Sets the to due date time.
	 *
	 * @param toDueDateTime the new to due date time
	 */
	public void setToDueDateTime(Long toDueDateTime) {
		this.toDueDateTime = toDueDateTime;
	}
	
	
}
