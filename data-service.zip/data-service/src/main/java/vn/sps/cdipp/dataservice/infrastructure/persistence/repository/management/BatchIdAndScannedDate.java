package vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management;

public interface BatchIdAndScannedDate {
	
	String getBatchId();
	
	Long getScannedDateTime();
}
