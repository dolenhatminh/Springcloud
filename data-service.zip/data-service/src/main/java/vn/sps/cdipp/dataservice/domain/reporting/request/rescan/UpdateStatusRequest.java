/*
 * Class: UpdateStatusRequest
 *
 * Created on Sep 14, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
/**
 * 
 */
package vn.sps.cdipp.dataservice.domain.reporting.request.rescan;

import java.util.List;

/**
 * The Class UpdateStatusRequest.
 */
public class UpdateStatusRequest {
    
    /** The batch ids. */
    private List<String> batchIds;
    
    /** The request status. */
    private String requestStatus;
    
    /** The update status. */
    private String updateStatus;
    
    /**
     * Gets the batch ids.
     *
     * @return the batch ids
     */
    public List<String> getBatchIds() {
        return batchIds;
    }
    
    /**
     * Sets the batch ids.
     *
     * @param batchIds the new batch ids
     */
    public void setBatchIds(List<String> batchIds) {
        this.batchIds = batchIds;
    }
    
    /**
     * Gets the request status.
     *
     * @return the request status
     */
    public String getRequestStatus() {
        return requestStatus;
    }
    
    /**
     * Sets the request status.
     *
     * @param requestStatus the new request status
     */
    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }
    
    /**
     * Gets the update status.
     *
     * @return the update status
     */
    public String getUpdateStatus() {
        return updateStatus;
    }
    
    /**
     * Sets the update status.
     *
     * @param updateStatus the new update status
     */
    public void setUpdateStatus(String updateStatus) {
        this.updateStatus = updateStatus;
    }

}
