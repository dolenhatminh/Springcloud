/*
 * Class: MonitorServiceImpl
 *
 * Created on Sep 18, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
/**
 * 
 */
package vn.sps.cdipp.dataservice.application.service.monitor;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import vn.sps.cdipp.dataservice.application.util.ComponentConstants;
import vn.sps.cdipp.dataservice.application.util.ServiceNameConstants;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.customer.MonitorTaskRepository;
import vn.sps.cdipp.domain.Document;
import vn.sps.cdipp.domain.Management;
import vn.sps.cdipp.domain.Session;
import vn.sps.cdipp.domain.Task;
import vn.sps.cdipp.domain.entity.customer.MonitorTaskEntity;
import vn.sps.cdipp.domain.type.InputResourceType;

/**
 * The Class MonitorServiceImpl.
 */
@Service
public class MonitorServiceImpl implements MonitorService {
    
    /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(MonitorServiceImpl.class);

    /** The Constant PHYSICAL_BARCODE. */
    private static final String PHYSICAL_BARCODE = "physicalBarcode";
    
    /** The Constant DIGITAL_BARCODE. */
    private static final String DIGITAL_BARCODE = "digitalBarcode";

    /** The monitor task repository. */
    @Autowired
    private MonitorTaskRepository monitorTaskRepository;

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.cdipp.dataservice.application.service.monitor.MonitorService#handle(java.lang.String, vn.sps.cdipp.domain.Task)
     */
    public boolean handle(String username, Task task) {
        try {
            if (task == null || task.getData() == null || CollectionUtils.isEmpty(task.getData().getDocuments())) {
                return true;
            }
            this.process(username, task, task.getData().getDocuments());
        }
        catch (Exception e) {
            LOGGER.error("Error when process monitor task", e);
            return false;
        }
        return true;
    }

    /**
     * Process.
     *
     * @param username the username
     * @param task the task
     * @param documents the documents
     */
    private void process(String username, Task task, List<Document> documents) {
        for (Document document : documents) {
            MonitorTaskEntity monitorTaskEntity = this.monitorTaskRepository.findByDocumentId(document.getId());
            if (monitorTaskEntity == null) {
                monitorTaskEntity = new MonitorTaskEntity();
            }
            monitorTaskEntity.setAssigningUser(username);
            monitorTaskEntity.setDocumentId(document.getId());
            monitorTaskEntity.setDocumentType(document.getDocumentType());
            final Management management = task.getManagement();
            if (management != null) {
            	if (management.getSource().equals(InputResourceType.SFTP)) {
            		 monitorTaskEntity.setBarcode((String) document.getProcessingData().get(PHYSICAL_BARCODE));
				} else {
					monitorTaskEntity.setBarcode((String) document.getProcessingData().get(DIGITAL_BARCODE));
				}
                monitorTaskEntity.setDueDate(management.getDueDateTime());
                monitorTaskEntity.setScanDate(management.getScannedDateTime());
                this.setDataFromSection(monitorTaskEntity, management);
            }
            monitorTaskEntity.setStatus(task.getStatus());
            monitorTaskEntity.setUserGroup(task.getUserGroup());
            this.monitorTaskRepository.save(monitorTaskEntity);
        }
    }

    /**
     * Sets the data from section.
     *
     * @param monitorTaskEntity the monitor task entity
     * @param management the management
     */
    private void setDataFromSection(MonitorTaskEntity monitorTaskEntity, Management management) {
        Session session = management.getSession();
        if (session != null) {
            List<String> operator = session
                .getSections()
                .stream()
                .filter(s -> ComponentConstants.WEBVIEW.equals(s.getComponent()))
                .map(s -> {
                    return s.getOperator();
                })
                .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(operator)) {
                monitorTaskEntity.setAssignedUser(operator.get(0));
            }
            if (ServiceNameConstants.EXPORTER.equals(session.getServiceName())) {
                monitorTaskEntity.setExportDate(management.getReturnedTime());
            }
            if (ServiceNameConstants.RESOURCE_IMPORTER.equals(session.getServiceName())) {
				List<Long> endTimeImporter = session.getSections().stream()
						.filter(s -> ComponentConstants.IMPORTER.equals(s.getComponent()))
						.map(s -> {return s.getEndTime();})
						.collect(Collectors.toList());
                if (!CollectionUtils.isEmpty(endTimeImporter)) {
                	 monitorTaskEntity.setImportDate(endTimeImporter.get(0));
				}
            }
        }
    }
}
