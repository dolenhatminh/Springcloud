package vn.sps.cdipp.dataservice.infrastructure.configuration.datasource;

import org.hibernate.dialect.SQLServer2012Dialect;
import org.hibernate.type.StandardBasicTypes;

import java.sql.Types;

public class SQlServerDBDialect extends SQLServer2012Dialect {
	
	public SQlServerDBDialect() {
		 super();
		 registerHibernateType(Types.NVARCHAR, StandardBasicTypes.STRING.getName());
	}
}
