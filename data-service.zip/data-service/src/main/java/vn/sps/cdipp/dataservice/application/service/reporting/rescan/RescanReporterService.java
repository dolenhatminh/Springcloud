package vn.sps.cdipp.dataservice.application.service.reporting.rescan;

import java.util.List;

import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;
import vn.sps.cdipp.domain.entity.management.TaskEntity;

/**
 * The Interface RescanReporterService.
 */
public interface RescanReporterService {
	
	/**
     * Gets the batch id in time range.
     *
     * @param status the status
     * @param fromTime the from time
     * @param toTime the to time
     * @return the batch id in time range
     */
	List<TaskEntity> getBatchIdInTimeRange(String status, Long fromTime, Long toTime);
	
	/**
     * Gets the batch id needed rescan.
     *
     * @param status the status
     * @return the batch id needed rescan
     */
	List<TaskEntity> getBatchIdNeededRescan(String status);
	
	/**
     * Gets the customer data by batch id.
     *
     * @param batchIds the batch ids
     * @param exceptions the exceptions
     * @return the customer data by batch id
     */
	List<CustomerDataEntity> getCustomerDataByBatchId(List<String> batchIds, List<String> exceptions);
}
