package vn.sps.cdipp.dataservice.application.service.dao.impl;

import org.springframework.data.jpa.repository.JpaRepository;

import java.io.Serializable;

abstract class AbstractPersistenceService<T, ID extends Serializable> {
	
	protected JpaRepository<T, ID> repository;
	
	public AbstractPersistenceService(JpaRepository<T, ID> repository) {
		this.repository = repository;
	}

	protected void save (T data) {
		this.repository.save(data);
	};
	
	protected abstract void update (T data);
}
