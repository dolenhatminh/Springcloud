package vn.sps.cdipp.dataservice.application.service.reporting.performance.compoment;

import java.util.HashMap;
import java.util.Map;

import vn.sps.cdipp.dataservice.infrastructure.configuration.common.ReportingConstants.PerformanceReport;
import vn.sps.cdipp.domain.entity.management.TaskEntity;

class ImportingPerformanceReporter extends AbstractComponentPerformanceReporter {
	
	private static final String IMPORTER_RESOURCE_COMPOMENT = "resource-importer";

	public ImportingPerformanceReporter() {
		super(IMPORTER_RESOURCE_COMPOMENT);
	}

	/* (non-Javadoc)
	 * @see vn.sps.cdipp.dataservice.application.reporting.performance.ComponentPerformanceReporter#analyze(java.lang.Object)
	 */
	@Override
	public Map<String, Object> analyze(TaskEntity data) {
		Map<String, Object> managementData = new HashMap<>();
		Long importingTime = data.getManagement().getReceivedTime();
		managementData.put(PerformanceReport.IMPORTING_TIME, importingTime);
		return managementData;
	}
	
	
}
