package vn.sps.cdipp.dataservice.application.service.dao.rollback;

public interface GlobalInvokingData<T> {
	
	T fetchData(String key);
}
