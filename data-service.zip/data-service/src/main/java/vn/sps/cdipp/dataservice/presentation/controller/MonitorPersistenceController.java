/*
 * class: MonitorPersistenceController.java 
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 * 
 * @since Sep 18, 2018
 */
package vn.sps.cdipp.dataservice.presentation.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import vn.sps.cdipp.dataservice.application.service.monitor.MonitorService;
import vn.sps.cdipp.dataservice.domain.monitoring.MonitoringRequest;

/**
 * The Class MonitorPersistenceController.
 */
@RestController
@RequestMapping("monitor")
public class MonitorPersistenceController {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(MonitorPersistenceController.class);
	
	/** The monitor task repository. */
	@Autowired
	private MonitorService monitorTaskService;
	
	/**
     * Persist task.
     *
     * @param monitorTaskEntity the monitor task entity
     */
	@PostMapping("/persist")
	public void persistTask(@RequestBody MonitoringRequest request) {
	    final String username = request.getUsername();
		LOGGER.info("::: Receive Monitor Task for {} ", username);
		this.monitorTaskService.handle(username, request.getTask());
	}
}