/*
 * Class: RescanReportController
 *
 * Created on Sep 6, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
/**
 * 
 */
package vn.sps.cdipp.dataservice.presentation.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import vn.sps.cdipp.dataservice.application.service.reporting.rescan.RescanReporterService;
import vn.sps.cdipp.dataservice.domain.reporting.ReportDetails;
import vn.sps.cdipp.dataservice.domain.reporting.ReportResponse;
import vn.sps.cdipp.dataservice.domain.reporting.request.rescan.UpdateStatusRequest;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management.TaskRepository;
import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;
import vn.sps.cdipp.domain.entity.management.BatchEntity;
import vn.sps.cdipp.domain.entity.management.ManagementEntity;
import vn.sps.cdipp.domain.entity.management.TaskEntity;

/**
 * The Class RescanReportController.
 */
@RestController
@RequestMapping("report")
public class RescanReportController {

    /**
     * The Class RescanRequest.
     */
    static class RescanRequest implements Serializable {

        /** The Constant serialVersionUID. */
        private static final long serialVersionUID = 97436470336900756L;

        /** The status. */
        private String status;

        /** The exceptions. */
        private List<String> exceptions;

        /** The from time. */
        private Long fromTime;

        /** The to time. */
        private Long toTime;

        /**
         * Instantiates a new rescan request.
         */
        public RescanRequest() {
        }

        /**
         * Gets the exceptions.
         *
         * @return the exceptions
         */
        public List<String> getExceptions() {
            return exceptions;
        }

        /**
         * Gets the from time.
         *
         * @return the from time
         */
        public Long getFromTime() {
            return fromTime;
        }

        /**
         * Gets the to time.
         *
         * @return the to time
         */
        public Long getToTime() {
            return toTime;
        }

        /**
         * Sets the exceptions.
         *
         * @param exceptions the new exceptions
         */
        public void setExceptions(List<String> exceptions) {
            this.exceptions = exceptions;
        }

        /**
         * Sets the from time.
         *
         * @param fromTime the new from time
         */
        public void setFromTime(Long fromTime) {
            this.fromTime = fromTime;
        }

        /**
         * Sets the to time.
         *
         * @param toTime the new to time
         */
        public void setToTime(Long toTime) {
            this.toTime = toTime;
        }

        /**
         * Gets the status.
         *
         * @return the status
         */
        public String getStatus() {
            return status;
        }

        /**
         * Sets the status.
         *
         * @param status the new status
         */
        public void setStatus(String status) {
            this.status = status;
        }
    }

    /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(RescanReportController.class);

    /** The Constant SCAN_DATE_TIME. */
    private static final String SCAN_DATE_TIME = "scanDateTime";

    /** The rescan reporter service. */
    @Autowired
    private RescanReporterService rescanReporterService;

    /** The task repository. */
    @Autowired
    private TaskRepository taskRepository;

    /**
     * Auto rescan.
     *
     * @param status the status
     * @param exceptions the exceptions
     * @return the report response
     */
    @GetMapping("/rescan")
    public ReportResponse autoRescan(@RequestParam String status, @RequestParam List<String> exceptions) {
        LOGGER.info("::: [Process Data] get data with status {} :::", status);
        List<TaskEntity> taskEntities = this.rescanReporterService.getBatchIdNeededRescan(status);
        if (CollectionUtils.isEmpty(taskEntities)) {
            return null;
        }
        List<CustomerDataEntity> customers = this.getCustomerDataByBatchId(taskEntities, exceptions);
        return handleBuildRescanReportRespone(taskEntities, customers);
    }

    /**
     * Handle build rescan report respone.
     *
     * @param taskEntities the task entities
     * @param customers the customers
     * @return the report response
     */
    private ReportResponse handleBuildRescanReportRespone(
        List<TaskEntity> taskEntities,
        List<CustomerDataEntity> customers) {
        List<ReportDetails> response = new ArrayList<>();
        try {
            response = this.buildRescanReportRespone(taskEntities, customers);
        }
        catch (Exception e) {
            LOGGER.error("Error when return result for rescan report", e);
        }
        ReportResponse rr = new ReportResponse();
        rr.setData(response);
        return rr;
    }

    /**
     * Builds the rescan report respone.
     *
     * @param taskEntities the task entities
     * @param customers the customers
     * @return the list
     */
    private List<ReportDetails> buildRescanReportRespone(
        List<TaskEntity> taskEntities,
        List<CustomerDataEntity> customers) {
        List<ReportDetails> response = new ArrayList<>();
        for (TaskEntity taskEntity : taskEntities) {
            BatchEntity batch = taskEntity.getBatch();
            ReportDetails r = new ReportDetails();
            r.setBatchId(batch.getBatchId());
            Map<String, Object> map = new HashMap<>();
            final ManagementEntity management = taskEntity.getManagement();
            map.put(SCAN_DATE_TIME, management.getScannedDateTime());
            r.setManagementData(map);
            Optional<CustomerDataEntity> customer = customers
                .stream()
                .filter(c -> c.getBatchId().equals(batch.getBatchId()))
                .findFirst();
            if (customer.isPresent()) {
                r.setCustomerData(customer.get().getData());
                response.add(r);
            }
        }
        return response;
    }

    /**
     * Gets the customer data by batch id.
     *
     * @param taskEntities the task entities
     * @param exceptions the exceptions
     * @return the customer data by batch id
     */
    private List<CustomerDataEntity> getCustomerDataByBatchId(List<TaskEntity> taskEntities, List<String> exceptions) {
        List<String> batchIds = taskEntities.stream().map(entity -> entity.getBatch().getBatchId()).collect(
            Collectors.toList());
        return this.rescanReporterService.getCustomerDataByBatchId(batchIds, exceptions);
    }

    /**
     * Manual rescan.
     *
     * @param rescanRequest the rescan request
     * @return the report response
     */
    @PostMapping("/rescan/manual")
    public ReportResponse manualRescan(@RequestBody RescanRequest rescanRequest) {
        LOGGER.info(
            "::: [Process Data] get data with status {} from {} to {} :::",
            rescanRequest.getStatus(),
            rescanRequest.getFromTime(),
            rescanRequest.getToTime());
        List<TaskEntity> taskEntities = this.loadBatchIdsFromManagementData(
            rescanRequest.getStatus(),
            rescanRequest.getFromTime(),
            rescanRequest.getToTime());
        if (CollectionUtils.isEmpty(taskEntities)) {
            return null;
        }
        List<CustomerDataEntity> customers = this.getCustomerDataByBatchId(taskEntities, rescanRequest.getExceptions());
        return handleBuildRescanReportRespone(taskEntities, customers);
    }

    /**
     * Load batch ids from management data.
     *
     * @param status the status
     * @param fromTime the from time
     * @param toTime the to time
     * @return the list
     */
    private List<TaskEntity> loadBatchIdsFromManagementData(String status, Long fromTime, Long toTime) {
        List<TaskEntity> taskEntities = this.rescanReporterService.getBatchIdInTimeRange(status, fromTime, toTime);
        Set<String> batchIdAlreadySeen = new HashSet<>();
        taskEntities.removeIf(p -> !batchIdAlreadySeen.add(p.getBatch().getBatchId()));
        return taskEntities;
    }

    /**
     * Handle update status rescan.
     *
     * @param request the request
     * @return true, if successful
     */
    @PutMapping("rescan/update")
    public boolean handleUpdateStatusRescan(@RequestBody UpdateStatusRequest request) {
        try {
            this.updateStatusRescan(request);
        }
        catch (Exception e) {
            LOGGER.error("Error when update for rescan report", e);
            return false;
        }
        return true;
    }
    
    /**
     * Update status rescan.
     *
     * @param request the request
     * @throws Exception the exception
     */
    private void updateStatusRescan(UpdateStatusRequest request) throws Exception {
        for (String batchId : request.getBatchIds()) {
            LOGGER.info("::: [Process Data] update management data for batchId {} :::", batchId);
            TaskEntity taskEntity = this.taskRepository.findByBatchIdAndStatus(batchId, request.getRequestStatus());
            if (taskEntity != null) {
                taskEntity.setStatus(request.getUpdateStatus());
                this.taskRepository.save(taskEntity);
            }
        }
    }
}