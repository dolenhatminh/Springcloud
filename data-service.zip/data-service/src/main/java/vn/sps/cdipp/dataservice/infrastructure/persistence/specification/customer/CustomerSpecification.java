package vn.sps.cdipp.dataservice.infrastructure.persistence.specification.customer;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.CollectionUtils;

import vn.sps.cdipp.dataservice.infrastructure.persistence.specification.criteria.CustomerDataCriteria;
import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity;
import vn.sps.cdipp.domain.entity.customer.CustomerDataEntity_;

public class CustomerSpecification {

    public static Specification<CustomerDataEntity> search(CustomerDataCriteria criteria) {
        return (root,query, cb) -> {
            Predicate p = null;
            if(!CollectionUtils.isEmpty(criteria.getBatchIdList())) {
                p = root.get(CustomerDataEntity_.batchId).in(criteria.getBatchIdList());
            }

            return p;
        };
    }
}
