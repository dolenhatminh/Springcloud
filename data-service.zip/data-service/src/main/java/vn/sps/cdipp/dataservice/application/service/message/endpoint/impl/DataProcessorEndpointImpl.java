/*
 * Class: DataServiceProcessorEndpointImpl
 *
 * Created on Aug 31, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
/**
 * 
 */
package vn.sps.cdipp.dataservice.application.service.message.endpoint.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.IntegrationMessageHeaderAccessor;
import org.springframework.integration.annotation.Aggregator;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.Router;
import org.springframework.integration.annotation.Splitter;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.transaction.annotation.Transactional;
import vn.sps.cdipp.dataservice.application.service.dao.GlobalDataAccess;
import vn.sps.cdipp.dataservice.infrastructure.configuration.common.Enumeration.PersistenceLevel;
import vn.sps.cdipp.dataservice.infrastructure.configuration.message.property.MessageChannelProperty;
import vn.sps.cdipp.dataservice.presentation.controller.TaskPersistenceController;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * The Class DataServiceProcessorEndpointImpl.
 */
@MessageEndpoint("dataProcessor")
class DataProcessorEndpointImpl  {
    
    /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(DataProcessorEndpointImpl.class);
    
    /** The data service repository. */
    @Autowired
    private GlobalDataAccess<Object> globalDataAccess;
    
    /** The message property configuration. */
    @Autowired
    private MessageChannelProperty messageChannelProperty;

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.cdipp.dataservice.application.service.message.endpoint.DataProcessorEndpoint#prepareMessage(java.lang.String)
     */
    @Splitter(inputChannel = "taskChannel", outputChannel = "distributeChannel")
    public List<String> prepareMessage(String jsonTask) {
        LOGGER.info("::: [Process Data] duplicate message twice :::");
        return Arrays.asList(jsonTask, jsonTask);
    }
    
    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.cdipp.dataservice.application.service.message.endpoint.DataProcessorEndpoint#distributeMessage(java.util.Map, org.springframework.messaging.Message)
     */
    @Router(inputChannel = "distributeChannel")
    public String distributeMessage(@Headers Map<String, Object> headers, Message<?> message) {
        int destinationKey = (int) headers.get(IntegrationMessageHeaderAccessor.SEQUENCE_NUMBER);
        LOGGER.info("::: [Process Data] router message by SEQUENCE_NUMBER = {} :::", destinationKey);
        return this.messageChannelProperty.getChannelMatrix().get(destinationKey);
    }
    
    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.cdipp.dataservice.application.service.message.endpoint.DataProcessorEndpoint#persistData(org.springframework.messaging.Message, java.util.Map)
     */
    @Transactional(transactionManager="chainedTransactionManager")
    @Aggregator(inputChannel = "persistDataChannel")
    public boolean persistData(List<Message<?>> messages) {
        try {
            for (Message<?> message : messages) {
                int level = (int) message.getHeaders().get(TaskPersistenceController.PERSISTENCE_LEVEL);
                PersistenceLevel persistenceLevel = PersistenceLevel.valueOf(level);
                this.globalDataAccess.handleRequest(persistenceLevel, message.getPayload());
            }
        }
        catch (Exception e) {
            LOGGER.error("Error when persist data", e);
            return false;
        }
        return true;
    }
}
