package vn.sps.cdipp.dataservice.application.service.reporting.performance.compoment;

import java.util.HashMap;
import java.util.Map;

import vn.sps.cdipp.dataservice.infrastructure.configuration.common.ReportingConstants.PerformanceReport;
import vn.sps.cdipp.domain.entity.management.TaskEntity;

class ICapCapturingPerformanceReporter extends AbstractComponentPerformanceReporter {
	
	private static final String ICAP_CAPTURING_COMPOMENT = "icapUsers";
	
	public ICapCapturingPerformanceReporter() {
		super(ICAP_CAPTURING_COMPOMENT);
	}

	/* (non-Javadoc)
	 * @see vn.sps.cdipp.dataservice.application.reporting.performance.impl.compoment.ComponentPerformanceReporter#analyze(java.lang.Object)
	 */
	@Override
	public Map<String, Object> analyze(TaskEntity data) {
		Map<String, Object> managementData = new HashMap<>();
		Long icapAlreadyCaptureTime = data.getManagement().getReceivedTime();
		Long icapCaptureDone = data.getManagement().getReturnedTime();
		managementData.put(PerformanceReport.ICAP_NORMAL_LOGGING_TIME, icapAlreadyCaptureTime);
		managementData.put(PerformanceReport.ICAP_NORMAL_DONE, icapCaptureDone);
		return managementData;
	}
	
	
}
