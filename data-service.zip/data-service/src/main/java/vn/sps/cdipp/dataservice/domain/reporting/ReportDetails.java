package vn.sps.cdipp.dataservice.domain.reporting;

import java.util.Map;

/**
 * @author nttung_3
 * Response Data Model
 */
public class ReportDetails {
	
	private String batchId;
	
	private String customerData;
	
	private Map<String, Object> managementData;

	/**
	 * @return the batchId
	 */
	public String getBatchId() {
		return batchId;
	}

	/**
	 * @param batchId the batchId to set
	 */
	public ReportDetails setBatchId(String batchId) {
		this.batchId = batchId;
		return this;
	}

	/**
	 * @return the customerData
	 */
	public String getCustomerData() {
		return customerData;
	}

	/**
	 * @param customerData the customerData to set
	 */
	public ReportDetails setCustomerData(String customerData) {
		this.customerData = customerData;
		return this;
	}

	/**
	 * @return the managementData
	 */
	public Map<String, Object> getManagementData() {
		return managementData;
	}

	/**
	 * @param managementData the managementData to set
	 */
	public ReportDetails setManagementData(Map<String, Object> managementData) {
		this.managementData = managementData;
		return this;
	}
	
}
