package vn.sps.cdipp.dataservice.infrastructure.configuration.common;

import java.util.HashMap;
import java.util.Map;

public final class Enumeration {
	
	public enum ICapStatus {
		QC_DONE,
		EXPORT_DONE;
	}
	
	public enum PersistenceLevel {
		
		/**
		 * Create both Customer and Management Data
		 * Using for after Importing Task
		 * Customer Data: Create a new record
		 * Management Data: Create a new Batch record
		 */
		CREATE_ALL(-1),
		
		/**
		 * Using for READY task
		 * Customer Data: Do nothing
		 * Management Data: Update Batch record and create an new Task
		 */
		UPDATE_MANA_ONLY(1),
		
		/**
		 * Using for DONE task
		 * Customer Data: Create a new record
		 * Management Data: Update Batch record and update Task
		 */
		CREATE_CUST_AND_UPDATE_MANA(2);
		
		private final int value;
		
		private static final Map<Integer, PersistenceLevel> levelMatrix = new HashMap<>();
		
		static {
			for (PersistenceLevel level : PersistenceLevel.values()) {
				levelMatrix.put(level.getValue(), level);
			}
		}

		private PersistenceLevel(int value) {
			this.value = value;
		}

		public int getValue() {
			return value;
		}
		
		public static PersistenceLevel valueOf(int value) {
			return levelMatrix.get(value);
		}

	}
}
