package vn.sps.cdipp.dataservice.domain.reporting.request.performance;

import vn.sps.cdipp.dataservice.domain.reporting.request.AbstractReportingRequest;

/**
 * The Class SystemPerformanceRequest.
 */
public class SystemPerformanceRequest extends AbstractReportingRequest {
	
	/** The Constant SYSTEM_PERFORMANCE_REPORTING_REQUEST. */
	private static final String SYSTEM_PERFORMANCE_REPORTING_REQUEST = "SYSTEM_PERFORMANCE_REPORTING_REQUEST";
	
    /** The from date. */
    private long fromDate;

    /** The to date. */
    private long toDate;
    
    /** The page. */
    private int page;

    /** The size. */
    private int size;
	
	/**
     * Instantiates a new system performance request.
     */
	public SystemPerformanceRequest() {
		super(SYSTEM_PERFORMANCE_REPORTING_REQUEST);
	}

    /**
     * Gets the from scanned date time.
     *
     * @return the from scanned date time
     */
    public long getFromDate() {
        return fromDate;
    }

    /**
     * Sets the from scanned date time.
     *
     * @param fromDate the new from scanned date time
     */
    public void setFromDate(long fromDate) {
        this.fromDate = fromDate;
    }

    /**
     * Gets the to scanned date time.
     *
     * @return the to scanned date time
     */
    public long getToDate() {
        return toDate;
    }

    /**
     * Sets the to scanned date time.
     *
     * @param toDate the new to scanned date time
     */
    public void setToDate(long toDate) {
        this.toDate = toDate;
    }

    /**
     * Gets the start.
     *
     * @return the start
     */
    public int getPage() {
        return page;
    }

    /**
     * Sets the start.
     *
     * @param page the new start
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * Gets the length.
     *
     * @return the length
     */
    public int getSize() {
        return size;
    }

    /**
     * Sets the length.
     *
     * @param size the new length
     */
    public void setSize(int size) {
        this.size = size;
    }
}
