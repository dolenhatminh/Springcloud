package vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import vn.sps.cdipp.domain.entity.management.SectionEntity;

@Repository
public interface SectionRepository extends CrudRepository<SectionEntity, Long>, JpaSpecificationExecutor<SectionEntity> {
}
