/*
 * Class: SpeedReportServiceImpl
 *
 * Created on Sep 13, 2018
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
/**
 * 
 */
package vn.sps.cdipp.dataservice.application.service.reporting.speed;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import vn.sps.cdipp.dataservice.application.util.ComponentConstants;
import vn.sps.cdipp.dataservice.domain.reporting.request.speed.SpeedReportRequest;
import vn.sps.cdipp.dataservice.domain.reporting.response.SpeedMonitoringDocument;
import vn.sps.cdipp.dataservice.domain.reporting.response.SpeedMonitoringOperator;
import vn.sps.cdipp.dataservice.domain.reporting.response.SpeedReportResponse;
import vn.sps.cdipp.dataservice.domain.reporting.response.UserSpeedDetails;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management.SectionRepository;
import vn.sps.cdipp.dataservice.infrastructure.persistence.specification.criteria.SpeedReportCriteria;
import vn.sps.cdipp.dataservice.infrastructure.persistence.specification.management.SectionSpecification;
import vn.sps.cdipp.domain.entity.management.SectionEntity;

/**
 * The Class SpeedReportServiceImpl.
 */
@Service
public class SpeedReportServiceImpl implements SpeedReportService {

    /** The section repository. */
    @Autowired
    private SectionRepository sectionRepository;

    /**
     * Builds the speed report criteria.
     *
     * @param request the request
     * @return the specification
     */
    private Specification<SectionEntity> buildSpeedReportCriteria(SpeedReportRequest request) {
        SpeedReportCriteria speedReportSC = new SpeedReportCriteria();
        speedReportSC.setProjects(request.getProjects());
        speedReportSC.setComponant(ComponentConstants.WEBVIEW);
        speedReportSC.setUsers(request.getUsers());
        speedReportSC.setStartTime(request.getStartTime());
        speedReportSC.setEndTime(request.getEndTime());
        return SectionSpecification.searchSpeed(speedReportSC);
    }

    /**
     * Builds the speed report order.
     *
     * @param request the request
     * @return the page request
     */
    private PageRequest buildSpeedReportOrder(SpeedReportRequest request) {
        Order order = request.getOrder().equalsIgnoreCase(Direction.DESC.toString())
                ? new Order(Direction.DESC, request.getFieldSort())
                : new Order(Direction.ASC, request.getFieldSort());
        Sort sort = new Sort(order);
        return new PageRequest(request.getPage(), request.getLength(), sort);
    }

    /**
     * Builds the speed report response.
     *
     * @param data the data
     * @return the speed report response
     */
    private SpeedReportResponse buildSpeedReportResponse(List<SectionEntity> data) {
        SpeedReportResponse response = new SpeedReportResponse();
        List<SpeedMonitoringOperator> speedMonitoringOperators = new ArrayList<>();
        Map<UserSpeedDetails, List<SpeedMonitoringDocument>> map = new LinkedHashMap<>();
        for (SectionEntity section : data) {
            UserSpeedDetails user = new UserSpeedDetails(section.getOperator(), null);
            SpeedMonitoringDocument document = new SpeedMonitoringDocument();
            document.setBatchId(section.getSession().getManagement().getTask().getBatch().getBatchId());
            document.setProjectName(section.getSession().getManagement().getTask().getTenantId());
            document.setStartTime(section.getStartTime());
            document.setEndTime(section.getEndTime());
            if (!map.containsKey(user)) {
                List<SpeedMonitoringDocument> documents = new ArrayList<>();
                documents.add(document);
                map.put(user, documents);
            }
            else {
                map.get(user).add(document);
            }
        }
        map.forEach((key, value) -> {
            speedMonitoringOperators.add(new SpeedMonitoringOperator(key.getUserName(), key.getFullName(), value));
        });
        response.setSpeedMonitoringOperators(speedMonitoringOperators);
        return response;
    }

    /**
     * Gets the speed report information.
     *
     * @param request the request
     * @return the speed report information
     */
    private List<SectionEntity> getSpeedReportInformation(SpeedReportRequest request) {
        Pageable page = this.buildSpeedReportOrder(request);
        Specification<SectionEntity> searchTaskSpecs = this.buildSpeedReportCriteria(request);
        return this.sectionRepository.findAll(searchTaskSpecs, page).getContent();
    }

    /**
     * {@inheritDoc}
     * 
     * @see vn.sps.cdipp.dataservice.application.service.reporting.speed.SpeedReportService#handleSpeedReport(vn.sps.cdipp.dataservice.domain.reporting.request.speed.SpeedReportRequest)
     */
    public SpeedReportResponse handleSpeedReport(SpeedReportRequest request) {
        List<SectionEntity> data = this.getSpeedReportInformation(request);
        return this.buildSpeedReportResponse(data);
    }
}