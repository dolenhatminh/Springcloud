package vn.sps.cdipp.dataservice.application.service.message.gateway;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.messaging.Message;

@MessagingGateway
public interface TaskGateway {
	
	@Gateway(requestChannel="taskChannel")
	boolean forwardTaskChannel(Message<String> message);
}
