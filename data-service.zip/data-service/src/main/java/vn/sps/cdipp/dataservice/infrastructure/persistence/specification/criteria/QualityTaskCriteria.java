package vn.sps.cdipp.dataservice.infrastructure.persistence.specification.criteria;

public class QualityTaskCriteria {
    private Long fromScannedTime;
    private Long toScannedTime;
    private String serviceName;

    public Long getFromScannedTime() {
        return fromScannedTime;
    }

    public void setFromScannedTime(Long fromScannedTime) {
        this.fromScannedTime = fromScannedTime;
    }

    public Long getToScannedTime() {
        return toScannedTime;
    }

    public void setToScannedTime(Long toScannedTime) {
        this.toScannedTime = toScannedTime;
    }

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
    
    
    
}
