/*
 * class: MonitorPersistenceController.java 
 *
 * (c) Copyright Swiss Post Solutions Ltd, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 * 
 * @since Sep 24, 2018
 */
package vn.sps.cdipp.dataservice.presentation.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import vn.sps.cdipp.dataservice.application.service.reporting.productivity.ProductivityReporterService;

@RestController()
@RequestMapping("barcode")
public class BarcodeController {

    @Autowired
    private ProductivityReporterService reportService;

    /**
     * @param barcode
     * @return
     * @throws MissingServletRequestParameterException
     */
    @GetMapping("/duplicate")
    public boolean validateBarcode(@RequestParam("barcode") String barcode, @RequestParam("source") String source)
            throws MissingServletRequestParameterException {
        if (StringUtils.isBlank(barcode)) {
            throw new MissingServletRequestParameterException("barcode", String.class.getName());
        }
        if (StringUtils.isBlank(source)) {
            throw new MissingServletRequestParameterException("source", String.class.getName());
        }
        return this.reportService.checkBarcode(barcode, source);
    }
}
