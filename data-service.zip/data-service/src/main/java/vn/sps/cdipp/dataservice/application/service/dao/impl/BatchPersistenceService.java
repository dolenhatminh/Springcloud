package vn.sps.cdipp.dataservice.application.service.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;

import vn.sps.cdipp.dataservice.application.service.dao.PersistentService;
import vn.sps.cdipp.dataservice.application.util.BatchEntityBuilder;
import vn.sps.cdipp.dataservice.infrastructure.configuration.common.Enumeration.PersistenceLevel;
import vn.sps.cdipp.dataservice.infrastructure.persistence.repository.management.BatchRepository;
import vn.sps.cdipp.domain.Task;
import vn.sps.cdipp.domain.entity.management.BatchEntity;

@Service
class BatchPersistenceService extends AbstractPersistenceService<BatchEntity, String> implements PersistentService<BatchEntity>{

	  /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(BatchPersistenceService.class);
	
	public BatchPersistenceService(BatchRepository repository) {
		super(repository);
	}

	@Override
	public void handle(PersistenceLevel level, BatchEntity data) {
		boolean isUpdate = (level == PersistenceLevel.CREATE_CUST_AND_UPDATE_MANA 
				|| level == PersistenceLevel.UPDATE_MANA_ONLY);
		if (isUpdate) {
			LOGGER.info("::: [Process Management Data] update management data with batch: {} :::", data.getBatchId());
			this.update(data);
		} else {
			LOGGER.info("::: [Process Management Data] create management data with batch: {} :::", data.getBatchId());
			try {
				BatchEntity batchEntity = BatchEntityBuilder.buildBatch(new BatchEntity(), data.getTransientTask() , data.getBatchId());
				this.save(batchEntity);
			} catch (JsonProcessingException e) {
				LOGGER.error("Building new BatchEntity with batchId {} is error: ", data.getBatchId(), e);
			}
			
		}
	}

	/* (non-Javadoc)
	 * @see vn.sps.cdipp.dataservice.application.service.dao.impl.AbstractPersistenceService#update(java.lang.Object)
	 */
	@Override
	protected void update(BatchEntity data) {
		BatchEntity oriData = this.repository.findOne(data.getBatchId());
		Task task = data.getTransientTask();
		try {
			BatchEntity updatedData = BatchEntityBuilder.buildBatch(oriData, task, data.getBatchId());
			this.repository.save(updatedData);
		} catch (JsonProcessingException e) {
			LOGGER.error("Building updated BatchEntity with batchId {} is error: ", data.getBatchId(), e);
		}
	}
	
}
