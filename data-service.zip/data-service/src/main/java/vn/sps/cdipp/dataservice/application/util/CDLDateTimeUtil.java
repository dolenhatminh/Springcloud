package vn.sps.cdipp.dataservice.application.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class CDLDateTimeUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(CDLDateTimeUtil.class.getName());

    // example: 2008-09-15T15:53:00+07:00
    public static ZonedDateTime isoStringToZonedDateTime(final String isoDateTimeStr) {
        if (StringUtils.isBlank(isoDateTimeStr)) {
            return null;
        }
        ZonedDateTime zdt =
                ZonedDateTime.parse(isoDateTimeStr, DateTimeFormatter.ISO_OFFSET_DATE_TIME.withZone(ZoneId.systemDefault()));
        return zdt;
    }
}
