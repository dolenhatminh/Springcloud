sudo systemctl disable cdipp-data-service.service
