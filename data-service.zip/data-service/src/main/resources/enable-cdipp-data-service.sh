sudo systemctl enable cdipp-data-service.service
