sudo systemctl reload-or-restart cdipp-data-service.service
