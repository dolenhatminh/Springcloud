sudo systemctl status cdipp-data-service.service -l
