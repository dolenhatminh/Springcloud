package vn.sps.cdipp.dataservice;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import vn.sps.cdipp.dataservice.domain.reporting.ReportResponse;

public class QualityReportTests {
	
	@Test
	public void testQualityReport() {
		RestTemplate restTemplate = new RestTemplate();
		
		String url = "http://localhost:8080/reporter/quality?fromScannedDateTime={param1}&toScannedDateTime={param2}";

		Map<String, String> uriVariables = new HashMap<>();
		uriVariables.put("param1", "2018-09-07T00:00:00.000+08:00");
		uriVariables.put("param2", "2018-09-10T00:00:00.000+08:00");
		
		ResponseEntity<ReportResponse> responseEntity = restTemplate.exchange(url, HttpMethod.GET, null, ReportResponse.class, uriVariables);
		ReportResponse report = responseEntity.getBody();
				
		assertThat(report).isNotNull();
	}
}
