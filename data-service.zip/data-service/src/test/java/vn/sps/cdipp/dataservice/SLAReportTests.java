package vn.sps.cdipp.dataservice;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import vn.sps.cdipp.dataservice.application.util.CDLDateTimeUtil;
import vn.sps.cdipp.dataservice.domain.reporting.ReportResponse;

public class SLAReportTests {
	
	@Test
	public void testSimpleQualityReport() {
		RestTemplate restTemplate = new RestTemplate();
		
		String url = "http://localhost:8080/reporter/sla?fromDueDateTime={param1}&toDueDateTime={param2}";

		Map<String, String> uriVariables = new HashMap<>();
		uriVariables.put("param1", "2018-09-09T00:00:00.000+08:00");
		uriVariables.put("param2", "2018-09-12T00:00:00.000+08:00");
		
		ResponseEntity<ReportResponse> responseEntity = restTemplate.exchange(url, HttpMethod.GET, null, ReportResponse.class, uriVariables);
		ReportResponse report = responseEntity.getBody();

		assertThat(report.getData()).isNotNull();
	}

	@Test
	public void testDateTime() {
		String dateTime = "2018-09-11T05:25:00.905+07:00";
		ZonedDateTime zdt = CDLDateTimeUtil.isoStringToZonedDateTime(dateTime);
		assertThat(zdt).isNotNull();
	}
}
